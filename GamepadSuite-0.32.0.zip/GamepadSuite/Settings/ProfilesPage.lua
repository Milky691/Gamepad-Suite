-- The Profiles page of the settings window: what each button does on it. The rules are in
-- ProfilesModel.lua and BuildPageModel.lua, the frames in ProfilesDraw.lua, the profiles in the
-- store (Core/Profiles.lua), the builds in Core/Builds.lua.
-- The builds of this character stand first. A on another build is held, as for Reset All
-- Settings: that build is then in use. A on the build in use opens its page: Name (A asks the
-- addon's on-screen keyboard for it; without that keyboard the name box takes a real keyboard, as
-- on My Wheels), Gear Set and Talents (A or left and right change them), Back. New Build makes a
-- copy of the build in use. A on a profile is held too: it goes into the build in use, and Undo
-- Last Profile gives the old binds back (and the build before, after a switch). X takes a build or
-- a profile off the list. Export as Text shows the build in use as a text in a box, selected, for
-- the player to copy; Import from Text opens the box empty, for a text another player made.
local _, ns = ...

local Model, BuildPage, Store, Builds, Draw = ns.SettingsProfilesModel, ns.SettingsBuildPageModel, ns.Profiles, ns.Builds, ns.SettingsProfilesDraw
local Rules, Count = ns.BuildRules, ns.ProfileRules.Count

local Page = {}
ns.SettingsProfiles = Page

local state = Model.New()
local lines, look -- the lines of the list and the profile in focus, read again at each draw
local exported    -- the text to copy, while its box is open
local typing      -- true while the player types a build's name in the name box with a real keyboard
local told        -- the log has which way the name was asked for (one line a session)

local function comes()
    return look and look.comes
end

-- True when the page is a tab of the window, and not a page that a row opened: the window has
-- no page under this one then (as Health/Page.lua asks it).
local function isTab()
    return ns.Settings ~= nil and #ns.Settings.State().stack == 0
end

-- This character's builds as the list shows them.
local function buildLines()
    local all, out = Builds.All(), {}
    for at, build in ipairs(all.list) do
        out[at] = { name = build.name, use = at == all.use }
    end
    out.more = #all.list < Rules.MOST
    return out
end

-- What the parchment shows of build `at`.
local function info(at)
    local all = Builds.All()
    local build = all.list[at]
    local binds, wheels = Count(build)
    return { name = build.name, use = at == all.use, binds = binds, wheels = wheels, gear = build.gear, talent = build.talent,
        roles = BuildPage.Roles(Rules.ROLES, build.roles), talents = Builds.HasTalents() }
end

local function note()
    return state.note and (Model.NOTE[state.note] or state.note) or nil
end

local function draw()
    local panel, shown
    local use = Builds.All().use
    if state.inside then
        -- the page of the build in use: a plain list, with room above Back
        local sets = Builds.GearSets()
        lines = BuildPage.Lines(Builds.Current(), { talents = Builds.HasTalents(), sets = sets })
        state.line = math.max(1, math.min(state.line, #lines))
        shown = {}
        for index, line in ipairs(lines) do
            shown[index] = { line = line, index = index, gap = line.kind == "back" }
        end
        panel = BuildPage.Panel(lines[state.line], info(use), Store.Me().name, sets)
        panel.note = note() or panel.note
    else
        lines = Model.Lines(Store.List(), Store.CanUndo(), ns.Adapter.ClassName, isTab(), state.page, buildLines())
        Model.Fit(state, lines)
        shown = Model.Shown(lines)
        local line = lines[state.line]
        look = line.kind == "profile" and Store.Look(line.entry) or nil
        if line.kind == "build" or line.kind == "new" then
            panel = BuildPage.Panel(line, line.build and info(line.build), Store.Me().name, line.build and Builds.GearSets())
            panel.note = note()
        else
            panel = Model.Panel(state, lines, look, Store.Me().name, Builds.Current().name)
            -- another character's build brings its role switches: its card shows them, as an own build's does
            -- (an old file's true or false in the words a load gives them)
            if line.kind == "profile" and line.entry.kind == "build" then
                panel.roles = BuildPage.Roles(Rules.ROLES, Rules.FixRoles(Rules.Copy(line.entry.profile.roles), Store.Me().class))
            end
        end
    end
    Draw.Page(shown, panel, state.line, state.box ~= nil, typing)
end

-- A full draw: the window opened this page, or came back to it. What this character can use is
-- read again from the game, the last note is gone, and the page shows the list.
function Page.Draw()
    Store.Fresh()
    state.note, state.used, state.hold, state.armed, state.inside = nil, nil, nil, nil, nil
    draw()
end

-- After an action on this page: draw it again, and the legend, because its words follow the focus.
local function redraw(sound)
    ns.Adapter.Sound(sound or "IG_MAINMENU_OPTION")
    draw()
    ns.SettingsDraw.Legend()
end

local function openBox(kind, text)
    state.box, state.note, exported = kind, kind, kind == "export" and text or nil
    Draw.OpenBox(text)
end

local function closeBox()
    if not state.box then
        return false
    end
    state.box, state.note, exported = nil, nil, nil
    Draw.CloseBox()
    return true
end

-- The build in use gets the typed name (an empty one gives it a number). A name another build has is not taken.
local function named(text)
    local name, why = Builds.Rename(Builds.All().use, text)
    state.note = not name and why or nil
    redraw()
end

-- The typing in the name box ends. With a text, the build gets it; with none, the name stays.
local function doneTyping(text)
    if not typing then
        return
    end
    typing = false
    Draw.StopTyping()
    if text then
        named(text)
    else
        redraw()
    end
end

-- A on Name. The addon's on-screen keyboard asks for the name and has the controller while it is
-- open; the build gets the name when the player confirms it. When that keyboard is not there, the
-- name box takes a real keyboard. A build with no name of its own ("Build 2") starts the text empty.
local function rename()
    local name = Builds.Current().name
    local text = name:find("^Build %d+$") and "" or name
    local asked = ns.Keyboard and ns.Keyboard.on and ns.Keyboard.Ask("Build name", text, Rules.NAME_MOST, named)
    if not asked then
        typing = true
        Draw.StartTyping(text)
    end
    if not told then
        told = true
        ns.Log.Add("builds", "A on the name box: " .. (asked and "the on-screen keyboard was asked" or "no on-screen keyboard, the box takes a real keyboard"))
    end
    redraw()
end

-- Left, right or A on Gear Set or Talents: the next choice that way.
local function change(step)
    local line, build = lines[state.line], Builds.Current()
    if line.kind == "gear" then
        local choices = { "None" }
        for _, name in ipairs(Builds.GearSets()) do
            choices[#choices + 1] = name
        end
        Builds.SetGear(BuildPage.Step(choices, build.gear, step))
    elseif line.kind == "talents" then
        Builds.SetTalent(BuildPage.Talent(BuildPage.Step(BuildPage.TALENTS, BuildPage.TalentName(build.talent), step)))
    else
        return
    end
    redraw()
end

-- From the build's page back to the list, with the focus on the build in use.
local function leave()
    state.inside, state.note, state.want = nil, nil, "build" .. Builds.All().use
end

-- True while a text box is open or a name is typed. Every button belongs to the keyboard then; B
-- alone closes the box or ends the typing. With no button given, this only says if one is open.
function Page.Typing(what)
    if typing then
        if what == "B" then
            doneTyping(Draw.TypedText())
        end
        return true
    elseif not state.box then
        return false
    end
    if what == "B" and closeBox() then
        redraw()
    end
    return true
end

function Page.ListOpen()
    return false
end

function Page.ChangeList()
end

-- D-pad. Up and down move the focus; on the build's page left and right change a choice.
function Page.Move(dy, dx)
    if state.inside then
        if dy ~= 0 then
            state.line, state.note = (state.line + dy - 1) % #lines + 1, nil
            redraw("U_CHAT_SCROLL_BUTTON")
        elseif dx and dx ~= 0 then
            change(dx)
        end
    elseif dy ~= 0 and Model.Move(state, lines, dy) then
        redraw("U_CHAT_SCROLL_BUTTON")
    end
end

-- A went down. "back" tells the window to go back; "hold" tells it to start the hold. On Next or
-- Previous the rules have set the page: the draw at the end shows it.
function Page.Press()
    if state.inside then
        local kind = lines[state.line].kind
        if kind == "name" then
            return rename()
        elseif kind == "back" then
            leave()
            return redraw()
        end
        return change(1)
    end
    local what = Model.Press(state, lines, comes())
    if what == "back" or what == "hold" or not what then
        return what
    elseif what == "open" then
        state.inside, state.line, state.note = true, 1, nil
    elseif what == "new" then
        local at = Builds.Add()
        state.note, state.want = at and ("Made " .. Builds.Current().name .. ". It is in use now.") or nil, at and ("build" .. at) or nil
    elseif what == "export" then
        local text = Store.Text()
        if text then
            openBox("export", text)
        else
            state.note = "noText"
        end
    elseif what == "import" then
        if Store.CanText() then
            openBox("import", "")
        else
            state.note = "noText"
        end
    elseif what == "undo" then
        -- (after a switch it is a switch back: the page names the build)
        local ok, at = Builds.Undo()
        state.note = (at and ("Done: " .. Builds.Current().name .. " is in use again.")) or (ok and "undone") or (ns.Adapter.InCombat() and "fight") or nil
    end
    redraw()
end

-- The list line that shows the bar of the hold: the profile's or the build's, while the hold is its own.
function Page.HoldRow()
    return state.hold and Draw.FocusRow(state.line) or nil
end

-- A was held to the end: on a profile this character uses it; on a build it switches to it.
function Page.Held()
    local what = Model.Held(state, lines)
    local line = lines[state.line]
    if what == "use" then
        state.used = Store.Use(line.entry)
        state.note = not state.used and "fight" or nil
    elseif what == "switch" then
        -- (in combat the switch waits for its end, and the chat says so: the page says the same)
        local waits = ns.Adapter.InCombat()
        Builds.Request(line.build)
        state.note, state.want = waits and (line.name .. " comes in when combat ends.") or ("Done: " .. line.name .. " is in use."), "build" .. line.build
    else
        return
    end
    redraw()
end

-- X: the first press asks, the second takes the build or the profile in focus off the list.
function Page.Clear()
    if state.inside then
        return
    end
    local what = Model.Clear(state, lines)
    local line = lines[state.line]
    if what == "remove" and line.kind == "build" then
        Builds.Remove(line.build)
    elseif what == "remove" then
        Store.Remove(line.entry)
    end
    if what then
        redraw()
    end
end

-- B: from the build's page back to the list. Else B goes back with the window. (With a text box
-- open, B is the box's: Page.Typing.)
function Page.Back()
    if state.inside then
        leave()
        redraw()
        return true
    end
    return false
end

-- A tab change or a close of the window: the box closes, a typed name is kept, and the page is at
-- its list the next time it opens.
function Page.Leave()
    closeBox()
    doneTyping(typing and Draw.TypedText())
    state.hold, state.armed, state.inside = nil, nil, nil
end

function Page.Words()
    local line = lines[state.line]
    if not state.box and (typing or state.inside or line.kind == "build" or line.kind == "new") then
        return BuildPage.Words(line, state, isTab(), typing)
    end
    return Model.Words(state, lines, comes(), isTab())
end

local handlers = {
    -- hover on a line gives it the focus when the mouse moved there; a click gives it at once
    Focus = function(index, clicked)
        if not index or index == state.line or state.box or typing or not (clicked or ns.Adapter.MouseMoved()) then
            return
        end
        if state.inside then
            state.line, state.note = index, nil
            redraw("U_CHAT_SCROLL_BUTTON")
        elseif Model.Move(state, lines, index - state.line) then
            redraw("U_CHAT_SCROLL_BUTTON")
        end
    end,
    Press = function(what) ns.SettingsInput.Press(what) end,
    Release = function(what) ns.SettingsInput.Release(what) end,
    Click = function(what) ns.SettingsInput.Click(what) end,
    -- The text in the box changed. The text to copy stays what it is. A pasted text that is a
    -- profile goes in the list; the box closes and the focus goes to the new profile.
    BoxChanged = function()
        local now = Draw.BoxText()
        if state.box == "export" then
            if now ~= exported then
                Draw.SetBox(exported)
            end
        -- (the key that opened the box can land in it as a space or a line break: that is no text)
        elseif state.box == "import" and now:find("%S") then
            local place, why = Store.Add(now)
            if place then
                closeBox()
                Model.Show(state, #Store.List(), place, lines.rows)
            else
                state.note = why
            end
            redraw()
        end
    end,
    BoxClosed = function()
        if closeBox() then
            redraw()
        end
    end,
    -- the name box: Enter or a lost focus keeps the name, Escape leaves it as it was
    NameDone = function(text) doneTyping(text) end,
    NameCancel = function() doneTyping(nil) end,
}

function Page.Build(win)
    return Draw.Build(win, handlers)
end
