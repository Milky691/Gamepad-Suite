-- The settings window's logic, with no game calls, so it can be tested outside the game.
-- State: which chapter (a tab), which row, the row each tab was left on, and a stack of sub-pages opened from a row.
local _, ns = ...

local Model = {}

function Model.New(chapters)
    assert(type(chapters) == "table" and #chapters > 0, "Model.New needs chapters")
    -- the window opens on the first tab that is not the search tab: Search is first in the strip, Setup is where a
    -- new player starts
    local first = chapters[1].search and chapters[2] and 2 or 1
    return { chapters = chapters, chapter = first, row = 1, stack = {}, rows = {} }
end

-- The page in view: the top sub-page if one is open, else the chapter.
function Model.Page(state)
    local top = state.stack[#state.stack]
    return top and top.page or state.chapters[state.chapter]
end

function Model.Rows(state)
    return Model.Page(state).rows or {}
end

function Model.Row(state)
    return Model.Rows(state)[state.row]
end

local function wrap(index, count)
    return (index - 1) % count + 1
end

-- LB / RB. Goes through the tabs in their order, round at the ends. Leaves any sub-page. Each
-- tab keeps the row the player was on. A guided page keeps its place: returns false. The way back
-- to the search results (Model.Go) is forgotten.
function Model.MoveChapter(state, step)
    if Model.Page(state).guide then
        return false
    end
    state.found = nil
    local first = state.stack[1]
    state.rows[state.chapter] = first and first.fromRow or state.row
    state.stack = {}
    state.chapter = wrap(state.chapter + step, #state.chapters)
    state.row = state.rows[state.chapter] or 1
    return true
end

-- D-pad up / down. A move past the first or the last row goes round to the other end. The page
-- in view stays: only A, B, LB and RB go to another page.
function Model.MoveRow(state, step)
    local count = #Model.Rows(state)
    if count == 0 then
        return false
    end
    state.row = wrap(state.row + step, count)
    return true
end

local function nextOption(options, value, step)
    local at = 1
    for i, option in ipairs(options) do
        if option == value then
            at = i
        end
    end
    return options[wrap(at + step, #options)]
end

-- D-pad left / right on a toggle, a row with choices, or a number. get and set are given by the window.
function Model.Change(state, step, get, set)
    local row = Model.Row(state)
    if row and row.kind == "pick" then
        set(row.key, nextOption(row.options, get(row.key), step))
        return true
    elseif row and row.kind == "toggle" then
        -- left or right flips it, the same as A
        set(row.key, not get(row.key))
        return true
    elseif row and row.kind == "slide" then
        -- a number: one step each press, held at its ends
        local value = math.max(row.min, math.min(row.max, get(row.key) + step * row.step))
        set(row.key, value)
        return true
    end
    return false
end

-- A. Returns what happened: "toggled", "changed", "opened", "ran", "hold", "next", "finished" or nil.
-- On a guided page A goes to the next row; on the last row the page closes, and the window reloads the interface.
function Model.Activate(state, get, set)
    local row = Model.Row(state)
    if not row then
        return nil
    end
    if Model.Page(state).guide then
        if state.row < #Model.Rows(state) then
            state.row = state.row + 1
            return "next"
        end
        Model.Back(state)
        return "finished"
    end
    if row.kind == "toggle" then
        set(row.key, not get(row.key))
        return "toggled"
    elseif row.kind == "pick" then
        set(row.key, nextOption(row.options, get(row.key), 1))
        return "changed"
    elseif row.kind == "open" and row.sub then
        state.stack[#state.stack + 1] = { page = row.sub, fromRow = state.row }
        state.row = 1
        return "opened"
    elseif row.kind == "run" then
        return "ran"
    elseif row.kind == "hold" then
        return "hold"
    elseif row.kind == "back" then
        -- the last row of a sub-page: A on it does what B does
        Model.Back(state)
        return "back"
    end
    return nil
end

-- A on a search result (Settings/Search.lua): the window goes to the result's row, in its tab, with
-- the pages on the way open as if the player had walked there (so the titles and the Back rows
-- work). entry: { tab = its number, path = { { page =, at = the row that opened it } }, at = its row }.
-- B on the page it lands on goes back to the results (Model.Back), until LB or RB goes to another tab.
function Model.Go(state, entry)
    local home = { chapter = state.chapter, row = state.row }
    state.chapter, state.row, state.stack = entry.tab, entry.at, {}
    for i, step in ipairs(entry.path) do
        state.stack[i] = { page = step.page, fromRow = step.at }
    end
    home.page = Model.Page(state)
    state.found = home
end

-- True on the page a search result went to: B goes back to the results from there.
function Model.Returns(state)
    return state.found ~= nil and Model.Page(state) == state.found.page
end

-- B. Returns "back" when a sub-page closed (or the window went back to the search results),
-- "close" when the window should close.
function Model.Back(state)
    if Model.Returns(state) then
        local home = state.found
        state.chapter, state.row, state.stack, state.found = home.chapter, home.row, {}, nil
        return "back"
    end
    local top = table.remove(state.stack)
    if top then
        state.row = top.fromRow
        return "back"
    end
    return "close"
end

-- The words the legend shows beside A for the focused row. Give the state to get the words of a guided page.
-- The last row of a guided page says that A reloads the interface (Settings/Window.lua), so the reload is no surprise.
function Model.ActionWord(row, value, state)
    if not row then
        return nil
    end
    if state and Model.Page(state).guide then
        return state.row < #Model.Rows(state) and "Next" or "Finish and reload"
    elseif row.kind == "toggle" then
        return value and "Turn off" or "Turn on"
    elseif row.kind == "pick" then
        return "Next option"
    elseif row.kind == "open" then
        return row.sub and (row.action or "Open") or nil
    elseif row.kind == "run" then
        return row.action or "Run"
    elseif row.kind == "hold" then
        -- the row names its own action: "Hold to reset", "Hold to forget"
        return row.action or "Hold"
    elseif row.kind == "back" then
        return "Back"
    end
    return nil
end

-- The arrow at the right edge of a row that goes to another page: "next" on a row that opens a
-- page, "back" on the Back row, its way on a row that goes by its own run (a search result, Next,
-- Previous). nil on every other row: it changes a value or runs an action, and the player must
-- read the two kinds apart at a glance.
function Model.Nav(row)
    if row.way then
        return row.way
    elseif row.kind == "open" and row.sub then
        return "next"
    end
    return row.kind == "back" and "back" or nil
end

-- Where the names of the tabs sit. The window shows them in rows of perRow names, in columns, so
-- a name of the second row stands under one of the first. widths: the width of each name, in the
-- tabs' order. Gives the middle of each column, counted from the left end of the first one, and
-- the width of all the columns with the gaps between them.
function Model.TabColumns(widths, perRow, gap)
    local middles, x = {}, 0
    for column = 1, perRow do
        local wide = 0
        for i = column, #widths, perRow do
            wide = math.max(wide, widths[i])
        end
        middles[column] = x + wide / 2
        x = x + wide + gap
    end
    return middles, x - gap
end

-- The rows this game build shows. A row goes when it has no feature behind it (no built = true),
-- when the module it names is off (on(name) says if a module runs), when the page it opens is not
-- built, and when the page it opens has lost every row but Back. A choice goes when the module it names is off (row.optionModule): it is taken
-- out of the row's own list, which the registry reads too, so a saved choice that is gone reads
-- as the start value. A tab that lost every row this way stays, and its line says why it is empty.
-- Facts given as a function are read here, once, from the game (the Health Check row's game build).
Model.NO_ROWS = "This game build does not have what these settings need. See Setup, Health Check."
function Model.Prune(chapters, on)
    local function prune(rows)
        local lost = 0
        for i = #rows, 1, -1 do
            local row = rows[i]
            if type(row.facts) == "function" then
                row.facts = row.facts()
            end
            for at = #(row.options or {}), 1, -1 do
                local needs = row.optionModule and row.optionModule[row.options[at]]
                if needs and not on(needs) then
                    table.remove(row.options, at)
                end
            end
            local off = row.module and not on(row.module)
            local under = row.sub and row.sub.rows
            local hollow = under and prune(under) > 0 and (under[1] == nil or under[1].kind == "back")
            if off or hollow or not row.built or (row.kind == "open" and not row.sub) then
                table.remove(rows, i)
                lost = lost + ((off or hollow) and 1 or 0)
            end
        end
        return lost
    end
    for _, chapter in ipairs(chapters) do
        if prune(chapter.rows) > 0 and #chapter.rows == 0 then
            chapter.line = Model.NO_ROWS
        end
    end
end

-- The text of a value as the row shows it. A row with an arrow has none: the arrow has its place.
-- A hold row has none either: its legend word says what A does. An info row shows its first fact,
-- so it does not read as a setting with no value.
function Model.ValueText(row, value)
    -- (a row of a feature in development: grey, its value says so, and it cannot change)
    if row.soon then
        return "In development"
    elseif row.kind == "hold" or Model.Nav(row) then
        return ""
    elseif row.kind == "info" then
        local first = type(row.facts) == "table" and row.facts[1]
        return first and first[2] or ""
    elseif row.kind == "toggle" then
        return value and "On" or "Off"
    elseif row.kind == "pick" then
        return tostring(value)
    elseif row.kind == "slide" then
        return tostring(value) .. (row.unit or "")
    end
    -- (a row can work out its value: Undo Last Bind shows if there is a step to take back)
    return type(row.value) == "function" and row.value() or row.value or ""
end

if ns then
    ns.SettingsModel = Model
end
return Model
