-- The settings window: drawing its state, what each button does, open and close.
-- The frames are built in Frames.lua and drawn by Draw.lua.
local _, ns = ...

local Theme, Widgets, Model, Registry = ns.Theme, ns.Widgets, ns.SettingsModel, ns.Registry
local px = Theme.px

local Settings = ns.Module("Settings", { "backdrop" }, "Settings Window")
ns.Settings = Settings

local Draw = ns.SettingsDraw
local ui = Draw.ui
local win, state, scaleRow

local function getValue(key)
    return Registry.Get(key)
end

-- Every row of every chapter, and of every sub-page under a row. A row on two pages is visited once.
local function eachRow(fn)
    local seen = {}
    local function walk(rows)
        for _, row in ipairs(rows) do
            if not seen[row] then
                seen[row] = true
                fn(row)
                if row.sub then
                    walk(row.sub.rows)
                end
            end
        end
    end
    for _, chapter in ipairs(ns.SettingsData) do
        walk(chapter.rows)
    end
end

-- A row that opens a page we have not built yet is not shown: a door with no room behind it. Nor
-- is a row that names a module which is off on this game build (Mouse Mode with no pointer).
local function pruneRows()
    Model.Prune(ns.SettingsData, function(name)
        return ns.modules[name] ~= nil and ns.modules[name].on
    end)
end

-- Every row that holds a saved value.
local function eachSetting(fn)
    eachRow(function(row)
        if row.kind == "toggle" or row.kind == "pick" or row.kind == "slide" then
            fn(row)
        end
    end)
end

local function setValue(key, value)
    Registry.Set(key, value)
end

-- Every setting is defined when this file loads, not at login: other modules read settings in
-- their own login step, and that step can run before this module's.
eachSetting(function(row)
    if row.kind == "toggle" then
        Registry.Define(row.key, "toggle", row.default)
    elseif row.kind == "pick" then
        Registry.Define(row.key, "pick", row.default, row.options)
    else
        Registry.Define(row.key, "number", row.default, { min = row.min, max = row.max })
    end
    if row.get then Registry.Virtual(row.key, row.get, row.set) end   -- a row that stands for another value
    if row.key == "window.scale" then
        scaleRow = row
    end
end)

-- ---------------------------------------------------------------- what the buttons do

-- The page that takes the whole body (the binds page, Profiles, My Wheels, Slot Binds), or nil.
-- Such a page has its own Move, Press, Clear, Back, Leave, ListOpen, ChangeList, Words and Draw.
local function special()
    return (Draw.Special())
end

-- A tab change or a close of the window: a carry ends, the list of binds closes, a typed search is searched.
local function leaveSpecial()
    for _, page in ipairs({ ns.SettingsBinds, ns.SettingsWheels, ns.SettingsProfiles, ns.SettingsSlots, ns.SettingsSearch }) do page.Leave() end
end

function Settings.Chapter(step)
    local page = special()
    if page and page.ListOpen() then
        -- LB and RB belong to the list while it is open
        page.ChangeList(step)
        return
    end
    if Model.MoveChapter(state, step) then
        leaveSpecial()
        ns.Adapter.Sound("IG_CHARACTER_INFO_TAB")
        Draw.All(true)
    end
end

-- The focus went to another row of the same page.
local function focusMoved()
    ns.Adapter.Sound("U_CHAT_SCROLL_BUTTON")
    Draw.Rows(false)
    Draw.Page()
    Draw.Legend()
end

function Settings.Move(step)
    local page = special()
    if page then
        page.Move(step, 0)
    elseif Model.MoveRow(state, step) then
        focusMoved()
    end
end

-- The game's own click for a change of value: a tick box sound for on and off, the option sound for the rest.
local function changeSound(row)
    if row.kind == "toggle" then
        ns.Adapter.Sound(Registry.Get(row.key) and "IG_MAINMENU_OPTION_CHECKBOX_ON" or "IG_MAINMENU_OPTION_CHECKBOX_OFF")
    else
        ns.Adapter.Sound("IG_MAINMENU_OPTION")
    end
end

local rumbleWarned

-- A row with sample = "rumble" rumbles once at its new strength.
local function sample(row)
    local value = Registry.Get(row.key)
    if row.sample ~= "rumble" or value == "Off" then
        return
    end
    if not ns.Rumble.Pulse(0.25) and not rumbleWarned then
        rumbleWarned = true
        ns.Print("This game build cannot rumble.")
    end
end

function Settings.Side(step)
    local page = special()
    if page then
        page.Move(0, step)
    elseif Model.Change(state, step, getValue, setValue) then
        local row = Model.Row(state)
        changeSound(row)
        Draw.Values()
        sample(row)
        if row.key == "system.controller" then
            Draw.Page()
        end
    end
end

function Settings.Layer(which)
    local page = special()
    if page and page.Layer then
        page.Layer(which)
    end
end

-- A went down. Returns true if this row wants a hold, so the input code starts the hold timer.
function Settings.Press()
    local page = special()
    if page then
        -- the Back line of My Wheels and of Profiles; a profile wants a hold
        local what = page.Press()
        if what == "back" then
            Settings.Back()
        end
        return what == "hold"
    end
    local row = Model.Row(state)
    local what = Model.Activate(state, getValue, setValue)
    if what == "hold" then
        return true
    elseif what == "opened" or what == "back" then
        ns.Adapter.Sound("IG_MAINMENU_OPTION")
        Draw.All(true)
    elseif what == "next" then
        focusMoved()
    elseif what == "finished" then
        Draw.All(true)
        -- the end of the guided setup reloads the interface (the legend says so), so the game
        -- writes the new settings to disk now. Only at this press, and never in a fight.
        ns.Adapter.Reload()
    elseif what == "ran" then
        -- (a row that went to another page by its run, a search result or Next, says so: it drew the window itself)
        if not (row.run and row.run(row)) and win:IsShown() then
            Draw.Values()
        end
    elseif what then
        changeSound(row)
        Draw.Values()
        sample(row)
        if row.key == "system.controller" then
            Draw.Page()
        end
    end
    return false
end

-- The bar of a hold grows along the row in focus, or along the line a special page names.
function Settings.HoldProgress(fraction)
    local page = special()
    local frame = page and page.HoldRow and page.HoldRow() or ui.rows[state.row]
    if not frame then
        return
    end
    frame.hold:SetShown(fraction > 0)
    frame.hold:SetWidth(math.max(1, frame:GetWidth() * math.min(fraction, 1)))
end

function Settings.HoldDone()
    local page, row = special(), Model.Row(state)
    if page and page.Held then
        return page.Held()
    elseif row and row.held then
        -- what the row does when its hold is full (Settings/Data.lua)
        row.held(row)
    end
    Draw.All(false)
end

-- The mouse is over a row: that row gets the focus.
function Settings.FocusRow(index)
    if ns.Adapter.MouseMoved() and not special() and state.row ~= index and Model.Rows(state)[index] then
        state.row = index
        focusMoved()
    end
end

-- The mouse clicked a tab's name. It does nothing while the list of binds is open.
function Settings.GoChapter(index)
    local page = special()
    if index ~= state.chapter and not (page and page.ListOpen()) then
        Settings.Chapter(index - state.chapter)
    end
end

-- True while the page in view has a text box open (the name of a wheel, the search line). Every button belongs to
-- the game's own keyboard then, and the window does nothing with it. `what` is the button that
-- came; the page ends the typing on B. With no button given, this only says if a box is open.
function Settings.Typing(what)
    local page = state and win and (special() or Model.Page(state).search and ns.SettingsSearch) or nil
    return page ~= nil and page.Typing ~= nil and page.Typing(what)
end

-- X. It acts on the binds page and on My Wheels only.
function Settings.Clear()
    local page = special()
    if page then
        page.Clear()
    end
end

function Settings.Back()
    local page = special()
    if page and page.Back() then
        return
    end
    if Model.Back(state) == "close" then
        Settings.Close()
    else
        Draw.All(true)
    end
end

-- ---------------------------------------------------------------- open and close

function Settings.Open(chapterId, rowKey)
    if not Settings.on then
        ns.Print("The settings window is off on this game build.")
        return
    end
    if ns.Adapter.InCombat() then
        ns.Print("The settings window opens out of combat.")
        return
    end
    if not win then
        pruneRows()
        win = ns.SettingsFrames.Build(ui, function()
            Draw.StopDemo()
            leaveSpecial()
            ns.Adapter.HideFocusArrow(false)
            ns.Adapter.Sound("IG_MAINMENU_CLOSE")
            ns.Send("settings:closed")
        end)
        ns.SettingsInput.Attach(win)
        Draw.Bind(win, state)
    end
    if chapterId then
        for i, chapter in ipairs(state.chapters) do
            if chapter.id == chapterId then
                state.chapter, state.row, state.stack = i, 1, {}
                for r, row in ipairs(chapter.rows) do
                    if row.key == rowKey then
                        state.row = r
                    end
                end
            end
        end
    end
    Settings.Place()
    ui.dim:Show()
    Draw.FadeIn(ui.dim, 0.32)
    ns.Adapter.Sound("IG_MAINMENU_OPEN")
    win:Show()
    -- the game's focus arrow stays on the game menu under the window (Core/AdapterWindow.lua)
    ns.Adapter.HideFocusArrow(true)
    ns.Send("settings:opened")
    Draw.FadeIn(win, 0.24)
    win.open:Stop()
    win.open:Play()
    Draw.All(true)
end

-- The limits of the window's scale on this screen, in percent. It may grow until it touches the
-- screen, and shrink until its smallest text (15 units) is 12 pixels high.
local function scaleLimits()
    local fit = math.min(UIParent:GetWidth() / win:GetWidth(), UIParent:GetHeight() / win:GetHeight())
    -- (a game that does not tell the screen's height: one unit is taken as one pixel)
    local smallest = px(15) * (ns.Adapter.ScreenHeight() or UIParent:GetHeight()) / UIParent:GetHeight()
    local low = math.ceil(12 / smallest * 20 - 0.001) * 5
    local high = math.floor(fit * 20 + 0.001) * 5
    return math.max(70, math.min(100, low)), math.max(100, math.min(130, high))
end

-- The player's scale and place for this window (Setup, Settings Window).
function Settings.Place()
    local low, high = scaleLimits()
    scaleRow.min, scaleRow.max = low, high
    local scale = math.max(low, math.min(high, Registry.Get("window.scale"))) / 100
    win:SetScale(scale)
    win:ClearAllPoints()
    -- offsets are in the window's own scaled units, so divide to move by screen units
    win:SetPoint("CENTER", UIParent, "CENTER", Registry.Get("window.x") / scale, Registry.Get("window.y") / scale)
end

function Settings.Close()
    if win then
        win:Hide()
    end
end

function Settings.Toggle()
    if win and win:IsShown() then
        Settings.Close()
    else
        Settings.Open()
    end
end

function Settings.IsOpen()
    return win ~= nil and win:IsShown()
end

function Settings.State()
    return state
end

function Settings.OnLogin()
    ns.Listen("setting", "Settings", function(key)
        if win and (key == "window.scale" or key == "window.x" or key == "window.y") then
            Settings.Place()
        end
    end)
    state = Model.New(ns.SettingsData)

    ns.On("PLAYER_REGEN_DISABLED", "Settings", Settings.Close)
    -- the button above the game menu
    ns.Listen("settings:open", "Settings", function()
        Settings.Open()
    end)
    ns.Adapter.OnIconSetChanged(function()
        Widgets.RefreshGlyphs()
        if Settings.IsOpen() then
            Draw.All(false)
        end
    end)

    -- "/gs" is the short one. Another addon can have it too; then the last one loaded has it,
    -- and the two long ones still open this window; "/gamepadsuite build <name>" is a build's bind (Core/Builds.lua).
    SLASH_GAMEPADSUITE1, SLASH_GAMEPADSUITE2, SLASH_GAMEPADSUITE3 = "/gs", "/gpad", "/gamepadsuite"
    SlashCmdList.GAMEPADSUITE = function(text)
        return ns.Builds and ns.Builds.on and ns.Builds.Slash(text) or Settings.Toggle()
    end
    ns.SettingsInput.WatchSticks()
end

-- for the game's key bindings window
BINDING_HEADER_GAMEPADSUITE = "Gamepad Suite"
BINDING_NAME_GAMEPADSUITE_TOGGLE = "Open or close Gamepad Suite"
function GamepadSuite_Toggle()
    Settings.Toggle()
end
