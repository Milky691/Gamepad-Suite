-- The tabs and rows of the settings window: names, summaries, the text of each page.
-- The fourteen tabs are in the order of LB and RB; the window shows them in two rows, seven and seven. A tab
-- has six rows at most, the window has no more room (tests/data_test.lua).
-- kind: toggle, pick, slide (a number), open (a sub-page), run (an action), hold (hold A to confirm),
-- back (the last row of a sub-page) or info (text only). A row with built = true has its feature
-- behind it; the window does not show the others (Settings/Model.lua, Prune).
-- A row on two pages (a tab and the guided setup) is one table, used in both.
-- module: the module that does the row's work, by the name it gave ns.Module. The window shows the
-- row only while that module runs on this game build (Settings/Model.lua, Prune). optionModule
-- does the same for one choice of a row.
local _, ns = ...

local controllerType = {
    key = "system.controller", name = "Controller Type", kind = "pick", default = "Auto", built = true,
    options = { "Auto", "Steam Deck", "Xbox style", "PlayStation style", "Nintendo style" },
    sum = "The controller shown in the pictures.",
    text = "Auto uses the controller the game reports. Change this if the picture does not match your controller. The Steam Deck picture includes the four back buttons and both trackpads.",
    steps = {
        { keys = { "DL", "DR" }, text = "Left and right change the picture" },
    },
    facts = { { "Default", "Auto" } },
}

local buttonIcons = {
    key = "screen.button_symbols", module = "ButtonIcons", name = "Button Icons", kind = "pick", default = "Auto", built = true,
    options = { "Auto", "Xbox style", "PlayStation style", "Nintendo style" },
    sum = "The icons shown for each button.",
    text = "Auto uses the icons that match your controller. These are the game's own button icons.",
    steps = {
        { keys = { "A", "B", "X", "Y" }, text = "These icons change" },
    },
    facts = { { "Default", "Auto" } },
}

-- A step of the guided setup, Button Look: the buttons in two groups, or Bars. It stands for the row Button Look, which also has
-- Square and Round: Groups keeps a look of groups the player has and gives Plate (that row's start value) for Bars.
local buttonLayout = {
    key = "setup.button_layout", name = "Button Look", kind = "pick", default = "Groups", built = true,
    options = { "Groups", "Bars" },
    get = function()
        return ns.Registry.Get("screen.look") == "Bars" and "Bars" or "Groups"
    end,
    set = function(value)
        if value == "Bars" then
            ns.Registry.Set("screen.look", "Bars")
        elseif ns.Registry.Get("screen.look") == "Bars" then
            ns.Registry.Set("screen.look", "Plate")
        end
    end,
    sum = "Buttons in two groups, or one bar for each layer.",
    text = "Groups: the D-pad on the left and the face buttons on the right, as on your controller. Bars: one bar for each layer, a gold ring on the bar in use. Groups keeps Square, Plate or Round. To choose one, see On-Screen Buttons, Button Look.",
    steps = {
        { keys = { "DL", "DR" }, text = "Left and right change the look" },
        { keys = {}, text = "The buttons show above this window" },
    },
    facts = { { "Default", "Groups" } },
}

local windowScale = {
    key = "window.scale", name = "Window Scale", kind = "slide", default = 100, min = 70, max = 130, step = 5, unit = "%", built = true,
    sum = "Size of this window, in percent.",
    text = "Changes the size of this window. The window resizes as you change the value.",
    steps = {
        { keys = { "DL", "DR" }, text = "Left: smaller. Right: larger." },
    },
    facts = { { "Default", "100%" } },
}

-- The last row of every sub-page. A on it goes back, as B does: for the mouse, and as a second way.
local back = {
    name = "Back", kind = "back", built = true,
    sum = "Goes back to the page before.",
    text = "Goes back to the page you came from. B does the same.",
    steps = {
        { keys = { "A" }, text = "Go back" },
    },
    facts = {},
}

-- A row of the page Back Buttons: the keys a back button answers to (its own and the one Steam Input usually
-- sends for it). A waits for a press of that back button and keeps the key it sends (Core/AdapterGrips.lua).
local function grip(ours, steam)
    return {
        key = "controller.grip_" .. ours, name = ours, kind = "run", built = true,
        value = function() return ns.Adapter.GripText(ours) end,
        sum = "The keys " .. ours .. " answers to.",
        text = ours .. " works as the controller's back button and as " .. steam .. ", the key Steam Input usually sends for it. If yours sends another key, press A, then press " .. ours .. ". Any other button stops the wait. A bind of yours on " .. steam .. " in the game's key bindings keeps " .. steam .. ".",
        steps = {
            { keys = { "A" }, text = "Wait for a press" },
            { keys = { ours }, text = "Press the back button" },
        },
        facts = { { "Default", "Back button or " .. steam } },
        run = function()
            ns.Adapter.LearnGrip(ours, function() ns.SettingsDraw.Values() end)
        end,
    }
end

local rumble = {
    key = "feel.rumble", name = "Rumble", kind = "pick", default = "Medium", sample = "rumble", built = true,
    options = { "Off", "Light", "Medium", "Strong" },
    sum = "Rumble strength for game events.",
    text = "The controller rumbles on events such as low health or a proc. Each event has its own pattern. When you change this value, the controller rumbles once at the new strength. The page Rumble Events turns the other events on and off.",
    steps = {
        { keys = {}, text = "Low health: one long pulse" },
        { keys = {}, text = "Proc ready: two short pulses" },
    },
    facts = { { "Default", "Medium" } },
}

-- the Back row, for a page that another file makes (the health page)
ns.SettingsBack = back

ns.SettingsData = {
    {
        id = "Search", line = "Find a setting by its name or its text.", search = true,
        -- the rows under the search line are the results (Settings/Search.lua)
        rows = {
            {
                name = "Search", kind = "run", action = "Type", built = true,
                value = function() return ns.SettingsSearch.Text() end,
                sum = "Type a name to find a setting.",
                text = "Type a word or two. Every row whose name, line or text has it shows under this one, best first. A name with a letter or two wrong is found too. A on a result goes to it. B there comes back here.",
                steps = {
                    { keys = { "A" }, text = "Type a name" },
                    { keys = { "DU", "DD" }, text = "Choose a result" },
                    { keys = { "A" }, text = "Go to it. B comes back." },
                },
                facts = { { "Letters", "2 to 30" } },
                run = function() ns.SettingsSearch.Type() end,
            },
        },
    },
    {
        id = "Setup", line = "Guided setup, controller type and this window.",
        rows = {
            {
                key = "system.guided_setup", name = "Guided Setup", kind = "open", action = "Start", built = true,
                sum = "Set controller type, icons, button look, window scale and rumble.",
                text = "The steps: controller type, button icons, button look, window scale, rumble, and how to open this window. Press A for the next step. On the last step, A finishes and reloads the interface to save your settings. B leaves at any step.",
                steps = {
                    { keys = { "A" }, text = "A: next step" },
                    { keys = { "DL", "DR" }, text = "Left and right: change a value" },
                    { keys = { "B" }, text = "B: leave" },
                },
                sub = {
                    guide = true, title = "Guided Setup",
                    rows = {
                        controllerType,
                        buttonIcons,
                        buttonLayout,
                        windowScale,
                        rumble,
                        {
                            key = "system.open_info", name = "Open This Window", kind = "info", built = true,
                            sum = "How to open this window.",
                            text = "Hold both stick clicks for one second to open or close this window. You can also type /gs or /gpad in chat. The window does not open in combat. Press A to finish. The interface reloads and your settings are saved. If not, type /reload.",
                            steps = {
                                { keys = { "LS", "RS" }, text = "Hold both stick clicks for one second" },
                                { keys = {}, text = "Or type /gs or /gpad in chat" },
                                { keys = { "A" }, text = "A: finish and reload" },
                            },
                            facts = { { "Chat commands", "/gs or /gpad" } },
                        },
                    },
                },
            },
            controllerType,
            buttonIcons,
            {
                key = "screen.this_window", name = "Settings Window", kind = "open", built = true,
                sum = "Scale and position of this window.",
                text = "Three values: scale in percent, X position and Y position. Left and right on the D-pad change a value. The window changes as you press.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                    { keys = { "DL", "DR" }, text = "Left and right change a value" },
                },
                facts = { { "Default", "100%, center" } },
                sub = {
                    title = "Settings Window",
                    line = "Scale and position of this window.",
                    rows = {
                        windowScale,
                        {
                            key = "window.x", name = "Window X Position", kind = "slide", default = 0, min = -400, max = 400, step = 10, built = true,
                            sum = "Moves this window left or right.",
                            text = "Left moves the window left. Right moves it right. The window cannot leave the screen.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Left and right move the window" },
                            },
                            facts = { { "Default", "0 (center)" } },
                        },
                        {
                            key = "window.y", name = "Window Y Position", kind = "slide", default = 0, min = -250, max = 250, step = 10, built = true,
                            sum = "Moves this window up or down.",
                            text = "Right moves the window up. Left moves it down. The window cannot leave the screen.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Right: up. Left: down." },
                            },
                            facts = { { "Default", "0 (center)" } },
                        },
                        back,
                    },
                },
            },
            {
                key = "system.health_check", name = "Health Check", kind = "open", built = true,
                sum = "Saves a report of what this game build has.",
                text = "Opens a page that writes a report to the addon's saved file: the controller the game sees, the hidden controller settings, and which of the addon's checks passed. Use it when something does not work.",
                steps = {
                    { keys = { "A" }, text = "Open the report" },
                },
                -- read from the game when the window first opens (Settings/Model.lua, Prune)
                facts = function()
                    local version, build = ns.Adapter.Build()
                    return { { "Game build", version .. "." .. build } }
                end,
            },
            {
                key = "system.reset", name = "Reset and Undo", kind = "open", built = true,
                sum = "Reset the settings or the binds. Undo the last bind.",
                text = "Opens a page with three things: put every setting back to its default, take every bind of this character away, and take back the last change of a bind.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = {},
                sub = {
                    title = "Reset and Undo",
                    line = "Reset the settings or the binds. Undo the last bind.",
                    rows = {
                        {
                            key = "system.start_over", name = "Reset All Settings", kind = "hold", action = "Hold to reset", built = true,
                            sum = "Resets every setting to the defaults.",
                            text = "Puts every setting in this window back to its default value. A pause of automation ends too. Your binds stay.",
                            steps = {
                                { keys = { "A" }, text = "Hold A until the bar is full" },
                            },
                            facts = {},
                            held = function()
                                ns.Registry.Each(function(key, default)
                                    ns.Registry.Set(key, default)
                                end)
                                -- every wheel's own place (Screen/WheelPlace.lua)
                                if ns.WheelPlace then
                                    ns.WheelPlace.Reset()
                                end
                                -- the pause of automation is a saved value of its own, not a setting (Auto/Automation.lua)
                                local resumed = ns.Automation and ns.Automation.Resume and ns.Automation.Resume()
                                ns.Print("All settings are reset to the defaults." .. (resumed and " Automation resumed." or ""))
                            end,
                        },
                        {
                            key = "system.reset_binds", name = "Reset Binds", kind = "hold", action = "Hold to reset", built = true,
                            sum = "Takes every bind of this character away.",
                            text = "Every bind of this character goes, in every set and layer. The buttons then do what the game gives them. Undo Last Bind brings your binds back.",
                            steps = {
                                { keys = { "A" }, text = "Hold A until the bar is full" },
                            },
                            facts = {},
                            held = function()
                                ns.Binds.Reset()
                                ns.Print("Your binds are reset. Setup, Reset and Undo, Undo Last Bind brings them back.")
                            end,
                        },
                        {
                            key = "system.undo_bind", name = "Undo Last Bind", kind = "run", action = "Undo", built = true,
                            value = function() return ns.Binds.CanUndo() and "1 step" or "Nothing" end,
                            sum = "Takes back the last change of a bind.",
                            text = "Takes back the last thing you did on the Binds page: a bind you put on a button, moved, swapped or cleared. It also takes back Reset Binds. One step.",
                            steps = {
                                { keys = { "A" }, text = "Undo" },
                            },
                            facts = {},
                            run = function()
                                ns.Print(ns.Binds.Undo() and "The last change of your binds is taken back." or "There is nothing to take back.")
                            end,
                        },
                        back,
                    },
                },
            },
        },
    },
    {
        id = "Binds", line = "", binds = true,
        -- the page is drawn by Settings/Binds.lua in place of rows
        rows = {
        },
    },
    {
        id = "Layers", line = "More binds on the same buttons, and binds that follow new ranks.",
        rows = {
            {
                key = "layers.trigger_layers", name = "Trigger Layers", kind = "info", built = true,
                sum = "Hold LT or RT to give every button another bind.",
                text = "Each trigger gives every button one more bind. Hold LT and press A for a second bind. Hold RT and press A for a third. Hold both for a fourth. These three layers are always on.",
                steps = {
                    { keys = { "LT", "A" }, text = "Hold LT, press A" },
                    { keys = { "RT", "A" }, text = "Hold RT, press A" },
                    { keys = { "LT", "RT", "A" }, text = "Hold both, press A" },
                },
                facts = { { "Always on", "LT, RT and LT + RT" } },
            },
            {
                key = "layers.sticky_layers", built = true, name = "Sticky Layers", kind = "toggle", default = false,
                sum = "Tap a trigger instead of holding it.",
                text = "Tap LT or RT and its layer stays on until you tap it again. Tap both for LT + RT. The on-screen buttons show it. A held trigger works as before. A game command such as Jump on a trigger layer leaves the layer on after the hold.",
                steps = {
                    { keys = { "LT" }, text = "Tap LT or RT and let it go" },
                    { keys = { "A" }, text = "Press any buttons. They use that layer" },
                    { keys = { "LT" }, text = "Tap the same trigger again. The layer turns off" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                key = "layers.hold_lb_rb_set", built = true, name = "LB + RB Layer", kind = "toggle", default = false,
                sum = "Hold LB, then press RB, for another layer.",
                text = "Hold LB, then press RB. The D-pad, the face buttons and both stick clicks change to another layer until you let go. LB and RB keep their own binds: LB does its bind when you press it. Put binds on the LB + RB page of the Binds tab.",
                steps = {
                    { keys = { "LB", "RB" }, text = "Hold LB, then press RB" },
                    { keys = { "DU", "DL", "DR", "DD", "A", "B", "X", "Y", "LS", "RS" }, text = "These buttons change" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                key = "layers.combat_set", built = true, name = "Combat Binds", kind = "pick", default = "Off", options = { "Off", "In combat", "Hostile target" },
                sum = "A second bind for a button, used in combat.",
                text = "A button can have a bind for combat, in the Combat set of the Binds page. In a form, Form and Stance Binds says which bind wins. A button with no combat bind keeps its other bind. Hostile target also counts any target you can attack.",
                steps = {
                    { keys = { "DU", "DL", "DR", "DD", "A", "B", "X", "Y" }, text = "Out of combat: your normal binds" },
                    { keys = { "DU", "DL", "DR", "DD", "A", "B", "X", "Y" }, text = "In combat: your combat binds" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                key = "layers.forms_and_stances", built = true, name = "Form and Stance Binds", kind = "pick", default = "Form First", options = { "Off", "Form First", "Combat First" },
                sum = "Each form or stance has its own binds.",
                text = "When you change form or stance, the buttons change to that form's binds, on every layer. Stealth and Prowl have their own binds too. Form First: in combat, the form's bind wins over the Combat bind. Combat First: the Combat bind wins.",
                steps = {
                    { keys = { "A", "B", "X", "Y" }, text = "Caster form binds" },
                    { keys = { "A", "B", "X", "Y" }, text = "After a form change: that form's binds" },
                },
                facts = { { "Default", "Form First" }, { "Warriors", "Combat First" } },
            },
            {
                key = "binds.follow_ranks", module = "RankUp", built = true, name = "Follow New Ranks", kind = "toggle", default = true,
                sum = "Binds move up when you learn a new rank.",
                text = "When you learn a new rank of a spell, a bind on a button, in a fixed slot or on My Wheels with the rank just below it moves up to it. A lower rank you chose stays. Saved profiles do not change. In combat it waits until combat ends.",
                steps = {
                    { keys = { "A" }, text = "Before: Frostbolt (Rank 3)" },
                    { keys = { "A" }, text = "After you learn Rank 4: Frostbolt (Rank 4)" },
                    { keys = { "B" }, text = "A Rank 2 you chose stays Rank 2" },
                },
                facts = { { "Default", "On" } },
            },
        },
    },
    {
        id = "Wheels", line = "Your wheels and their look. Push the right stick at an entry and let go to use it.",
        rows = {
            {
                key = "wheels.mine", module = "Wheels", name = "My Wheels", kind = "open", built = true,
                sum = "Make wheels of your own.",
                text = "Make a wheel of your own. It has 8 slots, and each slot is a direction. Put a spell, an item, a macro, an emote, a game window or a target command on the slots you want. In the game only those slots show. You can name the wheel.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = {},
                -- the page is drawn by Settings/WheelsPage.lua in place of rows
                sub = { title = "My Wheels", line = "Make wheels of your own.", wheels = true, rows = {} },
            },
            {
                key = "wheels.position", module = "Wheels", name = "Wheel Settings", kind = "open", built = true,
                sum = "The size and place of each wheel.",
                text = "Change all wheels at once, or give one wheel a size and a place of its own, such as a large Healer Wheel at the right. A test wheel shows while you change a value.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = { { "Default", "100%, center" } },
                -- Wheel to Change, its size and its two positions: Screen/WheelPlace.lua (the choices are the player's
                -- own wheels, filled in at login; the three rows stand for the size and place of the wheel chosen, and
                -- the positions reach the edges of the player's screen)
                sub = {
                    title = "Wheel Settings",
                    line = "The size and place of each wheel.",
                    rows = {
                        {
                            key = "wheels.move", name = "Wheel to Change", kind = "pick", default = "All Wheels", built = true,
                            options = { "All Wheels", "Consumables Wheel", "Quest Item Wheel", "Raid Marker Wheel", "Quick Chat Wheel", "Roll Wheel", "Healer Wheel" },
                            sum = "The wheel that the rows below change.",
                            text = "Choose a wheel here. Wheel Size, Wheel X Position and Wheel Y Position then change that wheel. All Wheels changes every wheel that has no size or place of its own. The wheel shows while you change a value.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Left and right choose the wheel" },
                            },
                            facts = { { "Default", "All Wheels" } },
                        },
                        {
                            key = "wheels.size", name = "Wheel Size", kind = "slide", default = 100, min = 60, max = 240, step = 10, unit = "%", built = true,
                            sum = "The size of the wheel, in percent.",
                            text = "Changes the size of the wheel named in Wheel to Change, and of the pictures on it. All Wheels changes every wheel that has no size of its own.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Left: smaller. Right: larger." },
                            },
                            facts = { { "Default", "100%" } },
                        },
                        {
                            key = "wheels.x", name = "Wheel X Position", kind = "slide", default = 0, min = -4000, max = 4000, step = 10, built = true,
                            sum = "Moves the wheel left or right.",
                            text = "Moves the wheel named in Wheel to Change left or right. 0 is the middle of the screen. It goes as far as the edge of your screen.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Left and right move the wheel" },
                            },
                            facts = { { "Default", "0 (center)" } },
                        },
                        {
                            key = "wheels.y", name = "Wheel Y Position", kind = "slide", default = 0, min = -2000, max = 2000, step = 10, built = true,
                            sum = "Moves the wheel up or down.",
                            text = "Moves the wheel named in Wheel to Change up or down. 0 is the middle of the screen. It goes as far as the edge of your screen.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Right: up. Left: down." },
                            },
                            facts = { { "Default", "0 (center)" } },
                        },
                        back,
                    },
                },
            },
            {
                key = "wheels.background", module = "Wheels", name = "Wheel Background", kind = "pick", default = "None", options = { "None", "Dark" }, built = true,
                sum = "A dark disc behind every wheel.",
                text = "None shows only the pictures and their names. Dark puts a dark disc behind the pictures of a wheel, so they stand out from the game.",
                steps = {
                    { keys = { "DL", "DR" }, text = "Left and right change the background" },
                },
                facts = { { "Default", "None" } },
            },
        },
    },
    {
        id = "Fixed Slots", line = "Extra slots that stay on the screen.",
        rows = {
            {
                key = "slots.actions", name = "Fixed Slot Binds", kind = "open", built = true,
                sum = "Choose the bind of each slot.",
                text = "Opens the list of the eight slots. Choose a bind for a slot, or clear it. A slot with no bind does not show on the screen. A tap or a click on a slot works, with no button needed.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = {},
                -- the page is drawn by Settings/SlotsPage.lua in place of rows
                sub = { title = "Fixed Slot Binds", line = "Choose the bind of each slot.", slots = true, rows = {} },
            },
            {
                key = "slots.move", name = "Slot to Move", kind = "pick", default = "Slot 1", built = true,
                options = { "Slot 1", "Slot 2", "Slot 3", "Slot 4", "Slot 5", "Slot 6", "Slot 7", "Slot 8" },
                sum = "The slot that the two position rows move.",
                text = "Choose a slot here. Slot X Position and Slot Y Position then move that slot. The slot shows on the screen with a gold rim while you change a value.",
                steps = {
                    { keys = { "DL", "DR" }, text = "Left and right choose the slot" },
                },
                facts = { { "Default", "Slot 1" } },
            },
            {
                key = "slots.size", name = "Slot Size", kind = "slide", default = 100, min = 60, max = 140, step = 10, unit = "%", built = true,
                sum = "Size of every fixed slot, in percent.",
                text = "Changes the size of every fixed slot and of the button pictures above it.",
                steps = {
                    { keys = { "DL", "DR" }, text = "Left: smaller. Right: larger." },
                },
                facts = { { "Default", "100%" } },
            },
            {
                key = "slots.x", name = "Slot X Position", kind = "slide", default = 0, min = -4000, max = 4000, step = 10, built = true,
                sum = "Moves the slot left or right.",
                text = "Moves the slot named in Slot to Move left or right. 0 is the middle of the screen. It goes as far as the edge of your screen. The slot shows on the screen while you change the value.",
                steps = {
                    { keys = { "DL", "DR" }, text = "Left and right move the slot" },
                },
                facts = { { "Default", "Different for each slot" } },
            },
            {
                key = "slots.y", name = "Slot Y Position", kind = "slide", default = 0, min = -2000, max = 2000, step = 10, built = true,
                sum = "Moves the slot up or down.",
                text = "Moves the slot named in Slot to Move up or down. 0 is the middle of the screen. It goes as far as the edge of your screen. The slot shows on the screen while you change the value.",
                steps = {
                    { keys = { "DL", "DR" }, text = "Right: up. Left: down." },
                },
                facts = { { "Default", "Different for each slot" } },
            },
        },
    },
    {
        id = "Profiles", line = "", profiles = true,
        -- the page is drawn by Settings/ProfilesPage.lua in place of rows
        rows = {
        },
    },
    {
        id = "Combat", line = "Targeting and casting.",
        rows = {
            {
                key = "combat.targeting", name = "Targeting", kind = "pick", default = "Cycle", options = { "Stick", "Cycle" }, built = true,
                sum = "How LB and RB select a target.",
                text = "Stick: hold RB and the enemies light up. Push the right stick to pick one. Hold LB for a friend. LB and RB keep their binds: a press does the bind. Cycle: RB and LB, if empty, get binds for the next enemy and friend.",
                steps = {
                    { keys = { "RB", "RS" }, text = "Stick: hold RB, push toward an enemy" },
                    { keys = { "LB", "RS" }, text = "Stick: hold LB, push toward a friend" },
                    { keys = {}, text = "Other buttons: the Stick Target binds, in the list Targeting" },
                },
                facts = { { "Default", "Cycle" } },
            },
            {
                key = "combat.dynamic_interact", built = true, name = "Dynamic Interact", kind = "pick", default = "X", options = { "Off", "RB", "LB", "X" },
                sum = "One button interacts when something is near.",
                text = "Choose a button. It keeps its bind from the Binds page. When something you can interact with is in reach, such as a vendor, a corpse or a herb, it interacts. Its Combat bind wins in combat. In a group, Healer Mode at Bumpers on it wins.",
                steps = {
                    { keys = { "RB", "LB", "X" }, text = "Choose one of these buttons" },
                    { keys = {}, text = "Nothing near: it does its bind" },
                    { keys = {}, text = "Something highlighted: it interacts" },
                },
                facts = { { "Default", "X" } },
            },
            {
                key = "combat.friend_menu", module = "FriendMenu", built = true, name = "Friendly Player Menu", kind = "toggle", default = false,
                sum = "Dynamic Interact opens a friendly player's menu.",
                text = "With a friendly player as your target, out of combat, the Dynamic Interact button opens their menu (Inspect, Trade, Invite, Whisper) when its bind has nothing for that player. A heal or a buff on it casts. Something in reach comes first.",
                steps = {
                    { keys = {}, text = "Target a friendly player" },
                    { keys = {}, text = "Dynamic Interact: that player's menu" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                -- (in development: the owner, 2026-10-16, "toggle it off/grey it out and put a in development on it for now")
                key = "combat.press_and_hold", built = true, name = "Press and Hold Casting", kind = "pick", default = "Off",
                -- In use again in 0.26.3: build 1.60.1.70425 made the game's Press and Hold Casting work with a
                -- gamepad. The game repeats a cast only for a press through its own bars (SecureTemplates.xml 6 to 8),
                -- so All spell binds puts each spell bind into an empty slot of its hidden bars (Core/HoldSlots.lua).
                options = { "Off", "All spell binds" }, optionModule = { ["All spell binds"] = "HoldSlots" },
                sum = "Hold a button to cast its spell again and again.",
                text = "All spell binds: hold a spell bind of yours and the game casts it again and again. It uses empty slots of the game's hidden bars; nothing of yours moves. Off leaves the game's own setting as you set it.",
                steps = {
                    { keys = { "A" }, text = "Hold: the spell casts again when it is ready" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                key = "combat.campfire_sit", module = "Campfire", built = true, name = "Sit at a Campfire", kind = "toggle", default = true,
                sum = "The Dynamic Interact button sits you down at a campfire.",
                text = "Near a campfire, with nothing else in reach, the Dynamic Interact button makes you sit. A line on screen names the button. It needs Dynamic Interact on a button, and it acts out of combat only.",
                steps = {
                    { keys = {}, text = "Stand near a campfire" },
                    { keys = {}, text = "Press the Dynamic Interact button" },
                },
                facts = { { "Default", "On" } },
            },
            {
                key = "combat.healer_mode", module = "Wheels", built = true, name = "Healer Mode", kind = "pick", default = "Wheel",
                options = { "Off", "Bumpers", "Wheel" },
                sum = "How you pick a member of your group.",
                text = "Wheel: a heal opens a party wheel. Bumpers, in a group: hold LB (RB if the game swaps them, with Targeting at Cycle); the D-pad targets party 1 to 4 or steps through a raid, A is you, X your pet, B your target's target. A tap is LB's bind.",
                steps = {
                    { keys = { "LB", "DU" }, text = "Bumpers: hold LB, then the D-pad" },
                    { keys = { "LB", "A" }, text = "Bumpers: hold LB, then A for yourself" },
                    { keys = {}, text = "Wheel: a heal opens the party wheel" },
                },
                facts = { { "Default", "Wheel" } },
            },
        },
    },
    {
        id = "Buttons", title = "On-Screen Buttons", line = "The on-screen buttons: place, size and look.",
        rows = {
            {
                key = "screen.look", built = true, name = "Button Look", kind = "pick", default = "Plate", options = { "Square", "Plate", "Round", "Bars" },
                sum = "The look of the on-screen buttons.",
                text = "Square: square pictures with a gold line. Plate: soft corners on a dark plate. Round: round pictures with a mark in the middle. Bars: one bar for each layer, with a gold ring on the bar in use. Fixed slots and the cooldown list match.",
                steps = {
                    { keys = { "DL", "DR" }, text = "Left and right change the look" },
                    { keys = {}, text = "The buttons show above this window" },
                },
                facts = { { "Default", "Plate" } },
            },
            {
                key = "screen.other_layers", built = true, name = "Other Layers", kind = "toggle", default = true,
                sum = "Small pictures of your LT and RT binds.",
                text = "Each main on-screen button gets three small pictures above it: its bind on LT, on LT + RT and on RT. You see what a held trigger gives before you hold it. The picture of the layer in use has a gold line. Not in Bars: it shows every layer.",
                steps = {
                    { keys = { "LT" }, text = "Left: the LT bind" },
                    { keys = { "LT", "RT" }, text = "Middle: the LT + RT bind" },
                    { keys = { "RT" }, text = "Right: the RT bind" },
                },
                facts = { { "Default", "On" } },
            },
            {
                key = "screen.position", name = "Size and Position", kind = "open", built = true,
                sum = "Size and place of the on-screen buttons.",
                text = "Four values: the size of the on-screen buttons, how far the two groups stand apart, and their X and Y position. Left and right on the D-pad change a value. The buttons show above this window while you change one.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                    { keys = { "DL", "DR" }, text = "Left and right change a value" },
                },
                facts = { { "Default", "100%, 0, 0" } },
                sub = {
                    title = "Size and Position",
                    line = "Size and place of the on-screen buttons.",
                    rows = {
                        {
                            key = "screen.size", name = "Button Size", kind = "slide", default = 100, min = 60, max = 140, step = 10, unit = "%", built = true,
                            sum = "Size of the on-screen buttons, in percent.",
                            text = "Makes the on-screen buttons smaller or larger. The fixed slots have a size of their own.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Left: smaller. Right: larger." },
                            },
                            facts = { { "Default", "100%" } },
                        },
                        {
                            key = "screen.spread", name = "Group Spread", kind = "slide", default = 0, min = -150, max = 400, step = 10, built = true,
                            sum = "Moves the two groups apart.",
                            text = "Moves the left group and the right group of on-screen buttons apart, or closer together. The middle of the screen stays free.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Left: closer. Right: farther apart." },
                            },
                            facts = { { "Default", "0" } },
                        },
                        {
                            key = "screen.x", name = "Buttons X Position", kind = "slide", default = 0, min = -500, max = 500, step = 10, built = true,
                            sum = "Moves the on-screen buttons left or right.",
                            text = "Moves both groups of on-screen buttons left or right. 0 is the middle of the screen.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Left and right move the buttons" },
                            },
                            facts = { { "Default", "0" } },
                        },
                        {
                            key = "screen.y", name = "Buttons Y Position", kind = "slide", default = 0, min = -60, max = 500, step = 10, built = true,
                            sum = "Moves the on-screen buttons up or down.",
                            text = "Moves the on-screen buttons up or down. 0 is their first place, near the bottom of the screen.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Right: up. Left: down." },
                            },
                            facts = { { "Default", "0" } },
                        },
                        back,
                    },
                },
            },
            {
                key = "screen.form_ring", name = "Form Ring", kind = "toggle", default = true, built = true,
                sum = "The form or stance you are in, and the buttons it changed.",
                text = "In a form, a stance or stealth, its picture and name show between the buttons, and each button with a bind of its own there has a thin rim in the form's color. So you see your stance and which buttons changed.",
                steps = {
                    { keys = {}, text = "Between the buttons: your form or stance" },
                    { keys = { "A", "B", "X", "Y" }, text = "Change form: the rim shows" },
                },
                facts = { { "Default", "On" } },
            },
            {
                key = "screen.alerts_page", module = "ButtonCues", built = true, name = "Button Alerts", kind = "open",
                sum = "Glows, gray and a flash on the buttons in combat.",
                text = "Four switches for what the on-screen buttons show in combat: a gold glow when the game lights a spell, a red glow on your interrupt while the enemy casts, a gray picture while an action cools down, and a flash when it is ready.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = { { "Default", "All on" } },
                sub = {
                    title = "Button Alerts",
                    line = "What the on-screen buttons show in combat.",
                    rows = {
                        {
                            key = "screen.proc_glow", module = "ButtonCues", built = true, name = "Proc Glow", kind = "toggle", default = true,
                            sum = "A button glows when the game lights its spell.",
                            text = "When the game lights a spell, as it lights Overpower after a dodge, each button with that spell glows gold inside its edge and gets a gold rim. Any rank of the spell counts. The small pictures of the other layers glow too.",
                            steps = {
                                { keys = {}, text = "A lit spell: a gold glow" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "screen.interrupt_glow", module = "ButtonCues", built = true, name = "Interrupt Glow", kind = "toggle", default = true,
                            sum = "Your interrupt glows while the enemy casts.",
                            text = "While an enemy target casts a spell that can be stopped, each button with an interrupt glows red: Kick, Pummel, Shield Bash, Counterspell, Earth Shock and the like. A cast that cannot be stopped gives no glow.",
                            steps = {
                                { keys = {}, text = "The enemy casts: a red glow" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "screen.gray_cooling", module = "ButtonCues", built = true, name = "Gray While Cooling", kind = "toggle", default = true,
                            sum = "A button turns gray while it cools down.",
                            text = "A button turns gray while its action cools down, and gets its color back when it is ready. The short cooldown after every cast does not count.",
                            steps = {
                                { keys = {}, text = "On cooldown: gray" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "screen.flash_ready", module = "ButtonCues", built = true, name = "Flash When Ready", kind = "toggle", default = true,
                            sum = "A button flashes once when it is ready.",
                            text = "When the cooldown of an action ends, its button gives one quick flash. The short cooldown after every cast gives no flash. Rumble When Ready, on the page Rumble Events of the Controller tab, gives a rumble.",
                            steps = {
                                { keys = {}, text = "The cooldown ends: one flash" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        back,
                    },
                },
            },
            {
                key = "screen.fade_page", built = true, name = "Fade and Hide", kind = "open",
                sum = "When the on-screen buttons dim or go away.",
                text = "Fade When Idle dims the on-screen buttons. Hide While Mounted and Hide While Resting take them off the screen on a mount or in a city. Hide Empty Bars folds an empty bar in the Bars look. Your binds always work.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = { { "Default", "All off" } },
                sub = {
                    title = "Fade and Hide",
                    line = "When the on-screen buttons dim or go away.",
                    rows = {
                        {
                            key = "screen.fade_when_idle", built = true, name = "Fade When Idle", kind = "pick", default = "Off", options = { "Off", "Dim to 40%", "Dim to 20%" },
                            sum = "The on-screen buttons dim when you are idle.",
                            text = "Out of combat, when you press nothing for four seconds, the on-screen buttons dim. Any button press brings them back.",
                            steps = {
                                { keys = {}, text = "Idle four seconds: dim" },
                                { keys = { "A" }, text = "Any press: full brightness" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "screen.hide_mounted", module = "HideButtons", built = true, name = "Hide While Mounted", kind = "toggle", default = false,
                            sum = "The buttons hide on a mount, in a travel form or on a flight path.",
                            text = "On a mount, in a travel form or on a flight path the on-screen buttons, the fixed slots and the cooldown list go out of sight. Your binds still work. The buttons come back in combat, when you target an enemy, and while a wheel is open.",
                            steps = {
                                { keys = {}, text = "Mount up or take a travel form: the buttons hide" },
                                { keys = {}, text = "Combat or an enemy target: they come back" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "screen.hide_resting", module = "HideButtons", built = true, name = "Hide While Resting", kind = "toggle", default = false,
                            sum = "The buttons hide in an inn or a city.",
                            text = "In an inn or a city, where the game shows that you are resting, the on-screen buttons go out of sight. Your binds still work. The buttons come back in combat, when you target an enemy, and while a wheel is open.",
                            steps = {
                                { keys = {}, text = "In a city: the buttons hide" },
                                { keys = {}, text = "Combat or an enemy target: they come back" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "screen.hide_empty_bars", built = true, name = "Hide Empty Bars", kind = "toggle", default = false,
                            sum = "A bar with nothing on it folds away.",
                            text = "For the Bars look. A bar where no button has a bind or a game action folds away, and the bars under it move up. The No trigger bar always shows. While you carry a spell or an item to drop on a button, every bar shows.",
                            steps = {
                                { keys = {}, text = "An empty bar folds away" },
                                { keys = {}, text = "Carry a spell: every bar shows" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        back,
                    },
                },
            },
        },
    },
    {
        id = "Cooldowns", line = "Cooldown numbers, a swing clock and a list of the binds that are cooling down.",
        rows = {
            {
                key = "screen.cooldown_numbers", built = true, name = "Cooldown Numbers", kind = "pick", default = "Large", options = { "Off", "Small", "Large" },
                sum = "Size of the cooldown number on each button, fixed slot and list line.",
                text = "Sets the size of the cooldown number on each on-screen button, each fixed slot and each line of the cooldown list.",
                steps = {
                    { keys = { "A", "B", "X", "Y" }, text = "The numbers show on the buttons" },
                },
                facts = { { "Default", "Large" } },
            },
            {
                key = "cooldowns.next_melee", built = true, name = "Next Melee Timer", kind = "pick", default = "Off", options = { "Off", "Queued", "Always" },
                sum = "A swing clock on Heroic Strike, Cleave and Maul.",
                text = "Heroic Strike, Cleave and Maul land on your next swing. Queued: a clock shows the time to that swing while one of them waits for it. Always: the clock shows after every swing, so you can time your press.",
                steps = {
                    { keys = {}, text = "Queued: press Heroic Strike or Maul" },
                    { keys = {}, text = "Always: each swing starts the clock" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                key = "cooldowns.list", module = "CooldownList", name = "Cooldown List", kind = "toggle", default = false, built = true,
                sum = "Lists every bind that is cooling down.",
                text = "Shows every bind of yours that is cooling down, on any layer. Each line has the bind, its time and its buttons. The one that ends soonest is on top.",
                steps = {
                    { keys = {}, text = "A bind in a fixed slot is not in the list" },
                    { keys = {}, text = "The list has five lines at most" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                key = "cooldowns.size", module = "CooldownList", name = "List Size", kind = "slide", default = 100, min = 60, max = 160, step = 5, unit = "%", built = true,
                sum = "Size of the cooldown list, in percent.",
                text = "Changes the size of the cooldown list. The list shows above this window while you change the value.",
                steps = {
                    { keys = { "DL", "DR" }, text = "Left: smaller. Right: larger." },
                },
                facts = { { "Default", "100%" } },
            },
            {
                key = "cooldowns.x", module = "CooldownList", name = "List X Position", kind = "slide", default = -330, min = -780, max = 690, step = 10, built = true,
                sum = "Moves the list left or right.",
                text = "Moves the cooldown list left or right. 0 is the middle of the screen.",
                steps = {
                    { keys = { "DL", "DR" }, text = "Left and right move the list" },
                },
                facts = { { "Default", "-330" } },
            },
            {
                key = "cooldowns.y", module = "CooldownList", name = "List Y Position", kind = "slide", default = 90, min = -270, max = 430, step = 10, built = true,
                sum = "Moves the list up or down.",
                text = "Moves the top of the cooldown list up or down. 0 is the middle of the screen.",
                steps = {
                    { keys = { "DL", "DR" }, text = "Right: up. Left: down." },
                },
                facts = { { "Default", "90" } },
            },
        },
    },
    {
        id = "Screen", line = "Target, range, info bar, pop-ups, error text and camera.",
        rows = {
            {
                key = "screen.target_tooltip", built = true, name = "Target Tooltip", kind = "pick", default = "Always", options = { "Off", "5 seconds", "10 seconds", "Always" },
                sum = "Shows the tooltip of your target.",
                text = "When you take a target, the game shows its tooltip for a few seconds. When that one fades, this one takes its place, at the same spot and size. It stays for 5 or 10 seconds more, or for as long as you have the target.",
                steps = {
                    { keys = {}, text = "Take a target" },
                },
                facts = { { "Default", "Always" } },
            },
            {
                key = "screen.brackets_page", built = true, name = "Target Marks", kind = "open",
                sum = "Brackets around your target, its range, and object names.",
                text = "Opens a page with five rows: Show Brackets and Bracket Size for two brackets that hang from the nameplate of your target, Range Finder for its distance, Range Tick for a rumble, and Object Names.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = { { "Default", "Object Names on, the rest off" } },
                sub = {
                    title = "Target Marks",
                    line = "Brackets around your target, its range, a rumble when it comes into reach, and object names.",
                    rows = {
                        {
                            key = "screen.target_brackets", module = "Brackets", built = true, name = "Show Brackets", kind = "toggle", default = false,
                            sum = "Two brackets around your target.",
                            text = "Two brackets hang from the nameplate of your target. They are yellow, and red while you attack it. The target needs a nameplate, so the game's nameplates must be on.",
                            steps = {
                                { keys = {}, text = "Take a target" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "screen.bracket_size", module = "Brackets", built = true, name = "Bracket Size", kind = "slide", default = 100, min = 60, max = 140, step = 10, unit = "%",
                            sum = "Size of the target brackets, in percent.",
                            text = "Changes the size of the two brackets around your target.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Left: smaller. Right: larger." },
                            },
                            facts = { { "Default", "100%" } },
                        },
                        {
                            key = "screen.range_finder", module = "Range", built = true, name = "Range Finder", kind = "toggle", default = false,
                            sum = "Shows the range to your target.",
                            text = "A text above an enemy target's nameplate shows its distance as a band of yards, like 5-30 yd. It turns red past your longest reach. Range Tick, on this page, rumbles as the target comes into reach.",
                            steps = {
                                { keys = {}, text = "Take a hostile target" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "feel.range_tick", module = "Range", built = true, name = "Range Tick", kind = "toggle", default = false,
                            sum = "A short rumble when your target comes into reach.",
                            text = "The controller gives a short pulse when your hostile target comes into reach of your longest attack. Going out of reach gives none. It uses the strength of Rumble and stops when Rumble is Off. It works with Range Finder off.",
                            steps = {
                                { keys = {}, text = "Target comes into reach: one short pulse" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "screen.object_names", module = "ObjectNames", built = true, name = "Object Names", kind = "toggle", default = true,
                            sum = "The name of an object you can use shows above it.",
                            text = "When a chest, a herb, a mailbox or another object is in reach, its name shows above it on the game's own name plate. People get no extra name. It does not change during combat.",
                            steps = {
                                { keys = {}, text = "An object in reach: its name shows" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        back,
                    },
                },
            },
            {
                key = "screen.info_bar", built = true, name = "Info Bar", kind = "toggle", default = true,
                sum = "A thin strip at the top of the screen.",
                text = "Shows your money, free bag slots, gear wear, zone and place on the map, experience toward the next level (blue while rested), latency and frames per second at the top of the screen. A small Hearthstone shows while yours is ready.",
                steps = {
                    { keys = {}, text = "Look at the top edge of the screen" },
                },
                facts = { { "Default", "On" } },
            },
            {
                key = "windows.popups_page", built = true, name = "Pop-ups", kind = "open",
                sum = "Notes on the screen or in chat for things you could miss.",
                text = "Opens a page of notes near the top of the screen: Whisper Pop-up, Rare Nearby, Share Quests, Pet Hungry for a hunter, and Low Battery Warning. After a poison, oil or stone from a bind, the same place offers your weapons.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = { { "Default", "On, Low Battery Warning off" } },
                sub = {
                    title = "Pop-ups",
                    line = "Notes on the screen or in chat for things you could miss while you play.",
                    rows = {
                        {
                            key = "windows.whisper_popup", module = "WhisperPopup", built = true, name = "Whisper Pop-up", kind = "toggle", default = true,
                            sum = "Shows a whisper near the top of the screen. Hold Y to reply, X to invite.",
                            text = "A whisper shows near the top of the screen for 8 seconds with what the game knows of the sender: level, race, class, zone. Hold Y 1 second and let go to reply, or X to invite. In combat, act after it ends.",
                            steps = {
                                { keys = { "Y" }, text = "Hold 1 second, then let go to reply" },
                                { keys = { "X" }, text = "Hold 1 second, then let go to invite" },
                            },
                            facts = { { "Default", "On" }, { "Invite", "When you lead or are not in a group" } },
                        },
                        {
                            key = "windows.rare_nearby", module = "RareNearby", built = true, name = "Rare Nearby", kind = "toggle", default = true,
                            sum = "A rumble and a note when a rare is close.",
                            text = "When a rare or rare elite is near, the controller rumbles once and its name and level show near the top of the screen, once for each rare. It finds rares by the enemy name plates, the enemy you face and your target.",
                            steps = {
                                { keys = {}, text = "Turn on the game's enemy name plates to see rares from afar" },
                                { keys = {}, text = "Face or target a rare" },
                            },
                            facts = { { "Default", "On" }, { "Not for", "A dead rare, or one another player tagged" }, { "Quiet", "In combat, on a flight path, or as a ghost" } },
                        },
                        {
                            key = "windows.share_quests", module = "ShareQuest", built = true, name = "Share Quests", kind = "toggle", default = true,
                            sum = "In a party, hold Y to share a quest you just took.",
                            text = "When you take a quest in a party and a member does not have it, a note shows near the top of the screen for 10 seconds. Hold Y 1 second and let go to share it. Not in a raid, and not for a quest a member shared.",
                            steps = {
                                { keys = { "Y" }, text = "Hold 1 second, then let go to share" },
                            },
                            facts = { { "Default", "On" }, { "Once", "Each quest" } },
                        },
                        {
                            key = "windows.pet_hungry", module = "PetHungry", built = true, name = "Pet Hungry", kind = "toggle", default = true,
                            sum = "A note when your pet is hungry and your bags hold its food.",
                            text = "When your pet turns content or unhappy and your bags hold food it eats, a note shows near the top of the screen. Press Feed Pet, or hold Y, let go and press Y. With no such food, one chat line names what it eats.",
                            steps = {
                                { keys = {}, text = "Press your Feed Pet bind" },
                                { keys = { "Y" }, text = "Or hold, let go, then press once more" },
                            },
                            facts = { { "Default", "On" }, { "For", "A hunter" } },
                        },
                        {
                            key = "feel.battery_note", module = "Battery", name = "Low Battery Warning", kind = "toggle", default = false, built = true,
                            sum = "A chat message when the controller battery is low.",
                            text = "Shows one chat message when the controller battery runs low. It shows once in a session. In combat it waits until combat ends. A controller on a cable gives no message. A controller that reports no battery level gives none.",
                            steps = {
                                { keys = {}, text = "One chat message, out of combat" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        back,
                    },
                },
            },
            {
                key = "screen.hide_error_spam", module = "ErrorSpam", built = true, name = "Hide Error Text", kind = "toggle", default = true,
                sum = "Hides red lines such as Not enough rage.",
                text = "Hides the red lines for not enough rage, energy or mana, not ready, out of range, another action in progress and no target. A full inventory still shows. The buttons show the first three, not the last two.",
                steps = {
                    { keys = {}, text = "Press a button that is not ready" },
                    { keys = {}, text = "No red line shows" },
                },
                facts = { { "Default", "On" } },
            },
            {
                key = "screen.camera", name = "Camera", kind = "open", built = true,
                sum = "Zoom the camera by itself, or with the stick.",
                text = "Opens a page with five settings. Four zoom the camera by itself: in combat and at an NPC, on a mount, on flight paths and indoors. With Stick Zoom the right stick zooms it.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = {},
                sub = {
                    title = "Camera",
                    line = "Zoom the camera by itself, or with the stick.",
                    rows = {
                        {
                            key = "feel.camera", module = "AutoZoom", built = true, name = "Auto Camera Zoom", kind = "pick", default = "Full", options = { "Off", "Low", "Full" },
                            sum = "Zooms out in combat. Zooms in at an NPC.",
                            text = "A controller has no scroll wheel, so the camera zooms for you: out when combat starts, in when you talk to an NPC. Low moves it 3 yards, Full 6. Off stops every automatic zoom on this page. The right stick always overrides it.",
                            steps = {
                                { keys = { "RS" }, text = "The right stick overrides it" },
                            },
                            facts = { { "Default", "Full" } },
                        },
                        {
                            key = "feel.camera_mount", module = "AutoZoom", built = true, name = "Zoom Out on a Mount", kind = "toggle", default = true,
                            sum = "Zooms out on a mount or in a travel form.",
                            text = "On a mount, in travel, aquatic or flight form, or as a Ghost Wolf, the camera zooms out as far as in combat. It comes back when you get off or shift out. Auto Camera Zoom sets how far. The right stick always overrides it.",
                            steps = {
                                { keys = { "RS" }, text = "The right stick overrides it" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "feel.camera_flight", module = "AutoZoom", built = true, name = "Zoom Out on Flight Paths", kind = "toggle", default = true,
                            sum = "Zooms out while you fly on a flight path.",
                            text = "On a flight path the camera zooms out twice as far as in combat, for a wide view. It comes back when you land. If combat starts as you land, it stays out as in combat. Auto Camera Zoom sets how far.",
                            steps = {
                                { keys = { "RS" }, text = "The right stick overrides it" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "feel.camera_indoors", module = "AutoZoom", built = true, name = "Zoom In Indoors", kind = "toggle", default = true,
                            sum = "Zooms in inside buildings and caves.",
                            text = "Inside a building or a cave the camera zooms in as far as at an NPC, so it bumps into fewer walls. It zooms out again when you go outside. Combat still zooms it out. Auto Camera Zoom sets how far.",
                            steps = {
                                { keys = { "RS" }, text = "The right stick overrides it" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "feel.stick_zoom", module = "Zoom", name = "Stick Zoom", kind = "toggle", default = true, built = true,
                            sum = "LB + RB and the right stick zoom the camera.",
                            text = "Hold LB and RB and push the right stick up or down to zoom in or out. LB and RB keep their own binds. A game command such as Jump on LB stops it. It works with LB + RB Layer on. The bind Stick Zoom, in the list Camera, works on any button.",
                            steps = {
                                { keys = { "LB", "RB" }, text = "Hold LB and RB" },
                                { keys = { "RS" }, text = "Up: zoom in. Down: zoom out." },
                                { keys = {}, text = "Let go of one: the camera turns again" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        back,
                    },
                },
            },
        },
    },
    {
        id = "Windows", line = "Dialogue, flight, upgrade arrows, quest rewards, bags, the bank, mail and the chat keyboard.",
        rows = {
            {
                key = "windows.dialogue_page", module = "Dialogue", built = true, name = "Dialogue View", kind = "open",
                sum = "Talk with NPCs in a band at the foot of the screen.",
                text = "Opens a page with five rows: the view on or off, its size, the interface during a talk, text that moves on by itself, and the Merchant View for vendors.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = { { "Default", "On" } },
                sub = {
                    title = "Dialogue View",
                    line = "Talks with NPCs and quests, in a band at the foot of the screen.",
                    rows = {
                        {
                            key = "windows.dialogue", module = "Dialogue", built = true, name = "Use Dialogue View", kind = "toggle", default = true,
                            sum = "A view of NPC talk and quests, made for the controller.",
                            text = "A talk with an NPC or a quest shows in a dark band at the foot of the screen, with the NPC's portrait and large text. With Off, in combat, with no controller, or while Immersion is on, the game's own windows show.",
                            steps = {
                                { keys = { "A" }, text = "Choose, accept or complete at once" },
                                { keys = { "X" }, text = "Next part, or back to the first" },
                                { keys = { "B" }, text = "Close" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "windows.dialogue_size", module = "Dialogue", built = true, name = "Dialogue Size", kind = "slide", default = 100, min = 80, max = 140, step = 5, unit = "%",
                            sum = "Size of the dialogue view, in percent.",
                            text = "Changes the size of the band, the portrait and every text of the dialogue view. On a narrow screen the view is never wider than the screen.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Left: smaller. Right: larger." },
                            },
                            facts = { { "Default", "100%" } },
                        },
                        {
                            key = "windows.dialogue_hide", module = "Dialogue", built = true, name = "Hide Interface In Talks", kind = "toggle", default = true,
                            sum = "The game's interface goes out of sight during a talk.",
                            text = "During a talk with an NPC the minimap, the unit frames, the chat and the bars go out of sight, so only the world, the NPC and the dialogue view show. They come back at once in combat and when the game needs you.",
                            steps = {
                                { keys = { "A" }, text = "Turn on or off" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "windows.dialogue_auto", module = "Dialogue", built = true, name = "Text Moves On By Itself", kind = "toggle", default = true,
                            sum = "Each part of an NPC's words moves on after a time.",
                            text = "Each part of an NPC's words shows for a time that fits its length, and a thin gold line shows the time left. Press X, LB, RB or the D-pad to turn the text by hand for the rest of that talk. The last part stays.",
                            steps = {
                                { keys = { "A" }, text = "Turn on or off" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "windows.merchant_view", module = "Merchant", built = true, name = "Merchant View", kind = "toggle", default = true,
                            sum = "Vendors open in a view like the dialogue view.",
                            text = "A vendor opens in this view in place of the game's window: big item cards and the NPC at the side. A buys, hold A buys a stack, X sells junk, Y repairs, hold Y on a Sell card marks it as junk, LB and RB switch Buy, Sell and Buyback.",
                            steps = {
                                { keys = { "A" }, text = "Buy one, hold for a stack" },
                                { keys = { "Y" }, text = "On the Sell tab, hold to mark junk" },
                                { keys = { "LB", "RB" }, text = "Buy, Sell and Buyback" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        back,
                    },
                },
            },
            {
                key = "windows.flight_list", module = "FlightList", built = true, name = "Flight List", kind = "toggle", default = true,
                sum = "A list of places beside the flight map.",
                text = "At a flight master, a list stands beside the map. It has every place you can fly to now, with the cost. The places you flew to last come first. The map marks the place the list is on. Press left to use the map itself.",
                steps = {
                    { keys = { "DU", "DD" }, text = "Move through the list. The map follows" },
                    { keys = { "A" }, text = "Fly there" },
                    { keys = { "DL" }, text = "Go to the map. Right comes back" },
                },
                facts = { { "Default", "On" } },
            },
            {
                key = "helpers.upgrade_arrows", module = "Upgrades", built = true, name = "Gear Upgrade Indicator", kind = "toggle", default = true,
                sum = "A green arrow on gear that is better for your class, a dim one on gear for later.",
                text = "A green arrow marks gear that is better for your class than what you wear there: a rogue gets none for intellect. Gear with no stats goes by item level. A dim arrow with a number is gear that is better once you reach that level.",
                steps = {
                    { keys = {}, text = "Open your bags, or loot" },
                    { keys = {}, text = "Look for the green arrow" },
                    { keys = {}, text = "A dim arrow: better at that level" },
                },
                facts = { { "Default", "On" } },
            },
            {
                key = "windows.wear_rewards", module = "WearReward", built = true, name = "Wear Quest Rewards", kind = "toggle", default = true,
                sum = "After a quest, hold Y to wear a reward that is better.",
                text = "When a quest gives you gear with the green arrow, a card shows above the on-screen buttons for 10 seconds. Hold Y for one second and let go: the piece goes on, and the old one goes to your bags. A tap of Y does what Y does. Not in combat.",
                steps = {
                    { keys = { "Y" }, text = "Hold, then let go: wear it" },
                },
                facts = { { "Default", "On" } },
            },
            {
                key = "windows.bags_page", built = true, name = "Bags, Bank and Mail", kind = "open",
                sum = "Trade goods into the bank, all your mail, room for loot, and care with quest items.",
                text = "Opens a page with five rows: Deposit Trade Goods at the bank, Take All Mail at the mailbox, Destroy Gray Item when loot does not fit, and Quest Item Guard and Mark Junk for the bag window at a vendor.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                sub = {
                    title = "Bags, Bank and Mail",
                    line = "Trade goods into the bank, your mail, room in your bags, and junk at a vendor.",
                    rows = {
                        {
                            key = "windows.bank_deposit", module = "BankDeposit", built = true, name = "Deposit Trade Goods", kind = "toggle", default = true,
                            sum = "Hold X at the bank to put your trade goods in it.",
                            text = "At the bank, hold X for one second and the trade goods in your bags go into the bank. A stack goes onto the same item first, then into an empty place, also in a profession bag that takes it. Things a quest needs stay in your bags.",
                            steps = {
                                { keys = { "X" }, text = "Hold on the bank window" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "windows.mail_take", module = "MailTake", built = true, name = "Take All Mail", kind = "toggle", default = true,
                            sum = "Hold Y at the mailbox to take all your mail.",
                            text = "At the mailbox, hold Y for one second to take the gold and items from your letters. COD letters are never paid and stay. With full bags the gold is still taken. Hold Y again to stop. A chat line then says what sold and who sent what.",
                            steps = {
                                { keys = { "Y" }, text = "Hold on the inbox" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "helpers.destroy_gray", module = "Destroy", built = true, name = "Destroy Gray Item", kind = "toggle", default = false,
                            sum = "Offers to destroy your cheapest gray item when loot does not fit.",
                            text = "When loot does not fit in your bags, a prompt shows your cheapest gray item. Hold the button on the prompt for 1 second, let go, then press it once more. The item is destroyed and the loot is picked up. It does not show in combat.",
                            steps = {
                                { keys = {}, text = "Loot with full bags" },
                                { keys = { "Y" }, text = "Hold 1 second, let go, press once more" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "helpers.quest_guard", module = "QuestGuard", built = true, name = "Quest Item Guard", kind = "toggle", default = true,
                            sum = "Shows which quest needs an item, and stops one wrong sale.",
                            text = "An item a quest needs shows Needed for in its tooltip. At a vendor, the first X on it in your bags does not sell it, and the hint over the bags says so for 3 seconds. Press X again to sell it. A chat message says how to buy it back.",
                            steps = {
                                { keys = {}, text = "Look at an item's tooltip" },
                                { keys = { "X" }, text = "At a vendor, press again to sell an item a quest needs" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "helpers.mark_junk", module = "JunkMark", built = true, name = "Mark Junk", kind = "toggle", default = true,
                            sum = "Press Y at a vendor to mark an item as junk.",
                            text = "At a vendor, Y on an item in your bags marks it as junk, and Y again takes the mark off. In the Merchant View, hold Y on the Sell tab. Marked items have a gold coin and sell with your gray items. Quest items cannot be marked.",
                            steps = {
                                { keys = { "Y" }, text = "At a vendor, mark or unmark the item" },
                                { keys = { "Y" }, text = "In the Merchant View, hold on the Sell tab" },
                                { keys = {}, text = "Auto Sell Junk sells marked items" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        back,
                    },
                },
            },
            {
                key = "windows.keyboard_page", module = "Keyboard", built = true, name = "Chat Keyboard", kind = "open",
                sum = "Word guesses on the chat keyboard.",
                text = "Opens a page with two rows: Word Guess turns the guesses on or off, and Forget Typed Words forgets the words the keyboard learned. On a chat line, hold LB and talk: your words come in as text.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = { { "Default", "On" } },
                sub = {
                    title = "Chat Keyboard",
                    line = "Word guesses while you type a chat line with the controller.",
                    rows = {
                        {
                            key = "keyboard.word_guess", module = "Keyboard", built = true, name = "Word Guess", kind = "toggle", default = true,
                            sum = "Guesses the word or name you are typing on the chat keyboard.",
                            text = "While you type a chat line, up to three guesses show above the keys. Your own words come first: it learns the words of the lines you send. Online names of your group, friends and guild show too. With Off, it guesses and learns nothing.",
                            steps = {
                                { keys = { "RB" }, text = "Put in the first guess" },
                                { keys = { "DU" }, text = "Up from the top row of keys goes to the guesses" },
                            },
                            facts = { { "Default", "On" }, { "Names", "Group, friends and guild, online only" } },
                        },
                        {
                            key = "keyboard.forget_words", module = "Keyboard", built = true, name = "Forget Typed Words", kind = "hold", action = "Hold to forget",
                            sum = "Forgets the words the keyboard learned from your chat lines.",
                            text = "The keyboard keeps up to 400 words from the chat lines you send, so it can guess them. This takes them all away. The built-in words stay. Names are never kept.",
                            steps = {
                                { keys = { "A" }, text = "Hold A until the bar is full" },
                            },
                            facts = {},
                            held = function()
                                ns.Keyboard.ForgetWords()
                                ns.Print("The keyboard forgot the words it learned.")
                            end,
                        },
                        back,
                    },
                },
            },
        },
    },
    {
        id = "Controller", line = "Rumble, the objective sound, roll buttons, back buttons and mouse mode.",
        rows = {
            rumble,
            {
                key = "feel.rumble_events", module = "RumbleEvents", built = true, name = "Rumble Events", kind = "open",
                sum = "The game events that make the controller rumble.",
                text = "Opens a page with five rows: Group Calls, Whispers, Death and Stuns, Level Up and Requests, and Rumble When Ready. When several come at once, only the most urgent one plays. Rumble sets their strength, and Rumble Off stops them.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                sub = {
                    title = "Rumble Events",
                    line = "Each row turns a group of game events on or off.",
                    rows = {
                        {
                            key = "feel.rumble_group", module = "RumbleEvents", built = true, name = "Group Calls", kind = "toggle", default = true,
                            sum = "A rumble for a ready check, an invite, a summon or a resurrection.",
                            text = "The controller gives two short pulses when a ready check starts, and when you get a group invite, a summon or an offer to resurrect you. A ready check that you start gives none.",
                            steps = {
                                { keys = {}, text = "Two short pulses" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "feel.rumble_whispers", module = "RumbleEvents", built = true, name = "Whispers", kind = "toggle", default = true,
                            sum = "A rumble when someone whispers to you.",
                            text = "The controller gives three quick taps when a player whispers to you. A whisper to yourself gives none.",
                            steps = {
                                { keys = {}, text = "Three quick taps" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "feel.rumble_danger", module = "RumbleEvents", built = true, name = "Death and Stuns", kind = "toggle", default = true,
                            sum = "A rumble when you die or lose control of your character.",
                            text = "The controller gives three long pulses when you die, and one firm pulse when you are stunned, feared or lose control in another way.",
                            steps = {
                                { keys = {}, text = "Death: three long pulses" },
                                { keys = {}, text = "Stun or fear: one firm pulse" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "feel.rumble_level", module = "RumbleEvents", built = true, name = "Level Up and Requests", kind = "toggle", default = true,
                            sum = "A rumble for a new level, and for a duel or trade request.",
                            text = "The controller gives two short pulses and a long one when you reach a new level, and two short pulses when a player asks you to duel or to trade. Not for a duel that Auto Decline Duel declines.",
                            steps = {
                                { keys = {}, text = "Level up: two short pulses and a long one" },
                                { keys = {}, text = "Duel or trade: two short pulses" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "feel.rumble_ready", module = "RumbleReady", built = true, name = "Rumble When Ready", kind = "toggle", default = false,
                            sum = "A short pulse in combat when a spell is ready again.",
                            text = "In combat, the controller pulses when a spell with a cooldown of 10 seconds or more is ready. Spells ready together give one pulse. Rumble sets its strength or stops it. Flash When Ready, on the On-Screen Buttons tab, flashes the button.",
                            steps = {
                                { keys = {}, text = "A spell is ready in combat: one short pulse" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        back,
                    },
                },
            },
            {
                key = "feel.objective_sound", module = "ObjectiveSound", built = true, name = "Objective Sound", kind = "toggle", default = true,
                sum = "A sound when a quest objective is done.",
                text = "When you finish an objective of a quest in your log, the game's objective sound plays. When the whole quest is done, the game's quest complete sound plays instead. You hear your progress without a look at the quest list.",
                steps = {
                    { keys = {}, text = "Finish a quest objective" },
                    { keys = {}, text = "Listen for the sound" },
                },
                facts = { { "Default", "On" } },
            },
            {
                key = "controller.roll_buttons", module = "Rolls", built = true, name = "Roll Buttons", kind = "toggle", default = true,
                sum = "Hold A, X or B to answer a loot roll.",
                text = "A loot roll shows low in the middle of the screen. Hold A for Need, X for Greed or B for Pass for 1 second, then let go. A quick tap still casts your bind. The item's tooltip shows beside it, with what you wear.",
                steps = {
                    { keys = { "DU", "DD" }, text = "Choose the roll" },
                    { keys = { "A", "X", "B" }, text = "Hold 1 second, then let go: Need, Greed or Pass" },
                },
                facts = { { "Default", "On" } },
            },
            {
                key = "controller.back_buttons", built = true, name = "Back Buttons", kind = "open",
                sum = "The keys that L4, L5, R4 and R5 answer to.",
                text = "Opens a page with the four back buttons. Each one works as the controller's back button and as the key Steam Input usually sends for it: F13 for L4, F14 for R4, F15 for L5, F16 for R5. The last row shows them beside the bars.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                sub = {
                    title = "Back Buttons",
                    line = "The keys each back button answers to, and the back buttons beside the bars.",
                    rows = {
                        grip("L4", "F13"), grip("L5", "F15"), grip("R4", "F14"), grip("R5", "F16"),
                        {
                            key = "screen.bars_grips", built = true, name = "Back Buttons on Bars", kind = "toggle", default = false,
                            sum = "L4, L5, R4 and R5 beside the bars.",
                            text = "For the Bars look. L4 and L5 show past LB, and R4 and R5 past RB, beside the No trigger bar. Each one shows its bind on the layer in use. Turn it on if your controller has back buttons, like the Steam Deck.",
                            steps = {
                                { keys = { "L4", "R4" }, text = "Small buttons beside the bars" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        back,
                    },
                },
            },
            {
                key = "controller.mouse_page", module = "Pointer", built = true, name = "Mouse Mode", kind = "open",
                sum = "A pointer on the right stick, for any window.",
                text = "Opens a page with four rows: the buttons that turn the pointer on and off, Pointer Magnet, Trackpad and Touch, and Mouse Mode at the Auction House.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                sub = {
                    title = "Mouse Mode",
                    line = "A pointer on the right stick, for the windows a controller does not reach.",
                    rows = {
                        {
                            key = "controller.mouse_mode", name = "Mouse Mode Buttons", kind = "pick", default = "View + Menu", built = true, module = "Pointer",
                            options = { "Off", "View + Menu" },
                            sum = "Two buttons turn the pointer on.",
                            text = "Hold View and press Menu to turn the pointer on and off, in the game's windows too. View keeps its bind. The right stick moves the pointer. LT is the left mouse button, RT the right one. Not in combat. Mouse Mode is also a bind.",
                            steps = {
                                { keys = { "VW", "MN" }, text = "Hold View, press Menu" },
                                { keys = { "RS" }, text = "Move the pointer" },
                                { keys = { "LT", "RT" }, text = "Left click and right click" },
                            },
                            facts = { { "Default", "View + Menu" } },
                        },
                        {
                            key = "controller.pointer_magnet", module = "PointerMagnet", built = true, name = "Pointer Magnet", kind = "toggle", default = true,
                            sum = "The pointer moves onto the nearest button of a window.",
                            text = "In mouse mode, let go of the right stick and the pointer moves onto the nearest button, box or slider of an open window, and stays there. Push the stick to move it on. It never moves onto the world.",
                            steps = {
                                { keys = { "RS" }, text = "Move the pointer near a button" },
                                { keys = {}, text = "Let go: it moves onto the button" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        {
                            key = "controller.pointer_handoff", module = "Handoff", built = true, name = "Trackpad and Touch", kind = "toggle", default = false,
                            sum = "A tap or a click shows the pointer.",
                            text = "The game hides the pointer while a stick turns the camera. Tap the screen or a trackpad, or click the mouse, and the pointer shows and stays. Tap again to click. Press a button or push a stick, and the stick turns the camera again.",
                            steps = {
                                { keys = {}, text = "Tap the screen or a trackpad: the pointer shows" },
                                { keys = {}, text = "Tap again to click" },
                                { keys = { "RS" }, text = "Push a stick or press a button for the camera" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "controller.pointer_auction", module = "PointerAuction", built = true, name = "Mouse Mode at the Auction House", kind = "toggle", default = true,
                            sum = "The pointer comes on at the auction house.",
                            text = "When the auction house opens, the pointer comes on, and it goes off when the auction house closes. If the pointer was on already, it stays on. B still turns it off. Not in combat.",
                            steps = {
                                { keys = {}, text = "Open the auction house: the pointer comes on" },
                                { keys = { "B" }, text = "Turn the pointer off" },
                            },
                            facts = { { "Default", "On" } },
                        },
                        back,
                    },
                },
            },
        },
    },
    {
        id = "Automation", line = "Vendors, quests, loot, duels and death, done for you, and a seat that holds while you eat.",
        rows = {
            {
                key = "helpers.vendor_page", built = true, name = "Vendor", kind = "open",
                sum = "Sells junk, repairs and restocks at a vendor.",
                text = "Opens a page with three rows: Auto Sell Junk, Auto Repair and Restock. Each one works when you open a vendor.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = {},
                sub = {
                    title = "Vendor",
                    line = "What the addon does for you when you open a vendor.",
                    rows = {
                        {
                            key = "helpers.sell_junk", module = "SellJunk", built = true, name = "Auto Sell Junk", kind = "toggle", default = false,
                            sum = "Sells your gray items and marked junk when you open a vendor.",
                            text = "When you open a vendor, your gray items are sold, then the items you marked with Mark Junk. One chat message says how many went and what they brought. An item a quest needs is never sold. Hold View as you open the vendor to keep them.",
                            steps = {
                                { keys = {}, text = "Open a vendor" },
                                { keys = {}, text = "One chat message says what was sold" },
                                { keys = { "VW" }, text = "Hold View as you open it to keep them" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "helpers.repair", module = "Repair", built = true, name = "Auto Repair", kind = "toggle", default = false,
                            sum = "Repairs your gear at a vendor that can repair.",
                            text = "When you open a vendor that can repair, all your gear is repaired. Your guild pays when it allows that. One chat message says the cost. If your gold is short, it waits for the gold of a sale. Hold View to skip it.",
                            steps = {
                                { keys = {}, text = "Open a vendor that can repair" },
                                { keys = {}, text = "One chat message says the cost" },
                                { keys = { "VW" }, text = "Hold View as you open it to skip it" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "helpers.restock_page", module = "Restock", built = true, name = "Restock", kind = "open",
                            sum = "Buys ammo, drinks, food and class reagents at a vendor.",
                            text = "Opens a page with a switch and four counts: ammo, drinks, food and class reagents. At a vendor that sells them, the addon buys what you are short of, up to each count.",
                            steps = {
                                { keys = { "A" }, text = "Open" },
                            },
                            facts = { { "Default", "Off" } },
                            sub = {
                                title = "Restock",
                                line = "What the addon buys for you at a vendor.",
                                rows = {
                                    {
                                        key = "helpers.restock", module = "Restock", built = true, name = "Restock at Vendors", kind = "toggle", default = false,
                                        sum = "Buys what you are short of when you open a vendor.",
                                        text = "When you open a vendor, the addon buys what you are short of, up to the four counts on this page, and leaves you a tenth of your gold. One chat message shows what it bought. Hold View as you open the vendor to buy nothing.",
                                        steps = {
                                            { keys = {}, text = "Set a count on this page" },
                                            { keys = {}, text = "Open a vendor that sells it" },
                                        },
                                        facts = { { "Default", "Off" } },
                                    },
                                    {
                                        key = "helpers.restock_ammo", module = "Restock", built = true, name = "Ammo Stacks", kind = "slide", default = 0, min = 0, max = 20, step = 1,
                                        sum = "Stacks of arrows or bullets to carry. 0 buys none.",
                                        text = "The addon buys the best arrows or bullets the vendor sells that your level can use, for the bow or gun you wear. Only that kind or better in your bags counts. To shoot new ammo, put it in your ammo slot.",
                                        steps = {
                                            { keys = { "DL", "DR" }, text = "Left: fewer. Right: more." },
                                        },
                                        facts = { { "Default", "0 (buys none)" } },
                                    },
                                    {
                                        key = "helpers.restock_drink", module = "Restock", built = true, name = "Drinks", kind = "slide", default = 0, min = 0, max = 200, step = 5,
                                        sum = "Drinks to carry. 0 buys none.",
                                        text = "The addon buys the best drink the vendor sells that your level can use. Only that drink or a better one in your bags counts. Lower drinks stay in your bags. A vendor sells drinks in fives, so you can end up a few short of the count.",
                                        steps = {
                                            { keys = { "DL", "DR" }, text = "Left: fewer. Right: more." },
                                        },
                                        facts = { { "Default", "0 (buys none)" } },
                                    },
                                    {
                                        key = "helpers.restock_food", module = "Restock", built = true, name = "Food", kind = "slide", default = 0, min = 0, max = 200, step = 5,
                                        sum = "Food to carry. 0 buys none.",
                                        text = "The addon buys the best food the vendor sells that your level can use. Only that food or better food in your bags counts. Lower food stays in your bags. A vendor sells food in fives, so you can end up a few short of the count.",
                                        steps = {
                                            { keys = { "DL", "DR" }, text = "Left: fewer. Right: more." },
                                        },
                                        facts = { { "Default", "0 (buys none)" } },
                                    },
                                    {
                                        key = "helpers.restock_reagents", module = "Restock", built = true, name = "Class Reagents", kind = "slide", default = 0, min = 0, max = 40, step = 1,
                                        sum = "Reagents to carry for your spells. 0 buys none.",
                                        text = "The addon buys up to this many of each reagent your learned spells use, such as the Ankh for Reincarnation. Only the reagent of your highest rank counts, and what is in your bags counts. It buys none while the Reagent Economy talent is on.",
                                        steps = {
                                            { keys = { "DL", "DR" }, text = "Left: fewer. Right: more." },
                                        },
                                        facts = { { "Default", "0 (buys none)" } },
                                    },
                                    back,
                                },
                            },
                        },
                        back,
                    },
                },
            },
            {
                key = "helpers.quests", module = "Quests", built = true, name = "Auto Quest", kind = "toggle", default = false,
                sum = "Accepts and turns in quests. It does not choose rewards.",
                text = "Quests are accepted and turned in for you. It stops for a choice of rewards, a cost, a PvP, gray or repeatable quest, a full quest log, or a group quest in a group. With the controller interface on, only in Dialogue View.",
                steps = {
                    { keys = {}, text = "Talk to the quest giver" },
                    { keys = { "A" }, text = "Press A only to choose a reward" },
                    { keys = { "VW" }, text = "Hold View to read it yourself" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                key = "helpers.skip_gossip", module = "Gossip", built = true, name = "Skip Gossip", kind = "toggle", default = false,
                sum = "Opens a vendor, trainer, flight master or bank at once.",
                text = "When an NPC's only choice opens a vendor, trainer, flight master, guild charter or bank, and there is no quest, it is taken for you. Not in a dungeon. With the controller interface on, only in Dialogue View. Hold View to stop it.",
                steps = {
                    { keys = {}, text = "Talk to the NPC" },
                    { keys = { "VW" }, text = "Hold View to see the choices" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                key = "helpers.fast_loot", module = "FastLoot", built = true, name = "Fast Loot", kind = "toggle", default = false,
                sum = "Takes all the loot at once.",
                text = "When you loot, everything goes to your bags at once. An item that binds on pickup still asks you first, and a loot roll still shows. With full bags only the coins are taken. Hold View as you loot to pick by hand.",
                steps = {
                    { keys = {}, text = "Loot a corpse or a chest" },
                    { keys = { "VW" }, text = "Hold View as you loot to pick by hand" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                key = "helpers.pass_unusable", module = "PassUnusable", built = true, name = "Pass on Gear You Cannot Wear", kind = "toggle", default = false,
                sum = "Passes on loot rolls for gear your class can never use.",
                text = "When a loot roll starts for armor or a weapon your class can never learn, like plate for a mage, you pass on it. One chat line names the item. Gear you can use now or at a higher level is never passed on, nor is anything that is not gear.",
                steps = {
                    { keys = {}, text = "A loot roll starts in a group" },
                    { keys = {}, text = "A chat line names the item you passed on" },
                },
                facts = { { "Default", "Off" } },
            },
            {
                key = "helpers.duels_page", built = true, name = "Duels, Death and Eating", kind = "open",
                sum = "Declines duels, releases your spirit and keeps you seated.",
                text = "Opens a page with three rows: Auto Decline Duel, Auto Release and Stay Seated While Eating.",
                steps = {
                    { keys = { "A" }, text = "Open" },
                },
                facts = { { "Default", "All off" } },
                sub = {
                    title = "Duels, Death and Eating",
                    line = "What the addon does for you when a player asks for a duel, when you die and while you eat.",
                    rows = {
                        {
                            key = "helpers.decline_duel", module = "DeclineDuel", built = true, name = "Auto Decline Duel", kind = "toggle", default = false,
                            sum = "Declines every duel a player asks for.",
                            text = "When a player asks you to duel, the addon declines at once. One chat message names the player. A duel to the death on a Hardcore realm still asks you.",
                            steps = {
                                { keys = {}, text = "A player asks you to duel" },
                                { keys = {}, text = "One chat message names the player" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "helpers.auto_release", module = "Release", built = true, name = "Auto Release", kind = "pick", default = "Off",
                            options = { "Off", "Battlegrounds", "Solo and Battlegrounds" },
                            sum = "Releases your spirit when you die.",
                            text = "When you die, your spirit is released after one second. Battlegrounds: only there. Solo and Battlegrounds: also when you are not in a group. Never in a dungeon or a raid, or when a soulstone or another player can bring you back.",
                            steps = {
                                { keys = { "DL", "DR" }, text = "Left and right change where it works" },
                                { keys = {}, text = "One chat message says your spirit is released" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        {
                            key = "auto.stay_seated", module = "Seated", built = true, name = "Stay Seated While Eating", kind = "toggle", default = false,
                            sum = "A small push of the left stick does not stand you up.",
                            text = "While you eat or drink, a small push of the left stick does not stand you up. To stand up, push the left stick all the way for half a second. The right stick still turns the camera. It acts out of combat only.",
                            steps = {
                                { keys = {}, text = "Eat or drink" },
                                { keys = { "LS" }, text = "To stand up, push the left stick all the way" },
                            },
                            facts = { { "Default", "Off" } },
                        },
                        back,
                    },
                },
            },
        },
    },
}
