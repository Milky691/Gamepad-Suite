-- The frames of the Fixed Slot Binds page and how they are drawn: a line for each fixed slot on the
-- left (its action's picture, or a green plus when it is empty; its name; the small pictures of
-- its buttons), and on the parchment the page of the slot in focus (Settings/Paper.lua). A slot
-- with an action shows there as it is in the game, at twice its size, with its buttons above it,
-- on the dark disc of My Wheels.
-- It draws what SlotsPage.lua gives it and holds no state of the page.
-- The sizes are the ones of the sample the user saw (mockups/slots_sample.py).
local _, ns = ...

local Theme, Widgets = ns.Theme, ns.Widgets
local px = Theme.px

local Draw = {}
ns.SettingsSlotsDraw = Draw

-- Numbers are in the mockup's units.
local WIDTH, HEIGHT, LIST_WIDTH, STAGE_X = 1232, 544, 280, 310
local FIRST_Y, LINE_HEIGHT, LINE_GAP, BREAK, PICTURE, DISC = 76, 38, 2, 16, 96, 208

local NOTE = "Empty slots do not show in the game. A tap or a click on a slot works. Slots with a bind are in the bind list under Fixed Slots."

local frame, body, paper, picture
local rows = {}
local actions -- what the mouse does, given by SlotsPage.lua

local function listLine(i)
    local row = CreateFrame("Frame", nil, body)
    row:SetSize(px(LIST_WIDTH), px(LINE_HEIGHT))
    row.light = row:CreateTexture(nil, "BACKGROUND")
    row.light:SetTexture(Theme.art.rowLight)
    row.light:SetBlendMode("ADD")
    row.light:SetAlpha(0.42)
    row.light:SetAllPoints()
    row.bar = Theme.Fill(row, "ARTWORK", Theme.Color("gold"))
    row.bar:SetWidth(px(3))
    row.bar:SetPoint("TOPLEFT", 0, -px(7))
    row.bar:SetPoint("BOTTOMLEFT", 0, px(7))
    row.icon = Widgets.Icon(row, px(28))
    row.icon:SetPoint("LEFT", px(12), 0)
    row.plus = ns.SettingsWheelsDraw.Plus(row.icon, 10, 2, "green")
    row.name = Theme.Text(row, "row", "cream")
    row.name:SetPoint("LEFT", px(50), 0)
    row.keys = Widgets.Keys(row, 20, 3)
    row.keys:SetPoint("RIGHT", -px(12), 0)
    -- Back leads to another page: it has the arrow and the glow of a control, and a gold name
    row.nav = Widgets.Nav(row)
    -- the mouse: hover gives the focus, a click is A, a right click is X
    row:EnableMouse(true)
    row:SetScript("OnEnter", function() actions.Focus(i) end)
    row:SetScript("OnMouseUp", function(_, button)
        actions.Focus(i, true)
        if button == "RightButton" then
            actions.Clear()
        else
            actions.Press()
        end
    end)
    rows[i] = row
end

-- handlers are the page's actions: Focus(index, clicked), Press(), Clear()
function Draw.Build(win, handlers, most)
    actions = handlers
    frame = CreateFrame("Frame", nil, win)
    frame:SetPoint("TOPLEFT", px(24), -px(119))
    frame:SetSize(px(WIDTH), px(HEIGHT))
    frame:Hide()
    -- body holds the page's own parts, so all of them hide together while the list of binds is open
    body = CreateFrame("Frame", nil, frame)
    body:SetAllPoints()
    local title = Theme.Text(body, "title", "gold", true)
    title:SetPoint("TOPLEFT")
    title:SetText("Fixed Slot Binds")
    for i = 1, most + 1 do
        listLine(i)
    end
    -- under the list, as on My Wheels
    local note = Theme.Text(body, "small", "muted")
    note:SetPoint("BOTTOMLEFT", 0, px(4))
    note:SetWidth(px(250))
    note:SetWordWrap(true)
    note:SetSpacing(px(4))
    note:SetText(NOTE)
    paper = ns.SettingsPaper.Build(body, STAGE_X)
    -- the slot as it is in the game, on the dark disc, in the middle of the column under the lead
    local plate = CreateFrame("Frame", nil, paper.page)
    plate:SetSize(px(DISC), px(DISC))
    plate:SetPoint("TOP", paper.lead, "BOTTOM", 0, -px(28))
    local disc = ns.WheelView.Piece(plate, "BACKGROUND")
    disc:SetColorTexture(0, 0, 0, 0.62)
    disc:SetAllPoints()
    disc:AddMaskTexture(disc.mask)
    picture = ns.SlotView.Make(plate)
    picture:SetSize(px(PICTURE), px(PICTURE))
    -- a little under the middle: the row of its buttons is above it
    picture:SetPoint("CENTER", plate, "CENTER", 0, -px(22))
    picture.top:SetScale(PICTURE / 48)
    picture.plate = plate
    return frame, body
end

-- lines and focus are the page's (SlotsModel.lua); panel is Model.Panel of the line in focus.
function Draw.Page(lines, focus, panel)
    local y = FIRST_Y
    for i, row in ipairs(rows) do
        local line = lines[i]
        row:SetShown(line ~= nil)
        if line then
            if i > 1 then
                y = y + LINE_HEIGHT + (line.back and BREAK or LINE_GAP)
            end
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", 0, -px(y))
            local focused = i == focus
            row.light:SetShown(focused)
            row.bar:SetShown(focused)
            row.name:SetText(line.name)
            row.name:SetTextColor(Theme.Color((line.back and "gold") or (focused and "white") or (line.action and "cream") or "muted"))
            row.nav:Set(line.back and "back" or nil)
            row.icon:SetShown(not line.back)
            row.icon:SetIcon(line.action and ns.Adapter.BindIcon(ns.BindRules.Real(line.action)) or nil)
            row.plus:SetShown(not line.back and line.action == nil)
            row.keys.Set(line.keys)
        end
    end
    paper.Show(panel, panel.picture)
    local line = lines[focus]
    picture.plate:SetShown(panel.picture == true)
    if panel.picture then
        ns.Screen.Fill(picture, ns.BindRules.Real(line.action), ns.Registry.Get("screen.cooldown_numbers"))
        ns.Screen.Look(picture)
        picture.Dim(line.unknown)
        picture.top.Set(line.keys)
    end
end
