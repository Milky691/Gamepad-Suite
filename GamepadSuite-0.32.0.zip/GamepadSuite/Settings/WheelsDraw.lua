-- The frames of the My Wheels page and how they are drawn: the list of the player's wheels on the
-- left; on the parchment the name box of the wheel in focus and its ring, larger than in
-- the game. The ring always has eight slots, each at its own direction. A slot with a bind shows
-- the bind's picture; an empty slot shows a green plus. The player puts a bind on the slot they
-- want. In the game only the slots with a bind show. The pictures are round, as on a wheel in the
-- game, and the slot in focus has a gold rim.
-- The page has two levels (WheelsModel.lua). In the list of wheels the line in focus is lit, and
-- no slot and no name box has a focus mark. Inside a wheel its line keeps the gold bar alone, and
-- the slot or the name box in focus has the mark.
-- It draws what WheelsPage.lua gives it and holds no state of the page.
-- The sizes are the ones of the sample the user saw (mockups/mywheels_sample.py).
local _, ns = ...

local Theme, Widgets, Model, View = ns.Theme, ns.Widgets, ns.SettingsWheelsModel, ns.WheelView
local px = Theme.px

local Draw = {}
ns.SettingsWheelsDraw = Draw

-- Numbers are in the mockup's units. SCALE: the ring is drawn at twice its size in the game.
local WIDTH, HEIGHT, LIST_WIDTH, STAGE_X, SCALE = 1232, 544, 280, 310, 2
local FIRST_Y, STEP, LINE_HEIGHT, MOST_LINES, MIDDLE_WIDTH = 76, 60, 54, 6, 140
local NAME_WIDTH, NAME_HEIGHT, NAME_LEFT, NAME_TOP, HEAD_LINE = 360, 48, 44, 38, 56
-- the middle of the ring is this far under the middle of the parchment: the name box is over it
local RING_DOWN = 20
local NOTE = "Empty slots do not show in the game. Saved wheels are in the bind list under Wheels."
local BACK_TEXT = "Goes back to the page you came from. B does the same."

local frame, body, stage, ring, heading, backText, name, count, nameBox
local rows, cells = {}, {}
local actions -- what the mouse and the text box do, given by WheelsPage.lua

-- A plus of two flat bars, in the middle of its parent.
local function plus(parent, arm, thick, colorName)
    local mark = CreateFrame("Frame", nil, parent)
    mark:SetAllPoints()
    for _, size in ipairs({ { arm, thick }, { thick, arm } }) do
        local bar = Theme.Fill(mark, "OVERLAY", Theme.Color(colorName))
        bar:SetSize(px(size[1]), px(size[2]))
        bar:SetPoint("CENTER")
    end
    return mark
end

local function listLine(i)
    local row = CreateFrame("Frame", nil, body)
    row:SetSize(px(LIST_WIDTH), px(LINE_HEIGHT))
    row:SetPoint("TOPLEFT", 0, -px(FIRST_Y + (i - 1) * STEP))
    row.light = row:CreateTexture(nil, "BACKGROUND")
    row.light:SetTexture(Theme.art.rowLight)
    row.light:SetBlendMode("ADD")
    row.light:SetAlpha(0.42)
    row.light:SetAllPoints()
    row.bar = Theme.Fill(row, "ARTWORK", Theme.Color("gold"))
    row.bar:SetWidth(px(3))
    row.bar:SetPoint("TOPLEFT", 0, -px(7))
    row.bar:SetPoint("BOTTOMLEFT", 0, px(7))
    row.icon = Widgets.Icon(row, px(40))
    row.icon:SetPoint("LEFT", px(12), 0)
    row.plus = plus(row.icon, 12, 2, "muted")
    row.name = Theme.Text(row, "row", "cream")
    row.name:SetPoint("LEFT", px(64), 0)
    -- New Wheel and Back lead to another page: they have the arrow and the glow of a control
    row.nav = Widgets.Nav(row)
    -- the mouse: hover gives the focus, a click is A
    row:EnableMouse(true)
    row:SetScript("OnEnter", function() actions.FocusLine(i) end)
    row:SetScript("OnMouseUp", function()
        actions.FocusLine(i, true)
        actions.Press()
    end)
    return row
end

-- A slot of the ring: a rim (thin, or thick and gold with the focus), a black edge,
-- and the bind's picture or, when the slot is empty, a dark plate with a green plus.
-- index is the slot's number, for the mouse.
local function slot(parent, size, index)
    local c = CreateFrame("Frame", nil, parent)
    c:SetSize(px(size), px(size))
    c.rim = View.Piece(c, "BACKGROUND", 1)
    c.edge = View.Piece(c, "BACKGROUND", 2)
    c.edge:SetColorTexture(0, 0, 0, 1)
    c.edge:SetPoint("TOPLEFT", -px(2), px(2))
    c.edge:SetPoint("BOTTOMRIGHT", px(2), -px(2))
    c.art = View.Piece(c, "ARTWORK")
    c.art:SetAllPoints()
    for _, part in ipairs({ c.rim, c.edge, c.art }) do
        View.Round(part, true)
    end
    c.plus = plus(c, 28, 4, "green")
    -- the mouse: hover gives the focus, a click is A, a right click is X
    c:EnableMouse(true)
    c:SetScript("OnEnter", function() actions.FocusStop(index) end)
    c:SetScript("OnMouseUp", function(_, button)
        -- the slot that was clicked, not the slot the D-pad left the focus on
        actions.FocusStop(index, true)
        if button == "RightButton" then
            actions.Clear()
        else
            actions.Press()
        end
    end)
    return c
end

-- The rim of a slot: thick and gold with the focus, else thin and faint.
local function rim(c, focused, faint)
    local out = px(focused and 6 or 4)
    c.rim:SetPoint("TOPLEFT", -out, out)
    c.rim:SetPoint("BOTTOMRIGHT", out, -out)
    if focused then
        c.rim:SetColorTexture(Theme.Color("gold"))
    else
        c.rim:SetColorTexture(faint[1], faint[2], faint[3], 0.5)
    end
end

-- A line round a frame, outside it: four bars, `thick` wide, starting `from` away from its edge.
local function outline(parent, from, thick, r, g, b, a)
    local to = px(from + thick)
    from = px(from)
    local bars = {}
    -- top and bottom run past the corners; left and right fill in between
    for i, at in ipairs({ { "BOTTOMLEFT", "TOPLEFT", -to, from, "BOTTOMRIGHT", "TOPRIGHT", to, from, "SetHeight" },
                          { "TOPLEFT", "BOTTOMLEFT", -to, -from, "TOPRIGHT", "BOTTOMRIGHT", to, -from, "SetHeight" },
                          { "TOPRIGHT", "TOPLEFT", -from, from, "BOTTOMRIGHT", "BOTTOMLEFT", -from, -from, "SetWidth" },
                          { "TOPLEFT", "TOPRIGHT", from, from, "BOTTOMLEFT", "BOTTOMRIGHT", from, -from, "SetWidth" } }) do
        local bar = Theme.Fill(parent, "BORDER", r, g, b, a)
        bar:SetPoint(at[1], parent, at[2], at[3], at[4])
        bar:SetPoint(at[5], parent, at[6], at[7], at[8])
        bar[at[9]](bar, to - from)
        bars[i] = bar
    end
    return bars
end

Draw.Outline = outline -- the Profiles page draws its text box with the same line
Draw.Plus = plus       -- the Fixed Slot Binds page marks an empty slot with the same plus

-- The name box: a text field at the top of the parchment with the wheel's name in it. It has
-- the rim of the window's picture boxes (a black line, then a faint gold one), and a full gold
-- rim with the focus. The box has a text box of its own for a real keyboard, shown only while
-- the player types in it.
local function buildNameBox()
    nameBox = CreateFrame("Frame", nil, stage)
    nameBox:SetSize(px(NAME_WIDTH), px(NAME_HEIGHT))
    nameBox:SetPoint("TOPLEFT", px(NAME_LEFT), -px(NAME_TOP))
    local plate = Theme.Fill(nameBox, "BACKGROUND", 0, 0, 0, 0.62)
    plate:SetAllPoints()
    outline(nameBox, 0, 1, 0, 0, 0, 1)
    nameBox.rim = outline(nameBox, 1, 2, Theme.Color("iconEdge", 0.5))
    nameBox.frame = outline(nameBox, 1, 3, Theme.Color("gold"))
    nameBox.text = Theme.Text(nameBox, "name", "cream")
    nameBox.text:SetPoint("LEFT", px(14), 0)
    nameBox.text:SetPoint("RIGHT", -px(14), 0)
    local edit = CreateFrame("EditBox", nil, nameBox)
    edit:SetAutoFocus(false)
    edit:SetFont(Theme.font.text, px(Theme.size.name), "")
    edit:SetTextColor(Theme.Color("cream"))
    edit:SetMaxLetters(ns.WheelRules.NAME_MOST)
    edit:SetPoint("TOPLEFT", px(14), 0)
    edit:SetPoint("BOTTOMRIGHT", -px(14), 0)
    edit:Hide()
    -- Enter, or a focus that goes away, keeps the name; Escape does not
    edit:SetScript("OnEnterPressed", function(self) actions.NameDone(self:GetText()) end)
    edit:SetScript("OnEditFocusLost", function(self) actions.NameDone(self:GetText()) end)
    edit:SetScript("OnEscapePressed", function() actions.NameCancel() end)
    nameBox.edit = edit
    nameBox:EnableMouse(true)
    nameBox:SetScript("OnEnter", function() actions.FocusStop("name") end)
    nameBox:SetScript("OnMouseUp", function()
        actions.FocusStop("name", true)
        actions.Press()
    end)
end

-- Where each stop of a wheel is on the parchment, in the mockup's units, in reading order: the
-- name box of a saved wheel (named), then the eight slots of the ring. The D-pad inside a wheel
-- goes by these places (Settings/Nav.lua). Draw.Page puts the slots at the same places.
function Draw.Places(rules, named)
    local places = {}
    if named then
        places[1] = { id = "name", x = NAME_LEFT, y = NAME_TOP, w = NAME_WIDTH, h = NAME_HEIGHT }
    end
    local radius, picture = rules.Radius(rules.MOST, 100) * SCALE, rules.PICTURE * SCALE
    local middleX, middleY = (WIDTH - STAGE_X) / 2, HEIGHT / 2 + RING_DOWN
    for i = 1, rules.MOST do
        local x, y = rules.Direction(i, rules.MOST)
        places[#places + 1] = { id = i, x = middleX + x * radius - picture / 2, y = middleY - y * radius - picture / 2, w = picture, h = picture }
    end
    return places
end

-- handlers are the page's actions: FocusLine(index, clicked), FocusStop(id, clicked) with id "name" or the
-- number of a slot, Press(), Clear(), NameDone(text), NameCancel()
function Draw.Build(win, handlers)
    actions = handlers
    frame = CreateFrame("Frame", nil, win)
    frame:SetPoint("TOPLEFT", px(24), -px(119))
    frame:SetSize(px(WIDTH), px(HEIGHT))
    frame:Hide()
    -- body holds the page's own parts, so all of them hide together while the list of binds is open
    body = CreateFrame("Frame", nil, frame)
    body:SetAllPoints()

    local title = Theme.Text(body, "title", "gold", true)
    title:SetPoint("TOPLEFT")
    title:SetText("My Wheels")
    for i = 1, MOST_LINES do
        rows[i] = listLine(i)
    end
    local note = Theme.Text(body, "small", "muted")
    note:SetPoint("BOTTOMLEFT", 0, px(4))
    note:SetWidth(px(250))
    note:SetWordWrap(true)
    note:SetSpacing(px(4))
    note:SetText(NOTE)

    -- the parchment, as on every page of the window
    stage = CreateFrame("Frame", nil, body, "BackdropTemplate")
    stage:SetPoint("TOPLEFT", px(STAGE_X), 0)
    stage:SetPoint("BOTTOMRIGHT")
    stage:SetBackdrop({ edgeFile = Theme.art.edgeThin, edgeSize = px(16) })
    stage:SetBackdropBorderColor(Theme.Color("paperEdge"))
    local paper = stage:CreateTexture(nil, "BACKGROUND")
    paper:SetTexture(Theme.art.parchment)
    paper:SetPoint("TOPLEFT", px(5), -px(5))
    paper:SetPoint("BOTTOMRIGHT", -px(5), px(5))
    -- New Wheel and Back have no name box: they keep the page's ink heading
    -- (the heading sits in a line as high as the name box, so the ring does not move)
    heading = Theme.Text(stage, "head", "inkRed", true, true)
    heading:SetPoint("LEFT", stage, "TOPLEFT", px(44), -px(28 + HEAD_LINE / 2))
    backText = Theme.Text(stage, "row", "ink", false, true)
    backText:SetPoint("TOPLEFT", px(44), -px(100))
    backText:SetText(BACK_TEXT)
    buildNameBox()

    -- the ring on its dark disc, in the middle of the room under the name box
    ring = CreateFrame("Frame", nil, stage)
    ring:SetPoint("CENTER", stage, "CENTER", 0, -px(RING_DOWN))
    local disc = View.Piece(ring, "BACKGROUND")
    disc:SetColorTexture(0, 0, 0, 0.62)
    disc:SetAllPoints()
    disc:AddMaskTexture(disc.mask)
    for i = 1, ns.WheelRules.MOST do
        cells[i] = slot(ring, ns.WheelRules.PICTURE * SCALE, i)
    end
    -- two lines in the free middle of the ring: the name of what has the focus, and the count
    name = Theme.Text(ring, "body", "cream")
    name:SetWidth(px(MIDDLE_WIDTH))
    name:SetJustifyH("CENTER")
    name:SetWordWrap(true)
    -- (three lines for "Cannot run now: ..." of a bind the game cannot run; a name takes two at most)
    name:SetMaxLines(3)
    count = Theme.Text(ring, "small", "cream")
    return frame, body
end

-- The player types a name with a real keyboard: the text box shows in the name box, with the
-- text, and a click on it gives it the keyboard focus. The addon moves no keyboard focus itself:
-- a working Forever addon traced a blocked action and a crash to that (ledger-link PR #8). (The
-- game shows no keyboard of its own for a text box: its UI code has no call for one. With a
-- controller alone the name comes from the addon's on-screen keyboard, Settings/WheelsPage.lua.)
function Draw.StartTyping(text)
    nameBox.text:Hide()
    local edit = nameBox.edit
    edit:SetText(text)
    edit:Show()
    edit:HighlightText()
end

function Draw.StopTyping()
    nameBox.edit:ClearFocus()
    nameBox.edit:Hide()
    nameBox.text:Show()
end

-- What the player typed so far.
function Draw.TypedText()
    return nameBox.edit:GetText()
end

-- lines and state are the page's (WheelsModel.lua); rules is Core/WheelRules.lua. typing is true
-- while the player types a name.
function Draw.Page(state, lines, rules, typing)
    for i, row in ipairs(rows) do
        local line = lines[i]
        row:SetShown(line ~= nil)
        if line then
            -- the light is the focus; inside a wheel its line keeps the bar alone
            local focused = i == state.line
            row.light:SetShown(focused and not state.inside)
            row.bar:SetShown(focused)
            row.name:SetText(line.name)
            local control = line.new or line.back
            row.name:SetTextColor(Theme.Color(control and "gold" or focused and not state.inside and "white" or "cream"))
            row.nav:Set(line.new and "next" or line.back and "back" or nil)
            -- a wheel shows the picture of its first bind, as it does in the bind list
            local _, first = Model.Count(line, rules)
            row.icon:SetShown(not line.back)
            row.icon:SetIcon(first and ns.Adapter.BindIcon(first) or nil)
            row.plus:SetShown(line.new == true)
        end
    end

    -- stop is nil in the list of wheels: no slot and no name box has the focus mark then
    local line, stop = Model.Focus(state, lines, rules)
    local saved = not line.new and not line.back
    heading:SetShown(not saved)
    heading:SetText(line.name)
    backText:SetShown(line.back == true)
    ring:SetShown(not line.back)
    nameBox:SetShown(saved)
    if saved then
        if not typing then
            nameBox.text:SetText(line.name)
        end
        local focused = typing or (stop ~= nil and stop.kind == "name")
        for i, bar in ipairs(nameBox.frame) do
            bar:SetShown(focused)
            nameBox.rim[i]:SetShown(not focused)
        end
    end
    if line.back then
        return
    end

    -- the ring: eight slots, each at its own direction, with the ring of the game for eight places
    local radius, why = rules.Radius(rules.MOST, 100) * SCALE, ns.Wheels and ns.Wheels.Why   -- (Core/WheelsNow.lua)
    local picture = rules.PICTURE * SCALE
    -- the disc: the ring, half a picture and 8 game units more
    local across = px(2 * radius + picture + 16 * SCALE)
    ring:SetSize(across, across)
    local places = Draw.Places(rules, false)
    for i, c in ipairs(cells) do
        local bind = line.slots[i]
        c:ClearAllPoints()
        c:SetPoint("TOPLEFT", stage, "TOPLEFT", px(places[i].x), -px(places[i].y))
        c.plus:SetShown(bind == nil)
        -- a bind the game cannot run now is not on the ring in the game: its picture is dim here (the Binds page's 0.55)
        c.art:SetAlpha(bind and why and why(bind) and 0.55 or 1)
        if bind then
            Widgets.Art(c.art, ns.Adapter.BindIcon(bind))
        else
            -- an empty slot: the dark plate of the plus box in the list
            c.art:SetColorTexture(0.04, 0.035, 0.03, 1)
        end
        rim(c, not typing and stop ~= nil and stop.index == i, bind and Theme.color.iconEdge or Theme.color.cream)
    end
    local text, total = Model.Middle(state, lines, rules, why)
    name:SetText(text)
    count:SetText(total)
    -- the two lines together sit in the middle, also when the name takes two lines; the count
    -- alone sits in the middle too
    name:ClearAllPoints()
    count:ClearAllPoints()
    if text == "" then
        count:SetPoint("CENTER", ring, "CENTER")
    else
        name:SetPoint("TOP", ring, "CENTER", 0, (name:GetStringHeight() + px(18)) / 2)
        count:SetPoint("TOP", name, "BOTTOM", 0, -px(3))
    end
end
