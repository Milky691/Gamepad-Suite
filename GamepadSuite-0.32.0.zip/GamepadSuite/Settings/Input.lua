-- Controller and keyboard input for the settings window.
-- The window takes the buttons itself while it is open, the way Blizzard's own gamepad windows do
-- (EnableGamePadButton and the OnGamePadButtonDown script). It sets no binding.
-- The sticks stay the game's, as ControllerForever's window leaves them: the hold of both stick
-- clicks that opens the window also runs the game's own jobs of those two buttons (auto run on
-- the left one, a ping on the right one: Blizzard_Gamepad GamepadPersistentInputLegend.lua 331
-- and 332), and the left stick must still be able to stop that run.
local _, ns = ...

local Input = {}
ns.SettingsInput = Input

local PAD = {
    PADLSHOULDER = "LB", PADRSHOULDER = "RB", PADLTRIGGER = "LT", PADRTRIGGER = "RT",
    PADDUP = "up", PADDDOWN = "down", PADDLEFT = "left", PADDRIGHT = "right",
    PAD1 = "A", PAD2 = "B", PAD3 = "X", PAD4 = "Y",
    -- Menu: Done on the on-screen keyboard (Screen/Keyboard.lua). The window itself does nothing with it.
    PADFORWARD = "MN",
}
local KEYS = {
    UP = "up", DOWN = "down", LEFT = "left", RIGHT = "right", Q = "LB", E = "RB", Z = "LT", C = "RT",
    ENTER = "A", SPACE = "A", ESCAPE = "B", BACKSPACE = "B", X = "X", Y = "Y",
}
local REPEATS = { up = true, down = true, left = true, right = true }
-- HOLD_SECONDS: the one hold of the suite that confirms a thing (the window's rows, a loot roll, the bank, the trainer)
local REPEAT_START, REPEAT_EVERY, HOLD_SECONDS = 0.38, 0.11, 1
Input.HOLD_SECONDS = HOLD_SECONDS

local win, onUpdate
local held, heldFor
local holding, holdFor = false, 0
local capture -- a page waits for the player to press a controller button: it gets the game's name of each one

-- The window has a per-frame step only while that step has work: a direction is held and
-- repeats, or A is held on a row that wants a hold.
local function watch()
    win:SetScript("OnUpdate", (held or holding) and onUpdate or nil)
end

local function act(what)
    local S = ns.Settings
    if what == "LB" then
        S.Chapter(-1)
    elseif what == "RB" then
        S.Chapter(1)
    elseif what == "up" then
        S.Move(-1)
    elseif what == "down" then
        S.Move(1)
    elseif what == "left" then
        S.Side(-1)
    elseif what == "right" then
        S.Side(1)
    elseif what == "LT" or what == "RT" or what == "Y" then
        -- the three buttons that only the binds page uses
        S.Layer(what)
    elseif what == "A" then
        if S.Press() then
            holding, holdFor = true, 0
        end
    elseif what == "B" then
        S.Back()
    elseif what == "X" then
        S.Clear()
    end
end

local function down(what)
    -- the on-screen keyboard is open over the window: a press that came here is the keyboard's
    if ns.Keyboard and ns.Keyboard.Act(what) then
        return
    end
    -- while the player types in a text box of the window, the buttons are the game's keyboard's
    if not what or ns.Settings.Typing(what) then
        return
    end
    -- another button ends a hold of A: the hold is for the row it started on
    if holding and what ~= "A" then
        holding = false
        ns.Settings.HoldProgress(0)
    end
    if REPEATS[what] then
        held, heldFor = what, 0
    end
    act(what)
    watch()
end

local function up(what)
    if what == held then
        held = nil
    end
    if what == "A" and holding then
        holding = false
        ns.Settings.HoldProgress(0)
    end
    watch()
end

-- A page asks for the next controller button (quick bind). fn gets the game's name of each
-- button that goes down, and returns true when it has its answer. nil ends the wait.
function Input.Capture(fn)
    capture = fn
end

-- The mouse presses the same buttons. A click is a press and a release.
function Input.Press(what)
    down(what)
end

function Input.Release(what)
    up(what)
end

function Input.Click(what)
    down(what)
    up(what)
end

function onUpdate(_, elapsed)
    if held then
        heldFor = heldFor + elapsed
        if heldFor >= REPEAT_START then
            heldFor = heldFor - REPEAT_EVERY
            act(held)
        end
    end
    if holding then
        holdFor = holdFor + elapsed
        ns.Settings.HoldProgress(holdFor / HOLD_SECONDS)
        if holdFor >= HOLD_SECONDS then
            holding = false
            ns.Settings.HoldDone()
            watch()
        end
    end
end

function Input.Attach(window)
    win = window
    win:EnableGamePadButton(true)
    win:EnableKeyboard(true)
    win:SetScript("OnGamePadButtonDown", function(_, button)
        if not capture then
            down(PAD[button])
        elseif capture(button) then
            capture = nil
        end
    end)
    win:SetScript("OnGamePadButtonUp", function(_, button) up(PAD[button]) end)
    -- a key that comes here while a text box is open is not for the window (the box has the keys).
    -- A key the window has no job for goes to a page that waits for a press: a back button that
    -- Steam Input sends as a key (Core/AdapterGrips.lua).
    win:SetScript("OnKeyDown", function(_, key)
        if capture and not KEYS[key] then
            if capture(key) then
                capture = nil
            end
        elseif not ns.Settings.Typing() then
            down(KEYS[key])
        end
    end)
    win:SetScript("OnKeyUp", function(_, key) up(KEYS[key]) end)
    win:HookScript("OnShow", function()
        held, holding, capture = nil, false, nil
        watch()
    end)
end

-- Hold both sticks in for one second to open or close the window, whatever is bound.
-- The game has no event for a button of the controller (its controller events are all in
-- Blizzard_APIDocumentationGenerated/GamePadDocumentation.lua: a controller came, went or
-- changed), and a frame that hears the buttons has to be shown and gets every press before the
-- game does. So the two buttons are looked at four times a second, and block no input. Not in a
-- fight: the window does not open in one, so the look stops when a fight starts. The game's own
-- watch of a held shoulder button looks in the same way, for the same reason: such a frame can
-- block input, and its let-go comes only to the frame that kept the press
-- (Blizzard_GamepadActionBars/ClassActionFlyout.lua 56 to 62).
function Input.WatchSticks()
    local ticker, looks, told = nil, 0, false
    local function look()
        if ns.Adapter.SticksDown() then
            looks = looks + 1
            -- the fifth look in a row is one second after the first; once for each hold
            if looks == 5 then
                ns.Settings.Toggle()
                -- (the log tells once in a session that the game gave the two stick clicks to this look)
                if not told then
                    told = true
                    ns.Log.Add("settings", "both stick clicks held one second: the window is " .. (ns.Settings.IsOpen() and "open" or "closed"))
                end
            end
        else
            looks = 0
        end
    end
    local function run(on)
        if ticker then
            ticker:Cancel()
        end
        looks = 0
        ticker = on and C_Timer.NewTicker(0.25, look) or nil
    end
    ns.On("PLAYER_REGEN_DISABLED", "SettingsSticks", function() run(false) end)
    ns.On("PLAYER_REGEN_ENABLED", "SettingsSticks", function() run(true) end)
    run(not ns.Adapter.InCombat())
end
