-- What the binds page offers right now, and the name of a bind as the page shows it. Binds.lua
-- (the page) asks here at each draw; the frames are BindsDraw.lua.
local _, ns = ...

local Widgets, Model, Store, Draw = ns.Widgets, ns.BindsModel, ns.Binds, ns.SettingsBindsDraw

local Shape = {}
ns.SettingsBindsShape = Shape

-- The card's words for a set. They fit in the card's two lines (about 125 letters).
-- In a form the form's bind wins over a Combat bind on that button; at Combat First the Combat
-- bind wins (Core/BindRules.lua Find).
local KEEPS = " A button with no bind here keeps its Normal bind."
local KEEPS_CAT = " A button with no bind here keeps its Cat Form bind."
local KEEPS_COMBAT = " A bind here wins over the other sets. The other buttons keep their bind."
local KEEPS_COMBAT_FORM = " A bind here wins over Normal. In a form, the form's bind wins."
local COMBAT_WINS = " A bind of the Combat set wins over a bind here."
local FORM_WINS = " Its binds win over Combat binds."

-- A bind's name, true when it is an action of the game itself, and its rank ("" when it has none).
function Shape.Describe(bind)
    local rank = ""
    if bind.kind == "spell" then
        -- the game's own text for the rank; the text kept when the bind was chosen stands in until the game has loaded it
        rank = ns.Adapter.SpellRank(bind.id)
        if rank == "" then
            rank = bind.detail or ""
        end
    end
    -- who it is cast on, when that is not the target, stands with the rank
    if Model.ON[bind.on] then
        rank = (rank ~= "" and rank .. ", " or "") .. Model.ON[bind.on]
    end
    -- A game command shows the game's name as it is now, not the one kept when the bind was made.
    -- The two Stick Target binds are commands with names of ours (Core/Binds.lua): those show.
    return Store.STICK and Store.STICK[bind.id] or bind.kind == "command" and ns.Adapter.CommandName(bind.id) or bind.name or tostring(bind.id),
        bind.kind == "command" or bind.kind == "emote" or bind.kind == "slash", rank
end

-- Sticky Layers: true for a bind that leaves its trigger layer on after the hold. The bind core sees a press on a
-- trigger layer only as a click of a button (Core/BindSecure.lua); a game command runs through none, so a trigger held
-- for it counts as a tap. A target command runs as its chat text from a button of ours (Core/BindPlan.lua), and is seen.
function Shape.Sticks(bind, layer)
    return layer >= 2 and layer <= 4 and bind.kind == "command" and not tostring(bind.id):find("^CLICK ")
        and ns.BindRules.ChatText(bind.id) == nil
end

-- What the page offers right now: the slots of the controller picture in use, the sets (Normal,
-- Combat when its setting is not Off, one for each form or stance), the hold layers that act
-- (switched on, and their buttons hold no bind: Core/BindRules.lua Holds), and the Dynamic
-- Interact button.
function Shape.Now()
    local get, style = ns.Registry.Get, Widgets.PadStyle()
    local layout = Draw.Layout(style)
    local sets = { { id = "normal", name = "Normal", help = "Your binds. A slot with no bind of its own in another set uses these." } }
    local combat = get("layers.combat_set")
    local forms = get("layers.forms_and_stances") ~= "Off" and ns.Adapter.Forms() or {}
    local combatFirst = get("layers.forms_and_stances") == "Combat First"
    if combat ~= "Off" then
        -- "Hostile target" is combat, and also out of combat with an enemy targeted
        local when = combat == "Hostile target" and "Used in combat, and while you target an enemy." or "Used in combat."
        sets[#sets + 1] = { id = "combat", name = "Combat", help = when .. ((combatFirst or #forms == 0) and KEEPS_COMBAT or KEEPS_COMBAT_FORM) }
    end
    for _, form in ipairs(forms) do
        -- (the set of Prowl is used in Cat Form while the druid prowls)
        sets[#sets + 1] = { id = form.id, name = form.name,
            help = "Used in " .. form.name .. "." .. (form.base and KEEPS_CAT or KEEPS) .. (combat ~= "Off" and (combatFirst and COMBAT_WINS or FORM_WINS) or "") }
    end
    return {
        left = layout.left, right = layout.right, layout = layout, style = style, sets = sets, places = Draw.Places(layout, #sets),
        combatFirst = combatFirst,
        holds = ns.BindRules.Holds(get("layers.hold_lb_rb_set")),
        interact = get("combat.dynamic_interact"),
        sticks = get("layers.sticky_layers") and Shape.Sticks or nil,
    }
end
