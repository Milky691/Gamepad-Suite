-- The two rows of tabs of the binds page: the sets over the layers. Part of BindsDraw.lua, which
-- gives it the page's frame and the page's mouse actions, and holds no state of the page.
local _, ns = ...

local Theme = ns.Theme
local px = Theme.px

-- ROWS: where each row is, in the mockup's units from the page's top. HEIGHT: a tab's height.
local Tabs = { ROWS = { sets = { y = 0, tabs = {} }, layers = { y = 44, tabs = {} } }, HEIGHT = 36 }
ns.SettingsBindsTabs = Tabs

local body, actions, width

-- parent: the page's own frame; handlers: the page's SelectSet(index) and SelectLayer(index);
-- pageWidth: the page's width in the mockup's units.
function Tabs.Build(parent, handlers, pageWidth)
    body, actions, width = parent, handlers, pageWidth
    for _, which in ipairs({ "sets", "layers" }) do
        local row = Tabs.ROWS[which]
        for _, side in ipairs({ "less", "more" }) do
            local arrow = body:CreateTexture(nil, "OVERLAY")
            arrow:SetTexture(side == "less" and "Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Up" or "Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up")
            arrow:SetSize(px(26), px(26))
            row[side] = arrow
        end
    end
end

local function tabFrame(row, which, index)
    local tab = row.tabs[index]
    if tab then
        return tab
    end
    tab = CreateFrame("Frame", nil, body)
    tab.outline = tab:CreateTexture(nil, "BACKGROUND", nil, -1)
    tab.outline:SetColorTexture(Theme.Color("gold"))
    tab.outline:SetPoint("TOPLEFT", -px(2), px(2))
    tab.outline:SetPoint("BOTTOMRIGHT", px(2), -px(2))
    tab.plate = Theme.Fill(tab, "BACKGROUND", 1, 1, 1, 1)
    tab.plate:SetAllPoints()
    tab.text = Theme.Text(tab, "row", "muted")
    tab.text:SetPoint("CENTER")
    tab:EnableMouse(true)
    tab:SetScript("OnMouseUp", function()
        actions[which == "sets" and "SelectSet" or "SelectLayer"](index)
    end)
    row.tabs[index] = tab
    return tab
end

-- One row of tabs, centred. The selected tab is gold. A row that has the focus shows an outline
-- on its selected tab and an arrow at each end where the selection can move. Gives the selected tab.
function Tabs.Draw(which, names, selected, focused)
    local row = Tabs.ROWS[which]
    local gaps, words = (#names - 1) * px(12), 0
    for i, name in ipairs(names) do
        tabFrame(row, which, i).text:SetText(name)
        words = words + row.tabs[i].text:GetStringWidth()
    end
    -- a class with many forms: the tabs get narrower, so the row and its arrows stay on the page
    local room = math.max(px(12), math.min(px(40), (px(width - 100) - words - gaps) / math.max(#names, 1)))
    local total = gaps
    for i = 1, #names do
        local tab = row.tabs[i]
        tab:SetSize(tab.text:GetStringWidth() + room, px(Tabs.HEIGHT))
        total = total + tab:GetWidth()
    end
    local x = -total / 2
    for i, tab in ipairs(row.tabs) do
        tab:SetShown(i <= #names)
        if i <= #names then
            tab:ClearAllPoints()
            tab:SetPoint("TOPLEFT", body, "TOP", x, -px(row.y))
            x = x + tab:GetWidth() + px(12)
            if i == selected then
                tab.plate:SetGradient("VERTICAL", CreateColor(0.79, 0.61, 0.25, 1), CreateColor(0.96, 0.84, 0.48, 1))
                tab.text:SetTextColor(0.11, 0.07, 0.02)
                tab.text:SetShadowOffset(0, 0)
            else
                tab.plate:SetGradient("VERTICAL", CreateColor(0, 0, 0, 0.35), CreateColor(0, 0, 0, 0.35))
                tab.text:SetTextColor(Theme.Color("muted"))
                tab.text:SetShadowOffset(1, -1)
            end
            tab.outline:SetShown(focused and i == selected)
        end
    end
    row.less:SetShown(focused and selected > 1)
    row.more:SetShown(focused and selected < #names)
    if #names > 0 then
        row.less:ClearAllPoints()
        row.less:SetPoint("RIGHT", row.tabs[1], "LEFT", -px(16), 0)
        row.more:ClearAllPoints()
        row.more:SetPoint("LEFT", row.tabs[#names], "RIGHT", px(16), 0)
    end
    return row.tabs[selected]
end
