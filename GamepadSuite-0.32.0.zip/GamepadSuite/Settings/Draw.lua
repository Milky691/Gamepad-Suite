-- Drawing the settings window from its state: the rows, the page, the legend. The strip of tabs
-- is laid out in Frames.lua.
local _, ns = ...

local Theme, Widgets, Model, Registry = ns.Theme, ns.Widgets, ns.SettingsModel, ns.Registry
local px = Theme.px

local Draw = { ui = {} }
ns.SettingsDraw = Draw
local ui = Draw.ui
local win, state

-- Called once the window is built.
function Draw.Bind(newWin, newState)
    win, state = newWin, newState
end

-- ---------------------------------------------------------------- small helpers

local function fadeIn(frame, duration, delay)
    if not frame.fade then
        frame.fade = frame:CreateAnimationGroup()
        frame.fade:SetToFinalAlpha(true)
        frame.fadeAlpha = frame.fade:CreateAnimation("Alpha")
        frame.fadeAlpha:SetFromAlpha(0)
        frame.fadeAlpha:SetToAlpha(1)
        frame.fadeAlpha:SetSmoothing("OUT")
    end
    frame.fade:Stop()
    frame.fadeAlpha:SetDuration(duration)
    frame.fadeAlpha:SetStartDelay(delay or 0)
    frame:SetAlpha(0)
    frame.fade:Play()
end

local function noFade(frame)
    if frame.fade then
        frame.fade:Stop()
    end
    frame:SetAlpha(1)
end

local function valueOf(row)
    if row.kind == "toggle" or row.kind == "pick" or row.kind == "slide" then
        return Registry.Get(row.key)
    end
    return nil
end

-- ---------------------------------------------------------------- drawing the state

local MOVE = { { keys = { "DPAD" }, text = "Move" } }

-- The page that takes the whole body in place of the rows and the parchment, and its frame: the
-- binds page, My Wheels, Profiles or Slot Binds. nil on every other page.
function Draw.Special()
    local page = Model.Page(state)
    if page.binds and ui.binds then
        return ns.SettingsBinds, ui.binds
    elseif page.wheels and ui.wheels then
        return ns.SettingsWheels, ui.wheels
    elseif page.profiles and ui.profiles then
        return ns.SettingsProfiles, ui.profiles
    elseif page.slots and ui.slots then
        return ns.SettingsSlots, ui.slots
    end
end

-- The legend (Widgets.Legend, the strip of every part): the page's buttons at the left, the row's at the right.
local function drawLegend()
    local page, row = Model.Page(state), Model.Row(state)
    local left, right = {}, {}
    -- on the binds page and on My Wheels the words follow the focus; a button with no word does nothing there
    local special = Draw.Special()
    -- (the search line's text box for a real keyboard has words of its own while it is open)
    local words = special and special.Words() or page.search and ns.SettingsSearch.Words() or nil
    if words and words.typing then
        left = {} -- the player types: the game's keyboard has the other buttons
    elseif words and words.list then
        left[1] = { keys = { "LB", "RB" }, text = words.list }
    elseif not page.guide then
        left[1] = { keys = { "LB", "RB" }, text = "Tab" }
    end
    if words then
        if page.binds and not words.list then
            left[#left + 1] = { keys = { "LT", "RT" }, text = "Layer" }
        end
        -- words.pad: what the D-pad does when up / down and left / right do two things
        for _, entry in ipairs(words.pad or MOVE) do
            left[#left + 1] = entry
        end
        if words.change then
            right[#right + 1] = { keys = { "DL", "DR" }, text = words.change }
        end
        for _, key in ipairs({ "A", "X", "Y", "B" }) do
            local word = words[key:lower()]
            -- (a tab a search result went to: B goes back to the results, Model.Back)
            if word == "Close" and Model.Returns(state) then
                word = "Back"
            end
            if word then
                right[#right + 1] = { keys = { key }, text = word }
            end
        end
    else
        left[#left + 1] = MOVE[1]
        local word = Model.ActionWord(row, row and valueOf(row), state)
        if word then
            right[#right + 1] = { keys = { "A" }, text = word }
        end
        if row and (row.kind == "toggle" or row.kind == "pick" or row.kind == "slide") then
            right[#right + 1] = { keys = { "DL", "DR" }, text = "Change" }
        end
        right[#right + 1] = { keys = { "B" }, text = (#state.stack > 0 or Model.Returns(state)) and "Back" or "Close" }
    end
    -- the tab strip is dim while LB and RB do not change the tab: a text box or a list is open
    local strip = words and (words.typing or words.list) and 0.4 or 1
    ui.chapterLB:SetAlpha(strip)
    ui.chapterRB:SetAlpha(strip)
    for _, text in ipairs(ui.chapterTexts) do
        text:SetAlpha(strip)
    end
    ui.legendLeft.Set(left)
    ui.legendRight.Set(right)
end

local function drawRows(animate)
    local page, rows = Model.Page(state), Model.Rows(state)
    ui.title:SetText(page.title or page.id or "")
    ui.line:SetText(page.guide and ("Step " .. state.row .. " of " .. #rows .. ".") or page.line or "")
    for i, frame in ipairs(ui.rows) do
        local row = rows[i]
        frame:SetShown(row ~= nil)
        if row then
            local focused = i == state.row
            local value, nav = valueOf(row), Model.Nav(row)
            frame.name:SetText(row.name)
            frame.sum:SetText(row.sum or "")
            frame.where:SetText(row.where or "")
            frame.value:SetText(Model.ValueText(row, value))
            if row.kind == "toggle" then
                frame.value:SetTextColor(Theme.Color(value and "gold" or "dim"))
            else
                frame.value:SetTextColor(Theme.Color("cream"))
            end
            frame.light:SetShown(focused)
            frame.bar:SetShown(focused)
            -- a row that goes to another page has a gold name and a gold arrow, so it does not read as a setting
            frame.nav:Set(nav)
            frame.name:SetTextColor(Theme.Color(row.soon and "dim" or nav and "gold" or focused and "white" or "cream"))
            if row.soon then
                frame.value:SetTextColor(Theme.Color("dim"))
            end
            local sides = row.kind == "pick" or row.kind == "slide"
            frame.sides.left:SetShown(sides)
            frame.sides.right:SetShown(sides)
            frame.less:SetAlpha(focused and sides and 1 or 0)
            frame.more:SetAlpha(focused and sides and 1 or 0)
            frame.endLine:SetShown(i == #rows)
            frame.hold:Hide()
            if animate then
                fadeIn(frame, 0.19, (i - 1) * 0.034)
            else
                noFade(frame)
            end
        end
    end
end

local demoTicker
function Draw.StopDemo()
    if demoTicker then
        demoTicker:Cancel()
        demoTicker = nil
    end
end

local function drawPage()
    Draw.StopDemo()
    local row = Model.Row(state)
    ui.stage:SetShown(row ~= nil)
    if not row then
        return
    end
    ui.pageTitle:SetText(row.name)
    ui.pageText:SetText(row.text or row.sum or "")

    local styleName = Widgets.PadStyle()
    local deck = styleName == "deck"
    local steps = row.steps or {}
    local pad = ui.pad
    -- the controller shows only on a page where a step presses a button; any other page shows its steps alone
    local pressing = false
    for _, step in ipairs(steps) do
        pressing = pressing or #step.keys > 0
    end
    pad:SetShown(pressing)
    pad:ClearAllPoints()
    if deck then
        -- the handheld is wide: it takes the page width, and the steps sit on its screen
        pad:SetStyle("deck", ui.page:GetWidth())
        pad:SetPoint("BOTTOM", ui.page, "BOTTOM", 0, px(52))
    else
        pad:SetStyle(styleName, px(350))
        pad:SetPoint("BOTTOMLEFT", ui.page, "BOTTOMLEFT", 0, px(58))
    end
    for i, step in ipairs(ui.steps) do
        local data = steps[i]
        step:SetShown(data ~= nil)
        if data then
            step.text:SetText(data.text)
            step:ClearAllPoints()
            if not pressing then
                step:SetParent(ui.page)
                step.text:SetWidth(px(480))
                step:SetPoint("TOPLEFT", ui.pageText, "BOTTOMLEFT", 0, -px(34) - (i - 1) * px(46))
            elseif deck then
                step:SetParent(pad)
                step.text:SetWidth(pad:GetWidth() * 0.34)
                step:SetPoint("TOPLEFT", pad, "TOPLEFT", pad:GetWidth() * 0.31, -pad:GetHeight() * 0.22 - (i - 1) * px(40))
            else
                step:SetParent(ui.page)
                step.text:SetWidth(px(150))
                step:SetPoint("TOPLEFT", pad, "TOPRIGHT", px(22), -px(40) - (i - 1) * px(50))
            end
        end
    end

    local facts = {}
    for _, fact in ipairs(row.facts or {}) do
        facts[#facts + 1] = fact[1] .. "  " .. fact[2]
    end
    ui.facts:SetText(table.concat(facts, "        "))

    local at = 0
    local function show()
        at = at % math.max(#steps, 1) + 1
        local data = steps[at]
        pad:SetLit(data and data.keys or {})
        for i, step in ipairs(ui.steps) do
            local now = i == at
            local dark = not deck or not pressing
            if now then
                step.dot:SetVertexColor(Theme.Color(dark and "inkRed" or "gold"))
                step.number:SetTextColor(Theme.Color(dark and "cream" or "ink"))
                step.text:SetTextColor(Theme.Color(dark and "ink" or "white"))
            else
                step.dot:SetVertexColor(Theme.Color(dark and "ink" or "muted", 0.25))
                step.number:SetTextColor(Theme.Color(dark and "ink" or "cream", 0.8))
                step.text:SetTextColor(Theme.Color(dark and "ink" or "muted", dark and 0.66 or 1))
            end
        end
    end
    show()
    if #steps > 1 then
        -- the demo steps by itself; the ticker stops when the row changes or the window hides
        demoTicker = C_Timer.NewTicker(1.5, show)
    end
    fadeIn(ui.page, 0.14)
end

function Draw.All(animate)
    local special, shown = Draw.Special()
    ui.list:SetShown(not special)
    ui.stage:SetShown(not special)
    for _, name in ipairs({ "binds", "wheels", "profiles", "slots" }) do
        if ui[name] then
            ui[name]:SetShown(ui[name] == shown)
        end
    end
    ns.SettingsFrames.Tabs(ui, win, state)
    if special then
        Draw.StopDemo()
        special.Draw()
    else
        drawRows(animate)
        drawPage()
    end
    drawLegend()
end

function Draw.Values()
    drawRows(false)
    drawLegend()
end

Draw.FadeIn, Draw.Rows, Draw.Page, Draw.Legend = fadeIn, drawRows, drawPage, drawLegend
