-- The rules of the Profiles page, with no game calls: the lines of its list, where the focus
-- goes, what A and X do on a line, and the words the page and the legend show.
-- The list: this character's builds and New Build (decision 79: what a player comes for stands
-- first), a line for each profile (the builds of the other characters, saved copies, imported
-- texts), Export as Text, Import from Text, Undo Last Profile after a load or a switch, and Back. A
-- profile or another build takes the place of this character's binds and wheels, so A is held for
-- it, as for Reset All Settings. The words of the builds' lines are Settings/BuildPageModel.lua's.
-- As a tab of the window the page has no page to go back to: it has no Back line then, and B
-- closes the window, as on every tab.
local _, ns = ...

local Model = {}

-- The list has room for ROOM lines; the profiles have what the other lines leave, ROWS at most.
-- With more profiles than that it shows them in pages, as the list of binds does: "Next" is the
-- last of their lines on every page but the last, and "Previous" the first on every page but the
-- first. A on one of them shows that page, and the focus stays on that line while the new page has
-- it. A move never changes the page.
Model.ROWS, Model.ROOM, Model.LEAST = 6, 11, 3
-- the lines that stand in the profiles' room: a profile, or one of the two that lead to another page
local IN_PAGE = { profile = true, next = true, previous = true }

-- The lead of each line that is no profile; %s is this character's name (for Export as Text the
-- name of its build in use).
local LEAD = {
    export = "Shows the build in use, %s, as one text: its binds, wheels and your settings. Another player with Gamepad Suite can import it. You need a keyboard to copy the text.",
    import = "Takes a text that another player exported, and puts it in the list as a profile. Nothing changes until you use it. You need a keyboard to paste the text.",
    undo = "Puts %s's binds and wheels back as they were before the last load or switch of builds. Settings that it changed go back too.",
    back = "Goes back to the page you came from. B does the same.",
    -- (for these two the numbers are the page in view and how many pages the list has)
    next = "Shows the next profiles of the list. This is page %d of %d.",
    previous = "Shows the profiles before these. This is page %d of %d.",
}
local STEPS = {
    export = { "Press A to show the text", "Click it, then press Ctrl+A and Ctrl+C", "Send the text to the other player" },
    import = { "Copy the text the other player sent", "Press A, click the box, then press Ctrl+V", "Find the profile in the list, marked Imported" },
    profile = { "Hold A until the bar is full", "To get the old binds back, use Undo Last Profile" },
    undo = { "Press A to undo" },
}
-- What the page says after an action, by the name the page gives it.
Model.NOTE = {
    full = "The list is full. Remove a profile first.",
    removeBuild = "Press X again to remove it. It cannot be put back.",
    taken = "Another build has this name.",
    export = "Click the text, then press Ctrl+A and Ctrl+C to copy it.",
    noText = "This game build cannot make or read the text.",
    removeChar = "Press X again to remove it. It comes back when you play that character.",
    removeCopy = "Press X again to remove it. It cannot be put back.",
    import = "Click the box and paste the text with Ctrl+V.",
    wrong = "This text is not a Gamepad Suite profile.",
    cut = "The text is not whole. Copy it again, from GPS1: to its end.",
    fight = "You cannot change binds in combat.",
    undone = "Done: the old binds and wheels are back.",
}
-- (A on Export as Text and on Import from Text opens the text box: the copy and the paste are the keyboard's)
local WORD = { export = "Show text", import = "Open text box", undo = "Undo", back = "Back", next = "Next", previous = "Previous" }

-- State: the line in focus, counted in the lines of the page in view, and that page's number.
function Model.New()
    return { line = 1, page = 1 }
end

-- The pages of `count` profiles in `rows` lines: each { first = its first profile, count = how many
-- it shows, lead = true when Previous has its first line }. A line that leads to another page takes
-- one of the rows, so a page with one shows that many fewer profiles.
local function pages(count, rows)
    local all, first = {}, 1
    repeat
        local lead = first > 1
        local room = rows - (lead and 1 or 0)
        if count - first + 1 > room then
            room = room - 1
        end
        all[#all + 1] = { first = first, count = math.min(room, count - first + 1), lead = lead }
        first = first + room
    until first > count
    return all
end

-- The lines of the list with page `page` of the profiles in view (a page the list does not have
-- gives its nearest one). list is Core/Profiles.lua List(); className gives the game's word for a
-- class; tab is true when the page is a tab of the window; builds are this character's builds,
-- { { name, use = true for the one in use }, more = true when there is room for one more }. The
-- lines also say which page they show (page), how many pages there are (pages), how many profiles
-- (count), how many lines stand above them (own) and how many lines a page of them has (rows).
-- Each line has a key that stays the same at each read: Model.Fit puts the focus back by it. The
-- build in use opens a page: it has way "next", the arrow of a control that opens one (decision 79).
function Model.Lines(list, canUndo, className, tab, page, builds)
    local lines = {}
    for at, build in ipairs(builds or {}) do
        lines[at] = { kind = "build", key = "build" .. at, build = at, name = build.name, right = build.use and "In use, saved" or "", use = build.use or false,
            way = build.use and "next" or nil }
    end
    if builds and builds.more then
        lines[#lines + 1] = { kind = "new", key = "new", name = "New Build" }
    end
    local own = #lines
    local rows = math.max(Model.LEAST, math.min(Model.ROWS, Model.ROOM - own - 2 - (canUndo and 1 or 0) - (tab and 0 or 2)))
    local all = pages(#list, rows)
    page = math.max(1, math.min(page or 1, #all))
    if all[page].lead then
        lines[#lines + 1] = { kind = "previous", name = "Previous" }
    end
    for at = all[page].first, all[page].first + all[page].count - 1 do
        local entry = list[at]
        -- at: the profile's place in the whole list
        local line = { kind = "profile", at = at, key = at, entry = entry, name = entry.profile.name or "Profile", right = "" }
        if entry.kind == "char" or entry.kind == "build" then
            line.class, line.right = entry.profile.class, entry.profile.class and className(entry.profile.class) or ""
        else
            line.right = entry.kind == "copy" and "Saved" or "Imported"
        end
        lines[#lines + 1] = line
    end
    if page < #all then
        lines[#lines + 1] = { kind = "next", name = "Next" }
    end
    lines[#lines + 1] = { kind = "export", name = "Export as Text" }
    lines[#lines + 1] = { kind = "import", name = "Import from Text" }
    if canUndo then
        lines[#lines + 1] = { kind = "undo", name = "Undo Last Profile" }
    end
    if not tab then
        lines[#lines + 1] = { kind = "back", name = "Back" }
    end
    for _, line in ipairs(lines) do
        line.key = line.key or line.kind
    end
    lines.page, lines.pages, lines.count, lines.own, lines.rows = page, #all, #list, own, rows
    return lines
end

-- After the lines were made again: the focus is on a line of them. After A on Next or Previous it
-- is on that line again when the new page has it, so each more page is one more press of A; else
-- on the page's first profile. After a paste it is on the new profile (Model.Show); after New Build
-- on the new build. state.want is the key of the line wanted.
function Model.Fit(state, lines)
    local want, first = state.want, nil
    state.page, state.want = lines.page, nil
    for index, line in ipairs(lines) do
        if want and line.key == want then
            state.line = index
            return
        end
        first = first or (line.kind == "profile" and index) or nil
    end
    state.line = math.max(1, math.min(want and first or state.line, #lines))
end

-- Puts profile `at` of `count` in view, with the focus on it: the page makes its lines again
-- with state.page, and Model.Fit puts the focus. rows: the lines a page of profiles has (lines.rows).
function Model.Show(state, count, at, rows)
    for number, page in ipairs(pages(count, rows or Model.ROWS)) do
        if at >= page.first and at < page.first + page.count then
            state.page, state.want = number, at
        end
    end
end

-- The list as it shows: { { line =, index = its place in lines, gap = true for more room above
-- it } }; an entry with note in place of line is plain text. There is more room above the lines
-- of the profiles and above the line after them.
function Model.Shown(lines)
    local out, before = {}, false
    for index, line in ipairs(lines) do
        -- with no profile yet, a plain line says so; it cannot have the focus
        if index == lines.own + 1 and lines.count == 0 then
            out[#out + 1] = { note = "No other character has used Gamepad Suite yet.", gap = index > 1 }
            before = true
        end
        local inPage = IN_PAGE[line.kind] or false
        out[#out + 1] = { line = line, index = index, gap = (index == lines.own + 1 and index > 1 and lines.count > 0) or (before and not inPage) }
        before = inPage
    end
    return out
end

-- D-pad up or down; the list wraps at its ends, as every list of the window. A new line in focus
-- takes the last note with it, and ends a hold of A.
function Model.Move(state, lines, step)
    local to = (state.line + step - 1) % #lines + 1
    if to == state.line or state.box then
        return false
    end
    state.line, state.note, state.used, state.hold, state.armed = to, nil, nil, nil, nil
    Model.Fit(state, lines)
    return true
end

-- What A does on the line in focus: "new", "export", "import", "undo", "back"; "open" on the
-- build in use (its page opens); on Next or Previous "turn" (the page then makes its lines again,
-- for the page before or after); on another build or a profile "hold" (the press starts the hold;
-- Model.Held is its end). comes is what of the profile this character can take; with nothing to
-- take, A does nothing.
function Model.Press(state, lines, comes)
    local line = lines[state.line]
    state.hold, state.armed = nil, nil
    if line.kind == "next" or line.kind == "previous" then
        state.page, state.want = state.page + (line.kind == "next" and 1 or -1), line.kind
        state.note, state.used = nil, nil
        return "turn"
    elseif line.kind == "build" then
        if line.use then
            return "open"
        end
        state.hold = line.key
        return "hold"
    elseif line.kind ~= "profile" then
        return line.kind
    elseif comes and comes.binds + comes.wheels > 0 and not state.used then
        -- the profile the hold is for: the hold counts only while this one keeps the focus
        state.hold = line.entry.profile
        return "hold"
    end
    return nil
end

-- A was held to the end: "use", when the profile the hold started on still has the focus;
-- "switch" when it is the build the hold started on.
function Model.Held(state, lines)
    local line, held = lines[state.line], state.hold
    state.hold = nil
    if held == nil then
        return nil
    elseif line.kind == "profile" and line.entry.profile == held then
        return "use"
    end
    return line.kind == "build" and line.key == held and not line.use and "switch" or nil
end

-- What X does on a profile or on a build that is not in use: "arm" at the first press (the page
-- then asks for a second one), "remove" at the second. A saved copy, an imported profile or a build
-- has no way back, and X is next to A. Nothing on any other line.
function Model.Clear(state, lines)
    local line = lines[state.line]
    state.hold = nil
    local what = line.kind == "profile" and line.entry.profile or (line.kind == "build" and not line.use and line.key) or nil
    if not what then
        return nil
    elseif state.armed == what then
        state.armed, state.note, state.used = nil, nil, nil
        return "remove"
    end
    local kind = line.kind == "profile" and line.entry.kind
    state.armed, state.note = what, (not kind and "removeBuild") or ((kind == "char" or kind == "build") and "removeChar") or "removeCopy"
    return "arm"
end

local function count(n, word)
    return n .. " " .. word .. (n == 1 and "" or "s")
end

-- "35 binds and 2 wheels", "1 bind", or nil for nothing.
local function amount(comes)
    local parts = {}
    if comes.binds > 0 then
        parts[#parts + 1] = count(comes.binds, "bind")
    end
    if comes.wheels > 0 then
        parts[#parts + 1] = count(comes.wheels, "wheel")
    end
    return #parts > 0 and table.concat(parts, " and ") or nil
end

-- What a hold would take from My Wheels and the fixed slots, by place (Core/ProfileRules.lua Fit):
-- " Wheel 1 loses 5 entries. Totems is left out. Slots 2 and 6 are left empty." ("" for none).
local function places(comes)
    local out = ""
    for _, one in ipairs(comes.wheelsCut or {}) do
        out = out .. " " .. one.name .. (one.all and " is left out." or (" loses " .. one.count .. (one.count == 1 and " entry." or " entries.")))
    end
    local slots = comes.slotsCut or {}
    if #slots > 0 then
        out = out .. (#slots == 1 and (" Slot " .. slots[1] .. " is")
            or (" Slots " .. table.concat(slots, ", ", 1, #slots - 1) .. " and " .. slots[#slots] .. " are")) .. " left empty."
    end
    return out
end

-- What the parchment shows for the line in focus:
--   { head =, text = the lead, steps = { text }, facts = { { label, value } }, note = }.
-- look is Core/Profiles.lua Look() of the profile in focus; me is this character's name; into is
-- the name of its build in use, which a profile goes into.
function Model.Panel(state, lines, look, me, into)
    local line = lines[state.line]
    local panel = { head = line.name, steps = STEPS[line.kind] or {}, facts = {}, note = state.note and (Model.NOTE[state.note] or state.note) }
    if line.kind == "next" or line.kind == "previous" then
        panel.text = LEAD[line.kind]:format(lines.page, lines.pages)
        return panel
    elseif line.kind ~= "profile" then
        panel.text = LEAD[line.kind]:format(line.kind == "export" and into or me or "")
        return panel
    end
    local comes, kind = look.comes, line.entry.kind
    local some = amount(comes)
    if state.used then
        -- the profile was used just now: the page says so, the spells to bind again, and how to go back to the old binds
        local lost = #(state.used.lost or {})
        panel.text = "Done: " .. (into or me) .. " now has " .. (amount(state.used) or "nothing") .. " from this profile."
            .. (lost > 0 and (" " .. count(lost, "spell") .. " to bind again: the Binds page shows where.") or "") .. " To get the old binds and wheels back, use Undo Last Profile."
        panel.steps = {}
    elseif some then
        -- the profile goes into the build in use; a spell left out keeps a marker on the Binds page. Another
        -- character's build brings its role switches too: they show in the place of the steps
        -- (Settings/ProfilesPage.lua), so its lead says how to go back. A text has its writer's settings.
        local lost, cut = #(comes.lost or {}), comes.cut
        panel.text = "Hold A to use this " .. (kind == "build" and "build. Its binds, wheels and the settings below" or "profile. Its binds and wheels")
            .. (look.settings and ", and every setting in this window," or "") .. " take the place of " .. (into and ("the ones in " .. into .. ", the build in use") or (me .. "'s"))
            .. ". " .. me .. " gets " .. some .. "."
        if cut > 0 and lost == 0 then
            panel.text = panel.text .. " " .. count(cut, "bind") .. (cut == 1 and " is left out, because " .. me .. " cannot use it." or " are left out, because " .. me .. " cannot use them.")
        elseif cut > 0 then
            panel.text = panel.text .. " " .. (lost == cut and (count(lost, "spell") .. (lost == 1 and " is" or " are") .. " left out")
                or (count(cut, "bind") .. " are left out, " .. lost .. " of them " .. (lost == 1 and "a spell" or "spells"))) .. ": the Binds page shows where."
        end
        panel.text = panel.text .. places(comes)
        if kind == "build" then
            panel.text = panel.text .. " Undo Last Profile gives the old binds back."
        end
    else
        panel.text, panel.steps = me .. " cannot use any bind of this profile.", {}
    end
    if kind == "char" or kind == "build" then
        panel.facts = { { "Class", look.className or "Not in this game" }, { "Last played", look.day } }
    else
        panel.facts = { { kind == "copy" and "Saved" or "Imported", look.day } }
    end
    panel.facts[#panel.facts + 1] = { "Binds", look.binds }
    panel.facts[#panel.facts + 1] = { "Wheels", look.wheels }
    if look.settings then
        panel.facts[#panel.facts + 1] = { "Settings", "Included" }
    end
    return panel
end

-- The legend's words for A, X and B. While a text box is open the keyboard has the other buttons.
-- tab is true when the page is a tab of the window: B closes the window there.
function Model.Words(state, lines, comes, tab)
    if state.box then
        return { typing = true, b = "Close", pad = {} }
    end
    local line, back = lines[state.line], tab and "Close" or "Back"
    if line.kind ~= "profile" then
        return { a = WORD[line.kind], b = back }
    end
    local can = comes and comes.binds + comes.wheels > 0 and not state.used
    return { a = can and "Hold to use" or nil, x = state.armed and "Remove now" or "Remove from list", b = back }
end

if ns then
    ns.SettingsProfilesModel = Model
end
return Model
