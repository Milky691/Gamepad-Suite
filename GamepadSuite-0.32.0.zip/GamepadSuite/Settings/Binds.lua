-- The binds page of the settings window: what each button does on it. The rules are in
-- BindsModel.lua, the frames in BindsDraw.lua, the binds in the store (Core/Binds.lua).
-- A on a slot with no bind of its own opens the list to choose one (Picker.lua), which takes the
-- page's place while it is open. The bind core (Core/BindCore.lua) puts each bind on its key.
-- What the page offers and the names of binds are in BindsShape.lua.
-- The list marks each entry that is on a button already with where. Before an entry takes a slot
-- with a bind of the player's, the Replace box asks (not for the game's own job: it comes back when
-- the bind is cleared); after the change the card says what happened, until the next button
-- (Settings/BindsWhere.lua has the words).
local _, ns = ...

local Model, Store, Picker, Draw, Nav, Where = ns.BindsModel, ns.Binds, ns.SettingsPicker, ns.SettingsBindsDraw, ns.SettingsNav, ns.BindsWhere
local describe, currentShape = ns.SettingsBindsShape.Describe, ns.SettingsBindsShape.Now

local Binds = {}
ns.SettingsBinds = Binds

local page, body
local state = Model.New()
local shape -- what the page offers now, made again at each draw
-- base: the set that a set keeps its binds from before Normal (Prowl keeps Cat Form's)
-- (set: a change by the player's hand, which Undo Last Bind can take back)
-- game: the game's own job of a slot with no bind of ours (Core/AdapterBindList.lua)
-- was: the spell a slot had before a load took it away (Core/Builds.lua)
local binds = { get = Store.Get, set = Store.Change, base = function(set)
    for _, form in ipairs(ns.Adapter.Forms()) do
        if form.id == set then
            return form.base
        end
    end
end, game = function(layer, key) return ns.Adapter.GameJob(key, layer) end,
was = function(set, layer, key) return ns.Builds and ns.Builds.on and ns.Builds.Was(set, layer, key) or nil end }
local target -- the slot the list was opened for: { set = , layer = , key = }
local asking -- quick bind: the entry of the list that waits for the player to press its button
local replacing -- the Replace box is up: the change that A makes
local said -- the card's line after a change, until the next button
local heard = { count = 0 } -- the game's names of buttons quick bind did not know, already in the log

-- The bind that an entry of the list becomes.
local function bindOf(entry)
    return { kind = entry.kind, id = entry.id, name = entry.name, icon = entry.icon, detail = entry.detail }
end

function Binds.Draw()
    shape = currentShape()
    Model.Fit(state, shape)
    Draw.Page(state, shape, binds, describe, said)
end

-- After an action on this page: draw it again, and the legend, because its words follow the focus.
local function redraw(sound)
    ns.Adapter.Sound(sound)
    if not Picker.IsOpen() then
        Binds.Draw()
    end
    ns.SettingsDraw.Legend()
end

-- The list closes and the page shows again.
local function closeList()
    Picker.Close()
    body:Show()
    redraw("IG_MAINMENU_OPTION")
end

-- True while the list to choose a bind is open.
function Binds.ListOpen()
    return Picker.IsOpen()
end

-- A set's name as its tab shows it.
local function setName(id)
    for _, set in ipairs(shape.sets) do
        if set.id == id then
            return set.name
        end
    end
    return id
end

-- The slot in the words of the change: "RT + A", with " in Combat" in a set other than Normal.
local function slotWords(set, layer, key)
    return Where.At({ set = set, layer = layer, key = key }, "normal", Draw.SlotName, setName)
end

-- The marks of the list: where each entry is bound, in the sets and the layers the page has now.
-- Read from the store when the list opens; the list closes after each change.
local function marks()
    local sets, keys, layers = {}, {}, {}
    for i, set in ipairs(shape.sets) do
        sets[i] = set.id
    end
    for _, column in ipairs({ shape.left, shape.right }) do
        for _, key in ipairs(column) do
            keys[#keys + 1] = key
        end
    end
    for _, layer in ipairs(Model.Layers(state, shape)) do
        layers[layer] = true
    end
    local index = Where.Index(Store.Each, function(set, layer, key)
        return layers[layer] and Model.Status(binds, set, layer, key) == "own"
    end, sets, state.set, keys)
    return function(entry)
        return Where.Mark(index[Where.Key(entry)], state.set, Draw.SlotName, setName)
    end
end

-- What a slot did before an entry goes on it (BindsWhere.lua Ask), or nil for nothing.
local function before(entry, set, layer, key)
    local status, here, from = Model.Status(binds, set, layer, key)
    local job = (status == "own" or status == "inherited") and here or status == "empty" and binds.game(layer, key) or nil
    if not job then
        return nil
    end
    local how = Where.Key(job) == Where.Key(entry) and "same" or status == "own" and "own" or status == "inherited" and "kept" or "game"
    return { how = how, name = (describe(job)), from = from and setName(from) }
end

-- The Replace box goes; the list stays open as it was.
local function backOut()
    replacing = nil
    Draw.Ask(nil)
    redraw("IG_MAINMENU_OPTION")
end

-- An entry of the list goes on a slot: at once, or at A in the Replace box when the slot has a bind
-- of the player's to lose. done() runs after the change (quick bind puts the page's focus there). The list closes.
local function put(entry, set, layer, key, done)
    local was, slot, name = before(entry, set, layer, key), slotWords(set, layer, key), (describe(entry))
    local function change()
        replacing = nil
        Draw.Ask(nil)
        if not (was and was.how == "same") then
            Store.Begin()
            Store.Change(set, layer, key, bindOf(entry))
        end
        said = Where.Said(name, slot, was)
        if done then
            done()
        end
        closeList()
    end
    local title, line = Where.Ask(name, slot, was)
    if title then
        replacing = change
        Draw.Ask(title, line)
        redraw("IG_MAINMENU_OPTION")
    else
        change()
    end
end

-- The Replace box takes A and B alone: the window asks here first, and every other button does
-- nothing while the box is up. With no button given nothing is typed, so Enter and Escape of a
-- real keyboard come as A and B.
function Binds.Typing(what)
    if not (replacing and what) then
        return false
    elseif what == "A" then
        Binds.Press()
    elseif what == "B" then
        Binds.Back()
    end
    return true
end

-- D-pad: in the slots, in the rows of tabs, or in the list. On the page the focus goes to the
-- thing that lies that way (Settings/Nav.lua with the places of the page).
function Binds.Move(dy, dx)
    said = nil
    if asking or replacing then
        -- quick bind waits for a button: a D-pad press is the answer (the capture has it), not a move
        return
    elseif Picker.IsOpen() then
        if Picker.Move(dy, dx) then
            ns.Adapter.Sound("U_CHAT_SCROLL_BUTTON")
            ns.SettingsDraw.Legend()
        end
        return
    end
    local tabs = state.zone ~= "slots" and dx ~= 0
    if Model.Move(state, shape, dy, dx, Nav.Go(shape.places, Model.At(state), dx, dy)) then
        redraw(tabs and "IG_CHARACTER_INFO_TAB" or "U_CHAT_SCROLL_BUTTON")
    end
end

-- LT or RT: flip that layer on or off. Y: who the slot's spell or item is cast on. They do
-- nothing while the list is open.
function Binds.Layer(which)
    said = nil
    if Picker.IsOpen() then
        return
    elseif which == "Y" then
        Store.Begin()
        if Model.CastOn(state, shape, binds) then
            redraw("IG_MAINMENU_OPTION")
        end
    else
        Model.FlipLayer(state, which)
        redraw("IG_CHARACTER_INFO_TAB")
    end
end

-- LB or RB while the list is open: the list before or after.
function Binds.ChangeList(step)
    if asking or replacing then
        return
    end
    Picker.ChangeList(step)
    ns.Adapter.Sound("IG_CHARACTER_INFO_TAB")
    ns.SettingsDraw.Legend()
end

-- A: pick up, put down or swap. On a slot with no bind of its own: open the list. In a row of
-- tabs: go to the slots. In the list: act on a control (More, Next, Back, Previous), or put the
-- entry on the slot the list was opened for.
function Binds.Press()
    said = nil
    if replacing then
        replacing()
        return
    elseif asking then
        return
    elseif Picker.IsOpen() then
        local entry = Picker.Choose()
        if entry then
            put(entry, target.set, target.layer, target.key)
        else
            redraw("IG_MAINMENU_OPTION")
        end
        return
    end
    Store.Begin()
    local what = Model.Press(state, shape, binds)
    if what == "choose" then
        -- the slot is kept now, so the entry lands on it whatever happens while the list is open
        local set, layer, key = Model.Cell(state, shape)
        target = { set = set, layer = layer, key = key }
        -- the slot's tooltip goes before the list shows the one of its first entry
        ns.Adapter.HideTooltip()
        if Picker.Open(Draw.SlotName(layer, key), page, nil, marks()) then
            body:Hide()
            redraw("IG_MAINMENU_OPTION")
        end
    elseif what then
        redraw("IG_MAINMENU_OPTION")
    end
end

-- Quick bind. X on an entry of the list: the entry goes on the button that the player presses
-- next, on the layer of the trigger that is held then, in the set in view. B ends it.
local function pressed(button)
    local key = ns.Adapter.NAME[button]
    if button == ns.Adapter.KEY.B then
        asking = nil
        Picker.For(Draw.SlotName(target.layer, target.key))
        redraw("IG_MAINMENU_OPTION")
        return true
    end
    local at
    for i, name in ipairs(shape.left) do
        at = name == key and i or at
    end
    for i, name in ipairs(shape.right) do
        at = name == key and #shape.left + i or at
    end
    if not at then
        -- a trigger is the layer, and a button that is not on this page takes no bind here: the page waits on.
        -- A button the addon has no name for goes to the log, once each, five at most: on some setups the
        -- Xbox button reaches the game under another name, or not at all.
        if not key and not heard[button] and heard.count < 5 then
            heard[button], heard.count = true, heard.count + 1
            ns.Log.Add("binds", "Quick bind: the game sent a button the addon does not know: " .. tostring(button))
        end
        return false
    end
    local lt, rt = ns.Adapter.Held()
    local layer, entry = 1 + (lt and 1 or 0) + (rt and 2 or 0), asking
    asking = nil
    Picker.For(Draw.SlotName(target.layer, target.key))
    -- the page shows that slot after the change; B in the Replace box leaves the page as it was
    put(entry, state.set, layer, key, function()
        Model.ShowLayer(state, layer)
        state.zone, state.focus = "slots", at
    end)
    return true
end

-- X: clear the focused slot, make it empty in this set, or give it the Normal bind back. In the
-- list: quick bind for the entry in focus.
function Binds.Clear()
    said = nil
    if asking or replacing then
        return
    elseif Picker.IsOpen() then
        local entry = Picker.Entry()
        if entry then
            asking = entry
            Picker.For("the next button you press")
            ns.SettingsInput.Capture(pressed)
            redraw("IG_MAINMENU_OPTION")
        end
        return
    end
    Store.Begin()
    if Model.Clear(state, shape, binds) then
        redraw("IG_MAINMENU_OPTION")
    end
end

-- B: true when it went back in the list, closed the list, ended a carry or went from the slots
-- back to the rows of tabs, so the window stays open. In a row of tabs B closes the window.
function Binds.Back()
    said = nil
    if replacing then
        backOut()
        return true
    elseif asking then
        -- (B from the keyboard: the controller's B comes through the capture)
        ns.SettingsInput.Capture(nil)
        return pressed(ns.Adapter.KEY.B)
    elseif Picker.IsOpen() then
        if Picker.Back() then
            redraw("IG_MAINMENU_OPTION")
        else
            closeList()
        end
        return true
    elseif Model.Back(state) ~= "close" then
        redraw("IG_MAINMENU_OPTION")
        return true
    end
    return false
end

-- A tab change or a close of the window ends a carry and closes the list.
function Binds.Leave()
    asking, replacing, said = nil, nil, nil
    Draw.Ask(nil)
    ns.SettingsInput.Capture(nil)
    Model.Leave(state)
    ns.Adapter.HideTooltip()
    if Picker.IsOpen() then
        Picker.Close()
        body:Show()
    end
end

-- The legend words right now. With the list open: list names LB / RB, and A chooses or opens.
function Binds.Words()
    if replacing then
        -- the Replace box: A and B alone
        return { typing = true, a = "Replace", b = "Back", pad = {} }
    elseif asking then
        -- every button of the controller is an answer now, the D-pad too: no hint for it; B ends it
        return { typing = true, b = "Cancel", pad = {} }
    elseif Picker.IsOpen() then
        return { list = "List", a = Picker.Word(), x = Picker.Entry() and "Bind to a button" or nil, b = "Back" }
    end
    return Model.Words(state, shape, binds)
end

-- The mouse. A click on a tab shows that set or layer; hover on a slot gives it the focus.
local mouse = {
    SelectSet = function(index)
        said = nil
        state.set = shape.sets[index].id
        redraw("IG_CHARACTER_INFO_TAB")
    end,
    SelectLayer = function(index)
        said = nil
        Model.ShowLayer(state, Model.Layers(state, shape)[index])
        redraw("IG_CHARACTER_INFO_TAB")
    end,
    Focus = function(index)
        if state.zone ~= "slots" or state.focus ~= index then
            said = nil
            state.zone, state.focus = "slots", index
            redraw("U_CHAT_SCROLL_BUTTON")
        end
    end,
    Press = function() ns.SettingsInput.Click("A") end,
    Clear = function() ns.SettingsInput.Click("X") end,
}

function Binds.Build(win)
    page, body = Draw.Build(win, mouse)
    Picker.Build(page)
    Store.Fill()
    return page
end
