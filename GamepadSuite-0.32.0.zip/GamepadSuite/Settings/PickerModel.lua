-- The rules of the list where the player chooses a bind, with no game calls, so they can be
-- tested outside the game. The list is a set of named lists (spell tabs, items, macros, game
-- menus, emotes ...). One list is in view. It is drawn as pages of two columns of seven cells:
-- the entries run down the left column, then down the right.
-- A list with more entries than a page shows has two controls. They are cells of the page and
-- not binds: "Next" in the last cell (bottom right) of every page but the last, and "Previous" in
-- the first cell of every page but the first. A on one of them shows that page, and the focus
-- stays on that control while the new page has it. The focus never leaves the page by a move:
-- only A on Next or Previous, and the mouse wheel, change the page.
-- An entry of the kind "more" holds lists of its own. Opening it shows those lists in place of
-- the ones in view, and going back returns to where the player was.
local _, ns = ...

local PickerModel = { COLUMN = 7, PER_PAGE = 14 }

local NEXT, PREVIOUS = { kind = "next", name = "Next" }, { kind = "previous", name = "Previous" }
-- A cell that leads to other entries is a control, and no bind: which way its arrow points
-- (Look/Widgets.lua Nav).
local WAY = { more = "next", next = "next", back = "back", previous = "back" }

-- "next" or "back" for a control (More, Next, Back, Previous), nil for a bind.
function PickerModel.Control(entry)
    return entry and WAY[entry.kind]
end

-- A list with no entries is dropped.
local function withEntries(lists)
    local kept = {}
    for _, list in ipairs(lists) do
        if #list.entries > 0 then
            kept[#kept + 1] = list
        end
    end
    return kept
end

-- lists: { { name = , entries = { entry, ... } }, ... }.
-- openOn names the list to show first, if it is there.
-- index is the entry in focus. With control set ("next" or "previous") the focus is on that
-- control of the page that shows the entry.
function PickerModel.New(lists, openOn)
    local state = { lists = withEntries(lists), list = 1, index = 1, places = {}, parents = {} }
    for i, list in ipairs(state.lists) do
        if list.name == openOn then
            state.list = i
        end
    end
    return state
end

-- The list in view, or nil when there is nothing to choose.
function PickerModel.List(state)
    return state.lists[state.list]
end

-- The name of the top list the player is in or came from: the one to open on next time.
function PickerModel.TopName(state)
    local top = state.parents[1] or state
    return top.lists[top.list].name
end

-- The pages of the list in view, each { first = its first entry, count = how many entries it
-- shows, lead = 1 when Previous has its first cell }, and the number of the page in view.
-- A control takes a cell, so a page with one shows that many fewer entries.
local function pages(state)
    local count, all, first, at = #PickerModel.List(state).entries, {}, 1, 1
    repeat
        local lead = first > 1 and 1 or 0
        local cells = PickerModel.PER_PAGE - lead
        if count - first + 1 > cells then
            cells = cells - 1
        end
        all[#all + 1] = { first = first, count = math.min(cells, count - first + 1), lead = lead }
        if first <= state.index then
            at = #all
        end
        first = first + cells
    until first > count
    return all, at
end

-- The page in view: its cells in order (each an entry of the list, or the control Next or
-- Previous), the cell in focus, the page's number, and how many pages the list has.
function PickerModel.Cells(state)
    local entries = PickerModel.List(state).entries
    local all, at = pages(state)
    local page, cells = all[at], {}
    if page.lead == 1 then
        cells[1] = PREVIOUS
    end
    for i = page.first, page.first + page.count - 1 do
        cells[#cells + 1] = entries[i]
    end
    if at < #all then
        cells[#cells + 1] = NEXT
    end
    local focus = state.control == "previous" and 1 or state.control == "next" and #cells or state.index - page.first + 1 + page.lead
    return cells, focus, at, #all
end

-- What has the focus: an entry of the list, or the control Next or Previous.
function PickerModel.Entry(state)
    local list = PickerModel.List(state)
    if not list then
        return nil
    end
    local cells, focus = PickerModel.Cells(state)
    return cells[focus]
end

-- Puts the focus on a cell of the page in view. For the D-pad (the page finds the cell that lies
-- that way, Settings/Nav.lua) and for the mouse. Returns false when the focus did not move.
function PickerModel.FocusCell(state, cell)
    local cells, focus = PickerModel.Cells(state)
    local entry = cells[cell]
    if not entry or cell == focus then
        return false
    end
    local all, at = pages(state)
    state.control = (entry == NEXT or entry == PREVIOUS) and entry.kind or nil
    if not state.control then
        state.index = all[at].first + cell - 1 - all[at].lead
    end
    return true
end

-- Shows the page after or before the one in view. For A on Next or Previous, and for the mouse
-- wheel. A focus that is on Next or Previous stays on that control when the new page has it, so
-- each more page is one more press of A. Else the focus goes to the new page's first entry.
-- Returns false when there is no such page.
function PickerModel.TurnPage(state, step)
    local all, at = pages(state)
    local to = all[at + step]
    if not to then
        return false
    end
    state.index = to.first
    if (state.control == "next" and at + step == #all) or (state.control == "previous" and to.lead == 0) then
        state.control = nil
    end
    return true
end

-- The names for the strip over the list: the list in view, the one before it and the one after it.
function PickerModel.Names(state)
    local count = #state.lists
    local parent = state.parents[#state.parents]
    local function at(step)
        local to = state.list + step
        -- under a More entry, a step past either end leads back to the list the player came from
        if parent and (to < 1 or to > count) then
            return parent.lists[parent.list].name
        end
        return state.lists[(to - 1) % count + 1].name
    end
    return at(0), at(-1), at(1)
end

-- LB / RB. At the top the lists wrap. Under a More entry a step past the first or the last list
-- goes back to the list the player came from, as B does. Each list keeps the entry the player
-- left it at.
function PickerModel.ChangeList(state, step)
    local to = state.list + step
    if #state.parents > 0 and (to < 1 or to > #state.lists) then
        PickerModel.Back(state)
        return
    end
    state.places[state.list] = state.index
    state.list = (to - 1) % #state.lists + 1
    state.index, state.control = state.places[state.list] or 1, nil
end

-- A on a "more" entry: the lists it holds take the place of the lists in view.
-- Each of those lists ends with a Back entry: A on it goes back, as B does. It is there for the
-- mouse, and as a second way.
PickerModel.BACK_ICON = "Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Up"
function PickerModel.Open(state, entry)
    state.parents[#state.parents + 1] = { lists = state.lists, list = state.list, index = state.index, places = state.places }
    local lists = {}
    for _, list in ipairs(withEntries(entry.lists)) do
        local entries = {}
        for i, one in ipairs(list.entries) do
            entries[i] = one
        end
        entries[#entries + 1] = { kind = "back", name = "Back", detail = "", icon = PickerModel.BACK_ICON }
        lists[#lists + 1] = { name = list.name, entries = entries }
    end
    state.lists, state.list, state.index, state.places, state.control = lists, 1, 1, {}, nil
end

-- B. Goes back to the lists the player came from, on the entry that was opened.
-- Returns false at the top, where B closes the whole list.
function PickerModel.Back(state)
    local parent = table.remove(state.parents)
    if not parent then
        return false
    end
    state.lists, state.list, state.index, state.places, state.control = parent.lists, parent.list, parent.index, parent.places, nil
    return true
end

-- A list where every entry would show the same picture shows names only.
function PickerModel.NamesOnly(list)
    local count = 0
    for _, entry in ipairs(list.entries) do
        -- the Back entry at the end of a list under More does not count
        if entry.kind ~= "back" then
            if entry.icon ~= list.entries[1].icon then
                return false
            end
            count = count + 1
        end
    end
    return count > 1
end

if ns then
    ns.PickerModel = PickerModel
end
return PickerModel
