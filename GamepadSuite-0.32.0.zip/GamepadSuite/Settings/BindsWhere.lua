-- The words of the bind list about where things are bound, with no game calls, so they can be
-- tested outside the game. Each entry of the list that is on a button shows where ("RT + A",
-- "RT + A in Combat", "RT + A +2"). Before a bind takes a slot with a bind of the player's, the Replace box asks
-- ("Replace Fireball?"), and after the change the card says what happened ("Frostbolt is on
-- RT + A. Fireball was there."). The page (Settings/Binds.lua) gives the slot and set words of the
-- binds page (BindsDraw.lua SlotName, the names of the set tabs).
local _, ns = ...

local Where = {}

-- The same thing on the list and on a button: its kind and its id (a spell by its spell number).
function Where.Key(bind)
    return tostring(bind.kind) .. ":" .. tostring(bind.id)
end

-- One place in words: "RT + A", and " in Combat" after it when its set is not `plain`.
-- slotName(layer, key) and setName(set) are the page's words.
function Where.At(place, plain, slotName, setName)
    local slot = slotName(place.layer, place.key)
    return place.set == plain and slot or (slot .. " in " .. setName(place.set))
end

-- Every place of the player's binds, by Where.Key: a list of { set, layer, key } in the order the
-- mark names them. each(fn) calls fn(bind, set, layer, key) for each bind of the store (Core/Binds.lua
-- Each). counts(set, layer, key) is true where a bind can act. sets: the ids of the page's sets in
-- the order of the tabs, with the set in view (view) first. keys: the buttons in the page's order;
-- a button that is not among them comes after them.
function Where.Index(each, counts, sets, view, keys)
    local setAt, keyAt, index = {}, {}, {}
    for i, set in ipairs(sets) do
        setAt[set] = set == view and 0 or i
    end
    for i, key in ipairs(keys) do
        keyAt[key] = i
    end
    each(function(bind, set, layer, key)
        if not bind.empty and setAt[set] and counts(set, layer, key) then
            local name = Where.Key(bind)
            index[name] = index[name] or {}
            table.insert(index[name], { set = set, layer = layer, key = key, rank = (setAt[set] * 10 + layer) * 100 + (keyAt[key] or 99) })
        end
    end)
    for _, places in pairs(index) do
        table.sort(places, function(a, b)
            return a.rank < b.rank or (a.rank == b.rank and a.key < b.key)
        end)
    end
    return index
end

-- The mark of an entry: its first place, and "+2" for two more. nil for no place.
function Where.Mark(places, view, slotName, setName)
    if not places or #places == 0 then
        return nil
    end
    local first = Where.At(places[1], view, slotName, setName)
    return #places > 1 and (first .. " +" .. (#places - 1)) or first
end

-- What a slot did before a bind goes on it: { how = , name = , from = }, or nil for nothing.
--   own   a bind of the player's in that set
--   game  the game's own job there (no bind of ours)
--   kept  the bind of another set that this set keeps (from: that set's name)
--   same  the thing that goes there now
-- The Replace box's two lines, or nil when no bind of the player's is lost (empty, game, kept,
-- same): "Replace Fireball?" and "Frostbolt goes on RT + A.". The game's own job comes back when
-- the bind is cleared, and the card says it was there (Where.Said).
function Where.Ask(name, slot, was)
    if not was or was.how ~= "own" then
        return nil
    end
    return "Replace " .. was.name .. "?", name .. " goes on " .. slot .. "."
end

-- The card's line after a bind went on a slot.
function Where.Said(name, slot, was)
    local said = name .. " is on " .. slot .. "."
    if not was then
        return said
    elseif was.how == "same" then
        return name .. " was on " .. slot .. " already."
    elseif was.how == "kept" then
        return said .. " " .. was.from .. " keeps " .. was.name .. "."
    end
    return said .. (was.how == "game" and " The game's " or " ") .. was.name .. " was there."
end

if ns then
    ns.BindsWhere = Where
end
return Where
