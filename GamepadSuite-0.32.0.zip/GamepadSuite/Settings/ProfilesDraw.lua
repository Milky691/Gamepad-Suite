-- The frames of the Profiles page and how they are drawn: the list on the left, and on the
-- parchment the page of the line in focus (Settings/Paper.lua: the title, one rule, the lead,
-- numbered steps, and the facts at the foot). Export as Text and Import from Text put a text box
-- in the place of the steps; a build puts its role switches there, in two columns, and its Name
-- line its name box (the look of the name box of My Wheels).
-- It draws what ProfilesPage.lua gives it and holds no state of the page.
-- The sizes are the ones of the samples the user saw (mockups/profiles_sample2.py,
-- mockups/profiles_builds_sample.py).
local _, ns = ...

local Theme, Widgets, Model = ns.Theme, ns.Widgets, ns.SettingsProfilesModel
local px = Theme.px

local Draw = {}
ns.SettingsProfilesDraw = Draw

-- Numbers are in the mockup's units.
local WIDTH, HEIGHT, LIST_WIDTH, STAGE_X = 1232, 544, 280, 310
local FIRST_Y, LINE_HEIGHT, LINE_GAP, BREAK, BOX_HEIGHT = 76, 38, 2, 16, 84
local MEASURE, STEP = ns.SettingsPaper.MEASURE, ns.SettingsPaper.STEP
-- the plain line of an empty list is two lines of text; the gold line round the text box is 4 wide
local PLAIN_HEIGHT, RIM = 44, 4
-- the name box (as on My Wheels) and the two columns of role switches, each row ROLE_STEP under the last
local NAME_WIDTH, NAME_HEIGHT, ROLE_STEP = 360, 48, 34
local WAY = { back = "back", previous = "back", next = "next" }

local frame, paper
local rows = {}
local note, box, edit, nameBox, roles
local actions -- what the mouse and the text box do, given by ProfilesPage.lua

local function listLine(i)
    local row = CreateFrame("Frame", nil, frame)
    row:SetSize(px(LIST_WIDTH), px(LINE_HEIGHT))
    row.light = row:CreateTexture(nil, "BACKGROUND")
    row.light:SetTexture(Theme.art.rowLight)
    row.light:SetBlendMode("ADD")
    row.light:SetAlpha(0.42)
    row.light:SetAllPoints()
    row.bar = Theme.Fill(row, "ARTWORK", Theme.Color("gold"))
    row.bar:SetWidth(px(3))
    row.bar:SetPoint("TOPLEFT", 0, -px(7))
    row.bar:SetPoint("BOTTOMLEFT", 0, px(7))
    row.name = Theme.Text(row, "row", "cream")
    row.name:SetPoint("LEFT", px(16), 0)
    row.name:SetWidth(px(LIST_WIDTH - 32))
    row.name:SetJustifyH("LEFT")
    row.name:SetWordWrap(true)
    row.right = Theme.Text(row, "body", "muted")
    -- Back, Next, Previous and the build in use lead to another page: each has the arrow and the glow of a
    -- control, and a gold name (decision 79)
    row.nav = Widgets.Nav(row)
    -- the bar of a hold, the same on every hold of the suite
    row.hold = Widgets.HoldLine(row)
    -- the mouse: hover gives the focus; a press is A, kept down for a line that wants a hold; a right click is X
    row:EnableMouse(true)
    row:SetScript("OnEnter", function() actions.Focus(row.index) end)
    row:SetScript("OnMouseDown", function(_, button)
        -- the plain line of an empty list is no line
        if not row.index then
            return
        end
        actions.Focus(row.index, true)
        if button == "RightButton" then
            actions.Click("X")
        else
            actions.Press("A")
        end
    end)
    row:SetScript("OnMouseUp", function() actions.Release("A") end)
    rows[i] = row
end

-- handlers are the page's actions: Focus(index, clicked), Press(what), Release(what), Click(what),
-- BoxChanged(), BoxClosed()
function Draw.Build(win, handlers)
    actions = handlers
    frame = CreateFrame("Frame", nil, win)
    frame:SetPoint("TOPLEFT", px(24), -px(119))
    frame:SetSize(px(WIDTH), px(HEIGHT))
    frame:Hide()
    local title = Theme.Text(frame, "title", "gold", true)
    title:SetPoint("TOPLEFT")
    title:SetText("Profiles")
    for i = 1, Model.ROOM + 1 do
        listLine(i)
    end

    paper = ns.SettingsPaper.Build(frame, STAGE_X)
    local page, lead = paper.page, paper.lead
    note = Theme.Text(page, "body", "ink", false, true)

    -- the text box: the gold line of the name box of My Wheels, on a darker plate (it sits on the
    -- bright middle of the parchment, and holds small text)
    box = CreateFrame("Frame", nil, page)
    box:SetSize(px(MEASURE - 2 * RIM), px(BOX_HEIGHT - 2 * RIM))
    box:SetPoint("TOPLEFT", lead, "BOTTOMLEFT", px(RIM), -px(22 + RIM))
    Theme.Fill(box, "BACKGROUND", Theme.Color("ground", 0.8)):SetAllPoints()
    ns.SettingsWheelsDraw.Outline(box, 0, 1, 0, 0, 0, 1)
    ns.SettingsWheelsDraw.Outline(box, 1, 3, Theme.Color("gold"))
    local clip = CreateFrame("Frame", nil, box)
    clip:SetPoint("TOPLEFT", px(14 - RIM), -px(12 - RIM))
    clip:SetPoint("BOTTOMRIGHT", -px(14 - RIM), px(12 - RIM))
    clip:SetClipsChildren(true)
    edit = CreateFrame("EditBox", nil, clip)
    edit:SetMultiLine(true)
    -- room for the longest text Import takes (spaces and line breaks of a chat window too); a
    -- box keeps no more, so a giant paste cannot slow the game down
    edit:SetMaxLetters(ns.ProfileRules.TEXT_MOST * 2)
    edit:SetAutoFocus(false)
    edit:SetFont(Theme.font.text, px(Theme.size.small), "")
    edit:SetTextColor(Theme.Color("cream"))
    edit:SetPoint("TOPLEFT")
    edit:SetSize(px(MEASURE - 28), px(BOX_HEIGHT - 24))
    edit:SetScript("OnTextChanged", function(_, byPlayer)
        if byPlayer then
            actions.BoxChanged()
        end
    end)
    -- Escape, or a focus that goes away, closes the box
    edit:SetScript("OnEscapePressed", function() actions.BoxClosed() end)
    edit:SetScript("OnEditFocusLost", function() actions.BoxClosed() end)

    -- the name box of a build: its name on a dark plate in a gold line; for a real keyboard a text
    -- box takes its place (Draw.StartTyping)
    nameBox = CreateFrame("Frame", nil, page)
    nameBox:SetSize(px(NAME_WIDTH), px(NAME_HEIGHT))
    nameBox:SetPoint("TOPLEFT", lead, "BOTTOMLEFT", px(RIM), -px(22 + RIM))
    Theme.Fill(nameBox, "BACKGROUND", 0, 0, 0, 0.62):SetAllPoints()
    ns.SettingsWheelsDraw.Outline(nameBox, 0, 1, 0, 0, 0, 1)
    ns.SettingsWheelsDraw.Outline(nameBox, 1, 3, Theme.Color("gold"))
    nameBox.text = Theme.Text(nameBox, "name", "cream")
    nameBox.text:SetPoint("LEFT", px(14), 0)
    nameBox.text:SetPoint("RIGHT", -px(14), 0)
    local typed = CreateFrame("EditBox", nil, nameBox)
    typed:SetAutoFocus(false)
    typed:SetFont(Theme.font.text, px(Theme.size.name), "")
    typed:SetTextColor(Theme.Color("cream"))
    typed:SetMaxLetters(ns.BuildRules.NAME_MOST)
    typed:SetPoint("TOPLEFT", px(14), 0)
    typed:SetPoint("BOTTOMRIGHT", -px(14), 0)
    typed:Hide()
    typed:SetScript("OnEnterPressed", function(self) actions.NameDone(self:GetText()) end)
    typed:SetScript("OnEditFocusLost", function(self) actions.NameDone(self:GetText()) end)
    typed:SetScript("OnEscapePressed", function() actions.NameCancel() end)
    nameBox.edit = typed
    nameBox:EnableMouse(true)
    nameBox:SetScript("OnMouseUp", function() actions.Click("A") end)

    -- the role switches of a build: two columns of three, each a name and its value
    roles = {}
    for i = 1, #ns.BuildRules.ROLES do
        local cell = CreateFrame("Frame", nil, page)
        cell:SetSize(px(MEASURE / 2), px(ROLE_STEP))
        cell:SetPoint("TOPLEFT", lead, "BOTTOMLEFT", px((i - 1) % 2 * MEASURE / 2), -px(30 + math.floor((i - 1) / 2) * ROLE_STEP))
        cell.name = Theme.Text(cell, "body", "ink", false, true)
        cell.name:SetPoint("LEFT")
        cell.value = Theme.Text(cell, "body", "inkRed", false, true)
        cell.value:SetPoint("LEFT", cell.name, "RIGHT", px(10), 0)
        roles[i] = cell
    end
    return frame
end

-- The text box with a text in it, selected when there is one. A click on it gives it the
-- keyboard focus, for a real keyboard: the copy and the paste are that keyboard's. The addon moves
-- no keyboard focus itself (Settings/WheelsDraw.lua, Draw.StartTyping, says why).
function Draw.OpenBox(text)
    box:Show()
    edit:SetText(text)
    edit:HighlightText()
end

-- The text of the box again, all selected: a key the player hit does not change the text to copy.
function Draw.SetBox(text)
    edit:SetText(text)
    edit:HighlightText()
end

function Draw.CloseBox()
    edit:ClearFocus()
end

function Draw.BoxText()
    return edit:GetText()
end

-- The player types a build's name with a real keyboard: the text box shows in the name box, with
-- the name selected. A click on it gives it the keyboard's focus; the addon moves no focus itself.
function Draw.StartTyping(text)
    nameBox.text:Hide()
    nameBox.edit:SetText(text)
    nameBox.edit:Show()
    nameBox.edit:HighlightText()
end

function Draw.StopTyping()
    nameBox.edit:ClearFocus()
    nameBox.edit:Hide()
    nameBox.text:Show()
end

function Draw.TypedText()
    return nameBox.edit:GetText()
end

-- The list line in focus, for the bar of a hold. nil when it is not in view.
function Draw.FocusRow(index)
    for _, row in ipairs(rows) do
        if row:IsShown() and row.index == index then
            return row
        end
    end
end

-- shown is Model.Shown, panel is Model.Panel (or BuildPageModel.Panel: with roles, a table of role
-- switches; with box, the name box), focus is the line in focus; open is true while the text box
-- is, typing while a name is typed in the name box.
function Draw.Page(shown, panel, focus, open, typing)
    local y, last = FIRST_Y, 0
    for i, row in ipairs(rows) do
        local item = shown[i]
        row:SetShown(item ~= nil)
        row.hold:Hide()
        if item then
            local line = item.line
            if i > 1 then
                y = y + last + (item.gap and BREAK or LINE_GAP)
            end
            last = line and LINE_HEIGHT or PLAIN_HEIGHT
            row:SetHeight(px(last))
            row.index = line and item.index or nil
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", 0, -px(y))
            local focused = line ~= nil and item.index == focus
            row.light:SetShown(focused)
            row.bar:SetShown(focused)
            row.name:SetText(line and line.name or item.note)
            -- which way the arrow of a line that leads to another page points; nil for any other line
            local way = line and (line.way or WAY[line.kind])
            row.name:SetTextColor(Theme.Color((not line and "muted") or (way and "gold") or (focused and "white") or "cream"))
            row.nav:Set(way)
            row.right:SetText(line and line.right or "")
            -- the word at the right ("In use") stands left of the arrow, when the line has one
            row.right:ClearAllPoints()
            if way then
                row.right:SetPoint("RIGHT", row.nav, "LEFT", -px(6), 0)
            else
                row.right:SetPoint("RIGHT", -px(16), 0)
            end
            -- a long name ends before the word at its right and the arrow; the plain line of an empty list has two lines
            row.name:SetWidth(px(LIST_WIDTH - 32) - (line and line.right ~= "" and row.right:GetStringWidth() + px(8) or 0) - (way and px(30) or 0))
            row.name:SetMaxLines(line and 1 or 2)
            if line and line.class then
                row.right:SetTextColor(ns.Adapter.ClassColor(line.class))
            elseif line and line.use then
                -- the build in use: "In use" in gold
                row.right:SetTextColor(Theme.Color("gold"))
            else
                row.right:SetTextColor(Theme.Color("muted"))
            end
        end
    end

    local named, kept = panel.box ~= nil or typing, panel.roles or {}
    paper.Show(panel, open or named or #kept > 0)
    box:SetShown(open)
    nameBox:SetShown(named)
    nameBox.text:SetText(panel.box or "")
    for i, cell in ipairs(roles) do
        cell:SetShown(kept[i] ~= nil)
        cell.name:SetText(kept[i] and kept[i][1] or "")
        cell.value:SetText(kept[i] and kept[i][2] or "")
    end
    -- the note sits under the box, the name box, the role switches or the last step
    note:ClearAllPoints()
    if open then
        note:SetPoint("TOPLEFT", box, "BOTTOMLEFT", -px(RIM), -px(14 + RIM))
    elseif named then
        note:SetPoint("TOPLEFT", nameBox, "BOTTOMLEFT", -px(RIM), -px(14 + RIM))
    elseif #kept > 0 then
        note:SetPoint("TOPLEFT", paper.lead, "BOTTOMLEFT", 0, -px(30 + math.ceil(#kept / 2) * ROLE_STEP + 12))
    else
        note:SetPoint("TOPLEFT", paper.lead, "BOTTOMLEFT", 0, -px(34 + #panel.steps * STEP + 20 - (STEP - 34)))
    end
    note:SetText(panel.note or "")
end
