-- The rules of the builds' part of the Profiles page, with no game calls: the lines of a build's own
-- page, the choices of its gear set and talents, and the words of the parchment and the legend for
-- a build, New Build and the lines of a build's page. The list itself is Settings/ProfilesModel.lua's.
-- A on the build in use opens its page: Name (A types it on the on-screen keyboard), Gear Set and
-- Talents (A or left and right change them), Back. A build that is not in use is held to switch to.
local _, ns = ...

local Model = {}

-- The talents a build can follow: None, then the game's two groups.
Model.TALENTS = { "None", "Primary", "Secondary" }

function Model.TalentName(group)
    return Model.TALENTS[(group or 0) + 1] or "None"
end

-- The group of a talents choice, or nil for None.
function Model.Talent(name)
    for at, one in ipairs(Model.TALENTS) do
        if one == name and at > 1 then
            return at - 1
        end
    end
    return nil
end

-- A build's gear set as the page shows it: "None", its name, or "Healing Gear (gone)" when sets
-- (the names of the character's equipment sets) does not have it.
local function gear(name, sets)
    if not name then
        return "None"
    end
    for _, one in ipairs(sets or { name }) do
        if one == name then
            return name
        end
    end
    return name .. " (gone)"
end

-- The lines of the page of the build in use. can.talents: the character has two talent groups;
-- can.sets: the names of its equipment sets.
function Model.Lines(build, can)
    local lines = {
        { kind = "name", name = "Name", right = build.name },
        { kind = "gear", name = "Gear Set", right = gear(build.gear, can.sets) },
    }
    if can.talents then
        lines[#lines + 1] = { kind = "talents", name = "Talents", right = Model.TalentName(build.talent) }
    end
    lines[#lines + 1] = { kind = "back", name = "Back" }
    return lines
end

-- The next choice after `value` (nil is None, the first), `step` 1 or -1, round. Gives nil for None.
-- A value that is no choice any more (a set that was deleted) counts as None.
function Model.Step(choices, value, step)
    local at = 1
    for index, one in ipairs(choices) do
        if one == value then
            at = index
        end
    end
    local to = (at - 1 + step) % #choices + 1
    return to > 1 and choices[to] or nil
end

-- The role switches of a build as the parchment shows them: { { name, value } }, in the list's order.
-- A switch the build has not kept (a build from an older file) is not shown: using the build leaves it as it is.
function Model.Roles(roles, kept)
    local out = {}
    for _, role in ipairs(type(kept) == "table" and roles or {}) do
        local value = kept[role.key]
        if value ~= nil then
            out[#out + 1] = { role.name, (value == true and "On") or (value == false and "Off") or tostring(value) }
        end
    end
    return out
end

local LEAD = {
    -- (%s: " or talents" when the character has two talent groups)
    use = "The build in use. It saves by itself: every change to binds, wheels, fixed slots and the settings below is kept in it. You change those settings on the Layers and Combat tabs. "
        .. "Press A to rename it, or to give it a gear set%s.",
    other = "Hold A to use this build. Its binds, wheels, fixed slots and the settings below come back as you left them.",
    new = "Makes a copy of the build in use, with all its binds, wheels and fixed slots, and switches to it. The build you leave keeps what it has. A character can have four.",
    -- (%s: the build's name)
    name = "The name shows in this list, on your other characters, and in the bind list as Build: %s.",
    gear = "This equipment set goes on when you switch to this build. Make sets in the character window, on the Equipment Manager tab.",
    talents = "When you change to these talents in the game, this build comes in by itself.",
    back = "Goes back to the list of builds. B does the same.",
}

-- What the parchment shows for a line of builds: { head, text, steps, facts, roles = { { name, value } }, box, note }.
-- info: the build in focus, or the build in use for the lines of its page: { name, use, binds, wheels, gear,
-- talent, roles (Model.Roles), talents (the character has two groups) }. sets: the names of the character's
-- equipment sets (nil: not asked).
function Model.Panel(line, info, me, sets)
    local kind = line.kind
    if kind == "new" then
        return { head = "New Build", text = LEAD.new, steps = { "Press A to make the build", "Press A on it to give it a name" }, facts = {} }
    end
    local panel = { head = info.name, steps = {}, facts = {} }
    if kind == "build" then
        panel.text, panel.roles = line.use and LEAD.use:format(info.talents and " or talents" or "") or LEAD.other, info.roles
        panel.facts = { { "Binds", info.binds }, { "Wheels", info.wheels }, { "Gear Set", gear(info.gear, sets) } }
        if info.talents then
            panel.facts[#panel.facts + 1] = { "Talents", Model.TalentName(info.talent) }
        end
    elseif kind == "name" then
        panel.text, panel.box = LEAD.name:format(info.name), info.name
    elseif kind == "gear" then
        panel.text, panel.facts = LEAD.gear, { { "Gear Set", gear(info.gear, sets) } }
        panel.note = sets and #sets == 0 and "You have no equipment sets yet." or nil
    elseif kind == "talents" then
        panel.text, panel.facts = LEAD.talents, { { "Talents", Model.TalentName(info.talent) } }
    else
        panel.text = LEAD.back
    end
    return panel
end

-- The legend's words for a line of builds. tab: the page is a tab of the window (B closes it there);
-- typing: the player types a name in the name box (the keyboard has the buttons, B is Done).
function Model.Words(line, state, tab, typing)
    if typing then
        return { typing = true, b = "Done", pad = {} }
    end
    local kind, back = line.kind, tab and "Close" or "Back"
    if kind == "build" then
        if line.use then
            return { a = "Open", b = back }
        end
        return { a = "Hold to use", x = state.armed == line.key and "Remove now" or "Remove", b = back }
    elseif kind == "new" then
        return { a = "Make", b = back }
    elseif kind == "name" then
        return { a = "Rename", b = "Back" }
    elseif kind == "gear" or kind == "talents" then
        return { a = "Next option", change = "Change", b = "Back" }
    end
    return { a = "Back", b = "Back" }
end

if ns then
    ns.SettingsBuildPageModel = Model
end
return Model
