-- The list where the player chooses a bind for a button, or for a place of a wheel of their own.
-- While it is open it takes the place of the page that opened it (the binds page, My Wheels). Its rules are in PickerModel.lua. Its lists come from Core/Catalog.lua.
-- A cell that leads to other entries (More, Next, Back, Previous) is a control: it has the arrow
-- and the glow of Look/Widgets.lua Nav and a gold name, so it does not read as one more bind.
-- The mouse works too: hover gives the focus, a click chooses, the wheel turns the page.
-- A page can mark entries: a few small words at the right end of the cell, such as where the
-- entry is bound already ("RT + A +2", Settings/BindsWhere.lua) or "In this wheel".
local _, ns = ...

local Theme, Widgets, Model, Nav = ns.Theme, ns.Widgets, ns.PickerModel, ns.SettingsNav
local px = Theme.px

local Picker = {}
ns.SettingsPicker = Picker

-- Two columns of cells. Numbers are in the mockup's units.
local WIDTH, CELL_WIDTH, CELL_HEIGHT, STEP, FIRST_Y = 1232, 600, 54, 60, 104

local frame, forSlot, pageText, plate, current, before, after
local cells = {}
local state, lastList
local marks -- marks(entry): the page's words for an entry, or nil; nil for a page with no marks

-- Where cell i of a page is, in the mockup's units: its left, its top and its width. Two columns
-- of seven. A list of names only has narrower cells, with the two columns in the middle of the page.
local function cellPlace(i, plain)
    local column, row = math.floor((i - 1) / Model.COLUMN), (i - 1) % Model.COLUMN
    if plain then
        return (WIDTH - 616) / 2 + column * 316, FIRST_Y + row * STEP, 300
    end
    return column * (WIDTH - CELL_WIDTH), FIRST_Y + row * STEP, CELL_WIDTH
end

-- The places of the first `count` cells of a page, for the D-pad (Settings/Nav.lua).
function Picker.Places(count, plain)
    local places = {}
    for i = 1, count do
        local x, y, width = cellPlace(i, plain)
        places[i] = { id = i, x = x, y = y, w = width, h = CELL_HEIGHT }
    end
    return places
end

-- A frame the mouse can press. what is the controller button it stands for.
local function clickable(target, what)
    target:EnableMouse(true)
    target:SetScript("OnMouseUp", function() ns.SettingsInput.Click(what) end)
end

function Picker.Build(parent)
    frame = CreateFrame("Frame", nil, parent)
    frame:SetAllPoints()
    frame:Hide()
    frame:EnableMouseWheel(true)
    frame:SetScript("OnMouseWheel", function(_, delta)
        if Model.TurnPage(state, delta > 0 and -1 or 1) then
            Picker.Draw()
        end
    end)

    local title = Theme.Text(frame, "title", "gold", true)
    title:SetPoint("TOPLEFT")
    title:SetText("Choose a Bind")
    forSlot = Theme.Text(frame, "row", "muted")
    forSlot:SetPoint("BOTTOMLEFT", title, "BOTTOMRIGHT", px(14), px(3))
    pageText = Theme.Text(frame, "small", "muted")
    pageText:SetPoint("TOPRIGHT", 0, -px(12))

    -- the strip: the list in view on a gold plate, its neighbours beside it, LB and RB at the ends
    plate = CreateFrame("Frame", nil, frame)
    plate:SetHeight(px(36))
    plate:SetPoint("TOP", 0, -px(52))
    local fill = Theme.Fill(plate, "BACKGROUND", 1, 1, 1, 1)
    fill:SetAllPoints()
    fill:SetGradient("VERTICAL", CreateColor(0.79, 0.61, 0.25, 1), CreateColor(0.96, 0.84, 0.48, 1))
    current = Theme.Text(plate, "row", "ink", false, true)
    current:SetPoint("CENTER")
    -- the neighbours are buttons for the mouse: each sits on a frame as wide as its name
    local function neighbour(what, point, to, x)
        local button = CreateFrame("Frame", nil, frame)
        button:SetHeight(px(36))
        button:SetPoint(point, plate, to, x, 0)
        button.text = Theme.Text(button, "row", "muted")
        button.text:SetPoint("CENTER")
        clickable(button, what)
        local glyph = Widgets.Glyph(frame, what, px(28))
        glyph:SetPoint(point, button, to, x > 0 and px(14) or -px(14), 0)
        clickable(glyph, what)
        return button
    end
    before = neighbour("LB", "RIGHT", "LEFT", -px(28))
    after = neighbour("RB", "LEFT", "RIGHT", px(28))

    for i = 1, Model.PER_PAGE do
        local cell = CreateFrame("Frame", nil, frame)
        cell.side = i <= Model.COLUMN and "RIGHT" or "LEFT"
        cell.box = Theme.Fill(cell, "BACKGROUND", Theme.Color("gold", 0.12))
        cell.box:SetAllPoints()
        cell.icon = Widgets.Icon(cell, px(40))
        cell.icon:SetPoint("LEFT", px(12), 0)
        cell.name = Theme.Text(cell, "row", "cream")
        cell.name:SetWordWrap(false)
        cell.detail = Theme.Text(cell, "small", "muted")
        cell.where = Theme.Text(cell, "tiny", "muted")
        cell.where:SetPoint("RIGHT", -px(14), 0)
        cell.nav = Widgets.Nav(cell)
        -- the mouse: hover gives the focus, a click is A
        cell:EnableMouse(true)
        cell:SetScript("OnEnter", function()
            if ns.Adapter.MouseMoved() and Model.FocusCell(state, i) then
                Picker.Draw()
                ns.SettingsDraw.Legend()
            end
        end)
        cell:SetScript("OnMouseUp", function() ns.SettingsInput.Click("A") end)
        cells[i] = cell
    end
end

function Picker.Draw()
    local list = Model.List(state)
    local shown, focus, page, pages = Model.Cells(state)
    local name, nameBefore, nameAfter = Model.Names(state)
    current:SetText(name)
    plate:SetWidth(current:GetStringWidth() + px(48))
    -- one list alone has no neighbours to name
    local alone = #state.lists == 1 and nameBefore == name
    before.text:SetText(alone and "" or nameBefore)
    after.text:SetText(alone and "" or nameAfter)
    before:SetWidth(before.text:GetStringWidth() + px(4))
    after:SetWidth(after.text:GetStringWidth() + px(4))
    pageText:SetText(pages > 1 and ("Page " .. page .. " of " .. pages) or "")
    -- in a list where no entry has a detail, the names sit in the middle of their cells
    local bare = true
    for _, entry in ipairs(list.entries) do
        bare = bare and (entry.detail or "") == ""
    end
    -- names only: narrower cells, with the two columns in the middle of the page
    local plain = Model.NamesOnly(list)
    ns.Adapter.HideTooltip()
    for i, cell in ipairs(cells) do
        local entry = shown[i]
        cell:SetShown(entry ~= nil)
        if entry then
            local x, y, width = cellPlace(i, plain)
            -- a control has its arrow at the right end and no picture box: its name starts where the box would
            local way = Model.Control(entry)
            local textX = px((plain or way) and 16 or 64)
            cell:SetSize(px(width), px(CELL_HEIGHT))
            cell:ClearAllPoints()
            cell:SetPoint("TOPLEFT", px(x), -px(y))
            -- a control has no mark; a mark takes the room it needs at the right end, and the name and the line under it end before it
            local mark = not way and marks and marks(entry) or nil
            cell.where:SetText(mark or "")
            local room = mark and (cell.where:GetStringWidth() + px(14)) or 0
            cell.name:SetWidth(math.max(px(40), px(width) - textX - px(way and 52 or 12) - room))
            cell.detail:SetWidth(math.max(px(40), px(width) - textX - px(12) - room))
            local focused = i == focus
            cell.box:SetShown(focused)
            cell.icon:SetIcon(entry.icon)
            cell.icon:SetShown(not plain and not way)
            cell.nav:Set(way)
            cell.name:SetText(entry.name)
            cell.name:SetTextColor(Theme.Color(way and "gold" or "cream"))
            cell.detail:SetText(entry.detail or "")
            cell.name:ClearAllPoints()
            -- a name with no line under it sits in the middle of its cell
            local alone = bare or (entry.detail or "") == ""
            cell.name:SetPoint(alone and "LEFT" or "BOTTOMLEFT", cell, "LEFT", textX, alone and 0 or px(1))
            cell.detail:SetPoint("TOPLEFT", cell, "LEFT", textX, -px(3))
            if focused and not way then
                ns.Adapter.ShowTooltip(cell, cell.side, entry)
            end
        end
    end
end

-- Opens the list for a slot, in the place of the page `host` (a frame of the size of the body).
-- slotName is the slot's name as the page shows it ("LT + A"). lists is what the page offers;
-- with none given it is every list of the catalog. mark(entry) gives the page's mark of an entry.
-- Returns false when the game gave nothing to choose from.
function Picker.Open(slotName, host, lists, mark)
    state, marks = Model.New(lists or ns.Catalog.Build(), lastList), mark
    if #state.lists == 0 then
        state, marks = nil, nil
        return false
    end
    Picker.For(slotName)
    frame:SetParent(host)
    frame:ClearAllPoints()
    frame:SetAllPoints(host)
    frame:Show()
    Picker.Draw()
    return true
end

-- The small words after the title: what the chosen bind is for ("for LT + A").
function Picker.For(what)
    forSlot:SetText("for " .. what)
end

-- The entry in focus when it is a bind (not a control: More, Next, Back, Previous), or nil.
function Picker.Entry()
    local entry = state and Model.Entry(state)
    return entry and not Model.Control(entry) and entry or nil
end

-- The top list the player was in is the one the next open starts on.
function Picker.Close()
    if state then
        lastList = Model.TopName(state)
        state, marks = nil, nil
        frame:Hide()
        ns.Adapter.HideTooltip()
    end
end

function Picker.IsOpen()
    return state ~= nil
end

-- D-pad: the focus goes to the cell of this page that lies that way (Settings/Nav.lua), and stops
-- at the edges of the page. A column is a list of its own: up and down do not leave it, also when
-- the other column is near (a list of names) and has cells further down. Returns false when the
-- focus did not move.
function Picker.Move(dy, dx)
    local shown, focus = Model.Cells(state)
    local all, places = Picker.Places(#shown, Model.NamesOnly(Model.List(state))), {}
    for _, place in ipairs(all) do
        if dy == 0 or place.x == all[focus].x then
            places[#places + 1] = place
        end
    end
    local to = Nav.Go(places, focus, dx, dy)
    if to then
        Model.FocusCell(state, to)
        Picker.Draw()
    end
    return to ~= nil
end

-- LB / RB: the list before or after.
function Picker.ChangeList(step)
    Model.ChangeList(state, step)
    Picker.Draw()
end

-- A. On a bind: that entry comes back. On a control nil comes back: More opens its lists, Back
-- goes back to the lists it came from, Next and Previous show that page.
function Picker.Choose()
    local entry = Model.Entry(state)
    if not Model.Control(entry) then
        return entry
    elseif entry.kind == "more" then
        Model.Open(state, entry)
    elseif entry.kind == "back" then
        Model.Back(state)
    else
        Model.TurnPage(state, entry.kind == "next" and 1 or -1)
    end
    Picker.Draw()
    return nil
end

-- B. Under a More entry: back to the lists it came from, and true. At the top: false.
function Picker.Back()
    local back = Model.Back(state)
    if back then
        Picker.Draw()
    end
    return back
end

-- The word for A on the focused entry.
local WORD = { more = "Open", back = "Back", next = "Next", previous = "Previous" }
function Picker.Word()
    return WORD[Model.Entry(state).kind] or "Choose"
end
