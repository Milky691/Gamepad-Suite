-- The binds page's rules, with no game calls, so they can be tested outside the game.
--
-- A slot is one button, on one layer, in one set.
--   Sets: "normal", "combat", and one for each form or stance. A slot with no bind of its own in
--   another set does what Normal does there. It can also be made empty on purpose in that set.
--   Layers: 1 no trigger, 2 LT, 3 RT, 4 LT + RT, 5 LB + RB (hold LB, then RB), 6 LB (hold LB).
--   Every set has every layer. Only ten buttons are in the two hold layers.
-- The focus is in one of three zones: the row of set tabs at the top, where the page opens, the
-- row of layer tabs under it, and the slots under that. The D-pad alone reaches every page. In a
-- row of tabs left and right change the set or the layer. Every other press moves the focus to
-- the thing that lies that way on the page: the page asks Settings/Nav.lua, with the places of
-- BindsDraw.lua, and gives the answer to Move.
--
-- shape is what the page offers right now:
--   { left = { keys }, right = { keys },            the two columns of slots
--     sets = { { id = , name = , help = }, ... },   the first one is Normal
--     holds = { [5] = true, [6] = false } }         which hold layers act (Core/BindRules.lua Holds)
-- binds is the store as two functions: get(set, layer, key) and set(set, layer, key, bind); and
-- game(layer, key), the game's own job of a slot with no bind of ours (nil for none).
local _, ns = ...

local BindsModel = {}

BindsModel.LAYERS = { "No trigger", "LT", "RT", "LT + RT", "LB + RB" }
local LAYER_HELP = {
    "No trigger held.", "Hold LT.", "Hold RT.", "Hold LT and RT.",
    "Hold LB, then press RB. For the D-pad, A, B, X, Y and both stick clicks. LB and RB keep their own binds.",
}
-- the ten buttons of a hold layer
local IN_HOLD = { DU = true, DD = true, DL = true, DR = true, A = true, B = true, X = true, Y = true, LS = true, RS = true }

function BindsModel.New()
    return { lt = false, rt = false, hold = nil, set = "normal", zone = "sets", focus = nil, carry = nil }
end

-- The layer in view, 1 to 6.
function BindsModel.Layer(state)
    return state.hold or (state.lt and 1 or 0) + (state.rt and 2 or 0) + 1
end

-- Shows a layer by its number.
function BindsModel.ShowLayer(state, layer)
    state.hold = layer > 4 and layer or nil
    if layer <= 4 then
        state.lt, state.rt = layer == 2 or layer == 4, layer == 3 or layer == 4
    end
end

-- The layers the set in view has, in tab order.
function BindsModel.Layers(state, shape)
    local layers = { 1, 2, 3, 4 }
    for hold = 5, 6 do
        if shape.holds[hold] then
            layers[#layers + 1] = hold
        end
    end
    return layers
end

-- The place of the set in view among shape.sets.
function BindsModel.SetIndex(state, shape)
    for i, set in ipairs(shape.sets) do
        if set.id == state.set then
            return i
        end
    end
    return 1
end

-- LT or RT. One press flips that trigger's layer on or off, and it stays. From a hold layer it
-- goes to that trigger's layer.
function BindsModel.FlipLayer(state, which)
    if state.hold then
        state.hold, state.lt, state.rt = nil, which == "LT", which == "RT"
    elseif which == "LT" then
        state.lt = not state.lt
    else
        state.rt = not state.rt
    end
end

-- Call this when the shape may have changed (another controller picture, a setting, a new form).
-- The focus counts down the left column, then down the right; a focus that fits no slot goes to
-- the first slot. A set or a hold layer that is gone gives way to Normal and layer 1. With one set
-- alone the page shows no row of sets, and the focus is on the row of layers.
function BindsModel.Fit(state, shape)
    if not (state.focus and state.focus >= 1 and state.focus <= #shape.left + #shape.right) then
        state.focus = 1
    end
    state.set = shape.sets[BindsModel.SetIndex(state, shape)].id
    if state.hold and not shape.holds[state.hold] then
        state.hold = nil
    end
    if state.zone == "sets" and #shape.sets < 2 then
        state.zone = "layers"
    end
end

-- The key of the focused slot.
function BindsModel.Key(state, shape)
    local left = #shape.left
    return state.focus > left and shape.right[state.focus - left] or shape.left[state.focus]
end

-- The focused slot: its set, layer and key.
function BindsModel.Cell(state, shape)
    return state.set, BindsModel.Layer(state), BindsModel.Key(state, shape)
end

-- The thing in focus, as the page's places name it (BindsDraw.lua Places): "sets", "layers", or
-- the number of a slot.
function BindsModel.At(state)
    return state.zone == "slots" and state.focus or state.zone
end

-- From a row of tabs into the slots: the top slot of the column the focus was in last. Both
-- columns start at the same height under the rows, so both are equally near.
local function intoSlots(state, shape)
    state.zone, state.focus = "slots", state.focus > #shape.left and #shape.left + 1 or 1
end

-- D-pad. In a row of tabs, left and right change the layer or the set and stop at the ends. Any
-- other press moves the focus to `to`: the thing that lies that way on the page ("sets", "layers",
-- the number of a slot), or nil when nothing lies that way, and then the focus stays. So in the
-- slots up and down move inside a column and stop at its ends, left and right go to the other
-- column, and up from the top slot of a column goes to the rows of tabs.
-- Returns false when nothing changed.
function BindsModel.Move(state, shape, dy, dx, to)
    local before = state.zone .. state.focus .. state.set .. BindsModel.Layer(state)
    if state.zone == "layers" and dx ~= 0 then
        local layers, at = BindsModel.Layers(state, shape), 1
        for i, layer in ipairs(layers) do
            if layer == BindsModel.Layer(state) then
                at = i
            end
        end
        BindsModel.ShowLayer(state, layers[math.max(1, math.min(#layers, at + dx))])
    elseif state.zone == "sets" and dx ~= 0 then
        local at = math.max(1, math.min(#shape.sets, BindsModel.SetIndex(state, shape) + dx))
        state.set = shape.sets[at].id
    elseif type(to) ~= "number" then
        state.zone = to or state.zone
    elseif state.zone == "slots" then
        state.focus = to
    else
        intoSlots(state, shape)
    end
    return before ~= state.zone .. state.focus .. state.set .. BindsModel.Layer(state)
end

-- What a slot holds. Returns a word and the bind to show:
--   "out"        the button is not in this hold layer
--   "own"        a bind of its own
--   "blocked"    made empty on purpose in this set
--   "inherited"  nothing of its own; it does what Normal does (the bind is Normal's). The set
--                of Prowl keeps the bind of Cat Form first (binds.base names that set). The
--                third value is the set the bind is kept from.
--   "empty"      nothing
function BindsModel.Status(binds, set, layer, key)
    if layer > 4 and not IN_HOLD[key] then
        return "out"
    end
    local own = binds.get(set, layer, key)
    if own and own.empty then
        return "blocked"
    elseif own then
        return "own", own
    end
    local base = set ~= "normal" and binds.base and binds.base(set)
    local kept = set ~= "normal" and (base and binds.get(base, layer, key) or binds.get("normal", layer, key))
    if kept and not kept.empty then
        return "inherited", kept, base and binds.get(base, layer, key) and base or "normal"
    end
    return "empty"
end

-- The name of a set as its tab shows it; of the set that `set` keeps its binds from first, when
-- `first` is true (Normal, or Cat Form for Prowl).
local function setName(shape, binds, set, first)
    if first then
        set = binds.base and binds.base(set) or "normal"
    end
    for _, info in ipairs(shape.sets) do
        if info.id == set then
            return info.name
        end
    end
    return "Normal"
end

-- Who a spell or an item is cast on, in the words of a slot and of the card. No entry: the target.
BindsModel.ON = { player = "on yourself", focus = "on your focus", mouseover = "on the unit under the pointer" }
local ON_ORDER = { "player", "focus", "mouseover" }

-- Y: the spell or item of the focused slot is cast on the next of: the target, yourself, the
-- focus, the unit under the pointer. False when the slot has no spell or item of its own.
function BindsModel.CastOn(state, shape, binds)
    if state.zone ~= "slots" or state.carry then
        return false
    end
    local set, layer, key = BindsModel.Cell(state, shape)
    local status, bind = BindsModel.Status(binds, set, layer, key)
    if status ~= "own" or (bind.kind ~= "spell" and bind.kind ~= "item") then
        return false
    end
    local at, copy = 0, {}
    for i, on in ipairs(ON_ORDER) do
        at = bind.on == on and i or at
    end
    for name, value in pairs(bind) do
        copy[name] = value
    end
    copy.on = ON_ORDER[at + 1]
    binds.set(set, layer, key, copy)
    return true
end

-- The name a slot shows. describe(bind) returns the bind's name, and true for a game action.
function BindsModel.Name(status, bind, describe)
    if bind then
        return (describe(bind))
    end
    return status == "blocked" and "Empty here" or status == "out" and "Not in this layer" or "Empty"
end

-- The bind being carried, or nil.
function BindsModel.Carried(state)
    return state.carry and state.carry.bind
end

-- True for the slot a carried bind came from. The bind stays in that slot until it is put down.
function BindsModel.Lifted(state, set, layer, key)
    local carry = state.carry
    return carry ~= nil and carry.set == set and carry.layer == layer and carry.key == key
end

-- A. In a row of tabs: the focus goes to the slots of the set and the layer in view, and
-- "slots" comes back. In the slots it returns "picked", "dropped" (put back where it came from),
-- "moved", "swapped", or "choose" on a slot with no bind of its own and nothing carried: the page
-- then opens the list. Returns nil when A does nothing: on a button that is not in the layer.
function BindsModel.Press(state, shape, binds)
    if state.zone ~= "slots" then
        intoSlots(state, shape)
        return "slots"
    end
    local set, layer, key = BindsModel.Cell(state, shape)
    local status, here = BindsModel.Status(binds, set, layer, key)
    if status == "out" then
        return nil
    end
    local carry = state.carry
    if not carry then
        if status ~= "own" then
            return "choose"
        end
        -- the carry remembers its own slot, so a change of layer or set while carrying does not change what was picked
        state.carry = { set = set, layer = layer, key = key, bind = here }
        return "picked"
    end
    state.carry = nil
    if carry.set == set and carry.layer == layer and carry.key == key then
        return "dropped"
    end
    local swap = status == "own"
    binds.set(carry.set, carry.layer, carry.key, swap and here or nil)
    binds.set(set, layer, key, carry.bind)
    return swap and "swapped" or "moved"
end

-- X. On a bind of its own: clears it. In a set other than Normal, on a bind that comes from
-- Normal: makes the slot empty in this set; and on such an empty slot: gives the Normal bind back.
-- Returns "cleared", "blocked", "restored", or false when X does nothing.
function BindsModel.Clear(state, shape, binds)
    local set, layer, key = BindsModel.Cell(state, shape)
    local status = BindsModel.Status(binds, set, layer, key)
    if state.zone ~= "slots" or state.carry then
        return false
    elseif status == "own" then
        binds.set(set, layer, key, nil)
        return "cleared"
    elseif status == "inherited" then
        binds.set(set, layer, key, { empty = true })
        return "blocked"
    elseif status == "blocked" then
        binds.set(set, layer, key, nil)
        return "restored"
    end
    return false
end

-- B goes back one level, as on every page. A carry ends: "cancel". In the slots the focus goes
-- back to the row of sets, where A went into the slots: "back" (with one set alone the page has
-- no such row, and Fit puts the focus on the row of layers). In a row of tabs: "close", and the
-- window closes.
function BindsModel.Back(state)
    if state.carry then
        state.carry = nil
        return "cancel"
    elseif state.zone == "slots" then
        state.zone = "sets"
        return "back"
    end
    return "close"
end

-- A tab change or a close of the window ends a carry. The next time the tab opens, the focus is
-- on the row of sets again.
function BindsModel.Leave(state)
    state.carry, state.zone = nil, "sets"
end

-- The legend words right now: a, x and b for those buttons, change for D-pad left and right in
-- a row of tabs. A missing word means the button does nothing.
function BindsModel.Words(state, shape, binds)
    local back = state.carry and "Cancel" or state.zone == "slots" and "Back" or "Close"
    if state.zone ~= "slots" then
        return { change = "Change", a = "Edit binds", b = back }
    end
    local set, layer, key = BindsModel.Cell(state, shape)
    local status = BindsModel.Status(binds, set, layer, key)
    if status == "out" then
        return { b = back }
    elseif state.carry then
        local swap = status == "own" and not BindsModel.Lifted(state, set, layer, key)
        return { a = swap and "Swap" or "Put down", b = back }
    elseif status == "own" then
        local _, here = BindsModel.Status(binds, set, layer, key)
        return { a = "Pick up", x = "Clear", y = (here.kind == "spell" or here.kind == "item") and "Cast on" or nil, b = back }
    end
    return { a = "Choose", x = status == "inherited" and "Clear here" or status == "blocked" and ("Use " .. setName(shape, binds, set, true)) or nil, b = back }
end

-- The card's line: about the focused slot, or about the focused tab.
function BindsModel.Help(state, shape, binds, describe)
    local set, layer, key = BindsModel.Cell(state, shape)
    local setInfo = shape.sets[BindsModel.SetIndex(state, shape)]
    if state.zone == "sets" then
        return setInfo.help
    elseif state.zone == "layers" then
        return LAYER_HELP[layer]
    end
    local status, here, from = BindsModel.Status(binds, set, layer, key)
    if status == "out" then
        return "This button is not in the " .. BindsModel.LAYERS[layer] .. " layer."
    elseif state.carry then
        local carried = describe(state.carry.bind)
        if status == "own" and not BindsModel.Lifted(state, set, layer, key) then
            return "Carrying " .. carried .. ". Swap it with " .. describe(here) .. " here."
        end
        return "Carrying " .. carried .. ". Put it down here."
    elseif status == "own" then
        local _, game = describe(here)
        local what = here.kind == "wheel" and "Opens this wheel." or (here.kind == "slash" and tostring(here.id):find("^build") and "Switches to another build.")
            or game and "The game's own command." or "Your bind."
        local on = BindsModel.ON[here.on]
        -- Y has no row or text of its own elsewhere: the card names it where the legend shows it
        local y = (here.kind == "spell" or here.kind == "item") and " Y changes who it is cast on." or ""
        -- shape.sticks(bind, layer): Sticky Layers is on and this bind leaves its trigger layer on (Settings/BindsShape.lua)
        local stick = shape.sticks and shape.sticks(here, layer) and " With Sticky Layers on, it leaves this layer on after the hold." or ""
        return what .. (on and (" It is cast " .. on .. ".") or "") .. y .. stick .. " Pick it up to move it or swap it."
    elseif status == "inherited" then
        -- The Combat set on a page that has a set for a form or a stance too: in a fight a slot with
        -- no bind of its own keeps the bind of the form the player is in, and then Normal's. The
        -- slot shows Normal's.
        local form = set == "combat" and shape.sets[#shape.sets].id ~= "combat" and ", or as the form you are in" or ""
        return "Same as " .. setName(shape, binds, from) .. form .. ". Choose a bind to change it in " .. setInfo.name .. "."
    elseif status == "blocked" then
        -- (a slot made empty in the Combat set stops the search there: no form's bind either)
        -- (in a form a form's own bind still comes first, unless Combat First)
        local inForm = shape.sets[#shape.sets].id ~= "combat" and not shape.combatFirst
        return "Empty in " .. setInfo.name .. ". " .. (set == "combat" and (inForm and "In a form, the form's bind is used. Normal's is not." or "No bind of another set is used here.")
            or ("The " .. setName(shape, binds, set, true) .. " bind is not used here."))
    elseif binds.was and binds.was(set, layer, key) then
        -- a load of another character's build left this spell out: the slot keeps its name until it gets a bind
        return "The loaded build had " .. binds.was(set, layer, key) .. " here. Choose a bind."
    elseif binds.game and binds.game(layer, key) then
        -- no bind of ours: the game's own job is on the button (the slot shows its name, dim)
        return "No bind of yours: the game does this. Choose a bind, or move one here."
    end
    return "Empty. Choose a bind, or move one here."
end

if ns then
    ns.BindsModel = BindsModel
end
return BindsModel
