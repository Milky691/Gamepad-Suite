-- The frames of the binds page and how they are drawn: two rows of tabs (sets over layers, in
-- BindsTabs.lua), the controller, a named slot for every button with a line to it, the card, the
-- carried bind, and the Replace box. It draws what Binds.lua gives it and holds no state of the page.
local _, ns = ...

local Theme, Widgets, Model, Tabs = ns.Theme, ns.Widgets, ns.BindsModel, ns.SettingsBindsTabs
local px = Theme.px

local Draw = {}
ns.SettingsBindsDraw = Draw

local NAMES = {
    LB = "LB", RB = "RB", LS = "Left Stick Click", RS = "Right Stick Click", VW = "View", MN = "Menu", GD = "Xbox Button",
    DU = "D-pad Up", DD = "D-pad Down", DL = "D-pad Left", DR = "D-pad Right",
    A = "A", B = "B", X = "X", Y = "Y", L4 = "L4 back grip", L5 = "L5 back grip", R4 = "R4 back grip", R5 = "R5 back grip",
}
Draw.NAMES = NAMES -- the Slot Binds page names a slot's button with the same words

-- Slots from top to bottom in the order the buttons sit on each drawing, so the lines do not cross.
-- GD is the Xbox button (the PS button, Home). The Steam Deck has none: Steam keeps its Steam button.
-- A column of eight fits on the page with a step of 57.
local SLOTS = {
    xbox = { left = { "LB", "GD", "LS", "VW", "DU", "DL", "DR", "DD" }, right = { "RB", "Y", "B", "MN", "X", "A", "RS" },
             step = 57, height = 52, padWidth = 560, padTop = 84 },
    deck = { left = { "LB", "VW", "DU", "DL", "DR", "LS", "DD", "L4", "L5" }, right = { "RB", "MN", "Y", "X", "B", "RS", "A", "R4", "R5" },
             step = 50, height = 46, padWidth = 640, padTop = 132 },
}
SLOTS.ps = { left = { "LB", "VW", "DU", "DL", "DR", "GD", "DD", "LS" }, right = { "RB", "MN", "Y", "X", "B", "A", "RS" },
             step = 57, height = 52, padWidth = 560, padTop = 84 }
SLOTS.switch = SLOTS.xbox
local WIDTH, HEIGHT, SLOT_WIDTH, FIRST_Y, TICK = 1232, 544, 280, 92, 20
-- a line with a soft edge, so a slanted line does not look like a stair
local LINE = "Interface\\TaxiFrame\\UI-Taxi-Line"
local MUTED = Theme.Hex("muted")
-- On the Steam Deck a trigger's label sits just over its bumper's label. The line to a bumper
-- goes to the outer end of its label, in the picture's units, so it stays clear of the trigger.
local DECK_END = { LB = -24, RB = 24 }

local frame, body, pad, card, carryBox, focusLine, box
local slots = {}
local rows = Tabs.ROWS
local actions -- what a click does, given by Binds.lua

-- The slots of a controller picture: its two columns of keys and the sizes that go with them.
function Draw.Layout(styleName)
    return SLOTS[styleName] or SLOTS.xbox
end

-- Where slot `row` of a column is, in the mockup's units: its left and its top.
local function slotPlace(layout, right, row)
    return right and WIDTH - SLOT_WIDTH or 0, FIRST_Y + (row - 1) * layout.step
end

-- Where each thing that can have the focus is on the page, in the mockup's units, in reading
-- order: the row of sets (when the page shows it: with more than one set), the row of layers, and
-- the slots, numbered down the left column and then down the right. A row of tabs is the whole
-- band across the page: its tabs stand in the middle of it, as wide as their names. The D-pad
-- goes by these places (Settings/Nav.lua).
function Draw.Places(layout, sets)
    local places = {}
    for _, which in ipairs({ "sets", "layers" }) do
        if which == "layers" or sets > 1 then
            places[#places + 1] = { id = which, x = 0, y = rows[which].y, w = WIDTH, h = Tabs.HEIGHT }
        end
    end
    for column, keys in ipairs({ layout.left, layout.right }) do
        for row = 1, #keys do
            local x, y = slotPlace(layout, column == 2, row)
            places[#places + 1] = { id = (column - 1) * #layout.left + row, x = x, y = y, w = SLOT_WIDTH, h = layout.height }
        end
    end
    return places
end

-- A slot's name as the page shows it: "A", or "LT + A" on a layer.
function Draw.SlotName(layer, key)
    return (layer > 1 and (Model.LAYERS[layer] .. " + ") or "") .. NAMES[key]
end

-- The Replace box: over the page, and over the list while it is open (Picker.lua puts the list in
-- this frame), in the window's look: its marble, its gold edge, a gold title. A dark veil under it
-- takes the mouse, so a click on a cell under the box presses nothing. A and B show as the legend
-- shows them, and a click on one presses it.
local function buildBox()
    box = CreateFrame("Frame", nil, frame)
    box:SetAllPoints()
    box:SetFrameLevel(frame:GetFrameLevel() + 20)
    box:EnableMouse(true)
    -- (the mouse wheel too: it would turn the page of the list under the box)
    box:EnableMouseWheel(true)
    box:SetScript("OnMouseWheel", function() end)
    Theme.Fill(box, "BACKGROUND", Theme.Color("veil", 0.66)):SetAllPoints()
    local plate = CreateFrame("Frame", nil, box, "BackdropTemplate")
    plate:SetSize(px(640), px(210))
    plate:SetPoint("CENTER")
    plate:SetBackdrop({
        bgFile = Theme.art.marble, tile = true, tileSize = px(256), edgeFile = Theme.art.edgeGold, edgeSize = px(32),
        insets = { left = px(11), right = px(11), top = px(11), bottom = px(11) },
    })
    plate:SetBackdropColor(0.78, 0.74, 0.70, 1)
    -- a long name and slot take two lines, in the title and in the line under it
    box.title = Theme.Text(plate, "name", "gold", true)
    box.line = Theme.Text(plate, "row", "cream")
    for _, text in ipairs({ box.title, box.line }) do
        text:SetWidth(px(580))
        text:SetJustifyH("CENTER")
        text:SetWordWrap(true)
        text:SetMaxLines(2)
    end
    box.title:SetPoint("TOP", 0, -px(32))
    box.line:SetPoint("TOP", box.title, "BOTTOM", 0, -px(12))
    for _, hint in ipairs({ { "A", "Replace", -px(120) }, { "B", "Back", px(40) } }) do
        local button = CreateFrame("Frame", nil, plate)
        button:SetSize(px(120), px(32))
        button:SetPoint("BOTTOMLEFT", plate, "BOTTOM", hint[3], px(28))
        local glyph = Widgets.Glyph(button, hint[1], px(28))
        glyph:SetPoint("LEFT")
        local word = Theme.Text(button, "body", "cream")
        word:SetPoint("LEFT", glyph, "RIGHT", px(8), 0)
        word:SetText(hint[2])
        button:EnableMouse(true)
        button:SetScript("OnMouseUp", function() ns.SettingsInput.Click(hint[1]) end)
    end
    box:Hide()
end

-- Shows the Replace box with its two lines ("Replace Fireball?", "Frostbolt goes on RT + A."),
-- or hides it with none.
function Draw.Ask(title, line)
    box:SetShown(title ~= nil)
    box.title:SetText(title or "")
    box.line:SetText(line or "")
end

-- handlers are the page's actions: SelectSet(index), SelectLayer(index), Focus(index), Press(), Clear()
function Draw.Build(win, handlers)
    actions = handlers
    frame = CreateFrame("Frame", nil, win)
    frame:SetPoint("TOPLEFT", px(24), -px(119))
    frame:SetSize(px(WIDTH), px(HEIGHT))
    frame:Hide()
    -- body holds the page's own parts, so all of them hide together while the list is open
    body = CreateFrame("Frame", nil, frame)
    body:SetAllPoints()
    Tabs.Build(body, handlers, WIDTH)

    pad = Widgets.Pad(body, px(560))

    card = CreateFrame("Frame", nil, body)
    card:SetSize(px(560), px(84))
    card:SetPoint("BOTTOM")
    local paper = card:CreateTexture(nil, "BACKGROUND")
    paper:SetTexture(Theme.art.parchment)
    paper:SetAllPoints()
    card.title = Theme.Text(card, "name", "inkRed", true, true)
    card.title:SetPoint("TOPLEFT", px(22), -px(12))
    card.label = Theme.Text(card, "small", "ink", false, true)
    card.label:SetPoint("LEFT", card.title, "RIGHT", px(12), 0)
    -- the card's line has the card's width and wraps: a long one takes two lines, and the card has room for two
    card.text = Theme.Text(card, "body", "ink", false, true)
    card.text:SetPoint("TOPLEFT", px(22), -px(48))
    card.text:SetPoint("TOPRIGHT", -px(22), -px(48))
    card.text:SetWordWrap(true)
    card.text:SetMaxLines(2)

    -- the carried bind: its picture in a gold-edged box at the corner of the focused slot or tab
    -- the one line from the focused slot's tick to its button
    focusLine = body:CreateLine(nil, "ARTWORK")
    carryBox = Widgets.Icon(body, px(34))
    carryBox:SetFrameLevel(body:GetFrameLevel() + 5)
    buildBox()
    return frame, body
end

local function slotFrame(index)
    local slot = slots[index]
    if slot then
        return slot
    end
    slot = CreateFrame("Frame", nil, body)
    slot.box = Theme.Fill(slot, "BACKGROUND", Theme.Color("gold", 0.12))
    slot.box:SetAllPoints()
    slot.icon = Widgets.Icon(slot, px(40))
    slot.name = Theme.Text(slot, "row", "dim")
    slot.name:SetWidth(px(SLOT_WIDTH - 76))
    slot.name:SetWordWrap(false)
    slot.key = Theme.Text(slot, "small", "muted")
    -- a short level tick for every slot; the focused slot also has one line to its button
    slot.tick = body:CreateLine(nil, "ARTWORK")
    -- the mouse: hover gives the focus, a left click is A, a right click is X
    slot:EnableMouse(true)
    slot:SetScript("OnEnter", function()
        if ns.Adapter.MouseMoved() then
            actions.Focus(index)
        end
    end)
    slot:SetScript("OnMouseUp", function(_, button)
        actions.Focus(index)
        if button == "RightButton" then
            actions.Clear()
        else
            actions.Press()
        end
    end)
    slots[index] = slot
    return slot
end

-- soft is for the one slanted line: a texture with a soft edge, much wider than the line it shows
local function setLine(line, x1, y1, x2, y2, strong, soft)
    if soft then
        line:SetTexture(LINE)
        line:SetVertexColor(Theme.Color("gold"))
        line:SetThickness(px(14))
    else
        line:SetColorTexture(Theme.Color("gold", strong and 1 or 0.3))
        line:SetThickness(strong and px(2) or px(1.5))
    end
    line:SetStartPoint("TOPLEFT", body, x1, y1)
    line:SetEndPoint("TOPLEFT", body, x2, y2)
    line:Show()
end

-- A bind's name for a slot: a spell shows its rank after its name.
local function nameWithRank(name, rank)
    return rank ~= "" and (name .. "  " .. MUTED .. rank .. "|r") or name
end

-- Draws the page. state and shape are the page's (see BindsModel.lua); binds is the store, with
-- binds.game(layer, key) the game's own job of a slot with no bind of ours (Adapter.GameJob);
-- describe(bind) gives a bind's name, true for a game action, and its rank ("" when it has none).
-- said: the line on the card after a change, in place of its help, or nil.
function Draw.Page(state, shape, binds, describe, said)
    local layout = shape.layout
    local set, layer = state.set, Model.Layer(state)
    pad:SetStyle(shape.style, px(layout.padWidth))
    pad:ClearAllPoints()
    pad:SetPoint("TOP", body, "TOP", 0, -px(layout.padTop))

    -- the two rows of tabs
    local setNames, layerNames, layerAt = {}, {}, 1
    for i, info in ipairs(shape.sets) do
        setNames[i] = info.name
    end
    for i, number in ipairs(Model.Layers(state, shape)) do
        layerNames[i] = Model.LAYERS[number]
        if number == layer then
            layerAt = i
        end
    end
    local setTab = Tabs.Draw("sets", #setNames > 1 and setNames or {}, Model.SetIndex(state, shape), state.zone == "sets")
    local layerTab = Tabs.Draw("layers", layerNames, layerAt, state.zone == "layers")

    -- a slot that stays in use is not hidden and shown again, so the game sends no new "mouse entered"
    for _, slot in ipairs(slots) do
        slot.used = false
    end
    focusLine:Hide()
    local padLeft = (px(WIDTH) - pad:GetWidth()) / 2
    local padTop = px(layout.padTop)
    local inSlots = state.zone == "slots"
    local focusedKey = inSlots and Model.Key(state, shape) or nil
    local carried = Model.Carried(state)
    carryBox:SetShown(carried ~= nil)
    if carried then
        carryBox:SetIcon(carried.kind == "macro" and ns.Adapter.BindIcon(carried) or ns.Catalog.Icon(carried) or carried.icon, true)
        local tab = state.zone == "sets" and setTab or layerTab
        if not inSlots and tab then
            carryBox:ClearAllPoints()
            carryBox:SetPoint("BOTTOMRIGHT", tab, "TOPLEFT", px(10), -px(10))
        end
    end
    local tipFrame, tipSide, tipBind
    for side, keys in pairs({ left = shape.left, right = shape.right }) do
        local right = side == "right"
        for row, key in ipairs(keys) do
            local index = right and (#shape.left + row) or row
            local slot = slotFrame(index)
            local focused = inSlots and index == state.focus
            local slotLeft, y = slotPlace(layout, right, row)
            slotLeft, y = px(slotLeft), px(y)
            slot:SetSize(px(SLOT_WIDTH), px(layout.height))
            slot:ClearAllPoints()
            slot:SetPoint("TOPLEFT", body, "TOPLEFT", slotLeft, -y)
            slot.box:SetShown(focused)
            slot.icon:ClearAllPoints()
            slot.name:ClearAllPoints()
            slot.key:ClearAllPoints()
            -- the picture sits at the outer end of the slot, the words run toward the controller
            local anchor, other, gap = "LEFT", "RIGHT", px(12)
            if right then
                anchor, other, gap = "RIGHT", "LEFT", -px(12)
            end
            slot.icon:SetPoint(anchor, slot, anchor, gap, 0)
            slot.name:SetPoint("BOTTOM" .. anchor, slot.icon, other, gap, px(1))
            slot.name:SetJustifyH(anchor)
            slot.key:SetPoint("TOP" .. anchor, slot.icon, other, gap, -px(3))

            -- a bind that is carried stays in its slot, dimmed; one that comes from Normal is faded and grey
            local status, bind = Model.Status(binds, set, layer, key)
            local lifted = Model.Lifted(state, set, layer, key)
            -- no bind of ours: the spell a load took away ("was Holy Light"), else the game's own job, dim
            -- (Jump on A), with its picture faded
            local was = status == "empty" and binds.was and binds.was(set, layer, key) or nil
            local job = status == "empty" and not was and binds.game(layer, key) or nil
            local name, _, rank = "", false, ""
            if bind then
                name, _, rank = describe(bind)
            end
            -- a button outside the layer is dim; its focus band is not, so the focus still shows
            local dim = status == "out" and 0.3 or 1
            slot.icon:SetAlpha(dim)
            slot.name:SetAlpha(dim)
            slot.key:SetAlpha(dim)
            slot.icon:SetIcon(bind and ((bind.kind == "fixed" or bind.kind == "macro") and ns.Adapter.BindIcon(bind) or ns.Catalog.Icon(bind) or bind.icon) or job and job.icon)
            slot.icon:SetStrength(lifted and 0.3 or (status == "inherited" or job) and 0.55 or 1, status == "inherited" or job ~= nil)
            slot.name:SetText(bind and nameWithRank(name, rank) or was and ("was " .. was) or job and job.name or Model.Name(status))
            slot.name:SetTextColor(Theme.Color(lifted and "dim" or status == "own" and "cream" or status == "inherited" and "muted" or "dim"))
            -- a button that is not in the layer shows its own name alone ("RB", not "LB + RB + RB")
            local label = (status == "out" and NAMES[key] or Draw.SlotName(layer, key))
                .. ((layer == 1 and key == shape.interact) and ", Dynamic Interact" or "")
                .. ((bind and shape.sticks and shape.sticks(bind, layer)) and ", sticks the layer" or "")
            slot.key:SetText(label)
            slot.used = true
            slot:Show()

            -- the tick is level; the focused slot's line runs on from the tick's end to its button
            local tickFrom = right and px(WIDTH - SLOT_WIDTH) or px(SLOT_WIDTH)
            local tickTo = tickFrom + (right and -px(TICK) or px(TICK))
            local lineY = -(y + px(layout.height) / 2)
            setLine(slot.tick, tickFrom, lineY, tickTo, lineY, focused)
            if focused then
                local bx, by = pad:ButtonOffset(key)
                local stop = px(26)
                local outer = shape.style == "deck" and DECK_END[key]
                if outer then
                    local unit = pad:GetWidth() / pad.style.width
                    bx, by, stop = bx + outer * unit, by - 9 * unit, px(4)
                end
                local toX, toY = padLeft + bx, -padTop + by
                local length = math.sqrt((toX - tickTo) ^ 2 + (toY - lineY) ^ 2)
                -- stop a little outside the button picture
                local reach = length > 0 and math.max(0, 1 - stop / length) or 0
                setLine(focusLine, tickTo, lineY, tickTo + (toX - tickTo) * reach, lineY + (toY - lineY) * reach, true, true)
                if carried then
                    carryBox:ClearAllPoints()
                    carryBox:SetPoint("TOPLEFT", body, "TOPLEFT", right and (slotLeft - px(24)) or px(SLOT_WIDTH - 10), -(y - px(8)))
                end
                card.title:SetText(bind and name or job and job.name or Model.Name(status))
                card.label:SetText((rank ~= "" and (rank .. ", ") or "") .. label)
                if bind and not carried then
                    tipFrame, tipSide, tipBind = slot, right and "LEFT" or "RIGHT", bind
                end
            end
        end
    end

    for _, slot in ipairs(slots) do
        if not slot.used then
            slot:Hide()
            slot.tick:Hide()
        end
    end

    -- the controller lights the focused button and the buttons that hold the layer in view
    local lit = { focusedKey }
    for _, key in ipairs(({ {}, { "LT" }, { "RT" }, { "LT", "RT" }, { "LB", "RB" }, { "LB" } })[layer]) do
        lit[#lit + 1] = key
    end
    pad:SetLit(lit)
    if not inSlots then
        card.title:SetText(state.zone == "sets" and setNames[Model.SetIndex(state, shape)] or Model.LAYERS[layer])
        card.label:SetText("")
    end
    card.text:SetText(said or Model.Help(state, shape, binds, describe))
    -- the small words after the title end at the card's edge too: a long rank and slot name is cut short there
    card.label:SetWidth(math.max(1, card:GetWidth() - px(56) - card.title:GetStringWidth()))
    if tipBind then
        ns.Adapter.ShowTooltip(tipFrame, tipSide, tipBind)
    else
        ns.Adapter.HideTooltip()
    end
end
