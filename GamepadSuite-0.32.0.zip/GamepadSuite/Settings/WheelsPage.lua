-- The My Wheels page of the settings window: what each button does on it. The player makes
-- wheels of their own here. The rules are in WheelsModel.lua, the frames in WheelsDraw.lua, the
-- wheels in the store (Core/Wheels.lua). The page has two levels: the list of wheels, and inside
-- one wheel its name box and its ring of eight slots. Inside a wheel the D-pad goes to the stop
-- that lies that way (Settings/Nav.lua). A on a slot opens the list to choose a bind for that
-- slot (Picker.lua), which takes the page's place while it is open. The player chooses the slot,
-- and with it the direction the bind has in the game. After a pick the list stays open for the
-- next empty slot, until B or until the wheel is full; an entry that is on the wheel already is
-- marked "In this wheel" in the list. A on the name box asks the addon's on-screen keyboard for
-- the name (ns.Keyboard). Without that keyboard the box takes the keyboard focus, for a real
-- keyboard: this game shows no keyboard of its own for a text box.
-- A saved wheel is in the bind list under Wheels by itself.
local _, ns = ...

local Model, Rules, Store, Picker, Draw, Nav = ns.SettingsWheelsModel, ns.WheelRules, ns.Wheels, ns.SettingsPicker, ns.SettingsWheelsDraw, ns.SettingsNav

local Page = {}
ns.SettingsWheels = Page

-- in the list only up and down move the focus; inside a wheel all four directions do
local UP_DOWN = { { keys = { "DU", "DD" }, text = "Move" } }

local frame, body
local state = Model.New()
local lines  -- the lines of the list now, made again at each draw
local target -- where the chosen bind goes: { id = the wheel (nil for a new one), place = }
local typing -- the wheel whose name the player is typing, or nil

function Page.Draw()
    lines = Model.Lines(Store.Mine(), Rules)
    Model.Fit(state, lines, Rules)
    Draw.Page(state, lines, Rules, typing ~= nil)
end

-- One of the player's wheels by its id, or nil.
local function mine(id)
    for _, wheel in ipairs(Store.Mine()) do
        if wheel.id == id then
            return wheel
        end
    end
end

-- The list's mark of an entry that is on the wheel the list is for already.
local function mark(entry)
    local wheel = target and target.id and mine(target.id)
    return wheel and Model.Mark(wheel.slots, entry, Rules) or nil
end

-- After an action on this page: draw it again, and the legend, because its words follow the focus.
local function redraw(sound)
    ns.Adapter.Sound(sound)
    if not Picker.IsOpen() then
        Page.Draw()
    end
    ns.SettingsDraw.Legend()
end

-- The list closes and the page shows again.
local function closeList()
    Picker.Close()
    body:Show()
    redraw("IG_MAINMENU_OPTION")
end

-- The typing ends. With a text, the wheel gets it as its name (an empty text gives the wheel
-- its own name back); with none, the name stays as it was.
local function doneTyping(text)
    if not typing then
        return
    end
    local id = typing
    typing = nil
    Draw.StopTyping()
    if text then
        Store.SetName(id, text)
    end
    redraw("IG_MAINMENU_OPTION")
end

-- A on the name box. The addon's on-screen keyboard asks for the name and has the controller
-- while it is open; the wheel gets the name when the player confirms it. When that keyboard is
-- not there, or did not open, the text box shows for a real keyboard, and a click gives it the focus.
-- The log keeps which of the two happened, so one try in the game tells.
-- The text starts with the name the player gave the wheel. A wheel with no name of its own shows
-- "Wheel 1": the text starts empty then, so the player does not delete those letters first.
local function rename(line)
    local id = line.id
    local text = line.name ~= Rules.Name(id) and line.name or ""
    local asked = ns.Keyboard and ns.Keyboard.on and ns.Keyboard.Ask("Wheel name", text, Rules.NAME_MOST, function(new)
        ns.Log.Add("wheel", "the on-screen keyboard gave a name for " .. id)
        Store.SetName(id, new)
        redraw("IG_MAINMENU_OPTION")
    end)
    if not asked then
        typing = id
        Draw.StartTyping(text)
    end
    ns.Log.Add("wheel", "A on the name box of " .. id .. ": " .. (asked and "the on-screen keyboard was asked" or "no on-screen keyboard, the text box shows for a real keyboard"))
    redraw("IG_MAINMENU_OPTION")
end

-- True while the player types a name in the box. Every button belongs to the keyboard then, so
-- the window does nothing with it. B alone ends the typing and keeps the name. With no button
-- given, this only says if the player is typing.
function Page.Typing(what)
    if not typing then
        return false
    end
    if what == "B" then
        doneTyping(Draw.TypedText())
    end
    return true
end

-- True while the list to choose a bind is open.
function Page.ListOpen()
    return Picker.IsOpen()
end

-- D-pad. In the list of wheels: up and down. Inside a wheel: to the slot or the name box that
-- lies that way on the page. In the list of binds: to the cell that lies that way.
function Page.Move(dy, dx)
    if Picker.IsOpen() then
        if Picker.Move(dy, dx) then
            ns.Adapter.Sound("U_CHAT_SCROLL_BUTTON")
            ns.SettingsDraw.Legend()
        end
    elseif not state.inside then
        if Model.Move(state, lines, dy) then
            redraw("U_CHAT_SCROLL_BUTTON")
        end
    elseif Model.FocusOn(state, lines, Rules, Nav.Go(Draw.Places(Rules, lines[state.line].id ~= nil), Model.At(state, lines, Rules), dx, dy, true)) then
        redraw("U_CHAT_SCROLL_BUTTON")
    end
end

-- LB or RB while the list of binds is open: the list before or after.
function Page.ChangeList(step)
    Picker.ChangeList(step)
    ns.Adapter.Sound("IG_CHARACTER_INFO_TAB")
    ns.SettingsDraw.Legend()
end

-- A. In the list of wheels: go into the wheel in focus; on the Back line "back" comes back, and
-- the window goes back. Inside a wheel, on a slot: open the list of binds; on the name box:
-- change the name. In the list of binds: act on a control, or put the entry on the slot the list
-- was opened for; the list stays open for the next empty slot of that wheel (EasyController's
-- editor goes on the same way), and closes when the wheel is full.
function Page.Press()
    if Picker.IsOpen() then
        local entry = Picker.Choose()
        if entry then
            local id = Store.SetEntry(target.id, target.place, entry)
            local wheel = id and mine(id)
            local nextSlot = wheel and Model.NextEmpty(wheel.slots, target.place, Rules)
            if id then
                -- the ring's focus follows the list, so B leaves the player on the slot it was for
                Model.Chose(state, Model.Lines(Store.Mine(), Rules), id, nextSlot or target.place)
            end
            if nextSlot then
                target = { id = id, place = nextSlot }
                Picker.For(Model.ListFor(wheel.name, nextSlot))
                Picker.Draw()
                redraw("IG_MAINMENU_OPTION")
            else
                closeList()
            end
        else
            redraw("IG_MAINMENU_OPTION")
        end
        return
    end
    local line, stop = Model.Focus(state, lines, Rules)
    if not stop then
        if not Model.Enter(state, lines) then
            return "back"
        end
        redraw("IG_MAINMENU_OPTION")
        return
    elseif stop.kind == "name" then
        rename(line)
        return
    end
    -- the slot is kept now, so the entry lands on it whatever happens while the list is open
    local id, place = Model.Target(state, lines, Rules)
    target = { id = id, place = place }
    -- the list offers what a wheel can run (Core/Wheels.lua Offer)
    if Picker.Open(Model.ListFor(line.new and "a new wheel" or line.name, place), frame, Store.Offer(ns.Catalog.Build()), mark) then
        body:Hide()
        redraw("IG_MAINMENU_OPTION")
    end
end

-- X: take the bind off the slot in focus. The other slots keep theirs. A wheel that loses its
-- last bind goes.
function Page.Clear()
    if Picker.IsOpen() then
        return
    end
    local line, stop, bind = Model.Focus(state, lines, Rules)
    if bind then
        Store.ClearEntry(line.id, stop.index)
        redraw("IG_MAINMENU_OPTION")
    end
end

-- B: true when it went back in the list of binds or closed it, or went from inside a wheel back
-- to the list of wheels, so the page stays. In the list of wheels B is the window's.
function Page.Back()
    if Picker.IsOpen() then
        if Picker.Back() then
            redraw("IG_MAINMENU_OPTION")
        else
            closeList()
        end
        return true
    elseif Model.Back(state) then
        redraw("IG_MAINMENU_OPTION")
        return true
    end
    return false
end

-- A tab change or a close of the window: a name that is being typed is kept, the list of binds
-- closes, and the page is at its list of wheels the next time it opens.
function Page.Leave()
    Model.Back(state)
    doneTyping(typing and Draw.TypedText())
    if body and not body:IsShown() then
        Picker.Close()
        body:Show()
    end
end

-- The legend words right now. With the list open: list names LB / RB, and A chooses or opens.
-- While the player types: B alone, the keyboard has the other buttons.
function Page.Words()
    if Picker.IsOpen() then
        return { list = "List", a = Picker.Word(), b = "Back" }
    elseif typing then
        return { typing = true, b = "Done", pad = {} }
    end
    local words = Model.Words(state, lines, Rules)
    words.pad = not state.inside and UP_DOWN or nil
    return words
end

-- The mouse: hover on a line, a slot or the name box gives it the focus, when the mouse moved
-- there. A click gives the focus at once, so that it acts on what was clicked and not on what
-- the D-pad left in focus.
local function focus(change, clicked)
    if not typing and (clicked or ns.Adapter.MouseMoved()) and change() then
        redraw("U_CHAT_SCROLL_BUTTON")
    end
end
local mouse = {
    -- a line of the list: the focus is in the list again, on that line
    FocusLine = function(index, clicked)
        focus(function()
            if state.line ~= index or state.inside then
                state.line, state.inside = index, false
                return true
            end
        end, clicked)
    end,
    -- a stop of the wheel in view ("name", or the number of a slot): the mouse goes into the wheel
    FocusStop = function(id, clicked)
        focus(function()
            return Model.FocusOn(state, lines, Rules, id)
        end, clicked)
    end,
    Press = function() ns.SettingsInput.Click("A") end,
    Clear = function() ns.SettingsInput.Click("X") end,
    -- the text box: Enter or a lost focus keeps the name, Escape leaves it as it was
    NameDone = function(text) doneTyping(text) end,
    NameCancel = function() doneTyping(nil) end,
}

function Page.Build(win)
    frame, body = Draw.Build(win, mouse)
    return frame
end
