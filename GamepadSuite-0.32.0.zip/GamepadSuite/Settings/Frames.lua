-- The frames of the settings window, built once when it first opens, and the strip of tabs at
-- its top, laid out again at each draw.
-- Layout numbers are the approved mockup's (a 1600 x 900 screen); px() scales them.
local _, ns = ...

local Theme, Widgets, Model = ns.Theme, ns.Widgets, ns.SettingsModel
local px = Theme.px

-- HEAD: the second row of tabs makes the top bar, and with it the window, this much higher.
local Frames = { MAX_ROWS = 6, HEAD = 36 }
ns.SettingsFrames = Frames
local MAX_ROWS = Frames.MAX_ROWS
-- The strip of tabs has seven names in a row: the fourteen tabs are two rows of seven, Search to
-- Profiles over Combat to Automation. Counted down from the window's top: the middle of each row
-- of names, and the middle of what stands beside the two rows (the addon's name, LB and RB).
local PER_ROW, TAB_Y, BAR_Y = 7, { -px(51), -px(93) }, -px(72)
-- what a click on a button picture in the legend presses
local CLICKS = { A = "A", B = "B", X = "X", Y = "Y", LB = "LB", RB = "RB", LT = "LT", RT = "RT", DL = "left", DR = "right", DU = "up", DD = "down" }

-- ui: the table that receives every part. onHide: called when the window hides.
function Frames.Build(ui, onHide)
    local dim = CreateFrame("Frame", nil, UIParent)
    dim:SetFrameStrata("FULLSCREEN")
    dim:SetAllPoints(UIParent)
    Theme.Fill(dim, "BACKGROUND", Theme.Color("veil", 0.66)):SetAllPoints()
    dim:Hide()
    ui.dim = dim

    local win = CreateFrame("Frame", "GamepadSuiteWindow", UIParent, "BackdropTemplate")
    win:SetFrameStrata("FULLSCREEN_DIALOG")
    win:SetSize(px(1280), px(732 + Frames.HEAD))
    win:SetPoint("CENTER")
    win:SetBackdrop({
        bgFile = Theme.art.marble, tile = true, tileSize = px(256),
        edgeFile = Theme.art.edgeGold, edgeSize = px(32),
        insets = { left = px(11), right = px(11), top = px(11), bottom = px(11) },
    })
    win:SetBackdropColor(0.78, 0.74, 0.70, 1)
    win:EnableMouse(true)
    win:SetClampedToScreen(true)
    win:Hide()

    local warm = Theme.Fill(win, "BORDER", 1, 1, 1, 1)
    warm:SetPoint("TOPLEFT", px(11), -px(11))
    warm:SetPoint("TOPRIGHT", -px(11), -px(11))
    warm:SetHeight(px(270))
    warm:SetGradient("VERTICAL", CreateColor(0.38, 0.26, 0.11, 0), CreateColor(0.38, 0.26, 0.11, 0.26))

    win.open = win:CreateAnimationGroup()
    local scale = win.open:CreateAnimation("Scale")
    scale:SetScaleFrom(0.97, 0.97)
    scale:SetScaleTo(1, 1)
    scale:SetOrigin("CENTER", 0, 0)
    scale:SetDuration(0.24)
    scale:SetSmoothing("OUT")

    -- top bar: the name at the left, the tabs between the pictures of LB and RB (Frames.Tabs)
    ui.brand = Theme.Text(win, "name", "gold", true)
    ui.brand:SetPoint("LEFT", win, "TOPLEFT", px(24), BAR_Y)
    ui.brand:SetText("Gamepad Suite")
    ui.chapterTexts = {}
    ui.chapterLB = Widgets.Glyph(win, "LB", px(30))
    ui.chapterRB = Widgets.Glyph(win, "RB", px(30))
    for what, glyph in pairs({ LB = ui.chapterLB, RB = ui.chapterRB }) do
        glyph:EnableMouse(true)
        glyph:SetScript("OnMouseUp", function() ns.SettingsInput.Click(what) end)
    end
    ui.chapterLine = win:CreateTexture(nil, "ARTWORK")
    ui.chapterLine:SetTexture(Theme.art.levelUp)
    ui.chapterLine:SetTexCoord(unpack(Theme.goldLineCoords))
    ui.chapterLine:SetHeight(px(7))

    -- Everything under the top bar is in this frame. It has the size the window had with one row
    -- of tabs, so the numbers below count from its top, and so do those of the pages that draw
    -- themselves (the binds page, My Wheels, Profiles, Slot Binds).
    local body = CreateFrame("Frame", nil, win)
    body:SetPoint("BOTTOMLEFT")
    body:SetPoint("BOTTOMRIGHT")
    body:SetHeight(px(732))

    for _, y in ipairs({ -px(96), -px(663) }) do
        local hair = Theme.Fill(body, "ARTWORK", Theme.Color("gold", 0.3))
        hair:SetHeight(1)
        hair:SetPoint("TOPLEFT", px(60), y)
        hair:SetPoint("TOPRIGHT", -px(60), y)
    end

    -- left column: the chapter and its rows
    local list = CreateFrame("Frame", nil, body)
    list:SetPoint("TOPLEFT", px(24), -px(119))
    list:SetSize(px(560), px(544))
    ui.list = list
    ui.title = Theme.Text(list, "title", "gold", true)
    ui.title:SetPoint("TOPLEFT")
    ui.line = Theme.Text(list, "body", "muted")
    ui.line:SetPoint("TOPLEFT", 0, -px(44))
    ui.rows = {}
    for i = 1, MAX_ROWS do
        local row = CreateFrame("Frame", nil, list)
        row:SetSize(px(560), px(76))
        row:SetPoint("TOPLEFT", 0, -px(86) - (i - 1) * px(76))
        local border = Theme.Fill(row, "BORDER", 1, 0.94, 0.78, 0.07)
        border:SetHeight(1)
        border:SetPoint("TOPLEFT")
        border:SetPoint("TOPRIGHT")
        row.endLine = Theme.Fill(row, "BORDER", 1, 0.94, 0.78, 0.07)
        row.endLine:SetHeight(1)
        row.endLine:SetPoint("BOTTOMLEFT")
        row.endLine:SetPoint("BOTTOMRIGHT")
        row.light = row:CreateTexture(nil, "BACKGROUND")
        row.light:SetTexture(Theme.art.rowLight)
        row.light:SetBlendMode("ADD")
        row.light:SetAlpha(0.42)
        row.light:SetAllPoints()
        row.bar = Theme.Fill(row, "ARTWORK", Theme.Color("gold"))
        row.bar:SetWidth(px(3))
        row.bar:SetPoint("TOPLEFT", 0, -px(9))
        row.bar:SetPoint("BOTTOMLEFT", 0, px(9))
        row.name = Theme.Text(row, "name", "cream")
        row.name:SetPoint("TOPLEFT", px(22), -px(16))
        row.sum = Theme.Text(row, "body", "muted")
        row.sum:SetPoint("TOPLEFT", px(22), -px(45))
        row.sum:SetWidth(px(400))
        -- the spellbook's own page arrows, for a value you change with left and right
        row.more = row:CreateTexture(nil, "OVERLAY")
        row.more:SetTexture("Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up")
        row.more:SetSize(px(26), px(26))
        row.more:SetPoint("RIGHT", -px(14), 0)
        row.value = Theme.Text(row, "name", "cream")
        row.value:SetPoint("RIGHT", row.more, "LEFT", -px(12), 0)
        row.less = row:CreateTexture(nil, "OVERLAY")
        row.less:SetTexture("Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Up")
        row.less:SetSize(px(26), px(26))
        row.less:SetPoint("RIGHT", row.value, "LEFT", -px(8), 0)
        -- a row that goes to another page has a gold arrow where the others have their value
        row.nav = Widgets.Nav(row)
        -- a search result's tab and page, in small type at the top right, clear of the arrow's glow
        row.where = Theme.Text(row, "small", "muted")
        row.where:SetPoint("TOPRIGHT", -px(58), -px(20))
        -- the bar of a hold, the same on every hold of the suite
        row.hold = Widgets.HoldLine(row)
        -- the mouse: hover gives the focus; a press is A, kept down for a row that wants a hold; the arrows are left and right
        row:EnableMouse(true)
        row:SetScript("OnEnter", function() ns.Settings.FocusRow(i) end)
        row:SetScript("OnMouseDown", function() ns.SettingsInput.Press("A") end)
        row:SetScript("OnMouseUp", function() ns.SettingsInput.Release("A") end)
        -- (these two show only on a row with a value to change, so a click on the gold arrow is a click on its row)
        row.sides = {}
        for what, arrow in pairs({ left = row.less, right = row.more }) do
            local button = CreateFrame("Frame", nil, row)
            button:SetAllPoints(arrow)
            button:EnableMouse(true)
            button:SetScript("OnMouseUp", function()
                ns.Settings.FocusRow(i)
                ns.SettingsInput.Click(what)
            end)
            row.sides[what] = button
        end
        ui.rows[i] = row
    end

    -- right column: the page that explains the focused row
    local stage = CreateFrame("Frame", nil, body, "BackdropTemplate")
    stage:SetPoint("TOPLEFT", px(614), -px(119))
    stage:SetSize(px(642), px(544))
    stage:SetBackdrop({ edgeFile = Theme.art.edgeThin, edgeSize = px(16) })
    stage:SetBackdropBorderColor(Theme.Color("paperEdge"))
    ui.stage = stage
    local paper = stage:CreateTexture(nil, "BACKGROUND")
    paper:SetTexture(Theme.art.parchment)
    paper:SetPoint("TOPLEFT", px(5), -px(5))
    paper:SetPoint("BOTTOMRIGHT", -px(5), px(5))
    local glow = Theme.Fill(stage, "BORDER", 1, 0.925, 0.73, 0.22)
    glow:SetPoint("TOPLEFT", px(40), -px(40))
    glow:SetPoint("BOTTOMRIGHT", -px(40), px(40))

    local page = CreateFrame("Frame", nil, stage)
    page:SetPoint("TOPLEFT", px(44), -px(28))
    page:SetPoint("BOTTOMRIGHT", -px(44), px(38))
    ui.page = page
    ui.pageTitle = Theme.Text(page, "head", "inkRed", true, true)
    ui.pageTitle:SetPoint("TOPLEFT")
    local rule = Theme.Fill(page, "ARTWORK", 1, 1, 1, 1)
    rule:SetHeight(px(2))
    rule:SetPoint("TOPLEFT", 0, -px(54))
    rule:SetPoint("TOPRIGHT", 0, -px(54))
    rule:SetGradient("HORIZONTAL", CreateColor(Theme.Color("inkRed", 0.85)), CreateColor(Theme.Color("inkRed", 0)))
    ui.pageText = Theme.Text(page, "row", "ink", false, true)
    ui.pageText:SetPoint("TOPLEFT", 0, -px(72))
    ui.pageText:SetPoint("TOPRIGHT", 0, -px(72))
    ui.pageText:SetWordWrap(true)
    ui.pageText:SetSpacing(px(8))
    ui.pageText:SetJustifyV("TOP")

    ui.pad = Widgets.Pad(page, px(350))
    ui.steps = {}
    for i = 1, 4 do
        local step = CreateFrame("Frame", nil, page)
        step:SetSize(px(182), px(34))
        step.dot = step:CreateTexture(nil, "ARTWORK")
        step.dot:SetTexture(Theme.art.circle)
        step.dot:SetSize(px(23), px(23))
        step.dot:SetPoint("TOPLEFT", 0, -px(4))
        step.number = step:CreateFontString(nil, "OVERLAY")
        step.number:SetFont(Theme.font.text, px(Theme.size.small), "")
        step.number:SetPoint("CENTER", step.dot)
        step.number:SetText(i)
        step.text = step:CreateFontString(nil, "OVERLAY")
        step.text:SetFont(Theme.font.text, px(Theme.size.body), "")
        step.text:SetPoint("TOPLEFT", px(34), -px(6))
        step.text:SetJustifyH("LEFT")
        step.text:SetJustifyV("TOP")
        step.text:SetWordWrap(true)
        ui.steps[i] = step
    end

    local factRule = Theme.Fill(page, "ARTWORK", Theme.Color("inkRed", 0.4))
    factRule:SetHeight(1)
    factRule:SetPoint("BOTTOMLEFT", 0, px(30))
    factRule:SetPoint("BOTTOMRIGHT", 0, px(30))
    ui.facts = Theme.Text(page, "small", "ink", false, true)
    ui.facts:SetPoint("BOTTOMLEFT", 0, px(2))

    -- the binds page takes the whole body, and so does the Profiles page: each is a tab
    ui.binds = ns.SettingsBinds and ns.SettingsBinds.Build(body) or nil
    ui.profiles = ns.SettingsProfiles and ns.SettingsProfiles.Build(body) or nil
    -- and so do My Wheels, a page under the Wheels tab, and Slot Binds, one under Fixed Slots
    ui.wheels = ns.SettingsWheels and ns.SettingsWheels.Build(body) or nil
    ui.slots = ns.SettingsSlots and ns.SettingsSlots.Build(body) or nil

    -- legend: the buttons of the page at the left, those of the row in focus at the right. A click on a
    -- button picture in it presses that button.
    local legend = CreateFrame("Frame", nil, body)
    legend:SetPoint("BOTTOMLEFT", px(24), px(12))
    legend:SetPoint("BOTTOMRIGHT", -px(24), px(12))
    legend:SetHeight(px(40))
    ui.legend = legend
    local function click(key)
        if CLICKS[key] then
            ns.SettingsInput.Click(CLICKS[key])
        end
    end
    ui.legendLeft = Widgets.Legend(legend, "LEFT", click)
    ui.legendLeft:SetPoint("LEFT")
    ui.legendRight = Widgets.Legend(legend, "RIGHT", click)
    ui.legendRight:SetPoint("RIGHT")

    win:SetScript("OnHide", function()
        dim:Hide()
        onHide()
    end)
    return win
end

-- The strip of tabs, laid out at each full draw: the names in two rows of seven, in columns, between
-- the pictures of LB and RB. LB and RB go through them row by row. The tab in view is gold and
-- has the gold line under it.
function Frames.Tabs(ui, win, state)
    local widths, gap = {}, px(30)
    for i, chapter in ipairs(state.chapters) do
        local text = ui.chapterTexts[i]
        if not text then
            text = Theme.Text(win, "row", "muted")
            ui.chapterTexts[i] = text
            -- a click on a tab's name goes to that tab
            local button = CreateFrame("Frame", nil, win)
            button:SetAllPoints(text)
            button:EnableMouse(true)
            button:SetScript("OnMouseUp", function() ns.Settings.GoChapter(i) end)
        end
        text:SetText(chapter.title or chapter.id)
        text:SetTextColor(Theme.Color(i == state.chapter and "gold" or "muted"))
        widths[i] = text:GetStringWidth()
    end
    local middles, wide = Model.TabColumns(widths, PER_ROW, gap)
    -- the strip stands in the middle of the window; one too wide for that moves right, 40 units clear of the addon's name
    local shift = math.max(0, px(24) + ui.brand:GetStringWidth() + px(40) - (px(640) - wide / 2 - gap - px(30)))
    for i, text in ipairs(ui.chapterTexts) do
        text:ClearAllPoints()
        text:SetPoint("CENTER", win, "TOP", middles[(i - 1) % PER_ROW + 1] - wide / 2 + shift, TAB_Y[math.ceil(i / PER_ROW)])
        if i == state.chapter then
            ui.chapterLine:ClearAllPoints()
            ui.chapterLine:SetPoint("TOPLEFT", text, "BOTTOMLEFT", -px(26), -px(6))
            ui.chapterLine:SetPoint("TOPRIGHT", text, "BOTTOMRIGHT", px(26), -px(6))
        end
    end
    ui.chapterLB:ClearAllPoints()
    ui.chapterLB:SetPoint("RIGHT", win, "TOP", shift - wide / 2 - gap, BAR_Y)
    ui.chapterRB:ClearAllPoints()
    ui.chapterRB:SetPoint("LEFT", win, "TOP", shift + wide / 2 + gap, BAR_Y)
end
