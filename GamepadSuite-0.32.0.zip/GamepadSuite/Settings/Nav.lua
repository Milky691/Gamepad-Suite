-- One rule for the D-pad on every page of the settings window where things lie in two dimensions
-- (the binds page, the list of binds, the ring of My Wheels): a press moves the focus to the thing
-- that lies that way on the screen, and the focus stays when nothing lies that way. It has no game
-- calls, so it can be tested outside the game. The places come from the file that draws the page
-- (Places in BindsDraw.lua, Picker.lua and WheelsDraw.lua), so the rule and the picture agree.
local _, ns = ...

local Nav = {}

-- The free room between two stretches of a line, each from its start over its size. 0 when they overlap.
local function room(a, sizeA, b, sizeB)
    return math.max(0, b - a - sizeA, a - b - sizeB)
end

-- A place along the press (x for left and right, y for up and down), or across it: its start and its size.
local function stretch(place, upDown)
    if upDown then
        return place.y, place.h
    end
    return place.x, place.w
end

-- places: the things that can have the focus, in the page's reading order:
--   { { id = , x = , y = , w = , h = }, ... }   the top left corner and the size; x grows to the right, y down
-- from: the id of the thing in focus. dx, dy: the press, one of them 1 or -1 and the other 0 (dy 1 is down).
-- A thing lies that way when
--   its middle is further that way,
--   it is clear of the thing in focus: there is room between the two that way, or they stand in one line, and
--   it is not more to the side than that way: the step to the side, from the middle of the one to the
--   nearest part of the other, is no longer than the step that way.
-- So on a ring, right of the top entry is the next entry round; under the top entry is the entry at
-- the foot, not a neighbor that is a little lower; and a wide box over the ring is "up" from the entries under it.
-- Of the things that lie that way the nearest wins, from middle to middle, and a step to the side
-- counts double. Two that are equally near: the first in the page's order.
-- Returns the id the focus goes to, or nil when nothing lies that way.
-- loose (a wheel's ring): when nothing lies that way by this rule, the nearest thing that is
-- further that way and not much more to the side (one and a half times the step that way) gets
-- the focus. So on the ring every direction moves, from the entries between the four main ones too:
-- up from the upper right entry is the top entry.
function Nav.Go(places, from, dx, dy, loose)
    local here
    for _, place in ipairs(places) do
        if place.id == from then
            here = place
        end
    end
    local best, least, near, nearest
    for _, place in ipairs(here and places or {}) do
        local a, sizeA = stretch(here, dy ~= 0)
        local b, sizeB = stretch(place, dy ~= 0)
        local c, sizeC = stretch(here, dy == 0)
        local d, sizeD = stretch(place, dy == 0)
        local midC, midD = c + sizeC / 2, d + sizeD / 2
        local along = (b + sizeB / 2 - a - sizeA / 2) * (dx + dy)
        local clear = room(a, sizeA, b, sizeB) > 0 or room(c, sizeC, d, sizeD) == 0
        local aside = math.min(room(midC, 0, d, sizeD), room(midD, 0, c, sizeC))
        local far = along + 2 * math.abs(midD - midC)
        if along > 0 and clear and aside <= along and (not least or far < least) then
            best, least = place.id, far
        end
        if loose and along > 0.5 and aside <= 1.5 * along and (not nearest or far < nearest) then
            near, nearest = place.id, far
        end
    end
    return best or near
end

if ns then
    ns.SettingsNav = Nav
end
return Nav
