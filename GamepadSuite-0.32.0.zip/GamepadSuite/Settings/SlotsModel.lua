-- The rules of the Fixed Slot Binds page, with no game calls: the lines of its list, where the focus
-- goes, and the words the page and the legend show. The list has a line for each of the eight
-- fixed slots, and Back. A on a slot opens the list of binds to choose its bind; X clears it.
-- (In the code the bind of a slot is its action, as the slot store names it.)
local _, ns = ...

local Model = {}

local BACK = "Goes back to the page you came from. B does the same."

function Model.New()
    return { line = 1 }
end

-- The lines of the list. get(n) gives the action of slot n or nil; keys(n) gives the buttons
-- that show above it ({ "RT", "A" }) or nil; unknown(n), when given, is true for a spell the
-- character does not know now (Slots.Unknown).
function Model.Lines(get, keys, most, unknown)
    local lines = {}
    for n = 1, most do
        lines[n] = { n = n, name = "Slot " .. n, action = get(n), keys = keys(n), unknown = unknown ~= nil and unknown(n) or false }
    end
    lines[#lines + 1] = { back = true, name = "Back" }
    return lines
end

-- D-pad up or down; the list wraps at its ends, as every list of the window.
function Model.Move(state, lines, step)
    local to = (state.line + step - 1) % #lines + 1
    if to == state.line then
        return false
    end
    state.line = to
    return true
end

-- The legend's words for A, X and B.
function Model.Words(state, lines)
    local line = lines[state.line]
    if line.back then
        return { a = "Back", b = "Back" }
    end
    return { a = line.action and "Change" or "Add", x = line.action and "Clear" or nil, b = "Back" }
end

-- What the parchment shows for the line in focus: { head =, text = the lead, steps = { text },
-- facts = { { label, value } }, picture = true when the slot shows as it is in the game }.
-- place(n) gives the slot's x and y; word(key) gives a button's name in words.
function Model.Panel(state, lines, place, word)
    local line = lines[state.line]
    if line.back then
        return { head = line.name, text = BACK, steps = {}, facts = {} }
    elseif not line.action then
        return {
            head = line.name, text = "This slot is empty. An empty slot does not show on the screen.", facts = {},
            steps = { "Press A to choose a bind", "On the Binds page, choose a button, then " .. line.name .. " from the list Fixed Slots",
                "On the tab Fixed Slots, move it with Slot to Move and the position rows" },
        }
    end
    local name, button = line.action.name or "This bind", nil
    if line.keys then
        local words = {}
        for i, key in ipairs(line.keys) do
            words[i] = word(key)
        end
        button = table.concat(words, " + ")
    end
    local x, y = place(line.n)
    return {
        head = line.name, picture = true, steps = {},
        text = name .. " is always in this slot: a held trigger does not change the slot. " .. (button and ("Its button is " .. button .. ".")
            or ("It has no button. A tap or a click on it works. For a button: on the Binds page, choose a button, then " .. line.name .. " from the list Fixed Slots.")),
        facts = { { "Bind", name .. (line.unknown and " (not known now)" or "") }, { "Button", button or "None" }, { "Position", x .. ", " .. y } },
    }
end

if ns then
    ns.SettingsSlotsModel = Model
end
return Model
