-- The My Wheels page of the settings window, with no game calls, so it can be tested outside the
-- game. The player makes wheels of their own here. The page has two levels.
-- Level 1 is the list on the left: the player's wheels, then "New Wheel" and "Back". Up and down
-- move in it. A on a wheel, or on New Wheel, goes into it ("Open"); B goes back with the window.
-- Level 2 is inside one wheel: its name box and its ring. The ring always has eight slots, each
-- with its own direction. A slot holds a bind, or it is empty and shows a plus. Here the D-pad
-- moves by place: the page asks Settings/Nav.lua which stop lies that way, with the places of
-- WheelsDraw.lua, so on the ring a press goes to the slot that lies that way. A on a slot opens
-- the list where a bind is chosen, so the player chooses the direction of each bind; A on the
-- name box changes the name; X clears the slot in focus; B goes back to the list.
-- A wheel is made when its first bind is chosen, and it goes with its last bind. In the game only
-- the slots with a bind show.
-- rules is Core/WheelRules.lua: MOST (8, the slots of a wheel) and MOST_OWN (5).
local _, ns = ...

local Model = {}

-- State: the line of the list; inside is true at level 2, with id the wheel the player is in
-- (nil in New Wheel) and place the stop of that wheel that has the focus.
function Model.New()
    return { line = 1, place = 1, inside = false }
end

-- The lines of the list: the player's wheels ({ id, name, slots }), then "New Wheel" while
-- there is room for one more, then "Back" (A on it does what B does).
function Model.Lines(wheels, rules)
    local lines = {}
    for i, wheel in ipairs(wheels) do
        lines[i] = { id = wheel.id, name = wheel.name, slots = wheel.slots }
    end
    if #wheels < rules.MOST_OWN then
        lines[#lines + 1] = { new = true, name = "New Wheel", slots = {} }
    end
    lines[#lines + 1] = { back = true, name = "Back", slots = {} }
    return lines
end

-- The stops of a line: the eight slots ({ kind = "slot", index = }), then the name box of a
-- saved wheel ({ kind = "name" }). New Wheel has the slots and no name yet. Back has no stop.
function Model.Stops(line, rules)
    local stops = {}
    if line.back then
        return stops
    end
    for i = 1, rules.MOST do
        stops[i] = { kind = "slot", index = i }
    end
    if not line.new then
        stops[#stops + 1] = { kind = "name" }
    end
    return stops
end

-- How many slots of a line hold a bind, and the first of those binds (the wheel's picture).
function Model.Count(line, rules)
    local count, first = 0, nil
    for i = 1, rules.MOST do
        if line.slots[i] then
            count = count + 1
            first = first or line.slots[i]
        end
    end
    return count, first
end

-- Keeps the focus on what is there, after the list changed. Inside a wheel the focus follows
-- that wheel. A wheel that went with its last bind leaves the player in New Wheel, on the same
-- slot: the ring they see is empty now.
function Model.Fit(state, lines, rules)
    if state.inside then
        local same, new
        for i, line in ipairs(lines) do
            same = state.id ~= nil and line.id == state.id and i or same
            new = line.new and i or new
        end
        state.id = same and state.id or nil
        state.line, state.inside = same or new or state.line, (same or new) ~= nil
    end
    state.line = math.max(1, math.min(state.line, #lines))
    state.place = math.max(1, math.min(state.place, #Model.Stops(lines[state.line], rules)))
end

-- D-pad up or down at level 1: the list wraps at its ends, as every list of the window.
-- Returns false inside a wheel, where the D-pad goes by place (FocusOn).
function Model.Move(state, lines, step)
    if state.inside or step == 0 then
        return false
    end
    state.line = (state.line - 1 + step) % #lines + 1
    return true
end

-- A on a wheel or on New Wheel at level 1: the player is inside it, on its top slot.
-- Returns false on Back.
function Model.Enter(state, lines)
    local line = lines[state.line]
    if line.back then
        return false
    end
    state.inside, state.id, state.place = true, line.id, 1
    return true
end

-- B inside a wheel: back to the list, on that wheel. Returns false at level 1, where B is the window's.
function Model.Back(state)
    local was = state.inside
    state.inside = false
    return was
end

-- What has the focus: the line, its stop (nil at level 1), and the bind when the stop is a slot
-- that holds one.
function Model.Focus(state, lines, rules)
    local line = lines[state.line]
    local stop = state.inside and Model.Stops(line, rules)[state.place] or nil
    return line, stop, stop and stop.kind == "slot" and line.slots[stop.index] or nil
end

-- The stop in focus as the page's places name it (WheelsDraw.lua Places): "name", or the number
-- of a slot. nil at level 1.
function Model.At(state, lines, rules)
    local _, stop = Model.Focus(state, lines, rules)
    return stop and (stop.index or "name")
end

-- Puts the focus on a stop of the line in focus: "name", or a slot by its number. For the D-pad
-- inside a wheel and for the mouse, which goes into the wheel this way. Returns true when the
-- focus changed.
function Model.FocusOn(state, lines, rules, id)
    local line = lines[state.line]
    for i, stop in ipairs(Model.Stops(line, rules)) do
        if (stop.index or "name") == id then
            local changed = not state.inside or state.place ~= i
            state.inside, state.id, state.place = true, line.id, i
            return changed
        end
    end
    return false
end

-- Where a chosen bind goes: the wheel (nil for "New Wheel", which is made then) and the slot in
-- focus. Gives nothing on the name box and at level 1.
function Model.Target(state, lines, rules)
    local line, stop = Model.Focus(state, lines, rules)
    if stop and stop.kind == "slot" then
        return not line.new and line.id or nil, stop.index
    end
end

-- After a bind went onto a wheel: the player is inside that wheel, on that slot.
function Model.Chose(state, lines, id, slot)
    for i, line in ipairs(lines) do
        if line.id == id then
            state.line = i
        end
    end
    state.inside, state.id, state.place = true, id, slot
end

-- After a pick the list stays open for the next empty slot after `after`, clockwise and round
-- past slot 8, until B. nil when the wheel is full: the list closes then.
function Model.NextEmpty(slots, after, rules)
    for step = 1, rules.MOST - 1 do
        local slot = (after + step - 1) % rules.MOST + 1
        if not slots[slot] then
            return slot
        end
    end
    return nil
end

-- The words after the list's title: which slot of which wheel it is for ("the right slot of
-- Wheel 1"). Slot 1 is at the top, then clockwise.
local SLOT_WORDS = { "top", "top right", "right", "bottom right", "bottom", "bottom left", "left", "top left" }
function Model.ListFor(name, slot)
    return "the " .. SLOT_WORDS[slot] .. " slot of " .. name
end

-- The mark of an entry of the list that is on this wheel already, or nil.
function Model.Mark(slots, entry, rules)
    for i = 1, rules.MOST do
        local bind = slots[i]
        if bind and bind.kind == entry.kind and bind.id == entry.id then
            return "In this wheel"
        end
    end
    return nil
end

-- The two lines of text in the middle of the ring: the name of the bind in the slot in focus
-- ("Add a bind" on an empty slot, nothing on the name box and at level 1), and how many slots
-- hold a bind ("5 of 8 slots"). One word each: a slot is the place, a bind is what is in it.
-- why(bind) gives why a bind cannot run now (Core/WheelsNow.lua Why), or nil: its slot reads "Cannot run now: ..."
-- in place of the name, as the game leaves it off the ring.
function Model.Middle(state, lines, rules, why)
    local line, stop, bind = Model.Focus(state, lines, rules)
    local cannot = bind and why and why(bind)
    local text = cannot and "Cannot run now: " .. cannot or bind and bind.name or stop and stop.kind == "slot" and "Add a bind" or ""
    return text, Model.Count(line, rules) .. " of " .. rules.MOST .. " slots"
end

-- The legend's words for A, X and B.
function Model.Words(state, lines, rules)
    local line, stop, bind = Model.Focus(state, lines, rules)
    local words = { b = "Back" }
    if not stop then
        -- (A on New Wheel goes into an empty wheel: the wheel is made when its first entry is chosen)
        words.a = line.back and "Back" or "Open"
    elseif stop.kind == "name" then
        words.a = "Rename"
    elseif bind then
        words.a, words.x = "Change", "Clear"
    else
        words.a = "Add"
    end
    return words
end

if ns then
    ns.SettingsWheelsModel = Model
end
return Model
