-- The rules of the settings search, with no game calls, so they can be tested outside the game:
-- which rows a text finds, how well, in which order, and the pages of the results. Settings/Search.lua
-- runs them in slices and puts the results on the window's rows.
local _, ns = ...

-- LEAST: the letters a search needs. MOST: the letters the search line takes. ROOM: the rows under it.
local Model = { LEAST = 2, MOST = 30, ROOM = 5 }

local function lower(text)
    return (text or ""):lower()
end

-- The text as the search reads it: no spaces at the ends, one space between words, lower case.
-- nil when it has fewer than LEAST letters.
function Model.Clean(text)
    text = lower(text):gsub("%s+", " "):match("^ ?(.-) ?$")
    return #text >= Model.LEAST and text or nil
end

-- A text the player typed, as a line of the game shows it: a bar is a bar, not the start of a color.
function Model.Plain(text)
    return (text:gsub("|", "||"))
end

-- The edit distance of a and b: the fewest letters to change, add or take away to make one the
-- other. nil when it is over most: the count stops as soon as every way is over it.
function Model.Distance(a, b, most)
    if math.abs(#a - #b) > most then
        return nil
    end
    local last = {}
    for j = 0, #b do
        last[j] = j
    end
    for i = 1, #a do
        local now, least, letter = { [0] = i }, i, a:byte(i)
        for j = 1, #b do
            now[j] = math.min(last[j] + 1, now[j - 1] + 1, last[j - 1] + (letter == b:byte(j) and 0 or 1))
            least = math.min(least, now[j])
        end
        if least > most then
            return nil
        end
        last = now
    end
    return last[#b] <= most and last[#b] or nil
end

-- How many letters a misspelt name may have wrong: none under 4 letters (two or three letters
-- would find every short word), one up to 5, two from 6.
function Model.Slack(text)
    return #text >= 6 and 2 or #text >= 4 and 1 or 0
end

local function add(list, place)
    place.lname, place.lsum, place.ltext, place.lwhere = lower(place.name), lower(place.sum), lower(place.text), lower(place.where)
    place.words = {}
    for word in place.lname:gmatch("%S+") do
        place.words[#place.words + 1] = word
    end
    list[#list + 1] = place
end

-- Every place the search can find, in the window's order: each row of each tab and of each page
-- under a row (a row on two pages once, where it first stands), and each tab that draws its own
-- page (Binds, Profiles). Not a Back row, not the Search tab, not the steps of a guided page.
-- Each place has the way to it: tab (its number), path (the pages opened on the way, each
-- { page =, at = the row that opened it }) and at (its row); where (its tab and page, for the small
-- type of a result) and group (its tab: a slice looks at whole tabs).
function Model.Entries(chapters)
    local list, seen = {}, {}
    local function walk(rows, tab, path, where)
        for at, row in ipairs(rows) do
            if not seen[row] and row.kind ~= "back" then
                seen[row] = true
                add(list, { row = row, name = row.name, sum = row.sum, text = row.text, where = where, tab = tab, path = path, at = at, group = tab })
                local page = row.sub
                if page and not page.guide then
                    local deeper = {}
                    for i, step in ipairs(path) do
                        deeper[i] = step
                    end
                    deeper[#deeper + 1] = { page = page, at = at }
                    walk(page.rows, tab, deeper, where .. ", " .. (page.title or row.name))
                end
            end
        end
    end
    for tab, chapter in ipairs(chapters) do
        local title = chapter.title or chapter.id
        if chapter.binds or chapter.profiles then
            add(list, { name = title, sum = "The " .. title .. " tab.", where = "Tab", tab = tab, path = {}, at = 1, group = tab })
        elseif not chapter.search then
            walk(chapter.rows, tab, {}, title)
        end
    end
    return list
end

-- A search of a clean text (Model.Clean). It is run by Model.Step.
function Model.Start(text)
    local words = {}
    for word in text:gmatch("%S+") do
        words[#words + 1] = word
    end
    return { text = text, words = words, slack = Model.Slack(text), at = 1, found = {} }
end

local function allIn(words, name)
    for _, word in ipairs(words) do
        if not name:find(word, 1, true) then
            return false
        end
    end
    return #words > 1
end

-- How well a place matches a search: 1 is best, nil is no match. Plain finds (no Lua patterns from
-- the player's text) come first; the edit distance is last, and only for a place no find took.
--   1 the name starts with the text      2 a word of the name does   3 the name has it, or every typed word
--   4 the line under the name has it     5 the page text does        6 the name of its tab or page does
--   7 or 8 the name with one or two letters wrong (the typed words against as many words of the name)
function Model.Score(place, search)
    local text = search.text
    local at = place.lname:find(text, 1, true)
    if at == 1 then
        return 1
    elseif (" " .. place.lname):find(" " .. text, 1, true) then
        return 2
    elseif at or allIn(search.words, place.lname) then
        return 3
    elseif place.lsum:find(text, 1, true) then
        return 4
    elseif place.ltext:find(text, 1, true) then
        return 5
    elseif place.lwhere:find(text, 1, true) then
        return 6
    end
    local best, count = nil, #search.words
    for i = 1, search.slack > 0 and #place.words - count + 1 or 0 do
        best = Model.Distance(text, table.concat(place.words, " ", i, i + count - 1), best and best - 1 or search.slack) or best
    end
    return best and 6 + best or nil
end

-- One slice of a search: the places of one tab, then of more tabs while more() says there is time.
-- The results so far are in search.found, best first, a tie in the window's order: { entry =, score = }.
-- search.done is true when every place was looked at; it is also the answer.
function Model.Step(search, entries, more)
    repeat
        local group = entries[search.at] and entries[search.at].group
        while entries[search.at] and entries[search.at].group == group do
            local score = Model.Score(entries[search.at], search)
            if score then
                search.found[#search.found + 1] = { entry = entries[search.at], score = score, order = search.at }
            end
            search.at = search.at + 1
        end
    until not entries[search.at] or not more()
    table.sort(search.found, function(a, b)
        return a.score < b.score or (a.score == b.score and a.order < b.order)
    end)
    search.done = entries[search.at] == nil
    return search.done
end

-- The pages of count results, room rows each, as on Profiles: Previous is the first row of every
-- page but the first, Next the last row of every page but the last. Each page: { first, count,
-- previous, next }. No results: one empty page.
function Model.Pages(count, room)
    local pages, first = {}, 1
    repeat
        local previous = #pages > 0
        local space = room - (previous and 1 or 0)
        if count - first + 1 > space then
            space = space - 1
        end
        local shown = math.min(space, count - first + 1)
        pages[#pages + 1] = { first = first, count = shown, previous = previous, next = first + shown <= count }
        first = first + shown
    until first > count
    return pages
end

-- The line under the tab's title. typed: what the player typed; search: the search of it (nil
-- when it is too short); page of pages: the results in view. nil: the tab keeps its own line.
function Model.Line(typed, search, page, pages)
    typed = (typed or ""):match("^%s*(.-)%s*$")
    if typed == "" then
        return nil
    elseif not search then
        return "Type two letters or more."
    end
    local quoted = '"' .. Model.Plain(typed) .. '"'
    if not search.done then
        return "Searching for " .. quoted .. "."
    elseif #search.found == 0 then
        return "Nothing found for " .. quoted .. "."
    end
    local line = "Found " .. #search.found .. " for " .. quoted .. "."
    return pages > 1 and line .. " Page " .. page .. " of " .. pages .. "." or line
end

if ns then
    ns.SettingsSearchModel = Model
end
return Model
