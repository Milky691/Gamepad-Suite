-- The Search tab of the settings window. The player types a name on the search line (its first row),
-- and the rows of every tab and page that have it show under that line, best first, five at a time
-- with Next and Previous. A on a result goes to that row in its own tab and page; B there comes back.
-- The rules are in SearchModel.lua and Model.lua (Go, Back); the window draws the rows on its own
-- grid, and the parchment explains the result in focus.
-- The search runs in slices of 4 ms, one frame after the other, only while a search is in progress
-- (ConsolePort draws its results in slices of the same size: ConsolePort_Config, Renderer.lua 10).
local _, ns = ...

local Model, Theme = ns.SettingsSearchModel, ns.Theme
local px = Theme.px

local Search = {}
ns.SettingsSearch = Search

local BUDGET = 4    -- milliseconds of one slice
local typed = ""    -- what the player typed
local entries       -- every place the search can find: made at the first search, after the window took out the rows this build lacks
local search        -- the search in view, in progress or done; nil when the text is too short
local page = 1      -- the page of the results in view
local made = {}     -- the row of each result, made once for each place
local base          -- the tab's own line, for no search
local box, typing   -- the text box for a real keyboard, and true while it is open
local told = {}     -- the log lines of this session, each once

local function tab()
    for _, chapter in ipairs(ns.SettingsData) do
        if chapter.search then
            return chapter
        end
    end
end

local function note(what, text)
    if not told[what] then
        told[what] = true
        ns.Log.Add("search", text)
    end
end

local turn

-- The rows that go to another page by their own run: each has the arrow its way says (Model.Nav).
local NEXT = { name = "Next", kind = "run", action = "Next", way = "next", sum = "More results.", steps = {}, facts = {}, run = function() return turn(1) end }
local PREVIOUS = { name = "Previous", kind = "run", action = "Previous", way = "back", sum = "The results before these.", steps = {}, facts = {}, run = function() return turn(-1) end }

-- A on a result: the window goes to its row (Model.Go) and draws itself.
local function go(entry)
    ns.SettingsModel.Go(ns.Settings.State(), entry)
    ns.Adapter.Sound("IG_MAINMENU_OPTION")
    ns.SettingsDraw.All(true)
    note("go", "A on a result went to " .. entry.where .. ", " .. entry.name)
    return true
end

-- The row of a result: the name, line, text, steps and facts of the row it stands for, the gold arrow,
-- and its tab and page in small type.
local function result(entry)
    local row = made[entry]
    if not row then
        local of = entry.row or entry
        row = { name = entry.name, sum = entry.sum, text = of.text, steps = of.steps, facts = of.facts, where = entry.where,
                kind = "run", action = "Go there", way = "next", run = function() return go(entry) end }
        made[entry] = row
    end
    return row
end

-- The rows of the tab: the search line, then the page of results in view; and the line under the title.
local function fill()
    local chapter = tab()
    base = base or chapter.line
    local found = search and search.found or {}
    local pages = Model.Pages(#found, Model.ROOM)
    page = math.max(1, math.min(page, #pages))
    local shown, rows = pages[page], { chapter.rows[1] }
    if shown.previous then
        rows[#rows + 1] = PREVIOUS
    end
    for i = shown.first, shown.first + shown.count - 1 do
        rows[#rows + 1] = result(found[i].entry)
    end
    if shown.next then
        rows[#rows + 1] = NEXT
    end
    for i = 1, math.max(#rows, #chapter.rows) do
        chapter.rows[i] = rows[i]
    end
    NEXT.text = ("Shows the next results. This is page %d of %d."):format(page, #pages)
    PREVIOUS.text = ("Shows the results before these. This is page %d of %d."):format(page, #pages)
    chapter.line = Model.Line(typed, search, page, #pages) or base
end

-- The rows again, when the Search tab is in view; the parchment too when the row in focus is another one.
local function redraw()
    local S, Rules = ns.Settings, ns.SettingsModel
    local state = S.State()
    if not (S.IsOpen() and Rules.Page(state) == tab()) then
        return
    end
    local before = Rules.Row(state)
    state.row = math.min(state.row, #tab().rows)
    ns.SettingsDraw.Values()
    if Rules.Row(state) ~= before then
        ns.SettingsDraw.Page()
    end
end

-- The game's clock in milliseconds (FrameScriptDocumentation.lua 533). With none, one slice does all.
local function now()
    return debugprofilestop and debugprofilestop() or 0
end

-- One slice: places for 4 ms, at least one tab. The next slice comes one frame later, and only
-- while this search is the one in view.
local function slice()
    local mine, deadline = search, now() + BUDGET
    mine.slices = mine.slices + 1
    Model.Step(mine, entries, function() return now() < deadline end)
    fill()
    redraw()
    if not mine.done then
        C_Timer.After(0, function()
            if search == mine then
                slice()
            end
        end)
    else
        note("slices", ("the first search looked at %d places in %d slices of %d ms and found %d"):format(#entries, mine.slices, BUDGET, #mine.found))
    end
end

-- Searches for a text: the player typed it. The focus stays where it is (the search line).
function Search.Find(text)
    typed = (text or ""):match("^%s*(.-)%s*$"):sub(1, Model.MOST)
    local clean = Model.Clean(typed)
    page, search = 1, nil
    if clean then
        entries = entries or Model.Entries(ns.SettingsData)
        search = Model.Start(clean)
        search.slices = 0
        slice()
    else
        fill()
        redraw()
    end
end

-- A on Next or Previous. The focus stays on Next or Previous when the new page has it; else it
-- goes to the first result (after Next) or the last one (after Previous).
function turn(step)
    page = page + step
    fill()
    local rows, state = tab().rows, ns.Settings.State()
    if step > 0 then
        state.row = rows[#rows] == NEXT and #rows or 3
    else
        state.row = rows[2] == PREVIOUS and 2 or #rows - 1
    end
    ns.Adapter.Sound("IG_MAINMENU_OPTION")
    ns.SettingsDraw.All(true)
    return true
end

-- The typed text at the right of the search line (none while the text box shows it).
function Search.Text()
    return typing and "" or Model.Plain(typed)
end

-- The typing in the text box ends: with a text, it is searched; with none, the old search stays.
local function stopTyping(text)
    if not typing then
        return
    end
    typing = false
    box:ClearFocus()
    box:Hide()
    if text then
        Search.Find(text)
    else
        redraw()
    end
end

-- No on-screen keyboard: a text box on the search line takes a real keyboard, the text selected. A
-- click on it gives it the keyboard's focus; the addon moves no focus itself (as on My Wheels).
local function startTyping()
    if not box then
        box = CreateFrame("EditBox", nil, ns.SettingsDraw.ui.rows[1])
        box:SetPoint("TOPLEFT", px(160), -px(14))
        box:SetPoint("BOTTOMRIGHT", -px(14), px(14))
        Theme.Fill(box, "BACKGROUND", 0, 0, 0, 0.62):SetAllPoints()
        ns.SettingsWheelsDraw.Outline(box, 1, 3, Theme.Color("gold"))
        box:SetAutoFocus(false)
        box:SetFont(Theme.font.text, px(Theme.size.name), "")
        box:SetTextColor(Theme.Color("cream"))
        box:SetTextInsets(px(12), px(12), 0, 0)
        box:SetMaxLetters(Model.MOST)
        box:SetScript("OnEnterPressed", function(self) stopTyping(self:GetText()) end)
        box:SetScript("OnEditFocusLost", function(self) stopTyping(self:GetText()) end)
        box:SetScript("OnEscapePressed", function() stopTyping(nil) end)
    end
    typing = true
    box:SetText(typed)
    box:Show()
    box:HighlightText()
end

-- A on the search line (its run in Settings/Data.lua). Our on-screen keyboard asks for the text, as
-- for a wheel's name; Done searches, Cancel keeps the old search.
function Search.Type()
    local asked = ns.Keyboard and ns.Keyboard.on and ns.Keyboard.Ask("Search", typed, Model.MOST, Search.Find)
    if not asked then
        startTyping()
    end
    note("type", "A on the search line: " .. (asked and "the on-screen keyboard was asked" or "no on-screen keyboard, the box takes a real keyboard"))
end

-- True while the text box is open: every button is the box's then, and B ends the typing. With no
-- button given, this only says if it is open (Settings.Typing).
function Search.Typing(what)
    if not typing then
        return false
    end
    if what == "B" then
        stopTyping(box:GetText())
    end
    return true
end

-- The legend while the text box is open: B searches, the other buttons are the box's.
function Search.Words()
    return typing and { typing = true, pad = {}, b = "Search" } or nil
end

-- A tab change or a close of the window: the text in the box is searched.
function Search.Leave()
    if typing then
        stopTyping(box:GetText())
    end
end
