-- The Fixed Slot Binds page of the settings window: what each button does on it. The player chooses
-- here what each fixed slot holds. The rules are in SlotsModel.lua, the frames in SlotsDraw.lua,
-- the slots in the store (Core/Slots.lua). A on a slot opens the list to choose a bind
-- (Picker.lua), which takes the page's place while it is open; X takes the action off the slot.
-- A slot's button is given on the Binds page: the slot is in the list of binds by itself.
local _, ns = ...

local Model, Rules, Store, Picker, Draw = ns.SettingsSlotsModel, ns.SlotRules, ns.Slots, ns.SettingsPicker, ns.SettingsSlotsDraw

local Page = {}
ns.SettingsSlots = Page

local frame, body
local state = Model.New()
local lines  -- the lines of the list now, made again at each draw
local target -- the slot the chosen bind goes on

local function word(key)
    return ns.SettingsBindsDraw.NAMES[key] or key
end

function Page.Draw()
    lines = Model.Lines(Store.Get, Store.Keys, Rules.MOST, Store.Unknown)
    Draw.Page(lines, state.line, Model.Panel(state, lines, Store.Place, word))
end

-- After an action on this page: draw it again, and the legend, because its words follow the focus.
local function redraw(sound)
    ns.Adapter.Sound(sound)
    if not Picker.IsOpen() then
        Page.Draw()
    end
    ns.SettingsDraw.Legend()
end

-- The list closes and the page shows again.
local function closeList()
    Picker.Close()
    body:Show()
    redraw("IG_MAINMENU_OPTION")
end

-- True while the list to choose a bind is open.
function Page.ListOpen()
    return Picker.IsOpen()
end

-- D-pad: up and down in the list of slots, or in the list of binds.
function Page.Move(dy, dx)
    if Picker.IsOpen() then
        if Picker.Move(dy, dx) then
            ns.Adapter.Sound("U_CHAT_SCROLL_BUTTON")
            ns.SettingsDraw.Legend()
        end
    elseif dy ~= 0 and Model.Move(state, lines, dy) then
        redraw("U_CHAT_SCROLL_BUTTON")
    end
end

-- LB or RB while the list of binds is open: the list before or after.
function Page.ChangeList(step)
    Picker.ChangeList(step)
    ns.Adapter.Sound("IG_CHARACTER_INFO_TAB")
    ns.SettingsDraw.Legend()
end

-- A. On a slot: open the list of binds. In the list: open a More entry, or put the entry on the
-- slot the list was opened for. On the Back line "back" comes back, and the window goes back.
function Page.Press()
    if Picker.IsOpen() then
        local entry = Picker.Choose()
        if entry then
            Store.Set(target, entry)
            closeList()
        else
            redraw("IG_MAINMENU_OPTION")
        end
        return
    end
    local line = lines[state.line]
    if line.back then
        return "back"
    end
    -- the slot is kept now, so the entry lands on it whatever happens while the list is open
    target = line.n
    if Picker.Open(line.name, frame, Rules.Offer(ns.Catalog.Build())) then
        body:Hide()
        redraw("IG_MAINMENU_OPTION")
    end
end

-- X: take the action off the slot in focus.
function Page.Clear()
    local line = lines[state.line]
    if not Picker.IsOpen() and line.action then
        Store.Clear(line.n)
        redraw("IG_MAINMENU_OPTION")
    end
end

-- B: true when it went back in the list of binds or closed it, so the page stays.
function Page.Back()
    if not Picker.IsOpen() then
        return false
    end
    if Picker.Back() then
        redraw("IG_MAINMENU_OPTION")
    else
        closeList()
    end
    return true
end

-- A tab change or a close of the window: the list of binds closes.
function Page.Leave()
    if body and not body:IsShown() then
        Picker.Close()
        body:Show()
    end
end

-- The legend words right now. With the list open: list names LB / RB, and A chooses or opens.
function Page.Words()
    if Picker.IsOpen() then
        return { list = "List", a = Picker.Word(), b = "Back" }
    end
    return Model.Words(state, lines)
end

local mouse = {
    -- hover on a line gives it the focus when the mouse moved there; a click gives it at once
    Focus = function(index, clicked)
        if index ~= state.line and lines[index] and (clicked or ns.Adapter.MouseMoved()) then
            state.line = index
            redraw("U_CHAT_SCROLL_BUTTON")
        end
    end,
    Press = function() ns.SettingsInput.Click("A") end,
    Clear = function() ns.SettingsInput.Click("X") end,
}

function Page.Build(win)
    frame, body = Draw.Build(win, mouse, Rules.MOST)
    return frame
end
