-- The parchment of a page that draws itself and has text on it (Profiles, Slot Binds), as every
-- page of the window has it (Settings/Frames.lua): the title, one rule, the lead, numbered steps,
-- and the facts at the foot over a thin line. One step is lit at a time and the light goes to the
-- next one by itself, as on the other pages (Settings/Draw.lua).
-- The text is a column in the middle of the parchment: this parchment is wider than on the other
-- tabs, and so is the dark band at each of its sides.
local _, ns = ...

local Theme = ns.Theme
local px = Theme.px

local Paper = { X = 151, MEASURE = 620, STEP = 46 }
ns.SettingsPaper = Paper

-- A numbered step under the lead.
local function stepLine(page, lead, i)
    local step = CreateFrame("Frame", nil, page)
    step:SetSize(px(Paper.MEASURE), px(34))
    step:SetPoint("TOPLEFT", lead, "BOTTOMLEFT", 0, -px(34 + (i - 1) * Paper.STEP))
    step.dot = step:CreateTexture(nil, "ARTWORK")
    step.dot:SetTexture(Theme.art.circle)
    step.dot:SetSize(px(23), px(23))
    step.dot:SetPoint("TOPLEFT", 0, -px(4))
    step.number = step:CreateFontString(nil, "OVERLAY")
    step.number:SetFont(Theme.font.text, px(Theme.size.small), "")
    step.number:SetPoint("CENTER", step.dot)
    step.number:SetText(i)
    step.text = step:CreateFontString(nil, "OVERLAY")
    step.text:SetFont(Theme.font.text, px(Theme.size.body), "")
    step.text:SetPoint("TOPLEFT", px(34), -px(6))
    return step
end

-- Builds the parchment in a page's frame, from `left` to the frame's right edge. Gives
-- { page = the frame of the text column, lead = the lead text, Show = , Stop = }.
function Paper.Build(frame, left)
    local stage = CreateFrame("Frame", nil, frame, "BackdropTemplate")
    stage:SetPoint("TOPLEFT", px(left), 0)
    stage:SetPoint("BOTTOMRIGHT")
    stage:SetBackdrop({ edgeFile = Theme.art.edgeThin, edgeSize = px(16) })
    stage:SetBackdropBorderColor(Theme.Color("paperEdge"))
    local art = stage:CreateTexture(nil, "BACKGROUND")
    art:SetTexture(Theme.art.parchment)
    art:SetPoint("TOPLEFT", px(5), -px(5))
    art:SetPoint("BOTTOMRIGHT", -px(5), px(5))
    local glow = Theme.Fill(stage, "BORDER", 1, 0.925, 0.73, 0.22)
    glow:SetPoint("TOPLEFT", px(40), -px(40))
    glow:SetPoint("BOTTOMRIGHT", -px(40), px(40))
    local page = CreateFrame("Frame", nil, stage)
    page:SetPoint("TOPLEFT", px(Paper.X), -px(28))
    page:SetPoint("BOTTOMRIGHT", -px(Paper.X), px(38))
    local head = Theme.Text(page, "head", "inkRed", true, true)
    head:SetPoint("TOPLEFT")
    local rule = Theme.Fill(page, "ARTWORK", 1, 1, 1, 1)
    rule:SetHeight(px(2))
    rule:SetPoint("TOPLEFT", 0, -px(54))
    rule:SetPoint("TOPRIGHT", 0, -px(54))
    rule:SetGradient("HORIZONTAL", CreateColor(0.24, 0.06, 0.02, 0.85), CreateColor(0.24, 0.06, 0.02, 0))
    local lead = Theme.Text(page, "row", "ink", false, true)
    lead:SetPoint("TOPLEFT", 0, -px(72))
    lead:SetWidth(px(Paper.MEASURE))
    lead:SetJustifyH("LEFT")
    lead:SetJustifyV("TOP")
    lead:SetWordWrap(true)
    lead:SetSpacing(px(8))
    local steps = {}
    for i = 1, 3 do
        steps[i] = stepLine(page, lead, i)
    end
    local factRule = Theme.Fill(page, "ARTWORK", 0.24, 0.06, 0.02, 0.4)
    factRule:SetHeight(1)
    factRule:SetPoint("BOTTOMLEFT", 0, px(30))
    factRule:SetPoint("BOTTOMRIGHT", 0, px(30))
    local facts = Theme.Text(page, "small", "ink", false, true)
    facts:SetPoint("BOTTOMLEFT", 0, px(2))

    local ticker, count, at = nil, 0, 0
    -- the lit step is full ink with a red dot, the others are faint
    local function light()
        at = at % math.max(count, 1) + 1
        for i, step in ipairs(steps) do
            local lit = i == at
            step.dot:SetVertexColor(Theme.Color(lit and "inkRed" or "ink", lit and 1 or 0.25))
            step.number:SetTextColor(Theme.Color(lit and "cream" or "ink", lit and 1 or 0.8))
            step.text:SetTextColor(Theme.Color("ink", lit and 1 or 0.66))
        end
    end
    local paper = { page = page, lead = lead }
    function paper.Stop()
        if ticker then
            ticker:Cancel()
            ticker = nil
        end
    end
    -- panel = { head =, text = the lead, steps = { text }, facts = { { label, value } } }. With
    -- noSteps the steps do not show: a text box or a picture has their place.
    function paper.Show(panel, noSteps)
        head:SetText(panel.head)
        lead:SetText(panel.text)
        for i, step in ipairs(steps) do
            local text = not noSteps and panel.steps[i]
            step:SetShown(text and true or false)
            step.text:SetText(text or "")
        end
        paper.Stop()
        count, at = noSteps and 0 or #panel.steps, 0
        light()
        if count > 1 then
            ticker = C_Timer.NewTicker(1.5, light)
        end
        local parts = {}
        for i, fact in ipairs(panel.facts) do
            parts[i] = fact[1] .. "  " .. fact[2]
        end
        facts:SetText(table.concat(parts, "        "))
    end
    frame:HookScript("OnHide", paper.Stop)
    return paper
end
