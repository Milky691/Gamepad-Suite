-- Spell binds that move up to a new rank (decision 24): the rules, with no game calls.
-- When the character learns a new rank, the rank that was the highest before moves up to it. A
-- lower rank was chosen on purpose (a down-ranked heal) and stays. Core/RankUp.lua does the moving.
local _, ns = ...

local Rules = {}

-- A learned spell that takes the place of another spell of another name. The game's own flyout
-- counts Dire Bear Form as the next rank of Bear Form (Blizzard_ActionBar/Shared/SpellFlyout.lua
-- 6-7, 321-325), and the form sets of the binds treat them as one (Core/Adapter.lua SAME_FORM).
Rules.NEXT = { [9634] = 5487 }

-- The rank in the game's text for it: "Rank 4" is 4, "Rang 4" too. nil for a spell with no rank
-- ("", "Racial", "Shapeshift", a profession's "Apprentice").
function Rules.Number(text)
    return type(text) == "string" and tonumber(text:match("^%D+(%d+)$")) or nil
end

-- known: the spells the character knows now, { { id, name, rank = the game's text } }.
-- learned: { [spell id] = true }, the spells the game just said were learned.
-- Gives { [old id] = new id }: for each spell, its highest rank before the learn moves to its
-- highest rank now. Before is now without the learned ones, so several ranks at one trainer
-- visit (4 and 5) move the old highest (3) straight to 5, whatever order the game tells them in.
function Rules.Moves(known, learned)
    local before, now = {}, {}
    local function top(list, spell, rank)
        local best = list[spell.name]
        if not best or rank > best.rank then
            list[spell.name] = { id = spell.id, rank = rank }
        end
    end
    for _, spell in ipairs(known) do
        local rank = Rules.Number(spell.rank)
        if rank then
            top(now, spell, rank)
            if not learned[spell.id] then
                top(before, spell, rank)
            end
        end
    end
    local moves = {}
    for name, best in pairs(now) do
        local was = before[name]
        if was and best.rank > was.rank then
            moves[was.id] = best.id
        end
    end
    for new, old in pairs(Rules.NEXT) do
        if learned[new] then
            moves[old] = new
        end
    end
    return moves
end

if ns then
    ns.RankUpModel = Rules
end
return Rules
