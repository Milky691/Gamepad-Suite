-- The adapter, part 10: what the two camera zooms ask the game. Stick Zoom (Screen/Zoom.lua) zooms
-- with the right stick; Auto Camera Zoom (Screen/AutoZoom.lua) zooms by itself in a fight, at an
-- NPC, on a mount, on a flight path and indoors. The game's own gamepad code zooms the camera with the same two calls, once a frame, from
-- the right stick (Blizzard_GamepadTargeting/TargetLogic.lua 78 to 84).
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- True while the automatic zoom makes its own call: that call is no zoom by the player's hand.
local own = false

-- The game zooms by no less than 0.05 yards in one call (DynamicCam's LibCamera.lua 292 to 293):
-- a smaller call is lost. The stick asks for less than that in one frame when it is pushed a
-- little, or the game draws many frames a second. So a smaller ask waits here and goes with the
-- next one; the camera moves by all that was asked, whatever the game does with small calls.
local SMALLEST = 0.05
local owed = 0

-- Zooms the camera by a number of yards: in when it is above 0, out when it is below 0. True when
-- the game took the call (or the ask waits for the next one). When it did not, the second value is
-- what the game said. auto is true for a call of the automatic zoom.
function Adapter.CameraZoom(amount, auto)
    if not results().cameraZoom then
        return false, "the game has no zoom call"
    end
    owed = owed + amount
    if math.abs(owed) < SMALLEST then
        return true
    end
    own = auto and true or false
    local ok, err = pcall(owed > 0 and CameraZoomIn or CameraZoomOut, math.abs(owed))
    own, owed = false, 0
    return ok, not ok and tostring(err) or nil
end

-- The game's setting for how far the camera may go. Its own slider runs from 1 to 2
-- (Blizzard_SettingsDefinitions_Frame/Camelot/ControlsOverrides.lua 6). A camera at the player's
-- farthest cannot go out for combat, so for the time of the combat the setting is held at the top
-- of that slider, the game's own way for a session (Adapter.HoldSetting); false gives it back.
local ROOM = "cameraDistanceMaxZoomFactor"
local roomy = false
function Adapter.CameraRoom(on)
    if on and not roomy then
        Adapter.HoldSetting(ROOM, "2")
    elseif roomy and not on then
        Adapter.ReleaseSetting(ROOM)
    end
    roomy = on and true or false
end

-- Tells fn each time the camera is zoomed by anything but the automatic zoom: the stick, the
-- mouse wheel, a zoom bind (its press starts a move, its let-go makes a zoom call:
-- Blizzard_FrameXML/Bindings_Camelot.xml 1422 to 1435), the game's own LB + RB zoom. The game's
-- calls are watched; nothing of the game's is replaced.
function Adapter.OnHandZoom(fn)
    for _, name in ipairs({ "CameraZoomIn", "CameraZoomOut", "MoveViewInStart", "MoveViewOutStart" }) do
        if type(_G[name]) == "function" then
            hooksecurefunc(name, function()
                if not own then
                    fn()
                end
            end)
        end
    end
end

-- How far the camera is from the player, in yards. nil when the game has no call for it or hides
-- the number.
function Adapter.CameraDistance()
    if not results().cameraRead then
        return nil
    end
    local ok, yards = pcall(function()
        return GetCameraZoom() + 0
    end)
    return ok and yards or nil
end

-- The same as text for the log, or "unknown".
function Adapter.ZoomText()
    local yards = Adapter.CameraDistance()
    return yards and string.format("%.1f", yards) or "unknown"
end

-- LB and RB as the controller has them now: true for one that is down. Adapter.ButtonDown asks
-- the game's key state, as the game's own code does for a shoulder button
-- (Blizzard_GamepadActionBars/ClassActionFlyout.lua 61), and the pad's own state, so a button that
-- is no modifier key is seen: on some setups only one of the two tells of the shoulders.
function Adapter.Shoulders()
    return Adapter.ButtonDown("LB"), Adapter.ButtonDown("RB")
end

-- What the game does with the right stick by itself while LB or RB is held as one of its own two
-- targeting buttons, or nil when it does nothing with it. "zoom": both are held and its bar is
-- shown, so the stick zooms the camera (Blizzard_GamepadTargeting/TargetLogic.lua 185 to 197 and
-- 213 to 216). "targeting": one is held, and the stick chooses a target (the same file, 132 to
-- 144 and 168 to 178).
function Adapter.GameStick()
    local ok, what = pcall(function()
        if GamepadMode.IsHUDBindingModifierDown() then
            return GamepadMainActionBarFrame:IsShown() and "zoom" or nil
        end
        return GamepadMode.IsTargetingModifierDown() and "targeting" or nil
    end)
    return ok and what or nil
end

-- Tells fn(live) each time the game looks at its own two targeting buttons: live is true while
-- its own zoom has the stick. The game's own call is watched.
function Adapter.OnGameZoom(fn)
    if type(GamepadMode) == "table" and type(GamepadMode.SetHUDBindingModifier) == "function" then
        hooksecurefunc(GamepadMode, "SetHUDBindingModifier", function()
            fn(Adapter.GameStick() == "zoom")
        end)
    end
end

-- The game's two settings for how fast the right stick turns the camera. While the stick zooms
-- they are held at 0 for the session, the game's own way (Adapter.HoldSetting): the camera stands
-- still, and no stick is taken from the game, so the left stick walks. (On this game a frame of
-- an addon that takes a stick takes every stick.) ControllerForever holds the tilt at 0 the same
-- way for its zoom. The game's notes for the call name no limit in a fight. True when both
-- settings read 0 after it: the camera stands still.
local TURN = { "GamePadCameraYawSpeed", "GamePadCameraPitchSpeed" }

function Adapter.CameraStill(on)
    local still = on and true or false
    for _, name in ipairs(TURN) do
        if on then
            Adapter.HoldSetting(name, "0")
            local ok, now = pcall(GetCVar, name)
            still = still and ok and tonumber(now) == 0
        else
            Adapter.ReleaseSetting(name)
        end
    end
    return still
end

-- The game's messages for a window of an NPC: the kind of window, and true for a message that
-- opens it. A quest has four messages that open its window and one that closes it
-- (Blizzard_UIPanels_Game/Mainline/QuestFrame.lua 10 to 14).
local WINDOWS = {
    GOSSIP_SHOW = { "talk", true }, GOSSIP_CLOSED = { "talk", false },
    QUEST_GREETING = { "quest", true }, QUEST_DETAIL = { "quest", true }, QUEST_PROGRESS = { "quest", true },
    QUEST_COMPLETE = { "quest", true }, QUEST_FINISHED = { "quest", false },
    MERCHANT_SHOW = { "vendor", true }, MERCHANT_CLOSED = { "vendor", false },
    TRAINER_SHOW = { "trainer", true }, TRAINER_CLOSED = { "trainer", false },
    BANKFRAME_OPENED = { "bank", true }, BANKFRAME_CLOSED = { "bank", false },
}

-- What the game says of the player now, for the situations of Auto Camera Zoom: on a mount, the
-- number of the form (GetShapeshiftFormID, nil in none or when the game hides it), on a flight
-- path, indoors. A call this game does not have answers false. The API notes put no limit on the
-- four in a fight (PlayerScriptDocumentation.lua 1342, 1399; UnitDocumentation.lua 2570).
local function ask(fn, ...)
    local ok, value = pcall(fn, ...)
    return ok and value or nil
end

function Adapter.Situation()
    local form = ask(GetShapeshiftFormID)
    if form ~= nil and issecretvalue and issecretvalue(form) then
        form = nil
    end
    return ask(IsMounted) and true or false, form, ask(UnitOnTaxi, "player") and true or false, ask(IsIndoors) and true or false
end

-- The game's messages for a change of those: a mount, a form, the controls going and coming back
-- at a flight path's start and end, the player's unit flags (the flags of a flight and a mount,
-- Core/AdapterCue.lua OnTravel), a change of zone or of indoors, a spell's use (a mount cannot be
-- used inside: DynamicCam's World (Indoors) hears it beside the zone messages), a loading screen.
local SITUATION = { "PLAYER_MOUNT_DISPLAY_CHANGED", "UPDATE_SHAPESHIFT_FORM", "PLAYER_CONTROL_LOST", "PLAYER_CONTROL_GAINED",
    "ZONE_CHANGED_INDOORS", "ZONE_CHANGED", "ZONE_CHANGED_NEW_AREA", "SPELL_UPDATE_USABLE", "PLAYER_ENTERING_WORLD" }

-- Tells fn(event) at each of those messages. A message that this game version does not have is
-- left out. Returns how many messages are heard.
function Adapter.OnSituation(owner, fn)
    local heard = 0
    for _, event in ipairs(SITUATION) do
        local ok, valid = pcall(C_EventUtils.IsEventValid, event)
        if ok and valid then
            ns.On(event, owner, function()
                fn(event)
            end)
            heard = heard + 1
        end
    end
    ns.OnUnit("UNIT_FLAGS", "player", owner, function()
        fn("UNIT_FLAGS")
    end)
    return heard + 1
end

-- Tells fn(kind, shown) each time a window of an NPC opens or closes: a talk, a quest, a vendor,
-- a trainer, the bank. A message that this game version does not have is left out. Returns how
-- many messages are heard.
function Adapter.OnNpcWindow(owner, fn)
    local heard = 0
    for event, what in pairs(WINDOWS) do
        local ok, valid = pcall(C_EventUtils.IsEventValid, event)
        if ok and valid then
            ns.On(event, owner, function()
                fn(what[1], what[2])
            end)
            heard = heard + 1
        end
    end
    return heard
end
