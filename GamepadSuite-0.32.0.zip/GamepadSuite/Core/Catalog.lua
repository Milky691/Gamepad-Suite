-- What the player can put on a button, as named lists for the list screen: the spellbook tabs,
-- pet actions, items, macros, the game's own commands by group, addons' key bindings, and emotes.
-- Everything is read from the game through the adapter. This file groups it, puts the most used
-- entries of a list first and the rest under a "More" entry, and gives each game command a picture.
local _, ns = ...

local Catalog = { PAGE = 14 } -- PAGE: the cells of a page of the list screen (Settings/PickerModel.lua PER_PAGE)

local function icon(name)
    return "Interface\\Icons\\" .. name
end
-- Pictures the game itself shows for the same thing: the gear of its Interact button and the
-- magnifier of its Inspect button, the yes and no of a ready check, its sign for "none" (a slot
-- that an equipment set leaves out), the arrows of its controller bar, the speaker of its voice
-- chat, the target ring of its pointer.
local INTERACT, INSPECT = "Interface\\Cursor\\Interact", "Interface\\Cursor\\Crosshair\\Inspect"
local YES, NO = "Interface\\RaidFrame\\ReadyCheck-Ready", "Interface\\RaidFrame\\ReadyCheck-NotReady"
local NONE = "Interface\\PaperDollInfoFrame\\UI-GearManager-LeaveItem-Opaque"
local UP, DOWN, LEFT, RIGHT = icon("Misc_arrowlup"), icon("Misc_arrowdown"), icon("Misc_arrowleft"), icon("Misc_arrowright")
local SPEAKER, AIM = "Interface\\Common\\VoiceChat-Speaker", "Interface\\Cursor\\Crosshairs"
local RUN, PET, EAR = icon("Ability_Rogue_Sprint"), icon("Ability_Hunter_BeastCall"), icon("INV_Misc_Ear_Human_02")
local VIEW, ENEMY, BELL = icon("INV_Misc_Spyglass_02"), icon("Ability_Hunter_SniperShot"), icon("INV_Misc_Bell_01")

-- The most used commands and emotes. A list shows them in this order on its first page. An entry
-- the game does not have is left out. (With the binds of ours that stand first in a list, and
-- More, a first page has fourteen cells: tests/catalog_test.lua counts each list.)
local COMMON = {
    -- (Social and Minimap are under More: the radial Main Menu and Last Link took their cells)
    ["Game Menus"] = { "OPENRADIAL", "TOGGLEGAMEMENU", "OPENALLBAGS", "TOGGLECHARACTER0", "TOGGLESPELLBOOK", "TOGGLETALENTS", "TOGGLEQUESTLOG",
        "TOGGLEWORLDMAP", "MINIMAPZOOMIN", "MINIMAPZOOMOUT" },
    -- (three: Mouse Mode, Cancel, Mount, Random Mount, Track Nearest Quest, Feed Pet, Cleanse, Next Build, Voice
    -- Transcription and Pause Automation are the first ten entries of this list; Sit or Stand and Interact with Target
    -- are under More: the row Dynamic Interact puts Interact on a button)
    ["Game Actions"] = { "JUMP", "TOGGLEAUTORUN", "TOGGLEUIFOCUS" },
    ["Targeting"] = { "TARGETNEARESTENEMY", "TARGETPREVIOUSENEMY", "TARGETNEARESTFRIEND", "TARGETSELF", "TARGETPARTYMEMBER1",
        "TARGETPARTYMEMBER2", "TARGETPET", "ASSISTTARGET", "STARTATTACK" },
    ["Camera"] = { "CAMERAZOOMIN", "CAMERAZOOMOUT", "FLIPCAMERAYAW", "CENTERCAMERA", "NEXTVIEW", "PREVVIEW" },
    ["Chat"] = { "OPENCHAT", "OPENCHATSLASH", "REPLY", "REPLY2", "CHATPAGEUP", "CHATPAGEDOWN", "CHATBOTTOM", "TOGGLE_VOICE_PUSH_TO_TALK" },
    -- (twelve: Mark Next is the first entry of this list)
    ["Markers and Pings"] = { "RAIDTARGET8", "RAIDTARGET7", "RAIDTARGET6", "RAIDTARGET5", "RAIDTARGET4", "RAIDTARGET3", "RAIDTARGET2",
        "RAIDTARGET1", "RAIDTARGETNONE", "TOGGLEPINGLISTENER", "PINGATTACK", "PINGWARNING" },
    ["Emotes"] = { "WAVE", "HELLO", "BYE", "THANK", "CHEER", "LAUGH", "DANCE", "BOW", "NOD", "NO", "SORRY", "POINT", "SALUTE" },
}
-- More emotes that players use, for the list "Other" under More Emotes. Each shows when the game has it.
local OTHER_EMOTES = {
    "AGREE", "ANGRY", "APOLOGIZE", "BECKON", "BLOW", "BORED", "CHUCKLE", "CLAP", "CONGRATULATE", "COWER", "CURTSEY",
    "FACEPALM", "FLIRT", "GASP", "GLARE", "GOLFCLAP", "GREET", "HUG", "LOVE", "MOURN", "PRAY", "READY", "ROFL", "SHRUG",
    "SIGH", "SURRENDER", "TAUNT", "TIRED", "VICTORY", "VIOLIN", "WELCOME", "WHISTLE", "YAWN",
}

-- A game command has no picture of its own, so each gets one here: the picture the game shows for
-- the same thing where it has one as a file, else an icon that shows the action itself and not
-- one class's spell. First the commands with a picture by their full name.
local OWN = {
    JUMP = icon("Ability_Racial_RocketJump"), OPENRADIAL = icon("Trade_Engineering"),
    TOGGLEGUILDTAB = icon("INV_Shirt_GuildTabard_01"), TOGGLEMINIMAP = icon("Ability_Hunter_Pathfinding"),
    TOGGLECHARACTER2 = icon("Achievement_Reputation_01"), TOGGLECHARACTER4 = icon("Achievement_BG_winWSG"),
    TOGGLEWORLDSTATESCORES = icon("Achievement_BG_winWSG"), TOGGLELEGACYSYSTEM = icon("INV_Crown_02"),
    FLIPCAMERAYAW = "Interface\\Buttons\\UI-RotationRight-Button-Up", CENTERCAMERA = icon("Ability_Hunter_EagleEye"),
    NEXTVIEW = RIGHT, PREVVIEW = LEFT,
    OPENCHAT = icon("UI_Chat"), OPENCHATSLASH = "Interface\\ChatFrame\\UI-ChatIcon-Chat-Up", REPLY2 = icon("INV_Letter_16"),
    -- the on-screen button Y with no bind does the game's own Inspect
    INSPECT = INSPECT,
    -- the game's targeting with the stick, as two binds of ours (Stick Target Enemy, Stick Target Friend)
    GAMEPADRIGHTTARGETMODIFIER = ENEMY, GAMEPADLEFTTARGETMODIFIER = icon("Achievement_GuildPerk_EverybodysFriend"),
    -- this addon's own key binding, in the list Addons
    GAMEPADSUITE_TOGGLE = "Interface\\AddOns\\GamepadSuite\\Art\\Icon.tga",
}
-- Jump and Back have a picture on the game's own controller bar that is a named part of a larger
-- sheet and no file of its own. Widgets.Art can show such a picture; with no Widgets.Art the
-- command shows its plain picture.
local SHEET = { JUMP = "gamepad-ability-icon-jump", STOPCASTING = "128-redbutton-exit" }
-- Then the rest: the first rule whose pattern is in the command's name. The order matters: a
-- narrow word stands before a wide one.
local RULES = {
    { "GAMEMENU", icon("INV_Misc_Gear_01") }, { "BAG", icon("INV_Misc_Bag_08") },
    { "BACKPACK", icon("INV_Misc_Bag_07") }, { "CHARACTER", icon("INV_Chest_Chain_05") },
    { "CURRENCY", icon("INV_Misc_Coin_01") }, { "SPELLBOOK", icon("INV_Misc_Book_09") },
    { "PROFESSION", icon("Trade_BlackSmithing") }, { "PETBOOK", icon("Ability_Hunter_BeastTaming") },
    { "TALENT", icon("Ability_Marksmanship") }, { "QUESTLOG", icon("INV_Misc_Book_08") },
    { "ZOOMIN", "Interface\\Minimap\\UI-Minimap-ZoomInButton-Up" },
    { "ZOOMOUT", "Interface\\Minimap\\UI-Minimap-ZoomOutButton-Up" }, { "MAP", icon("INV_Misc_Map_01") },
    { "MOUNT", icon("Ability_Mount_RidingHorse") }, { "PETJOURNAL", icon("INV_Box_PetCarrier_01") },
    { "TOYBOX", icon("INV_Misc_Toy_10") }, { "WARDROBE", icon("INV_Chest_Cloth_17") },
    { "COLLECTIONS", icon("MountJournalPortrait") }, { "GROUPFINDER", icon("INV_Misc_GroupNeedMore") },
    { "SOCIAL", icon("INV_Misc_GroupLooking") }, { "TAB$", icon("INV_Misc_GroupLooking") },
    { "AUTORUN", RUN }, { "STEER", RUN }, { "TOGGLERUN", icon("INV_Boots_05") },
    { "FORWARD", UP }, { "BACKWARD", DOWN }, { "PITCHUP", UP }, { "PITCHDOWN", DOWN }, { "LEFT$", LEFT }, { "RIGHT$", RIGHT },
    { "SITORSTAND", icon("Spell_Nature_Sleep") }, { "SHEATH", icon("INV_Sword_04") },
    { "FOLLOW", icon("Ability_Tracking") }, { "VEHICLEEXIT", icon("Ability_Mount_RidingHorse") },
    { "STOPCASTING", NONE }, { "STOPATTACK", icon("Ability_Warrior_Disarm") },
    { "SCREENSHOT", icon("INV_Misc_Spyglass_03") }, { "MUSIC", icon("INV_Misc_Drum_01") },
    { "SOUND", SPEAKER }, { "VOLUME", SPEAKER }, { "RELOADUI", icon("INV_Misc_Wrench_01") },
    { "TOGGLEUI", icon("INV_Misc_Eye_01") }, { "RAIDTARGETNONE", NONE },
    { "PINGATTACK", icon("Ability_Warrior_Charge") }, { "PINGWARNING", "Interface\\DialogFrame\\UI-Dialog-Icon-AlertNew" },
    { "PINGONMYWAY", RUN }, { "PINGASSIST", icon("Achievement_Reputation_01") },
    { "PING", BELL }, { "NAMEPLATES", icon("INV_Misc_Note_01") },
    { "PARTYPET", PET }, { "TARGETPET", PET }, { "PETATTACK", icon("Ability_GhoulFrenzy") },
    { "PARTYMEMBER", icon("Spell_Holy_PrayerOfHealing") }, { "TARGETSELF", icon("Spell_Holy_Renew") },
    { "FOCUS", icon("Ability_Hunter_MarkedForDeath") }, { "INTERACT", INTERACT },
    { "ASSIST", AIM }, { "ATTACK", icon("Ability_MeleeDamage") },
    { "FRIEND", icon("Achievement_GuildPerk_EverybodysFriend") },
    { "PREVIOUSENEMY", icon("Ability_Hunter_MasterMarksman") }, { "TARGET", ENEMY },
    { "VOICE", EAR }, { "SPEECH", EAR }, { "PAGEUP", "Interface\\ChatFrame\\UI-ChatIcon-ScrollUp-Up" },
    { "PAGEDOWN", "Interface\\ChatFrame\\UI-ChatIcon-ScrollDown-Up" },
    { "BOTTOM", "Interface\\ChatFrame\\UI-ChatIcon-ScrollEnd-Up" }, { "REPLY", icon("INV_Letter_15") },
    { "SAVEVIEW", icon("INV_Misc_Spyglass_01") }, { "RESETVIEW", icon("INV_Misc_Spyglass_03") },
    { "SETVIEW", VIEW }, { "CAMERA", VIEW },
}
-- The picture for a command that no rule names, by the game's group.
local GROUP_ICON = {
    BINDING_HEADER_MOVEMENT = RUN, BINDING_HEADER_TARGETING = ENEMY, BINDING_HEADER_CAMERA = VIEW,
    BINDING_HEADER_CHAT = icon("UI_Chat"), BINDING_HEADER_PING_SYSTEM = BELL,
}
local OTHER_ICON = icon("INV_Misc_Gear_02")
-- the More entry shows the window's own "next" arrow, so it does not read as one more entry
local MORE_ICON = "Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up"
-- An emote has no picture in the game either. The most used get one that shows the gesture. Any
-- other shows the picture the game's own controller menu has for every emote: a smiling mask,
-- which the game names by its file number only.
local EMOTE = {
    WAVE = icon("INV_Gauntlets_04"), HELLO = icon("Ability_Warrior_BattleShout"), BYE = icon("INV_Boots_05"),
    THANK = icon("INV_Misc_Gift_01"), CHEER = icon("Ability_Warrior_WarCry"), LAUGH = icon("INV_Misc_Toy_07"),
    DANCE = icon("INV_Misc_Drum_01"), BOW = icon("INV_Crown_01"), NOD = YES, NO = NO,
    SORRY = icon("Spell_Holy_RemoveCurse"), POINT = "Interface\\Cursor\\Point", SALUTE = icon("INV_Helmet_03"),
}
local EMOTE_MASK = 3750314

-- Our lists for the game's command groups, in the order they show. A group that is not named
-- here is not offered (the action bar slots, the debug and tournament tools).
local LISTS = {
    { name = "Game Menus", headers = { "BINDING_HEADER_INTERFACE" } },
    { name = "Game Actions", headers = { "BINDING_HEADER_MOVEMENT", "BINDING_HEADER_MISC", "BINDING_HEADER_VEHICLE", "GAMEPAD_LABEL" } },
    { name = "Targeting", headers = { "BINDING_HEADER_TARGETING" } },
    { name = "Camera", headers = { "BINDING_HEADER_CAMERA" } },
    { name = "Chat", headers = { "BINDING_HEADER_CHAT" } },
    { name = "Markers and Pings", headers = { "BINDING_HEADER_RAID_TARGET", "BINDING_HEADER_PING_SYSTEM" } },
    -- the key bindings that addons add, this addon's settings window among them
    { name = "Addons", headers = { "ADDONS" } },
}
-- A command from a group that is not offered, with no group, or easier to find in another list (the
-- game's radial Main Menu beside the game menu, the minimap's zoom beside Minimap), and the list it goes in. The last two are the game's left and right mouse click.
local ALSO = { OPENRADIAL = "Game Menus", MINIMAPZOOMIN = "Game Menus", MINIMAPZOOMOUT = "Game Menus", RELOADUI = "Game Actions", CAMERAORSELECTORMOVE = "Game Actions", TURNORACTION = "Game Actions" }
-- Slash commands the game has no key binding for: the token the game knows it by, our name for it,
-- its list and its picture. One is offered only when the game has the command.
local SLASH = {
    { token = "CLEARFOCUS", name = "Clear Focus", list = "Targeting", icon = icon("Spell_Shadow_SacrificialShield") },
    { token = "INSPECT", name = "Inspect Target", list = "Targeting", icon = INSPECT },
    -- a roll of 1 to 100, for gear on master loot (the owner, 2026-10-16); the game's own word for it is /random
    { token = "RANDOM", name = "Roll", list = "Chat", icon = icon("INV_Misc_Dice_02"), text = "/roll" },
}
-- Commands of the game that the lists do not show. The first two are LT and RT as the game binds
-- them: they are the layers here. The other two are the game's targeting with the stick, which
-- Core/Binds.lua offers by names of ours (Stick Target Enemy, Stick Target Friend).
local NOT_OFFERED = {
    GAMEPADLEFTMOD = true, GAMEPADRIGHTMOD = true, GAMEPADLEFTTARGETMODIFIER = true, GAMEPADRIGHTTARGETMODIFIER = true,
}
-- Binds that are ours and no command of the game, in the order they show: the list each stands
-- first in, and the module that gives it with its Bind(), while it runs on this game build.
Catalog.OURS = { { "Game Actions", "Pointer" }, { "Game Actions", "Cancel" }, { "Game Actions", "Mount" }, { "Game Actions", "RandomMount" },
    { "Game Actions", "TrackQuest" }, { "Game Actions", "FeedPet" }, { "Game Actions", "Cleanse" }, { "Game Actions", "Builds" }, { "Game Actions", "VoiceText" }, { "Game Actions", "Automation" }, { "Markers and Pings", "MarkNext" }, { "Camera", "LookBehind" }, { "Camera", "Zoom" },
    { "Targeting", "StickEnemy" }, { "Targeting", "StickFriend" }, { "Targeting", "TargetMenu" }, { "Targeting", "SelfMenu" }, { "Game Menus", "MinimapZoom" }, { "Game Menus", "PeekMap" }, { "Game Menus", "ChatLinks" } }

-- The picture a command has by its name. nil for a command that nothing here names, and for a
-- click on a button (Mouse Mode, Mark Next, Look Behind): the owner of the button gives that one.
local function named(command)
    if command:find("^CLICK ") then
        return nil
    end
    local mark = command:match("^RAIDTARGET(%d)$")
    if mark then
        return "Interface\\TargetingFrame\\UI-RaidTargetingIcon_" .. mark
    elseif SHEET[command] and ns and ns.Widgets and ns.Widgets.Art then
        return SHEET[command]
    elseif OWN[command] then
        return OWN[command]
    end
    for _, rule in ipairs(RULES) do
        if command:find(rule[1]) then
            return rule[2]
        end
    end
end

-- The picture for a game command. header is the game's group for it, when that is known.
function Catalog.CommandIcon(command, header)
    return named(command) or GROUP_ICON[header] or OTHER_ICON
end

-- The picture, as it is in this build, of a bind whose picture is ours to give: a game command,
-- a slash command or an emote. A bind is saved with the picture it had when it was chosen, and
-- that one can be an older build's. nil for any other bind, and for one that nothing here names:
-- it keeps the picture it was saved with.
function Catalog.Icon(bind)
    if bind.kind == "command" then
        return named(bind.id)
    elseif bind.kind == "emote" then
        return EMOTE[bind.id]
    elseif bind.kind == "slash" then
        for _, extra in ipairs(SLASH) do
            if extra.token == bind.id then
                return extra.icon
            end
        end
    end
end

-- The first page of a list: the binds of ours (lead), then the most used entries in their own
-- order, then one "More" entry that holds the rest. rest is a set of named lists with every
-- entry that is not most used: { { name = , entries = } }. The page is filled before anything
-- goes under More: the first of the rest take the cells that are free, and a list that fits on
-- one page has no More entry. A list with nothing most used shows everything.
function Catalog.MostUsedFirst(name, entries, rest, lead)
    local byId, first, used = {}, {}, {}
    for _, entry in ipairs(lead or {}) do
        first[#first + 1] = entry
    end
    local ours = #first
    for _, entry in ipairs(entries) do
        byId[entry.id] = entry
    end
    for _, id in ipairs(COMMON[name] or {}) do
        local entry = byId[id]
        if entry then
            first[#first + 1] = entry
            used[entry] = true
        end
    end
    local count = 0 -- the entries that are not on the page yet
    for _, list in ipairs(rest) do
        for _, entry in ipairs(list.entries) do
            count = count + (used[entry] and 0 or 1)
        end
    end
    -- The cells they can have: as many as they are when nothing is most used; else the cells
    -- the page has free, less one for More when they do not all fit.
    local room = Catalog.PAGE - #first
    room = #first == ours and count or count > room and room - 1 or room
    local more = {}
    for _, list in ipairs(rest) do
        local left = {}
        for _, entry in ipairs(list.entries) do
            if not used[entry] and room > 0 then
                first[#first + 1], room, count = entry, room - 1, count - 1
            elseif not used[entry] then
                left[#left + 1] = entry
            end
        end
        if #left > 0 then
            more[#more + 1] = { name = list.name, entries = left }
        end
    end
    if count > 0 then
        first[#first + 1] = { kind = "more", name = "More " .. name, detail = count .. " more", icon = MORE_ICON, lists = more }
    end
    return first
end

-- Groups the game's commands into our lists. commands is what Adapter.Commands gives; slash is
-- the function that tells if the game has a slash command. A list made of more than one of the
-- game's groups keeps those groups as the lists under its More entry. lead: the binds of ours
-- that stand first in a list, by the list's name.
function Catalog.CommandLists(commands, slash, lead)
    local lists, listOf = {}, {}
    for i, list in ipairs(LISTS) do
        lists[i] = { name = list.name, entries = {}, groups = {}, mixed = #list.headers > 1 }
        for _, header in ipairs(list.headers) do
            listOf[header] = lists[i]
        end
        listOf[list.name] = lists[i]
    end
    local function add(list, entry, group)
        list.entries[#list.entries + 1] = entry
        if not list.groups[group] then
            list.groups[group] = { name = group, entries = {} }
            list.groups[#list.groups + 1] = list.groups[group]
        end
        local entries = list.groups[group].entries
        entries[#entries + 1] = entry
    end
    for _, command in ipairs(commands) do
        local list = listOf[ALSO[command.id] or command.header]
        if list and not NOT_OFFERED[command.id] then
            local group = list.mixed and command.headerName ~= "" and command.headerName or list.name
            add(list, {
                kind = "command", id = command.id, name = command.name,
                detail = list.mixed and command.headerName or "", icon = Catalog.CommandIcon(command.id, command.header),
            }, group)
        end
    end
    for _, extra in ipairs(SLASH) do
        local text = slash(extra.token) and (extra.text or slash(extra.token))
        if text then
            add(listOf[extra.list], { kind = "slash", id = extra.token, name = extra.name, detail = text, icon = extra.icon }, extra.list)
        end
    end
    for i, list in ipairs(lists) do
        lists[i] = { name = list.name, entries = Catalog.MostUsedFirst(list.name, list.entries, list.groups, lead and lead[list.name]) }
    end
    return lists
end

-- Reads one source from the game. A source the game does not have, or one that fails, gives an
-- empty list and a line in the log, and the other lists still show.
local function read(check, reader, ...)
    if not ns.Adapter.Results()[check] then
        return {}
    end
    local ok, result = ns.Call("Catalog", ns.Adapter[reader], ...)
    return ok and result or {}
end

local function tagged(entries, kind, picture)
    for _, entry in ipairs(entries) do
        entry.kind = kind
        entry.icon = entry.icon or picture
    end
    return entries
end

-- Gives emote entries their kind and their picture.
local function emotes(entries)
    for _, entry in ipairs(entries) do
        entry.kind, entry.icon = "emote", EMOTE[entry.id] or EMOTE_MASK
    end
    return entries
end

-- The emote list: the most used on the first page; under More the game's own two menu lists
-- (with an animation, with a voice) and a list of other emotes players use.
local function emoteList()
    local menu = read("emoteList", "Emotes")
    local rest = {
        { name = "Animated", entries = emotes(menu.animated or {}) },
        { name = "Voice", entries = emotes(menu.voice or {}) },
        { name = "Other", entries = emotes(read("emoteList", "EmotesByToken", OTHER_EMOTES)) },
    }
    local first = emotes(read("emoteList", "EmotesByToken", COMMON.Emotes))
    -- an emote on the first page is not listed again under More
    local shown = {}
    for _, entry in ipairs(first) do
        shown[entry.id] = true
    end
    for _, list in ipairs(rest) do
        for i = #list.entries, 1, -1 do
            if shown[list.entries[i].id] then
                table.remove(list.entries, i)
            end
        end
    end
    return Catalog.MostUsedFirst("Emotes", first, rest)
end

-- Every list, in the order the list screen shows them. It is read again each time, so a new
-- spell or a new item in the bags is there at the next open.
function Catalog.Build()
    local lists = {}
    for _, tab in ipairs(read("spellBook", "Spells")) do
        lists[#lists + 1] = { name = tab.name, entries = tagged(tab.entries, "spell") }
    end
    lists[#lists + 1] = { name = "Pet", entries = tagged(read("petBar", "PetActions"), "pet", PET) }
    local items = tagged(read("bagItems", "Items"), "item")
    -- the first entry of Items: the fishing pole, and the weapons back at the next press (Core/Hands.lua)
    if ns.Hands and ns.Hands.on then
        table.insert(items, 1, ns.Hands.Bind())
    end
    lists[#lists + 1] = { name = "Items", entries = items }
    lists[#lists + 1] = { name = "Macros", entries = tagged(read("macroList", "Macros"), "macro") }
    -- a wheel is a bind as any other: the button it is on opens it
    if ns.Wheels then
        lists[#lists + 1] = { name = "Wheels", entries = ns.Wheels.Binds() }
    end
    -- a fixed slot with an action: the button it is on runs what the slot holds
    if ns.Slots and ns.Slots.on then
        lists[#lists + 1] = { name = ns.SlotRules.LIST, entries = ns.Slots.Binds() }
    end
    lists[#lists + 1] = ns.GearSets and ns.GearSets.on and { name = ns.GearModel.LIST, entries = ns.GearSets.Binds() } or nil -- the character's equipment sets: the button a set is on wears it
    lists[#lists + 1] = ns.Builds and ns.Builds.on and { name = "Builds", entries = ns.Builds.Binds() } or nil -- the character's builds: the button switches to one (Core/Builds.lua)
    -- the binds of ours stand first in their lists: they are given to the lists before the first
    -- page of each is made, so that page is one page with them
    local lead = {}
    for _, ours in ipairs(Catalog.OURS) do
        local module = ns[ours[2]]
        if module and module.on then
            lead[ours[1]] = lead[ours[1]] or {}
            table.insert(lead[ours[1]], module.Bind())
        end
    end
    for _, list in ipairs(Catalog.CommandLists(read("commandList", "Commands"), ns.Adapter.SlashCommand, lead)) do
        lists[#lists + 1] = list
    end
    lists[#lists + 1] = { name = "Emotes", entries = emoteList() }
    return lists
end

if ns then
    ns.Catalog = Catalog
end
return Catalog
