-- The adapter's part for Weapon Items (Auto/WeaponItem.lua): which hands hold a weapon, the item's name, and the two
-- ways to give a waiting poison, oil or stone its weapon. SpellCanTargetItem (the game's bags and paper doll ask it,
-- Camelot/PaperDollFrame.lua 1614 and 1861) says a use waits for an item; Adapter.SpellWaits (Core/AdapterFeed.lua)
-- asks it. PickupInventoryItem(slot) gives the waiting use the item in that slot, as the paper doll does at the pad's
-- own A (Camelot/PaperDollFrame.lua 2129); it has no note in this build. The other way is a secure button of the
-- game's own kind with no action and a target slot: its click gives the waiting use that slot's item
-- (Blizzard_FrameXML/SecureTemplates.lua 758 to 784), as the Consumables Wheel's main hand button does
-- (Core/AdapterWheel.lua).
local _, ns = ...

local Adapter = ns.Adapter

local MAIN, OFF, WEAPON = 16, 17, 2   -- INVSLOT_MAINHAND, INVSLOT_OFFHAND (Blizzard_FrameXMLBase/Constants.lua 151 to 152); item class 2

Adapter.Check("weaponItems", function()
    return SpellCanTargetItem and PickupInventoryItem and GetInventoryItemID and C_Item.GetItemInfoInstant
        and C_EventUtils.IsEventValid("CURRENT_SPELL_CAST_CHANGED") == true
end)

-- True when the slot holds a weapon (C_Item.GetItemInfoInstant: classID is the 6th value, ItemDocumentation.lua 659).
-- A shield or a held-in-off-hand piece is armor.
local function weapon(slot)
    local ok, holds = pcall(function()
        local id = GetInventoryItemID("player", slot)
        return id and select(6, C_Item.GetItemInfoInstant(id)) == WEAPON
    end)
    return ok and holds and true or false
end

-- If the main hand and the off hand hold a weapon.
function Adapter.WeaponHands()
    return weapon(MAIN), weapon(OFF)
end

-- The name of an item of a bind ("item:2892" or a name), or nil while the game has not loaded it.
function Adapter.BindItemName(what)
    local id = type(what) == "string" and tonumber(what:match("^item:(%d+)"))
    if not id then
        return type(what) == "string" and what ~= "" and what or nil
    end
    local ok, name = pcall(C_Item.GetItemInfo, id)
    return ok and type(name) == "string" and name or nil
end

-- Gives the waiting use the weapon in the main hand (16) or the off hand (17). True when the call was made.
function Adapter.GiveHand(slot)
    return (pcall(PickupInventoryItem, slot))
end

-- A secure button whose click gives the waiting use the weapon in slot. It acts when the key goes down. Out of a fight.
function Adapter.HandButton(name, slot)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    button:RegisterForClicks("AnyDown")
    button:SetAttribute("useOnKeyDown", true)
    button:SetAttribute("target-slot", slot)
    return button
end
