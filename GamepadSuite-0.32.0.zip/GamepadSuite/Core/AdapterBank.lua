-- The adapter's part for trade goods: the bank deposit (Windows/BankDeposit.lua) and a stack for
-- a letter (Windows/MailAttach.lua). Each has its own login check.
--
-- What the game's code says:
--   The bank window of this game (Blizzard_UIPanels_Game/Camelot/BankFrame.lua and .xml) is a
--   window of the game's panels (BankFrameRegistration.lua 11), so the game's window manager
--   takes it when it shows (Blizzard_GamepadSharedUtility/FrameControlsManager.lua 209 to 216).
--   It has no controller code of its own: the D-pad walks its slots, A clicks, B closes, and X
--   and Y are blocked with no job (FrameControlsManager.lua 205 and 206).
--   The bank's places are the containers of its bought tabs (Camelot/BankFrame.lua 91 to 99).
--   A bag slot clicked with the right button while the bank is open moves its stack into the
--   bank with C_Container.UseContainerItem, the bank's kind given (Mainline/ContainerFrame.lua
--   1603 to 1609). The game's notes mark a call that the game limits with HasRestrictions (the
--   destroy, ItemDocumentation.lua 105); UseContainerItem and PickupContainerItem have no such
--   mark (ContainerDocumentation.lua 420 to 429 and 584 to 596). ForeverPlus sells at a vendor
--   with UseContainerItem from a timer on this game (Modules/AutoSellGray.lua 231), and
--   Mastercraft, made for this game's build, moves bank stacks the same way (QoL.lua 72). So a
--   move here comes from no press. That the bank takes a stack from addon code is not proved in
--   the game: the module writes what came. The call names no place: the game picks the place
--   in the bank, so a stack cannot be steered into a herb bag.
--   A bag of a profession (a herb bag) takes only its own items: C_Container.GetContainerNumFreeSlots
--   gives its free places and its bagFamily, 0 for a plain bag (ContainerDocumentation.lua 297 to
--   311), and C_Item.GetItemFamily the item's family (ItemDocumentation.lua 486 to 499). The game's
--   own Lua never compares the two (it counts only plain bags, Blizzard_StoreUI/
--   Blizzard_Shared_StoreUISecure.lua 1813 and 1814); the rule here is that they share a bit.
--   The game's letter takes a stack from the pointer at a click of one of its item places,
--   which calls ClickSendMailItemButton (Blizzard_MailFrame/MailFrame.lua 1492 and 1493). The
--   game's notes have no entry for that call. Mastercraft puts stacks into a letter with
--   PickupContainerItem and ClickSendMailItemButton from a timer (Mail.lua 75 and 76). Ours runs
--   inside a press of Y. The letter has ATTACHMENTS_MAX_SEND places (MailFrame.lua 4), and the
--   game's letter reads each with HasSendMailItem (1294). When its items change the game says
--   MAIL_SEND_INFO_UPDATE, at which the letter draws them again (MailFrame.lua 32 and 142 to 143,
--   MailInfoDocumentation.lua 126).
--   The game's navigation keeps the button in focus in SmartNavigation.currentButton
--   (Blizzard_GamepadSmartNavigation/SmartNavigation.lua 1679 to 1681). A slot of the bag window
--   says so with its buttonContext (Mainline/ContainerFrame.xml 85), and its bag with GetBagID,
--   which only reads (ContainerFrame.lua 1831 to 1833). The bag window is a window of the
--   manager (FrameControlsManager.lua 235 to 237). All of it is read; nothing is written.
--   The navigation sets its focus in one place, SelectButton (SmartNavigation.lua 568 to 632:
--   currentButton is written there, 606, and cleared only at its reset, 91); ControllerForever
--   watches that call on this game (ControllerForever_Focus.lua 905 to 914).
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

local function event(name)
    return C_EventUtils.IsEventValid(name) == true
end

Adapter.Check("bankDeposit", function()
    return BankFrame.HookScript and C_Bank.FetchPurchasedBankTabIDs and Enum.BankType.Character
        and C_Container.UseContainerItem and C_Container.GetContainerNumSlots and C_Container.GetContainerNumFreeSlots
        and C_Container.GetContainerItemInfo and C_Container.GetContainerItemQuestInfo and C_Item.GetItemInfoInstant
        and C_Item.GetItemMaxStackSizeByID and C_Item.GetItemFamily and GamepadMode.FrameControlsManager and event("BAG_UPDATE_DELAYED")
end)

Adapter.Check("mailAttach", function()
    return SendMailFrame.HookScript and ClickSendMailItemButton and HasSendMailItem and type(ATTACHMENTS_MAX_SEND) == "number"
        and C_Container.PickupContainerItem and C_Container.GetContainerItemInfo and C_Container.GetContainerItemQuestInfo
        and C_Item.GetItemInfoInstant and GetCursorInfo and ClearCursor and SmartNavigation.SelectButton and hooksecurefunc
        and ContainerFrameCombinedBags and GamepadMode.FrameControlsManager and event("ITEM_LOCK_CHANGED")
        and event("MAIL_SEND_INFO_UPDATE")
end)

-- The game's bags: the backpack to the reagent bag.
local FIRST, LAST = 0, 5
local SLOT = "ButtonContext_ContainerFrameItemButton"

-- The items a quest in the log names (item name -> quest title): the game marks only its own quest
-- items, so cloth or ore an objective asks for is read from the quest log (Auto/JunkModel.lua).
local function questNeeds()
    return ns.JunkModel and Adapter.QuestLog and ns.JunkModel.Needs(Adapter.QuestLog()) or {}
end

-- One bag slot as a thing of Windows/GoodsModel.lua, or nil when it is empty.
local function read(bag, slot, needs)
    local info = C_Container.GetContainerItemInfo(bag, slot)
    if not (info and info.itemID) then
        return nil
    end
    local _, _, _, _, _, class = C_Item.GetItemInfoInstant(info.itemID)
    local quest = C_Container.GetContainerItemQuestInfo(bag, slot)
    return { bag = bag, slot = slot, id = info.itemID, name = info.itemName or ("item " .. info.itemID),
        count = info.stackCount or 1, locked = info.isLocked or false, bound = info.isBound or false, class = class,
        family = results().bankDeposit and C_Item.GetItemFamily(info.itemID) or nil,
        quest = type(quest) == "table" and (quest.isQuestItem or quest.questID ~= nil) or needs[info.itemName] ~= nil }
end

-- ---------------------------------------------------------------- the bank
-- Tells fn each time the bank window shows or hides. It runs inside the game's code: fn must
-- only take note.
function Adapter.OnBankWindow(fn)
    BankFrame:HookScript("OnShow", fn)
    BankFrame:HookScript("OnHide", fn)
end

-- The bank window while it shows, or nil. Adapter.WindowHasPad (Core/AdapterGameWindows.lua)
-- says if it has the controller: not while the bags beside it have it.
function Adapter.BankWindow()
    local ok, shown = pcall(function()
        return results().bankDeposit and BankFrame:IsShown()
    end)
    return ok and shown and BankFrame or nil
end

-- Everything in the bags, as things of Windows/GoodsModel.lua, in the bags' order.
function Adapter.BagItems()
    local things = {}
    pcall(function()
        local needs = questNeeds()
        for bag = FIRST, LAST do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                things[#things + 1] = read(bag, slot, needs)
            end
        end
    end)
    return things
end

-- What the character's bank takes now: { free (empty places that take any item), room (item id
-- -> how many more its stacks take), bags (each bag of a profession: { family, free }) }.
function Adapter.BankRoom()
    local bank = { free = 0, room = {}, bags = {} }
    pcall(function()
        for _, bag in ipairs(C_Bank.FetchPurchasedBankTabIDs(Enum.BankType.Character)) do
            local free, family = C_Container.GetContainerNumFreeSlots(bag)
            if (family or 0) == 0 then
                bank.free = bank.free + (free or 0)
            else
                bank.bags[#bank.bags + 1] = { family = family, free = free or 0 }
            end
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info and info.itemID then
                    local most = C_Item.GetItemMaxStackSizeByID(info.itemID) or 1
                    bank.room[info.itemID] = (bank.room[info.itemID] or 0) + math.max(0, most - (info.stackCount or 1))
                end
            end
        end
    end)
    return bank
end

-- Asks the game to move a stack from the bags into the character's bank, as the bag window's
-- right click does. Not in a fight. True when the call was made with no error; the game's answer
-- is that the bags change.
function Adapter.BankDeposit(thing)
    if not results().bankDeposit or InCombatLockdown() then
        return false
    end
    return (pcall(C_Container.UseContainerItem, thing.bag, thing.slot, nil, Enum.BankType.Character, false))
end

-- ---------------------------------------------------------------- a stack for a letter
-- Tells fn each time the page for a new letter shows or hides, with the mail window too. It
-- runs inside the game's code: fn must only take note.
function Adapter.OnMailWriting(fn)
    SendMailFrame:HookScript("OnShow", fn)
    SendMailFrame:HookScript("OnHide", fn)
end

-- True while the page of the mail window for a new letter shows.
function Adapter.MailWriting()
    local ok, shown = pcall(function()
        return results().mailAttach and SendMailFrame:IsVisible()
    end)
    return ok and shown and true or false
end

-- The game's bag window, to stand a hint by, or nil.
function Adapter.BagWindow()
    return results().mailAttach and ContainerFrameCombinedBags or nil
end

-- The bag slot in the game's focus while the bag window has the controller, as a thing of
-- Windows/GoodsModel.lua; nil for an empty slot or when the focus is elsewhere.
function Adapter.BagFocus()
    local ok, thing = pcall(function()
        local button = SmartNavigation.currentButton
        if results().mailAttach and Adapter.WindowHasPad(ContainerFrameCombinedBags) and button and button.buttonContext == SLOT then
            return read(button:GetBagID(), button:GetID(), questNeeds())
        end
    end)
    return ok and thing or nil
end

-- Tells fn each time the game's navigation moves its focus (or sets it again), in any window.
-- The game's call is watched, after it ran; nothing of the game is replaced or written. fn runs
-- inside the game's code, often inside a press: it must only take note.
function Adapter.OnFocusMoved(fn)
    if type(SmartNavigation) == "table" and type(SmartNavigation.SelectButton) == "function" then
        hooksecurefunc(SmartNavigation, "SelectButton", function() fn() end)
    end
end

-- The first free item place of the letter, or nil when every place holds a stack. Only reads.
function Adapter.MailFreePlace()
    local ok, free = pcall(function()
        for place = 1, results().mailAttach and ATTACHMENTS_MAX_SEND or 0 do
            if not HasSendMailItem(place) then
                return place
            end
        end
    end)
    return ok and free or nil
end

-- Puts a whole stack into the first free item place of the letter: the stack goes onto the
-- pointer, and the place takes it, as at a click of the place. Call it only inside a press of
-- the player, out of a fight. A pointer that still holds the stack after means that the letter
-- did not take it: the stack goes back to its bag. True when it went in, else false and why.
function Adapter.MailAttach(thing)
    if not results().mailAttach or InCombatLockdown() then
        return false, "a fight, or the game has no call for it"
    end
    local ok, why = pcall(function()
        local free = Adapter.MailFreePlace()
        if not free then
            return "the letter has no free place"
        elseif GetCursorInfo() then
            return "the pointer holds something"
        end
        C_Container.PickupContainerItem(thing.bag, thing.slot)
        local kind, id = GetCursorInfo()
        if kind ~= "item" or id ~= thing.id then
            ClearCursor()
            return "the pointer did not take the stack (it holds " .. tostring(kind) .. " " .. tostring(id) .. ")"
        end
        ClickSendMailItemButton(free)
        if GetCursorInfo() then
            ClearCursor()
            return "the letter did not take the stack"
        end
    end)
    if not ok then
        pcall(ClearCursor)
        return false, tostring(why)
    end
    return why == nil, why
end
