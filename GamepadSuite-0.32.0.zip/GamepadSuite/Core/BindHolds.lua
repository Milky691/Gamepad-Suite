-- The bind core's held buttons: the LB + RB layer, Stick targeting, Sticky Layers for a trigger that
-- is a modifier too, and the game's own stick targeting when it is left on. Core/BindCore.lua and
-- Core/BindSecure.lua use this file; the restricted code here runs in a fight too.
--
-- LB + RB. LB and RB keep their own binds. While its row is on, LB's key goes to the LB button: on the press it does
-- LB's own bind (it takes the action of one of the owner frame's secure buttons, or a target command as its chat
-- command) and tells the owner frame that LB is held ("lbdown"). While LB is held, RB's key goes to the chord button,
-- whose press starts the layer ("both", Core/BindSecure.lua CHORD) and whose let-go ends it. The let-go of LB ends
-- both. ControllerForever makes its LB + RB layer the same way on this game: RB's press looks at LB (its
-- Shoulders.lua 1421 to 1448). Its layer ends at RB's let-go only, and a press with LB up then does nothing and ends
-- it (11137 to 11160); ours ends at either let-go, so the keys and the on-screen buttons agree. RB held before LB
-- keeps its own job until its let-go (no layer then, as in ControllerForever), and is the chord button after it.
--
-- Stick targeting (the row Targeting at Stick). A bumper with no bind of ours has the game's own command
-- GAMEPADRIGHTTARGETMODIFIER (an enemy) or GAMEPADLEFTTARGETMODIFIER (a friend): the press lights the targets up, the
-- right stick picks one, the let-go ends it (Blizzard_Gamepad/Bindings.xml 21 to 27,
-- Utility/Bindings/HoldBindings.lua 119 to 200, Blizzard_GamepadTargeting/TargetLogic.lua 132 to 178). A bumper with
-- a bind of ours goes to its own button, which does the bind on the press and holds the bumper ("lbdown", "rbdown").
-- While one bumper is held so, the game's targeting is on the same way, through the two calls the game's own start
-- makes (Holds.Aim). ControllerForever makes those calls on this game for its LB and RB too. Holds.Aim and Holds.Unstick
-- are in Core/BindAim.lua.
local _, ns = ...

local Holds = {}
ns.BindHolds = Holds

local Rules = ns.BindRules
local header
local logged = {}     -- what the log has had this session: LB's bind that no button can run, the same for Stick targeting
local lines, on = { came = 0 }, {}

-- Which triggers are down. A trigger that the game makes Shift, Ctrl or Alt ("mod:<side>") is down while that
-- modifier is (MODIFIER below keeps "moddown:<side>"). For a watched trigger the pad itself is read; the game lets
-- restricted code do that, in a fight too. The press or release that arrives right now ("now:L", "now:R") counts over
-- both, which can be a moment behind it. The keys get the layer of the triggers that are down or that taps keep on
-- ("stuck"), from its table ("table:<layer>"), or the table of the triggers that are held ("combo:<layer>"). The keys
-- are set again only when the answer changed.
Holds.HOLD = [[
    local pad = GetGamePadState and GetGamePadState()
    local buttons = pad and pad.buttons
    local stuck = self:GetAttribute("stuck")
    local held, hold = "", ""
    for _, side in ipairs(newtable("L", "R")) do
        local down = self:GetAttribute("now:" .. side)
        if down == nil and self:GetAttribute("mod:" .. side) then
            down = self:GetAttribute("moddown:" .. side) and 1 or 0
        elseif down == nil then
            down = buttons and buttons[self:GetAttribute("index:" .. side) or 0] and 1 or 0
        end
        if down == 1 then
            held = held .. side
        end
        if down == 1 or stuck == side or stuck == "LR" then
            hold = hold .. side
        end
    end
    if not (stuck and self:GetAttribute("table:" .. hold)) then
        hold = self:GetAttribute("combo:" .. held) and held or nil
    end
    if hold ~= self:GetAttribute("hold") then
        self:SetAttribute("hold", hold)
        self:RunAttribute("apply")
    end
]]

-- A trigger went down or up ("tapside", "tapdown" = 1 or 0): from its hold button (Core/BindSecure.lua WATCH) or, for
-- a trigger that is a modifier, from the change of the game's modifier keys (MODIFIER below). Sticky Layers
-- ("sticky"): a tap of a trigger turns its layer on, and the next tap of the same trigger turns it off ("stuck": "L",
-- "R" or "LR"). A press of any other button changes nothing: the layer stays on until its own trigger is tapped. The
-- keys get the layer of the triggers that are kept on or held (HOLD above), so a tap of LT while RT is kept on gives
-- LT + RT. This code has no clock. A tap is a press and a release of the trigger with no other button of the pad down
-- at either end ("pad1" to "pad<pads>": their places on the pad), and no press in between that the game shows to this
-- code ("tap:<side>" is still there).
Holds.TAP = [[
    local side, down = self:GetAttribute("tapside"), self:GetAttribute("tapdown") == 1
    if self:GetAttribute("sticky") then
        local pad = GetGamePadState and GetGamePadState()
        local buttons = pad and pad.buttons
        local clean = true
        for i = 1, self:GetAttribute("pads") or 0 do
            clean = clean and not (buttons and buttons[self:GetAttribute("pad" .. i)])
        end
        if down then
            self:SetAttribute("tap:" .. side, clean or nil)
        elseif self:GetAttribute("tap:" .. side) then
            self:SetAttribute("tap:" .. side, nil)
            if clean then
                local was = self:GetAttribute("stuck")
                local l, r = was == "L" or was == "LR", was == "R" or was == "LR"
                if side == "L" then
                    l = not l
                else
                    r = not r
                end
                local now = (l and "L" or "") .. (r and "R" or "")
                self:SetAttribute("stuck", now ~= "" and now or nil)
            end
        end
    end
    self:SetAttribute("now:" .. side, down and 1 or 0)
    self:RunAttribute("readhold")
    self:SetAttribute("now:" .. side, nil)
]]

-- The game's modifier keys changed. A trigger that the game makes Shift, Ctrl or Alt (LT is Shift on most setups)
-- sends no press of its own to any key, so its press, its let-go and its tap are seen here ("mod:L", "mod:R": the
-- modifier it is). So is the press of a bumper that is one ("mod:LB", "mod:RB"; LB is Ctrl at the game's start):
-- while a raid's party wheel is open it changes the radial as the bumper's key does (Core/BindPlan.lua CYCLE).
Holds.MODIFIER = [[
    for _, side in ipairs(newtable("L", "R", "LB", "RB")) do
        local name = self:GetAttribute("mod:" .. side)
        if name then
            local down = ((name == "CTRL" and IsControlKeyDown()) or (name == "ALT" and IsAltKeyDown()) or (name == "SHIFT" and IsShiftKeyDown())) and true or false
            if down ~= (self:GetAttribute("moddown:" .. side) or false) then
                self:SetAttribute("moddown:" .. side, down or nil)
                if #side == 1 then
                    self:SetAttribute("tapside", side)
                    self:SetAttribute("tapdown", down and 1 or 0)
                    self:RunAttribute("tap")
                elseif down and self:GetAttribute("wraid") and strmatch(self:GetAttribute("wheel") or "", "^heal") then
                    self:SetAttribute("wstep", side == "LB" and "prev" or "next")
                    self:RunAttribute("cycle")
                end
            end
        end
    end
    if self:GetAttribute("watching") then
        self:RunAttribute("readhold")
    end
]]

-- The key of LB or RB ("who": "lb" or "rb"), while the LB + RB layer, Stick targeting or Healer Mode at Bumpers is in
-- use. The press takes the bumper's own action for the state in use ("lb:<state>": the number of a secure button of
-- the owner frame, 0 for none) and holds the bumper. At Bumpers ("tap:<who>") that action runs at the let-go, and only
-- when no key targeted the group in the hold ("bused", Core/BindGroup.lua): holding it to target never runs it.
Holds.ROUTER = [[
    local who = self:GetAttribute("who")
    local tap = control:GetAttribute("tap:" .. who)
    if down then
        local n = control:GetAttribute(who .. ":" .. (control:GetAttribute("state-binds") or "n0")) or 0
        local from = n > 0 and control:GetFrameRef("act" .. n)
        for _, name in ipairs(newtable("type", "spell", "item", "macro", "macrotext", "unit", "action")) do
            self:SetAttribute(name, from and from:GetAttribute(name) or nil)
        end
        self:SetAttribute("useOnKeyDown", not tap)
        control:SetAttribute("bused", nil)
        control:SetAttribute(who .. "down", true)
    else
        control:SetAttribute(who .. "down", nil)
        if who == "lb" then
            control:SetAttribute("both", nil)
        end
    end
    control:SetAttribute(who .. "now", true)
    control:RunAttribute("apply")
    control:SetAttribute(who .. "now", nil)
    if tap and not down and control:GetAttribute("bused") then
        return false
    end
]]

-- Makes the LB and RB buttons, out of a fight (Core/BindSecure.lua). make(header, name) makes a secure button that hears both ends of a press.
function Holds.Build(owner, make, seen)
    header = owner
    Holds.header = owner
    header:SetAttribute("tap", Holds.TAP)
    header:SetAttribute("cycle", Rules.CYCLE)
    for _, ours in ipairs({ "LB", "RB" }) do
        local button = make(header, Rules[ours .. "_BUTTON"])
        button:SetAttribute("who", ours:lower())
        button:SetAttribute("useOnKeyDown", true)
        SecureHandlerWrapScript(button, "OnClick", header, seen .. Holds.ROUTER)
        -- the on-screen buttons show the press of the bumper's own action
        button:HookScript("PostClick", function(self, _, down)
            local kind = down and self:GetAttribute("type")
            if kind then
                ns.Send("press", Rules.Signature({ type = kind, spell = self:GetAttribute("spell"), item = self:GetAttribute("item"),
                    macro = self:GetAttribute("macro"), macrotext = self:GetAttribute("macrotext"), action = self:GetAttribute("action"), unit = self:GetAttribute("unit") }))
            end
        end)
    end
    -- The game's own stick targeting came on or went off: looked at when it may have been left on
    -- (Holds.Unstick). The first times go in the log, so one try in the game tells that its command
    -- runs (on a bumper with no bind, or the bind Stick Target on another button) and that it ends.
    ns.Adapter.OnTargetingChanged(function(left, down)
        C_Timer.After(0, Holds.Unstick)
        local ours = left and "LB" or "RB"
        if (down or on[ours]) and lines.came < 8 then
            lines.came = lines.came + 1
            ns.Log.Add("binds", ("the game's stick targeting for %s %s; %s held through our button: %s; its key reads %s"):format(
                left and "a friend" or "an enemy", down and "came on" or "went off", ours, tostring(header:GetAttribute(ours:lower() .. "down") or false),
                tostring(header:GetAttribute("set:" .. tostring(ns.Adapter.KEY[ours])))))
        end
        on[ours] = down or nil
    end)
    for _, event in ipairs({ "PLAYER_REGEN_ENABLED", "PLAYER_TARGET_CHANGED" }) do
        ns.On(event, "BindHolds", Holds.Unstick)
    end
    -- A fight starts (the game tells before it locks the keys): a bumper that waits for its one
    -- press of the game's own command gets its bind back, so it never does the game's targeting
    -- for the whole fight. The look comes again when the fight ends.
    ns.On("PLAYER_REGEN_DISABLED", "BindHolds", function()
        local changed = false
        for _, ours in ipairs({ "LB", "RB" }) do
            local key = ns.Adapter.KEY[ours]
            if key and header:GetAttribute("free:" .. key) then
                header:SetAttribute("free:" .. key, nil)
                changed = true
            end
        end
        if changed then
            SecureHandlerExecute(header, ns.BindSecure.REFRESH)
        end
    end)
    -- (a window took the controller or gave it back: in a fight too for our own stick targeting)
    ns.Listen("pad", "BindHolds", function()
        Holds.Unstick()
        Holds.Aim("pad")
    end)
    -- Stick targeting follows the bumpers held through their buttons (Holds.Aim). The ring on screen follows the
    -- wheel that the restricted code opened or closed, and the on-screen buttons follow the layer that a tap keeps
    -- on. The log has each layer the keys got from a held or kept trigger one time, with how the triggers were heard,
    -- so one try in the game shows each layer. With Sticky Layers on, it also has the first buttons whose press
    -- reached the restricted code, and the first changes of a trigger that is the game's Shift, Ctrl or Alt. The
    -- first times the LB + RB layer came on or went off go in the log too.
    local heard, said, seen, mod, held, late, chords, layer = {}, {}, 0, 0, 0, 0, 0, false
    header:HookScript("OnAttributeChanged", function(_, name, value)
        if name == "lbdown" or name == "rbdown" or name == "both" then
            Holds.Aim(name)
        end
        if name == "both" and (value and true or false) ~= layer then
            layer, chords = value and true or false, chords + 1
            if chords <= 8 then
                ns.Log.Add("binds", ("the LB + RB layer %s; LB held through our button: %s; in combat: %s"):format(value and "came on" or "went off",
                    tostring(header:GetAttribute("lbdown") or false), tostring(ns.Adapter.InCombat())))
            end
        end
        if name == "wheel" then
            ns.Send("wheel", value, header:GetAttribute("wwhy"))
        elseif name == "stuck" or name == "both" or name == "lbdown" then
            ns.Send("hold")
        elseif name == "late" and value and late < 4 then
            late = late + 1
            ns.Log.Add("binds", "a key that was down when its bind changed keeps Jump or its slot's command until its let-go (" .. tostring(header:GetAttribute("state-binds")) .. ")")
        elseif name == "hold" and value and held < 12 then
            local how, stuck = {}, header:GetAttribute("stuck") or ""
            for side in value:gmatch(".") do
                how[#how + 1] = side .. "T " .. (header:GetAttribute("moddown:" .. side) and "held as the game's " .. tostring(header:GetAttribute("mod:" .. side))
                    or stuck:find(side) and "kept on by a tap" or "held")
            end
            local line = "the keys have the " .. (value == "LR" and "LT + RT" or value .. "T") .. " layer's binds: " .. table.concat(how, ", ")
            if not said[line] then
                said[line], held = true, held + 1
                ns.Log.Add("binds", line)
            end
        elseif name == "seen" and value and not heard[value] and seen < 12 then
            heard[value], seen = true, seen + 1
            ns.Log.Add("binds", "Sticky Layers: a press of " .. value .. " was seen")
        elseif name:find("^moddown:.$") and header:GetAttribute("sticky") and mod < 12 then
            mod = mod + 1
            ns.Log.Add("binds", ("Sticky Layers: %sT %s as the game's %s at %.2f"):format(name:sub(-1), value and "down" or "up",
                tostring(header:GetAttribute("mod:" .. name:sub(-1))), GetTime()))
        end
    end)
end

-- A secure button of the owner frame that a bumper's button takes its action from.
function Holds.Lend(n)
    if n > 0 then
        SecureHandlerSetFrameRef(header, "act" .. n, ns.BindSecure.actionButtons[n])
    end
end

-- What the owner frame needs for the held buttons, written with the bind core's writer.
function Holds.Write(write, plan, form)
    local chord, aim = plan.chord, plan.aim
    for name, keys in pairs(chord and chord.states or {}) do
        for key, binding in pairs(keys) do
            write("both:" .. name .. ":" .. key, binding, key)
        end
    end
    if chord then
        for name, n in pairs(chord.lb) do
            write("lb:" .. name, n)
            Holds.Lend(n)
        end
        -- RB, with any modifier that can be down with it, is the chord button while LB is held
        for _, front in ipairs(Rules.Fronts(form.mods)) do
            write("chordkey:" .. front .. form.keys.RB, true, front .. form.keys.RB)
        end
    end
    -- (the chat lines are said once for the character, and again when they change: Core/BindCheck.lua Tell) With the row
    -- LB + RB Layer off the chord is there for Stick Zoom alone (Core/BindShape.lua): the words name Stick Zoom then
    local off, lb = chord and #chord.off > 0, chord and chord.bind or {}
    if off and not logged.off then
        logged.off = true
        ns.Log.Add("binds", "LB + RB is off in " .. table.concat(chord.off, ", ") .. ": LB's bind there is a game command that no button can run")
    end
    ns.BindCheck.Tell("chord", off and (form.holds[5] and "LB + RB Layer is off where LB has a command of the game, as no button can run it. On the Binds tab, give LB a spell, an item, a macro or a target bind such as Target Nearest Enemy."
        or "Stick Zoom on LB + RB is off because LB has " .. (lb.kind == "command" and ns.Adapter.CommandName and ns.Adapter.CommandName(lb.id) or lb.name or tostring(lb.id))
        .. ", which no button can run. Hold the bind Stick Zoom instead, or give LB a spell or a target bind.") or nil)
    -- Stick targeting: each bumper's own action, and where the pad shows the two bumpers
    write("aim", aim and true or nil)
    for _, who in ipairs({ "lb", "rb" }) do
        for name, n in pairs(aim and aim[who] or {}) do
            write(who .. ":" .. name, n)
            Holds.Lend(n)
        end
        write("index:" .. who, ns.Adapter.PadIndex(who:upper()))
    end
    local stuck = aim and #aim.off > 0
    if stuck and not logged.aim then
        logged.aim = true
        table.sort(aim.off)
        ns.Log.Add("binds", "Stick targeting is off for " .. table.concat(aim.off, ", ") .. ": the bind there is a game command that no button can run")
    end
    ns.BindCheck.Tell("aim", stuck and "Targeting (Combat tab) is Stick, but LB or RB has a command of the game, so holding that bumper does not target with the stick. On the Binds tab, give it a spell, an item, a macro or a target bind such as Target Nearest Enemy." or nil)
    -- A trigger that is a modifier: its layer's table while it is held, and Sticky Layers. A layer
    -- that taps keep on stays on when the binds are given to the game again; with the setting off it goes.
    write("mod:L", form.mods.LT)
    write("mod:R", form.mods.RT)
    -- A raid's party wheel (Core/BindPlan.lua CYCLE): in a raid whose groups the game shows, LB, RB and the D-pad change
    -- its radial while it is open, by their keys (CycleKeys) or by the modifier that the game makes a bumper (MODIFIER
    -- above), to the radial that each step goes to from each pair (Screen/WheelRaidModel.lua Moves).
    local _, raid = ns.Adapter.PartyUnits()
    write("wraid", raid and next(raid) and true or nil)
    for pair, moves in pairs(ns.WheelRaidModel.Moves(ns.WheelRaidModel.Pairs(raid or {}))) do
        for step, to in pairs(moves) do write("wgo:" .. pair .. ":" .. step, to) end
    end
    write("mod:LB", form.mods.LB)
    write("mod:RB", form.mods.RB)
    for key, step in pairs(Rules.CycleKeys(form.keys, form.mods)) do
        write("wcycle:" .. key, step, key)
    end
    header:SetAttribute("stuck", form.sticky and header:GetAttribute("stuck") or nil)
    -- the layers that have a table for the time their triggers are held or kept on (HOLD above)
    for combo in pairs(plan.held) do
        write("table:" .. combo, true)
    end
end

-- True while LB and RB are held through the LB button (the message "hold" tells of a change).
-- Stick Zoom and the on-screen buttons use it.
function Holds.Both()
    return header ~= nil and header:GetAttribute("both") and true or false
end
