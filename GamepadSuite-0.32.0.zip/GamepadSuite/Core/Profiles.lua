-- Profiles: the builds of every character of the account, the copies the player saved, and the
-- profiles that came as a text from another player.
--   The player saves nothing for this: a character's build in use is its own binds, wheels, fixed
--   slots and wheel places, the very same tables, so the game writes them to the files at logout.
--   Its other builds keep their own tables (Core/BuildRules.lua says what a build is; the module
--   is Core/Builds.lua). The account's file has every character's builds, for the others to load.
--   To use a profile, this character makes every bind of it again from its own lists
--   (Core/ProfileRules.lua). A spell it does not know, or a macro it does not have, is left out;
--   a button that lost a spell keeps a marker with the spell's name, for the Binds page.
--   What the character had before is kept once, for Undo. A switch of builds is Undo's too.
-- The page is Settings/ProfilesPage.lua.
local _, ns = ...

local Profiles = ns.Module("Profiles", nil, "Profiles")
ns.Profiles = Profiles

local Rules, Build = ns.ProfileRules, ns.BuildRules
local store      -- GamepadSuiteDB.profiles = { chars = { "Name-Realm" = { name, realm, class, when, builds } }, copies = { profile } }
local me         -- Adapter.Character()
local known      -- the facts about this character that Rules.Fit asks for, read once for each open of the page
local exact      -- the profile in hand keeps each spell's exact rank: a saved copy, or one of this account's class
local applying   -- true while a load or an undo puts its tables in place: its own changes are no bind change
local told = {}  -- what the log has this session, by subject
local views = setmetatable({}, { __mode = "k" }) -- another character's build as a profile, one table for each build

-- The log (kind "profiles") tells once in a session what only the game can show: the text that
-- went into the box and the text that came back from a paste (the same length when the copy and
-- the paste worked), and what came over when a profile was used.
local function tell(subject, text)
    if not told[subject] then
        told[subject] = true
        ns.Log.Add("profiles", text)
    end
end

local function amount(profile)
    local binds, wheels = Rules.Count(profile)
    return "(binds " .. binds .. ", wheels " .. wheels .. ")"
end

-- This character's builds: { use, list }; and the one in use.
local function builds()
    return GamepadSuiteCharDB.builds
end
local function current()
    return builds().list[builds().use]
end

-- The build in use is the live state; the account's file lists the builds for the other characters.
local function link()
    local build, char = current(), GamepadSuiteCharDB
    build.binds, build.wheels, build.slots, build.places = char.binds.sets, char.wheels, char.slots, char.wheelPlaces
    store.chars[me.key] = { name = me.name, realm = me.realm, class = me.class, own = true, when = ns.Adapter.Today(), builds = builds().list }
end

-- What this character can use, from its own bind list: its spells, its macros, the game's
-- commands and emotes. The page asks again at each open (Profiles.Fresh). entry: one of Profiles.List.
local function facts(entry)
    exact = entry.kind == "copy" or (entry.profile.own == true and entry.profile.class == me.class)
    if known then
        return known
    end
    -- byName: a spell by its name; top: a spell with ranks by its name, at its highest rank
    -- (the rank text read as Core/RankUp.lua reads it)
    local listed, byName, top, ranks = {}, {}, {}, {}
    local function take(entries)
        for _, entry in ipairs(entries) do
            if entry.kind == "more" then
                for _, list in ipairs(entry.lists) do
                    take(list.entries)
                end
            else
                listed[entry.kind .. ":" .. tostring(entry.id)] = entry
                if entry.kind == "spell" then
                    byName[entry.name] = entry
                    local text = ns.Adapter.SpellRank(entry.id)
                    local rank = ns.RankUpModel.Number(text ~= "" and text or entry.detail)
                    if rank and rank > (ranks[entry.name] or 0) then
                        top[entry.name], ranks[entry.name] = entry, rank
                    end
                end
            end
        end
    end
    for _, list in ipairs(ns.Catalog.Build()) do
        take(list.entries)
    end
    local function bind(entry)
        return entry and { kind = entry.kind, id = entry.id, name = entry.name, icon = entry.icon, detail = entry.detail } or nil
    end
    local forms, keys = {}, {}
    for _, form in ipairs(ns.Adapter.Forms()) do
        forms[form.id] = true
    end
    for key in pairs(ns.Adapter.KEY) do
        keys[key] = (key ~= "LT" and key ~= "RT") or nil
    end
    local buttons = ns.Adapter.MenuButtons()
    known = {
        class = me.class, keys = keys, forms = forms, most = ns.WheelRules.MOST_OWN,
        -- a spell of another rank has another number: the spell with the same name is the one.
        -- Another class or a text takes this character's highest rank (Follow New Ranks moves
        -- only the highest); a saved copy, and a character of this account with this class, keep
        -- a rank this character knows (decision 24: the player chose it)
        spell = function(id)
            local name = ns.Adapter.SpellName(id) or ""
            return bind(not exact and top[name] or listed["spell:" .. id] or top[name] or byName[name])
        end,
        item = ns.Adapter.ItemBind,
        listed = function(kind, id)
            local entry = listed[kind .. ":" .. tostring(id)]
            -- a command the game names and the list does not offer (what a button did at the first fill)
            local name = not entry and kind == "command" and type(id) == "string" and ns.Adapter.CommandName(id)
            return bind(entry or (name and { kind = kind, id = id, name = name, icon = ns.Catalog.CommandIcon(id), detail = "" }))
        end,
        runs = function(command)
            return ns.WheelRules.CommandText(command, buttons) ~= nil
        end,
        setting = ns.Registry.Fits,
        spellName = ns.Adapter.SpellName,
    }
    return known
end

function Profiles.Fresh()
    known = nil
end

-- Another character's build as a profile: "Thorgar: Prot Tank", with that character's class.
local function view(char, build)
    local out = views[build] or {}
    views[build] = out
    out.name, out.class, out.own, out.when = tostring(char.name) .. ": " .. tostring(build.name), char.class, true, char.when
    out.binds, out.wheels, out.slots, out.places, out.roles = build.binds, build.wheels, build.slots, build.places, build.roles
    return out
end

-- The profiles the page lists: the builds of the other characters, the last one played first
-- (a character not played since builds came lists its binds as one profile), then the saved copies
-- and the profiles from texts, the oldest first. Each is { id, kind, profile } (a build has index,
-- its place among its character's builds); kind is "build", "char", "copy" or "text".
function Profiles.List()
    local chars, out = {}, {}
    for key, char in pairs(store.chars) do
        if key ~= me.key and type(char) == "table" then
            chars[#chars + 1] = { key = key, char = char }
        end
    end
    table.sort(chars, function(a, b)
        local first, second = a.char.when or 0, b.char.when or 0
        if first ~= second then
            return first > second
        end
        return a.key < b.key
    end)
    for _, one in ipairs(chars) do
        if type(one.char.builds) == "table" then
            for index, build in ipairs(one.char.builds) do
                if type(build) == "table" then
                    out[#out + 1] = { id = one.key, index = index, kind = "build", profile = view(one.char, build) }
                end
            end
        else
            out[#out + 1] = { id = one.key, kind = "char", profile = one.char }
        end
    end
    for index, profile in ipairs(store.copies) do
        out[#out + 1] = { id = index, kind = profile.own and "copy" or "text", profile = profile }
    end
    return out
end

-- What the page shows of one profile: its name, its class, the day, how much it holds, and how
-- much of it this character can take ({ binds, wheels, cut, lost }).
function Profiles.Look(entry)
    local profile = entry.profile
    local binds, wheels = Rules.Count(profile)
    local _, comes = Rules.Fit(profile, facts(entry))
    return {
        name = profile.name or "Profile", class = profile.class, className = profile.class and ns.Adapter.ClassName(profile.class),
        day = ns.Adapter.DayText(profile.when), binds = binds, wheels = wheels,
        -- a text always has its writer's settings: one it does not name is the default there
        settings = entry.kind == "text", comes = comes,
    }
end

function Profiles.Me()
    return me
end

-- Binds, wheels and fixed slots take the place of this character's own, and the places of My
-- Wheels when given; with settings given, every setting becomes what the profile had (a setting it
-- does not name is the default there); then the role switches given.
local function apply(binds, wheels, slots, settings, places, roles)
    applying = true
    ns.Wheels.Replace(wheels)
    -- (a profile, or an undo, of a build that had no fixed slots: the character keeps its own)
    if slots then
        ns.Slots.Replace(slots)
    end
    if places then
        ns.WheelPlace.Replace(places)
    end
    ns.Binds.Replace(binds)
    if settings then
        ns.Registry.Each(function(key, default)
            local value = settings[key]
            -- (a saved value from an older build that the setting no longer takes is the default too)
            if value == nil or not ns.Registry.Fits(key, value) then
                value = default
            end
            if not Rules.NOT_SHARED[key] and ns.Registry.Get(key) ~= value then
                ns.Registry.Set(key, value)
            end
        end)
    end
    for key, value in pairs(roles or {}) do
        if ns.Registry.Get(key) ~= value then
            ns.Registry.Set(key, value)
        end
    end
    link()
    applying = false
end

-- Uses a profile for this character: it goes into the build in use. Gives the count of what came
-- over, or nil in a fight (the game lets no bind change there).
function Profiles.Use(entry)
    if ns.Adapter.InCombat() then
        return nil
    end
    Profiles.Fresh()
    local profile = entry.profile
    local withSettings = entry.kind == "text"
    -- (a text from before 0.26.5 has Healer Mode and Form and Stance Binds as true or false)
    Build.FixRoles(withSettings and profile.settings, me.class)
    local fitted, comes = Rules.Fit(profile, facts(entry))
    local char, build = GamepadSuiteCharDB, current()
    -- the tables in use now are let go as they are: they are what Undo gives back
    char.undo = {
        binds = char.binds.sets, wheels = char.wheels, slots = char.slots, places = char.wheelPlaces, was = build.was,
        roles = Build.Roles(ns.Registry.Get), settings = withSettings and Rules.Copy(ns.Registry.Saved()) or nil,
    }
    build.was = Build.Marks(comes.lost)
    -- (a profile with no places keeps the places this build had: they are for wheels of its own)
    local places = type(profile.places) == "table" and Build.FitPlaces(profile.places, fitted.wheels) or nil
    apply(fitted.binds, fitted.wheels, fitted.slots, withSettings and fitted.settings or nil, places, Build.FitRoles(profile.roles, ns.Registry.Fits, me.class))
    tell("use " .. entry.kind, "used the profile " .. tostring(profile.name) .. " (" .. entry.kind .. ", class " .. tostring(profile.class) .. "): came over: binds "
        .. comes.binds .. ", wheels " .. comes.wheels .. "; left out: binds " .. comes.cut .. ", spells marked " .. #comes.lost .. (withSettings and "; with its settings" or ""))
    ns.Print(Build.LoadLine(build.name, Rules.Clean(profile.name, 48) or "Profile", comes.binds, #comes.lost, comes.cut, Build.Changed(char.undo.roles, ns.Registry.Get),
        Build.CutLine(comes.wheelsCut, comes.slotsCut)))
    return comes
end

-- The switch to build `at`: the live tables stay in the build that was in use, and the new
-- build's tables are made live by the path a profile takes.
local function switch(at)
    local build = builds().list[at]
    builds().use = at
    apply(build.binds or { normal = {} }, build.wheels or { next = 1, list = {} }, build.slots or {}, nil, build.places or {}, Build.FitRoles(build.roles, ns.Registry.Fits, me.class))
end

-- Makes build `at` the build in use. False in a fight, or for the build in use. Undo goes back.
function Profiles.Switch(at)
    local all = builds()
    if ns.Adapter.InCombat() or not all.list[at] or at == all.use then
        return false
    end
    GamepadSuiteCharDB.undo = { build = current() }
    switch(at)
    return true
end

-- The place of the build an undo of a switch goes back to, or nil. (The saved file keeps no link
-- between two tables: after a reload the undo has a copy of that build, found by its name.)
local function before(undo)
    local list = builds().list
    return Build.IndexOf(list, undo.build) or Build.Find(list, tostring(undo.build.name))
end

-- True when Undo has something to give back: the binds from before a load, or the build used
-- before a switch.
function Profiles.CanUndo()
    local undo = GamepadSuiteCharDB.undo
    return undo ~= nil and (not undo.build or before(undo) ~= nil)
end

-- Gives true when it gave something back, and after a switch the place of the build in use again
-- (Builds.Undo then does what a switch does: the chat line and the gear set).
function Profiles.Undo()
    local undo = GamepadSuiteCharDB.undo
    if not Profiles.CanUndo() or ns.Adapter.InCombat() then
        return false
    end
    GamepadSuiteCharDB.undo = nil
    if undo.build then
        local at = before(undo)
        switch(at)
        return true, at
    end
    current().was = undo.was
    apply(undo.binds, undo.wheels, undo.slots, undo.settings, undo.places, Build.FitRoles(undo.roles, ns.Registry.Fits, me.class))
    return true
end

-- True when the game can make a text of a table and read it back.
function Profiles.CanText()
    return ns.Adapter.Results().profileText == true
end

-- The build in use, its binds, wheels and the settings as one text. nil when the game cannot make it.
function Profiles.Text()
    local lean = Rules.Lean({
        name = me.name .. ": " .. current().name, class = me.class, binds = GamepadSuiteCharDB.binds.sets, wheels = GamepadSuiteCharDB.wheels,
        slots = GamepadSuiteCharDB.slots, settings = ns.Registry.Saved(),
    })
    local packed = ns.Adapter.Pack(lean)
    local text = packed and (Rules.TAG .. packed) or nil
    tell("export", text and ("export: a text of " .. #text .. " letters is in the box " .. amount(lean)) or "export: the game could not make the text")
    return text
end

-- Takes a text another player made and keeps it as a profile. Gives its place in the list
-- (Profiles.List), or nil and why: "full" (the list is full), "cut" (the tag is there, the rest does
-- not unpack: a chat program cut it at its limit) or "wrong" (not a profile text).
function Profiles.Add(text)
    local body = Rules.Body(text)
    local raw = body and ns.Adapter.Unpack(body, Rules.RAW_MOST)
    local profile = raw and raw.v == 1 and Rules.Lean(raw)
    -- (the length without spaces and line breaks, as the export line counts it)
    local letters = type(text) == "string" and #text:gsub("%s+", "") or 0
    if not profile then
        tell("import wrong", "import: a text of " .. letters .. " letters came in the box and is no profile ("
            .. (not body and "no tag, or too long" or not raw and "the game could not unpack it" or "another form") .. ")")
        local tagged = letters > 0 and letters <= Rules.TEXT_MOST and text:gsub("%s+", ""):sub(1, #Rules.TAG) == Rules.TAG
        return nil, tagged and not raw and "cut" or "wrong"
    end
    tell("import", "import: a text of " .. letters .. " letters came in the box: a profile " .. amount(profile))
    if #store.copies >= Rules.COPIES then
        return nil, "full"
    end
    profile.name, profile.when = profile.name or "Profile", ns.Adapter.Today()
    store.copies[#store.copies + 1] = profile
    return #Profiles.List()
end

-- Takes a profile off the list. Another character's comes back when that character is played.
function Profiles.Remove(entry)
    local char = store.chars[entry.id]
    if entry.kind == "build" then
        if char and type(char.builds) == "table" then
            table.remove(char.builds, entry.index)
        end
    elseif entry.kind == "char" then
        store.chars[entry.id] = nil
    else
        table.remove(store.copies, entry.id)
    end
end

function Profiles.OnLogin()
    store = ns.Registry.Store("profiles")
    store.chars, store.copies = store.chars or {}, store.copies or {}
    me = ns.Adapter.Character()
    -- (the wheels' places of this character: Screen/WheelPlace.lua keeps this table)
    local char = GamepadSuiteCharDB
    char.wheelPlaces = char.wheelPlaces or {}
    -- a character with no builds yet has one: what it has now, as Build 1
    local all = char.builds
    if type(all) ~= "table" or type(all.list) ~= "table" or not all.list[1] then
        local roles = Build.Roles(ns.Registry.Get)
        -- a new warrior starts at Combat First (Core/BuildRules.lua FormRole)
        roles["layers.forms_and_stances"] = me.class == "WARRIOR" and Build.FormRole(nil, me.class) or roles["layers.forms_and_stances"]
        char.builds = Build.First({ binds = char.binds.sets, wheels = char.wheels, slots = char.slots, places = char.wheelPlaces }, roles)
    elseif not all.list[all.use] then
        all.use = 1
    end
    -- Undo Last Profile after a load is for this session: a week later it would throw away a week of
    -- binds. After a switch it stays (a switch back loses nothing).
    if type(char.undo) == "table" and not char.undo.build then
        char.undo = nil
    end
    link()
    -- Reset Binds, its Undo and a profile give the store a new table of binds (the message comes
    -- with no set): the build in use follows it, or it would keep the old binds. The first bind
    -- the player changes after a load ends that load's undo, which would take the bind away.
    ns.Listen("bind", "Profiles", function(set)
        if not set then
            link()
        elseif not applying and type(GamepadSuiteCharDB.undo) == "table" and not GamepadSuiteCharDB.undo.build then
            GamepadSuiteCharDB.undo = nil
        end
    end)
end
