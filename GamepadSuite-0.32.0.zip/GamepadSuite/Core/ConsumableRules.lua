-- The rules of the two wheels that the bags fill, with no game calls: which things in the bags a
-- player uses up (the consumables wheel), and which are quest items to use (the Quest Item Wheel).
-- The game files every item under a class and a subclass, each a number of its own lists
-- (Enum.ItemClass, Enum.ItemConsumableSubclass), and it knows how an item binds (Enum.ItemBind).
-- The adapter reads these numbers for each item in the bags (Core/AdapterWheel.lua); this file
-- says if the item goes on a wheel. No names are kept here.
-- On the consumables wheel, all of the class Consumable:
--   the subclasses Potion, Elixir, Flask, Scroll, Food and drink, Bandage and the temporary Item
--   enhancement;
--   the subclasses Generic and Other, where this game files a bomb (Generic), a healthstone, a
--   sharpening stone, an oil and a fishing lure (Other), but not a thing of these two that is not
--   used up when used. A bomb waits for a place: the game's own controller cursor for spell
--   targeting picks it (the game setting GamePadCursorForTargeting, on in the player's game).
--   How a thing binds says nothing here. This game's item tables (Item, ItemSparse, ItemEffect)
--   have 209 things of Generic and Other with a use that bind when picked up, and nearly all are
--   used up as any other: this game's own Rough Sharpening Stone (287978), healing potions
--   (223913), mana gems, soulstones, scrolls, battleground rations. A crate or a box to hand in
--   is not one of them: the care packages, supply bags and treasures have no use, and the
--   Waylaid Supplies crates are trade goods (class 7, subclass 11).
-- Not on it: every other class (a quest item, a key, a reagent, trade goods, gear), a quest
-- item of any class, a thing that starts a quest, a thing with no use, a thing that needs a
-- higher level than the character has, and the subclass Item enhancement. In this game build each of its 211 items with a use puts a lasting enchant on a
-- piece of gear that the player picks (Light Armor Kit goes on the chest, the legs, the hands or
-- the feet: spell effect 53 in the game's own item and spell tables). The gamepad UI ends such a
-- pick when none of its windows is open (Blizzard_GamepadSharedUtility/FrameControlsManager.lua
-- 550 to 552), so from a wheel it does nothing.
local _, ns = ...

local Consumable = {}

-- The game's number of the class Consumable, and of the class Quest.
Consumable.CLASS, Consumable.QUEST = 0, 12
-- The game's subclass number of a consumable -> its kind on the wheel. The kind is also its
-- place in the order: what is needed in a hurry comes first.
Consumable.KIND = { [1] = 1, [0] = 2, [8] = 2, [7] = 3, [5] = 4, [2] = 5, [3] = 6, [4] = 7, [15] = 8 }
-- The kinds by name, for the log.
Consumable.NAME = { "potion", "stone or other", "bandage", "food and drink", "elixir", "flask", "scroll", "weapon item" }
-- The kinds that wait for the end of a fight: food and drink. In a fight such an entry is gray and its name reads
-- "<name>, after combat" (Screen/WheelInfo.lua); it stays on the ring, as nothing can change in a fight.
Consumable.CALM = { [4] = true }
-- The subclass Item enhancement: a lasting enchant on a piece of gear the player picks.
Consumable.ON_GEAR = 6
-- The subclasses Generic and Other hold more than consumables.
Consumable.LOOSE = { [0] = true, [8] = true }
-- A secure button of the game's own kind with no action, whose click gives the weapon in the main
-- hand (the game's slot 16) to an item use that waits for an item, and does nothing else
-- (Core/AdapterWheel.lua).
Consumable.HAND = "GamepadSuiteMainHand"

-- item is what the game says of one thing in the bags:
--   class, sub: its class and subclass numbers (the game knows these for every item at once)
--   use: it has a use
--   usedUp: using it uses it up
--   quest: the game marks it as a quest item, or it starts a quest
--   starts: it starts a quest that the player has not taken
--   bind: how it binds (4: a quest item)
--   level: the level it needs
-- use, usedUp, bind and level are nil while the game has not loaded the item. A potion, food or another
-- thing of a subclass that holds only consumables goes on the wheel by its subclass then. A thing
-- of Generic or Other waits until the game says that it has a use.
-- level is the character's level: a thing that needs a higher one cannot be used yet.
-- Gives its kind (1 to 8), or nil and the reason in a few words for the log.
function Consumable.Kind(item, level)
    local loose = Consumable.LOOSE[item.sub]
    if item.class ~= Consumable.CLASS then
        return nil, "class " .. tostring(item.class)
    elseif item.sub == Consumable.ON_GEAR then
        return nil, "waits for a pick of gear"
    elseif not Consumable.KIND[item.sub] then
        return nil, "subclass " .. tostring(item.sub)
    elseif item.use == false then
        return nil, "no use"
    elseif loose and item.use == nil then
        return nil, "not loaded yet"
    elseif item.quest or item.bind == 4 then
        return nil, "quest item"
    elseif loose and item.usedUp == false then
        return nil, "not used up"
    elseif level and item.level and item.level > level then
        return nil, "needs level " .. item.level
    end
    return Consumable.KIND[item.sub]
end

-- The chat command of an entry of the consumables wheel. A sharpening stone, a weightstone, an
-- oil or a lure, used alone, waits for a pick of a weapon, and this game files them under Other
-- with things that wait for nothing (a healthstone). So each entry clicks the button HAND after
-- the use: the game itself looks if the use waits for an item, and only then gives it the weapon
-- in the main hand (Blizzard_FrameXML/SecureTemplates.lua 758 to 784).
function Consumable.Text(item)
    return "/use item:" .. item.id .. "\n/click " .. Consumable.HAND
end

-- True when an item goes on the Quest Item Wheel: it starts a quest that the player has not
-- taken (the game's own bags mark such an item, Blizzard_UIPanels_Game/Mainline/ContainerFrame.lua
-- 1860), or it is a quest item with a use ("use it on the corpse"). One that the game has not
-- loaded yet waits for its use to be known.
function Consumable.Quest(item)
    return item.starts or ((item.quest or item.class == Consumable.QUEST) and item.use) or false
end

if ns then
    ns.ConsumableRules = Consumable
end
return Consumable
