-- The bind core's restricted code: the short programs the game runs for the owner frame of the
-- binds (Core/BindCore.lua). The game runs them in a fight too. They can read the frame's
-- attributes, a few game states and the pad, and they can set keys. They cannot call the addon.
-- The owner frame and its buttons are made at the end of this file.
local _, ns = ...

-- The owner works out what every key must be now, and sets the keys that differ from what it
-- set last ("set:<key>"). "force" sets all of them, for the times Blizzard may have cleared one.
--   away: a window has the controller. It counts out of a fight only; in a fight the addon cannot
--         keep it true, and Blizzard's window binds are above ours anyway.
--   off: the game's controller interface is off (the master switch, Core/Pad.lua): no key is ours, in a fight too.
--   lbdown: LB is held through the LB button (Core/BindHolds.lua); RB is the chord button then
--         ("chordkey:<key>"). both: RB is held too: the LB + RB layer. The pad says if LB and RB
--         are still down: a let-go can be lost while a window has the controller. rbdown: RB is held
--         through the RB button (Stick targeting: Core/BindHolds.lua Aim hears these changes).
--   gwho, gkey:<key>: Healer Mode at Bumpers: while that bumper is held ("lbdown", "rbdown") and LB + RB is not, the
--         D-pad, A, X and B go to the group button (Core/BindGroup.lua). "bused": one of them was pressed in that hold.
--   free:<key>: the game's own targeting was left on with that bumper up; the bumper does the
--         game's own command for one press (Core/BindHolds.lua Unstick).
--   hold: the layer of the watched triggers that are down or kept on ("L", "R", "LR"), when a table goes with it (see
--         HOLD). stuck: the triggers whose layers taps keep on (Sticky Layers, Core/BindHolds.lua TAP).
--   bonus: the player is in a form or a stance that has a bar of its own in the game.
--   sit: the player stands at a campfire (Auto/Campfire.lua). Out of a fight only, and not in water.
--   wheel: the wheel that is open. The right stick's direction keys use an entry, B closes it.
--         One that holds nothing now (the binds were given to the game again) closes. "wwhy" says
--         what closed it last, for the log (Screen/Wheel.lua). In a raid ("wraid") LB, RB and the D-pad
--         change the radial of a party wheel ("wcycle:<key>": Core/BindPlan.lua CycleKeys and CYCLE).
--   swim: in water A is Jump (swim up) out of a fight, also when A has a spell on it. In a fight, or
--         with a live enemy as the target, A keeps the player's bind, so a spell can be cast in water
--         (ControllerForever CHANGELOG.md 389).
--   pop1, pop2: a window that the game's gamepad mode gives no control is shown; A and B press
--         its two buttons. Out of a fight only.
--   Dynamic Interact: its key is the game's interact command while something is in reach. In a
--         fight "in reach" comes from the game's own state driver. Out of a fight the addon tells
--         it too ("near"), because the driver does not see things that are not units (a mailbox).
--   The Interact button ("ik:<state>:<key>": a key that has the game's Interact on it). With an
--         enemy as the target it starts the attack ("attack"). With a fishing pole in the hands,
--         out of a fight, it casts Fishing ("fish"), and while the line is out ("line") it
--         interacts, which takes the bobber. Out of a fight, something in reach comes first: the
--         key then interacts as it always does. The Dynamic Interact button fishes the same way.
--   gbkey:<state>: the friendly bumper's key where Healer Mode at Bumpers holds the group. When it is the Dynamic
--         Interact button too, the hold wins (decision 137): that key never interacts, fishes, opens a menu or sits.
local APPLY = [[
    local state = self:GetAttribute("state-binds") or "n0"
    local fight = PlayerInCombat()
    local away = (self:GetAttribute("away") and not fight) or self:GetAttribute("off")
    -- (not at the bumper's own press: the pad can be a moment behind it)
    for _, who in ipairs(newtable("lb", "rb")) do
        local index = self:GetAttribute("index:" .. who)
        if (self:GetAttribute(who .. "down") or self:GetAttribute("both")) and not self:GetAttribute(who .. "now") and index then
            local pad = GetGamePadState and GetGamePadState()
            if pad and pad.buttons and not pad.buttons[index] then
                self:SetAttribute(who .. "down", nil)
                self:SetAttribute("both", nil)
            end
        end
    end
    local lbdown, both = self:GetAttribute("lbdown"), self:GetAttribute("both")
    local group = not both and self:GetAttribute((self:GetAttribute("gwho") or "") .. "down")
    local hold = self:GetAttribute("hold")
    local wheel = self:GetAttribute("wheel")
    if wheel and (self:GetAttribute("wn:" .. wheel) or 0) == 0 then
        self:SetAttribute("wwhy", "it holds nothing now")
        self:SetAttribute("wheel", nil)
        wheel = nil
    end
    local bonus = HasBonusActionBar()
    local force = self:GetAttribute("force")
    local interact = self:GetAttribute("ikey")
    if interact and interact == self:GetAttribute("gbkey:" .. state) then
        interact = nil
    end
    local live = interact and not self:GetAttribute("ioff:" .. state)
        and (tostring(self:GetAttribute("state-interact")) == "1" or (self:GetAttribute("near") and not fight))
    local akey, bkey = self:GetAttribute("akey"), self:GetAttribute("bkey")
    local swim = tostring(self:GetAttribute("state-swim")) == "1"
    local reach = self:GetAttribute("near") and not fight
    local enemy = tostring(self:GetAttribute("state-enemy")) == "1"
    local attack = enemy and self:GetAttribute("attack")
    local fish = not fight and tostring(self:GetAttribute("state-pole")) == "1" and self:GetAttribute("fish")
    local line = fish and self:GetAttribute("line") and self:GetAttribute("icommand")
    local pop1, pop2 = not fight and self:GetAttribute("pop1"), not fight and self:GetAttribute("pop2")
    -- "keep" (Core/HoldSlots.lua): a key that is down keeps the command of a spell's slot until it is up, so that its
    -- let-go runs that command. The game's Jump the same, always: a key whose bind changes while it holds Jump would
    -- send its let-go elsewhere, and the character would go on rising (ControllerForever CHANGELOG.md 517). That is
    -- our bind Jump, or a key with no bind of ours whose own job in the game is Jump ("jump:<key>", A) that gets a
    -- bind of ours while it is down. "late" says that a key waits for its bind; the let-go of Jump tells the owner
    -- frame (Core/BindCore.lua), and so does the next press of a button of ours (SEEN).
    local pad = GetGamePadState and GetGamePadState()
    local down, late = pad and pad.buttons, nil
    for i = 1, self:GetAttribute("count") or 0 do
        local key = self:GetAttribute("key" .. i)
        local binding, held = nil, down and down[self:GetAttribute("pad:" .. key) or 0]
        if not away then
            -- (while LB + RB is held its ten keys are that layer's alone: over a held trigger, over
            -- the Interact button's jobs)
            local layer = (both and self:GetAttribute("both:" .. state .. ":" .. key)) or (hold and self:GetAttribute("h:" .. hold .. ":" .. state .. ":" .. key))
            binding = layer or self:GetAttribute("b:" .. state .. ":" .. key)
            -- in a form or a stance the game's stance bar can stand for a trigger bar
            if bonus and binding then
                binding = self:GetAttribute("alt:" .. binding) or binding
            end
            -- the Interact button: the bobber while the line is out; its other jobs when nothing is in reach
            if not layer and self:GetAttribute("ik:" .. state .. ":" .. key) then
                binding = line or (not reach and (attack or fish)) or binding
            end
            if live and key == interact and not layer then
                binding = self:GetAttribute("icommand")
            end
            -- the Dynamic Interact button with nothing in reach: with a fishing pole in the hands it fishes; with
            -- a friendly player as the target it opens the target's menu (Auto/UnitMenus.lua); at a campfire it sits
            if key == interact and not live and not fight and not layer and not self:GetAttribute("ioff:" .. state) then
                binding = line or fish or (self:GetAttribute("menu") and "CLICK TargetFrame:RightButton")
                    or (self:GetAttribute("sit") and not swim and "SITORSTAND") or binding
            end
            if swim and not fight and not enemy and key == akey and binding and not layer then
                binding = "JUMP"
            end
            if key == akey and pop1 then
                binding = pop1
            elseif key == bkey and pop2 then
                binding = pop2
            end
            -- the friendly bumper held (Healer Mode at Bumpers): over every rule above; an open wheel comes after it
            if group and self:GetAttribute("gkey:" .. key) then
                binding = "CLICK GamepadSuiteGroup:" .. self:GetAttribute("gkey:" .. key)
            end
            -- (RB held already with no bind of ours keeps the game's targeting until its let-go, which
            -- would else go to the chord button and leave the targeting on)
            if lbdown and self:GetAttribute("chordkey:" .. key) and not (held and not self:GetAttribute("set:" .. key)) then
                binding = "CLICK GamepadSuiteChord:LeftButton"
            end
            -- B closes the open wheel on every layer ("SHIFT-PAD2" is LT + B), and a key with the bind
            -- Cancel closes it too: that press does nothing else (Auto/Cancel.lua)
            local way = self:GetAttribute("stick:" .. key)
            local step = wheel and self:GetAttribute("wraid") and strmatch(wheel, "^heal") and self:GetAttribute("wcycle:" .. key)
            if wheel and way then
                binding = "CLICK GamepadSuiteWheelUse:" .. way
            elseif wheel and strmatch(key, "[^-]+$") == bkey then
                binding = "CLICK GamepadSuiteWheel:close"
            elseif step then
                binding = "CLICK GamepadSuiteWheel:go" .. step
            elseif wheel and binding == "CLICK GamepadSuiteCancel:LeftButton" then
                binding = "CLICK GamepadSuiteWheel:cancel"
            end
            binding = self:GetAttribute("free:" .. key) or binding
        end
        -- A key that the game itself holds during play ("top:<key>", Core/BindCore.lua) is set at the level of the
        -- game's window binds, where the last one set wins, and at every run: the game sets its own bind again when
        -- one of its windows closes, in a fight too. Such a run, and "force", leave a key that is down alone while
        -- its bind is the same: it is set again at a run after its let-go, so a hold is never cut short.
        local top = self:GetAttribute("top:" .. key)
        local was = held and (self:GetAttribute("set:" .. key) or binding and self:GetAttribute("jump:" .. key))
        if was and was ~= binding and (was == "JUMP" or self:GetAttribute("slot:" .. was)) then
            binding, late = was, true
        end
        if binding ~= self:GetAttribute("set:" .. key) or ((force or top) and not held) then
            self:SetBinding(top and true or false, key, binding)
            self:SetAttribute("set:" .. key, binding)
        end
    end
    if late ~= self:GetAttribute("late") then self:SetAttribute("late", late) end
]]
-- A watched trigger went down or up (Core/BindHolds.lua TAP: Sticky Layers and the held layer).
local WATCH = [[
    control:SetAttribute("tapside", self:GetAttribute("side"))
    control:SetAttribute("tapdown", down and 1 or 0)
    control:RunAttribute("tap")
]]
-- A button that a key clicks went down. Sticky Layers: a trigger that is down now is held for that press, so its
-- release is no tap. A layer that a tap keeps on stays on: only a tap of its own trigger turns it off
-- (Core/BindHolds.lua TAP). The game shows this code a press only as a click on a secure button
-- (Blizzard_RestrictedAddOnEnvironment/SecureHandlers.lua 396 to 414): a press of a key whose bind is a game command
-- (Jump, a target command) is not seen here. A key that kept Jump or a slot's command until its let-go ("late") is
-- looked at again: in a fight the addon cannot tell the owner frame of that let-go. With Sticky Layers on, the
-- button's name is told ("seen"), so the log can show that a press of it reached this code in the game.
local SEEN = [[
    if down then
        control:SetAttribute("tap:L", nil)
        control:SetAttribute("tap:R", nil)
        if control:GetAttribute("sticky") and control:GetAttribute("seen") ~= self:GetName() then
            control:SetAttribute("seen", self:GetName())
        end
        if control:GetAttribute("late") then
            control:RunAttribute("apply")
        end
    end
]]
-- The keys are worked out again. The pad is read first: a trigger's release can be lost while a
-- window has the controller.
local REFRESH = [[
    if self:GetAttribute("watching") then
        self:RunAttribute("readhold")
    end
    self:RunAttribute("apply")
]]
local FORCE = "self:SetAttribute('force', true)\n" .. REFRESH .. "self:SetAttribute('force', nil)"
-- RB while LB is held and the LB + RB layer is on: its press starts that layer, its release ends it.
-- ("rbnow": the pad can be a moment behind this press; a later run reads it for a lost let-go.)
local CHORD = SEEN .. [[
    control:SetAttribute("both", down and true or nil)
    control:SetAttribute("bused", true)
    control:SetAttribute("rbnow", true)
    control:RunAttribute("apply")
    control:SetAttribute("rbnow", nil)
    return false
]]
-- The bind of a wheel was pressed. The click's button name is the wheel. A press opens it; a
-- press on the bind of the open wheel, "close" (B) or "cancel" (the bind Cancel), closes it. A
-- wheel with nothing in it does not open. In a raid the bind of a party wheel closes it from any
-- radial ("heal774:2"); "goprev", "gonext" (LB, RB) and "goup" to "goright" (the D-pad) change the radial (Core/BindPlan.lua CYCLE).
local OPEN = SEEN .. [[
    if down and strmatch(button, "^go") then
        control:SetAttribute("wstep", strmatch(button, "^go(.*)$"))
        control:RunAttribute("cycle")
    elseif down then
        local now = control:GetAttribute("wheel")
        local wanted
        if button ~= "close" and button ~= now and button ~= strmatch(now or "", "^(.+):%d+$") and (control:GetAttribute("wn:" .. button) or 0) > 0 then
            wanted = button
        end
        if wanted ~= now then
            control:SetAttribute("wwhy", button == "close" and "B" or button == "cancel" and "Cancel" or "its bind")
            control:SetAttribute("wheel", wanted)
            control:SetAttribute("wsel", nil)
            control:SetAttribute("wkey", nil)
            control:RunAttribute("apply")
        end
    end
    return false
]]
local USE = ns.BindWheelUse   -- the stick's pick on an open wheel (Core/BindWheelUse.lua)

-- A secure button of the owner frame. It gets the press and the release of the key that clicks it.
local function secureButton(header, name)
    local button = CreateFrame("Button", name, header, "SecureActionButtonTemplate")
    button:RegisterForClicks("AnyDown", "AnyUp")
    return button
end

-- Makes the owner frame of the binds: its restricted code, the game's state drivers that run it,
-- and the buttons that every plan has. Core/BindCore.lua calls it one time, out of a fight.
local function build()
    local Rules = ns.BindRules
    local header = CreateFrame("Frame", "GamepadSuiteBinds", UIParent, "SecureHandlerStateTemplate")
    header:SetAttribute("apply", APPLY)
    header:SetAttribute("readhold", ns.BindHolds.HOLD)
    header:SetAttribute("icommand", Rules.INTERACT)
    -- a change of one of these states works the keys out again, with the pad read first (a trigger's
    -- let-go that a window took in a fight); the last two are the Interact button's other jobs: a
    -- live enemy is the target, a fishing pole is in the hands
    for _, state in ipairs({ "binds", "interact", "swim", "bonus", "enemy", "pole" }) do
        header:SetAttribute("_onstate-" .. state, REFRESH)
    end
    header:SetAttribute("_onstate-modifier", ns.BindHolds.MODIFIER)
    -- the start and the end of a fight: every key is set again once
    header:SetAttribute("_onstate-fight", FORCE)
    RegisterStateDriver(header, "modifier", "[mod:alt,mod:ctrl,mod:shift] 7; [mod:alt,mod:ctrl] 6; [mod:alt,mod:shift] 5; "
        .. "[mod:ctrl,mod:shift] 3; [mod:alt] 4; [mod:ctrl] 2; [mod:shift] 1; 0")
    RegisterStateDriver(header, "interact", "[@softinteract,exists] 1; 0")
    RegisterStateDriver(header, "fight", "[combat] 1; 0")
    RegisterStateDriver(header, "swim", "[swimming] 1; 0")
    RegisterStateDriver(header, "enemy", "[@target,harm,nodead] 1; 0")
    -- this driver only starts a new run of "apply"; the run asks the game itself if a bonus bar is up
    RegisterStateDriver(header, "bonus", "[bonusbar:1][bonusbar:2][bonusbar:3][bonusbar:4][bonusbar:5] 1; 0")
    -- the game has no event for "in water": its own state driver tells, and the campfire's line follows (Auto/Campfire.lua)
    header:HookScript("OnAttributeChanged", function(_, name, value)
        if name == "state-swim" then
            ns.Send("swim", tostring(value) == "1")
        end
    end)
    -- "empty here": a button with no action
    secureButton(header, Rules.NOTHING_BUTTON)
    SecureHandlerWrapScript(secureButton(header, Rules.CHORD_BUTTON), "OnClick", header, CHORD)
    ns.BindHolds.Build(header, secureButton, SEEN)
    if ns.BindGroup then
        ns.BindGroup.Build(header, secureButton, SEEN)
    end
    local logged = 0
    for _, side in ipairs({ "L", "R" }) do
        local button = secureButton(header, Rules.HOLD_BUTTON .. side)
        button:SetAttribute("side", side)
        SecureHandlerWrapScript(button, "OnClick", header, WATCH)
        -- The on-screen buttons show the layer of a held trigger. With Sticky Layers on, the first
        -- twelve times go in the log: when the trigger's key came, and the layer kept on after it.
        button:HookScript("PostClick", function(_, _, down)
            ns.Send("hold")
            if header:GetAttribute("sticky") and logged < 12 then
                logged = logged + 1
                ns.Log.Add("binds", ("Sticky Layers: %sT %s at %.2f, kept on: %s"):format(side, down and "down" or "up", GetTime(), tostring(header:GetAttribute("stuck"))))
            end
        end)
    end
    -- the wheels: one button opens and closes, one uses the entry on the stick's release
    local opener = secureButton(header, Rules.WHEEL_BUTTON)
    SecureHandlerWrapScript(opener, "OnClick", header, OPEN)
    opener:HookScript("PostClick", function(_, id, down)
        if down then
            ns.Send("wheel:pressed", id)
        end
    end)
    local use = secureButton(header, Rules.WHEEL_USE_BUTTON)
    use:SetAttribute("pressAndHoldAction", true)
    SecureHandlerWrapScript(use, "OnClick", header, USE)
    -- The log has the first let-go of each kind of entry (a spell, an item, a macro or a chat
    -- command, a pet action): what the game was given to run, and on whom. One try shows each kind.
    local ran = {}
    use:HookScript("PostClick", function(self, _, down)
        local kind = not down and self:GetAttribute("typerelease")
        if kind and not ran[kind] then
            ran[kind] = true
            local what = self:GetAttribute("spell") or self:GetAttribute("item") or self:GetAttribute("macrotext") or self:GetAttribute("macro") or self:GetAttribute("action")
            ns.Log.Add("wheel", ("a let-go of the stick ran the entry: %s %s%s, in a fight: %s"):format(kind, (tostring(what):gsub("\n", "; ")),
                self:GetAttribute("unit") and " on " .. self:GetAttribute("unit") or "", tostring(ns.Adapter.InCombat())))
        end
    end)
    return header
end

-- The secure button that runs a spell, an item, a macro or a chat command: number index of them.
local actionButtons, petTold = {}, false
local function actionButton(header, index)
    local button = actionButtons[index]
    if not button then
        button = secureButton(header, ns.BindRules.BUTTON .. index)
        -- the action comes when the key goes down, whatever the game's setting for that is: the
        -- game's own gamepad buttons do the same, and a layer can change before the key comes up
        button:SetAttribute("useOnKeyDown", true)
        -- the on-screen buttons show the press; the log has the first press of a pet bind, a press
        -- of its pet bar slot (one try in the game shows that the pet changes)
        button:HookScript("PostClick", function(self, _, down)
            if down then
                ns.Send("press", self.signature)
            end
            if down and self:GetAttribute("type") == "pet" and not petTold then
                petTold = true
                ns.Log.Add("binds", "a pet bind ran as a press of pet bar slot " .. tostring(self:GetAttribute("action")))
            end
        end)
        actionButtons[index] = button
    end
    return button
end

ns.BindSecure = {
    APPLY = APPLY, WATCH = WATCH, REFRESH = REFRESH, FORCE = FORCE, CHORD = CHORD,
    OPEN = OPEN, USE = USE, SEEN = SEEN, Build = build, ActionButton = actionButton, actionButtons = actionButtons,
}
