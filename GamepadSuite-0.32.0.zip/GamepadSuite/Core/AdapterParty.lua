-- The adapter, the part for the party on the D-pad (Screen/HudParty.lua): what the bind core's owner frame says of the
-- friendly bumper of Healer Mode at Bumpers (Core/BindGroup.lua), heard and read, never written. Both frames are the
-- addon's own secure frames; their attributes can be read in combat, and a hook only watches (Core/BindHolds.lua hooks
-- the owner frame the same way). The portrait and the name come from Core/AdapterWheel.lua and Core/AdapterPlate.lua.
local _, ns = ...

local Adapter = ns.Adapter

local function frames()
    local header, button = _G.GamepadSuiteBinds, ns.BindGroup and _G[ns.BindGroup.BUTTON]
    if type(header) == "table" and type(button) == "table" then
        return header, button
    end
end

-- The owner frame's attributes the look follows: the bumper held or let go through its button ("lbdown", "rbdown", Core/
-- BindHolds.lua ROUTER), the LB + RB layer ("both"), the first group press of the hold ("bused"), which bumper is the
-- friendly one ("gwho"). The group button's: the place in focus in a raid ("k", "s") and the raid's order ("groups").
local HEADER = { lbdown = true, rbdown = true, both = true, bused = true, gwho = true }
local GROUP = { k = true, s = true, groups = true }

-- Tells fn of each change of one of them, in combat too. False while the bind core has not made its frames yet.
function Adapter.OnGroupHold(fn)
    local header, button = frames()
    if not header then
        return false
    end
    header:HookScript("OnAttributeChanged", function(_, name)
        if HEADER[name] then
            fn()
        end
    end)
    button:HookScript("OnAttributeChanged", function(_, name)
        if GROUP[name] then
            fn()
        end
    end)
    return true
end

-- The friendly bumper now: held (through its own button, and LB + RB is not held: Core/BindSecure.lua APPLY), used (a
-- group press came in this hold), and get(name), the group button's attribute of that name (the party's units by
-- direction, the raid's order and its place in focus: Core/BindGroup.lua).
local NONE = function() return nil end
function Adapter.GroupHold()
    local header, button = frames()
    if not header then
        return { held = false, used = false, get = NONE }
    end
    local who = header:GetAttribute("gwho")
    return {
        held = who and header:GetAttribute(who .. "down") and not header:GetAttribute("both") and true or false,
        used = header:GetAttribute("bused") and true or false,
        get = function(name) return button:GetAttribute(name) end,
    }
end

-- The game's yes or no. One it hides from addon code is an error in the test, and counts as no.
local function yes(fn, ...)
    local ok, answer = pcall(function(...) return fn(...) and true or false end, ...)
    return ok and answer
end

-- In a party or a raid.
function Adapter.InGroup()
    return yes(IsInGroup)
end

-- True while the unit is there: the group button's press does nothing on one that is not (Core/BindGroup.lua SNIPPET).
function Adapter.UnitThere(unit)
    return yes(UnitExists, unit)
end

-- True for a player. A target's target can be a creature: its name then has no class colour.
function Adapter.IsPlayerUnit(unit)
    return yes(UnitIsPlayer, unit)
end

-- How long the look waits after the press of the bumper: the game's own wait before its friendly targeting bar shows
-- ("a delayed visual state to allow rapid tab targeting", Blizzard_Gamepad/Utility/Bindings/HoldBindings.lua 155 to 177,
-- the setting GamepadTargetingModifierVisualDelay), or 0.25 seconds when the game gives none.
function Adapter.TargetingDelay()
    local ok, value = pcall(C_CVar.GetCVar, "GamepadTargetingModifierVisualDelay")
    value = ok and tonumber(value) or nil
    return value and value >= 0 and value or 0.25
end
