-- The adapter's part for the bind Cleanse and the debuff mark of the party wheel (Auto/Cleanse.lua):
-- the debuffs on a unit, and the button that casts.
-- A cast is a thing an addon may not do, so the bind clicks one of the game's secure buttons that
-- runs a chat command as the game's own code (Blizzard_FrameXML/SecureTemplates.lua 450 to 464,
-- as for the bind Cancel). The game locks the button in a fight. Nothing the game runs in a fight
-- can look at auras: its restricted code has no call for them (RestrictedEnvironment.lua), and it
-- cannot read an attribute of an addon's own frame in a fight (RestrictedFrames.lua 79 to 99 and
-- 192 to 196). So the command is written out of a fight only.
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("cleanse", function()
    return C_UnitAuras.GetAuraDataByIndex and C_EventUtils.IsEventValid("UNIT_AURA") == true
end)

-- True for a value the game hides from addon code. A compare with one is an error.
local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- The kinds of the debuffs on a unit, as the game names them: { Magic = true, Poison = true }.
-- nil while the game hides the unit's auras from addon code (in a restricted fight the game's
-- notes mark them so: UnitAuraDocumentation.lua 208 to 224), and when it cannot tell.
function Adapter.DebuffKinds(unit)
    local ok, kinds = pcall(function()
        local out = {}
        -- (the game's answers end at the first empty place; 40 is only a bound for the loop)
        for i = 1, 40 do
            local aura = C_UnitAuras.GetAuraDataByIndex(unit, i, "HARMFUL")
            if hidden(aura) then
                return nil
            elseif aura == nil then
                return out
            end
            local kind = aura.dispelName
            if hidden(kind) then
                return nil
            elseif kind then
                out[kind] = true
            end
        end
        return out
    end)
    return ok and kinds or nil
end

-- True while the target is a friend that the character can help and that lives: the chat
-- command's [help,nodead]. False with no target, and while the game hides one of the answers.
function Adapter.FriendTarget()
    local ok, yes = pcall(function()
        local there, help, dead = UnitExists("target"), UnitCanAssist("player", "target"), UnitIsDeadOrGhost("target")
        if hidden(there) or hidden(help) or hidden(dead) then
            return false
        end
        return there and help and not dead or false
    end)
    return ok and yes or false
end

-- Makes the button. It runs its command when the key goes down, whatever the game's setting
-- for casts on key down says.
function Adapter.CleanseButton(name)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    button:RegisterForClicks("AnyDown")
    button:SetAttribute("useOnKeyDown", true)
    button:SetAttribute("type", "macro")
    return button
end

-- Gives the button the command of its next press. Out of a fight only. False and the game's
-- words when the game refused it.
function Adapter.SetCleanse(button, text)
    local ok, err = pcall(button.SetAttribute, button, "macrotext", text)
    return ok, not ok and tostring(err) or nil
end
