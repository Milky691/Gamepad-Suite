-- The wheels: what each wheel holds now. There are three sorts.
--   The wheels every character has (consumables, quest items, raid markers, portals, quick chat, rolls) are filled
--   from the game out of a fight: the bags, the spells the character knows, the group. Each is read again when the
--   game says that its part changed, and at no other time.
--   The player's own wheels (Settings, My Wheels) hold the binds the player chose, 2 to 8 of them, kept for each character.
--   The party wheel of healer mode has one entry for each member of the party; there is one such wheel for each
--   friendly spell or item that a button would cast, and in a raid one more for each pair of groups with members
--   ("heal774:2", ten places: Screen/WheelRaidModel.lua; LB, RB and the D-pad move, Core/BindPlan.lua CYCLE).
-- The bind core writes the entries of the wheels in use on its owner frame, for the game's restricted code in a fight.
local _, ns = ...

local Wheels = ns.Module("Wheels", { "secure", "padButtons" }, "Wheels")
ns.Wheels = Wheels

local Rules = ns.WheelRules
local entries = {}   -- id of a wheel every character has -> its entries now
local party, raid, GROUPS = {}, {}, 8   -- the party's units now (the player's group in a raid); [group] = units of the game's 8 raid groups
local saved          -- the player's own wheels: { next = number, list = { { id = "my1", name = text or nil, slots = { [place 1 to 8] = bind } } } }
local signature, due, logged, notes = nil, {}, {}, {}   -- the readers to run at the next update (READ); what the log has, by subject

-- What the wheels found goes to the log when it is new, five lines at most for each subject.
local function note(about, text)
    if logged[about] ~= text and (notes[about] or 0) < 5 then
        logged[about], notes[about] = text, (notes[about] or 0) + 1
        ns.Log.Add("wheel", about .. ": " .. text)
    end
end

local function own(id)
    for index, wheel in ipairs(saved and saved.list or {}) do
        if wheel.id == id then
            return wheel, index
        end
    end
end

-- What is read from the game, by the game's event that says it changed: the bags (the consumables wheel and the Quest
-- Item Wheel, each thing at the place it kept: Core/WheelsNow.lua; again when the game has loaded an item that it had not
-- loaded at the read, and at a new level), the spells (a mage's portals), the group (the party for healer mode, and the
-- channel of the quick chat lines: Core/ChatWheel.lua).
local READ = {
    BAG_UPDATE_DELAYED = function()
        local items, found, quests, questFound = ns.Adapter.Consumables(function() Wheels.Update("BAG_UPDATE_DELAYED") end)
        local keep = Wheels.Keep or function(_, list) return list end
        entries.consumables, entries.quest = keep("consumables", Rules.Consumables(items)), keep("quest", Rules.Consumables(quests or {}))
        note("consumables wheel", found)
        note("quest item wheel", questFound)
    end,
    SPELLS_CHANGED = function()
        entries.portals = ns.Adapter.Class() == "MAGE" and Rules.Portals(ns.Adapter.KnownSpells(Rules.PORTALS)) or {}
    end,
    GROUP_ROSTER_UPDATE = function()
        party, raid = ns.Adapter.PartyUnits()
        raid, entries.chat = raid or {}, ns.ChatWheel and ns.ChatWheel.Entries() or nil
    end,
}
READ.PLAYER_LEVEL_CHANGED = READ.BAG_UPDATE_DELAYED

-- The lists My Wheels offers, from the lists of the bind list: every bind a wheel can run.
function Wheels.Offer(lists)
    local buttons = ns.Adapter.MenuButtons()
    return Rules.Offer(lists, function(command)
        return Rules.CommandText(command, buttons) ~= nil
    end)
end

-- Healer mode. In a party or a raid, what would cast a friendly spell or use a friendly item on the target opens its
-- party wheel in its place: for a bind on a button, a fixed slot, an entry of My Wheels, and a spell in the game's own
-- slot of a button with no bind of ours (HealSlots). The game says what is friendly (Adapter.FriendlySpell). No macro.
local LAYER = { "", "LT + ", "RT + ", "LT + RT + " }
local function grouped() return #party > 1 or next(raid) ~= nil end   -- a party of two or more, or a raid of two or more
local healIcon = {}     -- the name of an item's party wheel -> the picture its bind had
local gameWheels = {}   -- the party wheels that HealSlots found last

-- What healer mode asks the game with (WheelRules.Finder keeps what it finds).
local function finder()
    return Rules.Finder(ns.Adapter.FriendlySpell, ns.Adapter.SpellCastName, ns.BindRules.WHEEL_BUTTON)
end

-- The finder's three tables (all empty with the setting off or in no group): wheels (what -> its party wheel's name),
-- foes (what -> the bind in its place, for a spell for an enemy too) and the names of all party wheels.
function Wheels.Heal()
    local found = finder()
    if not (ns.Registry.Get("combat.healer_mode") == "Wheel" and grouped()) then
        return found.wheels, found.foes, found.names
    end
    local function look(bind)
        local real = ns.BindRules.Real(bind)
        if (real.kind == "spell" or real.kind == "item") and type(real.id) == "number" then
            local name = found.Ask(real.kind, real.id)
            if name then
                healIcon[name] = real.icon or healIcon[name]
            end
        end
    end
    ns.Binds.Each(look)
    for n = 1, ns.SlotRules.MOST do
        look(ns.Slots.Get(n) or {})
    end
    for _, wheel in ipairs(saved and saved.list or {}) do
        for place = 1, Rules.MOST do
            look(wheel.slots[place] or {})
        end
    end
    note("healer mode, binds", found.Text())
    return found.wheels, found.foes, found.names
end

-- Healer mode for a button with no bind of ours. Such a button runs the game's own slot, and a friendly spell in that
-- slot opens its party wheel too. Gives layer -> our key -> the bind that takes the key, for the bind plan
-- (Core/BindPlan.lua), and one text for all of it. The party wheels it found are kept: Secure writes the ones that
-- the plan was given. With Form and Stance Binds off, a character with forms leaves the slots of a trigger bar that
-- the stance bar can stand for to the game. A character with no form has no such bar (a priest): its slots count.
function Wheels.HealSlots()
    local slots, found, parts = {}, finder(), {}
    if ns.Registry.Get("combat.healer_mode") == "Wheel" and grouped() then
        local forms = ns.Registry.Get("layers.forms_and_stances") ~= "Off" or #ns.Adapter.Forms() == 0
        for layer = 1, #LAYER do
            for key in pairs(ns.Adapter.KEY) do
                local spell, at = ns.Adapter.NativeSpell(key, layer)
                local name = spell and (forms or not ns.Adapter.NativeFormButtonName(key, layer)) and found.Ask("spell", spell, at)
                if name then
                    slots[layer] = slots[layer] or {}
                    slots[layer][key] = found.foes[spell] or { kind = "wheel", id = name }
                    parts[#parts + 1] = LAYER[layer] .. key .. " " .. name
                end
            end
        end
        table.sort(parts)
        note("healer mode, the game's own slots", found.Text() .. "; buttons " .. table.concat(parts, ", "))
    end
    gameWheels = found.names
    return slots, table.concat(parts, ", ")
end

-- What an entry of the player's own wheels, or a tap on a fixed slot (Core/Slots.lua), needs to run. A game command
-- is the one chat command that does the same (WheelRules.CommandText), or nothing. A friendly spell or item that
-- healer mode acts for opens its party wheel by a chat command (wheels and foes are Wheels.Heal's, asked here when the
-- caller has none), but not one that the player gave a receiver of its own (yourself).
function Wheels.Action(bind, wheels, foes)
    if not wheels then wheels, foes = Wheels.Heal() end
    if bind.kind == "command" then
        local text = Rules.CommandText(bind.id, ns.Adapter.MenuButtons())
        return text and { type = "macro", macrotext = text } or nil
    end
    local real = ns.BindRules.Real(bind)
    local what = not real.on and (real.kind == "spell" and real.id or real.kind == "item" and "item:" .. tostring(real.id))
    local text = what and (foes[what] and foes[what].detail or wheels[what] and Rules.HealText(ns.BindRules.WHEEL_BUTTON, wheels[what]))
    return text and { type = "macro", macrotext = text } or ns.BindRules.Action(bind)
end

-- What a wheel holds, in ring order (WheelRules.lua). wheels and foes: Wheels.Heal's, when the caller has them. A party
-- wheel's entry stops a cast or a wand first: no cast starts while a wand shoots.
function Wheels.Entries(id, wheels, foes)
    local kind, number, pair = Rules.HealOf(id)
    if kind then
        local cast, icon = kind == "item" and "item:" .. number or ns.Adapter.SpellCastName(number), ns.Adapter.BindIcon({ kind = kind, id = number, icon = healIcon[id] })
        -- in a raid a radial of two groups; the bind's own wheel has the player's own pair
        pair = pair or next(raid) and ns.WheelRaidModel.Own(raid)
        return pair and ns.WheelRaidModel.Radial(raid, pair, kind, number, icon, cast) or Rules.Party(party, kind, number, icon, cast)
    end
    local mine = own(id)
    if mine then
        if not wheels then wheels, foes = Wheels.Heal() end
        return Rules.FromSlots(mine.slots, function(bind)
            return Wheels.Action(bind, wheels, foes)
        end, ns.Adapter.BindIcon)
    end
    return entries[id] or {}
end

-- The wheels that are in use, each as the restricted code needs it: a wheel with a bind or in a
-- fixed slot, and every party wheel of healer mode.
function Wheels.Secure()
    local out = {}
    local wheels, foes, names = Wheels.Heal()
    local function add(id)
        if id and not out[id] then
            out[id] = Rules.Secure(Wheels.Entries(id, wheels, foes))
        end
    end
    ns.Binds.Each(function(bind)
        -- (a button can have a wheel through a fixed slot that holds it)
        bind = ns.BindRules.Real(bind)
        add(bind.kind == "wheel" and bind.id)
    end)
    -- a wheel in a fixed slot opens at a tap on the slot, also when no button has it
    for n = 1, ns.SlotRules.MOST do
        local held = ns.Slots.Get(n)
        add(held and held.kind == "wheel" and held.id)
    end
    for _, found in ipairs({ names, gameWheels }) do
        for _, name in ipairs(found) do
            add(name)
            for pair = 1, GROUPS / 2 do add((raid[2 * pair - 1] or raid[2 * pair]) and name .. ":" .. pair) end
        end
    end
    return out
end

-- The player's own wheels: { id, name, slots ({ [place] = bind }) }, oldest first.
function Wheels.Mine()
    local out = {}
    for i, wheel in ipairs(saved and saved.list or {}) do
        out[i] = { id = wheel.id, name = wheel.name or Rules.Name(wheel.id), slots = wheel.slots }
    end
    return out
end

-- The picture of one of the player's own wheels: the one of its first entry. nil for any other wheel.
function Wheels.Icon(id)
    local _, first = Rules.Count((own(id) or {}).slots or {})
    return first and ns.Adapter.BindIcon(first)
end

-- Every wheel as a bind list entry: every character's (quick chat while its module, needing quickChat, is on), then My Wheels.
function Wheels.Binds()
    local out = Rules.Binds(ns.Adapter.Class(), { chat = not (ns.ChatWheel and ns.ChatWheel.on) })
    for _, wheel in ipairs(saved and saved.list or {}) do
        out[#out + 1] = { kind = "wheel", id = wheel.id, name = wheel.name or Rules.Name(wheel.id), detail = "", icon = Wheels.Icon(wheel.id) }
    end
    return out
end

-- One text for everything the wheels hold, to see a change.
local function sign(all)
    local parts = { table.concat(party, ","), tostring(ns.Registry.Get("combat.healer_mode")) }
    for group = 1, GROUPS do parts[#parts + 1] = table.concat(raid[group] or {}, ",") end
    for _, wheel in ipairs(Rules.LIST) do
        for _, entry in ipairs(all[wheel.id] or {}) do
            parts[#parts + 1] = tostring(entry.macro) .. "@" .. tostring(entry.x)
        end
        parts[#parts + 1] = "|"
    end
    for _, wheel in ipairs(saved and saved.list or {}) do
        parts[#parts + 1] = wheel.id
        for place = 1, Rules.MOST do
            local bind = wheel.slots[place]
            if bind then
                parts[#parts + 1] = place .. ":" .. tostring(bind.kind) .. ":" .. tostring(bind.id)
            end
        end
    end
    return table.concat(parts, ";")
end

-- Looks at the wheels again; part is the game's event for the part to read first (READ), or nil. If a wheel changed,
-- the bind core writes them again ("wheels"). In a fight this waits for its end, and reads every part that changed.
function Wheels.Update(part)
    if READ[part] then
        due[READ[part]] = true
    end
    ns.Queue.Run("Wheels", function()
        for read in pairs(due) do
            read()
        end
        due = {}
        local text = sign(entries)
        if text ~= signature then
            signature = text
            ns.Send("wheels")
        end
    end)
end

-- Puts a bind on a place (1 to 8, and with it a direction) of one of the player's wheels; id = nil makes a new wheel.
-- Returns the wheel's id, or nil when there is no such place or no room for one more wheel.
function Wheels.SetEntry(id, place, bind)
    if not saved or type(place) ~= "number" or place < 1 or place > Rules.MOST or place % 1 ~= 0 then
        return nil
    end
    local wheel = own(id)
    if not wheel then
        if #saved.list >= Rules.MOST_OWN then
            return nil
        end
        wheel = { id = "my" .. saved.next, slots = {} }
        saved.next = saved.next + 1
        saved.list[#saved.list + 1] = wheel
    end
    wheel.slots[place] = { kind = bind.kind, id = bind.id, name = bind.name, icon = bind.icon, detail = bind.detail }
    Wheels.Update()
    return wheel.id
end

-- Gives one of the player's wheels the name the player typed (empty: its own name again); a bind that opens it shows
-- the new name too. Returns the name now.
function Wheels.SetName(id, text)
    local wheel = own(id)
    if not wheel then
        return nil
    end
    wheel.name = Rules.CleanName(text)
    local name = wheel.name or Rules.Name(id)
    local function rename(bind)
        if bind and bind.kind == "wheel" and bind.id == id then
            bind.name = name
        end
    end
    ns.Binds.Each(rename)
    for n = 1, ns.SlotRules.MOST do
        rename(ns.Slots.Get(n))
    end
    return name
end

-- Takes the bind off a place of one of the player's wheels. The other places keep their binds and their directions. A
-- wheel with no bind left goes, and so does every bind that opened it. Returns true when the wheel is gone.
function Wheels.ClearEntry(id, place)
    local wheel, at = own(id)
    if not wheel or not wheel.slots[place] then
        return false
    end
    wheel.slots[place] = nil
    local gone = Rules.Count(wheel.slots) == 0
    if gone then
        table.remove(saved.list, at)
        local binds = {}
        ns.Binds.Each(function(bind, set, layer, key)
            if bind.kind == "wheel" and bind.id == id then
                binds[#binds + 1] = { set, layer, key }
            end
        end)
        for _, slot in ipairs(binds) do
            ns.Binds.Set(slot[1], slot[2], slot[3], nil)
        end
        -- and a fixed slot that held the wheel is empty
        for n = 1, ns.Slots and ns.SlotRules.MOST or 0 do
            local held = ns.Slots.Get(n)
            if held and held.kind == "wheel" and held.id == id then
                ns.Slots.Clear(n)
            end
        end
    end
    Wheels.Update()
    return gone
end

-- The player's own wheels, all at once: a profile takes their place (Core/Profiles.lua).
function Wheels.Replace(wheels)
    GamepadSuiteCharDB.wheels, saved = wheels, wheels
    Wheels.Update()
end

function Wheels.OnLogin()
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    GamepadSuiteCharDB.wheels = GamepadSuiteCharDB.wheels or { next = 1, list = {} }
    saved = GamepadSuiteCharDB.wheels
    -- a wheel that an earlier build kept as a plain list: its binds go on places, spread as that build showed them
    -- The bind Quest Item of builds before 0.22.0 is the Quest Item Wheel now, and a wheel holds no wheel: it goes.
    local gone = {}
    for _, wheel in ipairs(saved.list) do
        if not wheel.slots then
            wheel.slots, wheel.entries = Rules.Spread(wheel.entries or {}), nil
        end
        for place = 1, Rules.MOST do
            if wheel.slots[place] and wheel.slots[place].kind == "questitem" then
                gone[#gone + 1] = { wheel.id, place }
            end
        end
    end
    for _, at in ipairs(gone) do
        Wheels.ClearEntry(at[1], at[2])
    end
    entries = { markers = Rules.Markers(), roll = ns.RollWheel and ns.RollWheel.Now() }
    for event, read in pairs(READ) do
        read()
        -- an event this game version does not have is left out
        pcall(ns.On, event, "Wheels", function()
            Wheels.Update(event)
            return event == "GROUP_ROSTER_UPDATE" and next(raid) and ns.Adapter.InCombat() and ns.Registry.Get("combat.healer_mode") == "Wheel"
                and note("healer mode", "the raid changed in combat: the party wheels follow it when combat ends")
        end)
    end
    signature = sign(entries)
    ns.Listen("setting", "Wheels", function(key)
        return key == "combat.healer_mode" and Wheels.Update()
    end)
    -- The game's own bar changed a slot (it tells of each, one after the other): if a friendly spell came
    -- or went, the binds are made again. Its page too (Core/BindCore.lua); in a fight that waits, and the log says so.
    ns.Adapter.OnNativeBarChanged(function()
        return grouped() and ns.Adapter.InCombat() and note("healer mode", "the game's bar changed its page in combat: the party wheels follow it when combat ends")
    end, true)
    local waiting, seen
    pcall(ns.On, "ACTIONBAR_SLOT_CHANGED", "Wheels", function()
        if not waiting then
            waiting = true
            C_Timer.After(0.2, function()
                waiting = false
                ns.Queue.Run("WheelSlots", function()
                    local _, text = Wheels.HealSlots()
                    if text ~= seen then
                        seen = text
                        ns.Send("wheels")
                    end
                end)
            end)
        end
    end)
end
