-- The adapter, the part for three small helpers: Mark Next (Auto/MarkNext.lua), Look Behind
-- (Auto/LookBehind.lua) and Stay Seated While Eating (Auto/Seated.lua).
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- ---------------------------------------------------------------- Mark Next
-- The game's notes flag its call for a raid mark as restricted, and every caller in the game's
-- files is the game's own code. ControllerForever, which runs on this game, never calls it from
-- addon code either. So the button is one of the game's secure buttons with the game's own
-- action for a mark ("raidtarget"): the game sets the mark, in a fight too.
-- An addon cannot change such a button in a fight. So the marks stand on the button, in order,
-- and this piece of the game's restricted code makes the step before each click: it puts the
-- mark of the place on the button and moves the place on by one, from the last to the first.
-- With no target, or with no right to mark (the attribute "allowed" is nil), it stops the click,
-- so the order stays where it is.
local STEP = [[
    if not UnitExists("target") or not self:GetAttribute("allowed") then
        return false
    end
    local place = self:GetAttribute("place") or 1
    self:SetAttribute("marker", self:GetAttribute("mark" .. place))
    self:SetAttribute("place", place % self:GetAttribute("marks") + 1)
]]

-- Makes the button. order is the list of the game's mark numbers, first to last. The attribute
-- "place" of the button is the place in that list of the mark that the next press gives.
function Adapter.MarkButton(name, order)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    -- the mark is given when the key goes down, whatever the game's setting for casts on key down says
    button:RegisterForClicks("AnyDown")
    button:SetAttribute("useOnKeyDown", true)
    button:SetAttribute("type", "raidtarget")
    button:SetAttribute("unit", "target")
    button:SetAttribute("action", "set")
    button:SetAttribute("marks", #order)
    button:SetAttribute("place", 1)
    button:SetAttribute("allowed", true)
    for place, mark in ipairs(order) do
        button:SetAttribute("mark" .. place, mark)
    end
    SecureHandlerWrapScript(button, "OnClick", button, STEP)
    return button
end

-- The game's number of the mark the target has now, or nil: for the log of the first presses.
function Adapter.TargetMark()
    local ok, mark = pcall(GetRaidTargetIndex, "target")
    return ok and mark or nil
end

-- The game's own question before its marker panel lets a mark be set on the target
-- (Blizzard_CompactRaidFrames/Classic/Blizzard_CompactRaidFrameManager.lua 322 to 328): for the log.
function Adapter.CanMarkTarget()
    local ok, can = pcall(CanBeRaidTarget, "target")
    return ok and can or false
end

local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- May the player set a raid mark? The game's own rule for its marker panel: not in a raid, or the
-- raid's leader, or an assistant (Blizzard_CompactRaidFrameManager.lua 174 to 179). A hidden
-- answer counts as no.
function Adapter.MayMark()
    local function yes(ask)
        local ok, answer = pcall(ask, "player")
        return ok and not hidden(answer) and answer == true
    end
    local ok, raid = pcall(IsInRaid)
    return not (ok and raid) or yes(UnitIsGroupLeader) or yes(UnitIsGroupAssistant)
end

-- ---------------------------------------------------------------- Look Behind
-- Turns the camera half way round. The game's own bind Flip Camera and its own controller code
-- make the same call, and ControllerForever makes it from addon code on this game. True when
-- the call ran; when it did not, the second value is what the game said. A call that the game
-- blocks without a word is in the log as a blocked action (Core/Log.lua).
function Adapter.FlipCamera()
    if not results().flipCamera then
        return false, "the game has no call for it"
    end
    local ok, err = pcall(FlipCameraYaw, 180)
    return ok, not ok and tostring(err) or nil
end

-- ---------------------------------------------------------------- Stay Seated While Eating
-- The names of the buffs that food and drink give while the character eats or drinks.
-- Limit: the English names, the ones ControllerForever looks for on this game. A game in
-- another language needs the names in that language: read them from the game's spells then.
local MEAL = { "Food", "Drink", "Food & Drink", "Refreshment" }

-- True while the player has one of those buffs. The game hides buffs from addon code in a
-- fight: this is asked out of a fight only.
function Adapter.Eating()
    if not results().auraByName then
        return false
    end
    for _, name in ipairs(MEAL) do
        local ok, found = pcall(function()
            return C_UnitAuras.GetAuraDataBySpellName("player", name, "HELPFUL") ~= nil
        end)
        if ok and found then
            return true
        end
    end
    return false
end
