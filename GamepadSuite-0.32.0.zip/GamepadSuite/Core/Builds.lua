-- Builds: up to four named setups of a character (the rules are in Core/BuildRules.lua, the
-- switch and the loads in Core/Profiles.lua, the page is the Profiles tab).
--   The build in use is the live state, so every change of binds, wheels, fixed slots and wheel
--   places is in it at once; a change of a role switch goes into it here, at the game's word.
--   A switch is out of combat only. Asked for in combat (Next Build, a build's bind, a talent
--   change) it waits for the end of combat and says so once. One chat line at each switch.
--   A build can put on an equipment set at the switch, and can follow a talent group: when the
--   player changes talent group, the build that follows the new group comes in.
--   The bind of a build is our chat command with its name (BuildRules.Entry): a button, a wheel and
--   a fixed slot run it. A build named anew takes its binds with it; a removed build leaves its
--   binds, and a press says it is gone (as an equipment set that is gone, Auto/GearModel.lua).
-- Nothing runs while nothing happens: a press, a store's message, a setting's or the game's event.
-- The log (kind "builds") has the talent groups at login, each change of group (five at most) and
-- the game's answer to the first gear set put on, so one try in the game tells.
local _, ns = ...

local Builds = ns.Module("Builds", nil, "Profiles")
ns.Builds = Builds

local Rules = ns.BuildRules
local waiting           -- the build that the end of this fight loads
local changes, worn = 0, false -- log lines: talent changes so far; a gear set was put on

-- The bind Next Build, first part of Game Actions (Core/Catalog.lua OURS).
Builds.Bind = Rules.NextEntry

-- This character's builds: { use, list }; and the one in use.
function Builds.All()
    return GamepadSuiteCharDB.builds
end

function Builds.Current()
    local all = Builds.All()
    return all.list[all.use]
end

-- The list Builds of the bind list: "Build: <name>" for each build.
function Builds.Binds()
    local out = {}
    for at, build in ipairs(Builds.All().list) do
        out[at] = Rules.Entry(build.name)
    end
    return out
end

-- The spell a button of the build in use had before a load took it away (the Binds page), or nil.
function Builds.Was(set, layer, key)
    return Rules.Was(Builds.Current().was, set, layer, key)
end

-- Every bind of the builds that are not in use, for Follow New Ranks (Core/RankUp.lua).
function Builds.Stored()
    local out, all = {}, Builds.All()
    for at, build in ipairs(all.list) do
        if at ~= all.use then
            Rules.EachBind(build, function(bind)
                out[#out + 1] = bind
            end)
        end
    end
    return out
end

-- The equipment sets a build can put on: their names, in the game's order.
function Builds.GearSets()
    local names = {}
    for _, set in ipairs(ns.Adapter.Results().gearSets and ns.Adapter.GearSets() or {}) do
        names[#names + 1] = set.name
    end
    return names
end

-- The build's gear set goes on, out of combat. Gives the words for the switch's chat line when it
-- did not go on in full: the game said no, or an item is not in the bags (Auto/GearModel.lua's
-- words). A set the player deleted or named anew in the game: once a session for a build, with
-- where to choose another (the cause does not change between switches).
local gone = {}
local function wear(build)
    if not build.gear or not ns.Adapter.Results().gearSets then
        return nil
    end
    local set
    for _, one in ipairs(ns.Adapter.GearSets()) do
        set = set or (one.name == build.gear and one) or nil
    end
    if not set then
        local key = build.name .. "|" .. build.gear
        local said = gone[key]
        gone[key] = true
        return not said and ("The equipment set " .. build.gear .. " is gone or has a new name: choose another in Profiles, " .. build.name .. ", Gear Set.") or nil
    end
    local ok, why = ns.Adapter.WearGearSet(build.gear)
    if not worn then
        worn = true
        ns.Log.Add("builds", "gear: " .. build.name .. " put on " .. build.gear .. ": " .. (ok and "the game took it" or ("not done (" .. tostring(why) .. ")")))
    end
    return not ok and ("The equipment set " .. build.gear .. " did not go on.") or ns.GearModel.GoneText(set)
end

-- What follows every switch, and an undo of one: the build's gear set, and one chat line.
local function after(build)
    local why = wear(build)
    ns.Print("Build in use: " .. build.name .. "." .. (why and (" " .. why) or ""))
end

local function load(build)
    waiting = nil
    local at = Rules.IndexOf(Builds.All().list, build)
    if at and ns.Profiles.Switch(at) then
        after(build)
    end
end

-- Asks for build `at`: now, or when the fight ends. The build in use says so (with no build
-- waiting: a press of the build in use then keeps it, in place of the one that waits).
function Builds.Request(at)
    local build = Builds.All().list[at]
    if not build then
        return false
    elseif at == Builds.All().use and not waiting then
        ns.Print(build.name .. " is in use already.")
        return true
    end
    if ns.Adapter.InCombat() and waiting ~= build then
        ns.Print("Build in use when combat ends: " .. build.name .. ".")
    end
    waiting = build
    ns.Queue.Run("Builds", function()
        load(build)
    end)
    return true
end

-- Next Build: the next build in the list, round; in a fight a second press goes on from the one that waits.
function Builds.Next()
    local all = Builds.All()
    local at = Rules.Next(all, waiting and Rules.IndexOf(all.list, waiting))
    if not at then
        ns.Print("You have one build. New Build on the Profiles tab makes another.")
        return
    end
    Builds.Request(at)
end

-- Our chat command: "/gamepadsuite build" is Next Build, "/gamepadsuite build <name>" that build.
-- False when the text is not for builds (the command then opens the settings window).
function Builds.Slash(text)
    local name = Rules.Slash(text)
    if not name then
        return false
    elseif name == "" then
        Builds.Next()
        return true
    end
    local at = Rules.Find(Builds.All().list, name)
    if at then
        Builds.Request(at)
    else
        ns.Print("No build is named " .. (Rules.CleanName(name) or "that") .. " now. Bind it again from the list Builds on the Binds tab.")
    end
    return true
end

-- New Build: a copy of the build in use, which it now is. Gives its place, or nil when there are four.
-- (Undo Last Profile would land in the wrong build after it: it ends.) The page says it; no chat line.
function Builds.Add()
    local at = Rules.Add(Builds.All())
    if at then
        GamepadSuiteCharDB.undo = nil
    end
    return at
end

-- Undo Last Profile. After a switch it is a switch back, with all a switch does. Gives true when it
-- gave something back, and after a switch the place of the build in use again.
function Builds.Undo()
    local ok, at = ns.Profiles.Undo()
    if at then
        after(Builds.All().list[at])
    end
    return ok, at
end

-- A typed name for build `at`. Every bind of that build, in every build of this character, gets
-- the new name. Gives the name, or nil and why ("taken").
function Builds.Rename(at, text)
    local name, old = Rules.Rename(Builds.All(), at, text)
    if name and old ~= name then
        local from, to = Rules.Entry(old), Rules.Entry(name)
        for _, build in ipairs(Builds.All().list) do
            Rules.EachBind(build, function(bind)
                if bind.kind == "slash" and bind.id == from.id then
                    bind.id, bind.name, bind.detail = to.id, to.name, to.detail
                end
            end)
        end
        -- the binds, the wheels and the fixed slots of the build in use are made again with the new text
        ns.Send("bind")
        ns.Wheels.Update()
        ns.Send("slots")
    end
    return name, old
end

-- Takes build `at` off (not the one in use). True, or nil and why ("use").
function Builds.Remove(at)
    local ok, why = Rules.Remove(Builds.All(), at)
    if ok then
        GamepadSuiteCharDB.undo = nil
    end
    return ok, why
end

-- The build in use puts on this equipment set at a switch (nil: none).
function Builds.SetGear(name)
    Builds.Current().gear = name
end

-- The build in use follows talent group `group` (nil: none); one build follows a group.
function Builds.SetTalent(group)
    for _, build in ipairs(Builds.All().list) do
        if group and build.talent == group then
            build.talent = nil
        end
    end
    Builds.Current().talent = group
end

-- True when this character has two talent groups to change between. Read at each draw of the
-- page: the second group can come during play.
function Builds.HasTalents()
    return ns.Adapter.Results().talentGroups == true and (ns.Adapter.TalentGroups() or 0) > 1
end

-- The game changed the talent group: the build that follows the new one comes in.
local function talents(now, before)
    local all = Builds.All()
    local at = Rules.ForTalents(all, now)
    if changes < 5 then
        changes = changes + 1
        ns.Log.Add("builds", "talent group " .. tostring(before) .. " to " .. tostring(now) .. "; the build that follows it: " .. (at and all.list[at].name or "none"))
    end
    if at and at ~= all.use then
        Builds.Request(at)
    end
end

function Builds.OnLogin()
    -- the old true/false switches (before 0.26.5) of every build, and of the copy Undo keeps of the
    -- build before a switch, take the words of now, once: a build not in use kept them for good
    local class, undo, fixed = ns.Adapter.Character().class, GamepadSuiteCharDB.undo, {}
    for _, build in ipairs(Builds.All().list) do
        fixed[#fixed + 1] = select(2, Rules.FixRoles(build.roles, class)) and build.name or nil
    end
    fixed[#fixed + 1] = select(2, Rules.FixRoles(type(undo) == "table" and type(undo.build) == "table" and undo.build.roles, class)) and "the copy Undo keeps" or nil
    Rules.FixRoles(type(undo) == "table" and undo.roles, class)
    if #fixed > 0 then
        ns.Log.Add("builds", "old true/false role switches written as words: " .. table.concat(fixed, ", "))
    end
    -- the role switches are the account's settings: the build in use of this character sets them
    -- (Core/Profiles.lua made the first build at its login)
    local roles = Builds.Current().roles
    if type(roles) == "table" and type(roles["layers.forms_and_stances"]) ~= "string" then
        roles["layers.forms_and_stances"] = Rules.FormRole(nil, class)
    end
    for key, value in pairs(Rules.FitRoles(roles, ns.Registry.Fits, class)) do
        if ns.Registry.Get(key) ~= value then
            ns.Registry.Set(key, value)
        end
    end
    -- a change of a role switch goes into the build in use
    ns.Listen("setting", "Builds", function(key)
        if Rules.ROLE[key] then
            local build = Builds.Current()
            build.roles = build.roles or {}
            build.roles[key] = ns.Registry.Get(key)
        end
    end)
    -- a button that gets a bind loses its marker
    ns.Listen("bind", "Builds", function(set, layer, key)
        if set and ns.Binds.Get(set, layer, key) ~= nil then
            Rules.Unmark(Builds.Current().was, set, layer, key)
        end
    end)
    -- (with one talent group too: the second can come during play)
    if ns.Adapter.Results().talentGroups then
        local count, active = ns.Adapter.TalentGroups()
        ns.Log.Add("builds", "talent groups at login: " .. tostring(count) .. ", in use " .. tostring(active))
        ns.Adapter.OnTalentGroup(talents)
    end
end
