-- The store of the player's binds: one bind for each button, on each layer, in each set.
-- It is the one owner of this data. Other modules read and change it here, and every change
-- sends the message "bind" with the set, the layer and the key.
-- Sets: "normal", "combat", and "form:<spell number>" for a form or stance.
-- Layers: 1 no trigger, 2 LT, 3 RT, 4 LT + RT, 5 LB + RB. Keys are our own names (A, LB, DU, ...).
-- A bind is a small table: its kind (spell, pet, item, macro, command, slash or emote), its id, and the
-- name and picture it had when it was chosen. { empty = true } is a slot made empty on purpose in a set.
local _, ns = ...

local Binds = ns.Module("Binds", nil, "Binds")
ns.Binds = Binds

local saved

function Binds.Get(set, layer, key)
    local layers = saved.sets[set]
    return layers and layers[layer] and layers[layer][key]
end

-- bind = nil removes what the slot holds.
function Binds.Set(set, layer, key, bind)
    assert(type(set) == "string" and type(layer) == "number" and type(key) == "string", "Binds.Set(set, layer, key, bind)")
    saved.sets[set] = saved.sets[set] or {}
    saved.sets[set][layer] = saved.sets[set][layer] or {}
    saved.sets[set][layer][key] = bind
    ns.Send("bind", set, layer, key)
end

-- Undo. What the player's last action on the Binds page changed is kept, as it was before: the
-- cells of one action (a swap is two), or every set before a reset. One step, kept in the file.
local group

-- The page starts an action: what it changes from here is one step for Undo.
function Binds.Begin()
    group = {}
end

-- Binds.Set for a change by the player's own hand: the cell is kept for Undo first.
function Binds.Change(set, layer, key, bind)
    if group then
        group[#group + 1] = { set, layer, key, Binds.Get(set, layer, key) or false }
        saved.last = { cells = group }
    end
    Binds.Set(set, layer, key, bind)
end

function Binds.CanUndo()
    return saved.last ~= nil
end

-- Takes the last step back. False when there is none.
function Binds.Undo()
    local last = saved.last
    if not last then
        return false
    end
    saved.last, group = nil, nil
    if last.sets then
        saved.sets, saved.filled = last.sets, true
        ns.Send("bind")
    else
        for i = #last.cells, 1, -1 do
            local cell = last.cells[i]
            Binds.Set(cell[1], cell[2], cell[3], cell[4] or nil)
        end
    end
    return true
end

-- Every bind of this character goes, and the buttons get what a new character has (Binds.Fill and
-- the row Targeting). Undo gives the old binds back. The markers of the last load of a profile
-- ("was Holy Light" on the Binds page, Core/Builds.lua) name binds that are gone now: they go too.
-- (Not at the message "bind" with no set: a load sends it too, just after it set its markers.)
function Binds.Reset()
    saved.last, group = { sets = saved.sets }, nil
    saved.sets, saved.filled, saved.cycle, saved.row, saved.told = { normal = {} }, nil, nil, nil, nil
    if ns.Builds and ns.Builds.on then
        ns.Builds.Current().was = nil
    end
    Binds.Fill()
    Binds.Targeting()
    ns.Send("bind")
end

-- Every bind at once: a profile takes the place of the store (Core/Profiles.lua).
function Binds.Replace(sets)
    -- the Binds page's last step was made on binds that are gone: Undo Last Profile gives those back
    saved.sets, saved.filled, saved.last, group = sets, true, nil, nil
    ns.Send("bind")
end

-- Calls fn(bind, set, layer, key) for every bind in the store.
function Binds.Each(fn)
    for set, layers in pairs(saved.sets) do
        for layer, slots in pairs(layers) do
            for key, bind in pairs(slots) do
                fn(bind, set, layer, key)
            end
        end
    end
end

-- Calls fn(bind) for every bind that Undo would give back (Core/RankUp.lua moves their rank, so an
-- Undo gives the new rank). After a swap one such table is on a button too: change those first.
function Binds.EachKept(fn)
    local last = saved.last or {}
    for _, cell in ipairs(last.cells or {}) do
        if cell[4] then
            fn(cell[4])
        end
    end
    for _, layers in pairs(last.sets or {}) do
        for _, slots in pairs(layers) do
            for _, bind in pairs(slots) do
                fn(bind)
            end
        end
    end
end

-- True when a button (in any set, on any layer) or a fixed slot has the bind of that game
-- command. A bind of ours (Mount, Feed Pet, Cleanse) makes its button and follows the game only then.
function Binds.Uses(command)
    local found = false
    Binds.Each(function(bind)
        found = found or (bind.kind == "command" and bind.id == command)
    end)
    for n = 1, ns.SlotRules.MOST do
        local held = ns.Slots.Get(n)
        found = found or (held ~= nil and held.kind == "command" and held.id == command)
    end
    return found
end

-- True when any set has a bind on that layer.
function Binds.LayerInUse(layer)
    for _, layers in pairs(saved.sets) do
        for _, bind in pairs(layers[layer] or {}) do
            if not bind.empty then
                return true
            end
        end
    end
    return false
end

-- The first fill of a new store: Menu opens the game's radial Main Menu (the owner, 2026-10-16: "the menu button on the
-- controller should come with that default on first install"), and that is the one bind. Every other
-- button has no bind of ours, so it keeps the game's own job (the row Targeting adds its own binds
-- after this). It is done once: a character that has binds keeps them. If the game has no name
-- for the command yet, it is tried again the next time.
Binds.MENU = "OPENRADIAL"
function Binds.Fill()
    local name = not saved.filled and ns.Adapter.CommandName(Binds.MENU)
    if not name then
        return
    end
    if not Binds.Get("normal", 1, "MN") then
        Binds.Set("normal", 1, "MN", { kind = "command", id = Binds.MENU, name = name, icon = ns.Catalog.CommandIcon(Binds.MENU) })
    end
    saved.filled = true
end

-- The row Targeting. "Stick": hold RB and push the right stick toward an enemy, hold LB for a
-- friend. It is the game's own way to select with the stick, and a bumper with no bind of ours
-- has it already (a short press selects the next one where the player's own game settings say
-- so). A bumper with a bind of ours does its bind when pressed, and the stick targets while it is
-- held (Core/BindHolds.lua). So the row puts no bind on RB or LB for it.
-- "Cycle": RB and LB select the next enemy and the next friend, and with LT the one before, as
-- four binds in the Normal set. They are binds like any other: the Binds page shows them and the
-- player can move or change them. One goes only on a button that is empty. The change to "Stick" takes away
-- those that are still there. The store keeps that they were made (a character's binds are its
-- own), so it is done one time.
-- The game's two commands for the stick, by names of ours. They are entries of the bind list,
-- first in the list Targeting (Core/Catalog.lua, OURS), for a player who wants the stick's
-- targeting on another button. They are offered when the game has the two commands (asked at login).
Binds.STICK = { GAMEPADRIGHTTARGETMODIFIER = "Stick Target Enemy", GAMEPADLEFTTARGETMODIFIER = "Stick Target Friend" }
for module, command in pairs({ StickEnemy = "GAMEPADRIGHTTARGETMODIFIER", StickFriend = "GAMEPADLEFTTARGETMODIFIER" }) do
    ns[module] = { Bind = function()
        return { kind = "command", id = command, name = Binds.STICK[command], detail = "Hold, then push the right stick", icon = ns.Catalog.CommandIcon(command) }
    end }
end
-- The binds the row made, by the value the store keeps for them (saved.row). A store that was
-- saved with "Stick" has the two Stick Target binds on RB and LB, put there by the row: they go
-- where they are still there. One that the player put on another button is the player's and stays.
local ROW = {
    Stick = { { 1, "RB", "GAMEPADRIGHTTARGETMODIFIER" }, { 1, "LB", "GAMEPADLEFTTARGETMODIFIER" } },
    Cycle = {
        { 1, "RB", "TARGETNEARESTENEMY" }, { 1, "LB", "TARGETNEARESTFRIEND" },
        { 2, "RB", "TARGETPREVIOUSENEMY" }, { 2, "LB", "TARGETPREVIOUSFRIEND" },
    },
}

function Binds.Targeting()
    local value = ns.Registry.Get("combat.targeting")
    -- (a game setting: out of a fight)
    ns.Queue.Run("Targeting", function()
        ns.Adapter.TargetSwap(value == "Stick")
    end)
    -- (a store that was saved with only "Cycle was done" in it is read the same way)
    local was, now = saved.row or (saved.cycle and "Cycle") or nil, value == "Cycle" and value or nil
    local notes = {}
    if was ~= now then
        saved.row, saved.cycle = now, nil
        for _, entry in ipairs(ROW[was] or {}) do
            local bind = Binds.Get("normal", entry[1], entry[2])
            if bind and bind.id == entry[3] then
                Binds.Set("normal", entry[1], entry[2], nil)
                notes[#notes + 1] = (Binds.STICK[entry[3]] or entry[3]) .. " is taken off " .. entry[2]
            end
        end
        for _, entry in ipairs(ROW[now] or {}) do
            local layer, key, command = entry[1], entry[2], entry[3]
            local name, there = ns.Adapter.CommandName(command), Binds.Get("normal", layer, key)
            if name and not there then
                Binds.Set("normal", layer, key, { kind = "command", id = command, name = name, icon = ns.Catalog.CommandIcon(command) })
                notes[#notes + 1] = name .. " is on " .. key
            end
        end
    end
    if #notes > 0 then
        ns.Log.Add("binds", "Targeting " .. value .. ": " .. table.concat(notes, "; "))
    end
end

function Binds.OnLogin()
    -- Binds are kept for each character: its spells are its own. Builds before 0.6.0 kept one
    -- store for the account. The first character to log in takes that store.
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    if not GamepadSuiteCharDB.binds then
        local old = ns.Registry.Store("binds")
        -- a store from a build with no sets kept its layers in "pages": they are the Normal set
        GamepadSuiteCharDB.binds = { sets = old.sets or { normal = old.pages or {} }, filled = old.filled }
        old.sets, old.pages, old.filled = nil, nil, nil
    end
    saved = GamepadSuiteCharDB.binds
    -- the bind Quest Item of builds before 0.22.0 used the first usable quest item: it opens the Quest Item Wheel now
    Binds.Each(function(bind)
        if bind.kind == "questitem" then
            bind.kind, bind.id, bind.name, bind.detail = "wheel", "quest", "Quest Item Wheel", ""
        end
    end)
    -- at login, so the on-screen buttons are not empty where the game has a named action
    Binds.Fill()
    ns.StickEnemy.on = ns.Adapter.StickTargeting()
    ns.StickFriend.on = ns.StickEnemy.on
    Binds.Targeting()
    ns.Listen("setting", "Binds", function(key)
        if key == "combat.targeting" then
            Binds.Targeting()
        end
    end)
end
