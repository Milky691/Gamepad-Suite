-- The adapter's lists: what the player can put on a button, read from the game itself.
-- Nothing here is a list of ours. A new spell, item, macro, game command or emote shows by itself.
-- Each reader has a check at login (Adapter.lua). The catalog calls a reader only when its check passed.
local _, ns = ...

local Adapter = ns.Adapter

-- The known spells inside a spellbook flyout (mage portals, warlock demons), added to entries.
local function addFlyoutSpells(entries, flyoutId, flyoutName)
    local _, _, slots, known = GetFlyoutInfo(flyoutId)
    if not known then
        return
    end
    for slot = 1, slots do
        local spellId, overrideId, slotKnown, name = GetFlyoutSlotInfo(flyoutId, slot)
        if slotKnown then
            local id = (overrideId and overrideId ~= 0) and overrideId or spellId
            entries[#entries + 1] = {
                id = id, name = C_Spell.GetSpellName(id) or name, detail = flyoutName, icon = C_Spell.GetSpellTexture(id),
            }
        end
    end
end

-- The spellbook: { { name = tab name, entries = { { id, name, detail (the rank), icon } } } }.
-- Spells the player can cast only. Passive spells and the tabs of another talent set are left out.
function Adapter.Spells()
    local tabs, bank, kinds = {}, Enum.SpellBookSpellBank.Player, Enum.SpellBookItemType
    for line = 1, C_SpellBook.GetNumSpellBookSkillLines() do
        local info = C_SpellBook.GetSpellBookSkillLineInfo(line)
        if info and not info.offSpecID and not info.shouldHide and not info.isGuild then
            local entries = {}
            for index = info.itemIndexOffset + 1, info.itemIndexOffset + info.numSpellBookItems do
                local item = C_SpellBook.GetSpellBookItemInfo(index, bank)
                if item and item.itemType == kinds.Spell and item.spellID and not item.isPassive then
                    entries[#entries + 1] = { id = item.spellID, name = item.name, detail = item.subName, icon = item.iconID }
                elseif item and item.itemType == kinds.Flyout then
                    addFlyoutSpells(entries, item.actionID, item.name)
                end
            end
            tabs[#tabs + 1] = { name = info.name, entries = entries }
        end
    end
    return tabs
end

-- Items with a "Use" effect: the two trinkets that are worn, then the bags, by name. Each item once.
function Adapter.Items()
    local seen, worn, carried = {}, {}, {}
    local function add(list, itemId, detail)
        if itemId and not seen[itemId] and C_Item.GetItemSpell(itemId) then
            local name = C_Item.GetItemNameByID(itemId)
            if name then
                seen[itemId] = true
                list[#list + 1] = { id = itemId, name = name, detail = detail, icon = C_Item.GetItemIconByID(itemId) }
            end
        end
    end
    add(worn, GetInventoryItemID("player", 13), "Trinket")
    add(worn, GetInventoryItemID("player", 14), "Trinket")
    for bag = 0, 4 do
        for slot = 1, C_Container.GetContainerNumSlots(bag) do
            add(carried, C_Container.GetContainerItemID(bag, slot), "")
        end
    end
    table.sort(carried, function(a, b) return a.name < b.name end)
    for _, item in ipairs(carried) do
        worn[#worn + 1] = item
    end
    return worn
end

-- The player's macros: the shared ones, then this character's. A macro is known by its name.
function Adapter.Macros()
    local macros = {}
    local shared, own = GetNumMacros()
    local function add(first, count, detail)
        for index = first, first + count - 1 do
            local name, icon = GetMacroInfo(index)
            if name then
                macros[#macros + 1] = { id = name, name = name, detail = detail, icon = Adapter.MacroIcon and Adapter.MacroIcon({ kind = "macro", id = name }) or icon }
            end
        end
    end
    add(1, shared, "General")
    -- (this character's come after the shared places: Blizzard_MacroUI.lua 166 to 173)
    add((Constants and Constants.MacroConsts and Constants.MacroConsts.MAX_ACCOUNT_MACROS or 120) + 1, own, "This character")
    return macros
end

-- Every command of the game that has a name in the game's own key bindings list:
-- { { id = command, name, header = the game's group ("" when it has none), headerName } }.
function Adapter.Commands()
    local commands = {}
    local seen = {}
    for index = 1, GetNumBindings() do
        local command, header = GetBinding(index)
        local name = command and Adapter.CommandName(command)
        if name then
            header = header or ""
            seen[command] = true
            commands[#commands + 1] = { id = command, name = name, header = header, headerName = _G[header] or "" }
        end
    end
    -- the game's radial Main Menu, which its key bindings list hides: offered while the game's gamepad
    -- interface has it (the world map runs it by name: Blizzard_WorldMap.lua 1116)
    if not seen.OPENRADIAL and GamepadMode and GamepadMode.OpenRadial then
        commands[#commands + 1] = { id = "OPENRADIAL", name = Adapter.CommandName("OPENRADIAL"), header = "GAMEPAD_LABEL", headerName = "" }
    end
    return commands
end

-- Every emote the game has, by its token: token -> chat command ("/wave").
local function emoteCommands()
    local command = {}
    for index = 1, MAXEMOTEINDEX do
        local token = _G["EMOTE" .. index .. "_TOKEN"]
        if token and not command[token] then
            command[token] = _G["EMOTE" .. index .. "_CMD1"]
        end
    end
    return command
end

-- "/wave" shows as "Wave". A command that does not start with a plain letter keeps its own form.
local function emoteEntry(token, slash)
    local name = slash:gsub("^/(%l)", string.upper):gsub("^/", "")
    return { id = token, name = name, detail = slash }
end

-- The emotes with these tokens, in this order: { { id = the token, name, detail = its chat command } }.
-- A token the game does not have is left out. Each emote once.
function Adapter.EmotesByToken(tokens)
    local command, emotes, seen = emoteCommands(), {}, {}
    for _, token in ipairs(tokens) do
        if command[token] and not seen[token] then
            seen[token] = true
            emotes[#emotes + 1] = emoteEntry(token, command[token])
        end
    end
    return emotes
end

-- The emotes of the game's own chat menu: { animated = the ones with an animation, voice = the ones with a voice }.
function Adapter.Emotes()
    return { animated = Adapter.EmotesByToken(EmoteList), voice = Adapter.EmotesByToken(TextEmoteSpeechList) }
end

-- The pet's actions while the player has a pet bar: the bar's commands (Attack, Follow, Stay, the
-- three moods) and abilities, then the abilities in the pet's spellbook that are not on the bar.
-- A command is known by the game's token for it, an ability by its spell number.
function Adapter.PetActions()
    local actions, seen = {}, {}
    if not PetHasActionBar() then
        return actions
    end
    for slot = 1, NUM_PET_ACTION_SLOTS do
        local name, texture, isToken, _, _, _, spellId = GetPetActionInfo(slot)
        if name and isToken then
            actions[#actions + 1] = { id = name, name = _G[name] or name, detail = "Pet command", icon = _G[texture] }
        elseif name and not seen[name] then
            seen[name] = true
            actions[#actions + 1] = { id = spellId or name, name = name, detail = "Pet ability", icon = texture }
        end
    end
    local bank = Enum.SpellBookSpellBank.Pet
    for index = 1, bank and C_SpellBook.HasPetSpells and C_SpellBook.HasPetSpells() or 0 do
        local item = C_SpellBook.GetSpellBookItemInfo(index, bank)
        if item and item.itemType == Enum.SpellBookItemType.Spell and item.spellID and not item.isPassive and not seen[item.name] then
            seen[item.name] = true
            actions[#actions + 1] = { id = item.spellID, name = item.name, detail = "Pet ability", icon = item.iconID }
        end
    end
    return actions
end

-- The pet bar slot that holds a pet command (by the game's token) or a pet ability (by its spell
-- number or its name) now, or nil. A bind of either is a press of that slot (Core/BindRules.lua).
function Adapter.PetSlot(id)
    local ok, found = pcall(function()
        for slot = 1, PetHasActionBar() and NUM_PET_ACTION_SLOTS or 0 do
            local name, _, isToken, _, _, _, spellId = GetPetActionInfo(slot)
            if name and (name == id or (not isToken and spellId == id)) then
                return slot
            end
        end
    end)
    return ok and found or nil
end

-- The chat command of a slash command the game knows by this token ("/clearfocus"), or nil.
function Adapter.SlashCommand(token)
    return _G["SLASH_" .. token .. "1"]
end
