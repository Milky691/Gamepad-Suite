-- The adapter's part for Trackpad and Touch (Screen/Handoff.lua). The calls that take the lock
-- off the pointer are mouse mode's (AdapterPointer.lua). Here: is the pointer locked, how far
-- the sticks are pushed, the events that wake the watch, and how long the game itself waits.
local _, ns = ...

local Adapter = ns.Adapter

-- The game tells of every mouse button that goes down, over a frame or over the world, with the
-- button's name. A tap on a trackpad is such a press: ControllerForever begins its pointer mode
-- at this event, on this game.
Adapter.MOUSE_DOWN = "GLOBAL_MOUSE_DOWN"

-- The game's words that can mean "the pointer is free now": its lock for the camera ended, the
-- controller is not the device in use any more, the world came in. The game's code does not
-- show that the first two come at that moment, so nothing depends on them: a mouse button
-- always wakes the watch, and the log says which of these words came with a free pointer.
Adapter.POINTER_FREED = { "PLAYER_STOPPED_LOOKING", "GAME_PAD_ACTIVE_CHANGED", "PLAYER_ENTERING_WORLD" }

-- The game's words that the pointer went onto or off a unit (its own unit frames hear this one,
-- Blizzard_UnitFrame/Shared/CompactUnitFrame.lua 37 and 84) or a thing of the world (its notes:
-- "Sends an update when the mouse enters or leaves something in-world (object, unit, etc) that
-- should display a tooltip", CursorDocumentation.lua 50 to 58).
Adapter.POINTER_OVER = { "UPDATE_MOUSEOVER_UNIT", "WORLD_CURSOR_TOOLTIP_UPDATE" }

-- True while the game has the pointer hidden and locked for the camera.
function Adapter.PointerLocked()
    local ok, locked = pcall(IsMouselooking)
    return ok and locked and true or false
end

-- How far each stick of the controller is pushed now, 0 to 1, by the stick's place in the pad's
-- own state. Empty when the game cannot tell.
function Adapter.StickPushes()
    local pushes = {}
    pcall(function()
        for place, stick in ipairs(C_GamePad.GetDeviceMappedState().sticks) do
            pushes[place] = stick.len + 0
        end
    end)
    return pushes
end

-- After the controller was used, the game waits before it gives the pointer to the mouse: its
-- setting GamePadOverlapMouseMs, 2 seconds as the game comes (its own help text: "Duration after
-- gamepad+mouse input to switch to just one or the other"). ControllerForever keeps it at 0.3
-- seconds on this game, and so does Trackpad and Touch while it is on. It is held for the
-- session only (Adapter.HoldSetting), and a player's own shorter time is left as it is.
local WAIT, QUICK = "GamePadOverlapMouseMs", 300

function Adapter.PointerWait(quick)
    if not quick then
        Adapter.ReleaseSetting(WAIT)
        return
    end
    local ok, value = pcall(GetCVar, WAIT)
    if ok and (tonumber(value) or 0) > QUICK then
        Adapter.HoldSetting(WAIT, tostring(QUICK))
    end
end

-- For the log: what the game says about the pointer, the mouse and the controller now. A "?"
-- stands for a call that this game does not have.
local function say(fn, ...)
    local ok, first, second = pcall(fn, ...)
    return ok and (tostring(first) .. (second ~= nil and "," .. tostring(second) or "")) or "?"
end

function Adapter.HandoffState()
    return "locked=" .. tostring(Adapter.PointerLocked()) .. ", mouse in use=" .. say(IsUsingMouse)
        .. ", controller in use=" .. say(IsUsingGamepad) .. ", pointer step=" .. say(GetCursorDelta)
        .. ", " .. WAIT .. "=" .. say(GetCVar, WAIT)
end
