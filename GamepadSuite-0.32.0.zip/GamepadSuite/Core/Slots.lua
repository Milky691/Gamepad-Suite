-- The fixed slots: what each of the eight holds, and where it sits (the rules are in
-- Core/SlotRules.lua, the frames on the screen in Screen/Slots.lua).
--   What a slot holds is the character's own, as its binds are: GamepadSuiteCharDB.slots.
--   Where a slot sits is the same for every character, as the place of every other thing on the
--   screen: two settings for each slot.
--   A button with the bind "Slot 3" runs what slot 3 holds at that time.
-- Every change sends the message "slots".
local _, ns = ...

local Slots = ns.Module("Slots", nil, "Fixed Slots")
ns.Slots = Slots

local Rules, Registry = ns.SlotRules, ns.Registry
local saved -- { [1 to 8] = bind }: the action of each slot

-- The two settings of a slot's place have no row of their own. The rows Slot X Position and
-- Slot Y Position stand for the two of the slot that the row Slot to Move names (OnLogin).
for n = 1, Rules.MOST do
    Registry.Define("slots." .. n .. ".x", "number", Rules.PLACE[n][1], Rules.X)
    Registry.Define("slots." .. n .. ".y", "number", Rules.PLACE[n][2], Rules.Y)
end

function Slots.Get(n)
    return saved and saved[n]
end

-- Where a slot sits: x and y from the middle of the screen.
function Slots.Place(n)
    return Registry.Get("slots." .. n .. ".x"), Registry.Get("slots." .. n .. ".y")
end

-- The slot that the two position rows move now.
function Slots.Moving()
    return Rules.Number(Registry.Get("slots.move")) or 1
end

-- The buttons that show above a slot ({ "RT", "A" }) and their layer, or nil when it has no
-- button. It is the button that runs the slot now: in the form and the set in use at this time,
-- on a layer that is switched on.
function Slots.Keys(n)
    local get = Registry.Get
    local state = ns.Adapter.BindState(get("layers.combat_set"), get("layers.forms_and_stances") ~= "Off" and ns.Adapter.Forms() or {}, get("layers.forms_and_stances") == "Combat First")
    return Rules.Keys(function(fn)
        for layer = 1, 5 do
            if layer ~= 5 or get("layers.hold_lb_rb_set") then
                for key in pairs(ns.Adapter.KEY) do
                    local bind = ns.BindRules.Find(ns.Binds.Get, state, layer, key)
                    if bind then
                        fn(bind, "normal", layer, key)
                    end
                end
            end
        end
    end, n, saved and saved[n])
end

-- True when slot n holds a spell the character does not know now (SlotRules.Unknown): a talent
-- reset took it. Its button stays; the slot and its page say so (Screen/Slots.lua, Settings/SlotsModel.lua).
function Slots.Unknown(n)
    local bind = saved and saved[n] and ns.BindRules.Real(saved[n])
    return Rules.Unknown(bind, ns.Adapter.SpellKnown, ns.Adapter.SpellNow)
end

-- The slots that have an action, as entries for the bind list.
function Slots.Binds()
    return Rules.Binds(saved or {}, ns.Adapter.BindIcon)
end

-- What a tap or a click on a slot runs, as the attributes of a secure button; nil for a slot with
-- no action, or with one a click cannot run. A key can run any game command. A click cannot: for
-- a game command it runs the chat command that does the same, when there is one; a bind of ours
-- and a wheel are a click on our own button (a held bind of ours gets the let-go too,
-- SlotRules.Click). A friendly spell or item opens its party wheel in healer mode, as the same
-- action on a key does (Core/Wheels.lua Action).
function Slots.Tap(n)
    local bind = saved and saved[n] and ns.BindRules.Real(saved[n])
    if not bind then
        return nil
    elseif bind.kind == "command" then
        local text = ns.WheelRules.CommandText(bind.id, ns.Adapter.MenuButtons())
        return Rules.Click(bind.id) or (text and { type = "macro", macrotext = text }) or nil
    elseif bind.kind == "wheel" then
        return { type = "macro", macrotext = "/click " .. ns.BindRules.WHEEL_BUTTON .. " " .. bind.id .. " 1" }
    end
    return ns.Wheels.Action(bind)
end

-- Puts an action on a slot. A slot cannot hold a slot.
function Slots.Set(n, bind)
    if not saved or not Rules.PLACE[n] or bind.kind == "fixed" then
        return false
    end
    local new = saved[n] == nil
    saved[n] = { kind = bind.kind, id = bind.id, name = bind.name, icon = bind.icon, detail = bind.detail }
    -- the position rows move the slot that is new on the screen (quiet: the slots do not show
    -- above the settings window for this change, as they do for a change of a row)
    if new and Registry.Has("slots.move") then
        Slots.quiet = true
        Registry.Set("slots.move", Rules.Name(n))
        Slots.quiet = nil
    end
    ns.Send("slots")
    return true
end

-- Takes the action off a slot: it does not show any more, and a button that had the slot as its
-- bind has no bind.
function Slots.Clear(n)
    if not saved or not saved[n] then
        return false
    end
    saved[n] = nil
    local binds = {}
    ns.Binds.Each(function(bind, set, layer, key)
        if bind.kind == "fixed" and bind.id == n then
            binds[#binds + 1] = { set, layer, key }
        end
    end)
    for _, slot in ipairs(binds) do
        ns.Binds.Set(slot[1], slot[2], slot[3], nil)
    end
    ns.Send("slots")
    return true
end

-- All eight at once: a profile takes their place (Core/Profiles.lua).
function Slots.Replace(slots)
    GamepadSuiteCharDB.slots, saved = slots, slots
    ns.Send("slots")
end

function Slots.OnLogin()
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    GamepadSuiteCharDB.slots = GamepadSuiteCharDB.slots or {}
    saved = GamepadSuiteCharDB.slots
    -- a slot with the bind Quest Item of builds before 0.22.0 opens the Quest Item Wheel now
    for _, bind in pairs(saved) do
        if bind.kind == "questitem" then
            bind.kind, bind.id, bind.name, bind.detail = "wheel", "quest", "Quest Item Wheel", ""
        end
    end
    -- a button with the bind "Slot 3" runs what the slot holds now (a slot can hold Fishing Pole,
    -- which is itself the action of the moment)
    ns.BindRules.LIVE.fixed = function(bind)
        local action = saved[bind.id]
        return action and ns.BindRules.Real(action) or nil
    end
    for _, axis in ipairs({ "x", "y" }) do
        if Registry.Has("slots." .. axis) then
            Registry.Virtual("slots." .. axis, function()
                return Registry.Get("slots." .. Slots.Moving() .. "." .. axis)
            end, function(value)
                Registry.Set("slots." .. Slots.Moving() .. "." .. axis, value)
            end)
        end
    end
end
