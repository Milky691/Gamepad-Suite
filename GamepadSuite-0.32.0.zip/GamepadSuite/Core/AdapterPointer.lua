-- The adapter, part 9: what mouse mode asks the game (Screen/Pointer.lua). This game lets an
-- addon put the mouse pointer at a place and press a mouse button, one time for each press or
-- move that comes from the controller itself, and at no other time (its notes for these calls:
-- "Insecure code can only call this once in response to gamepad input hardware events"). The
-- notes give this group of calls no namespace, so they are globals, as GetCursorPosition is.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- The game's word for each thing it can allow: a move, a press (true), a let-go (false).
local KIND = { move = "MouseMove", [true] = "MouseDown", [false] = "MouseUp" }

local function allowed(what)
    local kinds = Enum.LimitedInputType
    local ok, yes = pcall(C_LimitedInput.LimitedInputAllowed, kinds and kinds[KIND[what]])
    return ok and yes == true
end

-- The screen in the units of the mouse pointer's place: its width, its height, and how many of
-- those units one unit of our frames is.
function Adapter.PointerSpace()
    local scale = UIParent:GetEffectiveScale()
    return UIParent:GetWidth() * scale, UIParent:GetHeight() * scale, scale
end

-- A frame's box (left, bottom, right, top) in the units of the pointer's place, or nil when the game
-- has not placed it.
function Adapter.FrameBox(f)
    local left, bottom, width, height = f:GetRect()
    if not left then
        return nil
    end
    local scale = f:GetEffectiveScale()
    return { left * scale, bottom * scale, (left + width) * scale, (bottom + height) * scale }
end

-- Puts the game's mouse pointer at a place. True when the game did it.
function Adapter.PointerMove(x, y)
    if not (results().pointer and allowed("move")) then
        return false
    end
    return (pcall(SetCursorPosition, x, y))
end

-- Presses a mouse button ("LeftButton", "RightButton") where the pointer is, or lets it go. True
-- when the game did it. The game does nothing for a button of its own that it protects in a fight.
function Adapter.PointerButton(button, down)
    if not (results().pointer and allowed(down)) then
        return false
    end
    return (pcall(down and SimulateMouseDown or SimulateMouseUp, button))
end

-- Where the game's mouse pointer is now.
function Adapter.PointerPlace()
    local ok, x, y = pcall(GetCursorPosition)
    return ok and x or 0, ok and y or 0
end

-- True while the game says that mouse button is down.
function Adapter.PointerHeld(button)
    local ok, down = pcall(IsMouseButtonDown, button)
    return ok and down and true or false
end

-- This game plays with the stick as the camera (its "freelook"): while a controller is in use it
-- keeps the game in mouselook, and mouselook holds the mouse pointer at its centered place: half
-- the width, and the setting CursorCenteredYPos (0.6) of the height. A move of the pointer comes
-- to nothing then, and a click goes to that place. The owner's 0.21.0 log said so at every click:
-- the pointer was asked to go under our picture, and the game still had it at 682, 461 (0.6 of
-- 768), with mouselook and freelook on. ConsolePort frees its cursor by turning the game's
-- freelook off (ConsolePort/Controller/Mouse.lua 292 to 303), and ControllerForever calls the
-- same switch on this game (ControllerForever_Command.lua 448 to 457); the game has it
-- (SetGamePadFreeLook and IsGamePadFreelookEnabled are names in its program). So while mouse mode
-- is on, freelook is off, and a press of the controller starts no mouselook. on = true gives the
-- game back what it had. Gives what the game says after, for the log.
local looked   -- freelook was on (true) or off when mouse mode took it; nil while nothing is held

function Adapter.CameraLook(on)
    if on then
        if looked then
            pcall(SetGamePadFreeLook, true)
        end
        looked = nil
    elseif looked == nil then
        local ok, was = pcall(IsGamePadFreelookEnabled)
        looked = ok and was and true or false
        pcall(SetGamePadFreeLook, false)
        Adapter.PointerFree(true)
    end
    return Adapter.PointerState()
end

-- While mouse mode is on: the game turned its freelook on again, or holds the pointer in
-- mouselook; both are stopped (frame by frame, and at a press of ours before the click), as
-- ControllerForever does for the pointer of a trackpad. The hand-off of a trackpad (no always)
-- leaves mouselook alone while a mouse button is down: a drag with the right button turns the
-- camera. Mouse mode (always) holds no mouse button and binds no mouse command of the game, so
-- for it every mouselook is the camera taking the pointer: the owner's 0.23.0 log had the game
-- saying a mouse button was down long after its let-go, and the pointer held in the middle all
-- that time. True when something had to be stopped.
-- Mouse mode sets nothing free where the game allows no move of its pointer now: the game takes its
-- pointer back for the camera after a click and holds it, hidden, at its centered place, and set
-- free there with no move after it, it showed in the middle of the screen next to ours (the owner's
-- report of 0.25.1). Set free only at a press or a move of the controller, it goes under ours at once.
function Adapter.PointerFree(always)
    if always and not allowed("move") then
        return false
    end
    local stopped = false
    local okFree, free = pcall(IsGamePadFreelookEnabled)
    if looked ~= nil and okFree and free then
        pcall(SetGamePadFreeLook, false)
        stopped = true
    end
    local ok, locked = pcall(IsMouselooking)
    if ok and locked and (always or not (Adapter.PointerHeld("LeftButton") or Adapter.PointerHeld("RightButton"))) then
        pcall(MouselookStop)
        stopped = true
    end
    return stopped
end

-- True while the game shows its own mouse pointer: it hides it while it holds it for the camera.
function Adapter.PointerShows()
    local ok, held = pcall(IsMouselooking)
    return ok and not held
end

-- A frame's name for the log, or "?" for one the game does not name to an addon.
function Adapter.FrameName(frame)
    local ok, name = pcall(frame.GetDebugName, frame)
    return ok and type(name) == "string" and name or "?"
end

-- What is under the game's own pointer: "world" where no frame of the interface takes the mouse
-- (a click there goes to the world), else that frame. nil when the game does not tell.
function Adapter.PointerFocus()
    local ok, region = pcall(function() return GetMouseFoci()[1] end)
    if not ok then
        return nil
    end
    return (region == nil or region == WorldFrame) and "world" or region
end

-- For the log: is the pointer held for the camera, is the stick the camera, and what is under
-- the game's pointer now (what a click there goes to).
function Adapter.PointerState()
    local okLook, look = pcall(IsMouselooking)
    local okFree, free = pcall(IsGamePadFreelookEnabled)
    local over = Adapter.PointerFocus()
    over = over == "world" and "nothing" or over and Adapter.FrameName(over) or "?"
    return "mouselook=" .. tostring(okLook and look) .. ", freelook=" .. tostring(okFree and free) .. ", under it: " .. over
end

-- Mouse mode's aim (Screen/PointerAim.lua): LT and RT go straight onto what the pointer rests on.
--
-- A button: the game's own secure button has an action that clicks another button, as the game's
-- own code (SECURE_ACTIONS.click, Blizzard_FrameXML/SecureTemplates.lua 557 to 564), so a button
-- that the game protects (a bag slot, a bar button) takes it too, out of a fight, and no "blocked"
-- box comes after. ControllerForever presses the game's map button and its Start menu entries this
-- way on this game (ControllerForever_RuleBar.lua 10561 to 10586: calling the map's own function
-- "got the blocked box"; ControllerForever_Wheel.lua 2290 to 2306). A key bound to it is a real
-- press. Made out of a fight. clicked(mouse, frame) is told after each click.
function Adapter.PointerClicker(name, clicked)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    -- one whole click at the let-go of the key, as a mouse click (SecureTemplates.lua 802 to 822:
    -- with useOnKeyDown false the action runs at the let-go); the press does nothing
    button:RegisterForClicks("AnyUp")
    button:SetAttribute("useOnKeyDown", false)
    button:SetAttribute("type", "click")
    button:HookScript("PostClick", function(self, mouse)
        clicked(mouse, self:GetAttribute("clickbutton"))
    end)
    return button
end

-- The frame that secure button clicks for a frame under the pointer: the frame itself or the
-- nearest frame around it that is a button with a click of its own that the game lets a script
-- click (the game's own test, SecureTemplates.lua 561). A mouse that clicks the bar of a unit frame
-- clicks the unit frame (the owner's 0.23.0 log: the pointer on PlayerFrame's mana bar found no
-- button). nil: only a mouse button at the place reaches it (a text box, a slider, the face of a
-- window).
function Adapter.ClickTarget(frame)
    while frame do
        local ok, button = pcall(function()
            return frame:IsObjectType("Button") and frame:GetScript("OnClick") ~= nil and not frame:HasAccessConstraints()
                and not frame:HasAnyForbiddenAspects(Enum.ForbiddenAspect.ScriptedInput)
        end)
        if ok and button then
            return frame
        end
        local okParent, parent = pcall(frame.GetParent, frame)
        frame = okParent and parent or nil
    end
end

-- The world: RT runs the game's interact, a command held by owner as TakeKey's button holds a
-- click. With the game's pointer under ours ("world") it is the game's interact with what is under
-- its pointer, else with what it highlights (Blizzard_FrameXML/Bindings_Camelot.xml 1139 to 1146;
-- the second is the one X runs on the game's own controller bar, Screen/HudModel.lua 220 to 223).
-- Neither moves the camera. Never the game's two mouse commands (1521 to 1534): a held trigger was
-- a camera drag with them. True when the key reads back as that command. Not in a fight, nor at
-- its start.
Adapter.WORLD = { world = "INTERACTMOUSEOVER", near = "INTERACTTARGET" }
function Adapter.TakeKeyFor(owner, ourKey, command)
    if ns.fightStarted or InCombatLockdown() then
        return false
    end
    SetOverrideBinding(owner, true, Adapter.KEY[ourKey], command)
    return GetBindingAction(Adapter.KEY[ourKey], true) == command
end

-- Tells fn(unit) when the game runs its interact. For the log. Only heard: the hook runs after the
-- game's own call.
function Adapter.OnInteract(fn)
    if type(C_PlayerInteractionManager) == "table" and type(C_PlayerInteractionManager.InteractUnit) == "function" then
        hooksecurefunc(C_PlayerInteractionManager, "InteractUnit", fn)
    end
end

-- The name of a unit ("mouseover": under the game's pointer; "softinteract": what the game
-- highlights to interact with), for the log: "no unit" when there is none.
function Adapter.UnitLabel(unit)
    local ok, name = pcall(UnitName, unit)
    return ok and type(name) == "string" and name or "no unit"
end

-- What View's key does now: the name of the button it clicks (a bind of the player's, or the
-- game's own button for its party frames or a window), "" for none, or nil for a command of the
-- game. With none the game's own action for View runs, its Focus UI: it comes from the game's
-- controller binds (Blizzard_Gamepad/Bindings.xml 6 to 8), which the key does not read back (the
-- bind core's log: "the game's Focus UI ran ... the key reads ").
function Adapter.ViewAction()
    local binding = Adapter.EffectiveBinding(Adapter.KEY.VW) or ""
    return binding == "" and "" or binding:match("^CLICK ([^:]+):")
end

-- True while View is down (Adapter.ButtonDown asks the key state and the pad).
function Adapter.ViewHeld()
    return Adapter.ButtonDown("VW")
end

-- Tells fn(down) after each press and let-go of a button, by its name. The button's own work is
-- not touched: the hook runs after it. True when the button is there.
function Adapter.HookPress(name, fn)
    local button = _G[name]
    if type(button) ~= "table" or not button.HookScript then
        return false
    end
    button:HookScript("PostClick", function(_, _, down)
        fn(down and true or false)
    end)
    return true
end

-- The switch of a frame that hands every stick it hears on to the game. A frame of an addon
-- that takes the sticks takes every stick; what its script gives back hands nothing on. The
-- game refuses the switch in a fight. Gives what the switch reads after.
function Adapter.HandSticksOn(frame)
    pcall(frame.SetPropagateKeyboardInput, frame, true)
    local ok, on = pcall(frame.GetPropagateKeyboardInput, frame)
    return ok and on and true or false
end

-- While mouse mode is on, a trigger must not be Shift, Ctrl or Alt too: a click with LT would be
-- a Shift click. The game's settings that say so are held at "none" for that time, the game's own
-- way for a setting of the session (Adapter.HoldSetting), and are let go after.
local EMULATE = { "GamePadEmulateShift", "GamePadEmulateCtrl", "GamePadEmulateAlt" }
local held = {}

function Adapter.PointerTriggers(on)
    for _, name in ipairs(EMULATE) do
        if on then
            local ok, value = pcall(GetCVar, name)
            if ok and (value == Adapter.KEY.LT or value == Adapter.KEY.RT) and Adapter.HoldSetting(name, "none") then
                held[name] = value
            end
        elseif held[name] then
            Adapter.ReleaseSetting(name)
            held[name] = nil
        end
    end
end

-- The magnet's windows (Screen/PointerMagnet.lua). The game lists its windows by name: its panels
-- (UIParentPanelManager.lua 82, filled by UIPanelWindows.lua), the frames that Escape closes (21)
-- and the old menus (Game.lua 54). The bags (Mainline/ContainerFrame.xml 300 to 308, which
-- Camelot/ContainerFrame.lua 12 builds on) and the popups (GameDialog.xml 339 to 354) are on no
-- list; ConsolePort's cursor adds them by name the same way. A name that is not there is passed over.
Adapter.Check("pointerMagnet", function()
    return type(UIPanelWindows) == "table" and type(UISpecialFrames) == "table" and EventRegistry and EventRegistry.RegisterCallback ~= nil
end)

-- Gives fn each window of the game that is there now (a window of an addon of the game's that is
-- not loaded yet is not), and none that is closed to addons.
function Adapter.PointerWindows(fn)
    local function give(name)
        local frame = _G[name]
        if type(frame) == "table" and frame.IsForbidden and not frame:IsForbidden() and frame.HookScript then
            fn(frame)
        end
    end
    for name in pairs(UIPanelWindows) do
        give(name)
    end
    for _, list in ipairs({ UISpecialFrames, type(UIMenus) == "table" and UIMenus or {} }) do
        for _, name in ipairs(list) do
            give(name)
        end
    end
    give("ContainerFrameCombinedBags")
    for i = 1, tonumber(NUM_CONTAINER_FRAMES) or 13 do
        give("ContainerFrame" .. i)
    end
    for i = 1, tonumber(STATICPOPUP_NUMDIALOGS) or 4 do
        give("StaticPopup" .. i)
    end
end

-- Tells fn(window) when the game shows one of its panels: a panel of an addon of the game's that
-- loaded late is heard here first. The game's own controller code hears the same message
-- (FrameControlsManager.lua 210; it is sent at UIParentPanelManager.lua 874).
local PANELS = {}
function Adapter.OnPanelShown(fn)
    EventRegistry:RegisterCallback("UIParentPanelManager.ShowUIPanel", function(_, frame)
        if type(frame) == "table" and frame.IsForbidden and not frame:IsForbidden() and frame.HookScript then
            fn(frame)
        end
    end, PANELS)
end

-- One of those settings as it is for the player: what we hold it away from while mouse mode is
-- on, or what the game says. The bind core plans the binds with this, so a plan that is made
-- while mouse mode is on is right for the time after it.
function Adapter.EmulateSetting(name)
    if held[name] then
        return true, held[name]
    end
    return pcall(GetCVar, name)
end
