-- The adapter's part for Sort Bags (Windows/BagSort.lua) and Window Tooltips (Windows/WindowTips.lua).
--
-- What the game's code says:
--   C_Container.SortBags takes nothing and has no restriction mark
--   (Blizzard_APIDocumentationGenerated/ContainerDocumentation.lua 553 to 556). The game's own
--   "Clean Up Bags" in the gamepad bag menu calls it from a click of the menu
--   (Blizzard_UIPanels_Game/Mainline/ContainerFrame.lua 735 to 741). The bank's own clean-up
--   plays the sort sound UI_BAG_SORTING_01 (Mainline/BankFrameTemplates.lua 1858).
--   With the controller the bags are one window, ContainerFrameCombinedBags, a window of the
--   game's window manager (Blizzard_GamepadSharedUtility/FrameControlsManager.lua 235 to 241).
--   Its buttons there: A picks up or repairs, X sells, reads, opens, uses, equips or folds a
--   bag, Y opens the bag's menu or More Actions, B closes (ContainerFrame.lua 3259 to 3370); LT
--   and RT go from window to window (PromptedBindingFooter.lua 116 to 128,
--   FrameControlsManager.lua 200 and 201); R3 turns the tooltips off and on (202). The window
--   blocks only the D-pad and the face buttons for everything else (205 and 206,
--   InputBindingStack/BindingSetFactory.lua 118 to 129). L3 has no job in the window; outside
--   one it is the game's Auto Run (Blizzard_Gamepad/UI/PersistentInputLegend/
--   GamepadPersistentInputLegend.lua 332). LB and RB have no job there either.
--   The game's bag menu is not offered while the pointer holds an item
--   (ContainerFrame.lua 3073 to 3075). Nothing of the game is written; the window is only read.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

Adapter.Check("bagSort", function()
    return C_Container.SortBags and ContainerFrameCombinedBags.HookScript and GamepadMode.FrameControlsManager
        and CursorHasItem and C_EventUtils.IsEventValid("BAG_UPDATE_DELAYED") == true
end)

-- The game's bag window of the controller, or nil on a game without the sort.
function Adapter.SortBagsWindow()
    return results().bagSort and ContainerFrameCombinedBags or nil
end

-- Tells fn each time the bag window shows or hides. It runs inside the game's code: fn must only take note.
function Adapter.OnSortBagsWindow(fn)
    if results().bagSort then
        Adapter.OnShownOrHidden(ContainerFrameCombinedBags, fn)
    end
end

-- True while the pointer holds an item.
function Adapter.PointerHoldsItem()
    local ok, holds = pcall(CursorHasItem)
    return ok and holds and true or false
end

-- Asks the game to sort the bags, as its own Clean Up Bags does, with the game's sort sound.
-- Not in a fight. True when the call was made with no error, else false and why; the game's
-- answer is that the bags change.
function Adapter.SortBags()
    if not results().bagSort or InCombatLockdown() then
        return false, "a fight, or the game has no sort"
    end
    local ok, err = pcall(C_Container.SortBags)
    if not ok then
        return false, tostring(err)
    end
    pcall(PlaySound, SOUNDKIT.UI_BAG_SORTING_01)
    return true
end

-- ---------------------------------------------------------------- window tooltips (Windows/WindowTips.lua)
-- The game hides every tooltip while one of its windows shows and its option GamepadDisableTooltips is on
-- (Blizzard_GameTooltip/Mainline/GameTooltip.lua 380 to 388). The option is one for the whole game. R3 in a
-- window turns it on and off (Blizzard_GamepadSharedUtility/FrameControlsManager.lua 176 to 188 and 209), and
-- so does the action bar editor (Blizzard_GamepadActionBars/ActionBarEditFrame.lua 159 and 160). But R3 works
-- only while the window manager's binds are on (FrameControlsManager.lua 120 to 130), and Professions shows L3
-- for it with no job (Blizzard_Professions/Blizzard_ProfessionsFrame.lua 1080). So the option can stay on, and
-- the tooltips of every window stay hidden.
Adapter.Check("windowTips", function()
    local manager = GamepadMode.FrameControlsManager
    return GetCVarBool and SetCVar and GameTooltip.Hide and GamepadMode.IsBindingGroupActive and manager.gamepadBindings
        and manager.FrameShown and manager.FrameHidden and manager.GetShownFrameCount
end)

-- True while the game hides the tooltips of its windows.
function Adapter.WindowTipsHidden()
    local ok, hidden = pcall(GetCVarBool, "GamepadDisableTooltips")
    return ok and hidden and true or false
end

-- Turns the tooltips of the game's windows on or off, as the game's R3 does. The game's window
-- navigation is not touched, so a tooltip turned on shows at the next move.
function Adapter.SetWindowTips(on)
    pcall(SetCVar, "GamepadDisableTooltips", not on)
    if not on then
        GameTooltip:Hide()
    end
end

-- True while the game's own R3 for the tooltips works: the window manager's binds are on. Only read.
function Adapter.GameTogglesTips()
    local ok, on = pcall(function()
        return GamepadMode.IsBindingGroupActive(GamepadMode.FrameControlsManager.gamepadBindings)
    end)
    return ok and on and true or false
end

-- The window of the game that has the controller now, or nil (also while the player walks with a
-- window open, and with the mouse interface: Core/AdapterGameWindows.lua WindowHasPad).
function Adapter.FocusedWindow()
    local ok, window = pcall(function()
        local manager = GamepadMode.FrameControlsManager
        return manager.isUIFocused and manager.focusedFrame:IsShown() and manager.focusedFrame or nil
    end)
    return ok and window or nil
end

-- The Professions window, or nil before the game loads it.
function Adapter.ProfessionsWindow()
    return ProfessionsFrame
end
