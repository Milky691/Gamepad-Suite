-- The adapter's part for Low Battery Warning (Auto/Battery.lua) and Button Icons
-- (Screen/ButtonIcons.lua): the controller's battery, and the pictures of the buttons.
--
-- Battery: the game tells of a change of the battery's level with GAME_PAD_POWER_CHANGED, and
-- C_GamePad.GetPowerLevel reads it; its levels are Critical 0, Low 1, Medium 2, High 3, Wired 4
-- and Unknown 5 (Blizzard_APIDocumentationGenerated/GamePadDocumentation.lua 206 to 220 and 334
-- to 341, GamePadConstDocumentation.lua 6 to 19). ConsolePort reads the same on the retail game
-- (Model/Gamepad/Gamepad.lua 6, 128 and 207).
--
-- Button Icons: the game draws a button with the pictures of one of its sets, the set of the
-- controller in use (Blizzard_SharedXML/Shared/InputIcons/InputDeviceIconSetManager.lua 22 to
-- 41). Its table of sets is local to its file, so the names of the pictures are here, as that
-- file gives them for the state Normal (InputIconTexture.lua 114 to 556).
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("battery", function()
    return C_GamePad.GetPowerLevel and Enum.GamePadPowerLevel.Low and C_EventUtils.IsEventValid("GAME_PAD_POWER_CHANGED") == true
end)
local results = Adapter.Results

-- The battery's level now, as the game counts it; nil when the game does not say.
function Adapter.BatteryLevel()
    local ok, level = pcall(C_GamePad.GetPowerLevel)
    return ok and results().battery and level or nil
end

-- True for a level of the battery that is low or lower.
function Adapter.BatteryLow(level)
    local ok, low = pcall(function()
        return level == Enum.GamePadPowerLevel.Low or level == Enum.GamePadPowerLevel.Critical
    end)
    return ok and low or false
end

-- True for a level that tells the charge: Medium or High. Wired and Unknown tell none.
function Adapter.BatteryPlain(level)
    local ok, plain = pcall(function()
        return level == Enum.GamePadPowerLevel.Medium or level == Enum.GamePadPowerLevel.High
    end)
    return ok and plain or false
end

-- The picture of each button in each set: Xbox style (the game's set Letters), PlayStation
-- style (Shapes) and Nintendo style (Reverse), by the game's name of the button.
local STYLE = { ["Xbox style"] = 1, ["PlayStation style"] = 2, ["Nintendo style"] = 3 }
local ATLAS = {
    PAD1 = { "gamepad-xbox1-buttona-normal", "gamepad-ps-buttoncrox-normal", "gamepad-switch-128x-face-b-normal" },
    PAD2 = { "gamepad-xbox1-buttonb-normal", "gamepad-ps-buttoncircle-normal", "gamepad-switch-128x-face-a-normal" },
    PAD3 = { "gamepad-xbox1-buttonx-normal", "gamepad-ps-buttonsquare-normal", "gamepad-switch-128x-face-y-normal" },
    PAD4 = { "gamepad-xbox1-buttony-normal", "gamepad-ps-buttontriangle-normal", "gamepad-switch-128x-face-x-normal" },
    PADLSHOULDER = { "gamepad-xbox1-trigger-lb-normal", "gamepad-ps-triggerl1-normal", "gamepad-switch-128x-shoulder-l-normal" },
    PADRSHOULDER = { "gamepad-xbox1-trigger-rb-normal", "gamepad-ps-triggerr1-normal", "gamepad-switch-128x-shoulder-r-normal" },
    PADLTRIGGER = { "gamepad-xbox1-trigger-lt-normal", "gamepad-ps-triggerl2-normal", "gamepad-switch-128x-zl-normal" },
    PADRTRIGGER = { "gamepad-xbox1-trigger-rt-normal", "gamepad-ps-triggerr2-normal", "gamepad-switch-128x-zr-normal" },
    PADDUP = { "gamepad-xbox1-dpadup-normal", "gamepad-ps-dpadup-normal", "gamepad-switch-128x-dpad-up-normal" },
    PADDDOWN = { "gamepad-xbox1-dpaddown-normal", "gamepad-ps-dpaddown-normal", "gamepad-switch-128x-dpad-down-normal" },
    PADDLEFT = { "gamepad-xbox1-dpadleft-normal", "gamepad-ps-dpadleft-normal", "gamepad-switch-128x-dpad-left-normal" },
    PADDRIGHT = { "gamepad-xbox1-dpadright-normal", "gamepad-ps-dpadright-normal", "gamepad-switch-128x-dpad-right-normal" },
    DIRPAD = { "gamepad-xbox1-dpadall-normal", "gamepad-ps-dpadall-normal", "gamepad-switch-128x-dpad-all-normal" },
    PADLSTICK = { "gamepad-xbox1-stick-l3-normal", "gamepad-ps-stickl3-normal", "gamepad-switch-128x-stick-l3-normal" },
    PADRSTICK = { "gamepad-xbox1-stick-r3-normal", "gamepad-ps-stickr3-normal", "gamepad-switch-128x-stick-r3-normal" },
    PADBACK = { "gamepad-xbox1-view-normal", "gamepad-ps-touchpad-normal", "gamepad-switch-128x-minus-normal" },
    PADFORWARD = { "gamepad-xbox1-menu-normal", "gamepad-ps-menu-normal", "gamepad-switch-128x-plus-normal" },
    CENTERBUTTON = { "gamepad-xbox1-xblogo-normal", "gamepad-ps-pslogo-normal", "gamepad-switch-128x-home-normal" },
}
local style   -- the set the player picked; nil for the game's own set (Auto)

function Adapter.SetIconStyle(choice)
    style = STYLE[choice]
end

-- The picture of a button (the game's name of it) in the set the player picked; nil for Auto,
-- and for a button the set has no picture of (the back grips): then the game's own set draws it.
function Adapter.StyleAtlas(gameKey)
    return style and ATLAS[gameKey] and ATLAS[gameKey][style] or nil
end
