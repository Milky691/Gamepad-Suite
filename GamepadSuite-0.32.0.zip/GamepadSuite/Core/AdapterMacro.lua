-- The adapter's part for a macro of the player's on a button: what it would use now. On the
-- game's own bar a macro shows the spell or the item that it would use at this moment, by its
-- conditions ([mod], [form], [@target,harm]): the picture (when its picture is the question
-- mark), the cooldown, the count, can it be used, is the target in reach. Every question of
-- Core/AdapterHud.lua about a bind asks Adapter.Now first, so each place that shows a bind (the
-- on-screen buttons and their small pictures, the fixed slots, the cooldown list, the wheels, the
-- Binds page) shows the same as the game's bar.
local _, ns = ...

local Adapter = ns.Adapter

-- The question mark, the picture of a macro whose player chose none: the game's macro window
-- reads it back as this number (Blizzard_FrameXMLBase/IconDataProvider.lua:2, 193), and the
-- game keeps it so in the saved macros (macros-cache.txt of the owner: "134400").
local QUESTION = 134400

-- What a bind uses now, as a bind of a spell or of an item. For a macro that is the one the game
-- would use at this moment: the spell (GetMacroSpell), else the item, which the game gives as its
-- name and its link (GetMacroItem). Any other bind, and a macro that uses neither now (a /say
-- line, or no condition is met), comes back as it is.
function Adapter.Now(bind)
    if not bind or bind.kind ~= "macro" then
        return bind
    end
    local ok, now = pcall(function()
        local spell = GetMacroSpell and GetMacroSpell(bind.id)
        if type(spell) == "number" then
            return { kind = "spell", id = spell }
        end
        local _, link = GetMacroItem(bind.id)
        local item = type(link) == "string" and tonumber(link:match("item:(%d+)"))
        return item and { kind = "item", id = item } or nil
    end)
    return ok and now or bind
end

-- One play tells what the game answers for a macro: a line each time a macro uses another thing,
-- a few lines at most.
local said, lines = {}, 0
local function tell(name, icon, now)
    if lines < 8 and said[name] ~= now.id then
        said[name], lines = now.id, lines + 1
        local what = now.kind == "macro" and "nothing" or now.kind .. " " .. tostring(now.id)
        ns.Log.Add("screen", "The macro " .. tostring(name) .. " has the picture " .. tostring(icon) .. " and uses " .. what .. " now.")
    end
end

-- The picture of a macro: the one its player chose, or, with the question mark, the picture of
-- what it would use now. nil when the game gives none (a macro that was renamed or deleted).
function Adapter.MacroIcon(bind)
    local ok, icon = pcall(function()
        local _, icon = GetMacroInfo(bind.id)
        local now = Adapter.Now(bind)
        pcall(tell, bind.id, icon, now)
        return icon == QUESTION and now ~= bind and Adapter.BindIcon(now) or icon
    end)
    return ok and icon or nil
end
