-- The adapter's part for who has the talks with NPCs (Screen/DialogueTake.lua): the game's own
-- gossip window and quest window hear the events that open them, or the dialogue view has the
-- talks. Also: another addon that has the game's windows already, a controller in use, and the
-- game's other windows that end a talk. The head of AdapterDialogue.lua has the proof from the
-- game's code; its login check covers this file.
local _, ns = ...

local Adapter = ns.Adapter

local OPENS = { "QUEST_GREETING", "QUEST_DETAIL", "QUEST_PROGRESS", "QUEST_COMPLETE" }
local asked = false   -- the chat has asked for a reload
local had             -- the events the game's frames heard before the first take, as { frame, event }

-- Which of the five events the game's frames hear, read one time before the first take. Only
-- these are taken and given back: an event that another addon took from the game's frame is
-- never given back to it.
local function before()
    if not had then
        had = {}
        local function one(frame, event)
            local ok, on = pcall(frame.IsEventRegistered, frame, event)
            if ok and on then
                had[#had + 1] = { frame, event }
            end
        end
        for _, event in ipairs(OPENS) do
            one(QuestFrame, event)
        end
        one(CustomGossipFrameManager, "GOSSIP_SHOW")
    end
    return had
end

-- The game's frames hear their events (on), or do not. Each event is asked for in a call of its
-- own and read back, so one that the game refuses does not stop the others. True when all read
-- back as asked.
local function hear(on)
    local held = true
    for _, pair in ipairs(before()) do
        local frame, event = pair[1], pair[2]
        pcall(frame[on and "RegisterEvent" or "UnregisterEvent"], frame, event)
        local ok, now = pcall(frame.IsEventRegistered, frame, event)
        held = held and ok and now == on
    end
    return held
end

-- Takes the events that open the game's gossip window and quest window from them (on), or gives
-- them back. True when the game's frames read back as asked. A take that did not hold is given
-- back at once: then the game's own windows work as always. When an event cannot be given back,
-- a window of the game would stay shut for the session: the chat asks for a reload, one time.
function Adapter.DialogueTake(on)
    local ok, held = pcall(hear, not on)
    held = ok and held or false
    local back = (on and not held) and select(2, pcall(hear, true)) or held
    if (not on or not held) and back ~= true and not asked then
        asked = true
        ns.Print("The game's own gossip and quest windows did not come back. Type /reload to get them back.")
    end
    return held
end

-- True while one of the game's two windows shows.
function Adapter.DialogueGameWindow()
    local ok, shown = pcall(function()
        return GossipFrame:IsShown() or QuestFrame:IsShown()
    end)
    return ok and shown and true or false
end

-- Another addon that has the game's windows already. Asked at login, before the first take: all
-- addons are loaded then. True and the addon's name for Immersion (its name in the addon list,
-- or one of its two frames: it puts the game's windows under a hidden frame and they hear
-- nothing). True alone when the game's quest window does not hear an offer and no addon is known
-- (the addon DialogueUI does the same). False when the game's windows are free.
function Adapter.DialogueOther()
    if Adapter.AddonLoaded("Immersion") or _G.ImmersionFrame ~= nil or _G.ImmersionAPI ~= nil then
        return true, "Immersion"
    end
    local ok, on = pcall(QuestFrame.IsEventRegistered, QuestFrame, "QUEST_DETAIL")
    return ok and not on, nil
end

-- True while a controller is in use: the game takes the controller's input, and a controller is
-- connected (the game's active device has a map of its buttons, as the game's own button
-- pictures ask: InputDeviceIconSetManager.lua 34 to 41; or the game lists a device). The last
-- input is not asked: a touch of the mouse would end a talk. A game build that cannot say has
-- the game's setting alone.
function Adapter.DialoguePad()
    if not Adapter.PadActive() then
        return false
    end
    local ok, there = pcall(function()
        local id = C_GamePad.GetActiveDeviceID()
        return id ~= nil and C_GamePad.GetDeviceMappedState(id) ~= nil or #(C_GamePad.GetAllDeviceIDs() or {}) > 0
    end)
    return not ok or there and true or false
end

-- For the log: what the game says of the last input, "controller", "mouse or keyboard" or "unknown".
function Adapter.DialogueLastInput()
    local ok, on = pcall(IsUsingGamepad)
    return not ok and "unknown" or on and "controller" or "mouse or keyboard"
end

-- True for the kinds of the game's interaction windows that are a part of a talk: a gossip, a
-- quest giver, an item's text (Enum.PlayerInteractionType 3, 4 and 2). Every other kind is a
-- window of its own (a vendor, a trainer, a flight map, the bank, the mail) and ends the talk:
-- the game's own gossip window would hide for it, and its hide ends the gossip
-- (Shared/PlayerInteractionFrameManager.lua 165 to 177, GossipFrameShared.lua 176 to 185).
-- True and true for the two kinds that are only a box of the game's: the inn's "make this inn
-- your home" and the spirit healer (Binder 20, SpiritHealer 18). No window of the game is made
-- for them (no RegisterPlayerInteraction in the game's code), so the game's own gossip window
-- stays behind the box; the box answers with ConfirmationInteraction and hides itself when that
-- interaction is no longer valid (Blizzard_StaticPopup_Game/GameDialogDefs.lua 2410 to 2430,
-- Mainline/GameDialogDefs.lua 1178 to 1201). So the talk is not closed under the box.
function Adapter.DialogueStays(kind)
    local types = Enum and Enum.PlayerInteractionType or {}
    if kind == (types.Binder or 20) or kind == (types.SpiritHealer or 18) then
        return true, true
    end
    return kind == (types.Gossip or 3) or kind == (types.QuestGiver or 4) or kind == (types.Item or 2)
end

-- True when the game has a window of its own for a gossip's texture kit (Mainline/
-- CustomGossipFrameBase.lua 21 to 33). For the log only: the view shows a plain list.
function Adapter.DialogueKitWindow(kit)
    local ok, has = pcall(function()
        return CustomGossipFrameManager.handlers[kit] ~= nil
    end)
    return ok and has or false
end

-- Tells fn each time a choice of a gossip is taken, by anybody: this addon's Skip Gossip, the
-- view, another addon. The game's calls are watched; nothing of the game's is replaced.
function Adapter.OnGossipChosen(fn)
    for _, name in ipairs({ "SelectOption", "SelectOptionByIndex" }) do
        if type(C_GossipInfo[name]) == "function" then
            hooksecurefunc(C_GossipInfo, name, function() fn() end)
        end
    end
end
