-- The core: module list, game events, messages between modules, start-up order.
-- A feature module tells the others of a change with a message (ns.Send), and hears theirs
-- (ns.Listen). Where it needs an answer at once it asks the other module by its name
-- (ns.Pad.Gameplay(), ns.Pointer.IsOn()).
local ADDON, ns = ...

ns.addon = ADDON
ns.modules = {}

local frame = CreateFrame("Frame")
local unitFrame = CreateFrame("Frame")
local eventOwners = {}   -- event -> { owner = fn }
local unitOwners = {}    -- event -> { owner = fn }, for the events that are heard for one unit only
local unitOf = {}        -- event -> that unit
local messageOwners = {} -- message -> { owner = fn }
local unknown = {}       -- event names this game build does not have
-- The game sends these two whatever the modules ask for: the core itself marks the fight by them.
local KEPT = { PLAYER_REGEN_DISABLED = true, PLAYER_REGEN_ENABLED = true }

-- True from the moment the game tells that a fight starts, before any module hears of it, until
-- it tells that the fight is over. A module that hears of the start late can ask here if the
-- fight has begun, whatever the game's own lock says at that moment.
ns.fightStarted = false

-- Every callback goes through here, so an error is logged each time, and a chat line tells it once. It is not handed to
-- the game's error window: opened from our failing code, that window counted as the addon's, and when the player closed
-- it the game's own code ran as ours and met a secret value (0.26.5, the gamepad bar: Blizzard_ScriptErrorsFrame.xml 81,
-- HideParentPanel). One handler for all callbacks: nothing is made anew at a call. calling: the owner whose callback runs now.
local calling
local said = {}
local function fault(err)
    if ns.Log then
        ns.Log.Error(calling, err)
    end
    local text = tostring(calling) .. ": " .. tostring(err)
    if not said[text] then
        said[text] = true
        ns.Print("an error in " .. text .. " It is saved for the Health Check.")
    end
end

-- (a callback can run another one: the owner before it is put back when it ends)
local function ended(before, ...)
    calling = before
    return ...
end

function ns.Call(owner, fn, ...)
    local before = calling
    calling = owner
    return ended(before, xpcall(fn, fault, ...))
end

-- The game raises at an event name it does not have, which would stop the rest of the file
-- that asked. Such an event is logged one time and never heard.
function ns.On(event, owner, fn)
    assert(type(event) == "string" and type(owner) == "string" and type(fn) == "function", "ns.On(event, owner, fn)")
    if unknown[event] then
        return
    end
    if not eventOwners[event] then
        if not pcall(frame.RegisterEvent, frame, event) then
            unknown[event] = true
            if ns.Log then
                ns.Log.Add("events", owner .. " asked for the event " .. event .. ", which this game build does not have")
            end
            return
        end
        eventOwners[event] = {}
    end
    eventOwners[event][owner] = fn
end

function ns.Off(event, owner)
    local owners = eventOwners[event]
    if not owners then
        return
    end
    owners[owner] = nil
    if not next(owners) then
        eventOwners[event] = nil
        if not KEPT[event] then
            frame:UnregisterEvent(event)
        end
    end
end

-- An event of one unit only: the game then does not send it for any other unit, so a buff
-- change of a stranger near the player costs nothing. Every owner of one event names the same unit.
function ns.OnUnit(event, unit, owner, fn)
    assert(type(event) == "string" and type(unit) == "string" and type(owner) == "string" and type(fn) == "function", "ns.OnUnit(event, unit, owner, fn)")
    if not unitOwners[event] then
        unitOwners[event], unitOf[event] = {}, unit
        unitFrame:RegisterUnitEvent(event, unit)
    end
    assert(unitOf[event] == unit, event .. " is heard for " .. unitOf[event] .. " already")
    unitOwners[event][owner] = fn
end

local function tell(owners, ...)
    for owner, fn in pairs(owners) do
        ns.Call(owner, fn, ...)
    end
end

frame:SetScript("OnEvent", function(_, event, ...)
    if KEPT[event] then
        ns.fightStarted = event == "PLAYER_REGEN_DISABLED"
    end
    local owners = eventOwners[event]
    if owners then
        tell(owners, ...)
    end
end)
for event in pairs(KEPT) do
    frame:RegisterEvent(event)
end

unitFrame:SetScript("OnEvent", function(_, event, ...)
    tell(unitOwners[event], ...)
end)

function ns.Listen(message, owner, fn)
    messageOwners[message] = messageOwners[message] or {}
    messageOwners[message][owner] = fn
end

function ns.Send(message, ...)
    local owners = messageOwners[message]
    if owners then
        tell(owners, ...)
    end
end

-- A module says what it needs from the game (names of checks in the adapter).
-- If a check fails at login, only that module stays off. label is the feature's name as the
-- player knows it (the name of its row, or its plain name): the chat line and the Health Check
-- report use it. The parts of one feature have one label.
function ns.Module(name, needs, label)
    assert(not ns.modules[name], "module defined twice: " .. name)
    assert(type(label) == "string" and label ~= "", "a module needs the feature's name for the player: " .. name)
    local module = { name = name, needs = needs or {}, label = label, on = false }
    ns.modules[name] = module
    ns.moduleOrder = ns.moduleOrder or {}
    ns.moduleOrder[#ns.moduleOrder + 1] = module
    return module
end

-- (the Theme loads after this file: a line printed before it is there still gets the gold)
function ns.Print(text)
    print((ns.Theme and ns.Theme.Hex("gold") or "|cfff4cc62") .. "Gamepad Suite:|r " .. text)
end

ns.On("ADDON_LOADED", "Core", function(loaded)
    if loaded ~= ADDON then
        return
    end
    ns.Off("ADDON_LOADED", "Core")
    ns.Registry.Load()
    ns.Adapter.LoadGrips()
end)

ns.On("PLAYER_LOGIN", "Core", function()
    local results = ns.Adapter.RunChecks()
    local told = {}   -- the features the chat has named: one line for a feature, however many parts it has
    for _, module in ipairs(ns.moduleOrder or {}) do
        local missing
        for _, need in ipairs(module.needs) do
            if not results[need] then
                missing = need
                break
            end
        end
        if missing then
            module.missing = missing
            ns.Log.Add("module", module.name .. " (" .. module.label .. ") is off: the game does not have '" .. missing .. "'")
            if not told[module.label] then
                told[module.label] = true
                ns.Print(module.label .. " is off on this game build. See Setup, Health Check.")
            end
        else
            module.on = true
            if module.OnLogin then
                ns.Call(module.name, module.OnLogin)
            end
        end
    end
end)
