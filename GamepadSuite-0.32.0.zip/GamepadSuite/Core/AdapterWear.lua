-- The adapter's part for Wear Quest Rewards (Screen/WearReward.lua): the links of a quest's rewards at its hand-in, a
-- reward in the bags, and the call that puts a piece on.
-- The hand-in: the game's own quest window and the Dialogue View both hand a quest in with GetQuestReward(choice)
-- (Blizzard_UIPanels_Game/Mainline/QuestFrame.lua 168, Blizzard_StaticPopup_Game/GameDialogDefs.lua 524,
-- Core/AdapterDialogue.lua 275). It is watched with hooksecurefunc: the game's call runs first, unchanged, and the watch
-- reads the links while the reward window's data is still there. QUEST_TURNED_IN (QuestLogDocumentation.lua 1396) says
-- that the hand-in went through.
-- The equip: C_Item.EquipItemByName(link, slot) (ItemDocumentation.lua 251 to 260). Its notes mark no HasRestrictions,
-- only SecretArguments AllowedWhenUntainted (our link and slot are plain values), so it needs no real key press: a
-- let-go read from the controller may make it. ControllerForever makes the same call on this game
-- (ControllerForever_Fishing.lua 216 to 225). The game itself puts the old piece in the bags, and asks with its own box
-- for a piece that binds when worn (EQUIP_BIND, Blizzard_Game/Mainline/EventImplementation.lua 296).
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("wear", function()
    return C_Item.EquipItemByName and GetQuestItemLink and GetNumQuestRewards and GetQuestReward and hooksecurefunc
        and C_Container.GetContainerNumSlots and C_Container.GetContainerItemInfo and GetInventoryItemID
        and C_EventUtils.IsEventValid("QUEST_TURNED_IN") and C_EventUtils.IsEventValid("BAG_UPDATE_DELAYED") == true
end)

-- Tells fn(links) at each hand-in: the link of the chosen item first, then the items given for sure.
function Adapter.OnQuestReward(fn)
    hooksecurefunc("GetQuestReward", function(choice)
        local links = {}
        pcall(function()
            if (tonumber(choice) or 0) > 0 then
                links[1] = GetQuestItemLink("choice", choice)
            end
            for index = 1, GetNumQuestRewards() or 0 do
                links[#links + 1] = GetQuestItemLink("reward", index)
            end
        end)
        fn(links)
    end)
end

-- The first stack in the bags of the item that a link names: { link, id, icon, name, quality }, or nil.
function Adapter.BagItem(link)
    local ok, item = pcall(function()
        local id = C_Item.GetItemInfoInstant(link)
        for bag = 0, 4 do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if id and info and info.itemID == id then
                    return { link = info.hyperlink, id = id, icon = info.iconFileID, name = info.itemName, quality = info.quality }
                end
            end
        end
    end)
    return ok and item or nil
end

-- Puts the piece a link names on, in a place (the game's number of it). True when the call ran; else false and the
-- game's words.
function Adapter.Wear(link, place)
    local ok, err = pcall(C_Item.EquipItemByName, link, place)
    return ok, not ok and tostring(err) or nil
end

-- The id of the item worn in a place, or nil.
function Adapter.WornID(place)
    local ok, id = pcall(GetInventoryItemID, "player", place)
    return ok and id or nil
end
