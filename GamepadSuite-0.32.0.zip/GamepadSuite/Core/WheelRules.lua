-- The rules of a wheel, with no game calls: which wheels there are, where each entry sits, and which entry the stick
-- points at. A wheel is a ring of pictures. The player opens it with a bind, pushes the right stick toward an entry and
-- lets the stick go: the entry is used. Core/Wheels.lua fills the wheels from the game, Core/BindSecure.lua uses an
-- entry in the game's restricted code, Screen/Wheel.lua draws the ring.
--
-- An entry is { name, icon } (or text, words in place of a picture: Core/ChatWheelRules.lua) and what it does:
--   macro = a chat command ("/use item:118"), or action = what a secure button needs ({ type = "spell", spell = 774 }).
-- An entry with neither does nothing (a quick chat line at rest). A bind the game cannot run is no entry.
-- An entry with a fixed place has x, y (its direction) and of (how many places its ring has):
-- the party wheel (five places; the entry also has unit, who the spell goes to) and a wheel of
-- the player's own (eight places). An entry with off is one the stick does not point at (a raid's radial not chosen).
local _, ns = ...

local Wheel = {}

-- The wheels every character has, in the order of the bind list; `only` names the one class that has the wheel. The
-- player's own wheels come after. fills: what a wheel that fills itself takes (the chat line when it is empty).
Wheel.LIST = {
    { id = "consumables", name = "Consumables Wheel", fills = "the food, drink, potions and other consumables in your bags", icon = "Interface\\Icons\\INV_Misc_Food_60" },
    { id = "quest", name = "Quest Item Wheel", fills = "the quest items in your bags that you can use", icon = "Interface\\Icons\\INV_Misc_Book_08" },
    { id = "markers", name = "Raid Marker Wheel", icon = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_1" },
    { id = "portals", name = "Portal Wheel", fills = "the teleport and portal spells you know", icon = "Interface\\Icons\\Spell_Arcane_PortalStormwind", only = "MAGE" },
    { id = "chat", name = "Quick Chat Wheel", icon = "Interface\\Icons\\Ability_Warrior_RallyingCry" },
    { id = "roll", name = "Roll Wheel", icon = "Interface\\Icons\\INV_Misc_Dice_02" },
}
-- A wheel has at most this many entries: with more, a push cannot tell two neighbours apart.
-- A wheel of the player's own has this many places, each with its own direction.
Wheel.MOST = 8
-- The player can make this many wheels: one page of the settings shows them.
Wheel.MOST_OWN = 5

-- The eight raid markers, in the game's own order (1 is the star, 8 is the skull).
Wheel.MARKERS = { "Star", "Circle", "Diamond", "Triangle", "Moon", "Square", "Cross", "Skull" }
-- A mage's teleports, then the portals: the spell numbers of both factions. A wheel shows the
-- ones the character knows.
Wheel.PORTALS = { 3561, 3562, 3565, 3567, 3563, 3566, 10059, 11416, 11419, 11417, 11418, 11420 }
-- The party wheel of healer mode: each member has a fixed place, the player at the top, so a
-- member is in the same direction whoever else is in the party.
Wheel.PARTY = { "player", "party1", "party2", "party3", "party4" }
-- The ring as the settings page draws it: the pictures are 44 across and stand 64 from the
-- middle. With more than six entries the ring grows so that neighbours do not touch.
Wheel.PICTURE, Wheel.RING = 44, 64
-- The wheel in the game is this many times as large at Wheel Size 100%: a picture is then as
-- large as an icon of the game's own radial menu (57 of the game's units), made for a controller.
Wheel.GAME = 1.5

-- The wheels a class has, as entries for the bind list. off: { id = true } for a wheel this game build cannot fill.
function Wheel.Binds(class, off)
    local out = {}
    for _, wheel in ipairs(Wheel.LIST) do
        if (not wheel.only or wheel.only == class) and not (off and off[wheel.id]) then
            out[#out + 1] = { kind = "wheel", id = wheel.id, name = wheel.name, icon = wheel.icon, detail = "" }
        end
    end
    return out
end

-- The name of one of the player's own wheels. Its number is kept for good, so the name does not
-- change when another wheel goes.
function Wheel.Name(id)
    return "Wheel " .. (tostring(id):match("^my(%d+)$") or "?")
end

-- Where entry i of n points, as a step of length 1: x is right, y is up. The first entry is at
-- the top and the others follow clockwise.
function Wheel.Direction(i, n)
    local angle = (i - 1) / n * 2 * math.pi
    return math.sin(angle), math.cos(angle)
end

-- Where entry i of a wheel points: its own fixed place if it has one.
function Wheel.Place(entries, i)
    if entries[i].x then
        return entries[i].x, entries[i].y
    end
    return Wheel.Direction(i, #entries)
end

-- The entry that a stick at x, y points at: the one whose direction is nearest, of those with no off. nil when
-- the stick is nearer to its middle than `least`, the wheel is empty, or the nearest is a blank place of a raid's radial.
-- (The pick that a let-go uses is made the same way in the game's restricted code, Core/BindWheelUse.lua.)
function Wheel.PickOf(entries, x, y, least)
    if #entries < 1 or x * x + y * y < (least or 0) ^ 2 or (x == 0 and y == 0) then
        return nil
    end
    local best, most
    for i = 1, #entries do
        local dx, dy = Wheel.Place(entries, i)
        local dot = not entries[i].off and x * dx + y * dy
        if dot and (not most or dot > most) then
            best, most = i, dot
        end
    end
    return not (best and entries[best].blank) and best or nil
end

-- How far the pictures stand from the middle for n places, at a size in percent.
function Wheel.Radius(n, percent)
    -- neighbours are 2 * radius * sin(pi / n) apart; they need a picture's width and a little air
    local need = n > 1 and (Wheel.PICTURE + 8) / (2 * math.sin(math.pi / n)) or 0
    return math.max(Wheel.RING, need) * percent / 100
end

-- The measures of a wheel in the game, for n places at the setting Wheel Size: how wide a
-- picture is, how far the pictures stand from the middle, and how wide the whole wheel is (the
-- ring, one round picture and a rim).
function Wheel.Measure(n, percent)
    percent = percent * Wheel.GAME
    local picture, radius = Wheel.PICTURE * percent / 100, Wheel.Radius(n, percent)
    return picture, radius, 2 * radius + picture + 12 * percent / 100
end

-- The consumables wheel and the Quest Item Wheel, from things in the bags ({ id, name, icon,
-- kind, level, text }: Core/ConsumableRules.lua says which things those are). kind is a number
-- that sorts them: potions first, weapon items last; quest items are all of one kind. In the ring
-- they stand by kind, in a kind the one for the highest level first, then by name, so an entry
-- keeps its place while the bags stay the same. A wheel has Wheel.MOST places. With more things
-- than places every kind gets one place first, then each kind a second one, and so on.
-- An entry uses the item: text is its chat command when it needs more than the plain one.
function Wheel.Consumables(items)
    local list, rank, ranks, out = {}, {}, {}, {}
    for i, item in ipairs(items) do
        list[i] = item
    end
    table.sort(list, function(a, b)
        if a.kind ~= b.kind then
            return a.kind < b.kind
        elseif (a.level or 0) ~= (b.level or 0) then
            return (a.level or 0) > (b.level or 0)
        end
        return a.name < b.name
    end)
    -- the place of each thing in its own kind, and the last such place that still gets on the wheel
    for i, item in ipairs(list) do
        rank[i] = i > 1 and list[i - 1].kind == item.kind and rank[i - 1] + 1 or 1
        ranks[i] = rank[i]
    end
    table.sort(ranks)
    local cut, spare = ranks[Wheel.MOST] or math.huge, 0
    for i = 1, Wheel.MOST do
        spare = spare + (ranks[i] == cut and 1 or 0)
    end
    for i, item in ipairs(list) do
        if rank[i] < cut or (rank[i] == cut and spare > 0) then
            spare = spare - (rank[i] == cut and 1 or 0)
            out[#out + 1] = { name = item.name, icon = item.icon, item = item.id, macro = item.text or ("/use item:" .. item.id), calm = item.calm }
        end
    end
    return out
end

-- The raid marker wheel: one entry for each marker (mark: its number). A marker that is on the
-- target already is taken off by the game's own command.
function Wheel.Markers()
    local out = {}
    for i, name in ipairs(Wheel.MARKERS) do
        out[i] = { name = name, icon = "Interface\\TargetingFrame\\UI-RaidTargetingIcon_" .. i, macro = "/tm " .. i, mark = i }
    end
    return out
end

-- The portal wheel, from the spells the character knows ({ id, name, icon, cast }); cast is the
-- spell's name as a chat command needs it.
function Wheel.Portals(known)
    local out = {}
    for i = 1, math.min(#known, Wheel.MOST) do
        out[i] = { name = known[i].name, icon = known[i].icon, macro = "/cast " .. known[i].cast, spell = known[i].id }
    end
    return out
end

-- A wheel of the player's own has eight places (Wheel.MOST), and each place keeps its direction:
-- the first at the top, the others clockwise, an eighth of a turn apart. The player puts a bind
-- on the place they want: slots is { [place] = bind }. Only the places that hold a bind are the
-- wheel's entries, in the order of the places, each at the direction of its place. The stick
-- points at the nearest entry, so a wheel with few entries has wide slices.
-- action(bind) says what a bind needs to run (BindRules.Action); icon(bind) gives its picture
-- as it is now. `of` tells the ring how many places it is made for. A bind the game cannot run
-- now (an equipment set with Equipment Sets off) is no entry: no dead slice takes the nearest push,
-- and as each place keeps its direction nothing else moves. My Wheels shows it dim.
function Wheel.FromSlots(slots, action, icon)
    local out = {}
    for place = 1, Wheel.MOST do
        local bind = slots[place]
        local act = bind and action(bind)
        if act and act.type then
            local x, y = Wheel.Direction(place, Wheel.MOST)
            out[#out + 1] = { name = bind.name, icon = icon(bind), x = x, y = y, of = Wheel.MOST, action = act, bind = bind }
        end
    end
    return out
end

-- How many places of a wheel hold a bind, and the first of those binds (its picture is the
-- wheel's picture in the lists).
function Wheel.Count(slots)
    local count, first = 0, nil
    for place = 1, Wheel.MOST do
        if slots[place] then
            count = count + 1
            first = first or slots[place]
        end
    end
    return count, first
end

-- A wheel that an earlier build kept as a plain list of binds, as places: the binds are spread
-- evenly over the eight places, the first at the top, as that build showed them.
function Wheel.Spread(binds)
    local slots, count = {}, math.min(#binds, Wheel.MOST)
    for i = 1, count do
        slots[math.floor((i - 1) * Wheel.MOST / count + 0.5) + 1] = binds[i]
    end
    return slots
end

-- A name the player typed for a wheel, made safe to show: no "|" (the game reads it as the
-- start of a color or a picture), no line break, no space at its ends. nil when nothing is
-- left: the wheel then has its own name ("Wheel 3"). The text box holds NAME_MOST letters.
Wheel.NAME_MOST = 16
function Wheel.CleanName(text)
    local clean = tostring(text or ""):gsub("[|%c]", "")
    clean = clean:gsub("^%s+", "")
    clean = clean:gsub("%s+$", "")
    return clean ~= "" and clean or nil
end

-- Game commands that have a chat command of the same effect. The game runs these chat commands
-- as its own code (they are in its list of secure commands, or call nothing it protects), so a
-- wheel can take a target, start an attack or get off a mount in a fight.
local COMMAND_TEXT = {
    TARGETNEARESTENEMY = "/targetenemy", TARGETPREVIOUSENEMY = "/targetenemy 1",
    TARGETNEARESTFRIEND = "/targetfriend", TARGETPREVIOUSFRIEND = "/targetfriend 1",
    TARGETSELF = "/target player", TARGETPET = "/target pet", TARGETFOCUS = "/target focus",
    TARGETMOUSEOVER = "/target mouseover", TARGETLASTTARGET = "/targetlasttarget",
    ASSISTTARGET = "/assist", FOCUSTARGET = "/focus",
    STARTATTACK = "/startattack", STOPATTACK = "/stopattack", STOPCASTING = "/stopcasting", PETATTACK = "/petattack",
    DISMOUNT = "/dismount", FOLLOWTARGET = "/follow", RELOADUI = "/reload",
}
for i = 1, 4 do
    COMMAND_TEXT["TARGETPARTYMEMBER" .. i] = "/target party" .. i
    COMMAND_TEXT["TARGETPARTYPET" .. i] = "/target partypet" .. i
end

-- The chat command that does what a game command does, or nil when there is none. A wheel entry
-- runs from the game's restricted code, which cannot press a key bind; it can run one chat command
-- as the game's own code, in a fight too. A raid marker is "/tm". Some commands have a chat
-- command of their own (COMMAND_TEXT). A game window is a click on the game's own button for it:
-- buttons is { game command = the name of that button }. A command with none of these needs a
-- real key press (jump, autorun, the game menu) and is not for a wheel.
function Wheel.CommandText(command, buttons)
    local marker = command:match("^RAIDTARGET(%d)$")
    if COMMAND_TEXT[command] then
        return COMMAND_TEXT[command]
    elseif marker then
        return "/tm " .. marker
    elseif command == "RAIDTARGETNONE" then
        return "/tm 0"
    elseif buttons[command] then
        return "/click " .. buttons[command]
    end
    return nil
end

-- What is left of a list's entries for My Wheels, and true when an entry was left out. A wheel
-- does not open a wheel. A game command stays only when a wheel can run it: runs(command).
-- A list where nothing is left out stays as it is, with its More entry. A list that lost entries
-- is short: what is left of it, also from under More, is one plain list.
local function offered(entries, runs)
    local flat, cut = {}, false
    local function take(from)
        for _, entry in ipairs(from) do
            if entry.kind == "more" then
                for _, list in ipairs(entry.lists) do
                    take(list.entries)
                end
            elseif entry.kind == "wheel" or entry.kind == "fixed" or (entry.kind == "command" and not runs(entry.id)) then
                cut = true
            else
                flat[#flat + 1] = entry
            end
        end
    end
    take(entries)
    return cut and flat or entries, cut
end

-- The lists My Wheels offers, from the lists of the bind list ({ { name = , entries = } }). A list
-- with nothing left has no entries; the list screen does not show it.
function Wheel.Offer(lists, runs)
    local out = {}
    for i, list in ipairs(lists) do
        out[i] = { name = list.name, entries = (offered(list.entries, runs)) }
    end
    return out
end

-- The party wheel of a friendly spell or item has a name of its own: "heal774" for the spell 774, "healitem1251" for
-- the item 1251, and in a raid one for each pair of groups: "heal774:2" is groups 3 and 4 (Core/Wheels.lua). This gives
-- the kind ("spell" or "item") and the number that a party wheel is for, and its pair, or nil for any other wheel.
function Wheel.HealOf(name)
    local kind, id, group = tostring(name):match("^heal(%a*)(%d+):?(%d*)$")
    if kind == "" or kind == "item" then
        return kind == "" and "spell" or "item", tonumber(id), tonumber(group)
    end
end

-- The chat command text that opens a party wheel: a click on the wheels' own button, which the
-- game runs as its own code. For a spell that can also be cast on an enemy, cast is its name as
-- a chat command needs it: an enemy that is the target and alive gets the spell as with healer
-- mode off, and with any other target the party wheel opens.
function Wheel.HealText(button, wheel, cast)
    local click = button .. " " .. wheel .. " 1"
    return cast and ("/cast [harm,nodead] " .. cast .. "\n/click [noharm][dead] " .. click) or ("/click " .. click)
end

-- Healer mode asks the game about each spell or item one time and keeps what it finds.
-- friendly(id, kind, slot) is the game's answer (slot: its bar slot, or nil): can it go to a friend, can it also be
-- cast on an enemy, and the game's own answers as text. castName(id) is a spell's name as a chat
-- command needs it. what is a spell's number, or "item:<number>". The finder has:
--   wheels: what -> the name of its party wheel, for one that goes to a friend only
--   foes: what -> the bind that takes its place, for one that can also be cast on an enemy
--         (HealText); the bind's id is the name of its party wheel
--   names: the name of every party wheel found
--   Ask(kind, id): the name of its party wheel, or nil when healer mode leaves it alone
--   Text(): a line for the log: what was found and what was left alone, with the game's answers
function Wheel.Finder(friendly, castName, button)
    local found, asked, acts, left = { wheels = {}, foes = {}, names = {} }, {}, {}, {}
    function found.Ask(kind, id, slot)
        local what = kind == "item" and "item:" .. id or id
        if asked[what] == nil then
            local yes, foe, answers = friendly(id, kind, slot)
            local cast = foe and (kind == "item" and what or castName(id))
            -- for friend and enemy, with no name to cast it by: left alone, so that an enemy can still get it
            local name = yes and (cast or not foe) and ("heal" .. (kind == "item" and "item" or "") .. id) or false
            local list = name and acts or left
            list[#list + 1] = (name or kind .. " " .. id) .. (answers and " (" .. answers .. ")" or "")
            if name and foe then
                found.foes[what] = { kind = "slash", id = name, detail = Wheel.HealText(button, name, cast) }
            elseif name then
                found.wheels[what] = name
            end
            found.names[#found.names + 1] = name or nil
            asked[what] = name
        end
        return asked[what] or nil
    end
    function found.Text()
        table.sort(acts)
        table.sort(left)
        return "party wheels " .. (acts[1] and table.concat(acts, ", ") or "none") .. "; left alone " .. (left[1] and table.concat(left, ", ") or "none")
    end
    return found
end

-- The party wheel for one friendly spell or item: an entry for each unit, at its place (in a raid group: its place in the list). With cast (a name to cast it by,
-- "item:<number>") it stops a cast or a wand first, not for a dead member (the game refuses a heal on one), then casts on the unit; with none it only casts.
function Wheel.Party(units, kind, id, icon, cast)
    local place, out = {}, {}
    for i, unit in ipairs(Wheel.PARTY) do
        place[unit] = i
    end
    for i, unit in ipairs(units) do
        if place[unit] or i <= #Wheel.PARTY then
            local x, y = Wheel.Direction(place[unit] or i, #Wheel.PARTY)
            out[#out + 1] = { unit = unit, x = x, y = y, of = #Wheel.PARTY, icon = icon, action = cast and { type = "macro", macrotext = "/stopcasting [@" .. unit .. ",nodead]\n/"
                .. (kind == "item" and "use" or "cast") .. " [@" .. unit .. "] " .. cast } or { type = kind, [kind] = kind == "item" and "item:" .. id or id } }
        end
    end
    return out
end

-- What the game's restricted code needs for one wheel: for each entry its direction, and the
-- one attribute a secure button needs to run it (type, key, value), with the unit if it has
-- one. An entry the game cannot run, or a quick chat line at rest, has a direction only.
function Wheel.Secure(entries)
    local out = {}
    for i, entry in ipairs(entries) do
        local x, y = Wheel.Place(entries, i)
        local one = { x = x, y = y, unit = entry.unit }
        if entry.macro and not entry.rest then
            one.type, one.key, one.value = "macro", "macrotext", entry.macro
        elseif entry.action then
            one.type = entry.action.type
            for _, key in ipairs({ "spell", "item", "macro", "macrotext", "action" }) do
                if entry.action[key] then
                    one.key, one.value = key, entry.action[key]
                end
            end
        end
        out[i] = one
    end
    return out
end

if ns then
    ns.WheelRules = Wheel
end
return Wheel
