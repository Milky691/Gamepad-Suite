-- The bind core's looks at the game's own stick targeting, out of its restricted code: Stick targeting for a bumper
-- with a bind of ours (the row Targeting at Stick), and the game's own targeting when it is left on with a bumper up.
-- The held buttons themselves are in Core/BindHolds.lua; this file was its second half (0.32.0, for its size).
local _, ns = ...

local Holds = ns.BindHolds
local aiming             -- the bumper whose stick targeting we started: "LB", "RB" or nil
local mouseTold = false  -- the log has had a bumper held while mouse mode is on
local lines = { stuck = 0, aim = 0 }

-- Stick targeting for a bumper with a bind of ours: while it alone is held through its button, the game's targeting
-- is on (RB an enemy, LB a friend), as on a bumper with no bind: the targets light up at the press, the right stick
-- picks one, the let-go ends it. The owner frame tells each change of "lbdown", "rbdown" and "both", in a fight too.
-- In mouse mode the right stick moves the pointer, so a held bumper starts nothing (one job for one stick, as Stick Zoom
-- refuses: Screen/ZoomModel.lua Refusal), and mouse mode coming on ends it (the message "pointer"); the bumper's bind
-- still runs on the press.
-- A let-go that a window took is seen when the pad says the bumper is up (Core/BindSecure.lua APPLY). With LB + RB
-- held (the layer, Stick Zoom), or a window that has the controller (in a fight too), it is off, as the game ends its
-- own when one of its windows takes the controller (FrameControlsManager.lua 89 to 93). A new plan (the row, a bind)
-- lets go of both bumpers (Core/BindCore.lua). Only a change of the bumpers starts it: a window, or the game's
-- controller interface switched off, can only end it (a window that closes again does not start it for a bumper whose
-- let-go it took). The first changes go in the log: one try in the game tells that it comes on, in a fight too, and
-- that the stick picked a target. name: what changed, the owner frame's attribute or "pad".
function Holds.Aim(name)
    local header = Holds.header
    local lb, rb = header:GetAttribute("lbdown"), header:GetAttribute("rbdown")
    local fight = ns.Adapter.InCombat()
    local held = header:GetAttribute("aim") and not header:GetAttribute("both") and ns.Pad.Gameplay()
        and ((lb and not rb and "LB") or (rb and not lb and "RB")) or nil
    local mouse = held and ns.Pointer and ns.Pointer.IsOn()
    local want = not mouse and held or nil
    if mouse and not mouseTold and name ~= "pad" then
        mouseTold = true
        ns.Log.Add("binds", "Stick targeting: " .. held .. " held, mouse mode is on: not started")
    end
    if want == aiming or (want and name == "pad") then
        return
    end
    local said = {}
    if aiming then
        said[1] = aiming .. " let go, the stick picked a target: " .. tostring(ns.Adapter.AimEnd())
    end
    if want then
        said[#said + 1] = want .. " held, the game's targeting for " .. (want == "LB" and "a friend " or "an enemy ")
            .. (ns.Adapter.Aim(want == "LB") and "came on" or "was refused")
    end
    aiming = want
    if lines.aim < 12 then
        lines.aim = lines.aim + 1
        ns.Log.Add("binds", "Stick targeting: " .. table.concat(said, "; ") .. " (in combat: " .. tostring(fight) .. ")")
    end
end

-- The game's own targeting on LB and RB (Blizzard_Gamepad/Utility/Bindings/HoldBindings.lua 132 to 200) stays on
-- until the key that started it goes up. A key that gets another bind while it is down (a window, a change of set)
-- sends its let-go to that bind, and the game's targeting stays on: the right stick picks targets, and LB and RB act
-- as the game's two held buttons. Out of a fight, when the game says a bumper is held while the pad says it is up,
-- that bumper gets the game's own command for its next press ("free:<key>"), whose let-go ends it. Then it has its
-- bind again. With LB held the keys are worked out again too: RB that was held before LB kept the game's targeting
-- until its let-go, and is the chord button now.
function Holds.Unstick()
    local header = Holds.header
    if not header or ns.Adapter.InCombat() then
        return
    end
    local stuck, changed = ns.Adapter.StuckTargeting(), false
    for _, ours in ipairs({ "LB", "RB" }) do
        local key = ns.Adapter.KEY[ours]
        if key and stuck[ours] ~= header:GetAttribute("free:" .. key) then
            header:SetAttribute("free:" .. key, stuck[ours])
            changed = true
            if stuck[ours] and lines.stuck < 6 then
                lines.stuck = lines.stuck + 1
                ns.Log.Add("binds", "the game's stick targeting stayed on with " .. ours .. " up: its next press is the game's own, and ends it")
            end
        end
    end
    if changed or header:GetAttribute("lbdown") then
        SecureHandlerExecute(header, ns.BindSecure.REFRESH)
    end
end

-- (mouse mode came on or went off: a stick targeting that we started ends; a change can only end it)
ns.Listen("pointer", "BindAim", function()
    if Holds.header then
        Holds.Aim("pad")
    end
end)
