-- The adapter's part for Auto Sell Junk and Auto Repair (Auto/Vendor.lua) and Fast Loot
-- (Auto/FastLoot.lua): the vendor's calls and the loot window's.
--
-- Sell: the game's vendor window sells every gray item with one call, C_MerchantFrame.
-- SellAllJunkItems, behind its Sell All Junk button, which shows while C_MerchantFrame.
-- IsSellAllJunkEnabled is true (Blizzard_UIPanels_Game/Mainline/MerchantFrame.lua 210, 482 and
-- 1124 to 1126). The game's notes put no restriction on the call (Blizzard_APIDocumentation
-- Generated/MerchantFrameDocumentation.lua 86). The button's question is the game's window only.
--
-- Repair: the game's two repair buttons call RepairAllItems, with true for the guild's money, and
-- read the cost with GetRepairAllCost and the guild's money with GetGuildBankWithdrawMoney (-1:
-- no limit) and GetGuildBankMoney (Mainline/MerchantFrame.xml 253 to 270 and 345 to 385,
-- MerchantFrame.lua 988 to 990). ForeverPlus repairs with these calls on this game.
--
-- Loot: the game's loot window takes one slot with LootSlot, knows an empty slot by
-- GetLootSlotType, and reads with GetLootSlotInfo, whose sixth value is true for a slot locked to
-- the player (Mainline/LootFrame.lua 84, 93 to 100 and 227 to 228). ForeverPlus loots every
-- slot with LootSlot on this game.
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("sellJunk", function()
    return C_MerchantFrame.SellAllJunkItems and C_MerchantFrame.GetNumJunkItems and C_MerchantFrame.IsSellAllJunkEnabled
        and C_Container.GetContainerNumSlots and C_Container.GetContainerItemInfo and C_Item.GetItemInfo
        and C_EventUtils.IsEventValid("MERCHANT_SHOW") and C_EventUtils.IsEventValid("MERCHANT_CLOSED")
        and C_EventUtils.IsEventValid("BAG_UPDATE_DELAYED") == true
end)
Adapter.Check("repair", function()
    return CanMerchantRepair and GetRepairAllCost and RepairAllItems and GetMoney
        and C_EventUtils.IsEventValid("MERCHANT_SHOW") and C_EventUtils.IsEventValid("MERCHANT_CLOSED")
        and C_EventUtils.IsEventValid("PLAYER_MONEY") == true
end)
Adapter.Check("fastLoot", function()
    return GetNumLootItems and GetLootSlotType and GetLootSlotInfo and LootSlot and Enum.LootSlotType.None
        and C_EventUtils.IsEventValid("LOOT_READY") and C_EventUtils.IsEventValid("LOOT_CLOSED") == true
end)
local results = Adapter.Results

local POOR = 0   -- the game's quality of a gray item (Enum.ItemQuality.Poor)

-- The gray items in the bags that a vendor buys: how many (each item of a stack counts), what a
-- vendor pays for them in copper, and whether the game knew the price of every one.
function Adapter.Grays()
    local grays = { count = 0, copper = 0, known = true }
    pcall(function()
        for bag = 0, results().sellJunk and 4 or -1 do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info and info.quality == POOR and not info.hasNoValue then
                    local count, price = info.stackCount or 1, select(11, C_Item.GetItemInfo(info.itemID))
                    grays.count = grays.count + count
                    grays.copper = grays.copper + (price or 0) * count
                    grays.known = grays.known and price ~= nil
                end
            end
        end
    end)
    return grays
end

-- Sells every gray item at the open vendor with the game's call. Gives whether the game has the
-- sale on, and its count of junk items before the call; the call is made only for a count over 0.
function Adapter.SellJunk()
    if not results().sellJunk then
        return false, 0
    end
    local ok, on, count = pcall(function()
        local on, count = C_MerchantFrame.IsSellAllJunkEnabled(), C_MerchantFrame.GetNumJunkItems()
        if on and count > 0 then
            C_MerchantFrame.SellAllJunkItems()
        end
        return on, count
    end)
    return ok and on and true or false, ok and tonumber(count) or 0
end

-- The game's count of junk items in the bags.
function Adapter.JunkLeft()
    local ok, count = pcall(C_MerchantFrame.GetNumJunkItems)
    return ok and tonumber(count) or 0
end

-- What a repair of all gear costs at the open vendor, the player's gold, and the guild's money
-- the player may spend on it (0 when the guild gives none, or the game has no guild bank).
-- Nothing when the vendor cannot repair or nothing needs it.
function Adapter.RepairCost()
    local ok, cost, gold, guild = pcall(function()
        if not (results().repair and CanMerchantRepair()) then
            return nil
        end
        local cost, can = GetRepairAllCost()
        if not can or not cost or cost <= 0 then
            return nil
        end
        local guild = 0
        if CanGuildBankRepair and GetGuildBankWithdrawMoney and GetGuildBankMoney and CanGuildBankRepair() then
            local allowed, bank = GetGuildBankWithdrawMoney(), GetGuildBankMoney()
            guild = allowed == -1 and bank or math.min(allowed, bank)
        end
        return cost, GetMoney(), guild
    end)
    if ok and cost then
        return cost, gold, guild
    end
end

-- Repairs all gear, with the guild's money when guild is true. True when the call ran.
function Adapter.RepairAll(guild)
    if not results().repair then
        return false
    end
    if guild then
        return (pcall(RepairAllItems, true))
    end
    return (pcall(RepairAllItems))
end

-- Takes every slot of the open loot window that holds something free for the player, from the
-- last one up; with coins true only the coin slots (Enum.LootSlotType.Money,
-- LootConstantsDocumentation.lua 34 to 44). Gives how many slots it took, how many were locked
-- to the player (a roll, or another player's loot), and how many free ones it left.
function Adapter.LootAll(coins)
    local took, locked, left = 0, 0, 0
    local ok, slots = pcall(GetNumLootItems)
    for slot = (ok and results().fastLoot and tonumber(slots) or 0), 1, -1 do
        pcall(function()
            local kind = GetLootSlotType(slot)
            if kind == Enum.LootSlotType.None then
                return
            end
            if select(6, GetLootSlotInfo(slot)) then
                locked = locked + 1
            elseif coins and kind ~= Enum.LootSlotType.Money then
                left = left + 1
            else
                LootSlot(slot)
                took = took + 1
            end
        end)
    end
    return took, locked, left
end
