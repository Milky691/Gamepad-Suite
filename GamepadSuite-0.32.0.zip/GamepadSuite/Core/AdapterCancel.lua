-- The adapter, the part for the bind Cancel (Auto/Cancel.lua).
local _, ns = ...

local Adapter = ns.Adapter

-- Stop the cast, take the targeting circle away, drop the target: each is a call of the game that
-- an addon may not make. The game has a chat command for each in its list of secure commands
-- (Blizzard_ChatFrameBase/Shared/SlashCommands.lua 390 to 400 and 541 to 545), and one of its
-- secure buttons runs chat commands as the game's own code (Blizzard_FrameXML/SecureTemplates.lua
-- 450 to 464). So the button holds the three commands, and the press works in a fight.
-- Each word is asked from the game's own word list. That list is not in the game's interface
-- files, so where the game gives no word the standard English one is used.
local WORDS = { { "STOPCASTING", "/stopcasting" }, { "STOPSPELLTARGET", "/stopspelltarget" }, { "CLEARTARGET", "/cleartarget" } }

-- Makes the button. A press of it does the three things, in that order. The second value is the
-- text the button runs, and the third is how many of its words came from the game: for the log.
function Adapter.CancelButton(name)
    local lines, fromGame = {}, 0
    for i, word in ipairs(WORDS) do
        local own = Adapter.SlashCommand(word[1])
        lines[i] = type(own) == "string" and own or word[2]
        fromGame = fromGame + (lines[i] == own and 1 or 0)
    end
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    -- the press acts when the key goes down, whatever the game's setting for casts on key down says
    button:RegisterForClicks("AnyDown")
    button:SetAttribute("useOnKeyDown", true)
    button:SetAttribute("type", "macro")
    button:SetAttribute("macrotext", table.concat(lines, "\n"))
    return button, table.concat(lines, " "), fromGame
end

-- What a press left behind, for the log: "nothing", or the things that are still there. The game
-- can hide such a fact in a fight; then the answer says so.
function Adapter.CancelLeft()
    local ok, text = pcall(function()
        local left = {}
        left[#left + 1] = (UnitCastingInfo("player") or UnitChannelInfo("player")) and "a cast" or nil
        left[#left + 1] = SpellIsTargeting() and "a targeting circle" or nil
        left[#left + 1] = UnitExists("target") and "a target" or nil
        return #left > 0 and table.concat(left, ", ") or "nothing"
    end)
    return ok and text or "the game did not tell"
end
