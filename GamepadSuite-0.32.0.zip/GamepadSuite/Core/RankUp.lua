-- Spell binds move up to a new rank (decision 24; the rules are in Core/RankUpModel.lua).
-- When the character learns a new rank of a spell, every bind of ours, every fixed slot and every
-- entry of the player's own wheels that holds the rank right below it moves up to the new rank.
-- A lower rank was chosen on purpose and stays. Each change goes through its store's own call, so
-- the buttons, the bind core and this character's build in use hear it. The other builds of this
-- character move by the same rule, in their own tables (Core/Builds.lua). Profiles kept as copies
-- do not change, and the game's own bars are the player's. Out of a fight only. The same walk
-- gives a bind the spell that the Slam rule casts in its place (RankUp.Follow).
local _, ns = ...

local RankUp = ns.Module("RankUp", { "spellBook" }, "Follow New Ranks")
ns.RankUp = RankUp

local Model = ns.RankUpModel
local KEY = "binds.follow_ranks"
local learned, wave = {}, 0   -- the spells the game said were learned since the last run; the last learn's number

-- The spells the character knows now, with the game's text for the rank: a list, and by id.
-- (the spellbook's own text stands in while the game has not loaded the spell's, as on the Binds page)
local function known()
    local list, byId = {}, {}
    for _, tab in ipairs(ns.Adapter.Spells()) do
        for _, entry in ipairs(tab.entries) do
            local rank = ns.Adapter.SpellRank(entry.id)
            local spell = { id = entry.id, name = entry.name, rank = rank ~= "" and rank or entry.detail or "", icon = entry.icon }
            list[#list + 1], byId[entry.id] = spell, spell
        end
    end
    return list, byId
end

-- "Frostbolt (Rank 4)", or the name alone for a spell with no rank.
local function named(spell)
    return Model.Number(spell.rank) and (spell.name .. " (" .. spell.rank .. ")") or spell.name
end

-- "from to to" for each move, in order, for the log.
local function listed(moves)
    local went = {}
    for from, to in pairs(moves) do
        went[#went + 1] = from .. " to " .. to
    end
    table.sort(went)
    return went
end

local function counted(count)
    return "binds " .. count.binds .. ", fixed slots " .. count.slots .. ", wheel entries " .. count.wheels
        .. (count.builds > 0 and (", binds of other builds " .. count.builds) or "")
end

-- What the game said was learned and what moved, as one line for the log.
local function report(just, byId, moves, count)
    local learnt = {}
    for id in pairs(just) do
        local spell = byId[id]
        learnt[#learnt + 1] = spell and (spell.name .. " " .. (spell.rank ~= "" and spell.rank or "with no rank") .. " (" .. id .. ")") or (id .. " (not in the spellbook)")
    end
    table.sort(learnt)
    local went = listed(moves)
    return "learned " .. table.concat(learnt, ", ") .. "; " .. (#went == 0 and "nothing moved"
        or ("moved " .. table.concat(went, ", ") .. ": " .. counted(count)))
end

-- Gives every stored spell bind that to(its id) gives a new number the spell of that number in the
-- spellbook: the binds of every set and layer, the binds Undo keeps, the fixed slots, the player's
-- own wheels, the binds of other builds. The rest of a bind (who it is cast on) stays. word(bind,
-- spell) names a change for chat (nil: no words). Gives the words, once each; the moves; the counts.
local function walk(to, byId, word)
    local function moved(bind)
        local spell = bind and bind.kind == "spell" and byId[to(bind.id)]
        if not spell then
            return nil
        end
        local out = {}
        for field, value in pairs(bind) do
            out[field] = value
        end
        out.id, out.name, out.detail, out.icon = spell.id, spell.name, spell.rank, spell.icon or bind.icon
        return out, spell
    end
    local names, seen, went, count = {}, {}, {}, { binds = 0, slots = 0, wheels = 0, builds = 0 }
    -- (before the change: the words name what the bind was)
    local function note(bind, spell, part)
        count[part] = count[part] + 1
        went[bind.id] = spell.id
        local text = word(bind, spell)
        if text and not seen[text] then
            seen[text], names[#names + 1] = true, text
        end
    end
    -- the binds of every set and layer
    -- Limit: each Binds.Set rebuilds the binds once; a visit moves a handful. A batch call in Core/Binds.lua if one ever stutters.
    local cells = {}
    ns.Binds.Each(function(bind, set, layer, key)
        local new, spell = moved(bind)
        if new then
            cells[#cells + 1] = { set, layer, key, new }
            note(bind, spell, "binds")
        end
    end)
    for _, cell in ipairs(cells) do
        ns.Binds.Set(cell[1], cell[2], cell[3], cell[4])
    end
    -- what Undo Last Bind would give back (after the binds on the buttons: a swap keeps one table in both)
    ns.Binds.EachKept(function(bind)
        local new = moved(bind)
        if new then
            bind.id, bind.name, bind.detail, bind.icon = new.id, new.name, new.detail, new.icon
        end
    end)
    for n = 1, ns.SlotRules.MOST do
        local bind = ns.Slots.Get(n)
        local new, spell = moved(bind)
        if new then
            note(bind, spell, "slots")
            ns.Slots.Set(n, new)
        end
    end
    for _, wheel in ipairs(ns.Wheels.Mine()) do
        for place = 1, ns.WheelRules.MOST do
            local bind = wheel.slots[place]
            local new, spell = moved(bind)
            if new then
                note(bind, spell, "wheels")
                ns.Wheels.SetEntry(wheel.id, place, new)
            end
        end
    end
    -- the builds that are not in use: nothing of theirs is live, so their tables change in place
    for _, bind in ipairs(ns.Builds and ns.Builds.on and ns.Builds.Stored() or {}) do
        local new, spell = moved(bind)
        if new then
            note(bind, spell, "builds")
            bind.id, bind.name, bind.detail, bind.icon = new.id, new.name, new.detail, new.icon
        end
    end
    return names, went, count
end

function RankUp.Run()
    local just = learned
    learned = {}
    local spells, byId = known()
    local moves = Model.Moves(spells, just)
    local names, _, count = walk(function(id)
        return moves[id]
    end, byId, function(_, spell)
        return named(spell)
    end)
    ns.Log.Add("ranks", report(just, byId, moves, count))
    if #names > 0 then
        ns.Print("Moved up to the new rank: " .. table.concat(names, ", ") .. ".")
    end
end

-- The Slam rule (Core/AdapterSpells.lua SpellNow): a bind whose number the character no longer
-- knows casts the spell of its name. Its stored number, name, rank and picture follow, so the Binds
-- page names what is cast. Not tied to Follow New Ranks: the bind casts the new spell already, and
-- this only makes the words true. Words that do not change (a spell with no rank) are not said.
function RankUp.Follow()
    local _, byId = known()
    local names, went, count = walk(function(id)
        local now = ns.Adapter.SpellNow(id)
        return now ~= id and now or nil
    end, byId, function(bind, spell)
        local was = named({ name = bind.name or spell.name, rank = bind.detail })
        return was ~= named(spell) and (was .. " is " .. named(spell) .. " now.") or nil
    end)
    local moves = listed(went)
    if #moves > 0 then
        ns.Log.Add("ranks", "the spell number rule moved " .. table.concat(moves, ", ") .. ": " .. counted(count))
    end
    if #names > 0 then
        ns.Print(table.concat(names, " "))
    end
end

function RankUp.OnLogin()
    -- (this build's name for it; LEARNED_SPELL_IN_TAB is gone: Blizzard_Deprecated/11_0_0_SpellBookAPITransitionGuide.lua 150)
    ns.On("LEARNED_SPELL_IN_SKILL_LINE", "RankUp", function(id)
        if ns.Registry.Has(KEY) and not ns.Registry.Get(KEY) then
            return
        end
        learned[id] = true
        -- A trainer's Learn All buys one rank after another: one run a second after the last
        -- learn, so a visit is one run and one chat line. Each timer runs once; only the last acts.
        wave = wave + 1
        local mine = wave
        C_Timer.After(1, function()
            if mine == wave then
                ns.Queue.Run("RankUp", RankUp.Run)
            end
        end)
    end)
    -- The spellbook changed (a login, a talent, a patch): a burst is one look, out of combat.
    local due
    ns.On("SPELLS_CHANGED", "RankUp", function()
        if not due then
            due = true
            C_Timer.After(0, function()
                due = false
                ns.Queue.Run("RankUp numbers", RankUp.Follow)
            end)
        end
    end)
end
