-- The adapter's part for the binds Mount and Random Mount (Auto/Mount.lua): the mounts of the
-- character, the forms that move faster, the button of the bind Mount, the call that summons a
-- mount, and the call that gets off.
-- On this game a mount is an entry of the mount journal, learned from an item: this build's item
-- table says "Teaches you how to summon this mount." on such items (Brown Horse Bridle, Black
-- Stallion Bridle). The game has a key command for the journal's tab (Blizzard_FrameXML/
-- Bindings_Camelot.xml 1273), and the journal marks favorites (C_MountJournal.GetMountInfoByID,
-- its seventh value; Blizzard_Collections/Mainline/Blizzard_MountCollection.lua 224 to 231). The
-- Mount button of that window calls C_MountJournal.SummonByID (the same file, 818 to 834). The
-- game's notes put no restriction on that call, and its chat command /dismount (with conditions)
-- calls Dismount() (Blizzard_ChatFrameBase/Shared/SlashCommands.lua 1285 to 1289).
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("mounts", function()
    return C_MountJournal.GetMountIDs and C_MountJournal.GetMountInfoByID and C_MountJournal.SummonByID
        and IsMounted and Dismount ~= nil
end)

-- The spells of the forms: Aquatic Form and Travel Form of a druid, Ghost Wolf of a shaman. This
-- build's spell table has them at the levels 16, 30 and 20.
local AQUATIC, TRAVEL, WOLF = 1066, 783, 2645

-- The mounts the character has, in the journal's order: { { id =, name =, spell =, usable =,
-- active =, favorite = } }. spell is the name of the mount's spell, which a chat command casts.
-- usable is the game's word for "can be ridden where the character stands"; active is true for
-- the one that is out. The second value is how many mounts the journal lists in all, for the log.
function Adapter.Mounts()
    local out, all = {}, 0
    pcall(function()
        for _, id in ipairs(C_MountJournal.GetMountIDs()) do
            all = all + 1
            local name, spell, _, active, usable, _, favorite, _, _, hidden, collected = C_MountJournal.GetMountInfoByID(id)
            if collected and not hidden then
                out[#out + 1] = { id = id, name = name or ("mount " .. id), spell = spell and C_Spell.GetSpellName(spell) or nil,
                    usable = usable and true or false, active = active and true or false, favorite = favorite and true or false }
            end
        end
    end)
    return out, all
end

-- The forms that the character knows, by the name a chat command casts them with: { aquatic =,
-- travel =, wolf = }, each nil when it does not know it.
function Adapter.MountForms()
    local function known(id)
        local spell = Adapter.KnownSpells({ id })[1]
        return spell and spell.name
    end
    return { aquatic = known(AQUATIC), travel = known(TRAVEL), wolf = known(WOLF) }
end

-- Makes the button of the bind Mount. It runs its macro text as the key goes down, whatever the
-- game's setting for casts on key down says. Out of a fight only: the game locks it in one.
function Adapter.MountButton(name)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    button:RegisterForClicks("AnyDown")
    button:SetAttribute("useOnKeyDown", true)
    button:SetAttribute("type", "macro")
    return button
end

-- Why the mount of this journal number cannot be summoned where the character stands, in the
-- game's own words: nil when it can, "" when the game says no and gives no reason. The game's own
-- journal asks the same, with checkIndoors true, for the red line of its tooltip
-- (Blizzard_Collections/Classic/Blizzard_MountCollection.lua 533 to 537). nil too on a game with
-- no such call.
function Adapter.MountWhy(id)
    local ok, usable, why = pcall(C_MountJournal.GetMountUsabilityByID, id, true)
    if ok and usable == false then
        return why or ""
    end
end

function Adapter.Indoors()
    local ok, inside = pcall(IsIndoors)
    return ok and inside and true or false
end

function Adapter.Swimming()
    local ok, wet = pcall(IsSwimming, "player")
    return ok and wet and true or false
end

function Adapter.Mounted()
    local ok, on = pcall(IsMounted)
    return ok and on and true or false
end

-- Gets off the mount.
function Adapter.Dismount()
    pcall(Dismount)
end

-- Summons a mount of the journal. True when the call ran; when it did not, the second value is
-- what the game said. A call that ran can still be refused by the game in its own red words
-- (indoors, in water): the addon does not hear of that.
function Adapter.Summon(id)
    local ok, err = pcall(C_MountJournal.SummonByID, id)
    return ok, not ok and tostring(err) or nil
end
