-- The one reload of the addon: the end of the guided setup (Settings/Window.lua) and the row
-- Reload of Health Check (Health/Page.lua). The interface reloads, so the game writes the saved
-- file to disk at once. C_UI.Reload is the call behind the game's own ReloadUI
-- (Blizzard_SharedXML/InterfaceUtil.lua 1 and 2). Its notes
-- (Blizzard_APIDocumentationGenerated/UIManagerDocumentation.lua 65) do not mark it as protected
-- or restricted, but notes from other Forever addons say the game refuses it to an addon
-- (build_plan/sources/more_forever_repos.md 52 and 153). So it is made only inside a press of the
-- player's (A or a click in the settings window), never in a fight, and both rows say to type
-- /reload when nothing happens.
local _, ns = ...

local Adapter = ns.Adapter

-- One line in the log, at the first try of a session. A reload that works starts a new session
-- right after it in the log; a refusal adds the game's block line (Core/Log.lua) or the fault here.
local told = false
function Adapter.Reload()
    if Adapter.InCombat() or not (C_UI and C_UI.Reload) then
        return
    end
    local ok, fault = pcall(C_UI.Reload)
    if not told then
        told = true
        ns.Log.Add("reload", "a reload was asked at a press: " .. (ok and "no fault" or tostring(fault)))
    end
end
