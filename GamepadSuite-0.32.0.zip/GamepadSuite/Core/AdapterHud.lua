-- The adapter, part 4: what the on-screen buttons ask the game about one button: its picture, its
-- cooldown, can it be used, is the target in reach, is it running. A button shows a bind of ours
-- (a spell, an item, a macro) or one of the game's own action slots: { kind = "slot", id = number }.
-- The game can refuse or hide an answer in a fight, so every question is asked in a guarded call
-- and an unknown answer gives the normal look.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- The game's own gamepad bar is four bars of eight buttons: no trigger, LT, RT and LT + RT.
local BAR = { [2] = "leftBar", [3] = "rightBar", [4] = "bottomBar" }

-- The number (1 to 8) of the game's own bar button that a pad button presses. nil for a pad
-- button that is not one of the eight (LB, a stick click).
function Adapter.NativeIndex(ourKey)
    local ok, command = pcall(GetBindingAction, Adapter.KEY[ourKey], false, Adapter.GameplayContext())
    return ok and type(command) == "string" and tonumber(command:match("^GAMEPADACTIONBUTTON(%d+)$")) or nil
end

-- The game's own bar button for a pad button on a layer (1 no trigger, 2 LT, 3 RT, 4 LT + RT).
-- With no trigger it is the bar in use now, which can be a vehicle's. live: the bar that takes a
-- trigger bar's place right now is used in its place (the stance bar in a form, by the game's
-- setting for it).
local function nativeButton(ourKey, layer, live)
    local index = results().nativeBar and Adapter.NativeIndex(ourKey)
    local unit = index and GamepadMainActionBarFrame.PageUnit
    if not unit then
        return nil
    end
    local bar = layer == 1 and unit:GetActiveBar() or unit.actionBars[BAR[layer]]
    if live and layer > 1 then
        for _, other in ipairs(unit.overrideBars) do
            if other:IsBarActivelyOverridingActionBar(bar) then
                bar = other
                break
            end
        end
    end
    return bar:GetActionButtonByIndex(index)
end

-- That button's name, so that a key can be bound to a click on it. nil when the game has none.
function Adapter.NativeButtonName(ourKey, layer)
    local ok, name = pcall(function()
        return nativeButton(ourKey, layer):GetName()
    end)
    return ok and type(name) == "string" and name ~= "" and name or nil
end

-- The name of the button that takes that button's place while the player is in a form or a
-- stance: the game can put its stance bar in the place of one trigger bar (its setting says
-- which, and on which page). nil when the stance bar does not stand for that layer's bar.
function Adapter.NativeFormButtonName(ourKey, layer)
    local ok, name = pcall(function()
        local unit = GamepadMainActionBarFrame.PageUnit
        local stance = unit.actionBars.stanceBar
        if stance:GetActionBarLinkedWithOverrideBar() ~= unit.actionBars[BAR[layer]]
            or stance:GetLinkedOverrideBarPage(stance:GetOverrideCVarValue()) ~= unit:GetCurrentPage() then
            return nil
        end
        return stance:GetActionButtonByIndex(Adapter.NativeIndex(ourKey)):GetName()
    end)
    return ok and type(name) == "string" and name ~= "" and name or nil
end

-- Tells fn each time the game's own bar changes its page or the bar in use. It sends no game
-- event for that. We watch its own calls and write nothing into it. The bar in use changes at
-- every press and release of a trigger; with pageOnly, fn hears a change of page and no more.
function Adapter.OnNativeBarChanged(fn, pageOnly)
    local unit = results().nativeBar and GamepadMainActionBarFrame.PageUnit
    if not unit or not hooksecurefunc then
        return
    end
    for _, name in ipairs(pageOnly and { "SetCurrentPage" } or { "SetCurrentPage", "SetActiveActionBar" }) do
        if type(unit[name]) == "function" then
            hooksecurefunc(unit, name, function()
                fn()
            end)
        end
    end
end

-- What that button holds now, as something the on-screen buttons can show. nil for an empty slot.
function Adapter.NativeSlot(ourKey, layer)
    local ok, slot = pcall(function()
        local slot = nativeButton(ourKey, layer, true).action
        return results().actionSlots and C_ActionBar.HasAction(slot) and slot
    end)
    return ok and slot and { kind = "slot", id = slot } or nil
end

-- The spell of a bind. Each question below asks it of what the bind uses now: a macro stands
-- for the spell or the item that it would use at this moment (Core/AdapterMacro.lua).
local function spellOf(bind)
    -- (the spell the bind means now: a number the game no longer knows gives the one of that name it knows, Core/AdapterSpells.lua)
    return bind.kind == "spell" and type(bind.id) == "number" and Adapter.SpellNow(bind.id) or nil
end

-- The picture of a bind as it is now: a macro's picture follows the macro (with the question
-- mark, what it would use now), a spell's follows its rank.
function Adapter.BindIcon(bind)
    if bind.kind == "slot" then
        local ok, texture = pcall(C_ActionBar.GetActionTexture, bind.id)
        return ok and texture or nil
    elseif bind.kind == "spell" and type(bind.id) == "number" then
        return C_Spell.GetSpellTexture(bind.id) or bind.icon
    elseif bind.kind == "item" then
        local ok, icon = pcall(C_Item.GetItemIconByID, bind.id)
        return ok and icon or bind.icon
    elseif bind.kind == "macro" then
        return Adapter.MacroIcon(bind) or bind.icon
    elseif ns.BindRules.LIVE[bind.kind] then
        -- the fishing pole or the fixed slot's action of the moment; with none, the picture the bind list gave
        local item = ns.BindRules.Real(bind)
        return item ~= bind and Adapter.BindIcon(item) or bind.icon
    elseif bind.kind == "wheel" and ns.Wheels then
        -- a wheel of the player's own shows the picture of its first entry as it is now
        return ns.Wheels.Icon(bind.id) or bind.icon
    elseif ns.MarkNext and bind.id == ns.MarkNext.COMMAND then
        -- the mark that the next press gives
        return ns.MarkNext.Icon()
    end
    -- a game command, a slash command or an emote: the picture of this build, not the saved one
    return ns.Catalog.Icon(bind) or bind.icon
end

-- How many of an item the player has. nil when the bind is no item or the game gives no plain number.
function Adapter.ItemCount(bind)
    if bind.kind ~= "item" or not C_Item.GetItemCount then
        return nil
    end
    local ok, count = pcall(function()
        local n = C_Item.GetItemCount(bind.id)
        return n + 0
    end)
    return ok and count or nil
end

-- Puts the count of a bind on a text: how many of an item (one shows nothing, none shows 0),
-- the game's own count of a slot, the charges or reagents of a spell. The game can hide a count
-- from addon code in a fight; such a value goes straight to the text and is not looked at here.
function Adapter.ShowCount(text, bind)
    bind = Adapter.Now(bind)
    local ok = pcall(function()
        if not bind then
            text:SetText("")
        elseif bind.kind == "slot" then
            text:SetText(C_ActionBar.GetActionDisplayCount(bind.id))
        elseif bind.kind == "item" then
            local count = Adapter.ItemCount(bind)
            text:SetText(count and count ~= 1 and count or "")
        else
            local spell = C_Spell.GetSpellDisplayCount and spellOf(bind)
            if spell then
                text:SetText(C_Spell.GetSpellDisplayCount(spell))
            else
                text:SetText("")
            end
        end
    end)
    if not ok then
        text:SetText("")
    end
end

-- Can the bind be used now: true, false, or "power" when only mana, rage or energy is short.
function Adapter.Usable(bind)
    -- a wheel that holds nothing does not open (Core/BindSecure.lua): its button is gray until it holds an entry
    -- (Core/WheelsNow.lua Count: cheap, no healer-mode walk of the binds; the "wheels" send redraws the buttons)
    if bind.kind == "wheel" then
        return not (ns.Wheels and ns.Wheels.Count) or ns.Wheels.Count(bind.id) > 0
    end
    if bind.kind == "macro" and GetMacroInfo then
        -- a macro that was renamed or deleted: the bind can do nothing
        local found, name = pcall(GetMacroInfo, bind.id)
        if found and name == nil then
            return false
        end
    end
    bind = Adapter.Now(bind)
    local ok, usable, noPower
    if bind.kind == "slot" then
        ok, usable, noPower = pcall(C_ActionBar.IsUsableAction, bind.id)
    elseif bind.kind == "item" then
        if Adapter.ItemCount(bind) == 0 then
            return false
        end
        ok, usable, noPower = pcall(C_Item.IsUsableItem, bind.id)
    else
        local spell = results().spellState and spellOf(bind)
        if spell then
            ok, usable, noPower = pcall(C_Spell.IsSpellUsable, spell)
        end
    end
    if not ok then
        return true
    end
    return usable and true or (noPower and "power" or false)
end

-- True for a value the game hides from an addon in a fight. A compare with one is an error.
local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- True only when the game says clearly that the target is too far. No target, or an action with
-- no reach, is not "too far". The game answers for an item's reach, in a fight too, only once
-- the item's data is loaded (charles-hood/wow-forever-addons, build 70338: its notes file 75-81): each
-- item a button shows is loaded at its first look, one time. A hidden answer is not "too far".
local loaded = {}
function Adapter.OutOfRange(bind)
    bind = Adapter.Now(bind)
    if bind.kind == "item" and not loaded[bind.id] then
        loaded[bind.id] = true
        pcall(C_Item.RequestLoadItemDataByID, bind.id)
    end
    local ok, out = pcall(function()
        if not UnitExists("target") then
            return false
        end
        local inRange
        if bind.kind == "slot" then
            inRange = C_ActionBar.IsActionInRange(bind.id)
        elseif bind.kind == "item" then
            inRange = C_Item.IsItemInRange(bind.id, "target")
        elseif spellOf(bind) then
            inRange = C_Spell.IsSpellInRange(spellOf(bind), "target")
        end
        return not hidden(inRange) and (inRange == false or inRange == 0)
    end)
    return ok and out or false
end

-- True while the bind is the action in progress: a cast, an attack that waits for the next
-- swing (Heroic Strike, Maul), auto attack or auto shot, or the form the player is in.
function Adapter.Running(bind)
    bind = Adapter.Now(bind)
    local ok, on = pcall(function()
        if bind.kind == "slot" then
            return C_ActionBar.IsCurrentAction(bind.id) or C_ActionBar.IsAutoRepeatAction(bind.id)
        elseif bind.kind == "item" then
            return C_Item.IsCurrentItem(bind.id)
        end
        local spell = spellOf(bind)
        if not spell then
            return false
        elseif C_Spell.IsAutoRepeatSpell(spell) or C_Spell.IsCurrentSpell(spell) then
            return true
        end
        local form = GetShapeshiftForm() or 0
        return form > 0 and select(4, GetShapeshiftFormInfo(form)) == spell
    end)
    return ok and on and true or false
end

-- True for an item that is worn (a trinket on a button).
function Adapter.Equipped(bind)
    bind = Adapter.Now(bind)
    local ok, on = pcall(function()
        if bind.kind == "slot" then
            return C_ActionBar.IsEquippedAction(bind.id)
        end
        return bind.kind == "item" and C_Item.IsEquippedItem(bind.id)
    end)
    return ok and on and true or false
end

-- Cooldown of a bind onto a cooldown frame. The game can hide these numbers from addon code in a
-- fight, so the values go straight to the frame and no maths is done on them. Where the game has
-- its own object for a cooldown, that is given to the frame: it works while the numbers are hidden.
local cooldownFault
-- The short cooldown that a cast (1.5 s) or a wand's shot puts on every spell and item is no
-- cooldown of one action: one of this many seconds or fewer does not count. The owner's 0.25.1 log
-- had a wand's shot hold his drink and hearthstone longer than 1.6 s, over in about 2 s.
local SHARED = 3
local short = {}
local function long(duration, bind)
    if duration <= SHARED and duration > 0 and not short[bind.kind] then
        short[bind.kind] = true
        ns.Log.Add("cooldowns", ("a cooldown of %.1f s on %s %s is left out: the short one that a cast or a wand's shot puts on all"):format(duration, bind.kind, tostring(bind.id)))
    end
    return duration > SHARED
end

-- Is the bind's action cooling down now, when does that end, and is the game sure. The short
-- cooldown that every cast starts does not count. In a fight the game can hide the numbers: the end
-- is nil, and only its never-hidden isActive and isOnGCD tell (SpellSharedDocumentation.lua 26, 30);
-- isOnGCD is right only in a cooldown event for spells about this spell. told is that event (spell,
-- base spell, start recovery category) or nil. As the game's cooldown viewer hears it (CooldownViewer.lua
-- 149-156, 360-391), it is about the spell it names, and about all when a cast starts the global
-- cooldown (category 133). A wand that shoots (IsAutoRepeatSpell; an event for Shoot each shot,
-- HostileTargetingActionBar.lua 74-78, 198) starts no cooldown, and its own timer is none.
function Adapter.Cooling(bind, told)
    bind = Adapter.Now(bind)
    local ok, active, ends, sure = pcall(function()
        if bind.kind == "item" then
            local start, duration = C_Container.GetItemCooldown(bind.id)
            if hidden(start) or hidden(duration) then
                return false
            end
            return long(duration, bind) and start + duration > GetTime(), start + duration, true
        end
        local spell = results().spellState and spellOf(bind)
        local info = spell and not C_Spell.IsAutoRepeatSpell(spell) and C_Spell.GetSpellCooldown(spell)
        if not info then
            return false
        elseif hidden(info.startTime) or hidden(info.duration) then
            local about = told and (told.spell == spell or told.base == spell or told.recovery == 133 and not C_Spell.IsAutoRepeatSpell(told.spell))
            return info.isActive == true and not (about and info.isOnGCD == true), nil, about
        end
        return long(info.duration, bind) and info.startTime + info.duration > GetTime(), info.startTime + info.duration, true
    end)
    if not ok and cooldownFault ~= tostring(active) then
        cooldownFault = tostring(active)
        ns.Log.Add("screen", "a cooldown could not be read: " .. cooldownFault)
    end
    return ok and active or false, ok and active and ends or nil, ok and active and sure or false
end

-- Two numbers of a cooldown onto a cooldown frame. The game may not be given a hidden number by
-- addon code (ForeverCDM, README.md 27): then the frame shows no cooldown. An item's cooldown has
-- no object of the game's that works while its numbers are hidden. With noShared, the short
-- cooldown that a cast starts for an item too is no cooldown.
local function put(frame, start, duration, noShared)
    if hidden(start) or hidden(duration) or noShared and duration <= SHARED then
        frame:Clear()
    else
        frame:SetCooldown(start, duration)
    end
end

-- Puts the cooldown of a bind on a cooldown frame; the game draws the clock and the number. With
-- noShared the short cooldown that every cast starts is left out (the cooldown list, the small
-- pictures of the other layers), for a spell and for one of the game's own slots alike.
function Adapter.ShowCooldown(frame, bind, noShared)
    bind = Adapter.Now(bind)
    local ok, err = pcall(function()
        local spell = bind and bind.kind ~= "slot" and results().spellState and spellOf(bind)
        if bind and bind.kind == "slot" then
            if C_ActionBar.GetActionCooldownDuration and frame.SetCooldownFromDurationObject then
                frame:SetCooldownFromDurationObject(C_ActionBar.GetActionCooldownDuration(bind.id, noShared == true))
            else
                local info = C_ActionBar.GetActionCooldown(bind.id)
                put(frame, info.startTime, info.duration)
            end
        elseif bind and bind.kind == "item" and C_Container.GetItemCooldown then
            local start, duration = C_Container.GetItemCooldown(bind.id)
            put(frame, start, duration, noShared)
        elseif spell and C_Spell.GetSpellCooldownDuration and frame.SetCooldownFromDurationObject then
            frame:SetCooldownFromDurationObject(C_Spell.GetSpellCooldownDuration(spell, noShared))
        elseif spell then
            local info = C_Spell.GetSpellCooldown(spell)
            put(frame, info.startTime, info.duration)
        else
            frame:Clear()
        end
    end)
    if not ok then
        frame:Clear()
        if cooldownFault ~= tostring(err) then
            cooldownFault = tostring(err)
            ns.Log.Add("screen", "a cooldown could not be shown: " .. cooldownFault)
        end
    end
end

-- What the mouse pointer carries, as a bind: a spell, an item or a macro. nil for nothing, or
-- for a thing that is no bind.
function Adapter.CursorBind()
    local ok, kind, id, _, spell = pcall(GetCursorInfo)
    if not ok then
        return nil
    elseif kind == "spell" and spell then
        return { kind = "spell", id = spell, name = C_Spell.GetSpellName(spell), icon = C_Spell.GetSpellTexture(spell) }
    elseif kind == "item" and id then
        return Adapter.ItemBind(id)
    elseif kind == "macro" and id then
        local name, icon = GetMacroInfo(id)
        return name and { kind = "macro", id = name, name = name, icon = icon } or nil
    end
end

-- Takes the thing off the pointer.
function Adapter.CursorClear()
    pcall(ClearCursor)
end

-- Tells fn each time the pointer picks a thing up or lets it go.
function Adapter.OnCursorChanged(owner, fn)
    pcall(ns.On, "CURSOR_CHANGED", owner, fn)
end

-- True while an enemy that is alive and can be attacked is the target.
function Adapter.EnemyTargeted()
    local ok, yes = pcall(function()
        return UnitCanAttack("player", "target") and not UnitIsDead("target")
    end)
    return ok and yes and true or false
end
