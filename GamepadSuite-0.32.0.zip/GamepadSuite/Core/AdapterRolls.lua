-- The adapter's part for the loot roll buttons (Screen/Rolls.lua), for Pass on Gear You Cannot
-- Wear (Auto/PassUnusable.lua), and at the end for the game's own auto loot (Auto/FastLoot.lua).
-- In the game's gamepad mode a roll is a card in the list GamepadGroupLootRollFrame, at most four
-- cards. With the mouse and keyboard interface it is one of GroupLootFrame1 to 4. Both kinds are
-- made the same way (Blizzard_UIPanels_Game/Mainline/GroupLootFrame.xml): the frame has rollID,
-- and its buttons are in LootButtonContainer by key. We read the frames and hook after Blizzard's
-- own code. Nothing of Blizzard's is written, and no script of Blizzard's is run from addon code:
-- a roll is the game's own call for it (PressRoll).
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

local FRAMES = { "GroupLootFrame1", "GroupLootFrame2", "GroupLootFrame3", "GroupLootFrame4" }
local faulted

-- A roll button that a press can use now: shown and not turned off by the game.
local function usable(button)
    return button and button:IsShown() and button:IsEnabled() and button or nil
end

-- frame is a roll if it shows an item and has a button to press. While the game plays its "you
-- rolled" animation the buttons are hidden: that roll is answered, and is no roll here.
local function add(list, seen, frame)
    local box = frame.LootButtonContainer
    if not (frame.rollID and box and frame:IsShown()) then
        return
    end
    seen[#seen + 1] = frame:GetName() or "card"
    -- the item as the game's own roll frame reads it (GroupLootFrame.lua 317): its picture, name, the
    -- stack's size and quality, and bop: it binds on pickup, so a Need or a Greed is followed by the
    -- game's question. On a dim Need the game's card keeps its words for why (341 to 345).
    local icon, name, count, quality, bop, canNeed, _, _, why = GetLootRollItemInfo(frame.rollID)
    local reason = not canNeed and _G["LOOT_ROLL_INELIGIBLE_REASON" .. tostring(why)]
    local roll = { id = frame.rollID, frame = frame, icon = icon, name = name, quality = quality, bop = bop and true or false,
        count = type(count) == "number" and count or 1, reason = type(reason) == "string" and reason or nil, why = why,
        need = usable(box.NeedButton),
        -- the game shows Transmog in the place of Greed on an item that has it
        greed = usable(box.GreedButton) or usable(box.TransmogButton), pass = usable(box.PassButton) }
    -- the time left, as the game's own bar reads it (GroupLootFrame.lua 422 to 433): the frame's
    -- rollTime is the roll's length, both in thousandths of a second. The compare stops a number
    -- the game hides in combat here, before it reaches the clock.
    local ok, ends = pcall(function()
        local at = GetTime() + GetLootRollTimeLeft(frame.rollID) / 1000
        return at > 0 and at or nil
    end)
    if ok and type(frame.rollTime) == "number" then
        roll.ends, roll.length = ends, frame.rollTime / 1000
    end
    if roll.need or roll.greed or roll.pass then
        list[#list + 1] = roll
    end
end

-- The rolls on the screen, top first: { id, frame, icon, name, quality, bop, count, reason, why, ends,
-- length, need, greed, pass }. need, greed and pass are the roll's own buttons, nil for a choice the
-- game does not allow for the item. reason is the game's words for a Need it does not allow, why its
-- number. ends (the game's clock) and length are in seconds, nil when the game
-- does not say. The second value is for the log: the names of the roll frames the game shows, or
-- nil when it shows none.
function Adapter.Rolls()
    local list, seen = {}, {}
    if not results().rolls then
        return list, nil
    end
    local ok, err = pcall(function()
        local pad = GamepadGroupLootRollFrame
        if pad and pad:IsShown() then
            seen[1] = "list:"
            pad.ScrollBox:ForEachFrame(function(frame)
                add(list, seen, frame)
            end)
        end
        for _, name in ipairs(FRAMES) do
            local frame = _G[name]
            if frame then
                add(list, seen, frame)
            end
        end
        table.sort(list, function(a, b)
            return (a.frame:GetTop() or 0) > (b.frame:GetTop() or 0)
        end)
    end)
    if not ok and not faulted then
        faulted = true
        ns.Log.Add("rolls", "the game's roll frames could not be read: " .. tostring(err))
    end
    return list, #seen > 0 and table.concat(seen, " ") or nil
end

-- A roll made by addon code: a hold on a roll (Screen/Rolls.lua) and Pass on Gear You Cannot
-- Wear. It is the call the game's own card makes for its keys (GroupLootFrame.lua 1274 to 1302):
-- RollOnLoot with the id of the roll's button, 1 Need, 2 Greed, 4 Transmog, 0 Pass. ForeverPlus
-- and ControllerForever make it from addon code on this game.
-- After a Need or a Greed on an item that binds on pickup, RollOnLoot only makes the game send
-- CONFIRM_LOOT_ROLL, at once (LootDocumentation.lua 118 to 128), and the game's handler opens its
-- "are you sure" box (EventRouting.lua 79, GameDialogDefs.lua 71 to 90). Opened inside an addon's
-- call it is the addon's: its window binds (FrameControlsManager.lua 397 to 470, the overrides of
-- InputBindingStack) would be refused in combat. So for such an item the roll is the call of the
-- box's own OK, ConfirmLootRoll with the roll and the kind (GameDialogDefs.lua 2551 to 2556): it
-- names the kind itself, so the game needs no RollOnLoot first, and no box opens. When the game
-- asks all the same inside a RollOnLoot of ours, the box's call answers for that roll only, as
-- ForeverPlus does on this game (Modules/Looting.lua 238 to 242).
-- Returns true when the call ran with no fault, and true again when the game ended the roll inside
-- it: its event for that is one it sends at once (CANCEL_LOOT_ROLL, LootDocumentation.lua 96 to
-- 104), and the game's roll list then ran its own code as the addon's. The log has it.
local calling, inside, asked
ns.On("CANCEL_LOOT_ROLL", "AdapterRolls", function(id)
    inside = inside or id == calling
end)
ns.On("CONFIRM_LOOT_ROLL", "AdapterRolls", function(id, kind)
    if id == calling then
        asked = pcall(ConfirmLootRoll, id, kind)
    end
end)
local function rollOn(id, kind, sure)
    calling, inside, asked = id, false, nil
    local ok = pcall(sure and ConfirmLootRoll or RollOnLoot, id, kind)
    calling = nil
    return ok, inside
end

-- A roll of Adapter.Rolls gets a choice ("need", "greed", "pass") by addon code. ask: RollOnLoot
-- also for an item that binds on pickup (the game asks, and is answered). Three answers: the two
-- of the call above, and a few words for the log on how the roll was made.
function Adapter.PressRoll(rolled, choice, ask)
    -- the game can give the frame to another roll before our next look at the screen
    if rolled.frame.rollID ~= rolled.id then
        return false, false, "the frame shows another roll"
    end
    local kind = rolled[choice] and rolled[choice]:GetID() or 0
    local sure = rolled.bop and kind ~= 0 and not ask
    local ok, ended = rollOn(rolled.id, kind, sure)
    return ok, ended, (sure and "the call of the game's box" or "the call of the roll's button")
        .. (asked ~= nil and ", the game asked if sure and was answered: " .. tostring(asked) or "")
end

-- Closes the open wheel as B does (Core/BindSecure.lua OPEN), with why for the wheel's log, and
-- gives true when it closed. Out of combat only, as Core/BindCore.lua closes one for a window: the
-- owner frame of the binds is protected, and in combat the game runs its restricted code for a
-- real press only (Blizzard_RestrictedAddOnEnvironment/RestrictedExecution.lua 469).
function Adapter.CloseWheel(why)
    local header = _G.GamepadSuiteBinds
    if InCombatLockdown() or not (header and header:GetAttribute("wheel")) then
        return false
    end
    header:SetAttribute("wwhy", why)
    header:SetAttribute("wheel", nil)
    SecureHandlerExecute(header, ns.BindSecure.REFRESH)
    return true
end

-- The tooltip of a roll's item, and beside it what the character wears in that place. The frames
-- are the addon's own, made from the game's templates: the game takes its one shared tooltip back
-- for the thing under the pointer (see AdapterAuto.lua). The game fills the item's tooltip with
-- its own call for a roll, the one its roll frame uses under the mouse
-- (Blizzard_UIPanels_Game/Mainline/GroupLootFrame.lua 475). The worn items are written here from
-- the game's own answers, the way the game writes them (Blizzard_SharedXMLGame/Tooltip/
-- TooltipComparisonManager.lua 219 to 316): the header "Equipped", the item, and what changes.
-- The game's one call that does all of this is not used: its notes mark it as protected, and it
-- puts the worn items at the side of the tooltip, toward the middle of the screen.
local tips                    -- [1] the roll's item, [2] and [3] what is worn in its place
local SCALE, GAP = 0.85, 24   -- smaller than the game's tooltip; GAP is the room for the header on a worn item

local function tipFrames()
    if not tips then
        tips = { CreateFrame("GameTooltip", "GamepadSuiteRollTip", UIParent, "GameTooltipTemplate"),
            CreateFrame("GameTooltip", "GamepadSuiteRollWorn1", UIParent, "ShoppingTooltipTemplate"),
            CreateFrame("GameTooltip", "GamepadSuiteRollWorn2", UIParent, "ShoppingTooltipTemplate") }
        for _, tip in ipairs(tips) do
            tip:SetScale(SCALE)
        end
    end
    return tips
end

function Adapter.HideRollTooltip()
    for _, tip in ipairs(tips or {}) do
        tip:Hide()
    end
end

-- Shows the tooltip of a roll's item (a roll of Adapter.Rolls) with the worn items, at the right
-- of beside (the card of the roll, low in the middle of the screen): it stands on the card's foot
-- and the worn items are above it. Returns true when the item's tooltip shows, and a few words
-- for the log.
function Adapter.ShowRollTooltip(roll, beside)
    if not results().rollTip then
        return false, "this game has no call for it"
    end
    Adapter.HideRollTooltip()
    local ok, shown = pcall(function()
        local tip = tipFrames()[1]
        tip:SetOwner(UIParent, "ANCHOR_NONE")
        tip:ClearAllPoints()
        tip:SetPoint("BOTTOMLEFT", beside, "BOTTOMRIGHT", GAP / 2, 0)
        return tip:SetLootRollItem(roll.id) and tip:IsShown()
    end)
    if not (ok and shown) then
        return false, ok and "the game gave the tooltip no lines" or tostring(shown)
    end
    -- a fault from here on leaves the item's tooltip as it is, with no worn item beside it
    local fine, count = pcall(function()
        local item = { hyperlink = GetLootRollItemLink(roll.id) }
        local info = item.hyperlink and C_TooltipComparison.GetItemComparisonInfo(item)
        if not info then
            -- nothing is worn in that place, or the item is nothing to wear
            return 0
        end
        local METHOD, worn = Enum.TooltipComparisonMethod, 0
        local single, both = info.method == METHOD.Single, info.method == METHOD.WithBothHands
        -- the second item: the other ring or trinket, or the other hand. When the game pairs the
        -- roll's item with one from the bags, that one is not worn, and is left out.
        local second = (single or both) and info.additionalItems[1] or nil
        for n, other in ipairs({ info.item, second }) do
            local data = other.guid and C_TooltipInfo.GetItemByGUID(other.guid)
                or other.hyperlink and C_TooltipInfo.GetHyperlink(other.hyperlink)
            if not data then
                break
            end
            local tip = tips[n + 1]
            tip:SetOwner(tips[1], "ANCHOR_NONE")
            tip:ClearAllPoints()
            tip:SetPoint("BOTTOMLEFT", tips[n], "TOPLEFT", 0, GAP)
            tip.CompareHeader.Label:SetText(EQUIPPED)
            tip.CompareHeader:SetWidth(tip.CompareHeader.Label:GetWidth() + 30)
            tip.CompareHeader:Show()
            tip:ProcessInfo({ tooltipData = data, append = true })
            -- what changes: for each worn item of its own, or for the two hands together under
            -- the first. Limit: no list of changes when the game pairs the item with one from
            -- the bags (a one-hand weapon against a worn two-hand one); the worn item still shows.
            local lines = (single or both and n == 1)
                and C_TooltipComparison.GetItemComparisonDelta(item, other, both and second or nil, false)
            if lines and #lines > 0 then
                GameTooltip_AddBlankLineToTooltip(tip)
                GameTooltip_AddNormalLine(tip, both and ITEM_DELTA_MULTIPLE_COMPARISON_DESCRIPTION or ITEM_DELTA_DESCRIPTION)
                for _, line in ipairs(lines) do
                    GameTooltip_AddHighlightLine(tip, line)
                end
            end
            tip:Show()
            worn = n
        end
        return worn
    end)
    if not fine then
        tips[2]:Hide()
        tips[3]:Hide()
    end
    return true, fine and count .. " worn beside it" or "no worn item beside it: " .. tostring(count)
end

-- Tells fn each time the rolls on the screen can have changed: the list of the gamepad mode was
-- drawn again or hidden, one of the four frames showed or hid, or a roll began its "you rolled"
-- animation (its buttons hide). Hooks after Blizzard's own code.
function Adapter.OnRollsChanged(fn)
    if not results().rolls then
        return
    end
    local pad = GamepadGroupLootRollFrame
    if pad then
        pad:HookScript("OnHide", fn)
        -- every change of the list goes through this call of the frame: a new roll, a roll that ends
        if type(pad.DoFullRefresh) == "function" then
            hooksecurefunc(pad, "DoFullRefresh", fn)
        end
    end
    for _, name in ipairs(FRAMES) do
        local frame = _G[name]
        if frame then
            frame:HookScript("OnShow", fn)
            frame:HookScript("OnHide", fn)
        end
    end
    if type(GroupLootFrame_StartNeedAnimation) == "function" then
        hooksecurefunc("GroupLootFrame_StartNeedAnimation", fn)
    end
end

-- Pass on Gear You Cannot Wear (Auto/PassUnusable.lua). The game tells of a roll's start with
-- START_LOOT_ROLL (Blizzard_APIDocumentationGenerated/LootDocumentation.lua 406). What it says
-- of the roll's item is what its own roll frame reads (Mainline/GroupLootFrame.lua 317: the
-- sixth answer is canNeed). The pass is the call that the game's own Pass button makes:
-- RollOnLoot with 0 (GroupLootFrame.xml 7, the button with id 0 at 505 and 571, and the pass of
-- a gamepad card at GroupLootFrame.lua 1274). It needs no press: ForeverPlus makes it from this
-- event on this game (Modules/Looting.lua 212 to 231).
Adapter.Check("rollPass", function()
    return GetLootRollItemInfo and GetLootRollItemLink and RollOnLoot and C_Item.GetItemInfoInstant
        and C_PlayerInfo.CanUseItem and C_EventUtils.IsEventValid("START_LOOT_ROLL") == true
end)

-- What the game says of a roll's item, in the fields that Screen/RollsModel.lua names, and its
-- link. nil when the game does not know the roll or its item yet, or a call fails.
function Adapter.RollItem(id)
    local ok, item = pcall(function()
        local _, name, _, _, _, canNeed = GetLootRollItemInfo(id)
        local link = name and GetLootRollItemLink(id)
        if not link then
            return nil
        end
        local itemId, _, _, place, _, class, sub = C_Item.GetItemInfoInstant(link)
        return itemId and { link = link, class = class, sub = sub, worn = place ~= nil and place ~= "",
            canNeed = canNeed and true or false, usable = C_PlayerInfo.CanUseItem(itemId) and true or false }
    end)
    return ok and item or nil
end

-- Passes on a roll. Two answers, as Adapter.PressRoll gives them.
function Adapter.PassRoll(id)
    return rollOn(id, 0)
end

-- The game's own auto loot (Auto/FastLoot.lua). With the controller interface the game's own
-- Interact sets, just before each interact, whether that loot is taken by itself:
-- C_AutoLoot.SetUseAutoLootToggle with the player's setting autoLootDefault for a tap, the other
-- way for a hold, and the setting again after a hold (Blizzard_GamepadActionBars/
-- MainActionBarFrame.lua 166 to 175). The suite's Interact is the game's command
-- INTERACTSOFTTARGET, which only interacts (Blizzard_GamepadTargeting/Bindings.xml 2 to 8): it
-- leaves the state as it was. So the state the game sets for a tap is set here: the setting's own
-- value. The game's notes put no restriction on the call (AutoLootDocumentation.lua 11 to 18).
Adapter.Check("autoLoot", function()
    return C_AutoLoot ~= nil and C_AutoLoot.SetUseAutoLootToggle ~= nil and C_CVar.GetCVarBool ~= nil
end)

-- Sets the game's auto loot for the next interact to the player's setting. Returns the setting
-- (true: on), or nil when this game has no such call.
function Adapter.AutoLootRest()
    if not results().autoLoot then
        return nil
    end
    local ok, on = pcall(C_CVar.GetCVarBool, "autoLootDefault")
    on = ok and on == true
    pcall(C_AutoLoot.SetUseAutoLootToggle, on)
    return on
end

-- Tells fn each time the player changes the setting autoLootDefault.
function Adapter.OnAutoLootSetting(fn)
    ns.On("CVAR_UPDATE", "AutoLoot", function(name)
        if name == "autoLootDefault" then
            fn()
        end
    end)
end
