-- The Roll Wheel (the owner: "a roll wheel bind Looks like a dice. Has /roll 100 /roll 99, /roll 101. This is for gear
-- rolls on master loot"). A wheel every character has, in the list Wheels with the game's dice picture
-- (Core/WheelRules.lua LIST), with a size and place of its own (Wheel to Change). It has three lines of words, as the quick chat
-- lines are: "/roll 100" up, "/roll 99" left and "/roll 101" right, the lower roll to the left and the higher to the
-- right. Each line is one chat command, which the wheels' own secure button runs at the stick's let-go, in a fight too
-- (Core/BindSecure.lua USE). The game runs its own name of the command (SLASH_RANDOM1, as EasyController reads it;
-- "/roll" where the game has none); the line on the ring shows "/roll". The first rolls of a session go to the log.
local _, ns = ...

local Roll = ns.Module("RollWheel", { "secure", "padButtons" }, "Wheels")
ns.RollWheel = Roll

Roll.ID = "roll"
-- the top number of each roll, and its place: up, left, right
Roll.LINES = { { 100, 0, 1 }, { 99, -1, 0 }, { 101, 1, 0 } }
local MAX_NOTES = 4     -- rolls that go to the log in one session

-- The wheel's entries: { name, text (the words on the ring), macro (the chat command), x, y (its place) }. slash is the
-- game's own name of the roll command, or nil.
function Roll.Entries(slash)
    local out = {}
    for i, line in ipairs(Roll.LINES) do
        local words = "/roll " .. line[1]
        out[i] = { name = words, text = words, macro = (slash or "/roll") .. " " .. line[1], x = line[2], y = line[3] }
    end
    return out
end

-- The entries with the game's own name of the command (Core/Wheels.lua asks at login).
function Roll.Now()
    return Roll.Entries(ns.Adapter.SlashCommand and ns.Adapter.SlashCommand("RANDOM"))
end

function Roll.OnLogin()
    -- The wheels' button is made with the binds, after this login step: the first wheel that opens finds it there.
    local hooked, notes = false, 0
    ns.Listen("wheel", "RollWheel", function()
        hooked = hooked or ns.Adapter.OnWheelUsed(function(text)
            for _, entry in ipairs(Roll.Now()) do
                if entry.macro == text and notes < MAX_NOTES then
                    notes = notes + 1
                    ns.Log.Add("wheel", "the Roll Wheel ran \"" .. text .. "\", in a fight: " .. tostring(ns.Adapter.InCombat()))
                end
            end
        end)
    end)
end
