-- The adapter, the part for the game's own stick targeting on LB and RB (Core/BindHolds.lua).
-- The game keeps its own word of "held" for each of the two (Blizzard_Gamepad/Utility/Bindings/
-- HoldBindings.lua 132 to 200): set at the press of its key command, cleared at its let-go. It is
-- only read here, and its calls are heard (hooksecurefunc), never made.
local _, ns = ...

local Adapter = ns.Adapter

-- The bumpers whose game targeting is on while the pad says the bumper is up: { LB = the game's
-- command for it, RB = ... }. With the game's toggle for its held buttons on, "held" is meant to
-- stay, and nothing is given.
-- The bumper of the game's friendly targeting: LB, or RB when the game's option swaps the two
-- (GamepadSwapTargetModifiers: Blizzard_Gamepad/Utility/Bindings/HoldBindings.lua 111 to 117).
function Adapter.FriendlyBumper()
    local ok, swapped = pcall(GetCVarBool, "GamepadSwapTargetModifiers")
    return ok and swapped and "RB" or "LB"
end

function Adapter.StuckTargeting()
    local out = {}
    pcall(function()
        if GetCVarBool("GamepadHudModifierUsesToggle") then
            return
        end
        local _, _, lb, rb = Adapter.Held()
        local both = GamepadMode.IsHUDBindingModifierDown()
        if not lb and (both or GamepadMode.IsTargetingModifierDown(GamepadMode.GetLeftTargetModifierFlag())) then
            out.LB = "GAMEPADLEFTTARGETMODIFIER"
        end
        if not rb and (both or GamepadMode.IsTargetingModifierDown(GamepadMode.GetRightTargetModifierFlag())) then
            out.RB = "GAMEPADRIGHTTARGETMODIFIER"
        end
    end)
    return out
end

-- Tells fn(left, down) each time the game's targeting on a bumper is pressed or let go: left is
-- true for LB. fn runs inside the game's code: it must only take note.
function Adapter.OnTargetingChanged(fn)
    pcall(hooksecurefunc, GamepadMode, "SetTargetModifier", function(flag, down)
        local ok, left = pcall(function()
            return flag == GamepadMode.GetLeftTargetModifierFlag()
        end)
        ns.Call("BindHolds", fn, ok and left, down and true or false)
    end)
end

-- The same targeting for a bumper that has a bind of ours, started and ended by us: the two calls
-- of the game's own start (Blizzard_GamepadTargeting/TargetLogic.lua 132 to 144): the targets
-- light up and the right stick picks one. ControllerForever makes the same calls from addon code
-- on this game (its Target Swinger on LB and RB, through the game's BeginTargeting). The game's
-- notes flag none of the three as protected. The game's own table and its "held" word are not
-- touched, so the game's targeting stays the game's. left: a friend, else an enemy. True when the
-- game took the calls.
function Adapter.Aim(left)
    return (pcall(function()
        local filters = Enum.GamepadTargetingFilters
        C_GamepadTargeting.SetFilter(left and filters.Friendly or filters.Hostile)
        C_GamepadTargeting.Enable()
    end))
end

-- Ends it, as the game's own end does (TargetLogic.lua 147 to 151). True when the stick picked a
-- target meanwhile. A short press picks nothing more: the bumper's bind did its job at the press.
function Adapter.AimEnd()
    local ok, picked = pcall(function()
        return C_GamepadTargeting.Disable()
    end)
    return ok and picked == true
end
