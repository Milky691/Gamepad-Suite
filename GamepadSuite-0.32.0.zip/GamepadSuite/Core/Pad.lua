-- Answers "who has the controller?": gameplay, or a window. The answer comes from Blizzard's own
-- stack of window binds and from our settings window. It changes when Blizzard's stack changes,
-- not on a timer. Every other module asks here, and hears the message "pad" when the answer changes.
-- The master switch: with the game's own controller interface off (its setting "Enable Gamepad
-- UI"), nothing of the controller is ours. The binds, the wheels, the on-screen buttons and mouse
-- mode rest, in a fight too (Core/BindCore.lua "off"); every other part of the suite goes on.
local _, ns = ...

local Pad = ns.Module("Pad", { "padOwner", "padStack" }, "Controller in Game Windows")
ns.Pad = Pad

local gameplay, controller = true, true
local waiting, told = false, false

-- True when a button press goes to the game: the game's controller interface is on, no Blizzard
-- window has the controller and our settings window is closed.
function Pad.Gameplay()
    return gameplay
end

-- True while the game's own controller interface is on.
function Pad.Controller()
    return controller
end

local function read()
    local on = ns.Adapter.ControllerUI()
    local now = on and ns.Adapter.GameplayHasPad() ~= false and not (ns.Settings and ns.Settings.IsOpen())
        and not (ns.Dialogue and ns.Dialogue.IsOpen()) and not (ns.Merchant and ns.Merchant.IsOpen())
    local switched = on ~= controller
    if switched then
        controller = on
        ns.Log.Add("binds", "the game's controller interface is " .. (on and "on: the suite's controller parts are back" or "off: the suite's controller parts rest"))
        ns.Print(on and "Controller on in the game's settings: your binds, wheels and on-screen buttons are back."
            or "Controller off in the game's settings: your binds, wheels and on-screen buttons are off. The rest of Gamepad Suite still works.")
    end
    if now ~= gameplay or switched then
        gameplay = now
        ns.Send("pad", now)
    end
    -- told every time, changed or not: Blizzard has just set or cleared window binds
    ns.Send("pad:stack")
end

-- Blizzard is in the middle of a change of its window binds (or another writer set a key): the
-- stack is read one frame later, when the change is whole, and one time for a burst of calls.
-- Nothing of ours then runs inside the game's own binding code.
local function later()
    if not waiting then
        waiting = true
        C_Timer.After(0, function()
            waiting = false
            read()
        end)
    end
end

-- The game's own controller bar was switched off with the controller interface on: every button
-- with no bind of ours does nothing until a reload. Addon code must not show a Blizzard frame
-- (it would taint the game's controller interface), so the player is asked to reload, once for
-- the character while the bar stays off (Core/BindCheck.lua Tell).
local function barCheck()
    local off = ns.Adapter.NativeBarOff()
    if off and not told then
        told = true
        ns.Log.Add("binds", "the game's controller bar is hidden while the controller interface is on")
    end
    ns.BindCheck.Tell("bar", off and "The game's controller bar is off, so buttons without a bind of yours do nothing. Type /reload to get it back." or nil)
end

function Pad.OnLogin()
    ns.Adapter.OnPadStackChanged(later)
    ns.Listen("settings:opened", "Pad", read)
    ns.Listen("settings:closed", "Pad", read)
    ns.Listen("dialogue:opened", "Pad", read)
    ns.Listen("dialogue:closed", "Pad", read)
    ns.Listen("merchant:opened", "Pad", read)
    ns.Listen("merchant:closed", "Pad", read)
    ns.Adapter.OnControllerUI(read)
    controller = ns.Adapter.ControllerUI()
    read()
    -- (the game hides the bar itself when its controller interface goes off: a second later that is known)
    ns.Adapter.OnNativeBarHidden(function()
        C_Timer.After(1, barCheck)
    end)
    C_Timer.After(2, barCheck)
end
