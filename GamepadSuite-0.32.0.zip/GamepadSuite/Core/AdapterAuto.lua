-- The adapter, part 6: what the small helpers ask the game (Auto/*.lua; Screen/TargetTip.lua asks HasTarget).
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- The NPC's choices, each { id = the choice's own number, place = its place in the list, icon =
-- its picture }, and how many quests the window offers or takes. Empty when the game cannot tell.
function Adapter.GossipChoices()
    local ok, options, quests = pcall(function()
        local out = {}
        for _, option in ipairs(C_GossipInfo.GetOptions() or {}) do
            out[#out + 1] = { id = option.gossipOptionID, place = option.orderIndex, icon = option.overrideIconID or option.icon }
        end
        return out, C_GossipInfo.GetNumActiveQuests() + C_GossipInfo.GetNumAvailableQuests()
    end)
    return ok and options or {}, ok and quests or 1
end

-- Takes a choice: by its own number, the way ForeverPlus does on this game build, else by its
-- place, the way the game's own window does (GossipFrameShared.lua 232). True when the game took the call.
function Adapter.ChooseGossip(choice)
    if choice.id and pcall(C_GossipInfo.SelectOption, choice.id) then
        return true
    end
    return choice.place ~= nil and pcall(C_GossipInfo.SelectOptionByIndex, choice.place) or false
end

-- True inside a dungeon, a raid or a battleground.
function Adapter.InInstance()
    local ok, inside = pcall(IsInInstance)
    return ok and inside and true or false
end

-- The buffs that tell of a campfire, by their spell numbers in the game's own spell list. A
-- player near a campfire of this game has Campfire Nearby (1283391: "The pleasant smoke of a
-- campfire drifts in the air from somewhere nearby."). The campfire of the older spell gives
-- Cozy Fire (7353).
local CAMPFIRE = { 1283391, 7353 }
-- Welcoming Campfire: the game gives it to a player who sits at the fire, some seconds after
-- the character sat down. So it is no sign of a fire for the sit button, and a sure sign of a
-- seated character.
local SEATED = 1229739

-- The name of a buff of the player, by its spell number; false when the player does not have it;
-- nil when the game gives no answer. In combat the game refuses the question, or gives a value
-- that addon code may not test (build_plan/sources/thunderz96_forever_addon_kit.md 43 and 46):
-- every test of the answer is made inside the pcall, so such a value cannot raise outside it.
local function buff(spell)
    local ok, name = pcall(function()
        local aura = C_UnitAuras.GetPlayerAuraBySpellID(spell)
        return aura ~= nil and tostring(aura.name or spell) or false
    end)
    if ok then
        return name
    end
end

-- True while the player has one of the campfire buffs, and the buff's name; then two signs of a
-- seated character (the player has Welcoming Campfire, the player eats or drinks), and true while
-- the player is on a mount (a character on a mount cannot sit). nil when the game gives no answer
-- now: the game hides buffs from addon code in combat, so this is asked out of combat only.
function Adapter.NearCampfire()
    if not results().auras then
        return false
    end
    for _, spell in ipairs(CAMPFIRE) do
        local name = buff(spell)
        if name == nil then
            return nil
        elseif name then
            return true, name, buff(SEATED) and true or false, Adapter.Eating(), Adapter.Mounted()
        end
    end
    return false
end

-- The game has no call and no event that tells if the character sits. What it has: its sit
-- command and its jump command are plain calls of its own, and the game lets an addon hear a
-- call (its secure hook; the call itself is not touched). fn(false) for the sit command, which
-- sits the character down or stands it up; fn(true) for a jump, which stands it up. True when
-- the sit command can be heard. (A fault in fn is logged and does not reach the game's command.)
function Adapter.OnSitKey(fn)
    if not hooksecurefunc or type(SitStandOrDescendStart) ~= "function" then
        return false
    end
    hooksecurefunc("SitStandOrDescendStart", function()
        ns.Call("SitKey", fn, false)
    end)
    if type(JumpOrAscendStart) == "function" then
        hooksecurefunc("JumpOrAscendStart", function()
            ns.Call("SitKey", fn, true)
        end)
    end
    return true
end

-- True while the character moves. A character that moves does not sit.
function Adapter.Moving()
    local ok, moving = pcall(IsPlayerMoving)
    return ok and moving and true or false
end

-- Tells fn when the character starts to move, and fn(true) when it starts a cast with a cast time
-- or a channel: each of them stands a seated character up. Until Adapter.OffMoved(owner). (The
-- casts of everybody near the player come to the handler while it is set; it is set only while
-- the character sits. A meal has no cast time; its buff tells Auto/Campfire.lua that it sits.)
local STANDS = { PLAYER_STARTED_MOVING = false, UNIT_SPELLCAST_START = true, UNIT_SPELLCAST_CHANNEL_START = true }
function Adapter.OnMoved(owner, fn)
    for event, cast in pairs(STANDS) do
        pcall(ns.On, event, owner, function(unit)
            if not cast or unit == "player" then
                fn(cast)
            end
        end)
    end
end

function Adapter.OffMoved(owner)
    for event in pairs(STANDS) do
        ns.Off(event, owner)
    end
end

function Adapter.HasTarget()
    return UnitExists("target") and true or false
end

-- True when a unit's nameplate is the nameplate of the player's target. The two plates are
-- compared, not the two units: in a fight the game can keep a unit compare to itself.
function Adapter.IsTargetPlate(unit)
    local ok, same = pcall(function()
        local plate = C_NamePlate.GetNamePlateForUnit(unit)
        return plate ~= nil and plate == C_NamePlate.GetNamePlateForUnit("target")
    end)
    return ok and same
end

-- Calls fn each time the game's own low health warning (the red edge of the screen) shows.
function Adapter.OnLowHealthWarning(fn)
    pcall(function()
        LowHealthFrame:HookScript("OnShow", function()
            -- the game shows the same red edge when a fight starts behind a full-screen window: that is not low health
            if not (GetUIPanel and GetUIPanel("fullscreen")) then
                fn()
            end
        end)
    end)
end

-- The target's nameplate, or nil when it has none or addon code may not touch it.
function Adapter.TargetPlate()
    local ok, plate = pcall(function()
        local found = results().plates and C_NamePlate.GetNamePlateForUnit("target")
        return found and not found:IsForbidden() and found or nil
    end)
    return ok and plate or nil
end

-- The readings of the info bar. Each is nil when the game cannot give it now.
function Adapter.Money()
    local ok, copper = pcall(function()
        return GetMoney() + 0
    end)
    return ok and copper or nil
end

-- Free bag slots, in the backpack and the bags that take anything (a quiver, an ammo pouch or a soul bag is left out:
-- its family is not 0).
function Adapter.BagSpace()
    local ok, free = pcall(function()
        local count = 0
        for bag = 0, 4 do
            local slots, family = C_Container.GetContainerNumFreeSlots(bag)
            if family == 0 then
                count = count + slots
            end
        end
        return count
    end)
    return ok and free or nil
end

-- Every piece of gear that can wear down: { now, most }.
function Adapter.GearWear()
    local out = {}
    for slot = 1, 18 do
        local ok, now, most = pcall(GetInventoryItemDurability, slot)
        if ok and type(now) == "number" and type(most) == "number" then
            out[#out + 1] = { now, most }
        end
    end
    return out
end

-- The player's place on the map of the zone: x and y from 0 to 1. nil inside a dungeon. The info
-- bar asks once a second. The game's map place is a new object at each call (about 2 KB:
-- build_plan/sources/more_forever_repos.md 56), so it is asked only when the character moved:
-- the place in the world (UnitPosition, no new object: the same notes, 57) is another one.
local was = {}   -- the place in the world and the map place of the last ask
local function place()
    local wy, wx, _, world = UnitPosition("player")
    if wy == nil or wy ~= was[1] or wx ~= was[2] or world ~= was[3] then
        local x, y = C_Map.GetPlayerMapPosition(C_Map.GetBestMapForUnit("player"), "player"):GetXY()
        was = { wy, wx, world, x, y }
    end
    return was[4], was[5]
end
function Adapter.MapPlace()
    local ok, x, y = pcall(place)
    if ok and type(x) == "number" and type(y) == "number" then
        return x, y
    end
end

-- The latency to the game world, in milliseconds.
function Adapter.Latency()
    local ok, _, _, _, world = pcall(GetNetStats)
    return ok and type(world) == "number" and world or nil
end

function Adapter.FrameRate()
    local ok, frames = pcall(GetFramerate)
    return ok and type(frames) == "number" and frames or nil
end
