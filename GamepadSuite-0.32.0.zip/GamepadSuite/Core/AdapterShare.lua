-- The adapter's part for Share Quests (Auto/ShareQuest.lua): the party, if a quest can be shared and who is not on
-- it, who offered a quest, and the share itself. The calls (QuestLogDocumentation.lua): IsPushableQuest 840 to 851,
-- IsUnitOnQuest(unit, questID) 1066 to 1081, GetLogIndexForQuestID 206 to 215, GetTitleForQuestID 668; no restriction
-- marks but SecretArguments, which our plain numbers are not. QuestLogPushQuest(questLogIndex) is a global with no
-- note: the game's own Share button runs it from plain code with a log index (Blizzard_UIPanels_Game/Mainline/
-- QuestMapFrame.lua 1446 to 1448).
local _, ns = ...

local Adapter = ns.Adapter

local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

Adapter.Check("shareQuests", function()
    return C_QuestLog.IsPushableQuest and C_QuestLog.IsUnitOnQuest and C_QuestLog.GetLogIndexForQuestID and C_QuestLog.GetTitleForQuestID
        and QuestLogPushQuest and IsInGroup and C_EventUtils.IsEventValid("QUEST_ACCEPTED") and C_EventUtils.IsEventValid("QUEST_DETAIL") == true
end)

-- True in a party, never in a raid: a share is for the few who stand together.
function Adapter.InParty()
    local ok, party = pcall(function()
        return IsInGroup() and not IsInRaid()
    end)
    return ok and party and true or false
end

-- True when the quest offer that shows now comes from a player: a quest a member shared (the game's quest window names
-- its giver "questnpc", Mainline/QuestFrame.lua 117 to 119). With it the quest's ID (GetQuestID), or nil.
function Adapter.OfferFromPlayer()
    local ok, player, id = pcall(function()
        return UnitIsPlayer("questnpc"), GetQuestID and GetQuestID()
    end)
    if not ok or hidden(player) then
        return false, nil
    end
    return player == true, not hidden(id) and type(id) == "number" and id > 0 and id or nil
end

-- What a share of this quest would do now: { title, pushable, names = { the members not on it } }, or nil.
function Adapter.ShareInfo(id)
    local ok, info = pcall(function()
        local names = {}
        for i = 1, 4 do
            local unit = "party" .. i
            if UnitExists(unit) then
                local on, name = C_QuestLog.IsUnitOnQuest(unit, id), UnitName(unit)
                if not hidden(on) and on == false and not hidden(name) and type(name) == "string" then
                    names[#names + 1] = name
                end
            end
        end
        local pushable, title = C_QuestLog.IsPushableQuest(id), C_QuestLog.GetTitleForQuestID(id)
        return { pushable = not hidden(pushable) and pushable == true, title = not hidden(title) and type(title) == "string" and title or nil, names = names }
    end)
    return ok and info or nil
end

-- Shares the quest with the party (the quest log's index, read now: inside QUEST_ACCEPTED it can still be nil). True
-- when the call was made.
function Adapter.ShareQuest(id)
    local ok, index = pcall(C_QuestLog.GetLogIndexForQuestID, id)
    if not ok or type(index) ~= "number" then
        return false
    end
    return (pcall(QuestLogPushQuest, index))
end
