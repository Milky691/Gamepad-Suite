-- The adapter, the part for Last Link (Screen/ChatLinks.lua): a chat line as plain text, the button of the bind, and
-- the tooltip of a link with the worn gear beside it.
--
-- The tooltip is a frame of the addon's own, made from the game's template (as Target Tooltip's, Core/AdapterTip.lua),
-- and filled by the game with SetHyperlink, a secure call of the template that runs untainted
-- (Blizzard_SharedXMLGame/Tooltip/TooltipDataHandler.lua 488 to 503). The game's own link window, ItemRefTooltip, is
-- never shown, filled or closed from here, and no chat link is clicked: a game window shown or closed by addon code
-- runs its scripts as the addon's (decisions 114, 140). Nothing here is protected, so it works in a fight.
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("chatLinks", function()
    return C_TooltipInfo ~= nil and C_TooltipInfo.GetHyperlink ~= nil
end)

local function secret(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- A name without the realm when it is the player's own realm ("Bob"), with it for another ("Bob-Far").
local function short(name)
    local ok, cut = pcall(Ambiguate, name, "none")
    return ok and type(cut) == "string" and cut or name
end

-- A chat line's text and sender as plain strings, or nil when the game hid the text: in an encounter, a PvP match or
-- a dungeon or raid the chat events give hidden values (SecretInChatMessagingLockdown,
-- Blizzard_APIDocumentationGenerated/SecretPredicatesDocumentation.lua 65). A hidden value is never cut or compared.
-- A hidden or empty name gives nil for the name only.
function Adapter.ChatLine(text, name)
    if secret(text) or type(text) ~= "string" then
        return nil
    end
    if secret(name) or type(name) ~= "string" or name == "" then
        return text
    end
    return text, short(name)
end

-- For the log: the game's own answer whether it hides chat from addons now.
function Adapter.ChatLocked()
    local ok, locked = pcall(C_ChatInfo.InChatMessagingLockdown)
    return ok and locked
end

-- The player's own name, read at the login (in a fight a name can be hidden).
function Adapter.PlayerName()
    local name = UnitName("player")
    return not secret(name) and name or nil
end

-- An item's quality from its link, or nil while the game does not know the item yet.
function Adapter.ItemQuality(link)
    local ok, quality = pcall(C_Item.GetItemQualityByID, link)
    return ok and type(quality) == "number" and quality or nil
end

-- The button the bind clicks: a secure button of ours, so Sticky Layers hears its press (decision 114, as Voice
-- Transcription's; its watch acts at the key down only, Core/BindSecure.lua SEEN). Made out of a fight. fn(down) runs
-- at each press and each let-go, as the bound button of Look Behind hears both (Auto/LookBehind.lua).
function Adapter.LinkButton(name, fn)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    button:RegisterForClicks("AnyDown", "AnyUp")
    button:SetScript("OnClick", function(_, _, down)
        fn(down)
    end)
    return button
end

-- A quest's state for the line under a quest link: "on" (in the quest log), "done" (handed in before) or "no"; nil
-- when the game cannot say. The calls: QuestLogDocumentation.lua 825 to 836 and 916 to 927, no restriction.
function Adapter.QuestState(id)
    local ok, state = pcall(function()
        return C_QuestLog.IsOnQuest(id) and "on" or C_QuestLog.IsQuestFlaggedCompleted(id) and "done" or "no"
    end)
    return ok and state or nil
end

-- The controller buttons a bind's click is on now, for the hint: the triggers held for it first ({ "RT", "A" }). Read
-- inside the press, while the key still reads as that click. nil when no key or more than one reads so.
function Adapter.KeysOf(click)
    local found
    for ours, theirs in pairs(Adapter.KEY) do
        if Adapter.EffectiveBinding(theirs) == click then
            if found then
                return nil
            end
            found = ours
        end
    end
    if not found then
        return nil
    end
    local keys, held = {}, { pcall(Adapter.Held) }
    for i, trigger in ipairs({ "LT", "RT", "LB", "RB" }) do
        if held[1] and held[i + 1] and trigger ~= found then
            keys[#keys + 1] = trigger
        end
    end
    keys[#keys + 1] = found
    return keys
end

-- The tooltips: [1] the link, [2] and [3] what is worn in its place. The size of the roll's tooltips, so the three
-- fit side by side on a Steam Deck screen. GAP: room between them, and for the header above a worn item.
local tips
local SCALE, GAP = 0.85, 24

local function frames()
    if not tips then
        tips = { CreateFrame("GameTooltip", "GamepadSuiteLinkTip", UIParent, "GameTooltipTemplate"),
            CreateFrame("GameTooltip", "GamepadSuiteLinkWorn1", UIParent, "ShoppingTooltipTemplate"),
            CreateFrame("GameTooltip", "GamepadSuiteLinkWorn2", UIParent, "ShoppingTooltipTemplate") }
        for _, tip in ipairs(tips) do
            tip:SetScale(SCALE)
            tip:SetFrameStrata("TOOLTIP")
        end
        -- the template's health bar compares the health in a fight (decision 131): a link never fills it, but it
        -- compares nothing here either
        local bar = rawget(tips[1], "StatusBar")
        if type(bar) == "table" then
            bar:SetScript("OnValueChanged", nil)
        end
    end
    return tips
end

function Adapter.HideLinkTip()
    for _, tip in ipairs(tips or {}) do
        tip:Hide()
    end
end

-- What is worn in the place of an item, at the right of the tooltip before it, the way the roll's tooltip shows it
-- (Core/AdapterRolls.lua 199 to 241, from the game's TooltipComparisonManager.lua 219 to 316): the header Equipped,
-- the item, and what changes. The game's own call for all of this is not used: its notes mark it protected. Gives
-- how many worn items show.
local function worn(text)
    local item = { hyperlink = text }
    local info = C_TooltipComparison.GetItemComparisonInfo(item)
    if not info then
        return 0
    end
    local METHOD, count = Enum.TooltipComparisonMethod, 0
    local single, both = info.method == METHOD.Single, info.method == METHOD.WithBothHands
    -- the other ring or trinket, or the other hand; one from the bags is not worn and is left out
    local second = (single or both) and info.additionalItems and info.additionalItems[1] or nil
    for n, other in ipairs({ info.item, second }) do
        local data = other.guid and C_TooltipInfo.GetItemByGUID(other.guid) or other.hyperlink and C_TooltipInfo.GetHyperlink(other.hyperlink)
        if not data then
            break
        end
        local tip = tips[n + 1]
        tip:SetOwner(tips[1], "ANCHOR_NONE")
        tip:ClearAllPoints()
        tip:SetPoint("BOTTOMLEFT", tips[n], "BOTTOMRIGHT", GAP / 2, 0)
        tip.CompareHeader.Label:SetText(EQUIPPED)
        tip.CompareHeader:SetWidth(tip.CompareHeader.Label:GetWidth() + 30)
        tip.CompareHeader:Show()
        tip:ProcessInfo({ tooltipData = data, append = true })
        local lines = (single or both and n == 1) and C_TooltipComparison.GetItemComparisonDelta(item, other, both and second or nil, false)
        if lines and #lines > 0 then
            GameTooltip_AddBlankLineToTooltip(tip)
            GameTooltip_AddNormalLine(tip, both and ITEM_DELTA_MULTIPLE_COMPARISON_DESCRIPTION or ITEM_DELTA_DESCRIPTION)
            for _, line in ipairs(lines) do
                GameTooltip_AddHighlightLine(tip, line)
            end
        end
        tip:Show()
        count = n
    end
    return count
end

-- Shows the tooltip of a link ({ link, text, kind }, Screen/ChatLinksModel.lua): low in the middle of the screen,
-- where the game's link window stands (Blizzard_UIPanels_Game/Mainline/ItemRef.xml 8: BOTTOM, 80 up), and just above
-- our on-screen buttons when they show, as the roll card (Screen/Rolls.lua 291 to 296). With worn gear the item stands
-- left of the middle and the worn items right of it. Gives the tooltip's frame and how many worn items show, or nil
-- and why.
function Adapter.ShowLinkTip(entry)
    Adapter.HideLinkTip()
    local ok, shown = pcall(function()
        local tip = frames()[1]
        tip:SetOwner(UIParent, "ANCHOR_NONE")
        tip:SetHyperlink(entry.link)
        return tip:IsShown()
    end)
    if not (ok and shown) then
        return nil, ok and "the game gave the tooltip no lines" or tostring(shown)
    end
    local fine, count = true, 0
    if entry.kind == "item" then
        fine, count = pcall(worn, entry.text)
        if not fine then
            tips[2]:Hide()
            tips[3]:Hide()
        end
    end
    local tip, buttons = tips[1], _G.GamepadSuiteScreen
    local point, x = (fine and count > 0) and "BOTTOMRIGHT" or "BOTTOM", (fine and count > 0) and -GAP / 2 or 0
    tip:ClearAllPoints()
    if type(buttons) == "table" and buttons:IsShown() then
        tip:SetPoint(point, buttons, "TOP", x, 8 / SCALE)
    else
        tip:SetPoint(point, UIParent, "BOTTOM", x, 80 / SCALE)
    end
    return tip, fine and count or "no worn item beside it: " .. tostring(count)
end
