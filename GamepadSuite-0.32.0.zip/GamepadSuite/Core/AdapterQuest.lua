-- The adapter's part for the bind Track Nearest Quest (Auto/QuestTrack.lua): the quests of the
-- log with the distance to each, and the call that makes one the quest the game points at.
-- On this game a quest is tracked in two steps. A watched quest is in the list at the side of
-- the screen. One thing at a time is "super tracked": the game's arrow in the world points at
-- it with the distance in yards (Blizzard_QuestNavigation/SuperTrackedFrame.lua 11 to 28 and
-- 200 to 207), and the map and the minimap mark it. The game's own quest list makes a quest that
-- one thing with C_SuperTrack.SetSuperTrackedQuestID
-- (Blizzard_ObjectiveTracker/Blizzard_QuestObjectiveTracker.lua 79 to 82). The game's notes do
-- not mark the call as restricted, and Mastercraft makes its sister call for a map pin from
-- addon code on this game. The addon draws nothing: the arrow and the marks are the game's.
-- The distance is the game's too: C_QuestLog.GetDistanceSqToQuest, which the game's own code
-- asks (Blizzard_FrameXML/Mainline/TutorialFrame.lua 28 to 31). It gives nothing for a quest
-- with no place on the map. The game's map draws its quest pins from places of the same kind
-- (Blizzard_WorldMap/Blizzard_WorldMap.lua 214 to 217).
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("questTrack", function()
    return C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo and C_QuestLog.GetDistanceSqToQuest
        and C_SuperTrack.SetSuperTrackedQuestID and C_SuperTrack.GetSuperTrackedQuestID ~= nil
end)

-- The quests of the log, in its order: { { id =, title =, far =, here = } }. far is the distance
-- to the quest's next step, squared (nil: the quest has no place on the map); here is true for
-- a quest on the continent the character is on. The headers of the log and the quests it hides
-- are left out.
function Adapter.Quests()
    local out = {}
    pcall(function()
        for index = 1, C_QuestLog.GetNumQuestLogEntries() do
            local info = C_QuestLog.GetInfo(index)
            if info and info.questID and not info.isHeader and not info.isHidden then
                local far, here = C_QuestLog.GetDistanceSqToQuest(info.questID)
                out[#out + 1] = { id = info.questID, title = info.title or ("quest " .. info.questID),
                    far = type(far) == "number" and far or nil, here = here and true or false }
            end
        end
    end)
    return out
end

-- The quest the game points at now, or nil.
function Adapter.TrackedQuest()
    local ok, id = pcall(C_SuperTrack.GetSuperTrackedQuestID)
    return ok and type(id) == "number" and id ~= 0 and id or nil
end

-- Makes a quest the one the game points at. True when the game then names it as that quest;
-- when the call did not run, the second value is what the game said.
function Adapter.TrackQuest(id)
    local ok, err = pcall(C_SuperTrack.SetSuperTrackedQuestID, id)
    return ok and Adapter.TrackedQuest() == id, not ok and tostring(err) or nil
end

-- Puts a quest in the list at the side of the screen, so its steps show there. The game's own
-- quest list does the same, up to its limit (Blizzard_UIPanels_Game/Mainline/QuestMapFrame.lua
-- 1438 to 1441; Constants.QuestWatchConsts.MAX_QUEST_WATCHES is 25, QuestConstantsDocumentation.lua
-- 168). Gives "watched" (it was there), "added", "full" (the list is full), or nil when the game
-- refused.
function Adapter.WatchQuest(id)
    local ok, kind = pcall(C_QuestLog.GetQuestWatchType, id)
    if not ok then
        return nil
    elseif kind ~= nil then
        return "watched"
    end
    local most = Constants and Constants.QuestWatchConsts and Constants.QuestWatchConsts.MAX_QUEST_WATCHES or 25
    local counted, count = pcall(C_QuestLog.GetNumQuestWatches)
    if counted and type(count) == "number" and count >= most then
        return "full"
    end
    return pcall(C_QuestLog.AddQuestWatch, id) and "added" or nil
end
