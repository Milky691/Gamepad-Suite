-- The adapter. Every Blizzard name we use is in this file, with a check at login.
-- A feature never names a Blizzard table itself. We read and hook. We never write into Blizzard's tables.
local _, ns = ...

local Adapter = {}
ns.Adapter = Adapter

local checks = {
    backdrop = function() return BackdropTemplateMixin ~= nil end,
    padIcons = function()
        return InputIconTextureSetUtility and InputIconTextureSetUtility.GetNormalActiveInputIconButtonTexture ~= nil
    end,
    padDevice = function()
        return C_GamePad and C_GamePad.GetActiveDeviceID and C_GamePad.GetDeviceMappedState ~= nil
    end,
    padOwner = function()
        local manager = GamepadSharedUtility and GamepadSharedUtility.InputBindingManager
        return manager and manager.IsOnlyCoreBindingSetActive ~= nil
    end,
    -- Blizzard's calls that change its stack of window binds; we watch them (AdapterPlay.lua)
    padStack = function()
        local manager = GamepadSharedUtility and GamepadSharedUtility.InputBindingManager
        return manager and manager.AddBindingSet and manager.RemoveSet and hooksecurefunc ~= nil
    end,
    -- what the bind core needs from the game's secure code
    secure = function()
        return RegisterStateDriver and SecureHandlerWrapScript and SecureHandlerExecute and InCombatLockdown ~= nil
    end,
    -- the pad's own buttons, for a trigger that the game makes no modifier (the game's restricted
    -- code reads the same state as GetGamePadState)
    padButtons = function()
        return C_GamePad and C_GamePad.ButtonBindingToIndex and C_GamePad.GetDeviceMappedState ~= nil
    end,
    -- the game's own action slots, for a button that has no bind of ours (AdapterHud.lua)
    actionSlots = function()
        return C_ActionBar and C_ActionBar.HasAction and C_ActionBar.GetActionTexture and C_ActionBar.IsUsableAction ~= nil
    end,
    -- an NPC's choices, for Skip Gossip; the player's buffs, for Sit at a Campfire (AdapterAuto.lua)
    gossip = function()
        return C_GossipInfo and C_GossipInfo.GetOptions and C_GossipInfo.SelectOption and C_GossipInfo.GetNumActiveQuests ~= nil
    end,
    auras = function() return C_UnitAuras and C_UnitAuras.GetPlayerAuraBySpellID ~= nil end,
    -- nameplates, for the target brackets
    plates = function() return C_NamePlate and C_NamePlate.GetNamePlateForUnit ~= nil end,
    nativeBar = function() return GamepadMainActionBarFrame and GamepadMainActionBarFrame.SetAlpha ~= nil end,
    spellState = function() return C_Spell.GetSpellCooldown and C_Spell.IsSpellUsable ~= nil end,
    -- the mouse pointer put at a place, and a mouse button pressed, at a press from the controller (AdapterPointer.lua)
    pointer = function()
        return SetCursorPosition and SimulateMouseDown and SimulateMouseUp
            and C_LimitedInput and C_LimitedInput.LimitedInputAllowed and Enum.LimitedInputType ~= nil
    end,
    -- the camera's zoom calls (AdapterZoom.lua); the game's own gamepad code makes the same two calls
    cameraZoom = function() return type(CameraZoomIn) == "function" and type(CameraZoomOut) == "function" end,
    -- how far the camera is, for the log only (AdapterZoom.lua)
    cameraRead = function() return type(GetCameraZoom) == "function" end,
    -- the game's loot roll frames: the list of the gamepad mode, or the four frames of the mouse and keyboard interface (AdapterRolls.lua)
    rolls = function()
        local pad = GamepadGroupLootRollFrame
        return (pad and pad.ScrollBox and pad.ScrollBox.ForEachFrame ~= nil) or GroupLootFrame1 ~= nil
    end,
    -- the pointer set free for a trackpad or a touch: the lock for the camera, the call that takes it off, and the
    -- game's event for a mouse button that goes down (AdapterHandoff.lua)
    handoff = function()
        return IsMouselooking and MouselookStop and IsMouseButtonDown and GetCursorPosition
            and C_EventUtils.IsEventValid("GLOBAL_MOUSE_DOWN") == true
    end,
    -- the game's call for a raid mark, which its secure button action makes for Mark Next (AdapterExtras.lua)
    raidMark = function() return SetRaidTarget ~= nil end,
    -- the camera turned half way round, for Look Behind
    flipCamera = function() return FlipCameraYaw ~= nil end,
    -- a buff of the player asked for by its name, for Stay Seated While Eating
    auraByName = function() return C_UnitAuras and C_UnitAuras.GetAuraDataBySpellName ~= nil end,
    -- the game's chat text box: its messages for the focus, and the code that sends them (AdapterKeyboard.lua)
    chatBox = function()
        return EventRegistry and EventRegistry.RegisterCallback and ChatFrameEditBoxMixin
            and ChatFrameEditBoxMixin.OnEditFocusGained ~= nil
    end,
    -- the game's range answers for a spell and its event when one changes, for the range finder (AdapterRange.lua)
    rangeEvents = function()
        return C_Spell.EnableSpellRangeCheck and C_Spell.IsSpellInRange and C_Spell.SpellHasRange and C_Spell.IsSpellHarmful
            and C_Spell.GetSpellInfo and C_EventUtils.IsEventValid("SPELL_RANGE_CHECK_UPDATE") == true
    end,
    -- the tooltip of a loot roll's item in a frame of the addon's own, and the worn items beside it (AdapterRolls.lua)
    rollTip = function()
        return TooltipDataHandlerMixin.SetLootRollItem and TooltipDataHandlerMixin.ProcessInfo and GetLootRollItemLink
            and C_TooltipComparison.GetItemComparisonInfo and C_TooltipComparison.GetItemComparisonDelta
            and C_TooltipInfo.GetItemByGUID and C_TooltipInfo.GetHyperlink and Enum.TooltipComparisonMethod.WithBothHands
            and GameTooltip_AddBlankLineToTooltip and GameTooltip_AddNormalLine and GameTooltip_AddHighlightLine
            and EQUIPPED and ITEM_DELTA_DESCRIPTION and ITEM_DELTA_MULTIPLE_COMPARISON_DESCRIPTION ~= nil
    end,
    -- masks, a shaped cooldown sweep and the game's range event, for the looks of the on-screen buttons (AdapterLook.lua)
    look = function()
        return C_Spell.EnableSpellRangeCheck ~= nil and UIParent.CreateMaskTexture ~= nil
    end,
    -- a spell, an item or a macro on the mouse pointer (a drop on an on-screen button)
    cursorDrop = function() return GetCursorInfo ~= nil and ClearCursor ~= nil end,
    -- a game setting set for this session only: the game puts the player's value back by itself
    tempSetting = function() return C_CVar and C_CVar.SetTempCVar and C_CVar.RemoveTempCVar ~= nil end,
    frameControls = function()
        return GamepadMode and GamepadMode.FrameControlsManager ~= nil
    end,
    rumble = function()
        return C_GamePad and C_GamePad.SetVibration and C_GamePad.StopVibration ~= nil
    end,
    consoleList = function() return ConsoleGetAllCommands ~= nil end,
    bindContext = function()
        return Enum and Enum.BindingContext and Enum.BindingContext.GamepadModeInGameCore ~= nil
    end,
    -- what is in the hands, and the game's macro condition that asks for it (Core/Hands.lua)
    hands = function()
        local worn = SecureCmdOptionParse("[worn:" .. C_Item.GetItemSubClassInfo(2, 20) .. "] 1; 0")
        return GetInventoryItemID and C_Item.GetItemInfoInstant and (worn == "1" or worn == "0")
    end,
    -- the sources of the list where the player chooses a bind (AdapterLists.lua)
    spellBook = function()
        return C_SpellBook.GetNumSpellBookSkillLines and C_SpellBook.GetSpellBookSkillLineInfo
            and C_SpellBook.GetSpellBookItemInfo and Enum.SpellBookItemType.Spell and Enum.SpellBookSpellBank.Player ~= nil
    end,
    bagItems = function()
        return C_Container.GetContainerNumSlots and C_Container.GetContainerItemID
            and C_Item.GetItemSpell and C_Item.GetItemNameByID and C_Item.GetItemIconByID ~= nil
    end,
    macroList = function() return GetNumMacros and GetMacroInfo ~= nil end,
    commandList = function() return GetNumBindings and GetBinding ~= nil end,
    emoteList = function() return type(EmoteList) == "table" and type(TextEmoteSpeechList) == "table" and MAXEMOTEINDEX ~= nil end,
    petBar = function() return PetHasActionBar and GetPetActionInfo and NUM_PET_ACTION_SLOTS ~= nil end,
    forms = function() return GetNumShapeshiftForms and GetShapeshiftFormInfo and UnitClass ~= nil end,
}

local results = {}

-- An adapter part adds the login check of its own feature (Core/Adapter*.lua, loaded after this file).
function Adapter.Check(name, fn)
    checks[name] = fn
end

function Adapter.RunChecks()
    for name, check in pairs(checks) do
        local ok, found = pcall(check)
        results[name] = (ok and found) and true or false
    end
    return results
end

function Adapter.Results()
    return results
end

-- Our key names on the left, the game's key names on the right.
Adapter.KEY = {
    A = "PAD1", B = "PAD2", X = "PAD3", Y = "PAD4",
    LB = "PADLSHOULDER", RB = "PADRSHOULDER", LT = "PADLTRIGGER", RT = "PADRTRIGGER",
    DU = "PADDUP", DD = "PADDDOWN", DL = "PADDLEFT", DR = "PADDRIGHT",
    LS = "PADLSTICK", RS = "PADRSTICK", VW = "PADBACK", MN = "PADFORWARD", GD = "PADSYSTEM",
    L4 = "PADPADDLE2", L5 = "PADPADDLE4", R4 = "PADPADDLE1", R5 = "PADPADDLE3",
}
Adapter.NAME = {}
for ours, theirs in pairs(Adapter.KEY) do
    Adapter.NAME[theirs] = ours
end

-- The game's own picture for a button, for the controller that is plugged in. nil if it has none.
function Adapter.IconAtlas(ourKey)
    -- (the game's pictures name the Xbox button CENTERBUTTON, not PADSYSTEM: GamepadConstants.lua 37)
    local gameKey = results.padIcons and (ourKey == "DPAD" and "DIRPAD" or ourKey == "GD" and "CENTERBUTTON" or Adapter.KEY[ourKey])
    if not gameKey then
        return nil
    end
    -- the set picked on the row Button Icons comes first (Core/AdapterController.lua)
    local ok, atlas = true, Adapter.StyleAtlas and Adapter.StyleAtlas(gameKey)
    if not atlas then
        ok, atlas = pcall(InputIconTextureSetUtility.GetNormalActiveInputIconButtonTexture, gameKey)
    end
    if ok and type(atlas) == "string" and atlas ~= "" then
        return atlas
    end
    return nil
end

function Adapter.OnIconSetChanged(fn)
    if InputDeviceIconSetManager and InputDeviceIconSetManager.RegisterActiveInputDeviceIconSetUpdatedCallback then
        InputDeviceIconSetManager:RegisterActiveInputDeviceIconSetUpdatedCallback(fn, ns)
    end
end

-- What the game says about the active controller. Used to pick the controller picture.
function Adapter.DeviceInfo()
    local info = {}
    if results.padDevice then
        local id = C_GamePad.GetActiveDeviceID()
        info.id = id
        local mapped = id and C_GamePad.GetDeviceMappedState(id)
        if mapped then
            info.name, info.labelStyle = mapped.name, mapped.labelStyle
            info.buttonCount, info.axisCount = mapped.buttonCount, mapped.axisCount
        end
        local raw = id and C_GamePad.GetDeviceRawState and C_GamePad.GetDeviceRawState(id)
        if raw then
            info.rawName = raw.name
        end
    end
    if GetPhysicalScreenSize then
        info.screenWidth, info.screenHeight = GetPhysicalScreenSize()
    end
    return info
end

-- True when gameplay has the controller, false when a Blizzard window has it, nil if we cannot tell.
function Adapter.GameplayHasPad()
    if not results.padOwner then
        return nil
    end
    return GamepadSharedUtility.InputBindingManager:IsOnlyCoreBindingSetActive() and true or false
end

function Adapter.WindowFocus()
    if not results.frameControls then
        return nil, nil
    end
    local manager = GamepadMode.FrameControlsManager
    local count = manager.GetShownFrameCount and manager:GetShownFrameCount() or nil
    return manager.isUIFocused, count
end

local rumbleTimer
function Adapter.Rumble(kind, strength, seconds)
    if not results.rumble then
        return false
    end
    C_GamePad.SetVibration(kind, strength)
    if rumbleTimer then
        rumbleTimer:Cancel()
    end
    -- the stop needs a timer: the game has no "pulse for n seconds" call
    rumbleTimer = C_Timer.NewTimer(seconds, function()
        rumbleTimer = nil
        C_GamePad.StopVibration()
    end)
    return true
end

-- One of the game's own interface sounds, by its name in the game's sound table.
function Adapter.Sound(name)
    if SOUNDKIT and SOUNDKIT[name] and PlaySound then
        PlaySound(SOUNDKIT[name])
    end
end

function Adapter.Build()
    local version, build, _, interface = GetBuildInfo()
    return version, build, interface
end

function Adapter.GameplayContext()
    return results.bindContext and Enum.BindingContext.GamepadModeInGameCore or nil
end

-- The rank of a spell as the game writes it ("Rank 6"), or "" when it has none or the game has not loaded it yet.
function Adapter.SpellRank(spellId)
    return C_Spell.GetSpellSubtext and C_Spell.GetSpellSubtext(spellId) or ""
end

-- Shows the game's own tooltip for a bind beside a frame. side is "LEFT" or "RIGHT" of that frame.
-- A spell, an item or a pet ability shows the game's full text, a macro its own text.
-- A game command or an emote has nothing more to say than its name, so it gets no tooltip.
function Adapter.ShowTooltip(owner, side, bind)
    local spell = (bind.kind == "spell" or bind.kind == "pet") and type(bind.id) == "number"
    if not (spell or bind.kind == "item" or bind.kind == "macro") then
        GameTooltip:Hide()
        return
    end
    GameTooltip:SetOwner(owner, side == "LEFT" and "ANCHOR_LEFT" or "ANCHOR_RIGHT")
    if spell then
        GameTooltip:SetSpellByID(bind.id)
    elseif bind.kind == "item" then
        GameTooltip:SetItemByID(bind.id)
    else
        local _, _, text = GetMacroInfo(bind.id)
        GameTooltip:SetText(bind.name or tostring(bind.id), 1, 1, 1)
        GameTooltip:AddLine(text or "", 0.94, 0.9, 0.79, true)
    end
    GameTooltip:Show()
end

function Adapter.HideTooltip()
    GameTooltip:Hide()
end

-- True when the mouse pointer has moved since the last time this was asked. A frame that is
-- drawn again under a resting pointer gets a new "mouse entered" from the game; that is not a move.
local lastX, lastY
function Adapter.MouseMoved()
    local x, y = GetCursorPosition()
    local moved = x ~= lastX or y ~= lastY
    lastX, lastY = x, y
    return moved
end

-- The classes whose forms change what the buttons should do. Stealth and Shadowform are forms to the game.
local FORM_CLASSES = { DRUID = true, WARRIOR = true, ROGUE = true, PRIEST = true }
-- Dire Bear Form takes the place of Bear Form when a druid learns it. Both are one set, so the
-- binds of the Bear set stay.
local SAME_FORM = { [9634] = 5487 }

-- Stealth that is no form of its own in the game's list has a set all the same: a druid's Prowl
-- (Cat Form with stealth), and a rogue's Stealth should this game not list it as a form. Such a
-- set has `when`, the game's own words for its state. Prowl has `base` too: the set of Cat Form,
-- which a button with no bind for Prowl uses first.
local CAT, PROWL, STEALTH = 768, 5215, 1784

local function knows(spell)
    return IsPlayerSpell ~= nil and IsPlayerSpell(spell) and true or false
end

-- The forms or stances the player has, in the game's order: { { id = "form:<spell number>", name,
-- index = the game's number of the form } }. The spell number names the form, so a bind stays
-- with its form when the game's order changes.
function Adapter.Forms()
    local forms = {}
    if not results.forms or not FORM_CLASSES[select(2, UnitClass("player"))] then
        return forms
    end
    for index = 1, GetNumShapeshiftForms() do
        local spellId = select(4, GetShapeshiftFormInfo(index))
        local name = spellId and C_Spell.GetSpellName(spellId)
        if name then
            forms[#forms + 1] = { id = "form:" .. (SAME_FORM[spellId] or spellId), name = name, index = index }
        end
    end
    local cat, listed
    for _, form in ipairs(forms) do
        cat = form.id == "form:" .. CAT and form or cat
        listed = listed or form.id == "form:" .. STEALTH
    end
    -- last in the list: the state driver asks the last one first, so Prowl stands before Cat Form
    if cat and knows(PROWL) then
        forms[#forms + 1] = { id = "form:" .. PROWL, name = C_Spell.GetSpellName(PROWL) or "Prowl", index = cat.index,
            when = "form:" .. cat.index .. ",stealth", stealth = true, base = cat.id }
    elseif select(2, UnitClass("player")) == "ROGUE" and not listed and knows(STEALTH) then
        forms[#forms + 1] = { id = "form:" .. STEALTH, name = C_Spell.GetSpellName(STEALTH) or "Stealth", index = 0, when = "stealth", stealth = true }
    end
    return forms
end

-- True when the list of forms is another one than at the last call. (The game also tells of
-- "the forms changed" when nothing changed.)
local lastForms
function Adapter.FormsChanged()
    local parts = {}
    for i, form in ipairs(Adapter.Forms()) do
        parts[i] = form.id .. "@" .. form.index
    end
    local now = table.concat(parts, " ")
    local changed = now ~= lastForms
    lastForms = now
    return changed
end

-- The game's own name for a binding command ("Jump"; "Toggle Game Menu" shows as "Game Menu"), or nil. The radial Main
-- Menu (OPENRADIAL, Blizzard_Gamepad/Bindings.xml 2) is a hidden binding with no name of the game's: it takes ours.
local OWN_NAME = { OPENRADIAL = "Main Menu" }
function Adapter.CommandName(command)
    local name = _G["BINDING_NAME_" .. command] -- (another addon can put anything in such a global: only text counts)
    return type(name) == "string" and (name:gsub("^Toggle ", "")) or OWN_NAME[command]
end

-- What a pad key does in gameplay now: the game's binding command. Nil when the key has no
-- command, or the game has no name for the command. The context argument is new on this build,
-- so the call is guarded.
function Adapter.KeyCommand(ourKey)
    local ok, command = pcall(GetBindingAction, Adapter.KEY[ourKey], false, Adapter.GameplayContext())
    -- the A button of Blizzard's bar is a fixed slot that runs Jump; the command does the same
    if ok and command == "GAMEPADACTIONBUTTON8" then
        command = "JUMP"
    end
    if ok and type(command) == "string" and command ~= "" and Adapter.CommandName(command) then
        return command
    end
    return nil
end

-- Every console setting whose name holds one of the words. For the report.
function Adapter.ConsoleSettings(words)
    local found = {}
    if not results.consoleList then
        return found
    end
    for _, info in ipairs(ConsoleGetAllCommands()) do
        local name = info.command
        local lower = name:lower()
        for _, word in ipairs(words) do
            if lower:find(word, 1, true) then
                local ok, value = pcall(GetCVar, name)
                found[name] = { value = ok and value or nil, help = info.help }
                break
            end
        end
    end
    return found
end
