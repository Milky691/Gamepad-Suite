-- The adapter's part for the bind Feed Pet (Auto/FeedPet.lua): the pet, the food in the bags,
-- and the button that feeds.
-- The game feeds a pet with its spell Feed Pet, which then waits for an item. The game's own bag
-- window knows the spell by its number and asks C_PetInfo.CanPetEatItem if the pet eats a thing
-- (Blizzard_UIPanels_Game/Mainline/ContainerFrame.lua 3206 to 3220). A cast is a thing an addon
-- may not do, so the bind clicks one of the game's secure buttons. Such a button casts its spell
-- and then, in the game's own code, gives the waiting spell the item of a bag place
-- (Blizzard_FrameXML/SecureTemplates.lua 396 to 405 and 766 to 784): the same call that a click
-- on an item in the bag makes while a spell waits (ContainerFrame.lua 1506 to 1508). It gives
-- the item only while a spell does wait for one. So a cast that the game refuses eats nothing.
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("feedPet", function()
    return C_PetInfo.CanPetEatItem and C_Container.GetContainerNumSlots and C_Container.GetContainerItemID
        and C_Container.GetContainerItemInfo and C_Item.GetItemInfo and C_Item.GetItemCount and UnitExists and UnitIsDead
        and C_EventUtils.IsEventValid("UNIT_PET") and C_EventUtils.IsEventValid("BAG_UPDATE_DELAYED") == true
end)

Adapter.Check("petHungry", function()
    return C_PetInfo.GetPetHappiness and C_PetInfo.GetPetFoodTypes and HasPetUI and UnitGUID
        and C_EventUtils.IsEventValid("UNIT_HAPPINESS") == true
end)

-- the game's number of the spell Feed Pet
local FEED = 6991

local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- The game feeds no pet while the player or the pet is in a fight. This piece of the game's
-- restricted code runs before each click and stops it then, so the press does nothing in a fight
-- (Blizzard_RestrictedAddOnEnvironment/RestrictedEnvironment.lua 200 has the question, and
-- SecureHandlers.lua 272 to 279 the stop).
local NOT_IN_A_FIGHT = [[
    if PlayerInCombat() then
        return false
    end
]]

-- True while a pet is out and alive.
function Adapter.HasPet()
    return Adapter.PetState() == "alive"
end

-- "alive", "dead" (it lies dead beside the hunter: Revive Pet is the next act), or nil with no pet out.
function Adapter.PetState()
    local ok, state = pcall(function()
        return UnitExists("pet") and (UnitIsDead("pet") and "dead" or "alive") or nil
    end)
    return ok and state or nil
end

-- If the player can cast Feed Pet now, and if the player knows it (a cast short of mana only: the game's own red
-- line says so). C_Spell.IsSpellUsable (SpellDocumentation.lua 980 to 995) gives isUsable and insufficientPower; the
-- game's own bags ask it before they offer "Feed to pet" (ContainerFrame.lua 3204 to 3217). A game with no such call:
-- both true.
function Adapter.FeedUsable()
    if not (C_Spell and C_Spell.IsSpellUsable) then
        return true, true
    end
    local ok, usable, short = pcall(C_Spell.IsSpellUsable, FEED)
    if not ok or hidden(usable) or hidden(short) then
        return true, true
    end
    return usable and true or false, (usable or short) and true or false
end

-- The hunter pet's happiness (1 unhappy, 2 content, 3 happy) and the damage it does in percent, as the game's own
-- happiness picture reads them (C_PetInfo.GetPetHappiness: PetInfoDocumentation.lua 35 to 43; Blizzard_FrameXML/
-- PetHappiness.lua 49 to 62 shows it only for HasPetUI's isHunterPet). nil with no living hunter pet.
function Adapter.PetHappiness()
    local ok, happy, damage = pcall(function()
        local _, hunterPet = HasPetUI()
        if not hunterPet or Adapter.PetState() ~= "alive" then
            return nil
        end
        return C_PetInfo.GetPetHappiness()
    end)
    if not ok or hidden(happy) or type(happy) ~= "number" then
        return nil
    end
    return happy, not hidden(damage) and type(damage) == "number" and damage or nil
end

-- What the pet eats, by the game's own names of the kinds ("Meat", "Fish": C_PetInfo.GetPetFoodTypes,
-- PetInfoDocumentation.lua 26 to 32; the game's own tooltip lists them, PetHappiness.lua 102 to 115).
function Adapter.PetDiet()
    local ok, list = pcall(C_PetInfo.GetPetFoodTypes)
    local out = {}
    for _, kind in ipairs(ok and type(list) == "table" and list or {}) do
        if type(kind) == "string" and not hidden(kind) then
            out[#out + 1] = kind
        end
    end
    return out
end

-- The pet's GUID: a different pet is a new cause.
function Adapter.PetGUID()
    local ok, guid = pcall(UnitGUID, "pet")
    return ok and type(guid) == "string" and not hidden(guid) and guid or nil
end

-- What the pet eats of the bags, in the order of the bags: { { bag =, slot =, id =, level =,
-- count =, name = } }. level is the item's level (0 until the game has loaded the item), count the
-- size of the stack, name nil until the game has loaded it. A stack that the game holds locked (it
-- is on the pointer) is left out.
function Adapter.PetFoods()
    local foods = {}
    pcall(function()
        for bag = 0, 4 do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                local id = C_Container.GetContainerItemID(bag, slot)
                if id and C_PetInfo.CanPetEatItem(id) then
                    local info = C_Container.GetContainerItemInfo(bag, slot)
                    if info and not info.isLocked then
                        local name, _, _, level = C_Item.GetItemInfo(id)
                        foods[#foods + 1] = { bag = bag, slot = slot, id = id, level = level or 0, count = info.stackCount or 1, name = name }
                    end
                end
            end
        end
    end)
    return foods
end

-- How many of an item the bags hold: for the log.
function Adapter.FoodLeft(id)
    local ok, count = pcall(C_Item.GetItemCount, id)
    return ok and type(count) == "number" and count or 0
end

-- True while a spell waits for an item (the game's pointer shows it): for the log of a press.
-- The game asks the same before it gives such a spell the item of a bag place (SecureTemplates.lua
-- 769), and its gamepad windows end such a wait when they close (Blizzard_GamepadSharedUtility/
-- FrameControlsManager.lua 550).
function Adapter.SpellWaits()
    local ok, waits = pcall(SpellCanTargetItem)
    return ok and waits and true or false
end

-- Makes the button. It acts when the key goes down, whatever the game's setting for casts on key
-- down says. It does nothing until Adapter.SetFeed gives it a food.
function Adapter.FeedButton(name)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    button:RegisterForClicks("AnyDown")
    button:SetAttribute("useOnKeyDown", true)
    button:SetAttribute("spell", FEED)
    SecureHandlerWrapScript(button, "OnClick", button, NOT_IN_A_FIGHT)
    return button
end

-- Gives the button the food of the next press (one of Adapter.PetFoods), or nil: then a press
-- does nothing. Out of a fight only: the game locks the button in one.
function Adapter.SetFeed(button, food)
    button:SetAttribute("type", food and "spell" or nil)
    button:SetAttribute("target-bag", food and food.bag or nil)
    button:SetAttribute("target-slot", food and food.slot or nil)
end
