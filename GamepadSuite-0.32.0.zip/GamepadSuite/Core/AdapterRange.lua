-- The adapter, the part for the range finder (Screen/Range.lua): how far the target is.
-- The game gives an addon no distance to an enemy. What it gives: for a spell or an item with a
-- reach, is the target inside that reach; and an event each time the answer of a spell that it
-- was asked to watch changes. The game's own cooldown list works the same way. The answers are
-- not hidden in a fight (charles-hood/wow-forever-addons, its notes file 75-79, build 70338).
local _, ns = ...

local Adapter = ns.Adapter

-- The melee reach, for every class: an item's reach. On this build the game answers for the
-- reach of an item, plain in a fight, once the item's data is loaded (the same notes, its notes file
-- 28-35 and docs/forever-addon-kit-issue.md 36-42: every band of LibRangeCheck's items from 5 to
-- 40 yards). Voodoo Charm reaches 5 yards (HunterProbe.lua 48). The game's own swing check gives
-- an addon no answer on this build (C_SwingTimer.IsTargetWithinSwingRange is always nil), and a
-- melee spell with no reach of its own (0 to 0) says "in reach" at any distance.
local MELEE_ITEM, MELEE = 8149, 5
local loading = false

-- The player's spells that reach out to an enemy, from the spell book:
--   { { spell = number, name =, min =, max = } }, the two reaches in yards.
-- A spell with no reach of its own (a shout, a form) and a spell for friends only are left out.
function Adapter.RangeSpells()
    local out = {}
    local ok, tabs = pcall(Adapter.Spells)
    for _, tab in ipairs(ok and tabs or {}) do
        for _, entry in ipairs(tab.entries) do
            pcall(function()
                local info = C_Spell.IsSpellHarmful(entry.id) and C_Spell.SpellHasRange(entry.id) and C_Spell.GetSpellInfo(entry.id)
                if info and info.maxRange > 0 then
                    out[#out + 1] = { spell = entry.id, name = info.name or entry.name, min = info.minRange or 0, max = info.maxRange }
                end
            end)
        end
    end
    return out
end

-- The melee reach as one more thing with a reach. The first call asks the game to load the
-- item's data, so that its answers come from the first reading on (Range.lua asks at login).
function Adapter.RangeMelee()
    if not loading then
        loading = true
        pcall(C_Item.RequestLoadItemDataByID, MELEE_ITEM)
    end
    return { item = MELEE_ITEM, name = "the 5 yard item", min = 0, max = MELEE }
end

-- Asks the game to tell when the answer of each spell changes. It is asked again at each new
-- target, which costs nothing. The game is never told to stop: its own action bars and cooldown
-- list ask for the same answers, and a "stop" of ours could end theirs. The item has no such event.
function Adapter.WatchReach(probes)
    for _, probe in ipairs(probes) do
        if probe.spell then
            pcall(C_Spell.EnableSpellRangeCheck, probe.spell, true)
        end
    end
end

-- Is the target inside the reach now: true or false; nil when the game cannot tell (no target,
-- a target that cannot be attacked, an item whose data is not loaded yet).
function Adapter.InRange(probe)
    local ok, inside = pcall(function()
        local answer
        if probe.item then
            answer = C_Item.IsItemInRange(probe.item, "target")
        else
            answer = C_Spell.IsSpellInRange(probe.spell, "target")
        end
        if answer == true or answer == 1 then
            return true
        elseif answer == false or answer == 0 then
            return false
        end
        return nil
    end)
    if not ok then
        return nil
    end
    return inside
end

-- Tells fn each time the game says that a watched answer changed, until
-- Adapter.OffRangeChanged(owner): fn(spell number) for a spell. The item has no event of its own,
-- so fn(nil, why) comes at what goes with an enemy in melee reach: a swing of the player's
-- (PLAYER_SWING, plain on this build: its notes file 60-62 of the same notes), a hit the player takes,
-- and the end of a walk (PLAYER_STOPPED_MOVING, which the game's own frame fader hears:
-- PlayerMovementFrameFader.lua 23 to 39), so a walk into melee reach shows when the player stops.
-- The hit is heard for the player alone, through the game's own unit filter: no unit is compared here.
local hits
function Adapter.OnRangeChanged(owner, fn)
    pcall(ns.On, "SPELL_RANGE_CHECK_UPDATE", owner, function(spell)
        fn(spell)
    end)
    pcall(ns.On, "PLAYER_SWING", owner, function()
        fn(nil, "a swing of the player")
    end)
    pcall(ns.On, "PLAYER_STOPPED_MOVING", owner, function()
        fn(nil, "the player stopped moving")
    end)
    hits = hits or CreateFrame("Frame")
    hits:SetScript("OnEvent", function()
        ns.Call(owner, fn, nil, "a hit the player took")
    end)
    pcall(hits.RegisterUnitEvent, hits, "UNIT_COMBAT", "player")
end

function Adapter.OffRangeChanged(owner)
    ns.Off("SPELL_RANGE_CHECK_UPDATE", owner)
    ns.Off("PLAYER_SWING", owner)
    ns.Off("PLAYER_STOPPED_MOVING", owner)
    if hits then
        hits:UnregisterEvent("UNIT_COMBAT")
    end
end
