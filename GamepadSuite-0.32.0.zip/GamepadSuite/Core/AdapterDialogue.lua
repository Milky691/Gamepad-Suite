-- The adapter's part for the dialogue view (Screen/Dialogue.lua): the events of a talk with an
-- NPC, what the game says of it, and the steps of the talk. The look is in AdapterDialogueLook.lua.
--
-- What the game's code says (Blizzard_UIPanels_Game, the files this game type loads):
--   A gossip. CustomGossipFrameManager hears GOSSIP_SHOW and GOSSIP_CLOSED and shows GossipFrame
--   with ShowUIPanel (Mainline/CustomGossipFrameBase.lua 3 to 6 and 37 to 55, Shared/
--   GossipFrameShared.lua 191 to 209). A quest. QuestFrame hears QUEST_GREETING, QUEST_DETAIL,
--   QUEST_PROGRESS, QUEST_COMPLETE and QUEST_FINISHED and shows itself the same way (Mainline/
--   QuestFrame.lua 9 to 111). There are no other frames for the controller: these two have the
--   controller code in them (GossipFrame.lua 74 to 132, QuestFrame.lua 695 to 868).
--   A window that ShowUIPanel shows gets the controller (Blizzard_GamepadSharedUtility/
--   FrameControlsManager.lua 210 to 216 and 397 to 473), and the game's navigation then draws
--   its pointer on it. A window that hides ends the talk: GossipFrameShared.lua 176 to 185,
--   QuestFrame.lua 436 to 453. So a game window that showed cannot be put away again.
--   The way taken here: the two frames stop hearing the five events that open them
--   (UnregisterEvent, a frame's own call; no field of the game is written). Then no game window
--   opens, nothing gets the controller, and the game's code for the end of a talk still runs.
--   The game's notes say that a frame can refuse a change of its events to an addon
--   (SimpleFrameAPIDocumentation.lua 1598 to 1602). So the change is read back, and the view
--   shows only when it held.
--   The boxes in which the game asks before a choice with a price (GOSSIP_CONFIRM, and the
--   trainer's CONFIRM_TALENT_WIPE) are shown by the game's own event code, apart from the two
--   windows (Blizzard_Game/Shared/EventRouting.lua 90 to 93, Mainline/EventRouting.lua 21), so
--   the take leaves them as they are. The player answers them there; no call of the view does.
--   What cannot be done: open the game's window for a talk that is already on. Its code would
--   run as an addon's, and what it writes for the controller (FrameControlsManager.lua 97 to 99
--   and 422, GossipFrame.lua 90) would stay marked for the session. When the view gives a talk
--   up, the talk ends, and the game's window opens at the next talk.
--   The steps of a talk are plain calls. The game makes them with no press: it takes a lone
--   choice inside the event (GossipFrameShared.lua 197). ForeverPlus accepts, completes and
--   takes the reward from the events on this game (Modules/QuestAutoAccept.lua 57 to 66,
--   QuestAutoTurnIn.lua 75 to 98). The events come inside the call that causes them (the notes
--   mark them SynchronousEvent), so the module makes each step from a timer, never inside a press.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

Adapter.Check("dialogue", function()
    for _, event in ipairs({ "GOSSIP_SHOW", "GOSSIP_CLOSED", "QUEST_GREETING", "QUEST_DETAIL", "QUEST_PROGRESS", "QUEST_COMPLETE",
        "QUEST_FINISHED", "QUEST_ITEM_UPDATE", "QUEST_LOG_UPDATE", "GET_ITEM_INFO_RECEIVED", "UNIT_MODEL_CHANGED",
        "UI_SCALE_CHANGED", "DISPLAY_SIZE_CHANGED", "UI_ERROR_MESSAGE", "PLAYER_INTERACTION_MANAGER_FRAME_SHOW",
        "GAME_PAD_CONNECTED", "GAME_PAD_DISCONNECTED", "GAME_PAD_ACTIVE_CHANGED", "GOSSIP_CONFIRM", "CONFIRM_TALENT_WIPE" }) do
        if not C_EventUtils.IsEventValid(event) then
            return false
        end
    end
    return QuestFrame.UnregisterEvent and QuestFrame.IsEventRegistered and GossipFrame.IsShown
        and CustomGossipFrameManager.UnregisterEvent and CustomGossipFrameManager.IsEventRegistered
        and C_GossipInfo.GetText and C_GossipInfo.GetOptions and C_GossipInfo.GetAvailableQuests and C_GossipInfo.GetActiveQuests
        and C_GossipInfo.SelectOptionByIndex and C_GossipInfo.SelectAvailableQuest and C_GossipInfo.SelectActiveQuest
        and C_GossipInfo.CloseGossip and C_GossipInfo.ForceGossip
        and GetGreetingText and GetNumAvailableQuests and GetAvailableTitle and GetNumActiveQuests and GetActiveTitle
        and SelectAvailableQuest and SelectActiveQuest and GetTitleText and GetQuestText and GetObjectiveText
        and GetProgressText and GetRewardText and GetRewardMoney and GetRewardXP and GetNumQuestRewards and GetNumQuestChoices
        and GetNumQuestItems and GetQuestItemInfo and GetQuestItemLink and GetQuestMoneyToGet and IsQuestCompletable
        and AcceptQuest and CompleteQuest and GetQuestReward and CloseQuest and GetQuestID
        and C_Item.GetItemCount and UnitExists and UnitName and SetPortraitTexture and hooksecurefunc ~= nil
end)
-- The objectives of a quest with their counts, for a quest in progress. On a game build
-- without the call the view shows the items the quest needs.
Adapter.Check("questGoals", function()
    return C_QuestLog.GetQuestObjectives ~= nil
end)

-- ---------------------------------------------------------------- what the game says of a talk

-- The unit that speaks: "questnpc", then "npc", each only when it is there, is not the player
-- and is not dead (a quest from an item has the player as its NPC). nil for none: the portrait
-- then shows the book picture and the quest's name. A value the game hides counts as no.
local function plain(value)
    return not (issecretvalue ~= nil and issecretvalue(value)) and value
end
local function speaker()
    for _, unit in ipairs({ "questnpc", "npc" }) do
        local ok, fine = pcall(function()
            return UnitExists(unit) and not plain(UnitIsUnit(unit, "player")) and not plain(UnitIsDead(unit))
        end)
        if ok and fine then
            return unit
        end
    end
end

-- "20 of 20" while the quest log has no room for one more quest, else nil, and nil when the game
-- cannot say (a reading that fails never stops an accept). The game's own dialog for a member's
-- quest turns its Accept off on the same compare (Blizzard_StaticPopup_Game/GameDialogDefs.lua 54
-- to 62); the calls: QuestLogDocumentation.lua 303 to 310 (the 2nd value counts the quests, not
-- the headers) and 241 to 250.
local function logFull()
    local ok, text = pcall(function()
        local _, have = C_QuestLog.GetNumQuestLogEntries()
        local most = C_QuestLog.GetMaxNumQuestsCanAccept()
        return most > 0 and have >= most and have .. " of " .. most or nil
    end)
    return ok and text or nil
end

-- The name of a quest as the game's own quest log of this game type writes it: "[24] Name",
-- "[30+] Name (Elite)", "(Dungeon)", "(PvP)", "(Raid)" (Blizzard_FrameXMLUtil/Camelot/
-- QuestUtilsOverrides.lua 6 to 35; the tag is its own call, which only reads and keeps nothing),
-- and "(Daily)" or "(Weekly)" for a quest that comes back (Enum.QuestFrequency 1 and 2). The level
-- is in the game's difficulty colour while the game's setting for it is on (the same file, 11 to
-- 18); the rest of the name keeps the view's colour, so the row in focus still reads white.
-- level: the level the gossip gives, for a quest the game does not know yet. The plain name for
-- a quest with no number, and when a call fails. seen counts for the log.
local seen = { rows = 0, levels = 0, tags = {} }
-- a colour (0 to 1 each) as the code in front of coloured words
local function hex(r, g, b)
    return ("|cff%02x%02x%02x"):format(math.floor(r * 255 + 0.5), math.floor(g * 255 + 0.5), math.floor(b * 255 + 0.5))
end
local AGAIN = { [1] = "(Daily)", [2] = "(Weekly)" }
local function label(id, name, level, frequency)
    local ok, text = pcall(function()
        if type(id) ~= "number" or id == 0 then
            return nil
        end
        seen.rows = seen.rows + 1
        -- (the game's level of the quest; 0 or no answer: the gossip's)
        local known, game = pcall(C_QuestLog.GetQuestDifficultyLevel, id)
        level = known and type(game) == "number" and game > 0 and game or level
        if type(level) ~= "number" or level <= 0 then
            return nil
        end
        seen.levels = seen.levels + 1
        local fine, elite = pcall(C_QuestLog.IsEliteQuest, id)
        local prefix = "[" .. level .. (fine and elite and "+" or "") .. "]"
        -- (the colour and the kind each on their own: a fault in one keeps the level)
        pcall(function()
            if C_CVar.GetCVarBool("showQuestDifficultyColor") then
                local color = GetDifficultyColor(C_PlayerInfo.GetContentDifficultyQuestForPlayer(id))
                prefix = hex(color.r, color.g, color.b) .. prefix .. "|r"
            end
        end)
        local tag
        fine, tag = pcall(function() return QuestUtilsOverrides.GetQuestTagText(id) end)
        tag = fine and type(tag) == "string" and tag ~= "" and tag or nil
        if tag then
            seen.tags[tag] = (seen.tags[tag] or 0) + 1
        end
        return prefix .. " " .. name .. (tag and " " .. tag or "") .. (AGAIN[frequency] and " " .. AGAIN[frequency] or "")
    end)
    return ok and text or nil
end

-- One line for the log, once a session, after the first list with a quest in it.
local told = false
local function tell()
    if told or seen.rows == 0 then
        return
    end
    told = true
    local tags = {}
    for tag, count in pairs(seen.tags) do
        tags[#tags + 1] = tag .. " " .. count
    end
    table.sort(tags)
    ns.Log.Add("dialogue", "quest rows with a level: " .. seen.levels .. " of " .. seen.rows .. "; tags: " .. (tags[1] and table.concat(tags, ", ") or "none"))
end

-- A gossip: the NPC's words and the rows in the order of the game's own window: the quests it
-- offers, the quests to hand in, then the choices by their place (GossipFrameShared.lua 255 to
-- 282). A row: text, act and id (the step that takes it), dim (a quest far under the player's
-- level), off (a choice that cannot be taken), ready (a quest that can be handed in now), and
-- for its small picture icon or quest. head: the row as the view shows it (a quest's level and
-- kind, a grey choice's reason). unit is the speaker (nil for none). auto is the lone choice that
-- the game's own window takes at once, with no window (191 to 199). full: the quest log has no room.
function Adapter.DialogueGossip()
    local data = { text = "", rows = {}, unit = speaker(), full = logFull() }
    local ok, err = pcall(function()
        data.text = C_GossipInfo.GetText() or ""
        local function quests(list, act)
            for _, quest in ipairs(list or {}) do
                data.rows[#data.rows + 1] = { act = act, id = quest.questID, text = quest.title or "", quest = quest,
                    head = label(quest.questID, quest.title or "", quest.questLevel, quest.frequency),
                    dim = (quest.isTrivial or quest.isIgnored) and true or false, ready = act == "gossipActive" and quest.isComplete and true or nil }
            end
        end
        quests(C_GossipInfo.GetAvailableQuests(), "gossipOffer")
        quests(C_GossipInfo.GetActiveQuests(), "gossipActive")
        local options = C_GossipInfo.GetOptions() or {}
        table.sort(options, function(a, b) return (a.orderIndex or 0) < (b.orderIndex or 0) end)
        if #data.rows == 0 and #options == 1 and options[1].selectOptionWhenOnlyOption and not C_GossipInfo.ForceGossip() then
            data.auto = options[1].orderIndex
        end
        for _, option in ipairs(options) do
            -- (the game's number for a choice that can be taken is 0; a grey one can say why, GossipInfoDocumentation.lua 379)
            local off, why = (option.status or 0) ~= 0, option.failureDescription
            data.rows[#data.rows + 1] = { act = "option", id = option.orderIndex, text = option.name or "",
                head = off and type(why) == "string" and why ~= "" and (option.name or "") .. " " .. hex(ns.Theme.Color("muted")) .. "(" .. why .. ")|r" or nil,
                icon = option.overrideIconID or option.icon, off = off }
        end
    end)
    tell()
    return data, ok and "" or tostring(err)
end

-- The quest list of an NPC with no gossip, in the order of the game's own window: the quests to
-- hand in, then the quests it offers (QuestFrame.lua 333 to 420). The rows are as in a gossip.
function Adapter.DialogueGreeting()
    local data = { text = "", rows = {}, unit = speaker(), full = logFull() }
    local ok, err = pcall(function()
        data.text = GetGreetingText() or ""
        for i = 1, GetNumActiveQuests() do
            local title, complete = GetActiveTitle(i)
            data.rows[#data.rows + 1] = { act = "greetActive", id = i, text = title or "", quest = { isComplete = complete }, ready = complete and true or nil,
                head = GetActiveQuestID and label(GetActiveQuestID(i), title or "") or nil,
                dim = IsActiveQuestTrivial and IsActiveQuestTrivial(i) and true or false }
        end
        for i = 1, GetNumAvailableQuests() do
            local trivial, frequency, repeatable, legendary, quest
            if GetAvailableQuestInfo then
                trivial, frequency, repeatable, legendary, quest = GetAvailableQuestInfo(i)
            end
            local title = GetAvailableTitle(i) or ""
            data.rows[#data.rows + 1] = { act = "greetOffer", id = i, text = title, dim = trivial and true or false, head = label(quest, title, nil, frequency),
                quest = { frequency = frequency, repeatable = repeatable, isLegendary = legendary } }
        end
    end)
    tell()
    return data, ok and "" or tostring(err)
end

-- The items of one kind ("reward": for sure, "choice", "required"): { kind, index, name, icon,
-- count, quality, id, link, unusable }. unusable: the character cannot use the item (the game's
-- own window tints it red: Mainline/QuestInfo.lua 553 to 557); not said of an item the game has
-- not loaded yet. An item that the game hides from the list of needed items is left out.
local function items(kind, count)
    local list = {}
    for index = 1, count or 0 do
        if not (kind == "required" and IsQuestItemHidden and (IsQuestItemHidden(index) or 0) ~= 0) then
            local name, icon, amount, quality, usable, id = GetQuestItemInfo(kind, index)
            list[#list + 1] = { kind = kind, index = index, name = name or "", icon = icon, count = amount or 1,
                quality = quality or 1, id = id, link = GetQuestItemLink(kind, index), unusable = (name or "") ~= "" and not usable or nil }
        end
    end
    return list
end

-- Rewards that are no item, no money and no experience, each as a few words.
local function others(list)
    local honor = GetRewardHonor and GetRewardHonor() or 0
    if honor > 0 then
        list[#list + 1] = honor .. " honor"
    end
    if GetRewardSkillPoints then
        -- (the skill's name, its picture, the points)
        local skill, _, points = GetRewardSkillPoints()
        if skill and (points or 0) > 0 then
            list[#list + 1] = "+" .. points .. " " .. skill
        end
    end
    local title = GetRewardTitle and GetRewardTitle()
    if title and title ~= "" then
        list[#list + 1] = title
    end
    for _, spell in ipairs(C_QuestInfoSystem.GetQuestRewardSpells(GetQuestID()) or {}) do
        local info = C_QuestInfoSystem.GetQuestRewardSpellInfo(GetQuestID(), spell)
        if info and info.name then
            list[#list + 1] = info.name
        end
    end
end

-- The objectives of a quest that is in the quest log: { text, have, need, done }. The game's
-- notes have the call and its answer (QuestLogDocumentation.lua 477 and 1581 to 1590). Empty
-- for a quest that is not in the log, and on a game build without the call.
local function goals(quest)
    local list = {}
    for _, goal in ipairs(results().questGoals and C_QuestLog.GetQuestObjectives(quest) or {}) do
        list[#list + 1] = { text = goal.text or "", have = goal.numFulfilled, need = goal.numRequired, done = goal.finished }
    end
    return list
end

-- A quest at one of its three windows. kind is "offer", "progress" or "handin". The fields are
-- the ones Screen/DialogueModel.lua names. more: rewards that are no item, as short texts.
-- confirm: "pvp" or "money" when the game asks before the last step (QuestFrame.lua 151 to 170
-- and 636 to 646); ask is the game's own question for it. head: the title with the level and the
-- kind. At an offer: full (the quest log has no room), size (the suggested group size, 0 for
-- none), group (its words), party (the player is in a group).
function Adapter.DialogueQuest(kind)
    local data = { title = "", text = "", fixed = {}, choices = {}, needed = {}, more = {}, unit = speaker(), money = 0, xp = 0, size = 0 }
    local ok, err = pcall(function()
        data.title, data.id = GetTitleText() or "", GetQuestID()
        data.head = label(data.id, data.title)
        local cost = GetQuestMoneyToGet() or 0
        if kind == "offer" then
            data.text, data.objectives = GetQuestText() or "", GetObjectiveText() or ""
            data.auto = QuestGetAutoAccept and QuestGetAutoAccept() and true or false
            data.full = logFull()
            -- a gray quest, far under the player's level (the game's map asks the same of an offer:
            -- Blizzard_SharedMapDataProviders/QuestOfferDataProvider.lua 156)
            local fine, trivial = pcall(C_QuestLog.IsQuestTrivial, data.id)
            data.trivial = fine and trivial == true
            -- the suggested group size, in the game's own words (QuestInfo.lua 362 to 376)
            local fine, size = pcall(function()
                return tonumber(GetSuggestedGroupSize()) or 0
            end)
            data.size = fine and size or 0
            fine, data.group = pcall(function()
                return data.size > 0 and QUEST_SUGGESTED_GROUP_NUM:format(data.size) or nil
            end)
            data.group = fine and data.group or nil
            fine, data.party = pcall(IsInGroup)
            data.party = fine and data.party and true or false
            if QuestFlagsPVP and QuestFlagsPVP() then
                data.confirm, data.ask = "pvp", CONFIRM_ACCEPT_PVP_QUEST
            end
        elseif kind == "progress" then
            data.text, data.needMoney, data.coins = GetProgressText() or "", cost, Adapter.CoinText(cost)
            data.completable = IsQuestCompletable() and true or false
            local ok, list = pcall(goals, data.id)
            data.goals = ok and list or {}
            data.needed = items("required", GetNumQuestItems())
            for _, item in ipairs(data.needed) do
                item.have = item.id and C_Item.GetItemCount(item.id) or 0
            end
        else
            data.text = GetRewardText() or ""
            if cost > 0 then
                data.confirm, data.ask = "money", (CONFIRM_COMPLETE_EXPENSIVE_QUEST or "") .. "\n" .. Adapter.CoinText(cost)
            end
        end
        -- the game's own window hides the rewards of some quests until the hand-in (QuestInfo.lua 645)
        local hidden = kind == "offer" and C_QuestLog and C_QuestLog.ShouldShowQuestRewards and not C_QuestLog.ShouldShowQuestRewards(data.id)
        if kind ~= "progress" and not hidden then
            data.money, data.xp = GetRewardMoney() or 0, GetRewardXP() or 0
            data.fixed, data.choices = items("reward", GetNumQuestRewards()), items("choice", GetNumQuestChoices())
            pcall(others, data.more)
        end
    end)
    return data, ok and "" or tostring(err)
end

-- The kinds of quest offer for which the game's own window does not show (QuestFrame.lua 39 to
-- 60). nil for a plain offer.
--   "map"     a quest from the adventure map: the map has its own window for it.
--   "item"    a quest that a looted item starts. The game's window puts a notice into the quest
--             tracker for it (through the tracker's own code: QuestFrame.lua 47 to 52,
--             Blizzard_ObjectiveTracker/Blizzard_AutoQuestPopUpTracker.lua 34 to 40) and closes
--             the offer. The view shows the offer itself.
--   "notice"  a quest that the game took by itself at a place: the same.
function Adapter.DialogueSpecial(startItem)
    local ok, what = pcall(function()
        if QuestIsFromAdventureMap and QuestIsFromAdventureMap() then
            return "map"
        elseif startItem ~= nil and startItem ~= 0 then
            return "item"
        elseif QuestGetAutoAccept and QuestGetAutoAccept() and QuestIsFromAreaTrigger and QuestIsFromAreaTrigger() then
            return "notice"
        end
    end)
    return ok and what or nil
end

-- ---------------------------------------------------------------- the steps of a talk

local STEPS = {
    option = function(place) C_GossipInfo.SelectOptionByIndex(place) end,
    gossipOffer = function(quest) C_GossipInfo.SelectAvailableQuest(quest) end,
    gossipActive = function(quest) C_GossipInfo.SelectActiveQuest(quest) end,
    greetOffer = function(place) SelectAvailableQuest(place) end,
    greetActive = function(place) SelectActiveQuest(place) end,
    accept = function() AcceptQuest() end,
    ack = function() AcknowledgeAutoAcceptQuest() end,
    complete = function() CompleteQuest() end,
    reward = function(choice) GetQuestReward(choice) end,
    -- B, Escape, combat, a movie, a fault: the game is told that the gossip and the quest are both
    -- closed (a quest that came from a gossip can leave the gossip open); each does nothing when
    -- nothing is open
    leave = function()
        pcall(C_GossipInfo.CloseGossip)
        pcall(CloseQuest)
    end,
}

-- Makes a step of a talk, by the name Screen/DialogueModel.lua gives it. True when the call ran;
-- else false and the game's words. The module calls this from a timer or an event only.
function Adapter.DialogueDo(step, value)
    if not (results().dialogue and STEPS[step]) then
        return false, "no such step"
    end
    local ok, err = pcall(STEPS[step], value)
    return ok, ok and "" or tostring(err)
end
