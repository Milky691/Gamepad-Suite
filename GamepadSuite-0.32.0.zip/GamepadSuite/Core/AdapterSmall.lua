-- The adapter, the small parts of round 0.31 (pack P35): the experience and the zone for the info bar (Screen/InfoBar.lua), the
-- game's colour of a chat type for the chat keyboard's channel row (Screen/KeyboardDraw.lua), and the kind of the
-- auction house's window for Mouse Mode at the Auction House (Screen/PointerAuction.lua).
local _, ns = ...

local Adapter = ns.Adapter

-- The experience: now, the most of this level, the level, the top level the character can reach, true while
-- experience is turned off at an NPC, and true while the character is rested (GetXPExhaustion gives the rested
-- experience left, nil when none: PlayerScriptDocumentation.lua 1168). Global calls of the game (UnitDocumentation.lua 3474 and 3489,
-- PlayerScriptDocumentation.lua 613 and 1498), none of them hidden in a fight. The game's own experience bar shows by
-- GameRulesUtil.CanShowExperienceBar (Blizzard_StatusTrackingBar/Mainline/StatusTrackingManagerOverrides.lua 31), whose
-- top level is the lower of GetMaxPlayerLevel and the expansion's cap (Blizzard_SharedXML/GameRulesUtil.lua 133 to 139,
-- 192 to 197), and a rule of the game can turn it off: the same two are read here. Both only read.
function Adapter.Experience()
    local rules = type(GameRulesUtil) == "table" and GameRulesUtil or {}
    local okTop, top = pcall(rules.GetEffectiveMaxLevelForPlayer)
    local okShow, show = pcall(rules.CanShowExperienceBar)
    local okRest, rest = pcall(GetXPExhaustion)
    return UnitXP("player"), UnitXPMax("player"), UnitLevel("player"), okTop and top or GetMaxPlayerLevel(),
        IsXPUserDisabled() or (okShow and show == false), okRest and type(rest) == "number" and rest > 0
end

-- The zone and the place in it as the game names them, for the info bar: GetZoneText and GetSubZoneText (globals,
-- ZoneScriptDocumentation.lua 43 to 57, with no restriction). Either is nil when the game does not say.
function Adapter.ZoneText()
    local okZone, zone = pcall(GetZoneText)
    local okSub, sub = pcall(GetSubZoneText)
    return okZone and zone or nil, okSub and sub or nil
end

-- The game's colour of a chat type ("GUILD", "CHANNEL1"): r, g, b, or nothing where the game has none. First its
-- call (C_ChatInfo.GetColorForChatType, ChatInfoDocumentation.lua 224, which may give nil), then the table that its
-- chat frame fills with the player's chat colours (ChatTypeInfo, Mainline/ChatFrameOverrides.lua 145 to 151).
function Adapter.ChatColor(kind)
    local color = C_ChatInfo and C_ChatInfo.GetColorForChatType and C_ChatInfo.GetColorForChatType(kind)
    color = color or type(ChatTypeInfo) == "table" and ChatTypeInfo[kind]
    if type(color) == "table" and type(color.r) == "number" then
        return color.r, color.g, color.b
    end
end

-- True for the game's number of the interaction Auctioneer (21, PlayerInteractionManagerConstantsDocumentation.lua
-- 34): the game's own manager opens the auction window at it (Blizzard_AuctionHouseUI_Bootstrap.lua 28), before
-- AUCTION_HOUSE_SHOW.
function Adapter.AuctionKind(kind)
    local types = Enum and Enum.PlayerInteractionType or {}
    return kind == (types.Auctioneer or 21)
end
