-- The adapter, part for the binds page: the game's own job of a button where no bind of ours is.
-- The page shows it dim in place of "Empty", so the player sees that A still jumps
-- (Settings/BindsDraw.lua). The order is the one of the on-screen buttons (Screen/HudModel.lua
-- Game): the action in the game's own bar slot first, then the fixed job of a face button, then the
-- game command of the key.
local _, ns = ...

local Adapter = ns.Adapter

-- With no trigger held, the four face buttons of the game's bar have a fixed job where its slot is
-- empty (the numbers are the game's own, as in Screen/HudModel.lua FIXED): X interacts, Y
-- inspects, B stops a cast, A jumps.
local FIXED = { [5] = "INTERACTTARGET", [6] = "INSPECT", [7] = "STOPCASTING", [8] = "JUMP" }

local function plain(value)
    return not (issecretvalue ~= nil and issecretvalue(value)) and value or nil
end

-- The name of what a slot of the game's bar holds, or nil.
local function slotName(slot)
    local ok, name = pcall(function()
        local kind, id = GetActionInfo(slot)
        kind, id = plain(kind), plain(id)
        if kind == "spell" then
            return C_Spell.GetSpellName(id)
        elseif kind == "item" then
            return C_Item.GetItemNameByID(id)
        elseif kind == "macro" then
            return (GetMacroInfo(id))
        elseif kind == "flyout" then
            return (GetFlyoutInfo(id))
        end
        return C_ActionBar.GetActionText(slot)
    end)
    name = ok and plain(name) or nil
    return type(name) == "string" and name ~= "" and name or nil
end

-- What the game does with a pad button on a layer (1 no trigger, 2 LT, 3 RT, 4 LT + RT) when we
-- have no bind there: { kind = "slot" | "command", id = , name = , icon = }, or nil for nothing. On
-- a trigger layer only one of the game's eight bar buttons has a job of its own; LB + RB has none.
local told = { count = 0 }
function Adapter.GameJob(ourKey, layer)
    if layer > 4 then
        return nil
    end
    local slot = Adapter.NativeSlot(ourKey, layer)
    local job
    if slot then
        job = { kind = "slot", id = slot.id, name = slotName(slot.id), icon = Adapter.BindIcon(slot) }
    elseif layer == 1 then
        local command = FIXED[Adapter.NativeIndex(ourKey) or 0] or Adapter.KeyCommand(ourKey)
        local name = command and Adapter.CommandName(command)
        job = name and { kind = "command", id = command, name = name, icon = ns.Catalog.CommandIcon(command) } or nil
    end
    -- the log has what the game gave, one time for each button and layer and eight lines in a
    -- session at most, so one look at the binds page in the game proves the names
    local word = (layer > 1 and (layer .. " ") or "") .. ourKey
    if job and not told[word] and told.count < 8 then
        told[word], told.count = true, told.count + 1
        ns.Log.Add("binds", "game job on the binds page: " .. word .. " = " .. job.kind .. " " .. tostring(job.id) .. " " .. tostring(job.name))
    end
    -- a slot whose name the game has not loaded yet still shows: by its picture, with a plain name
    if job and not job.name then
        job.name = "The game's bar slot"
    end
    return job
end
