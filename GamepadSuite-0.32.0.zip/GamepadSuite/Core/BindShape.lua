-- The shape of the bind plan: what Core/BindPlan.lua needs to know from the settings and from
-- the game before it can plan the keys. Core/BindCore.lua asks for it each time the binds are
-- given to the game. Out of a fight only: it may hold a game setting.
local _, ns = ...

-- a spell's name as a chat command needs it, for a bind that is cast on the focus or on the unit under the pointer
ns.BindRules.CastName = ns.Adapter.SpellCastName
-- A spell is cast by the name the spellbook has for it, so that the game casts the version for the
-- form the player is in; a chosen lower rank keeps its number. What each spell got is kept, to see
-- a change when the player learns a spell or a rank.
local named = {}
ns.BindRules.BookName = function(id)
    named[id] = ns.Adapter.SpellBindName(id) or false
    return named[id] or nil
end
-- Stealth, Prowl and Shadowform: the game's word for the state, and the spell's name
ns.BindRules.Toggle = ns.Adapter.ToggleSpell
-- the game's own word of a chat command (SLASH_<word>1)
ns.BindRules.Word = ns.Adapter.SlashCommand
-- the pet bar slot of a pet command or ability; what each got is kept, to see a change of the pet bar
local petSlots = {}
ns.BindRules.PetSlot = function(id)
    petSlots[id] = ns.Adapter.PetSlot(id) or false
    return petSlots[id] or nil
end

-- Stealth, Prowl and Shadowform in a slot of the game's own bar where no bind of ours is: a button
-- of ours runs the slot's spell, so a second press ends it there too (BindRules.Action). They go in
-- the table of healer mode's game slots (Core/Wheels.lua HealSlots), which the plan reads the same
-- way. Gives the places as text, to see a change.
local function toggleSlots(gameSlots)
    local parts = {}
    for layer = 1, 4 do
        for ours in pairs(ns.Adapter.KEY) do
            local spell = not (gameSlots[layer] and gameSlots[layer][ours]) and ns.Adapter.NativeSpell(ours, layer)
            if spell and ns.Adapter.ToggleSpell(spell) then
                gameSlots[layer] = gameSlots[layer] or {}
                gameSlots[layer][ours] = { kind = "spell", id = spell }
                parts[#parts + 1] = layer .. ours
            end
        end
    end
    table.sort(parts)
    return table.concat(parts, " ")
end
-- The game's own bar button for each of its eight buttons on each trigger layer: its slot number,
-- run by a button of ours (Adapter.NativeAction says why), or a click on it for a slot of the game's
-- own fixed jobs or a spellbook pop-out. And the button that takes its place while the player is in
-- a form or a stance. Gives the two tables and their text, to see a change.
local function routes(keys)
    local native, nativeForm, parts = {}, {}, {}
    local function own(name)
        return name and (ns.Adapter.NativeAction(name) or ("CLICK " .. name .. ":LeftButton")) or nil
    end
    for layer = 2, 4 do
        native[layer], nativeForm[layer] = {}, {}
        for ours in pairs(keys) do
            native[layer][ours] = own(ns.Adapter.NativeButtonName(ours, layer))
            nativeForm[layer][ours] = own(ns.Adapter.NativeFormButtonName(ours, layer))
            parts[#parts + 1] = layer .. ours .. tostring(native[layer][ours]) .. tostring(nativeForm[layer][ours])
        end
    end
    table.sort(parts)
    return native, nativeForm, table.concat(parts, " ")
end

-- The buttons that take a bind: all but LT and RT, which are the layers.
local function padKeys()
    local keys = {}
    for ours, theirs in pairs(ns.Adapter.KEY) do
        if ours ~= "LT" and ours ~= "RT" then
            keys[ours] = theirs
        end
    end
    return keys
end

-- A slot of the game's bar changed (the game tells of each, one after the other): when such a spell
-- or a pop-out came or went, the binds are made again, as Core/Wheels.lua does for a friendly spell.
local toggled, routed, waiting = "", "", false
ns.On("ACTIONBAR_SLOT_CHANGED", "ToggleSlots", function()
    if not waiting then
        waiting = true
        C_Timer.After(0.2, function()
            waiting = false
            ns.Queue.Run("ToggleSlots", function()
                if toggleSlots({}) ~= toggled or select(3, routes(padKeys())) ~= routed then
                    ns.Send("wheels")
                end
            end)
        end)
    end
end)

-- The trigger layers and the triggers that hold them.
local HOLDER = { [2] = { "LT" }, [3] = { "RT" }, [4] = { "LT", "RT" } }

-- What the binds page offers is what the game gets: the same settings and the same form list.
function ns.BindShape()
    local get, keys = ns.Registry.Get, padKeys()
    petSlots = {}
    -- (the binds are built again: what is kept of the pad for "which button is held" is read anew)
    ns.Adapter.PadChanged()
    local forms = get("layers.forms_and_stances") ~= "Off" and ns.Adapter.Forms() or {}
    local holds = ns.BindRules.Holds(get("layers.hold_lb_rb_set"))
    -- LB + RB is heard through the LB button (Core/BindHolds.lua) while its row is on, so the
    -- on-screen buttons show the layer while LB + RB is held, also before it has a bind. Stick
    -- Zoom on LB + RB needs it too where LB or RB has a bind of the player's: the game's own two
    -- targeting buttons tell of LB + RB only while both have none. LB + RB is no mouse mode button.
    local chord = holds[5]
        or get("feel.stick_zoom") and (ns.BindAsk.Where("LB") ~= nil or ns.BindAsk.Where("RB") ~= nil) or false
    -- A bumper that the game makes Shift, Ctrl or Alt (LB is Ctrl at the game's start) sends no
    -- press of its own, so a bind on it would never run, nor would Dynamic Interact on it. While it
    -- has a bind of the player's, holds LB + RB or is the Dynamic Interact button, the game's
    -- setting for it is held at "none" for the session.
    local interact = get("combat.dynamic_interact")
    for _, button in ipairs({ "LB", "RB" }) do
        ns.Adapter.FreeButton(button, chord or interact == button or ns.BindAsk.Where(button) ~= nil)
    end
    -- Which modifier each trigger is, from the game's own settings. A layer with no bind in it
    -- changes nothing in the game.
    -- A trigger layer with a friendly spell of the game's own bar that healer mode opens a party
    -- wheel for is in use too: else its trigger is not watched, the game pages its own bar, and the
    -- spell casts with no wheel (the owner, 0.24.1: Flash Heal on RT + Y never opened its wheel).
    local needs, inUse, healSlots = {}, {}, ns.Wheels.HealSlots()
    local was = toggled
    toggled = toggleSlots(healSlots)
    if toggled ~= was and toggled ~= "" then
        ns.Log.Add("binds", "Stealth, Prowl or Shadowform in the game's own slots (layer and button): " .. toggled .. ". A second press ends it.")
    end
    for layer, buttons in pairs(HOLDER) do
        inUse[layer] = (ns.Binds.LayerInUse(layer) or healSlots[layer] ~= nil) or nil
        for _, button in ipairs(inUse[layer] and buttons or {}) do
            needs[button] = true
        end
    end
    -- A trigger is watched: it goes to a hold button of ours, and the pad tells while it is down,
    -- in the game's restricted code. A trigger that the game makes Shift, Ctrl or Alt (LT is Shift
    -- at the game's start) is held free of it first, while its layer has binds or Sticky Layers is
    -- on: with LT as Shift, a key held with it ran the plain bind (the owner, 0.23.0), and its Shift
    -- never reached the owner frame. With Sticky Layers on, a trigger is watched for a tap also when
    -- its layer has only the game's own actions. Where the game keeps the modifier, the trigger is
    -- not watched: its press is heard as the modifier (Core/BindHolds.lua MODIFIER), and a bound
    -- trigger stops sending it (ControllerForever RuleBar.lua 4981 to 4986).
    local sticky = get("layers.sticky_layers")
    for _, button in ipairs({ "LT", "RT" }) do
        ns.Adapter.FreeButton(button, sticky or needs[button] or false)
    end
    local mods = ns.Adapter.Modifiers()
    local watch = {}
    -- A trigger that is no modifier and is not watched lets the plain key's bind of ours take the
    -- press with it held, while the on-screen button shows the game's own slot of that layer (the
    -- owner, 0.25.1: Mind Blast on the game's RT bar, and RT + that button cast the plain bind). So it
    -- is watched also while any button has a bind of ours with no trigger: then its layer runs the
    -- game's own slot of each button with no bind of ours there (Core/BindPlan.lua, held layers).
    local plain = ns.Binds.LayerInUse(1)
    for _, button in ipairs({ "LT", "RT" }) do
        if not mods[button] and (sticky or needs[button] or plain) then
            watch[button] = ns.Adapter.PadIndex(button)
        end
    end
    -- the game's own bar buttons of the trigger layers (routes)
    local native, nativeForm
    native, nativeForm, routed = routes(keys)
    -- Sticky Layers: the places on the pad of the buttons that are no trigger. A trigger that is
    -- let go while one of them is down was held for that button: it is no tap.
    local pads = {}
    for ours in pairs(sticky and keys or {}) do
        pads[#pads + 1] = ns.Adapter.PadIndex(ours)
    end
    -- Press and Hold Casting: the game's own setting follows the row, for the session. It is the
    -- game that casts again while a key is held, and only for a press through one of its own bar
    -- slots: an addon's button cannot give the cast the word "a key is held"
    -- (Blizzard_FrameXML/SecureTemplates.xml 6 to 8). "Game buttons": a button with no bind of
    -- ours. "All spell binds": each spell bind has a slot of the game's keyboard bars
    -- (Core/HoldSlots.lua); such a slot must cast on the press, which alone carries that word
    -- (SecureTemplates.lua 806 to 818), so the game's setting for that is held on too.
    local mode = get("combat.press_and_hold")
    -- (a game with no such slots: the row does not offer All spell binds, and a saved one is Off)
    mode = (mode ~= ns.HoldRules.ALL or ns.HoldSlots.on) and mode or "Off"
    -- (Off, the only value while the row is in development: the game's own setting is the player's)
    if mode == "Off" then
        ns.Adapter.ReleaseSetting("ActionButtonUseKeyHeldSpell")
    else
        ns.Adapter.HoldSetting("ActionButtonUseKeyHeldSpell", "1")
    end
    if mode == ns.HoldRules.ALL then
        ns.Adapter.HoldSetting("ActionButtonUseKeyDown", "1")
    else
        ns.Adapter.ReleaseSetting("ActionButtonUseKeyDown")
    end
    -- A layer gets no slot command where that would go wrong. Sticky Layers: a command is no
    -- click, so the owner frame does not see the press and a tapped layer would stay on; the
    -- layers of the triggers keep our own buttons then. The game's Self Cast key: one of the
    -- game's bar buttons that is pressed with it down casts on the player, so a layer whose key
    -- name has that modifier keeps our own buttons.
    local noSlot, selfCast = {}, ns.Adapter.SelfCastModifier()
    for layer, buttons in pairs(HOLDER) do
        noSlot[layer] = sticky or nil
        for _, button in ipairs(buttons) do
            noSlot[layer] = noSlot[layer] or selfCast and mods[button] and selfCast:find(mods[button], 1, true) and true or nil
        end
    end
    -- The game's own Interact button: the fifth button of its bar, with no trigger. And the
    -- Interact button's two other jobs, as the hands are now (Core/Hands.lua).
    -- And the buttons whose own job in the game is Jump (A: its bar's Jump runs the game's Jump at
    -- the press and its let-go at the let-go, Blizzard_GamepadActionBars/MainActionBarFrame.lua
    -- 323 to 336). Such a key that gets a bind of ours while it is down keeps Jump until it is up.
    local gameInteract, jump = {}, {}
    for ours, theirs in pairs(keys) do
        gameInteract[ours] = ns.Adapter.NativeIndex(ours) == 5 or nil
        jump[theirs] = ns.Adapter.KeyCommand(ours) == "JUMP" and "JUMP" or nil
    end
    local hands = ns.Hands.on and ns.Hands or nil
    local heal, healFoe = ns.Wheels.Heal()
    return {
        gameInteract = gameInteract, jump = jump, pole = hands and hands.PoleDriver() or nil,
        jobs = hands and { attack = hands.AttackText(), fish = hands.FishingText() } or {},
        native = native, nativeForm = nativeForm, heal = heal, healFoe = healFoe, healSlots = healSlots,
        keys = keys, combat = get("layers.combat_set"), holds = holds, chord = chord, mods = mods, inUse = inUse,
        watch = watch, triggers = { LT = ns.Adapter.KEY.LT, RT = ns.Adapter.KEY.RT }, sticky = sticky, pads = pads, slots = ns.HoldSlots.on and ns.HoldSlots.Sync(noSlot) or {}, noSlot = noSlot,
        forms = forms, combatFirst = get("layers.forms_and_stances") == "Combat First",
        -- Targeting at Stick: hold LB or RB and push the right stick, whatever bind the bumper has (Core/BindHolds.lua)
        aim = get("combat.targeting") == "Stick" and ns.Adapter.StickTargeting() or nil,
        -- Healer Mode at Bumpers: the friendly bumper (Core/BindGroup.lua), in a party or a raid only: solo a hold could
        -- target only the player and the pet, and would move the bumper's bind from the press to the let-go
        group = get("combat.healer_mode") == "Bumpers" and ns.Adapter.InGroup() and ns.Adapter.FriendlyBumper() or nil,
        interact = interact ~= "Off" and interact or nil,
    }
end

-- Questions about the state in use. The bind core gives InteractButton to the other parts of the
-- addon as ns.BindCore.InteractButton.
local Ask = {}
ns.BindAsk = Ask

-- True when a spell of the binds is cast by another name or number now than the plan was given:
-- the player learned it, or learned a higher rank of it. Or a pet action of the binds is in
-- another slot of the pet bar now (a pet came, went, or its bar changed).
function Ask.NamesChanged()
    for id, name in pairs(named) do
        if (ns.Adapter.SpellBindName(id) or false) ~= name then
            return true
        end
    end
    for id, slot in pairs(petSlots) do
        if (ns.Adapter.PetSlot(id) or false) ~= slot then
            return true
        end
    end
    return false
end

-- Reach. The game sends no event when the player walks into reach of a thing it highlights already;
-- its own Interact picture has the same gap (it is drawn again on four events only,
-- Blizzard_GamepadActionBars/MainActionBarFrame.lua 419 to 426). So while Dynamic Interact or the
-- Interact button's other jobs need reach, the bind core holds the game's setting "highlight only
-- what is in reach" (Core/BindCore.lua push): then a new highlight is the game's word of reach, and
-- nothing is looked at on a timer. Only a far highlight goes: the game's own Interact passes over a
-- thing out of reach at the press anyway (MainActionBarFrame.lua 190 to 208).

-- The buttons whose key interacts now, for the log: "RB, X", or "none".
function Ask.Interacting()
    local list = {}
    for ours, theirs in pairs(ns.Adapter.KEY) do
        if ns.Adapter.EffectiveBinding(theirs) == ns.BindRules.INTERACT then
            list[#list + 1] = ours
        end
    end
    table.sort(list)
    return #list > 0 and table.concat(list, ", ") or "none"
end

-- Something came in reach, out of a fight (the bind core told the owner frame). The log has it one
-- time for a unit (an NPC, a corpse) and one time for a thing that is no unit (a mailbox, a herb):
-- the buttons that interact now, and what the owner frame's own rule gives, the one rule it has in
-- a fight (Core/BindSecure.lua). It sees units only, so for a thing it should give 0.
local reachTold = {}
function Ask.NoteReach()
    local seen = ns.Adapter.Highlight()
    local kind = seen.unit and "a unit" or "a thing that is no unit"
    if seen.name and not reachTold[kind] then
        reachTold[kind] = true
        ns.Log.Add("interact", seen.name .. " is in reach (" .. kind .. "): the buttons that interact now: " .. Ask.Interacting()
            .. "; the rule [@softinteract,exists] gives " .. seen.rule)
    end
end

-- Where a button has a bind of the player's that can come in use: on a layer and in a set that
-- the settings have on. Gives the layer and the set of the first one, or nil. A bind whose id
-- is in skip does not count.
function Ask.Where(ourKey, skip)
    local get = ns.Registry.Get
    local layers = { true, true, true, true, get("layers.hold_lb_rb_set") }
    for _, state in ipairs(ns.BindRules.States(get("layers.forms_and_stances") ~= "Off" and ns.Adapter.Forms() or {}, get("layers.combat_set"), get("layers.forms_and_stances") == "Combat First")) do
        for layer = 1, 5 do
            local bind, set = ns.BindRules.Find(ns.Binds.Get, state, layer, ourKey)
            if layers[layer] and bind and not (skip and skip[bind.id]) then
                return layer, set
            end
        end
    end
end

-- The bumper that holds the group now (Healer Mode at Bumpers, in a group: Core/BindGroup.lua), "LB" or "RB", or nil.
function Ask.GroupBumper()
    local group = ns.BindCore.plan and ns.BindCore.plan.group
    return group and group.who:upper() or nil
end

-- The button that interacts now, by our key name, for the state the player is in. nil when
-- Dynamic Interact is off, nothing is in reach, or the Combat set has its own bind for the
-- button and is in use; nil too on the bumper that holds the group (its hold wins, decision 137).
-- With always, "in reach" is not asked. For the on-screen buttons.
function Ask.InteractButton(state, always)
    local ours = ns.Registry.Get("combat.dynamic_interact")
    if ours == "Off" or ours == Ask.GroupBumper() or not (always or ns.Adapter.InteractNear()) then
        return nil
    end
    local _, set = ns.BindRules.Find(ns.Binds.Get, state, 1, ours)
    return set ~= "combat" and ours or nil
end

-- The game's own Focus UI ran, so View had no bind of ours at that press. With no window open
-- the game then says "No interface frame to focus". The log tells which set was in use and what
-- the key had, five lines at most. The player is told when View does have a bind, but only in a
-- set that is not in use now (the Combat set out of a fight, a form's set out of the form): once
-- for the character (Core/BindCheck.lua Tell). header is the bind core's owner frame.
local focusLines, focusTold = 0, false
function Ask.FocusRan(header)
    local key = ns.Adapter.KEY.VW
    if not (header and ns.BindCore.plan and key) then
        return
    end
    local ours = header:GetAttribute("set:" .. key)
    if focusLines < 5 then
        focusLines = focusLines + 1
        ns.Log.Add("binds", "the game's Focus UI ran: state " .. tostring(header:GetAttribute("state-binds")) .. ", our bind for " .. key .. " is "
            .. tostring(ours) .. ", the key reads " .. tostring(ns.Adapter.EffectiveBinding(key))
            .. (ns.Pad.Gameplay() and "" or ", a window has the controller") .. (ns.Adapter.InCombat() and ", in a fight" or ""))
    end
    if not ours and not focusTold and ns.Pad.Gameplay() and select(2, ns.Adapter.WindowFocus()) == 0 then
        ns.Binds.Each(function(bind, _, layer, button)
            focusTold = focusTold or (button == "VW" and layer == 1 and not bind.empty)
        end)
        if focusTold then
            ns.BindCheck.Tell("view", "View did the game's own job: your bind for View is in Combat Binds or Form and Stance Binds, and those work only in combat or in that form.")
        end
    end
end
