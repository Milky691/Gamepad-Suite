-- The adapter, part 8: what profiles ask the game (Core/Profiles.lua): who the character is, a
-- table as one line of text and back, an item by its number, the day.
local _, ns = ...

local Adapter = ns.Adapter

-- a table as one line of text, for a profile another player can paste
Adapter.Check("profileText", function()
    local coder = C_EncodingUtil
    return coder and coder.SerializeCBOR and coder.DeserializeCBOR and coder.CompressString and coder.DecompressString
        and coder.EncodeBase64 and coder.DecodeBase64 ~= nil
end)
local results = Adapter.Results

-- Two talent groups, for a build that follows one (Core/Builds.lua). The game's own talent frame of
-- this game type asks these two (Blizzard_PlayerSpells/Camelot/ClassTalents/Blizzard_ClassTalentsFrame.lua
-- 100 to 108). The old GetActiveTalentGroup is not here: its file does not load for this game type.
Adapter.Check("talentGroups", function()
    return C_SpecializationInfo ~= nil and C_SpecializationInfo.GetActiveSpecGroup ~= nil and GetNumSpecGroups ~= nil
end)

-- How many talent groups the character has, and the one in use; nil for what the game does not tell.
function Adapter.TalentGroups()
    local ok, count = pcall(GetNumSpecGroups)
    local okActive, active = pcall(C_SpecializationInfo.GetActiveSpecGroup)
    return ok and count or nil, okActive and active or nil
end

-- fn(now, before) when the player changes talent group (SpecializationInfoDocumentation.lua 445 to 453).
function Adapter.OnTalentGroup(fn)
    ns.On("ACTIVE_TALENT_GROUP_CHANGED", "Builds", fn)
end

-- This character: { key = "Name-Realm", name =, realm =, class = "MAGE" }.
function Adapter.Character()
    local name, realm = UnitFullName("player")
    if not realm or realm == "" then
        realm = GetNormalizedRealmName and GetNormalizedRealmName() or ""
    end
    return { key = name .. "-" .. realm, name = name, realm = realm, class = Adapter.Class() }
end

-- A class as the game shows it to the player ("Mage"). nil for a word that is no class here.
function Adapter.ClassName(class)
    local names = LOCALIZED_CLASS_NAMES_MALE
    local name = type(names) == "table" and names[class]
    return type(name) == "string" and name or nil
end

function Adapter.SpellName(id)
    local ok, name = pcall(C_Spell.GetSpellName, id)
    return ok and name or nil
end

-- A bind of an item by its number, when the game has such an item. The name can come a moment
-- later from the game; until then the bind has a plain one.
function Adapter.ItemBind(id)
    local ok, found, _, _, _, icon = pcall(C_Item.GetItemInfoInstant, id)
    if not (ok and found) then
        return nil
    end
    return { kind = "item", id = id, name = C_Item.GetItemNameByID(id) or ("Item " .. id), icon = icon }
end

-- A table of plain values as one line of letters and numbers, and back. nil when the game
-- cannot, when the text is no such line, or when it unpacks to more than most bytes.
function Adapter.Pack(value)
    local ok, text = pcall(function()
        local coder = C_EncodingUtil
        return coder.EncodeBase64(coder.CompressString(coder.SerializeCBOR(value)))
    end)
    return results().profileText and ok and type(text) == "string" and text or nil
end

function Adapter.Unpack(text, most)
    local ok, value = pcall(function()
        local coder = C_EncodingUtil
        local raw = coder.DecompressString(coder.DecodeBase64(text))
        return #raw <= most and coder.DeserializeCBOR(raw) or nil
    end)
    return results().profileText and ok and type(value) == "table" and value or nil
end

-- Now, as the game counts time, and a day of it as a short text: "Oct 3".
function Adapter.Today()
    return time()
end

function Adapter.DayText(when)
    local ok, text = pcall(date, "%b %d", when)
    return ok and type(text) == "string" and (text:gsub(" 0", " ")) or ""
end
