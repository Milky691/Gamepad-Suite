-- The adapter, the part for the back buttons (L4, L5, R4, R5). The game names a pad's back buttons
-- PADPADDLE1 to 4, but Steam Input sends a Steam Deck's grips as the keyboard keys the player gives
-- them there (F13 to F16 is usual), and other pads' back buttons go through their own apps the same
-- way. So a back button with no learned key answers to both: its PADPADDLE key and its Steam key.
-- A back button can also learn the key it sends: a press of it on the page Back Buttons
-- (Settings/Data.lua), and then it answers to that key only. EasyController (Paddles.lua 7 to 10) and
-- ControllerForever (Menu 8950 to 8973) learn them in the same way. Kept for the account: one device
-- for every character.
local _, ns = ...

local Adapter = ns.Adapter

local PADDLE = { L4 = "PADPADDLE2", L5 = "PADPADDLE4", R4 = "PADPADDLE1", R5 = "PADPADDLE3" }
-- Steam Input's usual keys for the grips: ControllerForever's own Deck guide (ControllerForever_Shoulders.lua 11784 to
-- 11785: "set L4, R4, L5, R5 to the keyboard keys F13, F14, F15, F16") and EasyController (Paddles.lua 7 to 10).
local STEAM = { L4 = "F13", R4 = "F14", L5 = "F15", R5 = "F16" }
local learning -- the back button that waits for its press
local told, said = {}, nil -- the Steam keys whose game bind the log named; the last line of the keys

-- The game's key of each back button that answers to its Steam key too -> that key: { PADPADDLE2 = "F13" }.
-- The bind core sets every key name of such a back button for both keys (Core/BindCore.lua).
Adapter.TWIN = {}

local function use(ours, key)
    Adapter.NAME[Adapter.KEY[ours]] = nil
    Adapter.KEY[ours], Adapter.NAME[key] = key, ours
end

-- At load, before any bind is given to the game: the keys the back buttons learned before.
function Adapter.LoadGrips()
    GamepadSuiteDB.grips = GamepadSuiteDB.grips or {}
    for ours, key in pairs(GamepadSuiteDB.grips) do
        if PADDLE[ours] and type(key) == "string" then
            use(ours, key)
        end
    end
end

-- The keys each back button answers to, worked out again: before the binds are given to the game, and
-- after a key is learned. A back button with no learned key answers to its Steam key too, unless another
-- back button learned that key, or the player has a key bind of the game's own on it (the game's Key
-- Bindings window; no override counts, so not ours and not another addon's). Blizzard reads the
-- player's bind of a pressed key the same way (Blizzard_FrameXML/Mainline/CoinPickupFrame.lua 181).
-- Adapter.NAME names the back button by both keys. Gives Adapter.TWIN, and true when the answer is
-- another one than the last time: one log line says it then.
function Adapter.GripKeys()
    for ours, steam in pairs(STEAM) do
        if Adapter.NAME[steam] == ours and Adapter.KEY[ours] ~= steam then
            Adapter.NAME[steam] = nil
        end
    end
    local twin, parts = {}, {}
    for ours, paddle in pairs(PADDLE) do
        local steam = STEAM[ours]
        if Adapter.KEY[ours] == paddle and not Adapter.NAME[steam] then
            local ok, game = pcall(GetBindingAction, steam)
            if not (ok and type(game) == "string" and game ~= "") then
                twin[paddle], Adapter.NAME[steam] = steam, ours
            elseif not told[steam] then
                told[steam] = true
                ns.Log.Add("binds", steam .. " has your own game key bind " .. game .. ", so " .. ours .. " does not answer to it")
            end
        end
        parts[#parts + 1] = ours .. " " .. Adapter.KEY[ours] .. (twin[paddle] and " " .. twin[paddle] or "")
    end
    table.sort(parts)
    local line = "the back buttons answer to: " .. table.concat(parts, ", ")
    Adapter.TWIN = twin
    if line == said then
        return twin, false
    end
    said = line
    ns.Log.Add("binds", line)
    return twin, true
end

-- A key bind of the game's own changed: the player's Key Bindings window, or the game's binds that load
-- after the login (ConsolePort waits for them the same way, Controller/Bindings.lua 113). The Steam keys
-- are looked at again one frame after a burst (ControllerForever RuleBar.lua 10490 to 10496 merges this
-- event the same way), out of a fight, once the binds were given: the game tells of every key our own
-- code sets too, and for those the answer is the same, so nothing more runs.
local waiting = false
ns.On("UPDATE_BINDINGS", "Grips", function()
    if waiting or not ns.BindCore.plan or Adapter.InCombat() then
        return
    end
    waiting = true
    C_Timer.After(0, function()
        waiting = false
        if select(2, Adapter.GripKeys()) then
            ns.BindCore.Rebuild()
        end
    end)
end)

-- What the page shows for a back button: the keys it answers to, or that it waits for a press.
function Adapter.GripText(ours)
    if learning == ours then
        return "Press it now"
    end
    local key = Adapter.KEY[ours]
    if key ~= PADDLE[ours] then
        return key
    end
    return Adapter.TWIN[key] and ("Back button or " .. Adapter.TWIN[key]) or "Back button"
end

-- A back button waits for its press. A back button of the pad or a key F1 to F24 that no other
-- button sends is learned; any other press (B among them) ends the wait and changes nothing. A key
-- that is only another back button's Steam key is free: that one lets go of it. The binds are given
-- to the game again. done() is told after, with true when a key was learned.
function Adapter.LearnGrip(ours, done)
    learning = ours
    ns.SettingsInput.Capture(function(key)
        learning = nil
        local other = Adapter.NAME[key]
        other = Adapter.KEY[other or ""] == key and other or nil
        local fits = (key:match("^PADPADDLE%d$") or key:match("^F%d%d?$")) and (other == nil or other == ours)
        if fits then
            GamepadSuiteDB.grips[ours] = key ~= PADDLE[ours] and key or nil
            use(ours, key)
            ns.Log.Add("binds", "the back button " .. ours .. " sends " .. key)
            Adapter.GripKeys()
            ns.BindCore.Rebuild()
        end
        done(fits and true or false)
        return true
    end)
end
