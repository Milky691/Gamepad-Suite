-- The rules of profiles, with no game calls. A profile is the binds and the wheels of one
-- character, and in a text from another player the settings too:
--   { name =, class =, binds = { set = { layer = { key = bind } } },
--     wheels = { next =, list = { { id =, name =, slots = { place = bind } } } },
--     slots = { [1 to 8] = bind } (the fixed slots), settings = { key = value } }
-- A profile comes from another character of the account, from a copy the player saved, or from a
-- text another player made. Nothing in it is used as it is. The character that takes a profile
-- makes every bind again from its kind and its number or name (Rules.Fit), out of its own lists.
-- So a bind the character cannot use is left out, and a text that is not what it says leaves
-- nothing behind: no chat command text and no picture path comes from a profile.
local _, ns = ...

local Rules = {}

Rules.TAG = "GPS1:"        -- the start of a profile text; the number is the version of its form
Rules.TEXT_MOST = 20000    -- a longer text is not read
Rules.RAW_MOST = 400000    -- nor one that unpacks to more than this
Rules.COPIES = 12          -- saved copies and profiles from texts, together
-- Settings that are the player's own: what the controller is, and where the settings window
-- sits on that screen. They do not come over with a text.
Rules.NOT_SHARED = {
    ["system.controller"] = true, ["screen.button_symbols"] = true, ["window.scale"] = true, ["window.x"] = true, ["window.y"] = true,
    ["slots.move"] = true, -- which fixed slot the position rows move now
    ["combat.press_and_hold"] = true, -- one of its values writes to the game's bars: each player picks it by hand
}

local LAYERS, PLACES, SLOTS = 5, 8, 8

-- Text from a profile, for the screen: no "|" (the game reads it as the start of a color or a
-- picture), no line break, no space at its ends, and no longer than most. nil when nothing is left.
-- Limit: the cut counts bytes, so a name longer than most can end in half a letter.
local function clean(text, most)
    if type(text) ~= "string" then
        return nil
    end
    text = text:gsub("[|%c]", "")
    text = text:gsub("^%s+", "")
    text = text:gsub("%s+$", "")
    text = text:sub(1, most)
    return text ~= "" and text or nil
end
Rules.Clean = clean

-- A copy of a table of plain values, so that a saved copy does not change with the binds in use.
local function copy(value)
    if type(value) ~= "table" then
        return value
    end
    local out = {}
    for key, inner in pairs(value) do
        out[key] = copy(inner)
    end
    return out
end
Rules.Copy = copy

-- A table that came through a text can have its numbers as text.
local function at(list, index)
    return list[index] or list[tostring(index)]
end

-- The kinds of bind that the character's own bind list answers for.
local LISTED = { command = true, slash = true, emote = true, macro = true, pet = true, fishingpole = true }
-- who a spell or an item can be cast on, other than the target (Core/BindRules.lua)
local ON = { player = true, focus = true, mouseover = true }

-- One bind of a profile as this character can use it, or nil. wheels has the names of the
-- profile's own wheels that came over; with none given the bind is for a wheel's slot, and a wheel
-- cannot hold a wheel. same: the profile is from a character of this account with the same class.
-- slots has the fixed slots that came over: a button with a fixed slot as its bind comes over
-- with the slot; with none given the bind is for a slot itself, and a slot cannot hold a slot.
local function fit(bind, me, wheels, same, slots)
    if type(bind) ~= "table" then
        return nil
    end
    local kind, id = bind.kind, bind.id
    -- the bind Quest Item of builds before 0.22.0 is the Quest Item Wheel now
    if kind == "questitem" then
        kind, id = "wheel", "quest"
    end
    if kind == "fixed" then
        return slots and type(id) == "number" and slots[id] and { kind = kind, id = id, name = "Slot " .. id, detail = slots[id].name or "" } or nil
    elseif kind == "spell" or kind == "item" then
        local made = type(id) == "number" and me[kind](id) or nil
        -- who it is cast on comes over with it
        if made and ON[bind.on] then
            made.on = bind.on
        end
        return made
    elseif kind == "wheel" then
        if not wheels or type(id) ~= "string" then
            return nil
        elseif id:find("^my%d+$") then
            return wheels[id] and { kind = "wheel", id = id, name = wheels[id], detail = "" } or nil
        end
        return me.listed(kind, id)
    elseif LISTED[kind] and (type(id) == "string" or type(id) == "number") then
        local made = me.listed(kind, id)
        -- the pet's list is empty while no pet is out: the player's own pet bind is kept as it is
        if not made and kind == "pet" and same then
            made = { kind = kind, id = id, name = clean(bind.name, 60), icon = bind.icon, detail = clean(bind.detail, 60) }
        end
        return made
    end
end

-- The profile as the character `me` can use it, and a count of it.
-- me = { class =, keys = { our key name = true }, forms = { set name = true }, most = wheels a character can have,
--        spell(id): a bind of that spell, or of the spell with the same name, when the character knows it,
--        item(id): a bind of that item, when the game has it,
--        listed(kind, id): the bind from the character's own bind list (a game command, a chat command,
--                          an emote, a macro, a pet action, a wheel every character has, Fishing Pole),
--        runs(command): true when a wheel can run that game command,
--        setting(key, value): true when the addon has that setting and it can take that value,
--        spellName(id): the game's name of a spell by its number (optional) }
-- Gives { binds =, wheels = { next =, list = }, slots =, settings = } and
--       { binds = how many come over (the actions of fixed slots count), wheels = how many, cut = how many binds are left out,
--         lost = { { set, layer, key, spell name } }: each button of a set that comes over that lost a spell (a marker
--         on the Binds page says where it was: Core/BuildRules.lua),
--         wheelsCut = { { name, count, all = true when none was left: the wheel does not come over } },
--         slotsCut = { the numbers of the fixed slots left empty } }.
function Rules.Fit(profile, me)
    local out = { binds = {}, wheels = { next = 1, list = {} }, slots = {}, settings = {} }
    local report = { binds = 0, wheels = 0, cut = 0, lost = {}, wheelsCut = {}, slotsCut = {} }
    if type(profile) ~= "table" then
        return out, report
    end
    local same = profile.own == true and profile.class == me.class
    -- the wheels first: a bind that opens a wheel comes over only with its wheel
    local names = {}
    local list = type(profile.wheels) == "table" and type(profile.wheels.list) == "table" and profile.wheels.list or {}
    for index = 1, me.most do
        local wheel = at(list, index)
        local number = type(wheel) == "table" and type(wheel.id) == "string" and tonumber(wheel.id:match("^my(%d+)$"))
        if number and not names[wheel.id] and type(wheel.slots) == "table" then
            local slots, count, cut = {}, 0, 0
            for place = 1, PLACES do
                local raw = at(wheel.slots, place)
                local bind = fit(raw, me, nil, same)
                if bind and (bind.kind ~= "command" or me.runs(bind.id)) then
                    slots[place], count = bind, count + 1
                elseif raw ~= nil then
                    cut = cut + 1
                end
            end
            report.cut = report.cut + cut
            local name = clean(wheel.name, 64)
            if cut > 0 then
                report.wheelsCut[#report.wheelsCut + 1] = { name = name or ("Wheel " .. number), count = cut, all = count == 0 or nil }
            end
            if count > 0 then
                out.wheels.list[#out.wheels.list + 1] = { id = wheel.id, name = name, slots = slots }
                out.wheels.next = math.max(out.wheels.next, number + 1)
                names[wheel.id] = name or ("Wheel " .. number)
            end
        end
    end
    report.wheels = #out.wheels.list
    -- the fixed slots, before the binds: a button with a slot as its bind comes over only with it
    -- (a profile of a build that had no fixed slots says nothing about them)
    if type(profile.slots) ~= "table" then
        out.slots = nil
    end
    for n = 1, out.slots and SLOTS or 0 do
        local raw = at(profile.slots, n)
        out.slots[n] = fit(raw, me, names, same)
        if out.slots[n] then
            report.binds = report.binds + 1
        elseif raw ~= nil then
            report.cut = report.cut + 1
            report.slotsCut[#report.slotsCut + 1] = n
        end
    end
    for set, layers in pairs(type(profile.binds) == "table" and profile.binds or {}) do
        -- a form's set comes over to a character that has the form, or to one of the same class
        local wanted = set == "normal" or set == "combat" or (type(set) == "string" and set:find("^form:%d+$") and (same or me.forms[set])) or false
        for layer = 1, type(layers) == "table" and LAYERS or 0 do
            local slots = at(layers, layer)
            for key, raw in pairs(type(slots) == "table" and slots or {}) do
                local empty = type(raw) == "table" and raw.empty
                local bind = wanted and me.keys[key] and (empty and { empty = true } or fit(raw, me, names, same, out.slots)) or nil
                if bind then
                    out.binds[set] = out.binds[set] or {}
                    out.binds[set][layer] = out.binds[set][layer] or {}
                    out.binds[set][layer][key] = bind
                    report.binds = report.binds + (empty and 0 or 1)
                elseif not empty then
                    report.cut = report.cut + 1
                    if wanted and me.keys[key] and type(raw) == "table" and raw.kind == "spell" then
                        local name = clean(raw.name, 60) or (me.spellName and type(raw.id) == "number" and clean(me.spellName(raw.id), 60)) or nil
                        report.lost[#report.lost + 1] = { set, layer, key, name }
                    end
                end
            end
        end
    end
    for key, value in pairs(type(profile.settings) == "table" and profile.settings or {}) do
        if type(key) == "string" and not Rules.NOT_SHARED[key] and me.setting(key, value) then
            out.settings[key] = value
        end
    end
    return out, report
end

-- How many binds and wheels a profile holds, as it is. A bind on the LB layer of an older build
-- (layer 6) does not count: no key reaches it, and Fit leaves it out without a word.
function Rules.Count(profile)
    local binds, wheels = 0, 0
    for _, layers in pairs(type(profile.binds) == "table" and profile.binds or {}) do
        for layer = 1, type(layers) == "table" and LAYERS or 0 do
            local slots = at(layers, layer)
            for _, bind in pairs(type(slots) == "table" and slots or {}) do
                binds = binds + ((type(bind) == "table" and not bind.empty) and 1 or 0)
            end
        end
    end
    local list = type(profile.wheels) == "table" and profile.wheels.list
    for _ in pairs(type(list) == "table" and list or {}) do
        wheels = wheels + 1
    end
    for _ in pairs(type(profile.slots) == "table" and profile.slots or {}) do
        binds = binds + 1
    end
    return binds, wheels
end

-- A profile with no more in it than a text needs: each bind is its kind and its number or name.
-- A table that came from a text goes through here too, before it is kept: what is not one of these
-- few plain values is gone. nil when the table is not a profile of this form.
function Rules.Lean(profile)
    if type(profile) ~= "table" or type(profile.binds) ~= "table" then
        return nil
    end
    -- A number is a whole number: every number of a profile is one, and the saved file cannot hold
    -- "not a number" or infinity, which a text can be made to carry.
    local function whole(value)
        return type(value) == "number" and value % 1 == 0
    end
    local function id(value, most)
        return whole(value) or (type(value) == "string" and #value <= most)
    end
    local function lean(bind)
        if type(bind) ~= "table" then
            return nil
        elseif bind.empty then
            return { empty = true }
        end
        return id(bind.kind, 20) and type(bind.kind) == "string" and id(bind.id, 80) and { kind = bind.kind, id = bind.id, on = ON[bind.on] and bind.on or nil } or nil
    end
    -- (a text of a build that had no fixed slots has no slots table: it keeps none, so the player
    -- who takes it keeps the slots they have)
    local out = { v = 1, name = clean(profile.name, 48), binds = {}, wheels = { list = {} }, slots = type(profile.slots) == "table" and {} or nil, settings = {} }
    for n = 1, out.slots and SLOTS or 0 do
        out.slots[n] = lean(at(profile.slots, n))
    end
    out.class = type(profile.class) == "string" and profile.class:find("^%u+$") and #profile.class <= 20 and profile.class or nil
    for set, layers in pairs(profile.binds) do
        if type(layers) == "table" and (set == "normal" or set == "combat" or (type(set) == "string" and #set <= 20 and set:find("^form:%d+$"))) then
            out.binds[set] = {}
            for layer = 1, LAYERS do
                local slots = at(layers, layer)
                for key, bind in pairs(type(slots) == "table" and slots or {}) do
                    -- a button's name is one or two letters: A, LB, L4
                    if type(key) == "string" and key:find("^%u[%u%d]?$") then
                        out.binds[set][layer] = out.binds[set][layer] or {}
                        out.binds[set][layer][key] = lean(bind)
                    end
                end
            end
        end
    end
    local list = type(profile.wheels) == "table" and type(profile.wheels.list) == "table" and profile.wheels.list or {}
    for index = 1, 8 do
        local wheel = at(list, index)
        if type(wheel) == "table" and type(wheel.id) == "string" and #wheel.id <= 8 and type(wheel.slots) == "table" then
            local slots = {}
            for place = 1, PLACES do
                slots[place] = lean(at(wheel.slots, place))
            end
            out.wheels.list[#out.wheels.list + 1] = { id = wheel.id, name = clean(wheel.name, 64), slots = slots }
        end
    end
    for key, value in pairs(type(profile.settings) == "table" and profile.settings or {}) do
        local kind = type(value)
        if type(key) == "string" and #key <= 60 and (kind == "boolean" or whole(value) or (kind == "string" and #value <= 60)) then
            out.settings[key] = value
        end
    end
    return out
end

-- The text of a profile as the player pasted it: no spaces or line breaks, and the tag in front.
-- Gives the part after the tag, or nil when it is not a profile text or is too long.
function Rules.Body(text)
    if type(text) ~= "string" or #text > Rules.TEXT_MOST * 2 then
        return nil
    end
    text = text:gsub("%s+", "")
    if #text > Rules.TEXT_MOST or text:sub(1, #Rules.TAG) ~= Rules.TAG or #text == #Rules.TAG then
        return nil
    end
    return text:sub(#Rules.TAG + 1)
end

if ns then
    ns.ProfileRules = Rules
end
return Rules
