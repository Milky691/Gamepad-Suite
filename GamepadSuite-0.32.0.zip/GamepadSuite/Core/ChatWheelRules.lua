-- The rules of the quick chat wheel, with no game calls: its eight lines, where each one stands,
-- the channel a line goes to, the chat command of an entry, the rest of a line after it was
-- sent, and the measures of an entry that is words and no picture.
-- It is a wheel as the others are (Core/WheelRules.lua): the player opens it with a bind, pushes
-- the right stick toward a line and lets the stick go. The game itself sends the line: an entry
-- is one chat command ("/p ready"), which the game runs as its own code, in a fight too.
-- A chat command takes no condition, and on this game a chat command text cannot run a second
-- one. So the channel is a part of the command, and the entries are made again when the group
-- changes (Core/ChatWheel.lua). The game takes new entries out of a fight only: in a fight a
-- line goes to the channel that was right when the fight began.
local _, ns = ...

local Chat = {}

-- The wheel's name among the wheels (Core/WheelRules.lua LIST).
Chat.ID = "chat"
-- The lines, from the top of the wheel clockwise. The two a player needs fastest in a fight
-- have the two places a thumb finds first: up and right. Down and left, the two other places
-- that are easy to find, have the two lines of a pull.
Chat.LINES = { "need help", "on my way", "oom", "one sec", "ready", "brb", "pulling", "thanks" }
-- A class with no mana cannot be out of it: it has another line in that place.
Chat.NO_MANA = { oom = "low hp" }
-- A line that was sent rests for this many seconds: a second flick at it sends nothing.
Chat.REST = 2

-- The channel a line goes to, as the middle of the wheel names it. group is what the player is
-- in: "instance" (a battleground, or a group the game made for an instance), "raid", "party",
-- or nil for a player alone.
function Chat.Channel(group)
    return (group == "instance" or group == "raid" or group == "party") and group or "say"
end

-- The wheel's entries. hasMana is false for a class with no mana. slash has the game's chat
-- command for each channel: { say = "/s", party = "/p", raid = "/raid", instance = "/i" }.
-- An entry has its words (text), the channel they go to (to) and its chat command (macro).
function Chat.Entries(hasMana, group, slash)
    local to, out = Chat.Channel(group), {}
    for place, line in ipairs(Chat.LINES) do
        line = not hasMana and Chat.NO_MANA[line] or line
        out[place] = { name = line, text = line, to = to, macro = slash[to] .. " " .. line }
    end
    return out
end

-- The rest of a line. rests is { [place] = when its line was sent }.
-- A line was sent. True when it rests from now on. In a fight no line rests: the game lets the
-- addon take no action off a wheel then, and a line must never be without its action in a fight.
function Chat.Sent(rests, place, now, fight)
    if fight then
        return false
    end
    rests[place] = now
    return true
end

-- The places whose rest is over at `now`, in order; they are taken out of rests. all: every
-- place that rests (a fight starts). A timer can come a moment early: that counts as in time.
function Chat.Over(rests, now, all)
    local out = {}
    for place, sent in pairs(rests) do
        if all or now - sent >= Chat.REST - 0.05 then
            out[#out + 1] = place
        end
    end
    table.sort(out)
    for _, place in ipairs(out) do
        rests[place] = nil
    end
    return out
end

-- An entry of words on the ring is a dark plate with the words on it. Every plate has one size,
-- so the longest line fits and the ring looks even. The numbers are for Wheel Size 100%: the
-- letters are about as large as the game's own chat text. The plates stand on the ring of a
-- wheel of eight pictures. A plate is as high as that ring lets it be: the plate at the top
-- and the one beside it do not touch, also with the frame on one of them. The middle has the
-- line in focus (FOCUS) and the channel under it (SMALL). The three type sizes are the Theme's body, row
-- and tiny (Look/Theme.lua Theme.size), written here: this file loads before the Theme.
Chat.LETTERS, Chat.WIDE, Chat.HIGH, Chat.FOCUS, Chat.SMALL = 16.5, 96, 24, 18, 13

-- The measures of a wheel of words at the setting Wheel Size. radius is how far the entries
-- stand from the middle (WheelRules.Measure). across is how wide the whole wheel is: the ring,
-- one plate and the rim of a wheel of pictures.
function Chat.Measure(percent, radius)
    local k = percent / 100
    return {
        letters = Chat.LETTERS * k, wide = Chat.WIDE * k, high = Chat.HIGH * k, focus = Chat.FOCUS * k, small = Chat.SMALL * k,
        across = 2 * radius + (Chat.WIDE + 18) * k,
    }
end

if ns then
    ns.ChatWheelRules = Chat
end
return Chat
