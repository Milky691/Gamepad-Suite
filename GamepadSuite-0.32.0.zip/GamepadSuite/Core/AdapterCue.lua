-- The adapter's part for the button cues (Screen/HudCues.lua) and for hiding the buttons on a mount
-- or at rest (Screen/HudHide.lua): which spell a bind casts now, the game's name of a spell, is a
-- spell lit, the game's cooldown event, what the target casts and can it be stopped, is the player
-- on a mount (or in a travel form), a flight or at rest. Each question is asked in a guarded call. A value the game hides in a fight is never
-- compared: "cannot be stopped" goes to the game's SetAlphaFromBoolean.
local _, ns = ...

local Adapter = ns.Adapter

local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

Adapter.Check("buttonCues", function()
    return C_SpellActivationOverlay and C_SpellActivationOverlay.IsSpellOverlayed and C_Spell.GetSpellName and C_Spell.GetBaseSpell
        and C_Spell.GetOverrideSpell and UnitCastingInfo and UnitChannelInfo and GetActionInfo ~= nil
end)
Adapter.Check("hideButtons", function() return IsMounted and UnitOnTaxi and IsResting ~= nil end)

-- The spell a press of the bind casts now: the spell a macro would cast at this moment, the spell
-- in one of the game's own slots (read as the game's own bar reads it for its glow,
-- Blizzard_ActionBar/Shared/ActionButton.lua 1038-1044), a pet ability, and the form's own version
-- of a spell (Feral Charge in Bear Form). nil for a bind that casts no spell.
function Adapter.CueSpell(bind)
    local ok, spell = pcall(function()
        bind = Adapter.Now(bind)
        local id = (bind.kind == "spell" or bind.kind == "pet") and bind.id
        if bind.kind == "slot" then
            local kind, action, sub = GetActionInfo(bind.id)
            id = (kind == "spell" or kind == "macro" and sub == "spell") and action
        end
        if type(id) ~= "number" or hidden(id) then
            return nil
        end
        local now = C_Spell.GetOverrideSpell(id)
        return not hidden(now) and type(now) == "number" and now or id
    end)
    return ok and spell or nil
end

-- The game's name of a spell: one name for all its ranks ("Overpower"), in the player's language.
-- base: the name of the spell it stands in for (C_Spell.GetBaseSpell), so that a form's version
-- has the name of its spell. nil when the game gives no name.
function Adapter.SpellKey(spell, base)
    local ok, name = pcall(function()
        if base then
            local first = C_Spell.GetBaseSpell(spell)
            spell = not hidden(first) and type(first) == "number" and first or spell
        end
        return C_Spell.GetSpellName(spell)
    end)
    return ok and not hidden(name) and type(name) == "string" and name or nil
end

-- True when the game says that this very spell is lit now (Blizzard_CooldownViewer/CooldownViewer.lua 1241).
function Adapter.SpellLit(spell)
    local ok, lit = pcall(C_SpellActivationOverlay.IsSpellOverlayed, spell)
    return ok and not hidden(lit) and lit == true
end

-- True for one of the game's own slots that the game itself calls an interrupt.
function Adapter.KickSlot(bind)
    if bind.kind ~= "slot" then
        return false
    end
    local ok, yes = pcall(C_ActionBar.IsInterruptAction, bind.id)
    return ok and not hidden(yes) and yes == true
end

-- Tells fn(spell, on) when the game lights a spell (on true) or puts it out. spell is nil when
-- the game hides the number.
function Adapter.OnSpellLit(owner, fn)
    for event, on in pairs({ SPELL_ACTIVATION_OVERLAY_GLOW_SHOW = true, SPELL_ACTIVATION_OVERLAY_GLOW_HIDE = false }) do
        ns.On(event, owner, function(spell)
            fn(not hidden(spell) and type(spell) == "number" and spell or nil, on)
        end)
    end
end

-- Tells fn(about) at the game's cooldown event for spells, with what it names for Adapter.Cooling:
-- { spell, base, recovery } (SpellBookDocumentation.lua 927 to 935), or nil when it is about all
-- cooldowns. As the game's cooldown viewer hears it (CooldownViewer.lua 2182 to 2186).
function Adapter.OnSpellCooldown(owner, fn)
    local function plain(value)
        return not hidden(value) and type(value) == "number" and value or nil
    end
    ns.On("SPELL_UPDATE_COOLDOWN", owner, function(spell, base, _, recovery)
        fn(plain(spell) and { spell = plain(spell), base = plain(base), recovery = plain(recovery) } or nil)
    end)
end

-- Does the target cast or channel now, and the game's "cannot be stopped" of that cast: true,
-- false, nil, or a hidden value (for Adapter.KickAlpha only). That a cast runs is read from a
-- value the game never hides, isTradeskill (UnitDocumentation.lua 838, 879).
function Adapter.TargetCast()
    local ok, casting, locked = pcall(function()
        local _, _, _, _, _, trade, _, locked = UnitCastingInfo("target")
        if trade ~= nil then
            return true, locked
        end
        local _, _, _, _, _, chanTrade, chanLocked = UnitChannelInfo("target")
        return chanTrade ~= nil, chanLocked
    end)
    if not ok then
        return false, nil
    end
    return casting, locked
end

-- Tells fn when the target starts, ends or changes a cast, and when the target changes. Only the
-- target's casts are heard (a frame of its own, the game's unit filter).
local CASTS = { "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_FAILED", "UNIT_SPELLCAST_INTERRUPTED",
    "UNIT_SPELLCAST_CHANNEL_START", "UNIT_SPELLCAST_CHANNEL_STOP", "UNIT_SPELLCAST_INTERRUPTIBLE", "UNIT_SPELLCAST_NOT_INTERRUPTIBLE" }
function Adapter.OnTargetCast(owner, fn)
    local ear = CreateFrame("Frame")
    for _, event in ipairs(CASTS) do
        pcall(ear.RegisterUnitEvent, ear, event, "target")
    end
    ear:SetScript("OnEvent", function()
        ns.Call(owner, fn)
    end)
    ns.On("PLAYER_TARGET_CHANGED", owner, fn)
end

-- Shows a region for a cast that can be stopped, and makes it unseen for one that cannot, from
-- the game's "cannot be stopped". A hidden value goes to the game, which keeps it from the addon.
-- True when the value was hidden.
function Adapter.KickAlpha(region, locked)
    if hidden(locked) then
        if not pcall(region.SetAlphaFromBoolean, region, locked, 0, 1) then
            region:SetAlpha(1)
        end
        return true
    end
    region:SetAlpha(locked and 0 or 1)
    return false
end

-- Is the player on a mount, on a flight path, at rest (an inn, a city). A travel form counts as a
-- mount: the forms of Auto Camera Zoom's list (Screen/AutoZoomModel.lua TRAVEL, read here at each
-- question as that file loads later), by GetShapeshiftFormID (Blizzard_FrameXMLBase/Constants.lua 329 to 333).
function Adapter.Travel()
    local ok, mounted, taxi, resting = pcall(function()
        local form = GetShapeshiftFormID and GetShapeshiftFormID()
        local travel = not hidden(form) and form ~= nil and ns.AutoZoomModel and ns.AutoZoomModel.TRAVEL[form]
        return (IsMounted() or travel) and true or false, UnitOnTaxi("player") and true or false, IsResting() and true or false
    end)
    if not ok then
        return false, false, false
    end
    return mounted, taxi, resting
end

-- Tells fn when one of those can have changed: a mount, a form, rest, the start or the end of a
-- flight (the controls go and come back; the flight's flag is one of the player's unit flags, which
-- UnitOnTaxi reads), a loading screen.
function Adapter.OnTravel(owner, fn)
    for _, event in ipairs({ "PLAYER_MOUNT_DISPLAY_CHANGED", "UPDATE_SHAPESHIFT_FORM", "PLAYER_UPDATE_RESTING", "PLAYER_CONTROL_LOST", "PLAYER_CONTROL_GAINED",
        "PLAYER_ENTERING_WORLD" }) do
        ns.On(event, owner, fn)
    end
    local ear = CreateFrame("Frame")
    pcall(ear.RegisterUnitEvent, ear, "UNIT_FLAGS", "player")
    ear:SetScript("OnEvent", function()
        ns.Call(owner, fn)
    end)
end
