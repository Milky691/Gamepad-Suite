-- The adapter's part for Quest Item Guard (Auto/JunkGuard.lua), the marked junk that Auto Sell
-- Junk sells (Auto/JunkSell.lua) and Mark Junk (Windows/JunkMark.lua). Four login checks.
--
-- What the game's code says:
--   The quest log: the game's own tracker reads each objective with GetNumQuestLeaderBoards and
--   GetQuestLogLeaderBoard(objective, log index): its text ("Linen Cloth: 3/10") and its kind
--   ("item") (Blizzard_ObjectiveTracker/Blizzard_QuestObjectiveTracker.lua 211 to 216).
--   The tooltip: TooltipDataProcessor.AddTooltipPostCall is the game's hook for addons. A call
--   added from addon code runs through a frame of the game that addons cannot touch, with
--   securecallfunction and forceinsecure, so it cannot mark the game's own code; the game shows
--   the tooltip after the post-calls (Blizzard_SharedXMLGame/Tooltip/TooltipDataHandler.lua 62 to
--   72, 111 to 151, 181 to 193, 294 to 300). The data's id is the item's (TooltipUtil.lua 8 to 20).
--   The buyback list: the vendor's Buyback tab is drawn from GetNumBuybackItems,
--   GetBuybackItemInfo and GetBuybackItemLink, the newest sale last, again at MERCHANT_UPDATE
--   (Mainline/MerchantFrame.lua 8, 97, 414 to 423, 532 to 563, 641 and 642).
--   The sale: the bag window's X at a vendor is a right click (Mainline/ContainerFrame.lua 3281
--   to 3286), which sells with C_Container.UseContainerItem. The game's notes put no
--   HasRestrictions on it (ContainerDocumentation.lua 584 to 596; the destroy has it,
--   ItemDocumentation.lua 105). ForeverPlus sells with it from a timer on this game
--   (Modules/AutoSellGray.lua 228 to 231), and the owner's game moved bank stacks with it from no
--   press (Deposit Trade Goods). With no vendor the same call uses or wears the item, so the
--   vendor's window must show at each call.
--   The bag window: the slot in focus is read as Core/AdapterBank.lua reads it; the item buttons
--   are read as Core/AdapterUpgrade.lua reads them (the list Items of each bag window). The
--   game's junk coin is the atlas bags-junkcoin (Mainline/ContainerFrame.xml 144).
--   Everything is read; nothing of the game is written or run.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

local COIN = "bags-junkcoin"
local SLOT = "ButtonContext_ContainerFrameItemButton"
local FIRST, LAST = 0, 5    -- the backpack to the last bag

local function event(name)
    return C_EventUtils.IsEventValid(name) == true
end
local function vendorEvents()
    return event("MERCHANT_SHOW") and event("MERCHANT_CLOSED") and event("BAG_UPDATE_DELAYED")
end

Adapter.Check("questNeeds", function()
    return C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo and GetNumQuestLeaderBoards and GetQuestLogLeaderBoard
        and C_Container.GetContainerNumSlots and C_Container.GetContainerItemInfo and C_Container.GetContainerItemQuestInfo ~= nil
end)
Adapter.Check("questTip", function()
    return TooltipDataProcessor.AddTooltipPostCall and Enum.TooltipDataType.Item and GameTooltip.AddLine and C_Item.GetItemNameByID
        and GetNumBuybackItems and GetBuybackItemInfo and GetBuybackItemLink and event("MERCHANT_UPDATE") and vendorEvents()
end)
Adapter.Check("junkSell", function()
    return C_Container.UseContainerItem and MerchantFrame.IsShown and C_MerchantFrame.IsSellAllJunkEnabled
        and C_MerchantFrame.GetNumJunkItems and C_Item.GetItemInfo and vendorEvents()
end)
Adapter.Check("junkMark", function()
    return ContainerFrameCombinedBags and SmartNavigation.SelectButton and hooksecurefunc and GamepadMode.FrameControlsManager
        and MerchantFrame.IsShown and C_Texture.GetAtlasInfo(COIN) ~= nil and vendorEvents()
end)

-- ---------------------------------------------------------------- the quest log
-- The quests of the log with their objectives: { { title, objectives = { { kind, text } } } }.
-- The headers are left out. A fault gives what was read before it.
function Adapter.QuestLog()
    local quests = {}
    pcall(function()
        for index = 1, C_QuestLog.GetNumQuestLogEntries() do
            local info = C_QuestLog.GetInfo(index)
            if info and not info.isHeader then
                local quest = { title = info.title or "a quest", objectives = {} }
                for n = 1, GetNumQuestLeaderBoards(index) or 0 do
                    local text, kind = GetQuestLogLeaderBoard(n, index)
                    quest.objectives[n] = { kind = kind, text = text }
                end
                quests[#quests + 1] = quest
            end
        end
    end)
    return quests
end

-- ---------------------------------------------------------------- the tooltip
-- Tells fn(item id) each time the game fills its tooltip, or a link's tooltip, with an item; a
-- text that fn gives back is added under it as one line in the colour r, g, b. Not the tooltips
-- that compare gear.
function Adapter.OnItemTooltip(fn, r, g, b)
    TooltipDataProcessor.AddTooltipPostCall(Enum.TooltipDataType.Item, function(tooltip, data)
        if (tooltip == GameTooltip or tooltip == ItemRefTooltip) and type(data) == "table" and type(data.id) == "number" then
            local text = fn(data.id)
            if text then
                tooltip:AddLine(text, r, g, b, true)
            end
        end
    end)
end

function Adapter.ItemName(id)
    local ok, name = pcall(C_Item.GetItemNameByID, id)
    return ok and type(name) == "string" and name or nil
end

-- ---------------------------------------------------------------- the vendor
-- The vendor's buyback list, oldest first: { { link, name } }.
function Adapter.Buyback()
    local list = {}
    pcall(function()
        for index = 1, GetNumBuybackItems() do
            list[#list + 1] = { link = GetBuybackItemLink(index) or ("entry " .. index), name = (GetBuybackItemInfo(index)) }
        end
    end)
    return list
end

-- True while the game's own sale of gray items is on and has gray items left to sell.
function Adapter.GraySalePending()
    local ok, pending = pcall(function()
        return C_MerchantFrame.IsSellAllJunkEnabled() and C_MerchantFrame.GetNumJunkItems() > 0
    end)
    return ok and pending and true or false
end

-- What a vendor pays for one of an item, or nil while the game has not loaded it.
function Adapter.ItemPrice(id)
    local ok, price = pcall(function()
        return select(11, C_Item.GetItemInfo(id))
    end)
    return ok and tonumber(price) or nil
end

-- ---------------------------------------------------------------- the bags
-- One bag slot as a thing of Auto/JunkModel.lua, or nil when it is empty.
local function read(bag, slot)
    local info = C_Container.GetContainerItemInfo(bag, slot)
    if not (info and info.itemID) then
        return nil
    end
    local quest = C_Container.GetContainerItemQuestInfo(bag, slot)
    return { bag = bag, slot = slot, id = info.itemID, name = info.itemName or ("item " .. info.itemID), count = info.stackCount or 1,
        quality = info.quality, noValue = info.hasNoValue or false, locked = info.isLocked or false,
        quest = type(quest) == "table" and (quest.isQuestItem or quest.questID ~= nil) or false }
end

-- Everything in the bags, in the bags' order.
function Adapter.JunkBags()
    local things = {}
    pcall(function()
        for bag = FIRST, LAST do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                things[#things + 1] = read(bag, slot)
            end
        end
    end)
    return things
end

-- The character's marks of junk: item id -> true. Kept for each character.
function Adapter.JunkMarks()
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    GamepadSuiteCharDB.junk = GamepadSuiteCharDB.junk or {}
    return GamepadSuiteCharDB.junk
end

-- Sells a stack to the open vendor, as the bag window's X does. Not in a fight, and only while
-- the vendor's window shows and the slot still holds that item. True when the call was made;
-- else false and why. The game's answer is that the bags change.
function Adapter.SellBagItem(thing)
    if not results().junkSell or InCombatLockdown() then
        return false, "a fight, or the game has no call for it"
    end
    local ok, why = pcall(function()
        if not (MerchantFrame:IsShown() or (ns.Merchant and ns.Merchant.Has())) then
            return "the vendor's window does not show"
        end
        local now = read(thing.bag, thing.slot)
        if not (now and now.id == thing.id) or now.locked then
            return "the slot holds something else now"
        end
        C_Container.UseContainerItem(thing.bag, thing.slot)
    end)
    if not ok then
        return false, tostring(why)
    end
    return why == nil, why
end

-- ---------------------------------------------------------------- the bag window
-- The game's bag window of the controller interface, to stand a hint by.
function Adapter.JunkBagWindow()
    return results().junkMark and ContainerFrameCombinedBags or nil
end

-- True while the game's own vendor window shows. Only then has the bag window's Y no job on an
-- item: with that window shut (the Merchant View has the vendor, Screen/Merchant.lua) Y opens the
-- game's More Actions menu there (Mainline/ContainerFrame.lua 3066 to 3068, 3132 to 3134).
function Adapter.VendorWindowShown()
    local ok, shown = pcall(function()
        return results().junkMark and MerchantFrame:IsShown()
    end)
    return ok and shown and true or false
end

-- The bag slot in the game's focus while the bag window has the controller, as a thing; nil for
-- an empty slot or when the focus is elsewhere.
function Adapter.JunkFocus()
    local ok, thing = pcall(function()
        local button = SmartNavigation.currentButton
        if results().junkMark and Adapter.WindowHasPad(ContainerFrameCombinedBags) and button and button.buttonContext == SLOT then
            return read(button:GetBagID(), button:GetID())
        end
    end)
    return ok and thing or nil
end

-- The bag windows of the game, in either interface (Core/AdapterUpgrade.lua says why the game's
-- own list of them is not asked).
local function bagFrames()
    local frames = { type(ContainerFrameCombinedBags) == "table" and ContainerFrameCombinedBags or nil }
    local held = type(ContainerFrameContainer) == "table" and ContainerFrameContainer.ContainerFrames
    for _, frame in ipairs(type(held) == "table" and held or {}) do
        frames[#frames + 1] = frame
    end
    return frames
end

-- Tells fn each time a bag window shows or hides. It runs inside the game's code: fn must only take note.
function Adapter.OnBagWindows(fn)
    if results().junkMark then
        for _, frame in ipairs(bagFrames()) do
            Adapter.OnShownOrHidden(frame, fn)
        end
    end
end

-- The items on the item buttons of the bag windows that show: { { frame, thing } }. A protected
-- button is left out: nothing of ours is put on one. Also true when a bag window shows, and how
-- many items were on a protected button (for the log).
function Adapter.BagSlotButtons()
    local spots, shows, locked = {}, false, 0
    pcall(function()
        for _, frame in ipairs(results().junkMark and bagFrames() or {}) do
            if frame:IsShown() and type(frame.Items) == "table" then
                shows = true
                for _, button in ipairs(frame.Items) do
                    local thing = button:IsShown() and read(button:GetBagID(), button:GetID())
                    if thing and button:IsProtected() then
                        locked = locked + 1
                    elseif thing then
                        spots[#spots + 1] = { frame = button, thing = thing }
                    end
                end
            end
        end
    end)
    return spots, shows, locked
end

-- Puts the game's own junk coin, in its own size, on a texture of ours.
function Adapter.JunkCoin(texture)
    texture:SetAtlas(COIN, true)
end
