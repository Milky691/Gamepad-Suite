-- The rules of the bind core, with no game calls: the key name of each layer, which bind a button
-- has in a state, the states, and what the game needs to run a bind. Core/BindPlan.lua makes the
-- plan for every state from them, and Core/BindCore.lua hands the plan to the game.
--
-- A state is "the Combat set is in use or not" and "in a form or not".
-- A layer is not a state. The game turns a held button into Shift, Ctrl or Alt (its settings say
-- which button is which), and a key pressed with it has a name of its own: with LT as Shift,
-- LT + A is the key "SHIFT-PAD1". So every layer of a button is bound at the same time, and a
-- held button changes no bind. The LB + RB layer is no key name: LB goes to a button of ours that
-- does LB's own bind and tells the owner frame that LB is held, and RB then starts the layer
-- (Core/BindHolds.lua).
-- A trigger that the game makes no modifier (RT, on most setups) has no key name. It is watched
-- instead: while it is held, the keys get its layer's binds (the "held" part of the plan).
local _, ns = ...

local Rules = {}

-- The secure buttons that run a spell, an item or a macro are named with this and a number.
Rules.BUTTON = "GamepadSuiteAction"
-- RB goes to this button while LB is held: its press starts the LB + RB layer.
Rules.CHORD_BUTTON = "GamepadSuiteChord"
-- LB goes to this button while the LB + RB layer is in use: it does LB's own bind and holds LB.
Rules.LB_BUTTON = "GamepadSuiteLB"
-- With the row Targeting at Stick, a bumper with a bind goes to its button: it does the bind and
-- holds the bumper, and the right stick then targets (Core/BindHolds.lua). LB's is the one above.
Rules.RB_BUTTON = "GamepadSuiteRB"
-- A slot made empty on purpose in a set goes to this button, which does nothing. So "empty here"
-- is nothing, not the game's own action and not the plain bind.
Rules.NOTHING_BUTTON = "GamepadSuiteNothing"
-- A watched trigger goes to one of two buttons, "...L" and "...R". Its press and its release
-- tell the owner frame to look at the pad.
Rules.HOLD_BUTTON = "GamepadSuiteHold"
-- A wheel's bind goes to the first button: the mouse button name of the click is the wheel
-- ("CLICK GamepadSuiteWheel:consumables"), and "close" closes the open wheel. While a wheel is
-- open, the right stick's four direction keys go to the second button, which uses the entry.
Rules.WHEEL_BUTTON = "GamepadSuiteWheel"
Rules.WHEEL_USE_BUTTON = "GamepadSuiteWheelUse"
-- The game's own command for "interact with what is highlighted". Dynamic Interact binds it.
Rules.INTERACT = "INTERACTSOFTTARGET"
-- The game's command for "interact with the target". A button can have it as its bind.
Rules.INTERACT_TARGET = "INTERACTTARGET"
-- The buttons the LB + RB layer has (layer 5). Every set has the layer: a form or a stance can
-- have its own binds on it, and so can the Combat set.
Rules.IN_HOLD = { "DU", "DD", "DL", "DR", "A", "B", "X", "Y", "LS", "RS" }
-- Healer Mode at Bumpers: our key name -> what it does while the friendly bumper is held (Core/BindGroup.lua)
Rules.GROUP_KEYS = { DU = "up", DR = "right", DD = "down", DL = "left", A = "player", X = "pet", B = "targettarget" }
-- The game writes the modifiers of a key name in this order.
local ORDER = { "ALT", "CTRL", "SHIFT" }
-- A game command that a button of ours can run as its chat command: { the game's word for it, the
-- standard English word, what follows }. LB's bind needs one while the LB + RB layer is in use, and
-- a bumper's bind while the right stick targets with it.
Rules.CHAT = {
    TARGETNEARESTENEMY = { "TARGET_NEAREST_ENEMY", "/targetenemy" }, TARGETPREVIOUSENEMY = { "TARGET_NEAREST_ENEMY", "/targetenemy", " 1" },
    TARGETNEARESTFRIEND = { "TARGET_NEAREST_FRIEND", "/targetfriend" }, TARGETPREVIOUSFRIEND = { "TARGET_NEAREST_FRIEND", "/targetfriend", " 1" },
    TARGETSELF = { "TARGET", "/target", " player" }, TARGETPET = { "TARGET", "/target", " pet" },
    TARGETPARTYMEMBER1 = { "TARGET", "/target", " party1" }, TARGETPARTYMEMBER2 = { "TARGET", "/target", " party2" },
    TARGETPARTYMEMBER3 = { "TARGET", "/target", " party3" }, TARGETPARTYMEMBER4 = { "TARGET", "/target", " party4" },
    ASSISTTARGET = { "ASSIST", "/assist" }, STARTATTACK = { "STARTATTACK", "/startattack" },
    TARGETLASTTARGET = { "TARGET_LAST_TARGET", "/targetlasttarget" },
}
-- The chat command text for a game command, or nil. Rules.Word(word) is the game's own word, where
-- the adapter's side gives it (Core/BindShape.lua).
function Rules.ChatText(command)
    local c = Rules.CHAT[command]
    return c and (((Rules.Word and Rules.Word(c[1])) or c[2]) .. (c[3] or "")) or nil
end

-- The front part of a key name for a set of modifiers: { SHIFT = true } gives "SHIFT-".
function Rules.Front(held)
    local text = ""
    for _, name in ipairs(ORDER) do
        text = text .. (held[name] and (name .. "-") or "")
    end
    return text
end

-- Every front a key can come with, for the modifiers the game has on a button:
-- "", "SHIFT-", "CTRL-", "CTRL-SHIFT-".
function Rules.Fronts(mods)
    local used, out = {}, { "" }
    for _, name in pairs(mods) do
        used[name] = true
    end
    for index = #ORDER, 1, -1 do
        if used[ORDER[index]] then
            for i = 1, #out do
                out[#out + 1] = ORDER[index] .. "-" .. out[i]
            end
        end
    end
    return out
end

-- The front part of a key name for each trigger layer: "", "SHIFT-", "ALT-SHIFT-". mods tells which
-- modifier each trigger is: { LT = "SHIFT", RT = "ALT" }. A layer whose trigger is no modifier has
-- no key name: nil.
--   1 no trigger, 2 LT, 3 RT, 4 LT + RT.
function Rules.Prefixes(mods)
    local function prefix(...)
        local held = {}
        for _, button in ipairs({ ... }) do
            if not mods[button] then
                return nil
            end
            held[mods[button]] = true
        end
        return Rules.Front(held)
    end
    return { [1] = "", [2] = prefix("LT"), [3] = prefix("RT"), [4] = prefix("LT", "RT") }
end

-- The bind of a button in a state, and the set it came from, on every layer. The form's set is
-- asked first (for Prowl, then the set of Cat Form), then the Combat set while it is in use, then
-- Normal: in a fight a druid who goes into Bear Form gets the Bear Form binds (the owner,
-- 2026-10-17). With Form and Stance Binds at Combat First (state.combatFirst, a warrior's start
-- value) the Combat set is asked before the form's set (decision 83). A bind on Normal is used
-- everywhere unless a set before it has its own. A slot made empty on purpose stops the search: the button then has no
-- bind of ours and does nothing there.
-- get(set, layer, key) reads the store. state = { combat = true or false, form = a set name or nil, base = the same,
-- combatFirst = true or nil }.
function Rules.Find(get, state, layer, key)
    local combat = state.combat and "combat" or false
    local order = state.combatFirst and { combat, state.form or false, state.base or false, "normal" }
        or { state.form or false, state.base or false, combat, "normal" }
    for _, set in ipairs(order) do
        local bind = set and get(set, layer, key)
        if bind then
            if bind.empty then
                return nil, set
            end
            return bind, set
        end
    end
end

-- The hold layer that acts: [5] LB + RB, while its row (both) is on. LB and RB keep their own
-- binds: hold LB, then press RB. The bind plan and the Binds page ask here.
function Rules.Holds(both)
    return { [5] = both and true or false }
end

-- Every state, each with a short name for the game's state driver: "c" or "n" (Combat set in
-- use or not) and the number of the form (0 is no form). forms is the adapter's list, in the
-- game's order. combat is the setting Combat Binds; combatFirst: Form and Stance Binds is at Combat First.
function Rules.States(forms, combat, combatFirst)
    local states = {}
    for _, inCombat in ipairs(combat ~= "Off" and { true, false } or { false }) do
        for index = 0, #forms do
            states[#states + 1] = {
                name = (inCombat and "c" or "n") .. index, combat = inCombat, form = forms[index] and forms[index].id,
                base = forms[index] and forms[index].base, combatFirst = combatFirst or nil,
            }
        end
    end
    return states
end

-- The line of conditions that tells the game which state is in use. The first one that is true
-- wins, so a form stands before "no form", and the Combat set before the rest.
-- "Hostile target" uses the Combat set in combat, and also while an enemy that can be attacked is the target. A critter
-- or a guard of the other faction across a city counts too ([harm]); decision 67 wants the set to hold, so it stays.
function Rules.Driver(forms, combat)
    local whens = combat == "Hostile target" and { "combat", "harm,nodead" } or combat == "In combat" and { "combat" } or {}
    local parts = {}
    local function add(prefix, conditions, index)
        local text = ""
        for _, condition in ipairs(conditions) do
            -- the form's own words (Prowl), or the game's number of the form: a form the list left out moves no other form
            local when = forms[index] and (forms[index].when or "form:" .. (forms[index].index or index)) or "form:" .. index
            text = text .. "[" .. condition .. (index > 0 and ((condition ~= "" and "," or "") .. when) or "") .. "]"
        end
        parts[#parts + 1] = (text ~= "[]" and text .. " " or "") .. prefix .. index
    end
    if #whens > 0 then
        for index = #forms, 0, -1 do
            add("c", whens, index)
        end
    end
    for index = #forms, 1, -1 do
        add("n", { "" }, index)
    end
    parts[#parts + 1] = "n0"
    return table.concat(parts, "; ")
end

-- A bind that stands for a thing of the moment, as the bind that acts now: "Fishing Pole" is a
-- chat command text made from what is in the hands, "Slot 3" is what that fixed slot holds.
-- Rules.LIVE has a function for each such kind. With no function, or when the function has
-- nothing now, the bind is itself.
Rules.LIVE = {}
local MOMENT = { fishingpole = true, fixed = true }
function Rules.Real(bind)
    local live = Rules.LIVE[bind.kind]
    return live and live(bind) or bind
end

-- Who a spell or an item is cast on when it is not the target (bind.on): yourself; or the focus
-- or the unit under the pointer when there is one, else as the game casts it. Rules.CastName(spell)
-- is a spell's name for a chat command; the adapter's side puts it here (Core/BindShape.lua).
-- Rules.BookName(spell) is the name a secure button casts the spell by, or nil to cast it by its
-- number: by its name the game casts the version for the form the player is in.
Rules.ON = { player = "player", focus = "focus", mouseover = "mouseover" }

-- What the game needs to run a bind. A game command is bound to the key itself: { command = }.
-- Anything else is a secure button's attributes. nil for a bind the game cannot run.
function Rules.Action(bind)
    bind = Rules.Real(bind)
    local kind, id = bind.kind, bind.id
    if MOMENT[kind] then
        -- nothing for it now (no fishing pole, an empty slot): the button stays this bind's and does nothing
        return { type = "macro", macrotext = "" }
    elseif kind == "command" then
        return { command = id }
    elseif kind == "spell" or kind == "item" then
        local on, what = Rules.ON[bind.on], kind == "item" and "item:" .. id or id
        -- Stealth, Prowl and Shadowform: this game does not end them on a second cast, so the press casts
        -- the spell out of its state and takes it off in it. Rules.Toggle(spell) gives the game's word for
        -- the state and the spell's name, from the adapter's side (Core/BindShape.lua).
        local word, plain
        if kind == "spell" and not on and Rules.Toggle then
            word, plain = Rules.Toggle(id)
        end
        if word then
            return { type = "macro", macrotext = "/cast [no" .. word .. "] " .. plain .. "\n/cancelaura [" .. word .. "] " .. plain }
        end
        local name = kind == "item" and what or (Rules.CastName and Rules.CastName(id))
        -- a spell goes by the name the spellbook has for it, where the game has one for the button (Rules.BookName)
        return on and on ~= "player" and name and { type = "macro", macrotext = (kind == "item" and "/use" or "/cast") .. " [@" .. on .. ",exists][] " .. name }
            or { type = kind, [kind] = kind == "spell" and Rules.BookName and Rules.BookName(id) or what, unit = on }
    elseif kind == "macro" then
        return { type = "macro", macro = id }
    elseif kind == "slot" then
        -- one of the game's own action slots
        return { type = "action", action = id }
    elseif kind == "wheel" then
        return { command = "CLICK " .. Rules.WHEEL_BUTTON .. ":" .. id }
    elseif kind == "emote" or kind == "slash" then
        return bind.detail and { type = "macro", macrotext = bind.detail } or nil
    elseif kind == "pet" then
        -- A pet command or ability on the pet bar is a press of its slot there (Rules.PetSlot, from the
        -- adapter's side): the typed pet commands run and change nothing on this game (ControllerForever,
        -- ClassWheels.lua 525 to 533). An ability that is not on the bar is cast by its name.
        local slot = Rules.PetSlot and Rules.PetSlot(id)
        if slot then
            return { type = "pet", action = slot }
        end
        return bind.name and not tostring(id):find("^PET_") and { type = "macro", macrotext = "/cast " .. bind.name } or nil
    end
end

-- One text for a secure button's action. Two binds with the same text share one button.
function Rules.Signature(action)
    return action.type .. ":" .. tostring(action.spell or action.item or action.macro or action.macrotext or action.action) .. (action.unit and "@" .. action.unit or "")
end

if ns then
    ns.BindRules = Rules
end
return Rules
