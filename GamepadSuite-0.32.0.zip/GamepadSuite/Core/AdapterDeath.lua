-- The adapter's part for Auto Decline Duel and Auto Release (Auto/DeclineDuel.lua, Auto/Release.lua): the game's
-- answer to a duel, its release of the spirit, and what it says of a death.
--
-- CancelDuel is a global of the game that its notes do not list (DuelInfoDocumentation.lua has no functions). The game's
-- own duel question calls it for its Decline button (Blizzard_StaticPopup_Game/GameDialogDefs.lua 2028 to 2041), and the
-- game hides that question itself at DUEL_FINISHED (Blizzard_Game/Mainline/EventImplementation.lua 432 to 435), so the
-- addon makes the call and never touches the question. RepopMe is the game's Release (PlayerScriptDocumentation.lua 1610),
-- the call of the Release button of its death window (Blizzard_StaticPopup_Game/Mainline/GameDialogDefs.lua 235). The
-- notes put no restriction on either. The game's death window turns its Release button off while the body falls (not
-- out of bounds) and while a no-release effect is on (the same file, 250 to 270), and shows only while
-- GetReleaseTimeRemaining is above 0 or -1, with no other player's resurrection on offer (Blizzard_Game/Camelot/
-- EventImplementation.lua 22): Death tells the same facts.
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("declineDuel", function()
    return type(CancelDuel) == "function" and C_EventUtils.IsEventValid("DUEL_REQUESTED") == true
end)

Adapter.Check("release", function()
    return type(RepopMe) == "function" and GetReleaseTimeRemaining and HasNoReleaseAura and IsFalling and IsOutOfBounds and ResurrectGetOfferer
        and UnitIsDead and UnitIsGhost and IsInInstance and IsInGroup and C_DeathInfo.GetSelfResurrectOptions
        and C_GameRules.IsHardcoreActive and C_EventUtils.IsEventValid("PLAYER_DEAD") == true
end)

-- Declines the duel that a player asks for. True when the game took the call, else false and the error.
function Adapter.DeclineDuel()
    return pcall(CancelDuel)
end

-- True while the game's own question of a duel shows: for the log (StaticPopup.lua 179, a read).
function Adapter.DuelAskShown()
    local ok, shown = pcall(StaticPopup_Visible, "DUEL_REQUESTED")
    return ok and shown and true or false
end

-- The answer of one of the game's calls, or nil when the call raised.
local function ask(fn, ...)
    local ok, a, b = pcall(fn, ...)
    if ok then
        return a, b
    end
end

-- What the game says of the player's death: { kind = the kind of place (IsInInstance: "none" in the open world, "pvp"
-- in a battleground, "party", "raid", "arena"; nil when unknown), grouped, dead, ghost, own = a resurrection of the
-- player's own that can be used now (a soulstone, Reincarnation): its name ("Soulstone", the game's "Use " left off),
-- or true when the game gives none; offer = the name of a player who offers one, falling, aura = a no-release effect,
-- time = the release time left (-1 for none), hardcore }. Of several the game's own death window shows the usable one
-- with the lowest priority first (Blizzard_StaticPopup_Game/GameDialogDefsUtil.lua 3 to 22): so here.
function Adapter.Death()
    local _, kind = ask(IsInInstance)
    local own, first = false, nil
    pcall(function()
        for _, option in ipairs(C_DeathInfo.GetSelfResurrectOptions() or {}) do
            if option.canUse == true and (not first or (option.priority or 0) < (first.priority or 0)) then
                first = option
            end
        end
        own = first ~= nil
        if own and type(first.name) == "string" and first.name ~= "" then
            own = first.name:gsub("^Use ", "")
        end
    end)
    -- (a name is tested inside the protected call: should the game ever hide who offers, no error comes out)
    local offer = ask(function()
        local name = ResurrectGetOfferer()
        return type(name) == "string" and name ~= "" and name or nil
    end)
    return {
        kind = type(kind) == "string" and kind or nil, grouped = ask(IsInGroup) and true or false,
        dead = ask(UnitIsDead, "player") and true or false, ghost = ask(UnitIsGhost, "player") and true or false,
        own = own, offer = offer,
        falling = ask(IsFalling) and not ask(IsOutOfBounds) and true or false, aura = ask(HasNoReleaseAura) and true or false,
        time = tonumber((ask(GetReleaseTimeRemaining))) or 0, hardcore = ask(C_GameRules.IsHardcoreActive) and true or false,
    }
end

-- Releases the spirit, as the game's Release button does. True when the game took the call, else false and the error.
function Adapter.Release()
    return pcall(RepopMe)
end
