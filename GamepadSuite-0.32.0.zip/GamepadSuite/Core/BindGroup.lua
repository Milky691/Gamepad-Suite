-- Healer Mode at Bumpers: while the friendly bumper is held, the D-pad, A, X and B target the group, as the game's own
-- friendly targeting does (Blizzard_GamepadActionBars/TargetActionBars/FriendlyTargetingActionBar.lua 108 to 260): in
-- a party the D-pad is party 1 to 4 (up, right, down, left), A the player, X the pet, B the target's target; in a raid
-- the D-pad steps through the raid as its frames stand: up and down the members of a group, left and right the groups.
-- The game's own targeting bar cannot do it here: our binds stand above it, and restricted code cannot see its
-- modifier. So while the bumper is held those keys go to the group button (Core/BindSecure.lua APPLY, "gkey:<key>"):
-- a secure button whose action is "target" and whose unit its restricted code picks at each press (SNIPPET), in a fight
-- too. Each press that targets somebody tells the owner frame that the bumper was used ("bused"), so the bumper's own
-- bind does not run at its let-go (Core/BindHolds.lua ROUTER); a press on an empty place leaves the tap whole. The
-- raid's order is written out of a fight at each change of the group, and kept as it is in a fight (a member who left
-- is skipped: UnitExists). Solo there is no group hold: the bumper is a plain bind on the press (Core/BindShape.lua).
-- On the bumper that is also the Dynamic Interact button the hold wins (decision 137): the owner frame does not make
-- that key interact in a state where it holds the group ("gbkey:<state>", Core/BindSecure.lua APPLY).
local _, ns = ...

local Group = {}
ns.BindGroup = Group

Group.BUTTON = "GamepadSuiteGroup"
local PARTY = { up = "party1", right = "party2", down = "party3", left = "party4" }
local MOST, SIZE = 8, 5

local button, header
local grouped      -- in a party or a raid at the last look: a change makes the plan again (solo has no group hold)
local reachTold    -- the log has had a group hold that began with something in reach

-- The press of a key while the bumper is held: the click's button name says what it does. In a raid ("groups": how
-- many groups have members) the group in focus ("k") and the place in it ("s") move, and wrap round.
Group.SNIPPET = [[
    if not down then
        return false
    end
    local unit = button
    if button == "up" or button == "down" or button == "left" or button == "right" then
        local groups = self:GetAttribute("groups")
        if groups then
            local k, s = self:GetAttribute("k") or 1, self:GetAttribute("s") or 1
            if button == "left" or button == "right" then
                k = k + (button == "right" and 1 or -1)
                if k < 1 then
                    k = groups
                elseif k > groups then
                    k = 1
                end
                local n = self:GetAttribute("n:" .. k) or 1
                if s > n then
                    s = n
                end
            else
                local n = self:GetAttribute("n:" .. k) or 1
                s = s + (button == "down" and 1 or -1)
                if s < 1 then
                    s = n
                elseif s > n then
                    s = 1
                end
            end
            self:SetAttribute("k", k)
            self:SetAttribute("s", s)
            unit = self:GetAttribute("u:" .. k .. ":" .. s)
        else
            unit = self:GetAttribute("party:" .. button)
        end
    end
    if not unit or not UnitExists(unit) then
        return false
    end
    control:SetAttribute("bused", true)
    self:SetAttribute("unit", unit)
]]

-- The raid's order, out of a fight: the groups with members in the game's order, each with its members (the player
-- first in the player's own group, Core/AdapterWheel.lua PartyUnits); the focus starts on the player.
function Group.Roster()
    local now = ns.Adapter.InGroup()
    if grouped ~= nil and now ~= grouped and ns.Registry.Get("combat.healer_mode") == "Bumpers" then
        ns.BindCore.Rebuild()
    end
    grouped = now
    if not button or ns.Adapter.InCombat() then
        return
    end
    local _, raid = ns.Adapter.PartyUnits()
    local order = {}
    for group = 1, MOST do
        if raid and raid[group] and #raid[group] > 0 then
            order[#order + 1] = raid[group]
        end
    end
    local k, s = 1, 1
    for at = 1, MOST do
        local list = order[at] or {}
        button:SetAttribute("n:" .. at, list[1] and #list or nil)
        for place = 1, SIZE do
            button:SetAttribute("u:" .. at .. ":" .. place, list[place])
            if list[place] == "player" then
                k, s = at, place
            end
        end
    end
    button:SetAttribute("groups", #order > 0 and #order or nil)
    button:SetAttribute("k", k)
    button:SetAttribute("s", s)
end

-- What the owner frame needs from a plan, written with the bind core's writer: the bumper ("gwho"), its own action in
-- each state ("lb:<state>"), its key in each state where it holds the group ("gbkey:<state>"), that it acts on a tap
-- ("tap:<who>"), and the keys that target the group while it is held. The line about a bumper that cannot hold the
-- group is said once for the character, and again when it changes (Core/BindCheck.lua Tell).
local logged = false
function Group.Write(write, plan)
    local group = plan.group
    write("gwho", group and group.who or nil)
    for _, who in ipairs({ "lb", "rb" }) do
        write("tap:" .. who, group and group.who == who or nil)
    end
    for name, n in pairs(group and group.n or {}) do
        write(group.who .. ":" .. name, n)
        write("gbkey:" .. name, ns.Adapter.KEY[group.who:upper()])
        ns.BindHolds.Lend(n)
    end
    for key, what in pairs(group and group.keys or {}) do
        write("gkey:" .. key, what, key)
    end
    local off = group and #group.off > 0
    if off and not logged then
        logged = true
        ns.Log.Add("binds", "Healer Mode Bumpers is off in " .. table.concat(group.off, ", ") .. ": the bumper's bind there is a game command that no button can run")
    end
    ns.BindCheck.Tell("group", off and "Healer Mode is Bumpers, but the bumper has a command of the game, so holding it does not target the group. On the Binds tab, give it a spell, an item, a macro or a target bind such as Target Nearest Friend." or nil)
end

-- The friendly bumper went down through its button. The log has, once, a hold that began with something in reach
-- while that bumper is the Dynamic Interact button too: one try in the game shows that the hold won (decision 137).
local function held(_, name, value)
    if value and not reachTold and name == (header:GetAttribute("gwho") or "") .. "down" and header:GetAttribute("ikey")
        and header:GetAttribute("ikey") == header:GetAttribute("gbkey:" .. tostring(header:GetAttribute("state-binds") or "n0"))
        and (header:GetAttribute("near") or tostring(header:GetAttribute("state-interact")) == "1") then
        reachTold = true
        ns.Log.Add("binds", name .. " true with softinteract in reach: the group hold began, Healer Mode at Bumpers wins over Dynamic Interact")
    end
end

-- Makes the group button. Core/BindSecure.lua calls it when it makes the owner frame, out of a fight. make(header,
-- name) makes a secure button; seen is the restricted code every press of ours runs first (Sticky Layers).
function Group.Build(owner, make, seen)
    header = owner
    header:HookScript("OnAttributeChanged", held)
    button = make(header, Group.BUTTON)
    button:RegisterForClicks("AnyDown")
    button:SetAttribute("type", "target")
    button:SetAttribute("useOnKeyDown", true)
    for way, unit in pairs(PARTY) do
        button:SetAttribute("party:" .. way, unit)
    end
    SecureHandlerWrapScript(button, "OnClick", header, (seen or "") .. Group.SNIPPET)
    for _, event in ipairs({ "GROUP_ROSTER_UPDATE", "PLAYER_REGEN_ENABLED", "PLAYER_ENTERING_WORLD" }) do
        ns.On(event, "BindGroup", Group.Roster)
    end
    -- the game's option that swaps its two bumpers changes which one is the friendly one
    pcall(ns.On, "CVAR_UPDATE", "BindGroup", function(name)
        if name == "GamepadSwapTargetModifiers" then
            ns.BindCore.Rebuild()
        end
    end)
    Group.Roster()
end
