-- The adapter's part for the merchant view (Screen/Merchant.lua): who has the vendor, what the
-- vendor sells and buys back, what the bags hold that a vendor buys, the steps of a sale, and the
-- tooltip of a card. The repair and the sale of junk are the calls of Core/AdapterVendor.lua.
--
-- What the game's code says (Blizzard_UIPanels_Game, the Mainline files this game type loads;
-- MF is Mainline/MerchantFrame.lua, PIFM Shared/PlayerInteractionFrameManager.lua):
--   The vendor window is opened by the game's interaction manager, not by MERCHANT_SHOW. The
--   window is registered for the interaction Merchant (MF 85 to 94); the manager is a frame with
--   no name that hears PLAYER_INTERACTION_MANAGER_FRAME_SHOW and calls the window's function
--   (PIFM 114 to 137 and 165 to 183), which shows the window with ShowUIPanel and ends the vendor
--   talk when it did not show (MF 68 to 77). The window's hide ends the talk too (MF 163 to 164).
--   So a window that showed cannot be put away again.
--   Writing the manager's tables (RegisterPlayerInteraction, SetPlayerInteractionConditions,
--   PIFM 73 to 94) would mark them as an addon's for the session: every later vendor window would
--   open from addon code. That is not done. The way taken is the dialogue view's
--   (Core/AdapterDialogueTake.lua): the manager frame stops hearing its show event, with its own
--   UnregisterEvent, for one frame at MERCHANT_SHOW, and hears it again after (RegisterEvent);
--   no field of the game is written. The frame is found once with the game's EnumerateFrames,
--   by its event script (PIFM 182). Both events are synchronous (MerchantFrameDocumentation.lua
--   109 to 114, PlayerInteractionManagerDocumentation.lua 111 to 118); which one comes first is
--   not in the game's Lua, so the module checks that the window stayed away.
--   The calls: nothing in MerchantFrameDocumentation.lua has HasRestrictions; UseContainerItem
--   has none (ContainerDocumentation.lua 584 to 596). BuyMerchantItem, BuybackItem, CloseMerchant
--   and GetMerchantItemCostItem are in no note of the game: its own code calls them as plain
--   globals (MF 659 to 667, 696 to 709), and Restock buys from an event (Auto/Restock.lua). A
--   bag item is sold as the game's right click sells it (Mainline/ContainerFrame.lua 1540 to
--   1608); with no vendor the same call uses or wears the item, so the module calls it only
--   while the vendor is open, and the slot is read again first.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

local SHOW = "PLAYER_INTERACTION_MANAGER_FRAME_SHOW"
local FIRST, LAST = 0, 5    -- the backpack to the last bag, as Core/AdapterJunk.lua reads them

Adapter.Check("merchantView", function()
    for _, event in ipairs({ "MERCHANT_SHOW", "MERCHANT_CLOSED", "MERCHANT_UPDATE", SHOW, "PLAYER_MONEY", "BAG_UPDATE_DELAYED",
        "UI_ERROR_MESSAGE", "GET_ITEM_INFO_RECEIVED", "UPDATE_INVENTORY_DURABILITY", "GAME_PAD_CONNECTED", "GAME_PAD_DISCONNECTED" }) do
        if not C_EventUtils.IsEventValid(event) then
            return false
        end
    end
    return EnumerateFrames and PlayerInteractionFrameManagerMixin.OnEvent and Enum.PlayerInteractionType.Merchant
        and MerchantFrame.IsShown and MerchantFrame.HookScript and GetMerchantNumItems and C_MerchantFrame.GetItemInfo
        and GetMerchantItemLink and GetMerchantItemMaxStack and GetMerchantItemCostInfo and GetMerchantItemCostItem
        and BuyMerchantItem and GetNumBuybackItems and GetBuybackItemInfo and GetBuybackItemLink and BuybackItem
        and CloseMerchant and GetMoney and CanMerchantRepair and C_Container.GetContainerNumSlots
        and C_Container.GetContainerItemInfo and C_Container.UseContainerItem and C_Item.GetItemInfo
        and TooltipDataHandlerMixin.SetMerchantItem and TooltipDataHandlerMixin.SetBuybackItem and TooltipDataHandlerMixin.SetBagItem ~= nil
end)

-- ---------------------------------------------------------------- who has the vendor
local manager         -- the game's interaction manager frame; false when it was not found
local asked = false   -- the chat has asked for a reload

local function find()
    if manager == nil then
        manager = false
        local want = PlayerInteractionFrameManagerMixin.OnEvent
        local ok, frame = pcall(EnumerateFrames)
        while ok and frame do
            local read, script = pcall(function()
                return frame:GetScript("OnEvent")
            end)
            if read and script == want then
                manager = frame
                break
            end
            ok, frame = pcall(EnumerateFrames, frame)
        end
    end
    return manager or nil
end

-- True when the game's interaction manager was found (for the log).
function Adapter.MerchantManager()
    return find() ~= nil
end

-- The manager does not hear the show of the game's windows (hold true), or hears it again. True
-- when it reads back as asked. A show that does not come back would keep every window of the
-- game shut for the session: the chat asks for a reload, one time.
function Adapter.MerchantHold(hold)
    local frame = find()
    if not frame then
        return false
    end
    pcall(frame[hold and "UnregisterEvent" or "RegisterEvent"], frame, SHOW)
    local ok, on = pcall(frame.IsEventRegistered, frame, SHOW)
    local fine = ok and (on and true or false) == not hold
    if not hold and not fine and not asked then
        asked = true
        ns.Print("The game's own windows for NPCs did not come back. Type /reload to get them back.")
    end
    return fine
end

-- True while the game's own vendor window shows.
function Adapter.MerchantGameWindow()
    local ok, shown = pcall(MerchantFrame.IsShown, MerchantFrame)
    return ok and shown and true or false
end

-- Tells fn each time the game's vendor window shows. It runs inside the game's code: fn must
-- only take note.
function Adapter.OnMerchantWindow(fn)
    pcall(MerchantFrame.HookScript, MerchantFrame, "OnShow", function() fn() end)
end

-- True for the game's number of the interaction Merchant (5).
function Adapter.MerchantKind(kind)
    local types = Enum and Enum.PlayerInteractionType or {}
    return kind == (types.Merchant or 5)
end

-- ---------------------------------------------------------------- what the vendor has
local function quality(link)
    local ok, _, _, value = pcall(C_Item.GetItemInfo, link)
    return ok and value or nil
end

-- One thing the vendor sells, or nil: { index, name, icon, link, quality, price (of one lot, in
-- copper), lot (items in one lot), stack (the most items one call buys), left (lots the vendor
-- has; -1 for no limit), buyable, usable, afford, questStart (the item starts a quest: the game's
-- window draws its yellow mark from it, MF 349 to 354; MerchantFrameDocumentation.lua 140),
-- costs = { { icon, value, name } } } (MF 290 to 300, 496 to 530, 713 to 739).
local function good(index)
    local info = C_MerchantFrame.GetItemInfo(index)
    if not info then
        return nil
    end
    local link = GetMerchantItemLink(index)
    local item = { index = index, name = info.name or "", icon = info.texture, link = link, quality = link and quality(link),
        price = info.price or 0, lot = math.max(1, info.stackCount or 1), left = info.numAvailable or -1,
        buyable = info.isPurchasable ~= false, usable = info.isUsable ~= false, stack = GetMerchantItemMaxStack(index) or 1, costs = {},
        questStart = info.isQuestStartItem == true }
    if CanAffordMerchantItem then
        local ok, can = pcall(CanAffordMerchantItem, index)
        item.afford = ok and can
    end
    if info.hasExtendedCost then
        for n = 1, GetMerchantItemCostInfo(index) or 0 do
            local icon, value, costLink, name = GetMerchantItemCostItem(index, n)
            if icon then
                local named = name
                if not named and costLink then
                    local read, itemName = pcall(C_Item.GetItemInfo, costLink)
                    named = read and itemName or nil
                end
                item.costs[#item.costs + 1] = { icon = icon, value = value or 0, name = type(named) == "string" and named or nil }
            end
        end
    end
    return item
end

-- Everything the open vendor sells, in the game's order. One thing that fails to read is left out.
function Adapter.MerchantGoods()
    local goods = {}
    local ok, count = pcall(GetMerchantNumItems)
    for index = 1, ok and tonumber(count) or 0 do
        local read, item = pcall(good, index)
        goods[#goods + 1] = read and item or nil
    end
    return goods
end

-- The vendor's buyback list, oldest first, as the game draws it (MF 553 to 566): { index, name,
-- icon, link, quality, price (of the whole stack), count, usable }.
function Adapter.MerchantBuyback()
    local list = {}
    local ok, count = pcall(GetNumBuybackItems)
    for index = 1, ok and tonumber(count) or 0 do
        pcall(function()
            local name, icon, price, stack, _, usable = GetBuybackItemInfo(index)
            local link = GetBuybackItemLink(index)
            if name then
                list[#list + 1] = { index = index, name = name, icon = icon, link = link, quality = link and quality(link), price = price or 0,
                    count = stack or 1, usable = usable ~= false }
            end
        end)
    end
    return list
end

-- Every stack in the bags, in the bags' order: { bag, slot, id, name, icon, link, quality, count,
-- price (what a vendor pays for one; nil while the game has not loaded it), noValue, locked,
-- quest (the game's own mark of a quest item), hasLoot (it holds things: a clam, an opened box;
-- ContainerDocumentation.lua 775) }.
function Adapter.MerchantBags()
    local things = {}
    for bag = FIRST, LAST do
        local ok, slots = pcall(C_Container.GetContainerNumSlots, bag)
        for slot = 1, ok and tonumber(slots) or 0 do
            pcall(function()
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info and info.itemID then
                    local quest = C_Container.GetContainerItemQuestInfo and C_Container.GetContainerItemQuestInfo(bag, slot)
                    local _, _, _, _, _, _, _, _, _, _, price = C_Item.GetItemInfo(info.itemID)
                    things[#things + 1] = { bag = bag, slot = slot, id = info.itemID, name = info.itemName or ("item " .. info.itemID),
                        icon = info.iconFileID, link = info.hyperlink, quality = info.quality, count = info.stackCount or 1, price = price,
                        noValue = info.hasNoValue or false, locked = info.isLocked or false, hasLoot = info.hasLoot == true,
                        quest = type(quest) == "table" and (quest.isQuestItem or quest.questID ~= nil) or false }
                end
            end)
        end
    end
    return things
end

-- The player's gold, in copper.
function Adapter.MerchantMoney()
    local ok, money = pcall(GetMoney)
    return ok and tonumber(money) or 0
end

-- True when the open vendor repairs.
function Adapter.MerchantRepairs()
    local ok, can = pcall(CanMerchantRepair)
    return ok and can and true or false
end

-- The game's sale of junk: on (its Sell All Junk button shows, MF 482) and its count of junk.
function Adapter.MerchantJunk()
    local ok, on, count = pcall(function()
        return results().sellJunk and C_MerchantFrame.IsSellAllJunkEnabled(), C_MerchantFrame.GetNumJunkItems()
    end)
    return ok and on and true or false, ok and tonumber(count) or 0
end

-- The game's own words for a purchase it refuses for the money, when it has them.
function Adapter.MerchantWords()
    return { money = type(ERR_NOT_ENOUGH_MONEY) == "string" and ERR_NOT_ENOUGH_MONEY or nil }
end

-- ---------------------------------------------------------------- the steps
-- A step of the vendor: "buy" (index, amount in items), "buyback" (index), "sell" (a thing of
-- MerchantBags: only while the slot still holds that item, not locked, out of combat), "junk" (the
-- game's sale of the gray items, when it has some: the marked stacks are Auto/JunkSell.lua's),
-- "repair" (true: the guild pays), "close". True when the call ran; else false and why. The
-- game's answer comes as a change of the bags, the gold or the vendor's list.
function Adapter.MerchantDo(step, value, amount)
    local ok, why = pcall(function()
        if step == "buy" then
            BuyMerchantItem(value, amount)
        elseif step == "buyback" then
            BuybackItem(value)
        elseif step == "sell" then
            if InCombatLockdown() then
                return "a fight is on"
            end
            local now = C_Container.GetContainerItemInfo(value.bag, value.slot)
            if not (now and now.itemID == value.id) or now.isLocked then
                return "the slot holds something else now"
            end
            C_Container.UseContainerItem(value.bag, value.slot)
        elseif step == "junk" then
            Adapter.SellJunk()
        elseif step == "repair" then
            if not Adapter.RepairAll(value) then
                return "the repair call did not run"
            end
        elseif step == "close" then
            CloseMerchant()
        else
            return "no such step: " .. tostring(step)
        end
    end)
    if not ok then
        return false, tostring(why)
    end
    return why == nil, why
end

-- The game's yellow mark of an item that starts a quest, on a texture of ours: the picture its
-- vendor window puts over such an item (TEXTURE_ITEM_QUEST_BANG, Blizzard_FrameXMLBase/Constants.lua
-- 274; MF 349 to 354).
function Adapter.QuestBang(texture)
    texture:SetTexture(type(TEXTURE_ITEM_QUEST_BANG) == "string" and TEXTURE_ITEM_QUEST_BANG or "Interface\\ContainerFrame\\UI-Icon-QuestBang")
end

-- ---------------------------------------------------------------- the tooltip of a card
-- The card in focus has the game's own tooltip, in a tooltip frame of the view's own, its bottom
-- right corner at corner's (a frame of the view), 1.2 times its size as in the dialogue view. The
-- game fills it with the calls of its vendor window (MF 758 to 763). entry: a thing of one of the
-- three lists, kind: "buy", "buyback" or "sell". True when it shows.
local tip

function Adapter.MerchantTipHide()
    if tip then
        pcall(tip.Hide, tip)
    end
end

function Adapter.MerchantTip(entry, kind, corner)
    local ok, shown = pcall(function()
        tip = tip or CreateFrame("GameTooltip", "GamepadSuiteMerchantTip", UIParent, "GameTooltipTemplate")
        tip:SetOwner(UIParent, "ANCHOR_NONE")
        tip:SetScale(1.2)
        tip:ClearAllPoints()
        tip:SetPoint("BOTTOMRIGHT", corner, "BOTTOMRIGHT")
        if kind == "buy" then
            tip:SetMerchantItem(entry.index)
        elseif kind == "buyback" then
            tip:SetBuybackItem(entry.index)
        else
            tip:SetBagItem(entry.bag, entry.slot)
        end
        return tip:IsShown()
    end)
    return ok and shown and true or false
end
