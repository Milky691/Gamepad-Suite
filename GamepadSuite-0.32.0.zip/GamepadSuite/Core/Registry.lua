-- Settings as data. A setting is one entry: its kind, its default and its choices.
-- No module reads the saved table itself. A change sends the message "setting".
local _, ns = ...

local Registry = {}
ns.Registry = Registry

local defs, saved = {}, nil

function Registry.Load()
    GamepadSuiteDB = GamepadSuiteDB or {}
    GamepadSuiteDB.settings = GamepadSuiteDB.settings or {}
    saved = GamepadSuiteDB.settings
    -- Press and Hold Casting was a switch before it had three values: a saved "off" is Off, and
    -- a saved "on" is Game buttons, what "on" did then.
    local hold = saved["combat.press_and_hold"]
    if type(hold) == "boolean" then
        saved["combat.press_and_hold"] = hold and "Game buttons" or "Off"
    end
    -- Healer Mode was a switch before it had three values: off is Off, on is the start value (Wheel)
    if type(saved["combat.healer_mode"]) == "boolean" then
        saved["combat.healer_mode"] = not saved["combat.healer_mode"] and "Off" or nil
    end
    -- Form and Stance Binds was a switch before it had three values: off is Off, on is the start value
    if type(saved["layers.forms_and_stances"]) == "boolean" then
        saved["layers.forms_and_stances"] = not saved["layers.forms_and_stances"] and "Off" or nil
    end
    ns.Log.Attach(GamepadSuiteDB)
end

-- kind: "toggle" (true / false), "pick" (one of options) or "number" (options = { min = , max = })
function Registry.Define(key, kind, default, options)
    assert(not defs[key], "setting defined twice: " .. key)
    assert(kind == "toggle" or kind == "pick" or kind == "number", "unknown kind for " .. key)
    if kind == "pick" then
        assert(type(options) == "table" and #options > 0, "a pick needs options: " .. key)
    elseif kind == "number" then
        assert(type(options) == "table" and options.min and options.max, "a number needs a range: " .. key)
    end
    defs[key] = { kind = kind, default = default, options = options }
end

function Registry.Has(key)
    return defs[key] ~= nil
end

function Registry.Get(key)
    local def = assert(defs[key], "unknown setting: " .. tostring(key))
    if def.get then
        return def.get()
    end
    local value = saved and saved[key]
    if value == nil then
        return def.default
    end
    -- a saved choice from an older build that is not one of the choices any more: the start value
    if def.kind == "pick" then
        for _, option in ipairs(def.options) do
            if option == value then
                return value
            end
        end
        return def.default
    end
    return value
end

-- True when there is such a setting and it can take the value. A value from outside the addon
-- (a profile text) is asked about here first.
function Registry.Fits(key, value)
    local def = defs[key]
    if not def then
        return false
    elseif def.kind == "toggle" then
        return type(value) == "boolean"
    elseif def.kind == "number" then
        return type(value) == "number" and value >= def.options.min and value <= def.options.max
    end
    for _, option in ipairs(def.options) do
        if option == value then
            return true
        end
    end
    return false
end

function Registry.Set(key, value)
    local def = assert(defs[key], "unknown setting: " .. tostring(key))
    assert(Registry.Fits(key, value), key .. " cannot take " .. tostring(value))
    if def.set then
        def.set(value)
    elseif value == def.default then
        saved[key] = nil
    else
        saved[key] = value
    end
    ns.Send("setting", key, value)
end

-- A setting that stands for a value kept in another place (the place of the fixed slot that
-- Slot to Move names): get() gives the value and set(value) keeps it. Nothing of it is saved.
function Registry.Virtual(key, get, set)
    local def = assert(defs[key], "unknown setting: " .. tostring(key))
    def.get, def.set = get, set
end

-- Calls fn(key, default) for every setting that has a value of its own. And the saved values, as
-- they are in the file: only the ones that are not the default. Both are for profiles
-- (Core/Profiles.lua) and for Reset All Settings.
function Registry.Each(fn)
    for key, def in pairs(defs) do
        if not def.get then
            fn(key, def.default)
        end
    end
end

function Registry.Saved()
    return saved
end

-- A place for a module to keep its own saved data that is not a setting.
function Registry.Store(name)
    GamepadSuiteDB[name] = GamepadSuiteDB[name] or {}
    return GamepadSuiteDB[name]
end
