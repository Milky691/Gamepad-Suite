-- The adapter's part for Restock (Auto/Restock.lua): what a vendor sells, what the character
-- carries and wears, the call that buys, and the two questions for the class reagents (which
-- spells the character knows, and whether Reagent Economy spares the reagents).
-- The game's own vendor window reads a thing with C_MerchantFrame.GetItemInfo and buys with
-- BuyMerchantItem(index, amount). The amount counts single items, in whole lots of the vendor,
-- one stack at most in one call (Blizzard_UIPanels_Game/Mainline/MerchantFrame.lua 659 to 667
-- and 713 to 739, with Blizzard_FrameXML/Mainline/StackSplitFrame.lua 16 and 333). ForeverPlus
-- buys ammunition with the same calls on this game. The call asks the server: what came is
-- known only when the bags change.
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("restock", function()
    return C_MerchantFrame.GetItemInfo and GetMerchantNumItems and GetMerchantItemID and GetMerchantItemMaxStack
        and BuyMerchantItem and GetMoney and GetInventoryItemID and UnitLevel
        and C_Item.GetItemInfo and C_Item.GetItemInfoInstant and C_Item.GetItemSpell and C_Item.GetItemCount
        and C_Container.GetContainerNumSlots and C_Container.GetContainerItemInfo
        and C_EventUtils.IsEventValid("MERCHANT_SHOW") and C_EventUtils.IsEventValid("MERCHANT_CLOSED")
        and C_EventUtils.IsEventValid("BAG_UPDATE_DELAYED") and C_EventUtils.IsEventValid("GET_ITEM_INFO_RECEIVED") == true
end)
local results = Adapter.Results

-- The game's numbers: the class Weapon, the slot of the ranged weapon (Blizzard_FrameXMLBase/
-- Constants.lua 153), and one spell each of the many with the name "Food" and the name "Drink".
local WEAPON, RANGED, FOOD, DRINK = 2, 18, 433, 430

-- What the game says of an item: its class and subclass (known at once), its name and the
-- level it asks for (both nil until the game has loaded the item), and the name of its use
-- effect.
local function facts(id)
    local ok, _, _, _, _, _, class, sub = pcall(C_Item.GetItemInfoInstant, id)
    local got, name, _, _, _, level = pcall(C_Item.GetItemInfo, id)
    local has, spell = pcall(C_Item.GetItemSpell, id)
    return { id = id, class = ok and class or nil, sub = ok and sub or nil, name = got and name or nil,
        level = got and name and level or nil, spell = has and spell or nil }
end

-- The names of the use effects of food and of a drink, in the game's language. The English
-- names when the game does not have the two spells.
function Adapter.MealWords()
    return { food = Adapter.SpellName(FOOD) or "Food", drink = Adapter.SpellName(DRINK) or "Drink" }
end

-- Everything the open vendor sells: { index, id, name, class, sub, spell, level, price (of one
-- lot, in copper), lot (the items in one lot), stack (the most one call buys), left (lots the
-- vendor has; -1 for no limit), buyable, usable (the character can use it), extended (it costs
-- more than gold) }.
function Adapter.VendorOffers()
    local offers = {}
    pcall(function()
        for index = 1, results().restock and GetMerchantNumItems() or 0 do
            local id, info = GetMerchantItemID(index), C_MerchantFrame.GetItemInfo(index)
            if id and info then
                local offer = facts(id)
                offer.index, offer.name = index, offer.name or info.name or ("item " .. id)
                offer.price, offer.lot, offer.left = info.price or 0, info.stackCount or 0, info.numAvailable or -1
                offer.buyable, offer.usable, offer.extended = info.isPurchasable, info.isUsable, info.hasExtendedCost
                offer.stack = GetMerchantItemMaxStack(index) or 1
                offers[#offers + 1] = offer
            end
        end
    end)
    return offers
end

-- The character at the vendor: { money (copper), level, weapon = the kind of the ranged weapon
-- (nil for none), carried = the things in the bags, each with id, class, sub, spell, level and
-- count }.
function Adapter.Supplies()
    local state = { money = 0, level = 1, carried = {} }
    pcall(function()
        if not results().restock then
            return
        end
        state.money, state.level = GetMoney(), UnitLevel("player")
        local weapon = GetInventoryItemID("player", RANGED)
        local shooter = weapon and facts(weapon)
        state.weapon = shooter and shooter.class == WEAPON and shooter.sub or nil
        for bag = 0, 4 do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info and info.itemID then
                    local item = facts(info.itemID)
                    item.count = info.stackCount or 1
                    state.carried[#state.carried + 1] = item
                end
            end
        end
    end)
    return state
end

-- How many of an item are in the bags.
function Adapter.Carried(id)
    local ok, count = pcall(C_Item.GetItemCount, id)
    return ok and tonumber(count) or 0
end

-- Which of the spell numbers the character knows (the spellbook, not the level): { [number] = true }.
-- It asks the call the wheels use (AdapterWheel.lua), which reads the spellbook three ways and takes
-- any yes, passive spells too. A game that cannot answer knows none.
function Adapter.KnownSpellSet(ids)
    local set = {}
    pcall(function()
        for _, spell in ipairs(Adapter.KnownSpells(ids)) do
            set[spell.id] = true
        end
    end)
    return set
end

-- Reagent Economy: a talent of WoW Forever's Legacy Tree, "Your class abilities no longer require
-- reagents purchaseable from vendors" (spell 1225503, from ForeverPlus Data/Reagents.lua, which
-- reads the Wowhead Forever database). ForeverPlus asks whether the spell is known or an aura of
-- it is on the player, and says it has not measured which one this build shows; so both are asked.
-- The game's notes mark the aura call as secret when the player's auras are restricted (a fight,
-- UnitAuraDocumentation.lua 397): a secret answer is no answer, and the reagents are bought.
local ECONOMY = 1225503
function Adapter.ReagentEconomy()
    local ok, yes = pcall(function()
        if Adapter.KnownSpells({ ECONOMY })[1] then
            return true
        end
        local aura = C_UnitAuras.GetPlayerAuraBySpellID(ECONOMY)
        return not (issecretvalue ~= nil and issecretvalue(aura)) and aura ~= nil
    end)
    return ok and yes == true
end

-- Asks the vendor for an amount of the thing at a place of its list. True when the call ran.
function Adapter.BuyFromVendor(index, amount)
    return results().restock and (pcall(BuyMerchantItem, index, amount)) or false
end
