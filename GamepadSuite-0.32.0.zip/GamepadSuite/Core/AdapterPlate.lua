-- The adapter, the part for the party wheel of healer mode (Screen/WheelPlate.lua): what a member's
-- plate shows, and what the spell in the middle shows. The game hides many of these values from
-- addon code (its notes mark them "secret"). Such a value goes straight to a widget that takes it,
-- and nothing is compared or added with it.
local _, ns = ...

local Adapter = ns.Adapter

-- True for a value the game hides from addon code. A compare, a sum or a test with one is an error.
local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- The health of a unit, on a status bar. A bar takes the numbers as they are, hidden too
-- (SimpleStatusBarAPIDocumentation.lua 229 to 232 and 355 to 358), so nothing is done with them here.
-- The bar's colour follows the health: green at full, yellow at half, red near none, and smooth
-- between them. The game's own call gives the colour for the health in percent from a colour curve
-- (UnitDocumentation.lua 1506 to 1523, CurveUtilDocumentation.lua 11 to 19; a curve is smooth by
-- itself, Blizzard_SharedXMLBase/CurveConstants.lua 3 to 6), hidden when the health is hidden, and
-- the bar takes a hidden colour as it is (SimpleStatusBarAPIDocumentation.lua 282 to 294).
-- Gives what the colour was, for the log: "hidden", "plain" or the fault. On a fault the bar keeps
-- the colour it had.
local shades
function Adapter.ShowHealth(bar, unit)
    pcall(function()
        bar:SetMinMaxValues(0, UnitHealthMax(unit))
        bar:SetValue(UnitHealth(unit))
    end)
    local ok, how = pcall(function()
        if not shades then
            local curve = C_CurveUtil.CreateColorCurve()
            curve:AddPoint(0, CreateColor(ns.Theme.Color("red")))
            curve:AddPoint(0.5, CreateColor(0.9, 0.8, 0.2))
            curve:AddPoint(1, CreateColor(0.2, 0.8, 0.25))
            shades = curve
        end
        local r, g, b = UnitHealthPercent(unit, true, shades):GetRGB()
        bar:SetStatusBarColor(r, g, b)
        return hidden(r) and "hidden" or "plain"
    end)
    return ok and how or "a fault: " .. tostring(how)
end

-- The heals on their way to a unit, on a status bar with the scale of its health bar, up to full
-- health: the game's own count, as its raid frames read it (CompactUnitFrame.lua 1186 to 1195).
-- Gives true and the amount shown. false while the game hides one of the numbers (the notes of
-- this build mark all three as such, UnitDocumentation.lua 1269 to 1285 and 1526 to 1540): the
-- caller hides the bar then. A game with no such call gives false too, and the log says why.
local incomingFault
function Adapter.ShowIncoming(bar, unit)
    local ok, shown, amount = pcall(function()
        local health, most, coming = UnitHealth(unit), UnitHealthMax(unit), UnitGetIncomingHeals(unit)
        if hidden(health) or hidden(most) or hidden(coming) then
            return false
        end
        local amount = math.max(0, math.min(coming or 0, most - health))
        bar:SetMinMaxValues(0, most)
        bar:SetValue(amount)
        return true, amount
    end)
    if not ok and not incomingFault then
        incomingFault = tostring(shown)
        ns.Log.Add("wheel", "The heals on the way could not be read: " .. incomingFault)
    end
    return ok and shown or false, ok and amount or 0
end

-- A unit's health in percent, a whole number, on a line of text. The game gives the percent by its
-- own call, with the heals it already counts as the bar's colour has them (its default, as its raid
-- frames read both: CompactUnitFrame.lua 725 and 1101), scaled to 100 by its own curve (UnitDocumentation.lua 1506 to 1523,
-- Blizzard_SharedXMLBase/CurveConstants.lua 9 to 12), and makes the text of a whole number itself
-- (StringUtilDocumentation.lua 138 to 150). Each takes a hidden number from addon code, and so does
-- a line of text (SimpleFontStringAPIDocumentation.lua 664 to 672). A game with no such calls: the
-- numbers themselves where they are not hidden, else no text. Gives what was shown, for the log:
-- "hidden" (the game's own text of a hidden number), "plain", "none", or the fault.
function Adapter.ShowPercent(text, unit)
    local ok, how = pcall(function()
        if UnitHealthPercent and C_StringUtil and C_StringUtil.RoundToNearestString and CurveConstants then
            local value = C_StringUtil.RoundToNearestString(UnitHealthPercent(unit, true, CurveConstants.ScaleTo100))
            text:SetText(value)
            return hidden(value) and "hidden" or "plain"
        end
        local health, most = UnitHealth(unit), UnitHealthMax(unit)
        if hidden(health) or hidden(most) or most <= 0 then
            text:SetText("")
            return "none"
        end
        text:SetText(tostring(math.floor(health * 100 / most + 0.5)))
        return "plain"
    end)
    if not ok then
        pcall(text.SetText, text, "")
    end
    return ok and how or "a fault: " .. tostring(how)
end

-- Is a member in reach of the spell or the item of a party wheel (kind "spell" or "item", id its
-- number). The game's answer for that very spell first (true, false, or nil when it cannot tell:
-- SpellDocumentation.lua 948 to 963). Where it cannot tell, the game's own party range, as its raid
-- frames use it (UnitInRange: CompactUnitFrame.lua 1044 to 1067), which it can hide. A member out of
-- reach is dimmed and gray: a plain answer dims the whole picture and grays the portrait (art); a
-- hidden answer dims it by the game's own call for that (SetAlphaFromBoolean,
-- SimpleFrameAPIDocumentation.lua 1145 to 1155). No answer: as in reach. A cast at a member out of
-- reach just fails, so the picture can still be chosen. gone: the member is offline or dead (its
-- portrait is gray whatever the reach). A plate of a raid group not in use has a dim of its own
-- (cell.dim, Screen/WheelRaid.lua): out of reach it keeps that dim and turns gray, as 0.35 of an already
-- dim plate would be near invisible. Gives the answer in words, for the log.
local DIM = 0.35
function Adapter.ShowReach(cell, art, kind, id, unit, gone)
    gone = gone == true
    local dim = cell.dim or 1
    local far = cell.dim and dim or DIM
    local ok, said = pcall(function()
        local from = kind == "item" and "the item" or "the spell"
        local inRange = (kind == "item" and C_Item.IsItemInRange or C_Spell.IsSpellInRange)(id, unit)
        if not hidden(inRange) and inRange == nil then
            -- (a hidden answer is never tested: it goes to the picture as it is)
            local near, checked = UnitInRange(unit)
            from = "the party range"
            if hidden(near) or not hidden(checked) and checked then
                inRange = near
            end
        end
        if hidden(inRange) then
            cell:SetAlphaFromBoolean(inRange, dim, far)
            art:SetDesaturated(gone)
            return from .. " hidden"
        end
        local out = inRange == false
        cell:SetAlpha(out and far or dim)
        art:SetDesaturated(out or gone)
        return from .. " " .. tostring(inRange)
    end)
    if not ok then
        cell:SetAlpha(dim)
        art:SetDesaturated(gone)
    end
    return ok and said or "a fault: " .. tostring(said)
end

-- A unit's raid target mark, on a texture: the game's own sheet of the eight marks, and the game
-- puts the mark's number into a cell of it itself (SetSpriteSheetCell takes a hidden number from
-- addon code, SimpleTextureBaseAPIDocumentation.lua 565 to 577; the game's target frame does the
-- same, Blizzard_UnitFrame/Mainline/TargetFrame.lua 688 to 692). No mark: the texture hides.
-- Gives the mark, "none", "hidden" or the fault, for the log.
local MARKS = "Interface\\TargetingFrame\\UI-RaidTargetingIcons"
function Adapter.ShowMark(texture, unit)
    local ok, said = pcall(function()
        local index = GetRaidTargetIndex(unit)
        if not hidden(index) and not index then
            texture:Hide()
            return "none"
        end
        texture:SetTexture(MARKS)
        texture:SetSpriteSheetCell(index, 4, 4)
        texture:Show()
        return hidden(index) and "hidden" or tostring(index)
    end)
    if not ok then
        texture:Hide()
    end
    return ok and said or "a fault: " .. tostring(said)
end

-- A unit's name on a line of text, as the game gives it, with no realm. The game can hide a name from
-- addon code (UnitDocumentation.lua 2489 to 2504); a line of text takes it as it is
-- (SimpleFontStringAPIDocumentation.lua 664 to 672), and it is never read here. The line has a
-- width and no second line, so the game itself cuts a long name to fit (its raid frames do the same,
-- CompactUnitFrame.lua 858). Gives the colour of the unit's class as the game's raid frames colour a
-- name (RAID_CLASS_COLORS, CompactUnitFrame.lua 866 to 874), or nil while the game hides the class;
-- and "hidden", "plain" or the fault, for the log.
function Adapter.ShowName(text, unit)
    local ok, color, how = pcall(function()
        local name = UnitName(unit)
        text:SetText(name)
        local _, class = UnitClass(unit)
        return not hidden(class) and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class] or nil, hidden(name) and "hidden" or "plain"
    end)
    return ok and color or nil, ok and how or "a fault: " .. tostring(color)
end

-- A member that a spell cannot reach now, in the game's own word, as its raid frames show it in place
-- of the health (CompactUnitFrame.lua 1095 to 1100: offline first, then dead or a ghost): PLAYER_OFFLINE
-- ("Offline") or DEAD ("Dead"). nil for a member who is there and alive. Neither answer is hidden in
-- this build (UnitDocumentation.lua 1855 to 1866, 1931 to 1942); one that is counts as there and alive.
-- A hunter who feigns death is dead to the game's call, and to its raid frames (CompactUnitFrame.lua 1097):
-- here it has the name of the spell, Feign Death, and stays a live member (UnitIsFeignDeath is plain,
-- UnitDocumentation.lua 1962 to 1974). Second answer: "offline", "feign" or "dead".
local FEIGN = 5384      -- Feign Death
function Adapter.MemberState(unit)
    local ok, word, how = pcall(function()
        local on, dead = UnitIsConnected(unit), UnitIsDeadOrGhost(unit)
        if not hidden(on) and on == false then
            return PLAYER_OFFLINE or "Offline", "offline"
        elseif not hidden(dead) and dead then
            local feign = UnitIsFeignDeath and UnitIsFeignDeath(unit)
            if feign and not hidden(feign) then
                return C_Spell.GetSpellName(FEIGN) or "Feign Death", "feign"
            end
            return DEAD or "Dead", "dead"
        end
    end)
    if ok then
        return word, how
    end
end

-- The game's own mark of a resurrection on its way to a dead member, on a texture, as its raid frames
-- draw it at INCOMING_RESURRECT_CHANGED (CompactUnitFrame.lua 153 to 154, 1411 to 1414, 1473; the call is
-- in the game's code and not in the notes). Gives "true", "false", "hidden" or the fault, for the log.
function Adapter.ShowRez(texture, unit)
    local ok, said = pcall(function()
        local coming = UnitHasIncomingResurrection(unit)
        if hidden(coming) or not coming then
            texture:Hide()
            return hidden(coming) and "hidden" or "false"
        end
        texture:SetAtlas("RaidFrame-Icon-Rez")
        texture:Show()
        return "true"
    end)
    if not ok then
        texture:Hide()
    end
    return ok and said or "a fault: " .. tostring(said)
end

-- Who has the aggro, on a member's edge: UnitThreatSituation (UnitDocumentation.lua 3278 to 3294) gives 2
-- (tanking, others close) or 3 (tanking), in the game's colour for that state (ThreatDocumentation.lua 10 to
-- 24); 0 and 1 are no aggro, as on the game's raid frames (CompactUnitFrame.lua 599 to 626, 907 to 932),
-- which also show none while the player is in no group. A hidden answer (a query of one unit is "generally
-- not secret", SecretPredicatesDocumentation.lua 155 to 158) is never tested: no edge. Gives "plain" and the
-- state, "hidden", "no group" or the fault, for the log.
function Adapter.ShowThreat(texture, unit)
    local ok, said = pcall(function()
        if UnitInParty("player") == false then
            texture:Hide()
            return "no group"
        end
        local state = UnitThreatSituation(unit)
        if hidden(state) then
            texture:Hide()
            return "hidden"
        end
        texture:SetShown(state == 2 or state == 3)
        if state == 2 or state == 3 then
            texture:SetVertexColor(GetThreatStatusColor(state))
        end
        return "plain " .. tostring(state)
    end)
    if not ok then
        texture:Hide()
    end
    return ok and said or "a fault: " .. tostring(said)
end

-- How far the spell of a party wheel reaches, in yards (its own data, SpellDocumentation.lua 1191 to 1192), or
-- nil: an item, or a spell the game tells nothing of.
function Adapter.ReachYards(kind, id)
    local ok, info = pcall(C_Spell.GetSpellInfo, id)
    return kind == "spell" and ok and type(info) == "table" and info.maxRange or nil
end

-- A unit's group role, on a texture: the game's own word for it (UnitGroupRolesAssigned, as its
-- raid frames read it: Blizzard_CompactRaidFrames/Classic/Blizzard_CompactRaidFrameManager.lua
-- 582) and the game's own small picture for that role (GetMicroIconForRole: tank, healer, damage,
-- Blizzard_SharedXMLBase/TextureUtil.lua 185 to 200, as its raid frames show it). No role, or one
-- the game hides: no picture. Gives the role (and if the game had no picture for it), "hidden"
-- or the fault, for the log.
local ROLES = { TANK = true, HEALER = true, DAMAGER = true }
function Adapter.ShowRole(texture, unit)
    local ok, said = pcall(function()
        local role = UnitGroupRolesAssigned(unit)
        if hidden(role) or not ROLES[role] then
            texture:Hide()
            return hidden(role) and "hidden" or tostring(role)
        end
        -- (the game says false for a picture it does not have: the log tells)
        local drawn = texture:SetAtlas(GetMicroIconForRole(role))
        texture:Show()
        return role .. (drawn == false and ", the game has no picture for it" or "")
    end)
    if not ok then
        texture:Hide()
    end
    return ok and said or "a fault: " .. tostring(said)
end

-- The player's own buffs on a unit, on the textures given (one each, in the game's order, as many as there are
-- textures): the helpful auras that the player cast, by the game's own filter for them (HELPFUL and PLAYER:
-- Blizzard_FrameXMLUtil/AuraUtil.lua 270 to 275), with the game's own picture of each. In a restricted fight the
-- game hides a unit's auras from addon code (UnitAuraDocumentation.lua 208 to 224: SecretWhenUnitAuraRestricted):
-- a hidden aura or picture is never read or tested, and does not show. Gives how many show, and "hidden" (the game
-- hid one), "plain" or the fault, for the log.
function Adapter.ShowMyBuffs(textures, unit)
    local ok, count, how = pcall(function()
        local count, how = 0, "plain"
        -- (the game's answers end at the first empty place; 40 is only a bound for the loop)
        for index = 1, 40 do
            local aura = C_UnitAuras.GetAuraDataByIndex(unit, index, "HELPFUL|PLAYER")
            if hidden(aura) then
                return count, "hidden"
            elseif aura == nil or count == #textures then
                break
            elseif hidden(aura.icon) then
                how = "hidden"
            else
                count = count + 1
                textures[count]:SetTexture(aura.icon)
                textures[count]:Show()
            end
        end
        return count, how
    end)
    local shown = ok and count or 0
    for i = shown + 1, #textures do
        textures[i]:Hide()
    end
    return shown, ok and how or "a fault: " .. tostring(count)
end

-- The game's own aura box on a plate. In a fight the game hides a unit's auras from addon code (the notes of
-- this build: UnitAuraDocumentation.lua 207 to 213), but it draws them itself on a frame it is given, in a
-- fight too: its raid frames hand each member's frame to its secure addon Blizzard_PrivateAurasUI as a
-- "container" (CompactUnitFrame.lua 2218 to 2240, 2293 to 2326; C_UnitAuras.AddPrivateAuraAnchor,
-- UnitAuraDocumentation.lua 40 to 50, its args UnitConstantsDocumentation.lua 6 to 17). That addon reads the
-- frame's attributes (Blizzard_PrivateAurasUI.lua 329 to 365), puts its own aura pictures on the frame and
-- keeps them right at each UNIT_AURA (697 to 764). Nothing of it is read here. Two boxes on a plate:
--   "buffs": the player's own buffs, four at most in one row from the box's top right, 3 units in (the
--     organization BuffsTopDebuffsBottom, 1, Blizzard_PrivateAurasUI.lua 911 to 919). The game shows a buff
--     there when the player cast it, or when the spell's own data says so (AuraUtil.lua 437 to 448);
--   "mark": the mark of a debuff the player can remove (canActivePlayerDispel, Blizzard_PrivateAurasUI.lua
--     419 to 433), the game's own 14-unit picture at the box's top left, 3 in and 2 down (BuffsRightDebuffsLeft,
--     2, 968 to 971), with no coloured cover on the plate (overlay type 0, 1353 to 1385).
-- The numbers of the game's lists: EditModeManagerConstantsDocumentation.lua 946 to 982. size: a buff's side.
-- Gives the anchor's number, or nil and why.
local BOX = {
    buffs = { ["max-buffs"] = 4, ["max-dispel-debuffs"] = 0, ["aura-organization-type"] = 1, ["ignore-buffs"] = false, ["dispel-indicator-option"] = 0 },
    mark = { ["max-buffs"] = 0, ["max-dispel-debuffs"] = 1, ["aura-organization-type"] = 2, ["ignore-buffs"] = true, ["dispel-indicator-option"] = 1 },
}
local SAME = { ["max-debuffs"] = 0, ["ignore-debuffs"] = true, ["ignore-dispel-debuffs"] = true, ["display-only-dispellable-debuffs"] = false,
    ["dispel-indicator-overlay-type"] = 0, ["dispel-indicator-overlay-animation"] = false, ["dispel-indicator-animated-border"] = false,
    ["display-larger-role-specific-debuffs"] = false, ["show-big-defensive"] = false, ["always-hide-duration"] = true,
    ["set-aura-size-to-icon-size"] = true, ["power-bar-used-height"] = 0 }
function Adapter.AddAuraBox(frame, unit, kind, size)
    local ok, id = pcall(function()
        for _, list in ipairs({ SAME, BOX[kind] }) do
            for key, value in pairs(list) do
                frame:SetAttribute(key, value)
            end
        end
        for _, key in ipairs({ "buff-size", "debuff-size", "big-defensive-size" }) do
            frame:SetAttribute(key, size)
        end
        -- (the game wants a place for one picture also for a box, and never uses it: CompactUnitFrame.lua 2268 to 2283)
        local place = { point = "BOTTOMLEFT", relativeTo = frame, relativePoint = "BOTTOMLEFT", offsetX = 0, offsetY = 0 }
        return C_UnitAuras.AddPrivateAuraAnchor({ unitToken = unit, auraIndex = 1, parent = frame, showCooldownFrame = false, showCooldownEdge = false,
            showCountdownNumbers = false, showDispelIcon = false, isContainer = true, iconInfo = { iconAnchor = place, iconWidth = size, iconHeight = size } })
    end)
    if not ok then
        return nil, tostring(id)
    end
    return id, id == nil and "the game gave no anchor" or nil
end

-- The box goes: the game takes its pictures off the frame (UnitAuraDocumentation.lua 543 to 551).
function Adapter.RemoveAuraBox(id)
    pcall(C_UnitAuras.RemovePrivateAuraAnchor, id)
end
