-- The adapter's part for the on-screen keyboard (Screen/Keyboard.lua): the game's chat text box.
-- The login check for all of it is chatBox (Adapter.lua).
--
-- The keyboard hears that the chat box took or lost the focus, and reads the box. It never
-- writes into it, and never sends or closes it. A text put into the box from addon code runs the
-- box's own scripts as addon code: OnTextChanged writes the box's fields ignoreTextChange,
-- lastTabComplete, tabCompleteText and tabCompleteTableIndex, and ParseText runs the game's chat
-- command code (Blizzard_ChatFrameBase/Shared/ChatFrameEditBox.lua 214 to 289 and 473 to 492).
-- The game's next own change of the box reads those fields at line 475: its send (A, lines 416
-- to 440) or its close empties the box with SetText (ClearChat, lines 548 to 558), so the rest
-- of that send or close runs as this addon: the hide, the hand-off of the controller to the
-- next window (ChatFrameUtil.lua 549 to 555, FrameControlsManager.lua 482 to 555) and the
-- binds it sets again. The game then blocks its own next protected call there and names this
-- addon ("Gamepad Suite has been blocked from an action only available to the Blizzard UI").
-- 0.15.0 wrote each letter into the box, and the game froze in that window code.
--
-- So a finished chat line goes to the game the way a macro line does: it is put on a secure
-- button of ours, and the press of Done clicks that button through a key bind. The game runs
-- the line as its own code in a chat box of its own (Blizzard_FrameXML/SecureTemplates.lua 450
-- to 464, Blizzard_ChatFrameBase/Shared/MacroExecutionManager.lua 19 to 28), with chat commands
-- read as from a typed line (ChatFrameEditBox.lua 214 to 321). The quick chat wheel sends its
-- lines this way, and in the game they came back. That chat box of its own takes the channel of
-- the game's first chat box (DEFAULT_CHAT_FRAME), not of the box that is open: with the "IM"
-- chat style the open box can be another one (ChatFrameUtil.lua 557 to 568), so a line for
-- another box gets that box's chat command in front (see line below).
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- The game's own messages for its chat text box. Each comes with the box
-- (Blizzard_ChatFrameBase/Shared/ChatFrameEditBox.lua 384 to 414). ControllerForever's notes say
-- that the box can keep the focus after it hides, so a hide counts as a loss of the focus too.
-- The game calls a listener through securecallfunction (Blizzard_SharedXMLBase/
-- CallbackRegistry.lua 198 to 214), so what a listener of ours does stays out of its chat code.
local GAINED = "ChatFrame.OnEditBoxFocusGained"
local LOST = { "ChatFrame.OnEditBoxFocusLost", "ChatFrame.OnEditBoxHide" }
local OWNER = {}

-- The most letters of a chat line (Blizzard_ChatFrameBase/Mainline/ChatFrameEditBox.xml 3).
Adapter.CHAT_MOST = 255

-- Tells gained(box) when a chat text box takes the focus, and lost(box) when it loses it or
-- hides. The game calls them from inside its own chat code: they must only take note, and do
-- their work one frame later. False when this game has no such messages.
function Adapter.OnChatBox(gained, lost)
    if not results().chatBox then
        return false
    end
    EventRegistry:RegisterCallback(GAINED, function(_, box) gained(box) end, OWNER)
    for _, message in ipairs(LOST) do
        -- one listener for each message: an owner has one for a message
        EventRegistry:RegisterCallback(message, function(_, box) lost(box) end, OWNER)
    end
    return true
end

-- What the chat box shows now: where the line goes ("Say:", "Party:", "To Name:") and the line.
-- Only read: nothing of the box runs.
function Adapter.ChatLine(box)
    local ok, title, text = pcall(function()
        return box.header:GetText(), box:GetText()
    end)
    return ok and title and title:match("^%s*(.-)%s*$") or "", ok and text or ""
end

-- Where the chat box `box` sends a line: its chat type ("SAY", "WHISPER", "CHANNEL"...), its whisper
-- name and its channel number, read with the box's own getters. Nothing when the box cannot be read.
function Adapter.ChatBoxKind(box)
    local ok, kind, tell, channel = pcall(function()
        return box:GetChatType(), box:GetTellTarget(), box:GetChannelTarget()
    end)
    if ok then
        return kind, tell, channel
    end
end

-- The button that sends a chat line: a click runs its line as a macro line, when the key goes
-- down (the press of Done). ran(text) is told after each click, for the log. Made out of a fight.
function Adapter.ChatSender(name, ran)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    button:RegisterForClicks("AnyDown")
    button:SetAttribute("useOnKeyDown", true)
    button:SetAttribute("type", "macro")
    button:HookScript("PostClick", function(self)
        ran(self:GetAttribute("macrotext"))
    end)
    return button
end

-- The macro line that sends text where the chat box `box` shows. A line that starts with "/" is
-- the player's own command, as typed. For the game's first chat box the plain line goes to its
-- channel, its whisper name and its channel number (MacroExecutionManager.lua 22 to 25). A line
-- for another box, and a line that starts with "#" (the game's macro code skips such a line, as
-- it skips "#showtooltip"), get the chat command of the box's channel in front, as the game
-- names it: SLASH_<chat type>1 is how it reads a command back as a channel (ChatFrameUtil.lua
-- 794 to 813, ChatFrameEditBox.lua 142 to 203). nil when that channel has no chat command (a
-- Battle.net whisper in another box): the line is then not sent anywhere else.
local function line(box, text)
    local first = DEFAULT_CHAT_FRAME and DEFAULT_CHAT_FRAME.editBox
    if text:find("^/") or (box == first and not text:find("^%s*#")) then
        return text
    end
    local kind, tell, channel = Adapter.ChatBoxKind(box)
    local slash = type(kind) == "string" and _G["SLASH_" .. kind .. "1"]
    if kind == "WHISPER" then
        slash = type(slash) == "string" and type(tell) == "string" and tell ~= "" and slash .. " " .. tell
    elseif kind == "CHANNEL" then
        slash = type(channel) == "number" and channel > 0 and "/" .. channel
    end
    return type(slash) == "string" and slash:find("^/") and slash .. " " .. text or nil
end

-- Puts the line for the chat box `box` on the button for this press of ourKey (our name for a
-- button: "MN", "A"). prefix is the chat command of a channel the player picked on the keyboard
-- ("/p", "/w Bob"): it goes in front of a line that is no command, in place of the box's channel.
-- True when that key clicks the button now and the button has the line, and then the chat command
-- put in front of the line ("" for none). Else false and why. Not with Shift, Ctrl or Alt down (LT
-- is one in most games): the game then runs the key's bind for that modifier, not the plain key's.
-- Out of a fight only: the game locks a secure button in one.
function Adapter.ChatToSend(button, ourKey, text, box, prefix)
    local click = "CLICK " .. button:GetName() .. ":LeftButton"
    if InCombatLockdown() then
        return false, "in combat"
    elseif IsModifierKeyDown and IsModifierKeyDown() then
        return false, "LT or another Shift, Ctrl or Alt was held"
    elseif GetBindingAction(Adapter.KEY[ourKey], true) ~= click then
        return false, "another bind is on that key"
    end
    local macro = prefix and not text:find("^/") and prefix .. " " .. text or line(box, text)
    if not macro then
        return false, "the chat box's channel has no chat command"
    elseif not (pcall(button.SetAttribute, button, "macrotext", macro) and button:GetAttribute("macrotext") == macro) then
        return false, "the game refused the line"
    end
    return true, macro:sub(1, #macro - #text):match("^(%S*)")
end

-- True while the player's hands are on the controller: a button is down, or the right stick is
-- pushed (a wheel uses its entry when that stick is let go, with the stick still on its way
-- back). The left stick does not count: it walks the character, whoever opens the chat box.
function Adapter.PadInUse()
    for _, down in pairs(Adapter.PadState()) do
        if down then
            return true
        end
    end
    local x, y = Adapter.RightStick()
    return x * x + y * y > 0.3 * 0.3
end

-- ---------------------------------------------------------------- the channel row and whisper names
-- The keyboard's channel row (Screen/KeyboardChannels.lua) asks the game what works now: the group, a
-- guild, the last whisper (ChatFrameUtil.lua 620 to 628, as the game's own /r reads it), the numbered
-- channels the player is in (GetChannelList: number, name, and true when the channel is off here, as
-- Blizzard_ProfessionsCrafting.lua 368 to 374 reads it). Whisper names come from the group, the friend
-- list and the guild's online members; the word guesses offer the same names (Screen/KeyboardNames.lua).
-- Only read; nothing is sent from here.
Adapter.Check("chatFlow", function()
    return GetChannelList and IsInGuild and IsInGroup and IsInRaid and GetNumGroupMembers and UnitName
        and ChatFrameUtil.GetLastTellTarget and C_FriendList.GetNumFriends and C_FriendList.GetFriendInfoByIndex
        and C_GuildInfo.GuildRoster
end)

-- The game's first chat command of each channel the row can offer (a game in another language has
-- its own words here).
local SLASH = {
    say = "SLASH_SAY1", party = "SLASH_PARTY1", raid = "SLASH_RAID1", instance = "SLASH_INSTANCE_CHAT1",
    guild = "SLASH_GUILD1", yell = "SLASH_YELL1", whisper = "SLASH_WHISPER1", reply = "SLASH_REPLY1",
}

-- A name from the game that can be shown and whispered: a plain text, not hidden ("secret").
local function plain(name)
    if issecretvalue and issecretvalue(name) then
        return nil
    end
    return type(name) == "string" and name ~= "" and name or nil
end

-- { slash = { say = "/s", ... }, group, guild, lastTell, channels = { { number, name } } } for the
-- channel row, or nil on a game build without these calls (the row then has Close alone).
function Adapter.ChatFacts()
    if not results().chatFlow then
        return nil
    end
    local facts = { slash = {}, channels = {} }
    for id, global in pairs(SLASH) do
        local text = _G[global]
        if type(text) == "string" and text:find("^/%S+$") then
            facts.slash[id] = text
        end
    end
    facts.group = Adapter.ChatGroup()
    pcall(function()
        facts.guild = IsInGuild() and true or false
        facts.lastTell = plain(ChatFrameUtil.GetLastTellTarget())
        local list = { GetChannelList() }
        for i = 1, #list, 3 do
            local name = plain(list[i + 1])
            if type(list[i]) == "number" and name and not list[i + 2] then
                facts.channels[#facts.channels + 1] = { number = list[i], name = name }
            end
        end
    end)
    return facts
end

-- A guild member's status, the 10th value of GetGuildRosterInfo (Core/AdapterGameWindows.lua GuildOnline gives
-- it): not in the game's notes, so both shapes count: 1 or a text with AFK is away, 2 or one with DND is busy. A
-- value the game hides is no status.
local function away(value)
    if issecretvalue and issecretvalue(value) then
        return nil
    elseif value == 1 or type(value) == "string" and value:find("AFK") then
        return "away"
    elseif value == 2 or type(value) == "string" and value:find("DND") then
        return "busy"
    end
end

-- One line for the log, once a session: what the game gave as that value, for the owner's file.
local toldGuild = false
local function tellGuild(status)
    if toldGuild or type(status) ~= "table" or status[1] == nil then
        return
    end
    toldGuild = true
    local seen, out = {}, {}
    for _, value in ipairs(status) do
        local word = issecretvalue and issecretvalue(value) and "hidden" or (type(value) == "string" and "text " or type(value) .. " ") .. tostring(value)
        if not seen[word] and word ~= "number 0" then
            seen[word], out[#out + 1] = true, word
        end
    end
    ns.Log.Add("keyboard", "the guild roster's 10th value reads: " .. (out[1] and table.concat(out, ", ") or "number 0 only"))
end

-- The names a whisper can go to, and the word guesses offer: { me, group = { }, friends = { }, guild = { },
-- hidden, state = { [name] = "away" or "busy" } }; the friends and the guild members who are in the game now.
-- state: a friend's afk or dnd (FriendListDocumentation.lua 648 to 664), a guild member's roster status. A member of another realm is
-- "Name-Realm"; the realm of the player's own realm is left off (UnitName gives none for it, and the game's
-- Ambiguate drops it from a friend's or a guild member's name). UnitName is marked as a call that can give a
-- hidden ("secret") value in some moments (SecretWhenUnitNameIdentityRestricted, UnitDocumentation.lua):
-- a person whose name or realm is hidden is skipped, and hidden counts them.
function Adapter.ChatNames()
    local out = { group = {}, friends = {}, guild = {}, hidden = 0, state = {} }
    if not results().chatFlow then
        return out
    end
    -- a text from the game, or nil; true when the game hid it
    local function read(value)
        if issecretvalue and issecretvalue(value) then
            return nil, true
        end
        return type(value) == "string" and value ~= "" and value or nil
    end
    -- the name to list for a person, or nil (and counted when the game hid it)
    local function listed(name, hidden)
        if hidden then
            out.hidden = out.hidden + 1
        end
        return not hidden and name or nil
    end
    pcall(function()
        out.me = plain(UnitName("player"))
        local raid, count = IsInRaid(), GetNumGroupMembers()
        for i = 1, raid and count or count - 1 do
            local name, realm = UnitName((raid and "raid" or "party") .. i)
            local first, hiddenName = read(name)
            local second, hiddenRealm = read(realm)
            local person = listed(first, hiddenName or hiddenRealm)
            out.group[#out.group + 1] = person and second and person .. "-" .. second or person
        end
        for i = 1, C_FriendList.GetNumFriends() do
            local info = C_FriendList.GetFriendInfoByIndex(i)
            if info and info.connected then
                local name = listed(read(info.name))
                name = name and Ambiguate and Ambiguate(name, "none") or name
                out.friends[#out.friends + 1] = name
                if name then
                    out.state[name] = info.afk == true and "away" or info.dnd == true and "busy" or nil
                end
            end
        end
        local list, status = Adapter.GuildOnline()
        for i, full in ipairs(list) do
            local name = listed(read(full))
            name = name and Ambiguate and Ambiguate(name, "none") or name
            out.guild[#out.guild + 1] = name
            if name and status and not out.state[name] then
                out.state[name] = away(status[i])
            end
        end
        tellGuild(status)
    end)
    return out
end

-- Asks the game for a new list of the guild's members, as the game's own name completion does
-- (Blizzard_AutoComplete/AutoComplete.lua 140 to 148); the answer comes later (GUILD_ROSTER_UPDATE), and the
-- whisper list and the name guesses read it when it comes. C_GuildInfo.GuildRoster has no restriction in the
-- game's notes. The game asks when a window shows (FriendsFrame.lua 393) and again only when the event says
-- canRequestRosterUpdate (AutoComplete.lua 143, FriendsFrame.lua 1093 to 1097). Here: once when a chat line
-- opens, never in answer to the event (the answer is an event too: that would loop), and not twice within
-- GUILD_WAIT seconds, as a guard for a player who opens the chat box again and again.
local GUILD_WAIT = 10
local askedAt
function Adapter.AskGuildList()
    if results().chatFlow then
        pcall(function()
            if IsInGuild() and (not askedAt or GetTime() - askedAt >= GUILD_WAIT) then
                askedAt = GetTime()
                C_GuildInfo.GuildRoster()
            end
        end)
    end
end
