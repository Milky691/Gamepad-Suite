-- The log. Every caught error and every action the game blocked is kept, with a count.
local ADDON, ns = ...

local Log = {}
ns.Log = Log

local MAX_LINES = 300
local lines, counts = {}, {}

function Log.Attach(saved)
    saved.log = saved.log or {}
    saved.errorCounts = saved.errorCounts or {}
    for _, line in ipairs(lines) do
        saved.log[#saved.log + 1] = line
    end
    for key, n in pairs(counts) do
        saved.errorCounts[key] = (saved.errorCounts[key] or 0) + n
    end
    lines, counts = saved.log, saved.errorCounts
    while #lines > MAX_LINES do
        table.remove(lines, 1)
    end
end

function Log.Add(kind, text)
    lines[#lines + 1] = date("%H:%M:%S") .. " [" .. kind .. "] " .. tostring(text)
    if #lines > MAX_LINES then
        table.remove(lines, 1)
    end
end

function Log.Error(owner, err)
    local key = owner .. ": " .. tostring(err)
    counts[key] = (counts[key] or 0) + 1
    Log.Add("error", key .. " (x" .. counts[key] .. ")")
end

function Log.Lines()
    return lines
end

function Log.ErrorCount()
    local total = 0
    for _, n in pairs(counts) do
        total = total + n
    end
    return total
end

local function blocked(kind)
    return function(addon, call)
        if addon == ADDON then
            Log.Error("blocked", kind .. " " .. tostring(call))
        end
    end
end

ns.On("ADDON_ACTION_BLOCKED", "Log", blocked("ADDON_ACTION_BLOCKED"))
ns.On("ADDON_ACTION_FORBIDDEN", "Log", blocked("ADDON_ACTION_FORBIDDEN"))
