-- The adapter, the part for the bind Voice Transcription (Auto/VoiceText.lua): the game's own calls that its Chat
-- Channels window makes to turn the transcription of a voice channel on and off (build 1.60.1.70425,
-- Blizzard_ChatFrame/Shared/VoiceChatTranscriptionButton.lua 80 to 97), and the same checks it makes before it
-- offers that (180 to 195): no Discord voice, transcription allowed, the game's setting speechToText on, and a voice
-- channel in use. The game has no key bind for it: its window offers RB while it has the controller
-- (Blizzard_Channels/Mainline/ChannelFrame.lua 151 to 178).
local _, ns = ...
local Adapter = ns.Adapter

Adapter.Check("voiceText", function()
    return C_VoiceChat ~= nil and C_VoiceChat.ActivateChannelTranscription ~= nil and C_VoiceChat.DeactivateChannelTranscription ~= nil
        and C_VoiceChat.IsTranscribing ~= nil and C_VoiceChat.IsTranscriptionAllowed ~= nil and C_VoiceChat.GetActiveChannelID ~= nil
end)

-- Why the transcription cannot change now ("allowed", "setting" or "channel"), or nil, the voice channel in use and
-- whether it is transcribed now.
function Adapter.VoiceText()
    local discord = C_VoiceChat.GetActiveVoiceProviderID and Enum and Enum.VoiceProviderID
        and C_VoiceChat.GetActiveVoiceProviderID() == Enum.VoiceProviderID.Discord
    if discord or not C_VoiceChat.IsTranscriptionAllowed() then
        return "allowed"
    elseif not GetCVarBool("speechToText") then
        return "setting"
    end
    local channel = C_VoiceChat.GetActiveChannelID()
    if not channel then
        return "channel"
    end
    return nil, channel, C_VoiceChat.IsTranscribing() and true or false
end

-- Turns the transcription of a voice channel on or off.
function Adapter.SetVoiceText(channel, on)
    if on then
        C_VoiceChat.ActivateChannelTranscription(channel)
    else
        C_VoiceChat.DeactivateChannelTranscription(channel)
    end
end

-- Voice to text on the chat keyboard (Screen/KeyboardVoice.lua): the open microphone while LB is held. The game's
-- push-to-talk key cannot be pressed by an addon; the way to talk can be set (Blizzard_Channels/Classic/
-- VoiceChatPrompt.lua 50 to 57 reads the same two ways).
Adapter.Check("voiceTalk", function()
    return C_VoiceChat ~= nil and C_VoiceChat.SetCommunicationMode ~= nil and C_VoiceChat.GetCommunicationMode ~= nil
        and C_VoiceChat.IsMuted ~= nil and Enum ~= nil and Enum.CommunicationMode ~= nil and Enum.CommunicationMode.OpenMic ~= nil
end)

function Adapter.VoiceMuted()
    return C_VoiceChat.IsMuted() and true or false
end

-- on: opens the microphone and gives the way to talk it had. Not on: puts that way (before) back.
function Adapter.VoiceTalk(on, before)
    local open = Enum.CommunicationMode.OpenMic
    if on then
        local mode = C_VoiceChat.GetCommunicationMode()
        if mode ~= open then
            C_VoiceChat.SetCommunicationMode(open)
        end
        return mode
    elseif before ~= nil and before ~= open then
        C_VoiceChat.SetCommunicationMode(before)
    end
end

-- True when a voice line (CHAT_MSG_VOICE_TEXT) is the player's own: the name with or without its realm. A line that
-- the game hides from addons is never read.
function Adapter.IsMyVoiceLine(text, name)
    if issecretvalue and (issecretvalue(text) or issecretvalue(name)) then
        return false
    end
    local me = UnitName("player")
    return type(text) == "string" and text ~= "" and type(name) == "string" and (name == me or name:match("^([^%-]+)%-") == me)
end
