-- The hands: what the character holds, and the three things the addon does with it.
--   The bind "Fishing Pole". A press puts the fishing pole from the bags in the hands. The next
--   press puts back the weapons the character had, main hand and off hand. It is one chat command
--   text, and the game itself reads what is in the hands at the press, so it works in a fight. A
--   character that had no weapon gets the pole put in the bags (out of a fight).
--   A hold of it, the suite's one hold (1 second, let go within 2.5, Screen/RollsModel.lua HOLD and
--   LIMIT; the bar of every hold fills on its on-screen button), puts the best lure of the bags on
--   the pole, while the pole in the hands has none, out of a fight. While the pole is in the hands,
--   out of a fight, the press waits for the let-go: a tap is the weapons, a hold is the lure, and a
--   hold that cannot put one on does nothing and says why once (a lure is on, none in the bags).
--   With no pole at all the press says so once.
--   The Interact button casts Fishing while a pole is in the hands, and takes the bobber while the
--   line is out.
--   The Interact button starts the attack when the target is an enemy: the wand for a character
--   that has one on, Auto Shot for a hunter, the melee attack for every other character.
-- The bind core (Core/BindCore.lua) puts the texts on its secure buttons, out of a fight. Which
-- button is the Interact button, and when each job has it, is in Core/BindPlan.lua and
-- Core/BindSecure.lua.
local _, ns = ...

local Hands = ns.Module("Hands", { "secure", "hands" }, "Fishing Pole")
ns.Hands = Hands

local POLE_ICON = "Interface\\Icons\\Trade_Fishing"
-- In front of a spell's name this keeps a shot that is running from being switched off by a second press.
local KEEP = "!"
-- A swap of weapons comes as two changes, one for each hand. The hands are read when both are in.
local SETTLE = 0.5
-- The pole's button, for the time the pole is in the hands or there is no pole, and the seconds a
-- press is held to be a hold, and the most (the suite's one hold: Screen/RollsModel.lua HOLD, LIMIT).
local BUTTON, HOLD, LIMIT = "GamepadSuitePole", 1, 2.5
local NOTES = 8           -- lines of the log about the lure, in one session

local saved              -- { main =, off = }: the weapons to put back (item numbers), kept for the character
local now, words = {}, {} -- Adapter.Hands() and Adapter.HandWords() at the last read
local signature, lineOut, waiting
local button, downAt, noted = nil, nil, 0
-- what the player was told of a press that did nothing, by its cause, until the cause changes: why a hold put no lure
-- on ("on", "skill", "none"), that there is no pole ("nopole"), that the bags have no room for the pole ("full")
local said = {}

local function note(text)
    noted = noted + 1
    if noted <= NOTES then
        ns.Log.Add("hands", "Fishing Pole: " .. text)
    end
end

-- What only the game can tell goes in the log one time in a session (Hands.OnLogin, read): the
-- rule that the owner frame of the binds reads for a pole in the hands, and the thing the game
-- highlights while the line is out, which a press of the Interact button takes.
local told, castAt = {}, nil
local function tell(what, text)
    if not told[what] then
        told[what] = true
        ns.Log.Add("hands", "Fishing Pole: " .. text)
    end
end

-- The bind as the bind list offers it.
function Hands.Bind()
    return { kind = "fishingpole", id = "fishingpole", name = "Fishing Pole", detail = "Press: pole or weapons. Hold: lure.", icon = POLE_ICON }
end

-- The chat command text of the bind "Fishing Pole", or nil for a character with no pole. The
-- game reads the three lines at one press, before it moves an item, so only one half acts: with
-- a pole in the hands the weapons go back, with none the pole goes on.
-- Limit: two weapons of one sort (the same item in both hands) can come back as one, because
-- the game finds an item by its number. A fix needs the place of each in the bags at the press.
function Hands.PoleText()
    if not (words.poles and now.pole) then
        return nil
    end
    local lines = {}
    for slot, item in pairs({ [16] = saved.main, [17] = saved.off }) do
        lines[#lines + 1] = "/equipslot [worn:" .. words.poles .. "] " .. slot .. " item:" .. item
    end
    table.sort(lines)
    lines[#lines + 1] = "/equip [noworn:" .. words.poles .. "] item:" .. now.pole
    return table.concat(lines, "\n")
end

-- The chat command text that puts the best lure of the bags on the pole in the main hand, or nil
-- when no lure can go on now. A lure used alone waits for a click on the item it goes on; the
-- second line gives it the main hand (the game's slot 16), as the consumables wheel does for an
-- oil (Core/ConsumableRules.lua Text).
function Hands.LureText()
    return now.worn and now.lure and ("/use item:" .. now.lure.id .. "\n/use 16") or nil
end

-- The Interact button with a pole in the hands: Fishing. nil for a character that cannot fish.
function Hands.FishingText()
    return words.poles and words.fishing and ("/cast " .. words.fishing.name) or nil
end

-- The Interact button with an enemy as the target. A wand: Shoot, and no more (a swing would stop
-- the wand). A hunter: Auto Shot and the melee attack, so the one that is in reach starts.
-- "@target" is said in each line: with no unit named, the game also counts the enemy it
-- highlights in front of the character, which is not the target (ControllerForever's finding).
-- "/use" casts a spell too, and the game's "/cast" first asks if a spell with that exact text
-- exists, which the mark in front of the name can fail.
function Hands.AttackText()
    local lines = {}
    if words.shoot and words.wands then
        lines[#lines + 1] = "/use [@target,harm,nodead,worn:" .. words.wands .. "] " .. KEEP .. words.shoot.name
        lines[#lines + 1] = "/stopmacro [worn:" .. words.wands .. "]"
    end
    if words.shot then
        lines[#lines + 1] = "/use [@target,harm,nodead] " .. KEEP .. words.shot.name
    end
    lines[#lines + 1] = "/startattack [@target,harm,nodead]"
    return table.concat(lines, "\n")
end

-- The line of conditions that tells the game's restricted code a pole is in the hands.
function Hands.PoleDriver()
    return words.poles and ("[worn:" .. words.poles .. "] 1; 0") or nil
end

local function shown(spell)
    return spell and { kind = "spell", id = spell.id, name = spell.name, icon = spell.icon } or nil
end

-- True while a press of Fishing is what a pole in the hands asks for: out of a fight, for a
-- character that can fish.
local function fishing()
    return words.fishing ~= nil and not ns.Adapter.InCombat() and ns.Adapter.PoleWorn()
end

-- What the Interact button does now in place of the game's Interact, as a bind the on-screen
-- buttons can show: the attack with an enemy as the target, Fishing with a pole in the hands.
-- nil while it interacts. The order is the one of the restricted code.
function Hands.Shown()
    if fishing() and lineOut or not ns.Adapter.InCombat() and ns.Adapter.InteractNear() then
        return nil
    elseif ns.Adapter.EnemyTargeted() then
        return shown((words.shoot and ns.Adapter.WandWorn() and words.shoot) or words.shot or words.attack)
    end
    return fishing() and shown(words.fishing) or nil
end

-- What the Dynamic Interact button does with a pole in the hands, when nothing is in reach:
-- "interact" while the line is out (it takes the bobber), else the bind Fishing. nil with no pole.
function Hands.Rod()
    if not fishing() then
        return nil
    end
    return lineOut and "interact" or shown(words.fishing)
end

-- Reads the hands. Weapons that are no fishing pole are remembered: the bind puts them back.
-- Gives one text for everything the chat command texts are made of, to see a change.
local function read()
    local before = now
    now, words = ns.Adapter.Hands(), ns.Adapter.HandWords()
    if ns.Adapter.InCombat() then
        -- the lure is read out of a fight only; the end of the fight reads it again
        now.lure, now.lured, now.lures = before.lure, before.lured, before.lures
    end
    if not now.worn and (now.main or now.off) then
        saved.main, saved.off = now.main, now.off
    end
    -- a cause that changed is told again at the next press that meets it
    if now.worn ~= before.worn or now.lured ~= before.lured or now.lures ~= before.lures or (now.lure and now.lure.id) ~= (before.lure and before.lure.id) then
        said.on, said.skill, said.none, said.full = nil, nil, nil, nil
    end
    if now.pole then
        said.nopole = nil
    end
    if now.worn and words.poles then
        tell("worn", "a pole is in the hands; the rule " .. Hands.PoleDriver() .. " gives " .. ns.Adapter.RuleReads(Hands.PoleDriver()))
    end
    local function name(spell)
        return spell and spell.name
    end
    local values = { now.pole, saved.main, saved.off, words.poles, words.wands, name(words.fishing), name(words.shot), name(words.shoot), Hands.LureText(), now.worn }
    local parts = {}
    for i = 1, 10 do
        parts[i] = tostring(values[i])
    end
    return table.concat(parts, ";")
end

-- One line to the player for a press that did nothing, once for its cause (said).
local function tellOnce(cause, text)
    if not said[cause] then
        said[cause] = true
        ns.Print(text)
        note("told: " .. text)
    end
end

-- A hold that put no lure on: why. A lure is on the pole already (with its minutes left, when the game tells them),
-- the lures in the bags need more Fishing skill, or there is none.
local function noLure()
    if now.lured then
        local left = ns.Adapter.LureLeft()
        tellOnce("on", "Fishing Pole: a lure is on your pole" .. (left and (", " .. left .. " min left.") or "."))
    elseif now.lures then
        tellOnce("skill", "Fishing Pole: your Fishing skill is too low for the lure in your bags.")
    else
        tellOnce("none", "Fishing Pole: no lure in your bags.")
    end
end

-- The bar of every hold (Look/Widgets.lua HoldLine) on the on-screen buttons of the bind, while the pole's button is
-- held and a hold can matter: the pole in the hands, out of a fight. It fills in HOLD seconds and goes after LIMIT, as
-- the hold does nothing then. The frame's script runs only during the hold, LIMIT seconds at most (a let-go that a
-- window took is never heard here).
local bars, filler, holding = {}, nil, nil
local function fill(part)
    if ns.Screen and ns.Screen.on then
        ns.Screen.Each(function(b)
            if b.bind and b.bind.id == "fishingpole" then
                bars[b] = bars[b] or ns.Widgets.HoldLine(b, 2)
                bars[b]:SetPart(part)
            end
        end)
    end
end
holding = function(on)
    if on and not filler then
        filler = CreateFrame("Frame")
        filler:SetScript("OnUpdate", function()
            local held = GetTime() - (downAt or 0)
            if held > LIMIT then
                holding(false)
            else
                ns.Call("Hands", fill, math.max(held / HOLD, 0.001))
            end
        end)
    end
    if filler then
        filler:SetShown(on)
    end
    for _, bar in pairs(on and {} or bars) do
        bar:SetPart(0)
    end
end

-- The pole's button is made the first time the pole is in the hands, a lure can go on, or there is no pole. Its key
-- goes to it then (BindRules.LIVE below). It tells how long the press was at the let-go, before its restricted code
-- runs (Core/AdapterHands.lua PRESS): out of a fight a tap is the weapons, a hold the lure. A tap with the pole in the
-- hands and no weapon to put back puts the pole in the bags.
local function make()
    button = ns.Adapter.PoleButton(BUTTON)
    button:HookScript("PreClick", function(self, _, down)
        local calm = not ns.Adapter.InCombat()
        if down then
            downAt = GetTime()
            holding(calm and self:GetAttribute("worn") and true or false)
            return
        end
        holding(false)
        if downAt and self:GetAttribute("waiting") and calm then
            local held = GetTime() - downAt
            local long = held >= HOLD and (held <= LIMIT and "lure" or "late") or nil
            self:SetAttribute("long", long)
            note(("held %.2f s: %s"):format(held, long == "lure" and (self:GetAttribute("lure") and "the lure" or "no lure can go on")
                or long and "let go too late, nothing" or "the pole or the weapons"))
            if long == "lure" and not self:GetAttribute("lure") then
                noLure()
            elseif not long and now.worn and not (saved.main or saved.off) then
                if ns.Adapter.PoleToBags() then
                    note("no weapon to put back: the pole went to the bags")
                else
                    tellOnce("full", "Fishing Pole: your bags have no room, so the pole stays on.")
                end
            end
        end
    end)
    -- the on-screen buttons show the press, as for the bind's other button; with no pole the press says so, once
    button:HookScript("PostClick", function(_, _, down)
        if down then
            ns.Send("press", ns.BindCore.Signature(Hands.Bind()))
            if not now.pole and not ns.Adapter.InCombat() then
                tellOnce("nopole", "Fishing Pole: no fishing pole in your bags.")
            end
        end
    end)
end

-- Puts the two texts on the pole's button. Out of a fight only: the game locks the button in one.
local offered -- the lure text on the button
local function pole()
    local lure = Hands.LureText()
    if lure ~= offered then
        offered = lure
        note(lure and ("a hold puts on " .. tostring(now.lure.name) .. " (+" .. now.lure.bonus .. ")") or "no lure to put on now")
    end
    if (lure or now.worn or not now.pole) and not button then
        make()
    end
    if button then
        -- (with the pole in the hands and no weapon saved the tap puts it in the bags, from the PreClick: no text)
        button:SetAttribute("swap", (now.worn and not (saved.main or saved.off)) and "" or Hands.PoleText())
        button:SetAttribute("lure", lure)
        button:SetAttribute("worn", now.worn or nil)
    end
end

-- Reads the hands again. If a text changed, the pole's button and the bind core write theirs
-- again (after the fight, if there is one): the bind core hears "hands".
function Hands.Update()
    local text = read()
    if text ~= signature then
        signature = text
        ns.Queue.Run("Hands pole", pole)
        ns.Send("hands")
    end
end

local function later()
    if not waiting then
        waiting = true
        C_Timer.After(SETTLE, function()
            waiting = false
            ns.Call("Hands", Hands.Update)
        end)
    end
end

-- The fishing line went out or came in. In a fight nothing can be told to the bind core's owner
-- frame, so the end of the line waits there for the end of the fight; so does the game setting.
local function line(on)
    lineOut = on
    -- (a line that was out for a few seconds and showed the game no bobber: no press could take it)
    if not on and castAt and GetTime() - castAt > 3 then
        tell("bobber", "the line came in, and the game highlighted nothing while it was out")
    end
    castAt = on and GetTime() or nil
    ns.Queue.Run("Hands", function()
        ns.Adapter.WideInteract(lineOut)
        ns.BindCore.Flag("line", lineOut)
    end)
    ns.Send("line")
end

function Hands.OnLogin()
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    GamepadSuiteCharDB.hands = GamepadSuiteCharDB.hands or {}
    saved = GamepadSuiteCharDB.hands
    -- the bind as the bind that acts now. While the pole is in the hands (a hold can matter), and while
    -- there is no pole at all (its press says so), a key goes to the pole's button ("click", read by
    -- Core/BindPlan.lua); a wheel and a fixed slot keep the text, as a hold is no part of them. With no
    -- pole the bind stays itself for the rest, and does nothing (Core/BindRules.lua MOMENT).
    ns.BindRules.LIVE.fishingpole = function(bind)
        local text = Hands.PoleText()
        local click = (now.worn or not now.pole) and ("CLICK " .. BUTTON .. ":LeftButton") or nil
        if not text then
            return { kind = bind.kind, id = bind.id, name = bind.name, icon = bind.icon, detail = bind.detail, click = click }
        end
        return { kind = "slash", id = bind.id, name = bind.name, icon = now.icon or bind.icon, detail = text, click = click }
    end
    signature = read()
    ns.Queue.Run("Hands pole", pole)
    -- every change goes through the timer: the bags can change a moment before the hands do. A
    -- lure that goes on or ends is a change of the weapon's enchant (the game's own buff frame
    -- hears the same event, Blizzard_BuffFrame/BuffFrame.lua 517 and 537); the end of a fight
    -- reads the lure again.
    for _, event in ipairs({ "PLAYER_EQUIPMENT_CHANGED", "BAG_UPDATE_DELAYED", "SPELLS_CHANGED", "WEAPON_ENCHANT_CHANGED", "PLAYER_REGEN_ENABLED" }) do
        pcall(ns.On, event, "Hands", later)
    end
    -- the wide interact settings are let go at logout, which a reload is too
    ns.On("PLAYER_LOGOUT", "Hands", function()
        ns.Adapter.WideInteract(false)
    end)
    ns.On("PLAYER_SOFT_INTERACT_CHANGED", "Hands", function()
        local seen = lineOut and not told.bobber and ns.Adapter.Highlight() or {}
        if seen.name then
            tell("bobber", "the line is out; the game highlights " .. seen.name .. " (" .. (seen.unit and "a unit" or "a thing that is no unit")
                .. ", in reach: " .. tostring(seen.reach) .. "); the buttons that interact now: " .. ns.BindAsk.Interacting())
        end
    end)
    ns.Adapter.OnPlayerChannel(function(spell)
        if ns.Adapter.IsFishing(spell) then
            line(true)
        end
    end, function()
        if lineOut then
            line(false)
        end
    end)
end
