-- The adapter's part for Destroy Gray Item (Screen/Destroy.lua): the game's sign for full bags,
-- the things in the bags, and the calls that destroy one and loot again.
--
-- The sign: the game's own loot window listens for the red error text while it is open, and
-- knows full bags by the text itself (Blizzard_UIPanels_Game/Mainline/LootFrame.lua 148 and 190
-- to 198: UI_ERROR_MESSAGE, with the message equal to ERR_INV_FULL).
--
-- The destroy: an item is picked up from its bag slot and the call DeleteCursorItem destroys
-- what the pointer holds, as the game's own "destroy this item?" window does it
-- (Blizzard_StaticPopup_Game/GameDialogDefs.lua 1560). The game's notes mark that call as
-- restricted (Blizzard_APIDocumentationGenerated/GameCursorDocumentation.lua 54 to 57); the
-- pick-up call has no such mark (ContainerDocumentation.lua 420). The restricted call needs a
-- press of the player: the game's own window makes it from the click of its button, and in the
-- gamepad mode that click comes from a key bind that clicks a button when the key goes DOWN
-- (Blizzard_GamepadSharedUtility/InputBindingStack/InputFunctionBinding.lua 20 and 45 to 50).
-- So the call here is made only from the click of our own button at a key's press down.
-- ConsolePort destroys an item from such a click on the retail game.
-- A call that the game refuses is no Lua fault that pcall could catch: the game sends its event
-- for a blocked addon and shows a window whose first button turns the addon off
-- (Blizzard_Game/Shared/EventImplementation.lua 90 to 92, Blizzard_StaticPopup_Game/
-- GameDialogDefs.lua 714). So the call is never tried at a moment that may be no press.
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("destroyGray", function()
    return C_Container.GetContainerNumSlots and C_Container.GetContainerItemInfo and C_Container.GetContainerItemQuestInfo
        and C_Container.GetContainerNumFreeSlots and C_Container.PickupContainerItem and C_Item.GetItemInfo
        and DeleteCursorItem and GetCursorInfo and ClearCursor and GetNumLootItems and LootSlot
        and SetOverrideBindingClick and ClearOverrideBindings and type(ERR_INV_FULL) == "string"
        and C_EventUtils.IsEventValid("UI_ERROR_MESSAGE") and C_EventUtils.IsEventValid("LOOT_OPENED")
        and C_EventUtils.IsEventValid("LOOT_CLOSED") and C_EventUtils.IsEventValid("BAG_UPDATE_DELAYED") == true
end)
local results = Adapter.Results

-- The game's number of the item class "Quest".
local QUEST = 12

-- True when a red error text of the game is the one for full bags.
function Adapter.BagsFullError(message)
    return results().destroyGray and message == ERR_INV_FULL
end

-- True while the loot window is the window that has the controller (Core/AdapterGameWindows.lua).
function Adapter.LootHasPad()
    return Adapter.WindowHasPad(LootFrame)
end

-- Everything in the bags: { bag, slot, id, name, icon, count, quality, locked, and for a gray
-- thing quest, price (what a vendor pays for one; nil while the game has not loaded the item)
-- and keep (the consumables wheel has it) }. The bags are read one time; the wheel's own look
-- at the bags is asked for only when a gray thing is there.
function Adapter.BagThings()
    local things, grays = {}, {}
    pcall(function()
        if not results().destroyGray then
            return
        end
        for bag = 0, 4 do
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                local info = C_Container.GetContainerItemInfo(bag, slot)
                if info and info.itemID then
                    local thing = { bag = bag, slot = slot, id = info.itemID, name = info.itemName, icon = info.iconFileID,
                        count = info.stackCount or 1, quality = info.quality, locked = info.isLocked or false }
                    if thing.quality == ns.DestroyModel.GRAY then
                        local quest = C_Container.GetContainerItemQuestInfo(bag, slot)
                        local name, _, _, _, _, _, _, _, _, _, price, class = C_Item.GetItemInfo(info.itemID)
                        thing.quest = type(quest) == "table" and (quest.isQuestItem or quest.questID ~= nil) or class == QUEST or false
                        thing.price = name and (info.hasNoValue and 0 or price) or nil
                        thing.name = thing.name or name
                        -- kept until the wheel's answer is known: a fault there must not free it
                        thing.keep = true
                        grays[#grays + 1] = thing
                    end
                    things[#things + 1] = thing
                end
            end
        end
        if grays[1] then
            local keep = {}
            for _, item in ipairs(Adapter.Consumables()) do
                keep[item.id] = true
            end
            for _, thing in ipairs(grays) do
                thing.keep = keep[thing.id] or false
            end
        end
    end)
    return things
end

-- What is left in the open loot that takes a bag slot: { quality, count, price (what a vendor pays for one; nil while
-- the game has not loaded the item), quest }. The calls are the ones the game's own loot window reads: the slot's
-- type (LootFrame.lua 92; Item is 1, Money 2: LootConstantsDocumentation.lua 41 to 44), its info (227 to 228: count
-- 3rd, quality 5th, isQuestItem 7th) and its link (69); the price is the 11th answer of C_Item.GetItemInfo
-- (ItemDocumentation.lua 648). Money and currency take no slot. nil when a call fails.
function Adapter.LootThings()
    local ok, things = pcall(function()
        local ITEM, list = Enum and Enum.LootSlotType and Enum.LootSlotType.Item or 1, {}
        for slot = 1, GetNumLootItems() do
            if GetLootSlotType(slot) == ITEM and (not LootSlotHasItem or LootSlotHasItem(slot)) then
                local _, _, count, _, quality, _, quest = GetLootSlotInfo(slot)
                local link, name, price = GetLootSlotLink(slot)
                if link then
                    name, _, _, _, _, _, _, _, _, _, price = C_Item.GetItemInfo(link)
                end
                list[#list + 1] = { quality = quality, count = count or 1, quest = quest and true or false, price = name and price or nil }
            end
        end
        return list
    end)
    return ok and things or nil
end

-- The free places in the bags that take any item (a quiver takes arrows only).
function Adapter.FreeBagSlots()
    local free = 0
    pcall(function()
        for bag = 0, 4 do
            local count, family = C_Container.GetContainerNumFreeSlots(bag)
            if (family or 0) == 0 then
                free = free + (count or 0)
            end
        end
    end)
    return free
end

-- True while a bag slot still holds the thing that was read there.
function Adapter.BagSlotHolds(thing)
    local ok, info = pcall(C_Container.GetContainerItemInfo, thing.bag, thing.slot)
    return ok and info ~= nil and info.itemID == thing.id and info.stackCount == thing.count
end

-- Destroys a thing of Adapter.BagThings. Call it only from the click that a key's press DOWN
-- makes on a button: the game takes the destroy only inside a press of the player. Nothing is done
-- when the pointer holds something already, or when the slot does not hold that same gray
-- stack any more. A pointer that still holds the item after the call means that the game
-- refused: the item is put back. Returns true when the item left the pointer, else false and
-- why; the third value is true when the game refused the destroy itself.
function Adapter.DestroyBagItem(thing)
    if not results().destroyGray or Adapter.InCombat() then
        return false, "a fight, or the game has no call for it"
    end
    local ok, why, refused = pcall(function()
        if GetCursorInfo() then
            return "the pointer holds something"
        end
        local info = C_Container.GetContainerItemInfo(thing.bag, thing.slot)
        if not (info and info.itemID == thing.id and info.stackCount == thing.count
            and info.quality == ns.DestroyModel.GRAY and not info.isLocked) then
            return "the bag slot does not hold that gray stack any more"
        end
        C_Container.PickupContainerItem(thing.bag, thing.slot)
        local kind, id = GetCursorInfo()
        if kind ~= "item" or id ~= thing.id then
            ClearCursor()
            return "the pointer did not take the item (it holds " .. tostring(kind) .. " " .. tostring(id) .. ")"
        end
        DeleteCursorItem()
        if GetCursorInfo() then
            ClearCursor()
            return "the game refused the destroy", true
        end
        return nil
    end)
    if not ok then
        pcall(ClearCursor)
        return false, tostring(why)
    end
    return why == nil, why, refused
end

-- Asks for every loot slot that still has something, the last one first (a slot that is looted
-- can give its number to the next). With no loot open there is none. Returns how many slots
-- were asked for. The game leaves this call free for addon code: ForeverPlus loots this way on
-- this game.
function Adapter.LootAgain()
    local asked = 0
    pcall(function()
        for slot = GetNumLootItems(), 1, -1 do
            if not LootSlotHasItem or LootSlotHasItem(slot) then
                LootSlot(slot)
                asked = asked + 1
            end
        end
    end)
    return asked
end
