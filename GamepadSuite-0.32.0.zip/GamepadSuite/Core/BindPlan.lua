-- The plan of the bind core, with no game calls: what every key must be in every state. It is
-- made from the rules of Core/BindRules.lua (the key name of each layer, which bind a button has
-- in a state, the states, what the game needs to run a bind). Core/BindCore.lua hands the plan to
-- the game.
local _, ns = ...

local Rules = ns.BindRules
-- The trigger layers and the triggers that hold them.
local TRIGGERS = { [2] = { "LT" }, [3] = { "RT" }, [4] = { "LT", "RT" } }

-- The plan for every state.
-- shape = { keys = our key name -> the game's key name, forms =, combat =, holds = { [5] = },
--           chord = the LB + RB layer is on and has binds: LB goes to the LB button (Core/BindHolds.lua),
--           mods = { LT =, RT =, LB =, RB = } (see Rules.Prefixes), interact = our key name or nil,
--           native = { [2] =, [3] =, [4] = { our key name -> slot number or binding } }: the game's
--                    own bar slot for that button and trigger layer (run by a secure button of ours),
--                    or a click on the game's button,
--           nativeForm = the same for the button that takes its place while the player is in
--                    a form or a stance (the game's stance bar), where there is one,
--           heal = { what -> wheel name }: healer mode is on and the player is in a party; a bind of such a spell
--                  (what is its number) or item ("item:<number>") opens the party wheel in place of the cast,
--           healFoe = { what -> bind }: the same for one that can also be cast on an enemy: the bind that takes its place,
--           healSlots = { layer -> { our key name -> bind } }: the same for a friendly spell in the game's own slot of a button,
--           watch = { LT =, RT = }: the place in the pad's own state of a trigger that is no
--                   modifier and holds a layer in use, triggers = { LT =, RT = } the game's key names,
--           inUse = { [2] =, [3] =, [4] = }: the trigger layers that have a bind,
--           gameInteract = { our key name = true }: the game's own Interact button,
--           jobs = { attack =, fish = }: the chat command texts of the Interact button's two
--                  other jobs (Core/Hands.lua), each nil when the character cannot do it,
--           sticky = Sticky Layers is on: a tap of a trigger keeps its layer on until its next tap.
--                    Each trigger that is no modifier is in watch then,
--           aim = the row Targeting is at Stick: a bumper with a bind of ours goes to its own button,
--                 and while it is held the right stick targets (Core/BindHolds.lua),
--           slots = { spell number -> key command }: Press and Hold Casting for every spell bind. The spell
--                   is in a slot of the game's keyboard bars, and a key that casts it gets that slot's command,
--           noSlot = { layer -> true }: but not on these layers (Core/BindShape.lua says why) }.
-- Gives {
--   driver = the condition line,
--   buttons = { attributes for secure button 1, 2, ... },
--   states = { name = { game key -> binding } },
--   chord = nil, or the LB + RB layer: { states = { name = { game key -> binding } } for the time LB
--           and RB are held, lb = { name -> the number of the secure button that does LB's own bind,
--           0 for none }, off = { the states where LB keeps a game command that no button can run,
--           so the layer is off there }, bind = LB's bind in the first of them, for the words } },
--   interact = nil, or { key = the game key, off = { state name = true } }: Dynamic Interact,
--   ikeys = { state name = { game key = true } }: the keys that are the Interact button there,
--   jobs = { attack =, fish = }: the binding for each of the Interact button's other jobs,
--   held = { "L", "R" or "LR" = { state name = { game key -> binding } } }: a trigger layer's binds
--          on the plain keys, for the time those triggers are down or a tap keeps them on,
--   group = nil, or Healer Mode at Bumpers: { who = "lb" or "rb", n = { state name -> the number of the secure button
--         that does the bumper's own bind }, off = { state names where none can }, keys = { game key -> what it does } }
--   aim = nil, or the bumpers for Stick targeting: { lb = { name -> the number of the secure button
--         that does LB's own bind }, rb = the same for RB, off = { "LB in n0", ... where the bind is
--         a game command that no button can run: there the bumper keeps it, with no stick targeting } },
--   watch = { "L" or "R" = the trigger's place in the pad's state }: the triggers that are watched,
--   alt = { binding -> binding }: a click on one of the game's own buttons, and the click that
--         takes its place while the player is in a form or a stance,
--   missing = { layer numbers that cannot be reached: no key name and no way to watch },
-- }
-- A binding is the game's own text for a key: a command ("JUMP") or a click on one of the buttons.
-- A key with no bind is not in a table: the game keeps it.
function Rules.Plan(get, shape)
    local plan = { driver = Rules.Driver(shape.forms, shape.combat), buttons = {}, states = {}, held = {}, watch = {}, alt = {}, missing = {},
        aim = shape.aim and { lb = {}, rb = {}, off = {} } or nil }
    local numberOf = {}
    local heal, healFoe, healSlots, slots = shape.heal or {}, shape.healFoe or {}, shape.healSlots or {}, shape.slots or {}
    local noSlot = shape.noSlot or {}
    -- the number of the secure button for an action; two binds with the same action share one
    local function number(action)
        local key = Rules.Signature(action)
        if not numberOf[key] then
            plan.buttons[#plan.buttons + 1] = action
            numberOf[key] = #plan.buttons
        end
        return numberOf[key]
    end
    -- healer mode: a friendly spell or item with no receiver of its own opens its party wheel in place of the cast
    local function healed(bind)
        local real = bind and Rules.Real(bind)
        local what = real and not real.on and (real.kind == "spell" and real.id or real.kind == "item" and "item:" .. tostring(real.id))
        return what and (healFoe[what] or heal[what] and { kind = "wheel", id = heal[what] }), real, what
    end
    local function binding(bind, layer)
        local wheel, real, what = healed(bind)
        -- a spell with a slot: the game's own command for that slot casts it, and casts it again while the key is held
        if not wheel and slots[what] and not noSlot[layer] then
            return slots[what]
        end
        -- a bind with a button of its own for a key: the bind Fishing Pole while a hold of it can put a lure on (Core/Hands.lua)
        if not wheel and real and real.click then
            return real.click
        end
        bind = wheel or bind
        local action = bind and Rules.Action(bind)
        -- Sticky Layers: a game command is no click, so the owner frame would not see its press, and
        -- a trigger held for it would count as a tap. One that has a chat command (a target command)
        -- runs as that text from a button of ours, as LB's bind does for LB + RB.
        local text = shape.sticky and action and action.command and Rules.ChatText(action.command)
        action = text and { type = "macro", macrotext = text } or action
        if not action or action.command then
            return action and action.command
        end
        return "CLICK " .. Rules.BUTTON .. number(action) .. ":LeftButton"
    end
    local function slot(state, layer, ours)
        local bind, set = Rules.Find(get, state, layer, ours)
        -- healer mode: a button with no bind of ours runs the game's own slot, and a friendly spell there opens its
        -- party wheel too; not in a form on the bar that the game's stance bar stands for
        local inForm = state.form and shape.nativeForm and shape.nativeForm[layer] and shape.nativeForm[layer][ours]
        bind = bind or not set and not inForm and healSlots[layer] and healSlots[layer][ours] or nil
        if bind then
            return binding(bind, layer)
        end
        return set and ("CLICK " .. Rules.NOTHING_BUTTON .. ":LeftButton") or nil
    end
    -- A bumper's own bind for a button of ours that holds the bumper (LB + RB, Stick targeting): the
    -- number of the secure button that does it, 0 for no bind, nil for a game command that no button
    -- can run (a target command runs as its chat command). The second value: it has a bind.
    -- Healer mode acts for LB's own bind in the LB + RB layer (heals): its button opens the party wheel
    -- by the chat command of a click on the wheels' button. Not with Stick targeting, where the right
    -- stick targets while the bumper is held.
    local function bumper(state, ours, heals)
        local bind = Rules.Find(get, state, 1, ours)
        local wheel = heals and healed(bind)
        if wheel and wheel.kind == "wheel" then
            wheel = { kind = "slash", detail = "/click " .. Rules.WHEEL_BUTTON .. " " .. wheel.id .. " 1" }
        end
        local action = bind and Rules.Action(wheel or bind)
        if action and action.command then
            local text = Rules.ChatText(action.command)
            action = text and { type = "macro", macrotext = text } or nil
        end
        if bind and not action then
            return nil, true
        end
        return action and number(action) or 0, bind ~= nil
    end
    local prefixes = Rules.Prefixes(shape.mods)
    -- A trigger layer slot with no bind of ours belongs to the game: its own bar has an action for
    -- each of its eight buttons on each trigger layer.
    local native, nativeForm, free = shape.native or {}, shape.nativeForm or {}, shape.gameInteract or {}
    local function own(layer, ours)
        -- (a slot number is run by a secure button of ours that holds that slot)
        local function run(game)
            return type(game) == "number" and binding({ kind = "slot", id = game }, layer) or game
        end
        local click = run(native[layer] and native[layer][ours] or nil)
        local inForm = click and run(nativeForm[layer] and nativeForm[layer][ours])
        if inForm and inForm ~= click then
            plan.alt[click] = inForm
        end
        return click
    end
    -- A trigger layer with no key name is held instead, when the pad can be read for each of its
    -- triggers that is no modifier. combo names the triggers that are down. fronts are the parts
    -- of a key name that the triggers that are modifiers may still give: the other trigger's, for
    -- a held layer. A layer in use whose triggers are the game's modifiers gets such a table too:
    -- the game often looks a key up without the modifier (ControllerForever RuleBar.lua 9264 to
    -- 9267 and 9311 to 9316), so the plain keys get the layer's binds while its triggers are down,
    -- and the key names keep them as well. own: a trigger of the layer is watched, so the game's
    -- bar cannot change for it.
    local watch, heldLayers = shape.watch or {}, {}
    for layer, buttons in pairs(TRIGGERS) do
        -- (Sticky Layers: every layer gets such a table, for the time a tap keeps it on. Then a key
        -- with the modifiers of its triggers gets it too: a trigger that is also held changes nothing.)
        local tap = prefixes[layer] and shape.sticky and true
        local combo, native, mods, watched = "", {}, {}, false
        for _, button in ipairs(buttons) do
            if shape.mods[button] then
                native[shape.mods[button]], mods[button] = true, shape.mods[button]
            elseif watch[button] then
                watched = true
            else
                combo = nil
            end
            combo = combo and (combo .. button:sub(1, 1))
        end
        combo = (not prefixes[layer] or tap or (shape.inUse or {})[layer]) and combo or nil
        if combo then
            heldLayers[layer] = { combo = combo, fronts = tap and Rules.Fronts(mods) or { "", Rules.Front(native) }, own = watched or shape.sticky }
        end
    end
    local chord = shape.chord and shape.keys.LB and shape.keys.RB and true or false
    for layer = 2, 4 do
        if not (prefixes[layer] or heldLayers[layer]) then
            plan.missing[#plan.missing + 1] = layer
        end
    end

    local states = Rules.States(shape.forms, shape.combat, shape.combatFirst)
    for _, state in ipairs(states) do
        local keys = {}
        for ours, theirs in pairs(shape.keys) do
            local plain = slot(state, 1, ours)
            keys[theirs] = plain
            for layer = 2, 4 do
                if prefixes[layer] then
                    -- With no bind of ours here the key has no bind, and the game goes on to its
                    -- own action by itself. But if the plain key has a bind of ours, or can get one
                    -- (the Interact button), the game would fall back to that: then the key is given to the game's own button.
                    -- With Sticky Layers the triggers' keys are ours, so the game's bar does not change for them: the same.
                    keys[prefixes[layer] .. theirs] = slot(state, layer, ours)
                        or ((plain or free[ours] or ours == shape.interact or shape.sticky) and own(layer, ours)) or nil
                end
            end
        end
        -- LB + RB. LB's key goes to the LB button, which does LB's own bind: a secure button's action,
        -- or a target command as its chat command. A game command with no chat command cannot be run
        -- so: in that state LB keeps it, and the layer is off there. The ten keys get the layer's binds
        -- while LB and RB are held (Core/BindSecure.lua), with a trigger held too, and a key with no
        -- bind there does nothing: ControllerForever's layer is ten binds of its own, each key with
        -- every modifier on a button of its own while it is on, an empty one too (its
        -- Shoulders.lua 11209 to 11246).
        if chord then
            plan.chord = plan.chord or { states = {}, lb = {}, off = {} }
            local n = bumper(state, "LB", true)
            if not n then
                plan.chord.off[#plan.chord.off + 1] = state.name
                plan.chord.bind = plan.chord.bind or Rules.Find(get, state, 1, "LB")
            else
                plan.chord.lb[state.name] = n
                keys[shape.keys.LB] = "CLICK " .. Rules.LB_BUTTON .. ":LeftButton"
                local second = {}
                for _, ours in ipairs(shape.holds[5] and Rules.IN_HOLD or {}) do
                    local bind = shape.keys[ours] and (slot(state, 5, ours) or "CLICK " .. Rules.NOTHING_BUTTON .. ":LeftButton")
                    for _, front in ipairs(bind and Rules.Fronts(shape.mods) or {}) do
                        second[front .. shape.keys[ours]] = bind
                    end
                end
                plan.chord.states[state.name] = second
            end
        end
        -- Stick targeting: a bumper with a bind of ours goes to its own button, which does that bind
        -- and holds the bumper. A bumper with no bind of ours has the game's own targeting already,
        -- and so has one with the bind Stick Target (the game's own command).
        for _, ours in ipairs(plan.aim and shape.keys.LB and shape.keys.RB and { "LB", "RB" } or {}) do
            local n, has = bumper(state, ours)
            if n and has then
                plan.aim[ours:lower()][state.name] = n
                keys[shape.keys[ours]] = "CLICK " .. Rules[ours .. "_BUTTON"] .. ":LeftButton"
            elseif has and not tostring(Rules.Find(get, state, 1, ours).id):find("TARGETMODIFIER$") then
                plan.aim.off[#plan.aim.off + 1] = ours .. " in " .. state.name
            end
        end
        -- Healer Mode at Bumpers: the friendly bumper (shape.group: "LB" or "RB") goes to its own button, which holds it
        -- and does its own bind on a tap; while it is held the D-pad, A, X and B target the group (Core/BindGroup.lua).
        -- A bumper whose bind is a game command that no button can run keeps it in that state, with no group targeting.
        if shape.group and shape.keys[shape.group] then
            local who = shape.group
            plan.group = plan.group or { who = who:lower(), n = {}, off = {}, keys = {} }
            local n = bumper(state, who)
            if n then
                plan.group.n[state.name] = n
                keys[shape.keys[who]] = "CLICK " .. Rules[who .. "_BUTTON"] .. ":LeftButton"
            else
                plan.group.off[#plan.group.off + 1] = state.name
            end
            for ours, what in pairs(Rules.GROUP_KEYS) do
                if shape.keys[ours] then
                    plan.group.keys[shape.keys[ours]] = what
                end
            end
        end
        -- A held layer. The plain key gets the layer's bind. With no bind there, one of the
        -- game's eight bar buttons gets the game's own action for that layer: the game itself
        -- cannot change its bar for a trigger that we watch, because our hold button has the
        -- trigger's key (nor for a layer a tap keeps on). For a trigger that is a modifier the
        -- game's bar changes by itself, so the rule of the key names above holds. Any other button
        -- stays what it is, as a key name with no bind falls back to the plain key. With both
        -- triggers down the game may put the other trigger's modifier in the key name or drop it
        -- (ControllerForever's note), so that name gets the same bind.
        for layer, hold in pairs(heldLayers) do
            local swap = {}
            for ours, theirs in pairs(shape.keys) do
                local bind = slot(state, layer, ours)
                    or ((hold.own or keys[theirs] or free[ours] or ours == shape.interact) and own(layer, ours)) or nil
                swap[theirs] = bind
                for _, front in ipairs(hold.fronts) do
                    if front ~= "" then
                        swap[front .. theirs] = bind or keys[theirs]
                    end
                end
            end
            plan.held[hold.combo] = plan.held[hold.combo] or {}
            plan.held[hold.combo][state.name] = swap
        end
        -- A watched trigger goes to its hold button, whatever modifier is down with it. A trigger
        -- that is a modifier is never watched (Core/BindShape.lua): a bound trigger stops sending
        -- its modifier (ControllerForever RuleBar.lua 4981 to 4986), and its press is heard as the
        -- modifier.
        for button, index in pairs(watch) do
            local side = button:sub(1, 1)
            plan.watch[side] = index
            for _, text in ipairs(Rules.Fronts(shape.mods)) do
                keys[text .. shape.triggers[button]] = "CLICK " .. Rules.HOLD_BUTTON .. side .. ":LeftButton"
            end
        end
        plan.states[state.name] = keys
    end
    -- Dynamic Interact: the chosen button interacts while something to interact with is in reach.
    -- It stands above the button's bind in every state but one: where the Combat set has its own
    -- bind (or its own empty slot) for the button, the player has said what the button does in a
    -- fight, and that stays.
    local ours = shape.interact
    plan.interact = ours and shape.keys[ours] and { key = shape.keys[ours], off = {} } or nil
    -- The Interact button of each state: a button with our bind "Interact With Target", or the
    -- game's own Interact button where it has no bind of ours. With an enemy as the target it
    -- starts the attack; with a fishing pole in the hands it casts Fishing (Core/BindSecure.lua).
    plan.ikeys, plan.jobs = {}, {}
    for _, state in ipairs(states) do
        if plan.interact and select(2, Rules.Find(get, state, 1, ours)) == "combat" then
            plan.interact.off[state.name] = true
        end
        local keys = {}
        for key, theirs in pairs(shape.keys) do
            local bind, set = Rules.Find(get, state, 1, key)
            bind = bind and Rules.Real(bind) -- (a fixed slot can hold the bind)
            keys[theirs] = (bind and bind.kind == "command" and bind.id == Rules.INTERACT_TARGET or not set and free[key]) and true or nil
        end
        plan.ikeys[state.name] = keys
    end
    for name, text in pairs(shape.jobs or {}) do
        plan.jobs[name] = binding({ kind = "slash", detail = text })
    end
    return plan
end

-- ---- a raid's party wheel: one radial for each pair of raid groups that has members (Core/Wheels.lua, "heal774:2")
-- While it is open LB goes to the radial before and RB to the radial after, and the D-pad to the radial that lies that
-- way, by their keys with every modifier that can be down in front: { [the game's key] = "prev", "next", "up", "down",
-- "left" or "right" } (Core/BindHolds.lua Write, Core/BindSecure.lua APPLY). A bumper that the game makes Shift, Ctrl
-- or Alt sends no key of its own: it is heard as that modifier (BindHolds MODIFIER).
function Rules.CycleKeys(keys, mods)
    local out = {}
    for who, step in pairs({ LB = "prev", RB = "next", DU = "up", DD = "down", DL = "left", DR = "right" }) do
        for _, front in ipairs(keys[who] and not mods[who] and Rules.Fronts(mods) or {}) do
            out[front .. keys[who]] = step
        end
    end
    return out
end

-- The owner frame's restricted code that changes the radial ("cycle", put there by Core/BindHolds.lua Build; it runs in
-- a fight too): "wstep" is one of the steps above. The open wheel is the bind's own ("heal774": the player's own pair,
-- the radial with the player at the first place of a half, 1 or 6) or a pair's ("heal774:2"). Where each step goes
-- from each pair is written out of a fight ("wgo:<pair>:<step>", Screen/WheelRaidModel.lua Moves). What the stick
-- pointed at is forgotten, so a let-go casts on no member of another radial. Where no radial lies, nothing changes.
Rules.CYCLE = [[
    local base, pair = strmatch(self:GetAttribute("wheel") or "", "^(heal%a*%d+):?(%d*)$")
    pair = tonumber(pair or "")
    for p = 1, base and not pair and 4 or 0 do
        if self:GetAttribute("wu:" .. base .. ":" .. p .. ":1") == "player" or self:GetAttribute("wu:" .. base .. ":" .. p .. ":6") == "player" then
            pair = p
        end
    end
    local step = self:GetAttribute("wstep")
    local to = pair and self:GetAttribute("wgo:" .. pair .. ":" .. step)
    if to and (self:GetAttribute("wn:" .. base .. ":" .. to) or 0) > 0 then
        self:SetAttribute("wwhy", step == "next" and "RB" or step == "prev" and "LB" or "D-pad " .. step)
        self:SetAttribute("wheel", base .. ":" .. to)
        self:SetAttribute("wsel", nil)
        self:SetAttribute("wkey", nil)
        self:RunAttribute("apply")
    end
]]
