-- The adapter's part for Take All Mail (Windows/MailTake.lua): the inbox page of the game's mail window, its letters,
-- and the calls that take the gold and the items of a letter. One login check.
--
-- What the game's code says:
--   The inbox with the controller has A Select, X "Open All Mail" and B Back in its footer
--   (Blizzard_MailFrame/MailFrame.lua 268 to 279). Y has no job there: the window manager blocks the D-pad and the face
--   buttons for a window (Blizzard_GamepadSharedUtility/FrameControlsManager.lua 212 and 213).
--   The game's Open All takes one thing, then waits in the OnUpdate script of its button OpenAllMail for the next
--   (MailFrame.lua 1678 to 1692, MailFrame.xml 444 to 455). The controller interface hides that button (MailFrame.lua
--   281 to 283), and a hidden frame gets no OnUpdate: with the controller X takes the first thing and no more.
--   Its steps are the model here: the gold of a letter first, then its items (1644 to 1656); letters with cash on
--   delivery and letters from a Game Master are passed (1552 to 1566); an item the game refused is passed (1568 to 1572);
--   no free bag slot stops the items (1632); the next take waits while C_Mail.IsCommandPending says the game is still on
--   one (1683).
--   GetInboxHeaderInfo gives the sender 3rd, the subject 4th, the gold 5th, the cash on delivery 6th, the days left 7th,
--   the number of items 8th, "it came back" 10th, "the player may answer" 12th and "from a Game Master" 13th
--   (MailFrame.lua 340, 583, 766 to 768: no answer to the auction house or a person of the game); GetInboxItem gives the
--   name, the item id, the picture and the count (712). GetInboxInvoiceInfo gives the kind of an auction letter, the
--   item, the other player, the bid, the buyout, the deposit, the cut, the wait, two times and the count (790); the
--   game's window reads it for the open letter only, so for a letter not opened it may give nothing (the run's log
--   says). These calls and the two takes are old global calls with no entry in the game's notes
--   (Blizzard_APIDocumentationGenerated), so no HasRestrictions mark can be read; the game's own Open All makes the takes
--   from an OnUpdate, with no press. The subject of a sale is the game's AUCTION_SOLD_MAIL_SUBJECT. C_Mail
--   and CalculateTotalNumberOfFreeBagSlots are in the notes with no restriction (MailInfoDocumentation.lua,
--   ContainerDocumentation.lua 11 to 18). Nothing of the game is written or run: its buttons and scripts stay its own.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

local function event(name)
    return C_EventUtils.IsEventValid(name) == true
end

Adapter.Check("mailTake", function()
    return MailFrame.IsShown and InboxFrame.HookScript and GetInboxNumItems and GetInboxHeaderInfo and GetInboxItem
        and GetInboxInvoiceInfo and TakeInboxMoney and TakeInboxItem and C_Mail.IsCommandPending and C_Container.CalculateTotalNumberOfFreeBagSlots
        and type(ATTACHMENTS_MAX_RECEIVE) == "number" and type(ERR_INV_FULL) == "string" and event("MAIL_INBOX_UPDATE")
        and event("MAIL_SUCCESS") and event("MAIL_FAILED") and event("UI_ERROR_MESSAGE") and event("BAG_UPDATE_DELAYED")
end)

-- Tells fn each time the inbox page shows or hides: the mailbox opens or closes, or a tab of the window is picked. It
-- runs inside the game's code: fn must only take note.
function Adapter.OnMailInbox(fn)
    InboxFrame:HookScript("OnShow", fn)
    InboxFrame:HookScript("OnHide", fn)
end

-- The mail window while its inbox page shows, or nil. Adapter.WindowHasPad (Core/AdapterGameWindows.lua) says if it
-- has the controller: not while the bags or a letter that is open have it.
function Adapter.MailInbox()
    local ok, shown = pcall(function()
        return results().mailTake and InboxFrame:IsVisible()
    end)
    return ok and shown and MailFrame or nil
end

-- The letters of the inbox, from the top: { money (copper), cod (it asks for payment), gm (from a Game Master), items =
-- { { slot, id, name, count } }, from, subject, days (left), back (it came back), reply (the player may answer it),
-- invoice = { kind, item, count } or nil }; and the game's count of every letter, which goes down when a letter goes.
function Adapter.MailLetters()
    local letters, total = {}, 0
    pcall(function()
        if not results().mailTake then
            return
        end
        local shown, all = GetInboxNumItems()
        total = all or shown or 0
        for index = 1, shown or 0 do
            local _, _, from, subject, money, cod, days, count, _, back, _, reply, gm = GetInboxHeaderInfo(index)
            local letter = { money = money or 0, cod = (cod or 0) > 0, gm = gm and true or false, items = {}, from = from,
                subject = subject, days = tonumber(days), back = back and true or false, reply = reply and true or false }
            local ok, kind, item, _, _, _, _, _, _, _, _, many = pcall(GetInboxInvoiceInfo, index)
            if ok and kind then
                letter.invoice = { kind = kind, item = item, count = tonumber(many) }
            end
            for slot = 1, (count or 0) > 0 and ATTACHMENTS_MAX_RECEIVE or 0 do
                local name, id, _, many = GetInboxItem(index, slot)
                if id then
                    letter.items[#letter.items + 1] = { slot = slot, id = id, name = name or ("item " .. id), count = many or 1 }
                end
            end
            letters[index] = letter
        end
    end)
    return letters, total
end

-- The game's words of an auction letter: the subject of a sale ("Auction successful: %s") and a stack ("%s (%d)").
function Adapter.MailWords()
    return { sold = type(AUCTION_SOLD_MAIL_SUBJECT) == "string" and AUCTION_SOLD_MAIL_SUBJECT or nil,
        stack = type(AUCTION_MAIL_ITEM_STACK) == "string" and AUCTION_MAIL_ITEM_STACK or nil }
end

-- True while the game is still on a mail call (a take with no answer yet). True too when the game cannot say: the run
-- then waits, and its three seconds end it.
function Adapter.MailBusy()
    local ok, busy = pcall(C_Mail.IsCommandPending)
    return not ok or busy == true
end

-- Free bag slots, counted as the game's Open All counts them.
function Adapter.MailBagFree()
    local ok, free = pcall(C_Container.CalculateTotalNumberOfFreeBagSlots)
    return ok and tonumber(free) or 0
end

-- True when a red error text of the game is the one for full bags (the loot window's sign,
-- Blizzard_UIPanels_Game/Mainline/LootFrame.lua 190 to 198).
function Adapter.MailBagsFull(message)
    return results().mailTake and message == ERR_INV_FULL or false
end

-- Asks the game for one thing of a letter: its gold, or with take.slot the item in that place. Not in a fight. True
-- when the call was made with no error; the game's answer is that the inbox changes.
function Adapter.MailTake(take)
    if not results().mailTake or InCombatLockdown() then
        return false
    end
    if take.slot then
        return (pcall(TakeInboxItem, take.index, take.slot))
    end
    return (pcall(TakeInboxMoney, take.index))
end
