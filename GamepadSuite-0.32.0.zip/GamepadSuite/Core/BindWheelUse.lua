-- The bind core's restricted code for an open wheel, kept apart from Core/BindSecure.lua for room: the press and the
-- let-go of a direction key of the right stick. Core/BindSecure.lua wraps the wheel's use button with it.
local _, ns = ...

-- A direction key of the right stick, while a wheel is open. The click's button name is the direction. A key that
-- goes down points: the entry nearest to the stick is remembered ("wsel"; the ring's gold frame marks that one and no
-- other, Screen/Wheel.lua). The key that comes up is the stick let go: the remembered entry is used and the wheel closes. What ControllerForever's code tells about the game, kept here: the
-- game sends one direction key for a stick at a time and no release for the key the stick left; in a fight the stick
-- can read as in the middle when its key goes down, and then the key itself gives the way. The entry runs from this
-- button on the key's release ("typerelease"), whatever the game's setting for casts on key down is. An entry is one
-- attribute of a secure button: a spell, an item, a macro or a chat command, and for the party wheel the unit it goes
-- to.
ns.BindWheelUse = [[
    self:SetAttribute("type", nil)
    self:SetAttribute("typerelease", nil)
    local wheel = control:GetAttribute("wheel")
    if not wheel then
        return false
    end
    if down then
        control:SetAttribute("wkey", button)
    end
    local pad = GetGamePadState and GetGamePadState()
    local stick = pad and pad.sticks and pad.sticks[control:GetAttribute("stickindex") or 2]
    local x, y = stick and stick.x or 0, stick and stick.y or 0
    local far = x * x + y * y
    -- (how far the stick was when the game's key went down: the log of Core/AdapterWheelNow.lua tells it, six times)
    if down then
        control:SetAttribute("wfar", far)
    end
    -- When the key goes down the stick is on its way out: its own reading is trusted from a small
    -- push on, because it points between the four key directions and an entry can stand there.
    -- The key's own direction is only for a reading at the very middle. When the key comes up,
    -- a stick near its middle says nothing new, and the entry chosen before stays.
    if far < (down and 0.02 or 0.15) then
        x, y = nil, nil
        if down then
            x = (button == "RIGHT" and 1) or (button == "LEFT" and -1) or 0
            y = (button == "UP" and 1) or (button == "DOWN" and -1) or 0
        end
    end
    if x then
        local best, most
        for i = 1, control:GetAttribute("wn:" .. wheel) or 0 do
            local dot = x * control:GetAttribute("wx:" .. wheel .. ":" .. i) + y * control:GetAttribute("wy:" .. wheel .. ":" .. i)
            if not most or dot > most then
                best, most = i, dot
            end
        end
        control:SetAttribute("wsel", best)
    end
    if down then
        return false
    end
    -- a release of a key the stick left earlier, with the stick still pushed: not the let-go
    if button ~= control:GetAttribute("wkey") and far > 0.08 then
        return false
    end
    local pick = control:GetAttribute("wsel")
    if not pick then
        return false
    end
    local at = wheel .. ":" .. pick
    local kind, key, value = control:GetAttribute("wt:" .. at), control:GetAttribute("wk:" .. at), control:GetAttribute("wv:" .. at)
    local unit = control:GetAttribute("wu:" .. at)
    control:SetAttribute("wwhy", kind and "the stick's let-go" or "the stick's let-go, on an entry with no action now")
    control:SetAttribute("wheel", nil)
    control:SetAttribute("wsel", nil)
    control:SetAttribute("wkey", nil)
    control:RunAttribute("apply")
    if not kind then
        return false
    end
    for _, name in ipairs(newtable("spell", "item", "macro", "macrotext", "action")) do
        self:SetAttribute(name, nil)
    end
    if key then
        self:SetAttribute(key, value)
    end
    -- a member of the party, for the party wheel; a unit that is not there casts nothing
    self:SetAttribute("unit", unit)
    self:SetAttribute("typerelease", kind)
]]
