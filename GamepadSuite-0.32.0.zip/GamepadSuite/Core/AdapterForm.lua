-- The adapter, the part for the picture of the form or stance on screen (Screen/HudForm.lua): which one the player
-- is in, with the game's own picture and name of it. nil in no form (a druid in caster form, a rogue not in stealth).
local _, ns = ...
local Adapter = ns.Adapter

function Adapter.ActiveForm()
    local ok, form = pcall(function()
        local index = GetShapeshiftForm()
        if not index or index == 0 then
            return nil
        end
        local icon, _, _, spell = GetShapeshiftFormInfo(index)
        local name = spell and C_Spell.GetSpellName(spell)
        return icon and { icon = icon, name = name or "" } or nil
    end)
    return ok and form or nil
end
