-- The bind core's look at the keys, out of a fight: what each key does now against what the owner
-- frame set last (Core/BindCore.lua).
local _, ns = ...

local Check = {}
ns.BindCheck = Check

local lastCheck

-- A line for the player about a standing state (a bind, a row, a state of the game): said once for this character, and
-- again only when its text changes, as Screen/PointerPair.lua does for its line (the no-nag rule). text nil: the cause
-- is gone, so its return is told again. name: the line's own name in GamepadSuiteCharDB.told.
function Check.Tell(name, text)
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    GamepadSuiteCharDB.told = GamepadSuiteCharDB.told or {}
    if text and GamepadSuiteCharDB.told[name] ~= text then
        ns.Print(text)
    end
    GamepadSuiteCharDB.told[name] = text
end

-- Reads back what each key does now. One line goes in the log when the answer changes: it is the
-- proof, taken in the player's own game, that our binds are the ones in use. header is the owner
-- frame, keys the keys of the last plan. Returns false when a key is neither ours nor held by a
-- part of the addon (mouse mode, the on-screen keyboard, the roll keys: Adapter.taken).
function Check.Keys(header, keys, why)
    if not ns.BindCore.plan or ns.Adapter.InCombat() or not ns.Pad.Gameplay() then
        return true
    end
    -- The game itself holds a key during play (in a party, View opens its raid window). From
    -- now on our bind for that key is set at the game's own level, where the last one set wins.
    -- In a set where the key has no bind of ours it stays the game's.
    local taken
    for _, key in ipairs(keys) do
        if not header:GetAttribute("top:" .. key) and ns.Adapter.GameTookKey(key) then
            header:SetAttribute("top:" .. key, true)
            taken = (taken and taken .. ", " or "") .. key
        end
    end
    if taken then
        ns.Log.Add("binds", "the game holds " .. taken .. " during play: our bind for it is set above the game's from now on")
        SecureHandlerExecute(header, ns.BindSecure.FORCE)
    end
    local total, ours, kept, first = 0, 0, 0, nil
    for _, key in ipairs(keys) do
        local wanted = header:GetAttribute("set:" .. key)
        if wanted then
            total = total + 1
            local now = ns.Adapter.EffectiveBinding(key)
            -- a click of a button of ours that no part of the addon wants now goes, and our bind shows again
            local dropped = now ~= wanted and ns.Adapter.DropLeftOver(key, now)
            local after = dropped and ns.Adapter.EffectiveBinding(key) or now
            local held = after ~= nil and ns.Adapter.taken[key] == after
            if after == wanted then
                ours = ours + 1
            elseif held then
                kept = kept + 1
            end
            if after ~= wanted or dropped then
                first = first or (key .. " reads " .. tostring(after) .. ", wanted " .. wanted
                    .. (dropped and " (" .. tostring(now) .. " was left over and went)" or held and " (a part of the addon holds it now)" or ""))
            end
        end
    end
    local line = ours .. " of " .. total .. " keys read back as set" .. (first and ("; " .. first) or "")
    if line ~= lastCheck then
        lastCheck = line
        ns.Log.Add("binds", line .. " (" .. why .. ")")
    end
    return ours + kept == total
end

-- Blizzard set or cleared window binds. Out of a fight, if a key of ours no longer reads back as
-- set, every key is set again. It cannot hurt a window: our binds are under its binds.
function Check.AfterWindow(header, keys)
    if ns.Adapter.InCombat() or Check.Keys(header, keys, "after a window") then
        return
    end
    SecureHandlerExecute(header, ns.BindSecure.FORCE)
    lastCheck = nil
    if not Check.Keys(header, keys, "set again after a window") then
        Check.Tell("keys", "Some buttons could not be set. Another addon or the game holds them. Turn other controller addons off in the addon list, then type /reload.")
    end
end

-- For the log: in each state, the keys of a trigger layer with no binding at all where the plain
-- key has one of ours, so that the game runs the plain bind there (LT + Y gives Y's bind). One
-- line when it changes. The owner saw this in Bear Form in a fight (2026-10-14).
local fallback
function Check.Note(plan, form)
    local out, prefixes = {}, ns.BindRules.Prefixes(form.mods)
    for name, keys in pairs(plan.states) do
        local miss = {}
        for layer = 2, 4 do
            for _, ours in ipairs(prefixes[layer] and prefixes[layer] ~= "" and { "A", "B", "X", "Y" } or {}) do
                local plain = form.keys[ours]
                if plain and keys[plain] and not keys[prefixes[layer] .. plain] then
                    miss[#miss + 1] = prefixes[layer] .. plain
                end
            end
        end
        if #miss > 0 then
            table.sort(miss)
            out[#out + 1] = name .. ": " .. table.concat(miss, " ")
        end
    end
    table.sort(out)
    local line = #out > 0 and table.concat(out, "; ") or "none"
    if line ~= fallback then
        fallback = line
        ns.Log.Add("binds", "trigger layer keys that fall back to the plain bind: " .. line)
    end
end
