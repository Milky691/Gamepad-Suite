-- The adapter, the part for Rumble Events (Auto/RumbleEvents.lua): who an event is about. In the
-- game's chat lockdown, the names and GUIDs of chat and group events can be hidden from addon code
-- (SecretInChatMessagingLockdown: PartyInfoDocumentation.lua 843, ChatInfoDocumentation.lua 2597).
-- A hidden one is never compared: it counts as another player.
local _, ns = ...

local Adapter = ns.Adapter

local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- True when a name is the player's own: a ready check the player started. The game's own ready
-- check window asks the same way (ReadyCheck.lua 27).
function Adapter.IsPlayer(name)
    local ok, yes = pcall(function()
        return not hidden(name) and type(name) == "string" and UnitIsUnit("player", name)
    end)
    return ok and yes and true or false
end

-- True when a whisper came from the player's own character: a whisper to oneself comes back.
function Adapter.FromPlayer(guid)
    local ok, yes = pcall(function()
        return not hidden(guid) and type(guid) == "string" and guid == UnitGUID("player")
    end)
    return ok and yes and true or false
end
