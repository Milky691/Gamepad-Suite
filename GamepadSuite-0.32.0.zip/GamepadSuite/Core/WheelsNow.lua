-- What a wheel can do now, for the parts that only show it: how many entries a wheel holds (the on-screen button of a
-- wheel is gray while it holds none: Core/AdapterHud.lua Usable), why a bind of My Wheels cannot run now (the page shows
-- that slot dim: Settings/WheelsDraw.lua), and the places of the two wheels that the bags fill (Core/Wheels.lua READ).
local _, ns = ...

local Wheels, Rules = ns.Wheels, ns.WheelRules
local Now = {}
ns.WheelsNow = Now

-- What a wheel can run of a bind, with no healer-mode walk of every bind: that walk changes what an entry does, never
-- whether it runs.
local function runs(bind)
    local act = Wheels.Action(bind, {}, {})
    return act ~= nil and act.type ~= nil
end

-- How many entries a wheel holds now. Each look of an on-screen button asks, in a fight too, so it is cheap: a wheel of
-- the player's own counts the slots whose bind runs (as WheelRules.FromSlots puts them on the ring).
function Wheels.Count(id)
    for _, wheel in ipairs(Wheels.Mine()) do
        if wheel.id == id then
            local count = 0
            for place = 1, Rules.MOST do
                count = count + (wheel.slots[place] and runs(wheel.slots[place]) and 1 or 0)
            end
            return count
        end
    end
    return #Wheels.Entries(id)
end

-- Why a bind of My Wheels cannot run now, in a few words for the page ("Cannot run now: ..."), or nil when it runs: an
-- equipment set with Equipment Sets off (the module's own name), a set that is gone or renamed, any other: not from a wheel.
function Wheels.Why(bind)
    if runs(bind) then
        return nil
    elseif bind.kind == "command" and ns.GearModel and tostring(bind.id):find("CLICK " .. ns.GearModel.BUTTON .. ":", 1, true) == 1 then
        return ns.GearSets and ns.GearSets.on and "the set is gone or renamed" or "Equipment Sets is off"
    end
    return "not from a wheel"
end

-- The places of a wheel that the bags fill, so the thumb learns "up is the potion". list: its entries in kind order
-- (WheelRules.Consumables); before: { [item] = place } from the last read. A thing keeps its place of the eight while it
-- is in the bags; a new thing takes the first free place after the thing before it in kind order (the first one: from
-- the top on); a wheel where no thing kept its place spreads its things in kind order (WheelRules.Spread: four are up,
-- right, down and left, as the ring of four was); a thing used up frees its place. Gives the entries with a fixed place
-- each (x, y, of: eight places), in the order of the places, and the new { [item] = place }.
function Now.Places(list, before)
    local at, taken, kept = {}, {}, false
    for i, entry in ipairs(list) do
        local place = before[entry.item]
        if place and not taken[place] then
            at[i], taken[place], kept = place, true, true
        end
    end
    if not kept then
        local spread = {}
        for place, entry in pairs(Rules.Spread(list)) do
            spread[entry] = place
        end
        for i, entry in ipairs(list) do
            at[i], taken[spread[entry] or 0] = spread[entry], true
        end
    end
    local last, out, places = 0, {}, {}
    for i, entry in ipairs(list) do
        for step = 1, at[i] and 0 or Rules.MOST do
            local place = (last + step - 1) % Rules.MOST + 1
            if not taken[place] then
                at[i], taken[place] = place, true
                break
            end
        end
        last = at[i] or last
        if at[i] then
            entry.x, entry.y = Rules.Direction(at[i], Rules.MOST)
            entry.of, entry.place, places[entry.item] = Rules.MOST, at[i], at[i]
            out[#out + 1] = entry
        end
    end
    table.sort(out, function(a, b) return a.place < b.place end)
    return out, places
end

-- The places are the character's, as the bags are, and live through a reload. id: "consumables" or "quest".
function Wheels.Keep(id, list)
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    local all = GamepadSuiteCharDB.wheelOrder or {}
    GamepadSuiteCharDB.wheelOrder = all
    local placed
    placed, all[id] = Now.Places(list, all[id] or {})
    return placed
end
