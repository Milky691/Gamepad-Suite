-- The rules of builds, with no game calls. A build is one named setup of a character: its binds
-- (every set and layer), My Wheels, the fixed slots, the places of My Wheels, the role switches,
-- a gear set and a talent group it follows, and the markers of spells a load left out:
--   { name =, binds =, wheels =, slots =, places =, roles = { key = value }, gear =, talent =,
--     was = { set = { layer = { key = spell name } } } }
-- A character keeps up to four: GamepadSuiteCharDB.builds = { use = the one in use, list = { build } }.
-- The build in use IS the live state: its binds, wheels, slots and places are the very tables the
-- stores use (Core/Profiles.lua links them), so every change is in it at once. The others keep
-- their own tables. Core/Builds.lua is the module; the switch is Core/Profiles.lua's.
local _, ns = ...

local Rules = {}

Rules.MOST = 4        -- builds of one character
Rules.NAME_MOST = 16  -- letters of a name, as the name of a wheel (decision 62)
-- The role switches: settings that change with a role, kept with each build and set at a switch.
-- Each decides how the build's own binds act, or is the role itself. Every other setting is the
-- account's, the same on every character.
Rules.ROLES = {
    { key = "combat.healer_mode", name = "Healer Mode" },             -- the role: the party wheel, or the bumper's group targeting
    { key = "layers.combat_set", name = "Combat Binds" },             -- whether the build's Combat set is used
    { key = "layers.forms_and_stances", name = "Form and Stance Binds" }, -- whether its form sets are used, and before Combat
    { key = "layers.hold_lb_rb_set", name = "LB + RB Layer" },        -- whether its fifth layer acts
    { key = "combat.targeting", name = "Targeting" },                 -- Cycle puts four binds on its RB and LB
    { key = "combat.dynamic_interact", name = "Dynamic Interact" },   -- which button of its layout interacts
}
Rules.ROLE = {}
for _, role in ipairs(Rules.ROLES) do
    Rules.ROLE[role.key] = true
end
-- A build's bind is our chat command with its name: a button, a wheel and a fixed slot run it as a
-- macro (Core/BindRules.lua Action). The long command, because another addon can take "/gs".
Rules.COMMAND = "/gamepadsuite build"
Rules.ICON = "Interface\\Icons\\Ability_Marksmanship"

local function copy(value)
    if type(value) ~= "table" then
        return value
    end
    local out = {}
    for key, inner in pairs(value) do
        out[key] = copy(inner)
    end
    return out
end
Rules.Copy = copy

-- A typed name: no "|" (the game reads it as a colour or a picture), no line break, no space at its
-- ends, 16 letters at most (letters, not bytes). nil when nothing is left.
function Rules.CleanName(text)
    local clean = tostring(text or ""):gsub("[|%c]", "")
    clean = clean:gsub("^%s+", ""):gsub("%s+$", "")
    local letters, cut = 0, #clean
    for at in clean:gmatch("()[\1-\127\194-\244][\128-\191]*") do
        letters = letters + 1
        if letters > Rules.NAME_MOST then
            cut = at - 1
            break
        end
    end
    clean = clean:sub(1, cut):gsub("%s+$", "")
    return clean ~= "" and clean or nil
end

-- The place of the build with this name, in small or capital letters, or nil.
function Rules.Find(list, name)
    local wanted = tostring(name):lower()
    for at, build in ipairs(list) do
        if tostring(build.name):lower() == wanted then
            return at
        end
    end
    return nil
end

function Rules.IndexOf(list, build)
    for at, one in ipairs(list) do
        if one == build then
            return at
        end
    end
    return nil
end

-- "Build 1", "Build 2"...: the first that no build has as its name. except: a build whose own name does not count.
function Rules.FreeName(list, except)
    local number = 1
    while true do
        local name = "Build " .. number
        local at = Rules.Find(list, name)
        if not at or list[at] == except then
            return name
        end
        number = number + 1
    end
end

-- The role switches as they are now. get(key) gives a setting's value.
-- Form and Stance Binds of a build: it was a switch before 0.26.3. On (or no value) is Form First, and
-- Combat First for a warrior, whose stance is always on (the Combat set first, decision 83); off is Off.
function Rules.FormRole(value, class)
    if value == false then
        return "Off"
    elseif value == true or value == nil then
        return class == "WARRIOR" and "Combat First" or "Form First"
    end
    return value
end

-- Healer Mode of a build: it was a switch before 0.26.5. On is Wheel, off is Off.
function Rules.HealerRole(value)
    if value == true then
        return "Wheel"
    elseif value == false then
        return "Off"
    end
    return value
end

-- The two old switches of a build in the words the settings take now, in place (gives roles, and
-- true when one was old). Login runs it over every build and Undo's copy, once (a build not in use
-- kept true or false for good).
function Rules.FixRoles(roles, class)
    local old = false
    if type(roles) == "table" then
        old = type(roles["combat.healer_mode"]) == "boolean" or type(roles["layers.forms_and_stances"]) == "boolean"
        roles["combat.healer_mode"] = Rules.HealerRole(roles["combat.healer_mode"])
        if type(roles["layers.forms_and_stances"]) == "boolean" then
            roles["layers.forms_and_stances"] = Rules.FormRole(roles["layers.forms_and_stances"], class)
        end
    end
    return roles, old
end

function Rules.Roles(get)
    local out = {}
    for _, role in ipairs(Rules.ROLES) do
        out[role.key] = get(role.key)
    end
    return out
end

-- The builds of a character that has none yet: one, in use, made of the live tables
-- (live = { binds, wheels, slots, places }).
function Rules.First(live, roles)
    return { use = 1, list = { { name = "Build 1", binds = live.binds, wheels = live.wheels, slots = live.slots, places = live.places, roles = copy(roles) } } }
end

-- New Build: a copy of the build in use. The build in use keeps a copy of its tables, and the new
-- build takes the live ones and is in use: nothing is bound again. Gives the new build's place, or
-- nil when the character has four.
function Rules.Add(builds)
    local list = builds.list
    if #list >= Rules.MOST then
        return nil
    end
    local old = list[builds.use]
    list[#list + 1] = { name = Rules.FreeName(list), binds = old.binds, wheels = old.wheels, slots = old.slots, places = old.places,
        roles = copy(old.roles), gear = old.gear, was = copy(old.was) }
    old.binds, old.wheels, old.slots, old.places = copy(old.binds), copy(old.wheels), copy(old.slots), copy(old.places)
    builds.use = #list
    return #list
end

-- A typed name for build `at`. An empty name gives it a number. Gives the new name and the old
-- one, or nil and "taken" when another build has that name (a bind finds a build by its name).
function Rules.Rename(builds, at, text)
    local build = builds.list[at]
    if not build then
        return nil
    end
    local name = Rules.CleanName(text) or Rules.FreeName(builds.list, build)
    local other = Rules.Find(builds.list, name)
    if other and other ~= at then
        return nil, "taken"
    end
    local old = build.name
    build.name = name
    return name, old
end

-- Takes build `at` off. True, or nil and "use": the build in use cannot go (and so neither can the last one).
function Rules.Remove(builds, at)
    if not builds.list[at] then
        return nil
    elseif at == builds.use then
        return nil, "use"
    end
    table.remove(builds.list, at)
    if at < builds.use then
        builds.use = builds.use - 1
    end
    return true
end

-- Next Build: the place of the build after `from` (the build in use when not given), round. nil with one build.
function Rules.Next(builds, from)
    local count = #builds.list
    return count > 1 and (from or builds.use) % count + 1 or nil
end

-- The first build that follows talent group `group`, or nil.
function Rules.ForTalents(builds, group)
    for at, build in ipairs(builds.list) do
        if build.talent == group then
            return at
        end
    end
    return nil
end

-- The markers of a load: lost is { { set, layer, key, spell name } } (Core/ProfileRules.lua Fit). nil when none.
function Rules.Marks(lost)
    local was
    for _, one in ipairs(lost or {}) do
        was = was or {}
        local set, layer = one[1], one[2]
        was[set] = was[set] or {}
        was[set][layer] = was[set][layer] or {}
        was[set][layer][one[3]] = one[4] or "a spell"
    end
    return was
end

-- The spell a button had before a load took it away, or nil.
function Rules.Was(was, set, layer, key)
    local layers = was and was[set]
    return layers and layers[layer] and layers[layer][key] or nil
end

-- The button got a bind: its marker goes. True when there was one. A set with none left goes too.
function Rules.Unmark(was, set, layer, key)
    if not Rules.Was(was, set, layer, key) then
        return false
    end
    was[set][layer][key] = nil
    if next(was[set][layer]) == nil then
        was[set][layer] = nil
    end
    if next(was[set]) == nil then
        was[set] = nil
    end
    return true
end

function Rules.MarkCount(was)
    local count = 0
    for _, layers in pairs(was or {}) do
        for _, keys in pairs(layers) do
            for _ in pairs(keys) do
                count = count + 1
            end
        end
    end
    return count
end

-- The role switches of a profile that this character takes: role keys only, with a value the
-- setting can take (fits(key, value)). An old true or false of a build that was never fixed (another
-- character's) comes in the words of now (class: this character's, Rules.FormRole).
function Rules.FitRoles(roles, fits, class)
    local out = {}
    local now = type(roles) == "table" and Rules.FixRoles(copy(roles), class)
    for _, role in ipairs(now and Rules.ROLES or {}) do
        local value = now[role.key]
        if value ~= nil and fits(role.key, value) then
            out[role.key] = value
        end
    end
    return out
end

-- The places of a profile's wheels that came over (wheels: Fit's wheels), as plain numbers.
function Rules.FitPlaces(places, wheels)
    local out = {}
    for _, wheel in ipairs(wheels and wheels.list or {}) do
        local at = type(places) == "table" and places[wheel.id]
        if type(at) == "table" and type(at.x) == "number" and type(at.y) == "number" then
            out[wheel.id] = { x = at.x, y = at.y }
        end
    end
    return out
end

-- Calls fn(bind) for every bind of a build: every set and layer, the fixed slots, My Wheels.
function Rules.EachBind(build, fn)
    for _, layers in pairs(build.binds or {}) do
        for _, keys in pairs(layers) do
            for _, bind in pairs(keys) do
                fn(bind)
            end
        end
    end
    for _, bind in pairs(build.slots or {}) do
        fn(bind)
    end
    for _, wheel in ipairs(build.wheels and build.wheels.list or {}) do
        for _, bind in pairs(wheel.slots or {}) do
            fn(bind)
        end
    end
end

-- The bind of a build, for the list Builds of the bind list.
function Rules.Entry(name)
    return { kind = "slash", id = "build:" .. name, name = "Build: " .. name, detail = Rules.COMMAND .. " " .. name, icon = Rules.ICON }
end

-- The bind Next Build (Game Actions).
function Rules.NextEntry()
    return { kind = "slash", id = "buildnext", name = "Next Build", detail = Rules.COMMAND, icon = Rules.ICON }
end

-- Our chat command's text after "/gamepadsuite": "build" alone is Next Build (""), "build <name>"
-- that build. nil for any other text.
function Rules.Slash(text)
    local rest = tostring(text or ""):match("^%s*[Bb][Uu][Ii][Ll][Dd](.*)$")
    if not rest or (rest ~= "" and not rest:find("^%s")) then
        return nil
    end
    return (rest:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function count(n, word)
    return n .. " " .. word .. (n == 1 and "" or "s")
end

-- The role switches a change gave new values, as chat words: "Healer Mode is now off." ("" for none).
-- before: Rules.Roles from before the change; get(key) gives a setting's value now.
function Rules.Changed(before, get)
    local out = {}
    for _, role in ipairs(Rules.ROLES) do
        local now = get(role.key)
        if now ~= before[role.key] then
            out[#out + 1] = role.name .. " is now " .. (now == true and "on" or now == false and "off" or tostring(now)) .. "."
        end
    end
    return table.concat(out, " ")
end

-- What a load left out of My Wheels and the fixed slots, by place, for the chat line after it:
-- "Wheel 1 lost 5 entries. Pots is left out. Slots 2 and 5 are empty now." ("" for none).
-- wheels: { { name, count, all = true when none was left } }; slots: the slots' numbers (Core/ProfileRules.lua Fit).
function Rules.CutLine(wheels, slots)
    local out = {}
    for _, one in ipairs(wheels or {}) do
        out[#out + 1] = one.name .. (one.all and " is left out." or (" lost " .. one.count .. (one.count == 1 and " entry." or " entries.")))
    end
    local numbers = copy(slots or {})
    if #numbers > 0 then
        local last = table.remove(numbers)
        out[#out + 1] = (#numbers > 0 and ("Slots " .. table.concat(numbers, ", ") .. " and " .. last .. " are") or ("Slot " .. last .. " is")) .. " empty now."
    end
    return table.concat(out, " ")
end

-- The chat line after a load into build `into`: how many binds came over, how many spells to bind
-- again, how many other binds were left out (cut counts every bind left out, lost the marked
-- spells), where (Rules.CutLine) and the role switches that changed (Rules.Changed).
function Rules.LoadLine(into, name, binds, lost, cut, changed, where)
    local line = into .. " now uses " .. name .. ". " .. count(binds, "bind") .. " came over."
    if lost > 0 then
        line = line .. " " .. count(lost, "spell") .. " to bind again: the Binds page shows where " .. (lost == 1 and "it was." or "they were.")
    end
    local more = cut - lost
    if more > 0 then
        line = line .. " " .. count(more, lost > 0 and "more bind" or "bind") .. (more == 1 and " is" or " are") .. " left out."
    end
    for _, part in ipairs({ where or "", changed or "" }) do
        line = line .. (part ~= "" and " " .. part or "")
    end
    return line
end

if ns then
    ns.BuildRules = Rules
end
return Rules
