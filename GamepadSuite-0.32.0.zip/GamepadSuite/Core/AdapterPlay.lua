-- The adapter, part 3: what the bind core and the on-screen buttons ask the game during play.
-- Every Blizzard name they use is here, each behind a login check of Adapter.lua's list.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

function Adapter.InCombat()
    return InCombatLockdown() and true or false
end

-- What a key does now with every override counted: the game's own text for the binding.
function Adapter.EffectiveBinding(gameKey)
    local ok, action = pcall(GetBindingAction, gameKey, true)
    return ok and action or nil
end

-- True while the game itself holds a key during play: no window has the controller, and one of
-- the game's own key buttons has the key at the level of its window binds. In a party the game
-- does this with View, for its raid window (Blizzard_CompactRaidFrameManager.lua 359 to 376 and
-- 464 to 472). Two times it is no fault and the answer is no: the game's bar is being edited,
-- and LB and RB are held as the game's own layer, which has the two stick clicks
-- (Blizzard_GamepadTargeting/TargetLogic.lua 185 to 217).
function Adapter.GameTookKey(gameKey)
    local ok, took = pcall(function()
        local manager = GamepadSharedUtility.InputBindingManager
        return manager:IsOnlyCoreBindingSetActive() and not manager.assumeCoreBindingsUsable
            and not GamepadMode.IsHUDBindingModifierDown()
            and GetBindingAction(gameKey, true) == "CLICK InputFunctionBindingButton_" .. gameKey .. ":LeftButton"
    end)
    return ok and took or false
end

-- Sticky Layers: the owner frame of the binds hears each press of a button that a key clicks, by
-- the button's name. It can be one of the game's own bar buttons. The game's own wrap does it:
-- the button's own code runs after ours, unchanged, and ControllerForever wraps the game's bar
-- buttons the same way on this game. True when the button is there and is wrapped now.
function Adapter.WatchClicks(name, header, body)
    local button = _G[name]
    return type(button) == "table" and pcall(function()
        assert(button:IsObjectType("Button") and button:IsProtected())
        SecureHandlerWrapScript(button, "OnClick", header, body)
    end) or false
end

-- Tells fn each time the game's own Focus UI runs: its action for View, which says "No
-- interface frame to focus" when no window is open. The game's call is watched, as
-- ControllerForever watches it on this game; nothing of Blizzard's is replaced.
function Adapter.OnFocusUI(fn)
    if results().frameControls and type(GamepadMode.ToggleUIFocus) == "function" then
        hooksecurefunc(GamepadMode, "ToggleUIFocus", function() fn() end)
    end
end

-- The state for binds: is the Combat set in use, and which form's set. combat is the setting
-- Combat Binds; forms is Adapter.Forms(). "Hostile target" counts a live enemy target out of combat too.
function Adapter.BindState(combat, forms, combatFirst)
    local state = { combat = false, combatFirst = combatFirst or nil }
    if combat ~= "Off" then
        state.combat = Adapter.InCombat()
            or (combat == "Hostile target" and UnitCanAttack("player", "target") and not UnitIsDead("target")) and true or false
    end
    local now = GetShapeshiftForm() or 0
    local hidden = IsStealthed ~= nil and IsStealthed()
    -- a set for stealth (Prowl) is after its form in the list, and takes its place while stealthed
    for _, form in ipairs(forms) do
        if (form.index == now or form.index == 0) and (not form.stealth or hidden) then
            state.form, state.base = form.id, form.base
        end
    end
    return state
end

-- The game turns a held controller button into Shift, Ctrl or Alt. Its settings say which button is which.
local EMULATE = { { "GamePadEmulateAlt", "ALT" }, { "GamePadEmulateCtrl", "CTRL" }, { "GamePadEmulateShift", "SHIFT" } }
local freed = {}  -- our key name -> the game's setting that is held at "none" (Adapter.FreeButton)

-- Which modifier key each holding button is now, by our key names: { LT = "SHIFT", LB = "CTRL" }.
-- A button that is held free (Adapter.FreeButton) is none.
function Adapter.Modifiers()
    local mods = {}
    for _, pair in ipairs(EMULATE) do
        local ok, value = Adapter.EmulateSetting(pair[1])
        local ours = ok and value and Adapter.NAME[value]
        if ours and not freed[ours] then
            mods[ours] = pair[2]
        end
    end
    return mods
end

-- The place of a button in the pad's own state (the table of buttons that are down). nil when
-- this game version cannot tell.
function Adapter.PadIndex(ourKey)
    if not results().padButtons then
        return nil
    end
    local ok, index = pcall(C_GamePad.ButtonBindingToIndex, Adapter.KEY[ourKey])
    index = ok and tonumber(index)
    return index and index >= 0 and index + 1 or nil
end

-- A button that the game's settings make Shift, Ctrl or Alt sends no press of its own: a bind on
-- it never runs, and a trigger's layer is not heard. on = true holds that setting at "none" for the
-- session, the game's own way (Adapter.HoldSetting); on = false gives it back. ControllerForever
-- turns LB's Ctrl off for good; here the player's setting comes back at logout.
function Adapter.FreeButton(ourKey, on)
    if on and not freed[ourKey] then
        for _, pair in ipairs(EMULATE) do
            local ok, value = Adapter.EmulateSetting(pair[1])
            if ok and value == Adapter.KEY[ourKey] and Adapter.HoldSetting(pair[1], "none") then
                freed[ourKey] = pair[1]
                Adapter.PadChanged()
                ns.Log.Add("binds", ourKey .. " was " .. pair[2] .. " in the game's settings: it is no modifier for this session, so its press reaches its bind")
            end
        end
    elseif not on and freed[ourKey] then
        Adapter.ReleaseSetting(freed[ourKey])
        freed[ourKey] = nil
        Adapter.PadChanged()
    end
end

-- Mouse mode lets go of the same settings when it ends (Core/AdapterPointer.lua PointerTriggers):
-- the ones held free are held again.
function Adapter.KeepFree()
    for _, name in pairs(freed) do
        Adapter.HoldSetting(name, "none")
    end
end

-- A game setting that a feature of ours needs at one value. It is set for this session only, the
-- game's own way: nothing is written to the player's settings file, and the game puts the
-- player's value back by itself at logout. True when the game took the value.
-- A setting can be lent for a short time to a feature that puts it back after (while the fishing
-- line is out, Adapter.WideInteract): a hold or a release of it in that time waits in Adapter.lent
-- (false: let go), and is what comes back at the end. So a rebuild of the binds then changes nothing.
Adapter.lent = {}
local refused = {}
function Adapter.HoldSetting(name, value)
    if Adapter.lent[name] ~= nil then
        Adapter.lent[name] = value
        return true
    elseif results().tempSetting then
        pcall(C_CVar.SetTempCVar, name, value)
    end
    local ok, now = pcall(GetCVar, name)
    if ok and now == value then
        return true
    end
    if not refused[name] then
        refused[name] = true
        ns.Log.Add("settings", "the game did not take " .. name .. " = " .. tostring(value) .. " (it reads " .. tostring(ok and now) .. ")")
    end
    return false
end

function Adapter.ReleaseSetting(name)
    if Adapter.lent[name] ~= nil then
        Adapter.lent[name] = false
    elseif results().tempSetting then
        pcall(C_CVar.RemoveTempCVar, name)
    end
end

-- The game's own targeting on LB and RB: hold one and push the right stick to select. A short
-- press, with no push, selects the next one where the player's own game settings say so; they are
-- not touched. One setting of the game gives the enemy to the left command
-- (Blizzard_Gamepad/Utility/Bindings/HoldBindings.lua 111 to 117). off = true holds it at "no"
-- for the session: the bind Stick Target: Enemy selects an enemy. off = false gives it back.
function Adapter.TargetSwap(off)
    if off then
        Adapter.HoldSetting("GamepadSwapTargetModifiers", "0")
    else
        Adapter.ReleaseSetting("GamepadSwapTargetModifiers")
    end
end

-- True when the game has its two commands for that targeting. Each runs one function of the game
-- with "is the key down" and no key name, so it does the same on any button
-- (Blizzard_Gamepad/Bindings.xml 21 to 27, HoldBindings.lua 119 to 125).
function Adapter.StickTargeting()
    return type(GamepadMode) == "table" and type(GamepadMode.OnRightTargetModifierChanged) == "function"
        and type(GamepadMode.OnLeftTargetModifierChanged) == "function"
end

-- The pad's own table of the buttons that are down now: place -> true. Empty when the game
-- cannot tell.
function Adapter.PadState()
    local ok, pad = pcall(function()
        return results().padButtons and C_GamePad.GetDeviceMappedState()
    end)
    return ok and type(pad) == "table" and type(pad.buttons) == "table" and pad.buttons or {}
end

-- Which holding buttons are down now: LT, RT, LB, RB. The pad itself is asked first: a button
-- that is no modifier (RT on most setups, LB when no layer needs it) is seen that way only.
-- This is asked many times a second while a button is held. So the places of the four buttons on
-- the pad and the game's modifier settings are kept, and read again only after the game says
-- that a setting or the controller changed, or the binds were built again (Adapter.PadChanged).
-- buttons: the pad's table of buttons, when the caller has read it for this look already.
local kept
function Adapter.PadChanged()
    kept = nil
end

function Adapter.Held(buttons)
    if not kept then
        kept = { mods = Adapter.Modifiers() }
        for _, ourKey in ipairs({ "LT", "RT", "LB", "RB" }) do
            kept[ourKey] = Adapter.PadIndex(ourKey) or false
        end
    end
    local down = { SHIFT = IsShiftKeyDown(), CTRL = IsControlKeyDown(), ALT = IsAltKeyDown() }
    buttons = buttons or Adapter.PadState()
    local function held(ourKey)
        local index = kept[ourKey]
        if index and buttons[index] ~= nil then
            return buttons[index] and true or false
        end
        return kept.mods[ourKey] and down[kept.mods[ourKey]] or false
    end
    return held("LT"), held("RT"), held("LB"), held("RB")
end

-- True while the game highlights something to interact with: a unit, or a thing that is no unit
-- (a mailbox, a herb).
function Adapter.InteractNear()
    local ok, there = pcall(function()
        local exists = UnitExists("softinteract") or (UnitIsGameObject and UnitIsGameObject("softinteract"))
        -- "in reach" is its own question in the game's own bar code
        return exists and (not UnitIsInInteractRange or UnitIsInInteractRange("softinteract"))
    end)
    return ok and there and true or false
end

-- Puts the game's own picture for the highlighted thing on a texture: a speech bubble, a loot
-- bag, a letter, a gear. The plain interact gear when the game has no picture for it.
function Adapter.InteractPicture(texture)
    local ok, has = pcall(SetUnitCursorTexture, texture, "softinteract")
    if not (ok and has) then
        texture:SetTexture("Interface\\Cursor\\Interact")
    end
end

-- This addon's version, as its own file list names it. "unknown" when the game does not tell.
function Adapter.Version()
    local get = C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
    local ok, version = pcall(get, ns.addon, "Version")
    return ok and version or "unknown"
end

function Adapter.AddonLoaded(name)
    local loaded = C_AddOns and C_AddOns.IsAddOnLoaded or IsAddOnLoaded
    return loaded and loaded(name) and true or false
end

-- The game's settings that turn a controller button into Shift, Ctrl or Alt. For the log.
function Adapter.TriggerSettings()
    local out = {}
    for _, name in ipairs({ "GamePadEmulateShift", "GamePadEmulateCtrl", "GamePadEmulateAlt" }) do
        local ok, value = pcall(GetCVar, name)
        out[#out + 1] = name .. "=" .. tostring(ok and value or nil)
    end
    return table.concat(out, ", ")
end


-- Blizzard's own gamepad bar. It is never hidden (its buttons are protected, and its camera keys
-- need it shown). It is made see-through, and Blizzard's own fades are answered the same way.
local barAlpha
function Adapter.NativeBarAlpha(alpha)
    local bar = results().nativeBar and GamepadMainActionBarFrame
    if not bar then
        return
    end
    if barAlpha == nil then
        -- the flag stops the two calls from chasing each other, and another addon's hook on the same bar too
        local busy = false
        hooksecurefunc(bar, "SetAlpha", function(self)
            if barAlpha and not busy then
                busy = true
                self:SetAlpha(barAlpha)
                busy = false
            end
        end)
    end
    barAlpha = alpha
    bar:SetAlpha(alpha)
end

-- True while the game takes its input from a controller.
function Adapter.PadActive()
    local ok, on = pcall(function() return C_GamePad.IsEnabled() end)
    return (not ok or on ~= false) and Adapter.ControllerUI()
end

-- True while the game's own controller interface is on: its setting "Enable Gamepad UI" sets the
-- interface style (Blizzard_SettingsDefinitions_Shared/Gamepad.lua 276 to 291, InputUtil.lua 11 to
-- 13). It is the master switch of the suite's controller parts (Core/Pad.lua). True when the game
-- cannot tell.
function Adapter.ControllerUI()
    local ok, on = pcall(function()
        return C_InputInterfaceStyle.GetCurrentStyle() == Enum.InputDeviceInterfaceType.Gamepad
    end)
    return not ok or on
end

-- Tells fn each time the game switches its interface between controller and mouse.
function Adapter.OnControllerUI(fn)
    pcall(ns.On, "INPUT_DEVICE_INTERFACE_TRANSITION", "Pad", fn)
    ns.On("CVAR_UPDATE", "PadStyle", function(name)
        if name == "InputDeviceInterfaceStyle" then
            fn()
        end
    end)
end

-- The game menu (Escape), or nil.
function Adapter.GameMenu()
    return GameMenuFrame
end

-- Tells fn each time a Blizzard frame shows or hides.
function Adapter.OnShownOrHidden(frame, fn)
    frame:HookScript("OnShow", fn)
    frame:HookScript("OnHide", fn)
end

-- A key for one of our own buttons while a Blizzard window has the controller: a priority bind
-- owned by that button, which clicks it (as mouse, "LeftButton" when none is given). It is not a
-- bind of the player; those are the bind core's. True when the key reads back as that click.
-- Adapter.taken: the game's key -> the click that a button of ours holds it for now. The bind core
-- reads it (Core/BindCheck.lua): a click of ours on a key that is not in it is left over.
Adapter.taken = {}
function Adapter.TakeKey(button, ourKey, mouse)
    -- A fight has started and the game is about to lock the keys: a key that is taken now could
    -- not be given back, and its button would be dead for the whole fight. After a login in a
    -- fight no start was heard, but the keys are locked.
    if ns.fightStarted or InCombatLockdown() then
        return false
    end
    local click = "CLICK " .. button:GetName() .. ":" .. (mouse or "LeftButton")
    SetOverrideBindingClick(button, true, Adapter.KEY[ourKey], button:GetName(), mouse or "LeftButton")
    Adapter.taken[Adapter.KEY[ourKey]] = click
    local twin = Adapter.TWIN and Adapter.TWIN[Adapter.KEY[ourKey]] -- a back button's Steam key too (Core/AdapterGrips.lua)
    if twin then SetOverrideBindingClick(button, true, twin, button:GetName(), mouse or "LeftButton"); Adapter.taken[twin] = click end
    if ns.Send then ns.Send("keys", button:GetName()) end   -- a pop-up's Y hint dims at once (Screen/PopupKey.lua)
    return GetBindingAction(Adapter.KEY[ourKey], true) == click
end

-- In a fight the game refuses it: the keys go when the fight ends, unless the button took one again
-- by then. Until then they are left over, and a key of the bind core under one stays dead.
function Adapter.GiveKeys(button)
    local front = "CLICK " .. tostring(button:GetName()) .. ":"
    local function holds()
        for _, click in pairs(Adapter.taken) do
            if click:sub(1, #front) == front then
                return true
            end
        end
    end
    for key, click in pairs(Adapter.taken) do
        Adapter.taken[key] = click:sub(1, #front) ~= front and click or nil
    end
    if not InCombatLockdown() then
        ClearOverrideBindings(button)
    elseif ns.Queue then
        ns.Queue.Run("GiveKeys " .. tostring(button:GetName()), function()
            return holds() or ClearOverrideBindings(button)
        end)
    end
    if ns.Send then ns.Send("keys", button:GetName()) end
end
