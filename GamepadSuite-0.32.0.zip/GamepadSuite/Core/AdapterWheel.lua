-- The adapter, part 5: what the wheels ask the game.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- The right stick's four direction keys. The game sends them only while its setting
-- GamePadStickAxisButtons is on. A bind on them does not keep the stick from the camera: the
-- stick frames of Screen/Wheel.lua do that.
Adapter.STICK = { UP = "PADRSTICKUP", DOWN = "PADRSTICKDOWN", LEFT = "PADRSTICKLEFT", RIGHT = "PADRSTICKRIGHT" }

-- The consumables and quest items that the game has not loaded yet: id -> true. The game is
-- asked to load each one, and when one comes (the game's own way: ITEM_DATA_LOAD_RESULT,
-- Blizzard_ObjectAPI/Mainline/AsyncCallbackSystem.lua) the bags are read again.
local loading, again = {}, nil
local function arrived(id)
    if loading[id] then
        loading = {}
        ns.Off("ITEM_DATA_LOAD_RESULT", "Consumables")
        again()
    end
end

-- The button HAND of Core/ConsumableRules.lua, made out of a fight (the game locks a secure
-- button's attributes in one). An entry of the consumables wheel clicks it after its use. It has
-- no action; the game's code for its click gives the weapon in the main hand to a use that waits
-- for an item, and does nothing when none waits (Blizzard_FrameXML/SecureTemplates.lua 758 to
-- 784; "/click" sends a click on the let-go, SlashCommands.lua 726 to 742, and the button acts on
-- the let-go, SecureTemplates.lua 802 to 818). A use that still waits after the click is one the
-- main hand cannot take (a sharpening stone and a staff): the log tells, three times at most.
local hand, refused = nil, 0
local function makeHand()
    if hand then
        return
    end
    hand = CreateFrame("Button", ns.ConsumableRules.HAND, UIParent, "SecureActionButtonTemplate")
    hand:RegisterForClicks("AnyUp")
    hand:SetAttribute("useOnKeyDown", false)
    hand:SetAttribute("target-slot", 16)
    hand:HookScript("PostClick", function()
        local ok, waits = pcall(SpellCanTargetItem)
        if ok and waits and refused < 3 then
            refused = refused + 1
            ns.Log.Add("wheel", "an item from the consumables wheel still waits for a pick: the weapon in the main hand did not take it")
        end
    end)
end

-- What the game says of the item in one bag slot, for the consumables wheel and the Quest Item
-- Wheel (Core/ConsumableRules.lua names the fields). The class, the subclass, the picture and
-- what the item has to do with a quest come at once for every item. Its use, name, level and how
-- it binds come only when the game has loaded the item: until then they stay nil, and the game
-- is asked for the item. Only a consumable or a quest item is read that far.
local function bagItem(id, bag, slot)
    local Rules = ns.ConsumableRules
    local ok, _, _, _, _, icon, class, sub = pcall(C_Item.GetItemInfoInstant, id)
    local item = { id = id, icon = ok and icon or nil, class = ok and class or nil, sub = ok and sub or nil }
    local asked, quest = pcall(C_Container.GetContainerItemQuestInfo, bag, slot)
    quest = asked and type(quest) == "table" and quest or {}
    item.quest = quest.isQuestItem or quest.questID ~= nil
    item.starts = quest.questID ~= nil and not quest.isActive
    if item.class ~= Rules.CLASS and item.class ~= Rules.QUEST and not item.quest then
        return item
    end
    local known, cached = pcall(C_Item.IsItemDataCachedByID, id)
    if known and not cached then
        loading[id] = true
        pcall(C_Item.RequestLoadItemDataByID, id)
        return item
    end
    item.use = C_Item.GetItemSpell(id) ~= nil
    -- (only Generic and Other hold things that are not used up: the game is asked about those alone)
    if item.use and item.class == Rules.CLASS and Rules.LOOSE[item.sub] then
        local told, used = pcall(C_Item.IsConsumableItem, id)
        if told then
            item.usedUp = used and true or false
        end
    end
    -- (the fifth answer is the level the item needs, the fourteenth how it binds)
    local got, _, _, _, _, level, _, _, _, _, _, _, _, _, bind = pcall(C_Item.GetItemInfo, id)
    item.level, item.bind = got and level or nil, got and bind or nil
    item.name = C_Item.GetItemNameByID(id)
    return item
end

-- The things in the bags for the two wheels that the bags fill, each item once
-- (Core/ConsumableRules.lua says which things go on each):
--   1. what a player uses up, for the consumables wheel: { id, name, icon, kind, level, text };
--   2. a text for the log: each consumable, with the game's class and subclass numbers, why the
--      ones that are left out are left out, and how many the game still loads. No source says
--      which numbers this game gives a healthstone or a crate, so the log does;
--   3. the quest items to use, for the Quest Item Wheel: { id, name, icon, kind = 1 };
--   4. a text for the log: their numbers, and which of them start a quest.
-- whenLoaded() is called when the game has loaded an item that was not loaded at this read; a
-- read with none (Core/AdapterDestroy.lua) keeps the one that an earlier read gave.
function Adapter.Consumables(whenLoaded)
    local out, quests, seen, took, left, quested = {}, {}, {}, {}, {}, {}
    if not results().bagItems then
        return out, "", quests, ""
    end
    local Rules = ns.ConsumableRules
    -- (a thing that needs a higher level than the character's cannot be used yet)
    local _, level = pcall(UnitLevel, "player")
    loading, again = {}, whenLoaded or again
    if not hand then
        ns.Queue.Run("WheelHand", makeHand)
    end
    for bag = 0, 4 do
        for slot = 1, C_Container.GetContainerNumSlots(bag) do
            local id = C_Container.GetContainerItemID(bag, slot)
            if id and not seen[id] then
                seen[id] = true
                local item = bagItem(id, bag, slot)
                local kind, why = Rules.Kind(item, type(level) == "number" and level or nil)
                local numbers = id .. " (" .. tostring(item.class) .. "." .. tostring(item.sub)
                if kind then
                    out[#out + 1] = { id = id, name = item.name or "", icon = item.icon, kind = kind, level = item.level, text = Rules.Text(item), calm = Rules.CALM[kind] }
                    took[#took + 1] = numbers .. " " .. Rules.NAME[kind] .. ")"
                elseif item.class == Rules.CLASS then
                    left[#left + 1] = numbers .. ", " .. why .. ")"
                end
                if Rules.Quest(item) then
                    quests[#quests + 1] = { id = id, name = item.name or "", icon = item.icon, kind = 1 }
                    quested[#quested + 1] = id .. (item.starts and " (starts a quest)" or "")
                end
            end
        end
    end
    local waits = 0
    for _ in pairs(loading) do
        waits = waits + 1
    end
    -- (an event this game version does not have is left out)
    if waits > 0 and again then
        pcall(ns.On, "ITEM_DATA_LOAD_RESULT", "Consumables", arrived)
    else
        ns.Off("ITEM_DATA_LOAD_RESULT", "Consumables")
    end
    table.sort(took)
    table.sort(left)
    table.sort(quested)
    return out, "on it " .. (took[1] and table.concat(took, ", ") or "nothing") .. "; left out " .. (left[1] and table.concat(left, ", ") or "nothing")
        .. "; the game still loads " .. waits, quests, "on it " .. (quested[1] and table.concat(quested, ", ") or "nothing")
end

-- The spells of a list that the character knows: { id, name, icon, cast }.
function Adapter.KnownSpells(ids)
    local out = {}
    for _, id in ipairs(ids) do
        local ok, known = pcall(function()
            return (C_SpellBook and C_SpellBook.IsSpellKnown and C_SpellBook.IsSpellKnown(id))
                or (IsPlayerSpell and IsPlayerSpell(id)) or (IsSpellKnown and IsSpellKnown(id))
        end)
        local name = ok and known and C_Spell.GetSpellName(id)
        if name then
            out[#out + 1] = { id = id, name = name, icon = C_Spell.GetSpellTexture(id), cast = Adapter.SpellCastName(id) or name }
        end
    end
    return out
end

-- The player's class as the game names it in code ("MAGE"), and the colour of a class (the
-- player's own when none is given).
function Adapter.Class()
    local _, class = UnitClass("player")
    return class
end

function Adapter.ClassColor(class)
    local color = RAID_CLASS_COLORS and RAID_CLASS_COLORS[class or Adapter.Class()]
    if color then
        return color.r, color.g, color.b
    end
    return 1, 1, 1
end

-- The right stick's place in the pad's own state. The game's own code finds a stick by asking
-- the name of each place (Blizzard_GamepadSharedUtility/InputBindingStack/InputAxisBinding.lua
-- 9 to 13); the call by name is not in this build's notes. Read once a pad is there, and kept;
-- 2 until then, or when no place is named "Right". The log has the names one time.
local rightStick
function Adapter.RightStickIndex()
    if rightStick then
        return rightStick
    end
    local names, found = {}, nil
    pcall(function()
        for i = 1, C_GamePad.GetDeviceMappedState().stickCount do
            names[i] = tostring(C_GamePad.StickIndexToConfigName(i - 1))
            found = found or (names[i] == "Right" and i) or nil
        end
    end)
    if not names[1] then
        return 2
    end
    rightStick = found or 2
    ns.Log.Add("wheel", "the pad's sticks by place: " .. table.concat(names, ", ") .. "; the right stick is place " .. rightStick)
    return rightStick
end

-- Where the right stick is now: x (right is more) and y (up is more), each from -1 to 1.
-- 0, 0 when the game cannot tell.
function Adapter.RightStick()
    local ok, x, y = pcall(function()
        local stick = C_GamePad.GetDeviceMappedState().sticks[Adapter.RightStickIndex()]
        return stick.x + 0, stick.y + 0
    end)
    if ok then
        return x, y
    end
    return 0, 0
end

-- The whole screen in the units of a place on it, wide and high: a place is in the units of the mockup, 900 to the
-- game's 768 (Look/Theme.lua px). The game's screen is 768 of its units high at UI scale 1 and 768 / scale at another
-- (UIParent is the whole screen), so a smaller UI scale gives more room: 1600 x 900 at scale 1 on a 16 to 9 screen,
-- 2500 x 1406 at 0.64.
function Adapter.ScreenUnits()
    return UIParent:GetWidth() / ns.Theme.px(1), UIParent:GetHeight() / ns.Theme.px(1)
end

-- True for a value the game hides from addon code in a fight. A compare or a sum with one is an error.
local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- The units of the player's party, the player first: "player", "party1", ... In a raid the player's
-- own raid group: the player, then the others of that group in the raid's order ("raid7"), five at
-- most. A group is found as the game's raid frames find it: the raid number of each member and its
-- group (Blizzard_CompactRaidFrameContainer.lua 396). Empty in no group, and in a raid while the
-- game hides who is in which group (the log says so one time). The second answer is every raid group
-- that has members, for the raid's party wheel: { [group] = its units in the raid's order, five at most,
-- the player's own with "player" first }; empty out of a raid, in a raid of one, and while the game hides it.
local raidHidden, raidSaid, raidLines = false, nil, 0
function Adapter.PartyUnits()
    local out, all = {}, {}
    local ok, err = pcall(function()
        if IsInRaid() then
            local groups, mine = {}, nil
            for i = 1, GetNumGroupMembers() do
                local _, _, group = GetRaidRosterInfo(i)
                local me = UnitIsUnit("raid" .. i, "player")
                if hidden(group) or hidden(me) then
                    error("the game hides who is in which raid group", 0)
                end
                -- (the player's own number has false: the player is first already)
                groups[i], mine = not me and group or false, me and group or mine
            end
            out[1], all[mine or 0] = "player", { "player" }
            for i, group in ipairs(groups) do
                if group == mine and #out < 5 then
                    out[#out + 1] = "raid" .. i
                end
                local list = all[group or 0] or {}
                all[group or 0] = list
                if #list < 5 then
                    list[#list + 1] = "raid" .. i
                end
            end
            all[0] = nil
            all = GetNumGroupMembers() > 1 and all or {}
        elseif IsInGroup() then
            out[1] = "player"
            for i = 1, 4 do
                if UnitExists("party" .. i) then
                    out[#out + 1] = "party" .. i
                end
            end
        end
    end)
    if not ok and not raidHidden then
        raidHidden = true
        ns.Log.Add("wheel", tostring(err) .. ": the party wheel has no raid group now")
    end
    -- (the raid group the party wheel has, and the groups with members, when they change: five lines at most)
    local text, list = ok and IsInRaid() and table.concat(out, " "), {}
    for group = 1, 8 do
        list[#list + 1] = all[group] and group or nil
    end
    text = text and text .. "; the groups with members: " .. (list[1] and table.concat(list, ", ") or "none")
    if text and text ~= raidSaid and raidLines < 5 then
        raidSaid, raidLines = text, raidLines + 1
        ns.Log.Add("wheel", "in a raid the party wheel has the player's group: " .. text)
    end
    return ok and out or {}, ok and all or {}
end

-- True when the game hides an item's cooldown from addon code now: then no swipe shows for it
-- (Adapter.ShowCooldown). For the log of the wheels; false when the game cannot tell.
function Adapter.ItemCooldownHidden(id)
    local ok, start = pcall(function()
        return C_Container.GetItemCooldown(id)
    end)
    return ok and hidden(start) or false
end

-- Healer mode asks the game three things about a spell, or about an item when kind is "item":
-- can it be cast on a friend, can it be cast on an enemy, and does it reach out to a target.
-- The first answer is true for one that can be cast on a friendly player: a heal, a buff, a
-- cure, a resurrection, a bandage. One with no reach is on the player only (a form, a potion)
-- and is not one. The second answer is true when it can be cast on an enemy too. The third is
-- the game's answers as text, for the log: no source says what the game answers for one spell
-- (each rank is a spell of its own on this game), so the log does. Where an answer for a spell
-- is not yes, the game is asked a second way: for the slot of its own bar that holds the spell
-- (slot, when the caller has one), as the game's bar buttons ask (ActionBarFrameDocumentation.lua
-- 574 to 589 and 798 to 813), and for the reach in the spell's own data (C_Spell.GetSpellInfo).
function Adapter.FriendlySpell(id, kind, slot)
    local item = kind == "item"
    local from = item and { C_Item.IsHelpfulItem, C_Item.IsHarmfulItem, C_Item.ItemHasRange }
        or { C_Spell.IsSpellHelpful, C_Spell.IsSpellHarmful, C_Spell.SpellHasRange }
    local answer = {}
    for i = 1, 3 do
        local ok, yes = pcall(from[i], id)
        -- "?" when the game has no such call, refuses it or hides the answer
        answer[i] = (not ok or hidden(yes)) and "?" or yes and true or false
    end
    local text = "helpful " .. tostring(answer[1]) .. ", harmful " .. tostring(answer[2]) .. ", reach " .. tostring(answer[3])
    local helpful, reach = answer[1] == true, answer[3] == true
    -- (a spell for an enemy alone is not asked again)
    if not item and not (helpful and reach) and (helpful or answer[2] ~= true) then
        local function ask(fn, ...)
            local ok, yes = pcall(fn, ...)
            return ok and not hidden(yes) and yes == true
        end
        local ok, info = pcall(C_Spell.GetSpellInfo, id)
        local far = ok and type(info) == "table" and type(info.maxRange) == "number" and not hidden(info.maxRange) and info.maxRange > 0
        local slotHelpful = slot and ask(C_ActionBar.IsHelpfulAction, slot, false) or false
        local slotReach = slot and ask(C_ActionBar.HasRangeRequirements, slot) or false
        helpful, reach = helpful or slotHelpful, reach or slotReach or far
        text = text .. "; its slot: " .. (slot and ("helpful " .. tostring(slotHelpful) .. ", reach " .. tostring(slotReach)) or "none")
            .. "; its data: reach " .. tostring(far)
    end
    -- A spell the game calls neither helpful nor harmful that reaches another unit (Dispel Magic,
    -- Resurrection: the owner, 0.24.1) counts for friend and enemy: a live enemy target gets the
    -- cast, any other target the party wheel. A hidden "helpful" answer with no harm and a reach is
    -- a friendly spell: its party wheel, never a cast at an enemy. Only a spell for an enemy alone
    -- or for the player alone (no reach) is left to cast as it is.
    local both = reach and not helpful and answer[1] == false and answer[2] == false
    local unsure = reach and answer[1] == "?" and answer[2] == false
    return (helpful or both or unsure) and reach, answer[2] == true or both, both and text .. "; for friend and enemy" or text
end

-- The spell in the game's own slot of a button on a layer (1 no trigger, 2 LT, 3 RT, 4 LT + RT),
-- and that slot. It is the slot of that layer's own bar, also while the game's stance bar stands
-- for the bar in a form. The button works its slot out from the bar's page each time (its own
-- CalculateAction, Blizzard_GamepadActionBars/ActionBarButton.lua 871 to 878, as Adapter.NativeAction
-- runs it), so the slot of the page in use is read. nil for an empty slot, for a slot that holds
-- no spell, and for a pad button that is not one of the game's eight.
local BAR = { "topBar", "leftBar", "rightBar", "bottomBar" }
function Adapter.NativeSpell(ourKey, layer)
    local ok, id, slot = pcall(function()
        local bar = GamepadMainActionBarFrame.PageUnit.actionBars[BAR[layer]]
        local slot = bar:GetActionButtonByIndex(Adapter.NativeIndex(ourKey)):CalculateAction()
        local kind, id = GetActionInfo(slot)
        return kind == "spell" and id or nil, slot
    end)
    if ok and type(id) == "number" and not hidden(id) then
        return id, slot
    end
    return nil
end

-- The portrait of a unit, on a texture.
function Adapter.Portrait(texture, unit)
    pcall(SetPortraitTexture, texture, unit)
end

-- The game's own buttons that open a window, by the game command each one stands for:
-- { TOGGLESPELLBOOK = "SpellbookMicroButton", ... }. A menu button keeps its command on itself as
-- commandName. The button of the game menu acts only with the mouse over it, so it is not here.
local MENU_BUTTONS = {
    "CharacterMicroButton", "SpellbookMicroButton", "TalentMicroButton", "ProfessionMicroButton", "AchievementMicroButton",
    "LegacyMicroButton", "QuestLogMicroButton", "GuildMicroButton", "LFDMicroButton", "CollectionsMicroButton", "EJMicroButton",
}
function Adapter.MenuButtons()
    local out = {}
    for _, name in ipairs(MENU_BUTTONS) do
        local button = _G[name]
        local command = type(button) == "table" and button.commandName
        if type(command) == "string" and not out[command] then
            out[command] = name
        end
    end
    -- in this game the quest log and the world map are one window, opened by the quest log's button
    out.TOGGLEWORLDMAP = out.TOGGLEWORLDMAP or out.TOGGLEQUESTLOG
    -- the bags: a click on the game's backpack button
    if type(_G.MainMenuBarBackpackButton) == "table" then
        out.TOGGLEBACKPACK = out.TOGGLEBACKPACK or "MainMenuBarBackpackButton"
        out.OPENALLBAGS = out.OPENALLBAGS or "MainMenuBarBackpackButton"
    end
    -- an equipment set on a wheel: the click of its own button (Auto/GearSets.lua)
    for command, click in pairs(ns.GearSets and ns.GearSets.on and ns.GearSets.Clicks() or {}) do
        out[command] = click
    end
    return out
end
