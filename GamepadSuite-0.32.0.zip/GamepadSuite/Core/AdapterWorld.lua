-- The adapter's part for four small things: Hide Error Spam (Auto/ErrorSpam.lua), the bind Peek Map
-- (Windows/PeekMap.lua), the quest objective sound (Auto/ObjectiveSound.lua) and Object Names (Auto/ObjectNames.lua).
-- Pack: build_plan/packs/P15_world_small.md.
local _, ns = ...

local Adapter = ns.Adapter

-- ---------------------------------------------------------------- Hide Error Spam
-- The red lines in the middle of the screen are the game's UIErrorsFrame. Its own switch hides one type of line:
-- SetMessageTypeEnabled(type, false) puts the type on the game's list BLACK_LISTED_MESSAGE_TYPES, and a line of a
-- type on that list does not show and plays no voice (Blizzard_UIErrorsFrame/Mainline/UIErrorsFrame.lua 103 to 107,
-- 133 to 157). This game starts the list with one type, another action in progress (Camelot/UIErrorsFrameOverrides.lua
-- 1 to 3), so it shows "not enough rage" and the like. ControllerForever uses the same switch on this game.
Adapter.Check("errorTypes", function()
    return type(UIErrorsFrame) == "table" and type(UIErrorsFrame.SetMessageTypeEnabled) == "function"
        and type(BLACK_LISTED_MESSAGE_TYPES) == "table"
end)

-- The game's number of each type of line, by its name ("LE_GAME_ERR_OUT_OF_RAGE"), and the names this build does
-- not have.
function Adapter.ErrorTypes(names)
    local found, missing = {}, {}
    for _, name in ipairs(names) do
        if type(_G[name]) == "number" then
            found[#found + 1] = _G[name]
        else
            missing[#missing + 1] = name
        end
    end
    return found, missing
end

-- True while the game hides lines of this type.
function Adapter.ErrorHidden(number)
    return BLACK_LISTED_MESSAGE_TYPES[number] and true or false
end

-- Shows or hides the lines of a type, with the game's own switch. The frame is no protected frame: in a fight too.
function Adapter.ShowErrors(number, show)
    UIErrorsFrame:SetMessageTypeEnabled(number, show)
end

-- ---------------------------------------------------------------- Peek Map
-- In this game the quest log and the world map are one window, and the quest log's button opens and closes it
-- (Blizzard_MicroMenu/Mainline/MainMenuBarMicroButtons.lua 1136 to 1140, Blizzard_WorldMap/QuestLogOwnerMixin.lua
-- 54 to 62), as a wheel opens it (Core/AdapterWheel.lua MenuButtons). The window's own close button only closes it
-- (Blizzard_SharedXML/Mainline/SharedUIPanelTemplates.xml 658 to 661, Blizzard_WorldMap/Blizzard_WorldMap.xml 121).
-- Both are the game's own clicks, the same as the player's: the window is never opened or closed by our code
-- (ImprovedForever found on this game that a window opened from addon code is tainted: its PeekMap.lua 7).
local QUEST_BUTTON = "QuestLogMicroButton"

Adapter.Check("peekMap", function()
    local map = WorldMapFrame
    return type(_G[QUEST_BUTTON]) == "table" and type(map) == "table" and type(map.BorderFrame) == "table"
        and type(map.BorderFrame.CloseButton) == "table"
end)

-- The bind's button. With "pressAndHoldAction" the game runs "type" as the key goes down and "typerelease" as it
-- comes up (Blizzard_FrameXML/SecureTemplates.lua 802 to 826; the pole's button does the same, Core/AdapterHands.lua):
-- the press is a click on the quest log's button, the let-go a click on the map's close button. The attributes never
-- change, so the button needs no restricted code. Made out of a fight: the game locks the attributes in one.
function Adapter.PeekButton(name)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    button:RegisterForClicks("AnyDown", "AnyUp")
    button:SetAttribute("pressAndHoldAction", true)
    button:SetAttribute("type", "macro")
    button:SetAttribute("macrotext", "/click " .. QUEST_BUTTON)
    button:SetAttribute("typerelease", "click")
    button:SetAttribute("clickbutton", WorldMapFrame.BorderFrame.CloseButton)
    return button
end

function Adapter.MapShown()
    return WorldMapFrame:IsShown() and true or false
end

-- ---------------------------------------------------------------- Objective Sound
-- The quest log as the game's own quest list reads it (C_QuestLog: Blizzard_APIDocumentationGenerated/
-- QuestLogDocumentation.lua; the arguments are plain quest numbers, and nothing comes back hidden).
Adapter.Check("questSound", function()
    return C_QuestLog.GetNumQuestLogEntries and C_QuestLog.GetInfo and C_QuestLog.GetQuestObjectives and C_QuestLog.IsComplete
        and SOUNDKIT.UI_QUEST_ROLLING_FORWARD_01 and SOUNDKIT.UI_AUTO_QUEST_COMPLETE and true
end)

-- Every quest of the log as it is now: { [quest number] = { done = the whole quest is complete, [n] = objective n is
-- done } }. The headers and the quests the log hides are left out. A quest the game completes by itself is never
-- "done" here: the game plays the quest's sound with its own pop-up (Blizzard_ObjectiveTracker/
-- Blizzard_AutoQuestPopUpTracker.lua 37).
-- Limit: a quest under a collapsed header is not in the log's list, so it is not seen; add the watch list if it matters.
function Adapter.QuestStates()
    local out = {}
    for index = 1, (C_QuestLog.GetNumQuestLogEntries()) do
        local info = C_QuestLog.GetInfo(index)
        if info and info.questID and not info.isHeader and not info.isHidden then
            -- auto: the game completes the quest by itself and sounds with its own pop-up (Auto/ObjectiveSoundModel.lua)
            local state = { done = not info.isAutoComplete and C_QuestLog.IsComplete(info.questID) and true or false, auto = info.isAutoComplete or nil }
            for n, objective in ipairs(C_QuestLog.GetQuestObjectives(info.questID) or {}) do
                state[n] = objective.finished and true or false
            end
            out[info.questID] = state
        end
    end
    return out
end

-- ---------------------------------------------------------------- Object Names
-- The game's name plate over the thing in reach that can be used: its setting SoftTargetNameplateInteract ("Always show
-- nameplates for soft interact target"), which the game's gamepad mode holds off (Blizzard_Gamepad/Core.lua 23). The
-- game's name plate leaves the health bar off for an object (Blizzard_NamePlates/Blizzard_NamePlateHealthBar.lua 37, 176).
Adapter.Check("objectNames", function()
    return type(UnitIsGameObject) == "function" and C_EventUtils.IsEventValid("PLAYER_SOFT_INTERACT_CHANGED") == true
end)

-- True while the thing in reach that can be used is an object of the world, not a person: the game's own answer (its
-- name plates ask the same), or a GUID of an object, as ConsolePort tells them (Controller/Targeting.lua 181). A hidden
-- answer counts as no.
local function plain(value)
    return not (issecretvalue and issecretvalue(value))
end
function Adapter.ObjectInReach()
    local ok, yes, guid = pcall(function() return UnitIsGameObject("softinteract"), UnitGUID("softinteract") end)
    return ok and ((plain(yes) and yes == true) or (plain(guid) and type(guid) == "string" and guid:find("^GameObject") ~= nil)) or false
end

-- The name plate over it: on (true), off as the game's gamepad mode has it (false), or the setting given back (nil).
function Adapter.ObjectName(on)
    if on == nil then
        Adapter.ReleaseSetting("SoftTargetNameplateInteract")
    else
        Adapter.HoldSetting("SoftTargetNameplateInteract", on and "1" or "0")
    end
end
