-- Press and Hold Casting, the value "All spell binds": each spell that the player has on a
-- button, with no receiver of its own, is put into a slot of the game's keyboard bars, and the
-- bind core gives the button that slot's key command in place of a click on a button of ours.
-- The press then reaches the game as a key press on one of its own bar buttons, the one way the
-- game casts again while a key is held (Core/HoldRules.lua, Core/AdapterSlots.lua).
--
-- The player's bars are the player's. Only a slot that holds nothing is used, so nothing of the
-- player's is ever moved. What is kept for the character is only which slots hold a spell of
-- ours. When a slot is no longer needed, or the row gets another value, our spell is taken out
-- of it, and only while the slot still holds that spell. A slot of ours that holds another thing
-- was changed by hand: it is the player's and nothing is changed there. Slots are written out
-- of a fight only: the bind core asks for the slots inside its own queue.
--
-- A key that is down when its bind changes (a trigger let go first, a form, a fight). The game
-- most likely runs the let-go of the command that was pressed, as for a keyboard key, and then
-- nothing is needed. This file looks for the other case: a press of a slot's key whose earlier
-- press got no let-go while no other button is down. For the rest of the session the owner frame
-- of the binds then makes a key that is down keep its command until it is up ("keep",
-- Core/BindSecure.lua). It is not kept longer: one let-go can be lost for another reason (the
-- game's window lost the focus).
local _, ns = ...

local Hold = ns.Module("HoldSlots", { "secure", "actionSlots" }, "Press and Hold Casting: All spell binds")
ns.HoldSlots = Hold

local Rules = ns.HoldRules

local saved                    -- for the character: slots = { [slot] = { spell = number } }
local commandOf, spellOf = {}, {}   -- spell -> its slot's key command, and back, as the bind plan has them
local lines, lastLine = 0, nil -- lines about the slots in this session, and the last one
local busy = false             -- the slots are being written now
local keep = false             -- the guard is on for this session
local open = {}                -- command -> true: its key went down and its let-go did not come yet
local watch, notes = nil, 0    -- the held press that is measured for the log; how many were logged
local starts = { [true] = 0, [false] = 0 }   -- how many presses were measured: of our slots, of the game's

local function name(spell)
    return tostring(ns.Adapter.SpellCastName(spell) or spell)
end

local function names(spells)
    local out = {}
    for i, spell in ipairs(spells) do
        out[i] = name(spell)
    end
    return table.concat(out, ", ")
end

-- The slots follow the binds. Gives { [spell] = key command } for the bind plan. The bind core
-- calls it when it builds the binds, which is out of a fight. noSlot: the layers whose binds get
-- no slot command (Core/BindShape.lua).
function Hold.Sync(noSlot)
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    saved = GamepadSuiteCharDB.holdslots or {}
    GamepadSuiteCharDB.holdslots = saved
    saved.slots = saved.slots or {}
    local all = ns.Registry.Get("combat.press_and_hold") == Rules.ALL
    commandOf, spellOf = {}, {}
    -- (nothing of ours is on a bar and nothing is to go there: the bars are not read at all)
    if not all and not next(saved.slots) then
        return commandOf
    end
    -- a button with the bind "Slot 3" casts what that fixed slot holds: its spell gets a slot too
    local function each(fn)
        ns.Binds.Each(function(bind, ...)
            fn(ns.BindRules.Real(bind), ...)
        end)
    end
    local plan = Rules.Assign(all and Rules.Wanted(each, noSlot, ns.Adapter.FormSpells()) or {}, saved.slots, ns.Adapter.HoldBarSlots())
    -- (set only around the writes: a fault in the plan must not leave the player's own changes of
    -- a slot unheard for the rest of the session)
    busy = true
    for _, slot in ipairs(plan.taken) do
        saved.slots[slot] = nil
    end
    local out = 0
    for _, slot in ipairs(plan.back) do
        if ns.Adapter.SlotTake(slot, saved.slots[slot].spell) then
            saved.slots[slot], out = nil, out + 1
        end
    end
    local refused = {}
    for _, one in ipairs(plan.put) do
        -- (the record is there before the write: a write that the game cuts short is still known)
        saved.slots[one.slot] = { spell = one.spell }
        if ns.Adapter.SlotPut(one.slot, one.spell) then
            plan.map[one.spell] = one.command
        else
            refused[#refused + 1] = one.spell
            saved.slots[one.slot] = nil
        end
    end
    busy = false
    local list = {}
    for spell, command in pairs(plan.map) do
        commandOf[spell], spellOf[command] = command, spell
        list[#list + 1] = name(spell) .. " on " .. command:gsub("MULTIACTIONBAR(%d)BUTTON(%d+)", "bar %1 button %2")
    end
    table.sort(list)
    local text = all and (#list .. " spell binds have a slot of the keyboard bars" .. (#list > 0 and " (" .. table.concat(list, "; ") .. ")" or "")
        .. ". " .. plan.empty .. " slots held nothing and could be used.") or "the row has another value."
    text = text .. (#plan.none > 0 and " No empty slot is left for: " .. names(plan.none) .. " (one cast for each press)." or "")
        .. (#refused > 0 and " The game refused the write of: " .. names(refused) .. " (one cast for each press)." or "")
        .. (out > 0 and " Our spell was taken out of " .. out .. " slots." or "")
        .. (#plan.taken > 0 and " Slot " .. table.concat(plan.taken, ", ") .. " holds another thing now: it is the player's, and nothing was changed there." or "")
    if lines < 14 and text ~= lastLine then
        lines, lastLine = lines + 1, text
        ns.Log.Add("binds", "Press and Hold: " .. text)
    end
    return commandOf
end

-- For the owner frame of the binds, while the guard is on: which key commands are a slot's, and
-- the place on the pad of the button behind each key name. write is the bind core's own writer.
function Hold.Write(write, keyList, keys)
    if not (keep and next(commandOf)) then
        return
    end
    write("keep", true)
    for _, command in pairs(commandOf) do
        write("slot:" .. command, true)
    end
    local index = {}
    for ours, theirs in pairs(keys) do
        index[theirs] = ns.Adapter.PadIndex(ours)
    end
    for _, key in ipairs(keyList) do
        write("pad:" .. key, index[key:match("[^-]+$")])
    end
end

-- The game ran the press or the let-go of a slot's key command.
local function pressed(command, down)
    local spell = spellOf[command]
    if not spell then
        return
    end
    if down then
        if open[command] and not keep and ns.Adapter.PadKeysDown() <= 1 then
            keep = true
            ns.Log.Add("binds", "Press and Hold: an earlier press of " .. name(spell) .. " got no let-go from the game. "
                .. "For this session a key that is down keeps its command until it is up.")
            ns.BindCore.Rebuild()
        end
        open[command] = true
        -- the on-screen buttons show the press, as for a click on a button of ours
        ns.Send("press", ns.BindCore.Signature({ kind = "spell", id = spell }))
        return
    end
    open[command] = nil
    -- (out of a fight the owner frame is told at once that a key which kept its command can get its bind)
    ns.BindCore.Flag("late", false)
end

-- A held key press of a slot, measured: does the game begin another cast of the spell while the
-- key is still down? Only the game casts again, and only for a key press on one of its own bar
-- slots: a slot of ours, or a spell the player keeps on the game's controller bar with no bind of
-- ours there ("Game buttons"). Both are measured, so one try in the game compares them. What
-- counts is a cast that begins before the let-go: a cast with a cast time lands after it
-- (Healing Touch, two seconds: the second cast of a hold of 3.8 s lands at 4 s). A hold that ends
-- less than 3 s after the first cast landed is too short to tell (the global cooldown, and the
-- game's wait between two tries). A press that does not reach the game as a key press never
-- casts again (SecureTemplates.lua 806 to 818) and is not measured, nor is any press while the
-- row is at Off (the game's own setting is off then, and its let-go never comes). A hold of 2 s
-- or more is written, eight in a session; twenty presses of each kind are measured at most, so a
-- player who never holds that long does not pay for it all session.
local function cast(spell, step)
    if not watch then
        return
    end
    -- (a let-go that never came: after 30 s the casts are no longer heard)
    if GetTime() - watch.at > 30 then
        watch = nil
        ns.Adapter.HearCasts(nil)
        return
    end
    if spell == nil then
        -- (the game hides the spell in a combat: such a cast cannot be told from another)
        watch.hidden = watch.hidden + 1
        return
    end
    if spell ~= watch.spell then
        return
    end
    if step == "start" or (step == "done" and not watch.casting) then
        watch.begun = watch.begun + 1
    elseif step == "refused" then
        watch.refused = watch.refused + 1
    end
    if step == "done" or step == "stop" then
        watch.landed = watch.landed or GetTime()
    end
    -- (a try that the game refuses while the cast goes on does not end that cast)
    if step ~= "refused" then
        watch.casting = step == "start"
    end
end

local function verdict(w)
    if w.begun > 1 then
        return "it casts again while the button is held."
    elseif w.refused > 0 and w.begun > 0 then
        return "it tries again, and the game does not let the cast go."
    elseif w.hidden > 0 then
        return "the game hid which spell was cast. Try it out of combat."
    elseif w.begun == 0 then
        return "the game did not cast it at all."
    elseif not w.landed or GetTime() - w.landed < 3 then
        return "the let-go came too soon to tell. Hold it until one cast lands and 3 s more."
    end
    return "it does not cast again while held."
end

local function used(slot, keyPress, spell, pad)
    if keyPress == nil then
        if watch and watch.slot == slot then
            local held, w = GetTime() - watch.at, watch
            watch = nil
            ns.Adapter.HearCasts(nil)
            if held >= 2 then
                notes = notes + 1
                ns.Log.Add("binds", string.format("Press and Hold: %s %s was held %.1f s. The game began %d %s of it while it was held%s%s: %s",
                    name(w.spell), w.ours and "in our slot " .. w.slot or w.pad and "on the game's controller bar" or "in the game's bar slot " .. w.slot,
                    held, w.begun, w.begun == 1 and "cast" or "casts",
                    w.refused > 0 and ", and refused " .. w.refused .. (w.refused == 1 and " try" or " tries") or "",
                    w.uses > 1 and ", and the press ran the slot " .. w.uses .. " times" or "", verdict(w)))
            end
        end
    elseif watch and watch.slot == slot then
        watch.uses = watch.uses + 1
    elseif keyPress and spell and notes < 8 and ns.Registry.Get("combat.press_and_hold") ~= "Off" then
        -- (a press of another slot starts a new measure: a let-go that never came ends nothing)
        local ours = saved and saved.slots[slot] and true or false
        if starts[ours] < 20 then
            starts[ours] = starts[ours] + 1
            watch = { slot = slot, spell = spell, ours = ours, pad = pad, at = GetTime(), begun = 0, refused = 0, hidden = 0, uses = 1 }
            ns.Adapter.HearCasts(cast)
        end
    end
end

function Hold.OnLogin()
    if not ns.Adapter.OnHoldBarKey(function(command, down)
        ns.Call("HoldSlots", pressed, command, down)
    end) then
        ns.Log.Add("binds", "Press and Hold: the game does not have the key commands of its keyboard bars")
    end
    if not ns.Adapter.OnActionUse(function(slot, keyPress, spell, pad)
        ns.Call("HoldSlots", used, slot, keyPress, spell, pad)
    end) then
        ns.Log.Add("binds", "Press and Hold: the game's use of an action slot cannot be heard, so a held press is not measured")
    end
    -- A slot of ours got another thing by the player's hand: the binds are built again, and the
    -- slot is the player's from then. The game tells the same event for our own writes, also
    -- while they are made: those change nothing here.
    ns.On("ACTIONBAR_SLOT_CHANGED", "HoldSlots", function(slot)
        local ours = not busy and saved and saved.slots[slot]
        local now = ours and ns.Adapter.SlotRead(slot)
        if ours and not (now and now.kind == "spell" and now.id == ours.spell) then
            ns.BindCore.Rebuild()
        end
    end)
end
