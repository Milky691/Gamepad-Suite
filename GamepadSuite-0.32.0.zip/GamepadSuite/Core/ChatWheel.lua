-- Quick chat: a wheel of eight short lines, for a player who has no keyboard at hand in a pull.
-- The bind list has it under Wheels. The player opens it, pushes the right stick toward a line
-- and lets the stick go: the line goes to the raid in a raid, to the party in a party, to the
-- instance channel in a battleground, and to "say" for a player alone.
--
-- The game sends the line, not the addon: an entry is one chat command, and the wheels' own
-- secure button runs it (Core/AdapterChat.lua says why). So this file only makes the entries
-- (Core/ChatWheelRules.lua has the lines and the rules), and it makes them again when the group
-- changes: Core/Wheels.lua asks at login and at the game's word of a change of the group.
--
-- No line twice in two seconds. The addon cannot stop the game's own action, but out of a fight
-- it can take the action off an entry. A line that was sent has no action for two seconds, and
-- shows dim on the ring. In a fight the game locks the wheels, and its restricted code has no
-- clock and reads nothing that addon code can change in a fight
-- (Blizzard_RestrictedAddOnEnvironment/RestrictedEnvironment.lua 81 to 266, RestrictedFrames.lua
-- 80 to 81). So in a fight a line can be sent again at once. At the start of a fight every
-- line gets its action back, so that none is without it in the fight.
local _, ns = ...

local Chat = ns.Module("ChatWheel", { "secure", "padButtons", "quickChat" }, "Quick Chat")
ns.ChatWheel = Chat

local Rules = ns.ChatWheelRules
local MAX_NOTES = 8     -- sent lines that go to the log in one session
local list              -- the wheel's entries now
local made              -- what they were made for: the class's mana and the group
local rests = {}        -- place -> when its line was sent (ChatWheelRules.Sent)
local notes, changes = 0, 0
local hooked, watching = false, false   -- the wheels' button tells of each use; a line is looked for in the chat

-- The game tells of every chat line with an event of its channel.
local HEARD = {
    say = { "CHAT_MSG_SAY" }, party = { "CHAT_MSG_PARTY", "CHAT_MSG_PARTY_LEADER" }, raid = { "CHAT_MSG_RAID", "CHAT_MSG_RAID_LEADER" },
    instance = { "CHAT_MSG_INSTANCE_CHAT", "CHAT_MSG_INSTANCE_CHAT_LEADER" },
}

-- The wheel's entries (see ChatWheelRules.Entries). They are the same ones until the group or
-- the class's mana is another: a change of who is in a raid makes nothing new.
function Chat.Entries()
    if not ns.Adapter.Results().quickChat then
        return nil
    end
    local mana, said = ns.Adapter.HasMana()
    local group = ns.Adapter.ChatGroup()
    local now = tostring(mana) .. " " .. tostring(group)
    if now ~= made then
        made, list = now, Rules.Entries(mana, group, ns.Adapter.ChatSlash())
        if changes < 5 then
            changes = changes + 1
            ns.Log.Add("quickchat", "The lines go to " .. list[1].to .. " (the group is " .. (group or "none") .. "). The class has mana: " .. tostring(mana)
                .. " (" .. said .. "). The first entry is \"" .. list[1].macro .. "\".")
        end
    end
    return list
end

-- The rest of a line is over: its entry gets the action back. all: every line that rests.
local function wake(all)
    local over = Rules.Over(rests, GetTime(), all)
    for _, place in ipairs(over) do
        if not ns.Adapter.WheelAction(Rules.ID, place, true) then
            -- (the game locked the wheels before this ran: the entry gets its action at the end of the fight)
            ns.Log.Add("quickchat", "The game did not take the action back for place " .. place .. ". It is given back after the fight.")
            ns.Queue.Run("ChatWheel" .. place, function()
                ns.Adapter.WheelAction(Rules.ID, place, true)
            end)
        end
        if list[place] then
            list[place].rest = nil
        end
    end
    if over[1] then
        ns.Send("chat")
    end
end

-- For the log: did the game show the line? For a second and a half the addon hears the chat
-- of the line's channel. One line at a time is looked for.
local function watch(entry)
    local back = "did not come back in 1.5 seconds"
    local me = ns.Adapter.Character().name
    local function heard(text, sender)
        -- (the game can hide a chat line's text and sender from addon code: such a line cannot be compared)
        local ok, mine = pcall(function()
            return text == entry.text and sender:find(me, 1, true) == 1
        end)
        back = not ok and "a line came, hidden from addon code" or mine and "came back" or back
    end
    watching = true
    for _, event in ipairs(HEARD[entry.to]) do
        -- an event this game version does not have is left out
        pcall(ns.On, event, "ChatWheel", heard)
    end
    C_Timer.After(1.5, function()
        watching = false
        for _, event in ipairs(HEARD[entry.to]) do
            ns.Off(event, "ChatWheel")
        end
        ns.Log.Add("quickchat", "\"" .. entry.text .. "\" in " .. entry.to .. " chat: " .. back .. ".")
    end)
end

-- The game ran a chat command text for a wheel (Adapter.OnWheelUsed). If it is one of the
-- lines, the line rests, and the first lines of a session go to the log.
local function used(text)
    for place, entry in ipairs(list or {}) do
        if entry.macro == text then
            local fight = ns.fightStarted or ns.Adapter.InCombat()
            local resting = Rules.Sent(rests, place, GetTime(), fight) and ns.Adapter.WheelAction(Rules.ID, place, false)
            if resting then
                entry.rest = true
                ns.Send("chat")
                C_Timer.After(Rules.REST, function()
                    wake()
                end)
            else
                rests[place] = nil
            end
            if notes < MAX_NOTES then
                notes = notes + 1
                ns.Log.Add("quickchat", "The game ran \"" .. text .. "\", in a fight: " .. tostring(fight) .. ". The line rests: " .. tostring(resting) .. ".")
                if not watching then
                    watch(entry)
                end
            end
            return
        end
    end
end

function Chat.OnLogin()
    -- The wheels' button is made with the binds, after this login step. The first wheel that
    -- opens finds it there. The log has the first answer, and the first yes.
    local tried = false
    ns.Listen("wheel", "ChatWheel", function()
        if hooked then
            return
        end
        hooked = ns.Adapter.OnWheelUsed(function(text)
            ns.Call("ChatWheel", used, text)
        end)
        if hooked or not tried then
            tried = true
            ns.Log.Add("quickchat", "The wheels' button tells of each use: " .. tostring(hooked) .. ".")
        end
    end)
    -- A fight starts. The game still takes a change at this moment, and after it takes none.
    ns.On("PLAYER_REGEN_DISABLED", "ChatWheel", function()
        wake(true)
    end)
end
