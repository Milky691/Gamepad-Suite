-- The adapter, the part for Target Tooltip (Screen/TargetTip.lua).
-- When the player takes a target with a controller, the game shows its own tooltip of it at its
-- place for a tooltip, and fades it a few seconds later. That is the game's one shared tooltip:
-- the game fills it from its "world cursor" at the event WORLD_CURSOR_TOOLTIP_UPDATE
-- (Blizzard_Game/Mainline/EventImplementation.lua 889 to 891), puts it at its place
-- (Blizzard_GameTooltip/Mainline/GameTooltip.lua 993 to 994), and fades it when the world cursor
-- has nothing more to show (the same file, 1021 to 1029: a fade at that place, else a hide).
-- The target's tooltip is a frame of the addon's own, made from the same template as the game's
-- (GameTooltip.xml 249), filled by the game for the target in the same way (SetUnit and the
-- world cursor both give lines to the template's one filler, ProcessInfo), and put at the same
-- place with the same call. So it has the game's font, border, lines and size, and the two look
-- like one tooltip. The game's tooltip is only heard: its show and hide (HookScript), the start
-- of its fade and each fill (hooksecurefunc). Nothing of it is replaced, called or written.
local _, ns = ...

local Adapter = ns.Adapter

local tip               -- the target's tooltip, made at its first use
local up = false        -- the game's own tooltip is at the place for a tooltip, and does not fade
local gameSize = "none" -- the game's tooltip's size when it last went from that place, for the log

-- The frame the game puts a tooltip at (Blizzard_SharedXML/SharedTooltipTemplates.lua 87 to 114).
local function home()
    return GameTooltipDefaultContainer or SharedTooltipDefaultContainer
end

-- "width x height" of a frame, for the log. In combat the game can hide the numbers.
local function size(frame)
    local ok, words = pcall(function()
        return string.format("%d x %d", frame:GetWidth(), frame:GetHeight())
    end)
    return ok and words or "not known"
end

-- Tells fn(true, how) when the game's own tooltip comes on at the place for a tooltip, and
-- fn(false, how) when it starts to fade there, hides, or is filled again at another place. A
-- tooltip of the game at a button or at the mouse is not at that place, and tells nothing. fn runs
-- inside the game's tooltip code: it must only take note. (A fault in fn is logged and does not reach the game.)
function Adapter.OnGameTip(fn)
    local function went(how)
        if up then
            up = false
            gameSize = size(GameTooltip)
            ns.Call("TargetTip", fn, false, how)
        end
    end
    -- Is the game's tooltip at the place now? (The game makes the same test: GameTooltip.lua 393 to 396.)
    local function sync(came, how)
        local ok, here = pcall(function()
            return GameTooltip:IsShown() and select(2, GameTooltip:GetPoint(1)) == home() and true or false
        end)
        if ok and here and not up then
            up = true
            ns.Call("TargetTip", fn, true, came)
        elseif ok and not here then
            went(how)
        end
    end
    pcall(function()
        -- (the game's own show can hide it again at once: GameTooltip.lua 380 to 388)
        GameTooltip:HookScript("OnShow", function()
            sync("came", "hid")
        end)
        GameTooltip:HookScript("OnHide", function()
            went("hid")
        end)
        hooksecurefunc(GameTooltip, "FadeOut", function()
            went("faded")
        end)
        -- Every fill of the game's tooltip (GameTooltip.lua 1014 to 1020, TooltipDataHandler.lua 488 to 503).
        -- A new thing under the world cursor while the last one fades fills it again with no new show.
        hooksecurefunc(GameTooltip, "ProcessInfo", function()
            sync("came back while it faded", "was filled at another place")
        end)
    end)
end

-- True while the game's own tooltip is at the place for a tooltip and does not fade.
function Adapter.GameTipUp()
    return up
end

-- Shows the target's tooltip at the place for a tooltip. The game fills it itself, so it has what
-- the game lets a player read of the unit, in a fight too. True when it shows; else false and why.
function Adapter.ShowTargetTip()
    local ok, shown = pcall(function()
        if not tip then
            tip = CreateFrame("GameTooltip", "GamepadSuiteTargetTip", UIParent, "GameTooltipTemplate")
            -- The template's health bar colours itself by comparing the health (HealthBar.lua 1 to 10), and in
            -- a fight the game hides that number from an addon's code: each fill then stopped with an error,
            -- and so many of them set off more in the game's gamepad bars (the owner's General.log, 0.26.3).
            -- Our bar keeps the game's fill, in one colour, and compares nothing.
            local bar = rawget(tip, "StatusBar")
            if type(bar) == "table" then
                bar:SetScript("OnValueChanged", nil)
                bar:SetStatusBarColor(0, 1, 0)
            end
        end
        GameTooltip_SetDefaultAnchor(tip, UIParent)
        return tip:SetUnit("target") and tip:IsShown()
    end)
    if not ok then
        return false, tostring(shown)
    elseif not shown then
        return false, "the game gave the tooltip no lines for the target"
    end
    return true
end

function Adapter.HideTargetTip()
    if tip then
        tip:Hide()
    end
end

-- True while the target's tooltip is on the screen.
function Adapter.TargetTipUp()
    return tip ~= nil and tip:IsShown() and true or false
end

-- For the log: the size of the game's tooltip when it last went, and the size of ours now.
function Adapter.TargetTipSizes()
    return gameSize, tip and size(tip) or "none"
end
