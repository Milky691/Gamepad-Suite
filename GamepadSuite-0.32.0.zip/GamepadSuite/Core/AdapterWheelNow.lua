-- The adapter, the part for what an open wheel shows now: the entry that the game's restricted code holds for the
-- stick's let-go (the ring's gold frame marks that one, Screen/Wheel.lua), and what the raid marker wheel can do
-- (Screen/WheelInfo.lua).
local _, ns = ...

local Adapter = ns.Adapter

-- True for a value the game hides from addon code in a fight. A compare with one is an error.
local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- Tells fn(index or nil) each time the restricted code of the wheels picks an entry for the stick's let-go, or forgets
-- it: the attribute "wsel" of the owner frame of the binds (Core/BindWheelUse.lua, Core/BindSecure.lua). The hook only
-- watches (HookScript), as the one of Core/BindHolds.lua does. No source says at what push the game's own direction key
-- of the right stick goes down: the restricted code writes the push at each key-down ("wfar", its square), and the log
-- has the first six of a session in one line. True when the frame is there and now tells.
function Adapter.OnWheelPick(fn)
    local owner = _G.GamepadSuiteBinds
    if type(owner) ~= "table" then
        return false
    end
    local pushes = {}
    return (pcall(owner.HookScript, owner, "OnAttributeChanged", function(_, name, value)
        if name == "wsel" then
            fn(value)
        elseif name == "wfar" and type(value) == "number" and #pushes < 6 then
            pushes[#pushes + 1] = ("%.2f"):format(math.sqrt(value))
            if #pushes == 6 then
                ns.Log.Add("wheel", "the game's direction keys of the right stick went down at these pushes (1 is a full push): " .. table.concat(pushes, ", "))
            end
        end
    end))
end

-- What the raid marker wheel can do now. can: a mark can go on the target. why: the line for the middle of the ring
-- when it cannot ("No target", "Leader or assistant only"); nil when it can, and when the target takes no mark (the
-- name of the entry dims then). on: the number of the mark the target has now. Only the leader or an assistant may mark
-- in a raid: a hidden answer counts as yes, so nothing is wrongly gray (UnitIsGroupLeader and UnitIsGroupAssistant are
-- hidden while the game hides who is who). A hidden mark counts as none (GetRaidTargetIndex: SecretReturns). A game
-- with no such calls: every mark can, as before. No source says whether CanBeRaidTarget already says no to a plain raid
-- member: the log has its answer then, once a session.
local told = false
function Adapter.MarkState()
    local ok, state = pcall(function()
        if not UnitExists("target") then
            return { can = false, why = "No target" }
        end
        local function yes(fn)
            local answer = fn("player")
            return hidden(answer) or answer == true
        end
        if IsInRaid() and not (yes(UnitIsGroupLeader) or yes(UnitIsGroupAssistant)) then
            if not told then
                told = true
                ns.Log.Add("wheel", "the raid marker wheel of a plain raid member: the game's CanBeRaidTarget says " .. tostring(CanBeRaidTarget("target")))
            end
            return { can = false, why = "Leader or assistant only" }
        end
        local on = GetRaidTargetIndex("target")
        return { can = CanBeRaidTarget("target") and true or false, on = not hidden(on) and on or nil }
    end)
    return ok and state or { can = true }
end
