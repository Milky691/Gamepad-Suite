-- The adapter, the part for the settings window: what Settings/Input.lua and Settings/Window.lua
-- ask the game.
local _, ns = ...

local Adapter = ns.Adapter

-- True while both stick clicks are down: the hold that opens and closes the settings window.
-- Adapter.ButtonDown asks the key state and the pad, which block no input and set no bind.
function Adapter.SticksDown()
    return Adapter.ButtonDown("LS") and Adapter.ButtonDown("RS")
end

-- The height of the screen in real pixels, for the smallest scale at which the window's text can
-- still be read. nil when the game does not tell.
function Adapter.ScreenHeight()
    local ok, _, height = pcall(GetPhysicalScreenSize)
    return ok and height or nil
end

-- The game's focus arrow. While a window of the game has the controller (the game menu, which stays
-- open under this window: Screen/MenuButton.lua), the game's navigation draws an arrow beside that
-- window's selected button (Blizzard_GamepadSmartNavigation/SmartNavigation.lua 719 to 723). Its frame
-- is in the TOOLTIP strata (SmartNavigation.lua 113), over this window (FULLSCREEN_DIALOG), and it
-- hides only when that window loses the controller (Blizzard_GamepadSharedUtility/
-- FrameControlsManager.lua 23 to 25, 539 to 544, 669). This window takes the buttons itself and tells
-- the game's window manager nothing (Settings/Input.lua), so the arrow stays. To close the menu or
-- move the game's focus from here would run the game's window code as ours (decision 114). So only
-- the arrow's holder, SmartNavigation.Pointer, goes see-through while this window shows: the game
-- never sets that frame's alpha (it fades the Icon under it, and reads only the alpha of
-- SmartNavigation itself: SmartNavigation.xml, SmartNavigation.lua 306 to 343), the frame is not
-- protected, and no script of the game runs. The log tells once where the arrow was.
local arrowAlpha
local told = {}

local function tell(text)
    if not told[text] then
        told[text] = true
        ns.Log.Add("settings", text)
    end
end

function Adapter.HideFocusArrow(hide)
    local nav = SmartNavigation
    local pointer = nav and nav.Pointer
    if not pointer then
        return
    end
    if hide and not arrowAlpha then
        arrowAlpha = pointer:GetAlpha()
        pointer:SetAlpha(0)
        local owner = nav.activeInfo and nav.activeInfo.frame
        local where = owner and (owner:GetName() or "a window with no name") .. (owner:IsShown() and " (still open)" or " (closed)")
        tell("the window opened: the game's focus arrow, at " .. (where or "no window of the game") .. ", is hidden, alpha now " .. pointer:GetAlpha())
    elseif not hide and arrowAlpha then
        pointer:SetAlpha(arrowAlpha)
        arrowAlpha = nil
        tell("the window closed: the game's focus arrow is back, alpha now " .. pointer:GetAlpha())
    end
end
