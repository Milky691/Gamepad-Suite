-- The bind core: the one place that gives the player's binds to the game. No other file sets a key.
-- It turns the plan of BindPlan.lua into the game's own parts: one secure frame that owns every
-- key, and one secure button for each spell, item, macro or chat command a key can run.
--
-- How a press reaches a bind. Each key, in each layer, is bound to a game command or to a click
-- on one of the secure buttons. A trigger goes to a hold button of ours, and while the pad says it
-- is down the keys get its layer's binds. A trigger that the game's settings make Shift, Ctrl or
-- Alt (LT is Shift at the game's start) is held free of it while its layer has binds: with LT as
-- Shift, LT + A ("SHIFT-PAD1") ran A's plain bind on this game, and ControllerForever goes by the
-- triggers that are held for every button (its CHANGELOG.md 359). Where the game keeps the
-- modifier, LT + A is the key name "SHIFT-PAD1" as before. The binds of every
-- state are written on the owner frame. A state driver of the game names the state in use (Combat
-- set or not, and the form), and the owner then sets the keys itself, in the game's restricted
-- code. That code runs in a fight too. It sets a key only when the key's bind changes, so a key
-- that is held down keeps its bind and the game hears of few changes.
--
-- Windows. Our binds are one level under Blizzard's window binds, which are priority binds. A
-- window that takes the controller covers our keys by itself, in a fight too. Out of a fight the
-- owner also gives every key back while a window has the controller, and takes them again after.
-- One key can be an exception: a key that the game itself holds during play, as View in a party.
-- Our bind for such a key is set at the game's own level (see check below).
local _, ns = ...

local Core = ns.Module("BindCore", { "secure" }, "Binds")
ns.BindCore = Core

local Rules = ns.BindRules
local Secure = ns.BindSecure
local LAYER = { [2] = "LT", [3] = "RT", [4] = "LT + RT" }

local header
local written = {}          -- the names the last plan wrote on the owner frame
local keyList = {}          -- the keys of the last plan
local told = {}             -- what the player was told one time: a layer that is off, by its number
local lastWatched, lastUnseen, lastCommands, near
-- Sticky Layers: the buttons that tell the owner frame of their press. The triggers' own buttons
-- are no such press, and the wheel's, RB's and the bumpers' tell in their own code (Core/BindSecure.lua).
local hears = { [Rules.HOLD_BUTTON .. "L"] = true, [Rules.HOLD_BUTTON .. "R"] = true, [Rules.WHEEL_BUTTON] = true, [Rules.CHORD_BUTTON] = true,
    [Rules.LB_BUTTON] = true, [Rules.RB_BUTTON] = true }

-- Out of a fight the addon tells the owner frame two things the game's restricted code cannot
-- see: a window has the controller, and something to interact with is in reach.
local function sync()
    if not (header and Core.plan) or ns.Adapter.InCombat() then
        return
    end
    local away, off = not ns.Pad.Gameplay(), not ns.Pad.Controller()
    local now = ns.Adapter.InteractNear()
    if away ~= (header:GetAttribute("away") or false) or now ~= near or off ~= (header:GetAttribute("off") or false) then
        near = now
        header:SetAttribute("away", away or nil)
        header:SetAttribute("off", off or nil)
        header:SetAttribute("near", now or nil)
        if away then
            -- a window has the controller: an open wheel closes (a layer that a tap keeps on stays on)
            header:SetAttribute("wwhy", "a window took the controller")
            header:SetAttribute("wheel", nil)
        end
        SecureHandlerExecute(header, Secure.REFRESH)
        if near then ns.BindAsk.NoteReach() end
    end
end

local function push()
    if not header then
        header = Secure.Build()
    end
    -- a back button with no learned key answers to its Steam Input key too (Core/AdapterGrips.lua)
    local twins = ns.Adapter.GripKeys()
    local form = ns.BindShape()
    local plan = Rules.Plan(ns.Binds.Get, form)
    -- (what can fault is asked before anything is changed: a fault leaves the old plan whole, never no binds)
    local wheels = ns.Wheels.Secure()
    ns.BindCheck.Note(plan, form)
    for index, action in ipairs(plan.buttons) do
        local button = Secure.ActionButton(header, index)
        for _, name in ipairs({ "type", "spell", "item", "macro", "macrotext", "unit", "action" }) do
            button:SetAttribute(name, action[name])
        end
        button.signature = Rules.Signature(action)
    end
    for index = #plan.buttons + 1, #Secure.actionButtons do
        Secure.actionButtons[index]:SetAttribute("type", nil)
    end

    -- the old plan goes: its keys, what the owner remembers of them, and its names
    ClearOverrideBindings(header)
    for _, key in ipairs(keyList) do
        header:SetAttribute("set:" .. key, nil)
    end
    for name in pairs(written) do
        header:SetAttribute(name, nil)
    end
    written, keyList = {}, {}
    local seen, unseen, commands = {}, {}, {}
    local function write(name, value, key)
        header:SetAttribute(name, value)
        written[name] = true
        if key and not seen[key] then
            seen[key] = true
            keyList[#keyList + 1] = key
        end
        -- Sticky Layers: every button that a key clicks tells the owner frame of its press, one of
        -- the game's own bar buttons too. It does so for the rest of the session; with the setting
        -- off its press changes nothing.
        local clicked = form.sticky and type(value) == "string" and value:match("^CLICK ([^:]+):")
        if clicked and not hears[clicked] then
            hears[clicked] = ns.Adapter.WatchClicks(clicked, header, Secure.SEEN)
            if not hears[clicked] and not unseen[clicked] then
                unseen[clicked], unseen[#unseen + 1] = true, clicked
            end
        end
        -- (a bind that is a game command is no click: no code of an addon sees its press)
        if form.sticky and not clicked and name:find("^[bh]:") and not commands[value] then
            commands[value], commands[#commands + 1] = true, value
        end
        -- a name that ends in a back button's key goes for its Steam key too, with the same front ("b:n0:SHIFT-F13")
        local base = key and key:match("[^-]+$")
        if base and twins[base] and name:sub(-#key) == key then
            local front = key:sub(1, #key - #base)
            write(name:sub(1, #name - #key) .. front .. twins[base], value, front .. twins[base])
        end
    end
    for name, state in pairs(plan.states) do
        for key, binding in pairs(state) do
            write("b:" .. name .. ":" .. key, binding, key)
        end
    end
    ns.BindHolds.Write(write, plan, form)
    if ns.BindGroup then
        ns.BindGroup.Write(write, plan)
    end
    for combo, states in pairs(plan.held) do
        write("combo:" .. combo, true)
        for name, state in pairs(states) do
            for key, binding in pairs(state) do
                write("h:" .. combo .. ":" .. name .. ":" .. key, binding, key)
            end
        end
    end
    -- With a trigger watched or a layer held, the owner reads both triggers: LT + RT is a layer
    -- too, and a trigger that is a modifier sends no press of its own.
    if next(plan.watch) or next(plan.held) then
        write("watching", true)
        write("index:L", ns.Adapter.PadIndex("LT"))
        write("index:R", ns.Adapter.PadIndex("RT"))
    end
    for i, index in ipairs(form.pads) do
        write("pad" .. i, index)
    end
    write("pads", #form.pads)
    write("sticky", form.sticky or nil)
    for click, inForm in pairs(plan.alt) do
        write("alt:" .. click, inForm)
    end
    -- The wheels that have a bind: each entry's direction and chat command, and the right stick's
    -- direction keys under every modifier that can be down with them. The game sends those keys
    -- only while its setting for them is on; it is held on for the session while a wheel is bound.
    for id, entries in pairs(wheels) do
        write("wn:" .. id, #entries)
        for i, entry in ipairs(entries) do
            write("wx:" .. id .. ":" .. i, entry.x)
            write("wy:" .. id .. ":" .. i, entry.y)
            write("wt:" .. id .. ":" .. i, entry.type)
            write("wk:" .. id .. ":" .. i, entry.key)
            write("wv:" .. id .. ":" .. i, entry.value)
            write("wu:" .. id .. ":" .. i, entry.unit)
        end
    end
    if next(wheels) then
        for _, front in ipairs(Rules.Fronts(form.mods)) do
            for way, key in pairs(ns.Adapter.STICK) do
                write("stick:" .. front .. key, way, front .. key)
            end
        end
        write("stickindex", ns.Adapter.RightStickIndex())
        ns.Adapter.HoldSetting("GamePadStickAxisButtons", "1")
    else
        ns.Adapter.ReleaseSetting("GamePadStickAxisButtons")
    end
    write("akey", form.keys.A, form.keys.A)
    write("bkey", form.keys.B, form.keys.B)
    if plan.interact then
        write("ikey", plan.interact.key, plan.interact.key)
        for name in pairs(plan.interact.off) do
            write("ioff:" .. name, true)
        end
    end
    -- Dynamic Interact and the Interact button's other jobs need "highlighted" to mean "in reach": a
    -- setting of the game, and then the game's own event tells of each change of reach (Core/BindShape.lua).
    if plan.interact or next(plan.jobs) then
        ns.Adapter.HoldSetting("SoftTargetInteractOnlyInRange", "1")
    else
        ns.Adapter.ReleaseSetting("SoftTargetInteractOnlyInRange")
    end
    -- the Interact button: its keys in each state, and the buttons of its two other jobs
    for name, keys in pairs(plan.ikeys) do
        for key in pairs(keys) do
            write("ik:" .. name .. ":" .. key, true, key)
        end
    end
    write("attack", plan.jobs.attack)
    write("fish", plan.jobs.fish)
    RegisterStateDriver(header, "pole", form.pole or "0")
    table.sort(keyList)
    -- (the triggers too: a trigger that is held keeps its hold button when every key is set again,
    -- at a fight's start for one, so its layer is not cut off under the thumb; written after the
    -- slots' own, which know the buttons only)
    ns.HoldSlots.Write(write, keyList, form.keys)
    local padOf = {}
    for _, list in ipairs({ form.keys, form.triggers }) do
        for ours, theirs in pairs(list) do
            padOf[theirs] = ns.Adapter.PadIndex(ours)
        end
    end
    for index, key in ipairs(keyList) do
        write("key" .. index, key)
        write("pad:" .. key, padOf[key:match("[^-]+$")])
        write("jump:" .. key, form.jump[key:match("[^-]+$")])
    end
    write("count", #keyList)
    for _, name in ipairs({ "both", "lbdown", "rbdown", "hold", "tap:L", "tap:R", "moddown:L", "moddown:R" }) do
        header:SetAttribute(name, nil)
    end
    near = ns.Adapter.InteractNear()
    header:SetAttribute("near", near or nil)
    header:SetAttribute("away", not ns.Pad.Gameplay() or nil)
    header:SetAttribute("off", not ns.Pad.Controller() or nil)
    for _, layer in ipairs(plan.missing) do
        if not told[layer] and ns.Binds.LayerInUse(layer) then
            told[layer] = true
            ns.Log.Add("binds", "no key name for the " .. LAYER[layer] .. " layer: " .. ns.Adapter.TriggerSettings())
            ns.Print("The " .. LAYER[layer] .. " layer is off. Gamepad Suite cannot read the triggers on this game build.")
        end
    end
    Core.plan = plan
    RegisterStateDriver(header, "binds", plan.driver)
    SecureHandlerExecute(header, Secure.REFRESH)
    local watched = (plan.watch.L and "LT " or "") .. (plan.watch.R and "RT" or "")
    if watched ~= lastWatched then
        lastWatched = watched
        ns.Log.Add("binds", "watched triggers: " .. (watched ~= "" and watched or "none"))
    end
    -- (a button that is not there yet, or that the game does not let the owner frame hear)
    table.sort(unseen)
    if form.sticky and table.concat(unseen, ", ") ~= lastUnseen then
        lastUnseen = table.concat(unseen, ", ")
        ns.Log.Add("binds", "Sticky Layers: " .. (lastUnseen == "" and "every button that a key clicks tells of its press" or "a press is not seen on " .. lastUnseen))
    end
    table.sort(commands)
    if form.sticky and #commands > 0 and table.concat(commands, ", ") ~= lastCommands then
        lastCommands = table.concat(commands, ", ")
        ns.Log.Add("binds", "Sticky Layers: a trigger held for one of these game commands counts as a tap (no addon code sees their press): " .. lastCommands)
    end
    ns.BindCheck.Keys(header, keyList, "binds set")
    ns.BindHolds.Unstick()
end

-- Builds the plan again and gives it to the game. In a fight it waits for the end of the fight.
function Core.Rebuild()
    ns.Queue.Run("BindCore", push)
end

-- The secure button's name for a bind, as the "press" message carries it. nil for a game command.
function Core.Signature(bind)
    local action = Rules.Action(bind)
    return action and not action.command and Rules.Signature(action) or nil
end

-- The triggers ("L", "R" or "LR") whose layers taps keep on now (Sticky Layers), or nil. The
-- on-screen buttons show that layer; the message "hold" tells them of a change.
function Core.Stuck()
    return header and header:GetAttribute("stuck") or nil
end

-- A and B go to the two buttons of a window that the game's gamepad mode gives no control
-- (Screen/Popups.lua). The names are the buttons' own; nil ends it. Out of a fight only.
function Core.Popup(first, second)
    if not header or ns.Adapter.InCombat() then
        return
    end
    local a = first and ("CLICK " .. first .. ":LeftButton") or nil
    local b = second and ("CLICK " .. second .. ":LeftButton") or nil
    if a ~= header:GetAttribute("pop1") or b ~= header:GetAttribute("pop2") then
        header:SetAttribute("pop1", a)
        header:SetAttribute("pop2", b)
        SecureHandlerExecute(header, "self:RunAttribute('apply')")
    end
end

-- A thing only the addon's own code can see, told to the owner frame. "sit": the player stands at
-- a campfire, and the Dynamic Interact button makes the player sit (Auto/Campfire.lua). "menu": a friendly player
-- is the target, and that button opens the target's menu (Auto/UnitMenus.lua). "line":
-- the fishing line is out (Core/Hands.lua). Out of a fight only.
function Core.Flag(name, on)
    if not header or ns.Adapter.InCombat() then
        return
    end
    on = on and true or nil
    if on ~= header:GetAttribute(name) then
        header:SetAttribute(name, on)
        SecureHandlerExecute(header, Secure.REFRESH)
    end
end

-- A question about the state in use, for the other parts of the addon (Core/BindShape.lua has it).
Core.InteractButton = ns.BindAsk.InteractButton

function Core.OnLogin()
    ns.Log.Add("binds", "trigger settings: " .. ns.Adapter.TriggerSettings())
    if ns.Adapter.InCombat() then -- (a reload in combat: no addon may set a key until it ends)
        ns.Log.Add("binds", "login in combat: the binds are given to the game when it ends")
        ns.Print("Your binds come back when this combat ends. The game lets no addon set them in combat.")
    end
    if ns.Adapter.AddonLoaded("ControllerForever") then
        ns.Print("ControllerForever is on too. Both set the same buttons. Turn one of them off in the addon list.")
    end
    ns.Adapter.OnFocusUI(function()
        ns.BindAsk.FocusRan(header)
    end)
    ns.Listen("bind", "BindCore", Core.Rebuild)
    -- what a wheel holds changed (the bags, a new spell); what the hands hold changed
    ns.Listen("wheels", "BindCore", Core.Rebuild)
    ns.Listen("hands", "BindCore", Core.Rebuild)
    ns.Listen("slots", "BindCore", Core.Rebuild)
    ns.Listen("setting", "BindCore", function(key)
        if key:find("^layers%.") or key == "combat.dynamic_interact" or key == "combat.press_and_hold" or key == "feel.stick_zoom" or key == "combat.targeting"
            or key == "combat.healer_mode" then
            Core.Rebuild()
        end
    end)
    -- a new form or stance: the list of states changes
    ns.On("UPDATE_SHAPESHIFT_FORMS", "BindCore", function()
        if ns.Adapter.FormsChanged() then
            Core.Rebuild()
        end
    end)
    -- The game's own bar changed its page: the game's button that a slot with no bind of ours
    -- clicks can be another one now. The page only: the bar in use changes at every trigger
    -- press, and the binds are not written again that often.
    ns.Adapter.OnNativeBarChanged(Core.Rebuild, true)
    -- The player learned a spell or a rank (a spell is cast by its name). And a setting or the
    -- controller changed: what is kept of the pad is read again (Adapter.Held).
    for _, event in ipairs({ "SPELLS_CHANGED", "PET_BAR_UPDATE" }) do
        ns.On(event, "BindCore", function()
            return ns.BindAsk.NamesChanged() and Core.Rebuild()
        end)
    end
    -- the let-go of the game's Jump: a key that kept Jump while it was down gets its bind (Core/BindSecure.lua)
    ns.Adapter.OnJumpUp(function()
        Core.Flag("late", false)
    end)
    for _, event in ipairs({ "CVAR_UPDATE", "GAME_PAD_CONFIGS_CHANGED", "GAME_PAD_CONNECTED", "GAME_PAD_DISCONNECTED", "GAME_PAD_ACTIVE_CHANGED" }) do
        ns.On(event, "BindCore", ns.Adapter.PadChanged)
    end
    -- (the game highlights only what is in reach: its word of a new highlight is the word of reach, see push)
    ns.On("PLAYER_SOFT_INTERACT_CHANGED", "BindCore", sync)
    ns.On("PLAYER_REGEN_ENABLED", "BindCore", sync)
    ns.Listen("pad", "BindCore", sync)
    -- Blizzard set or cleared window binds: the keys are read back (Core/BindCheck.lua)
    ns.Listen("pad:stack", "BindCore", function()
        if header and Core.plan then
            ns.BindCheck.AfterWindow(header, keyList)
        end
    end)
    -- Mouse mode ended. It let go of the game's settings that make a trigger Shift, Ctrl or Alt, so
    -- the ones the binds hold free are held again. And a trigger's let-go that mouse mode took is
    -- seen: the pad is read again.
    ns.Listen("pointer", "BindCore", function(on)
        if not on then
            ns.Adapter.KeepFree()
        end
        if header and Core.plan and not ns.Adapter.InCombat() then
            SecureHandlerExecute(header, Secure.REFRESH)
        end
    end)
    -- The LB + RB layer's row had another key in an older build: its value moves to the row, once.
    local saved = ns.Registry.Saved()
    if saved and saved["layers.hold_lb_set"] ~= nil then
        local was = saved["layers.hold_lb_set"]
        saved["layers.hold_lb_set"] = nil
        if was == true and saved["layers.hold_lb_rb_set"] == nil then
            ns.Registry.Set("layers.hold_lb_rb_set", true)
            ns.Log.Add("binds", "the LB + RB Layer row is on: it was on under its old name")
        end
    end
    Core.Rebuild()
    -- (the modules after this one make their buttons at login: the next frame, or after the fight, sees them all)
    C_Timer.After(0, function()
        ns.Queue.Run("BindCoreLogin", push)
    end)
end
