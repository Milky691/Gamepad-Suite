-- The adapter, the part for the quick chat wheel (Core/ChatWheel.lua): the game's chat command
-- for each channel, the group the player is in, if the class has mana, and two things on the
-- wheels' own secure frames.
--
-- Why the wheel sends a line with a chat command text and not with a call of the addon. The
-- game's notes mark its call for a chat line as one with restrictions for addon code
-- (C_ChatInfo.SendChatMessage: HasRestrictions) and name a lock on chat messaging
-- (C_ChatInfo.InChatMessagingLockdown: an encounter, a PvP match, a map such as a dungeon or a
-- raid). A chat command in a chat command text is run by the game's own code:
-- Blizzard_FrameXML/SecureTemplates.lua 450 to 464 hands the text to the game,
-- Blizzard_ChatFrameBase/Shared/MacroExecutionManager.lua 19 to 28 gives each line to a chat
-- box of the game's own, and Shared/ChatFrameEditBox.lua 188 to 316 reads the channel from the
-- command and sends the rest. The notes name one limit for such a line
-- (RestrictedForMacroChatMessages): in an encounter in an instance it does not go to a channel
-- that players outside the group can read. Of the wheel's four channels that is "say".
local _, ns = ...

local Adapter = ns.Adapter

-- The game's own first chat command of each channel, as its chat menu shows it
-- (Blizzard_ChatFrameBase/Mainline/ChatFrameMenuButton.lua 61 to 68). A game in another language
-- has its own words here.
local SLASH = { say = "SLASH_SAY1", party = "SLASH_PARTY1", raid = "SLASH_RAID1", instance = "SLASH_INSTANCE_CHAT1" }

-- { say = "/s", party = "/p", raid = "/raid", instance = "/i" }, or nil and the name of the one the game lacks.
function Adapter.ChatSlash()
    local out = {}
    for channel, global in pairs(SLASH) do
        local text = _G[global]
        if type(text) ~= "string" or not text:find("^/%S+$") then
            return nil, global
        end
        out[channel] = text
    end
    return out
end

-- With a part missing the Quick Chat Wheel is off (Core/ChatWheel.lua needs this check), and the bind list leaves it
-- out. The log names the part once, so the owner's file says what this game build lacks.
local lacks
Adapter.Check("quickChat", function()
    local _, missing = Adapter.ChatSlash()
    missing = missing or not (IsInGroup and IsInRaid) and "IsInGroup" or not LE_PARTY_CATEGORY_INSTANCE and "LE_PARTY_CATEGORY_INSTANCE"
        or not (UnitPowerType and UnitPowerMax and Enum and Enum.PowerType and Enum.PowerType.Mana) and "the mana of a class" or nil
    if missing and missing ~= lacks then
        lacks = missing
        ns.Log.Add("quickchat", "Quick Chat is off: the game has no " .. missing .. ".")
    end
    return not missing
end)

-- What the player is in, for the channel of a chat line: "instance" (a battleground, or a group
-- the game made for an instance: the game has one channel for those), "raid", "party", or nil
-- for a player alone. The game's own chat box asks the same things for a typed line
-- (Blizzard_ChatFrameBase/Shared/ChatFrameEditBox.lua 669 to 680).
function Adapter.ChatGroup()
    local ok, group = pcall(function()
        if IsInGroup(LE_PARTY_CATEGORY_INSTANCE) then
            return "instance"
        end
        return IsInRaid() and "raid" or IsInGroup() and "party" or nil
    end)
    return ok and group or nil
end

-- False when the player's class has no mana (a warrior, a rogue). A druid in a form has no mana
-- bar, but the class has mana: the game is asked for the most mana the character can have, not
-- only for the bar it shows now. When the game does not answer, the class counts as one with
-- mana. The second answer is what the game said, for the log.
function Adapter.HasMana()
    local mana = Enum.PowerType.Mana
    local ok, now, most = pcall(function()
        return UnitPowerType("player") + 0, UnitPowerMax("player", mana) + 0
    end)
    if not ok then
        return true, "the game gave no answer"
    end
    return now == mana or most > 0, "power type " .. now .. ", most mana " .. most
end

-- Takes the action off one entry of a wheel, or gives it back, on the owner frame of the binds.
-- That frame is made in Core/BindSecure.lua; "wt:<wheel>:<place>" is the kind of an entry's
-- action there, and an entry with none does nothing. Out of a fight only: the game locks the
-- frame in one. True when the frame reads back as asked.
function Adapter.WheelAction(id, place, on)
    local owner = _G.GamepadSuiteBinds
    if type(owner) ~= "table" or InCombatLockdown() then
        return false
    end
    local name, kind = "wt:" .. id .. ":" .. place, on and "macro" or nil
    pcall(owner.SetAttribute, owner, name, kind)
    return owner:GetAttribute(name) == kind
end

-- Tells fn of each chat command text that the game ran for a wheel: fn(text). The wheels' own
-- button runs an entry when the stick is let go, and keeps the entry's action until the next
-- push (Core/BindSecure.lua). True when the button is there and now tells.
function Adapter.OnWheelUsed(fn)
    local button = _G[ns.BindRules.WHEEL_USE_BUTTON]
    if type(button) ~= "table" then
        return false
    end
    return (pcall(button.HookScript, button, "PostClick", function(self, _, down)
        if not down and self:GetAttribute("typerelease") == "macro" then
            fn(self:GetAttribute("macrotext"))
        end
    end))
end
