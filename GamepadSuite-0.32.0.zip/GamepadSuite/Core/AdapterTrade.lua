-- The adapter's part for the trade hold (Windows/TradeHint.lua): the game's trade window, the other
-- player's name, and the call that accepts the trade.
--
-- What the game's code says (blizzard_ui_1.60.1.70450/Interface/AddOns):
--   The trade window shows at TRADE_SHOW (and TRADE_UPDATE) with ShowUIPanel, and closes the trade
--   when it cannot show; it hides at TRADE_CLOSED (Blizzard_UIPanels_Game/Mainline/TradeFrame.lua 34
--   to 48). So the window shows exactly while a trade is open. With the controller it opens the bags
--   (24 to 31), and its own hide closes the trade (238 to 245): B on the window cancels it. It is a
--   panel of the game (Blizzard_UIParentPanelManager/Mainline/UIPanelWindows.lua 16), so the game's
--   window manager takes it when it shows (Blizzard_GamepadSharedUtility/FrameControlsManager.lua 217
--   to 222), as it takes the bags (242 and 243); LT and RT go from one to the other (207 and 208).
--   The window has no controller code of its own: the manager blocks the D-pad and A, B, X, Y for
--   everything else (213, InputBindingStack/BindingSetFactory.lua 118 to 129), so Y has no job there.
--   The other player is the unit "NPC": the window writes its name with it (TradeFrame.lua 76 and
--   91). UnitName can give a hidden value (SecretWhenUnitNameIdentityRestricted,
--   Blizzard_APIDocumentationGenerated/UnitDocumentation.lua 2489 to 2503): a hidden name counts as none.
--   The accepts come with TRADE_ACCEPT_UPDATE (playerAccepted, targetAccepted, numbers:
--   TradeInfoDocumentation.lua 65 to 74). The player's accept on turns the Trade button off, and off
--   again turns it on (TradeFrame.lua 210 to 220); it is off too while the money typed is more than
--   the player has (260 to 272), and while the game's question about a bind enchant shows (285 to
--   301). So the button's own state says if a click of it could accept now; it is read, never set.
--   A change of the offer comes with TRADE_PLAYER_ITEM_CHANGED, TRADE_TARGET_ITEM_CHANGED and
--   TRADE_MONEY_CHANGED (TradeInfoDocumentation.lua 87 to 102, 147 to 155).
--   The Trade button's click is the global AcceptTrade (TradeFrame.xml 405 and 422). The game's
--   notes have no entry for that global; the one AcceptTrade in them, with HasRestrictions, is
--   C_SecureTransfer's (SecureTransferDocumentation.lua 10 to 14), which only the game's secure
--   window for a confirm calls (Blizzard_SecureTransferUI/Blizzard_SecureTransferUI.lua 123 to 131,
--   its .toc "UseSecureEnvironment: 1"). That window shows at SECURE_TRANSFER_CONFIRM_TRADE_ACCEPT
--   (354 and 355, SecureTransferDocumentation.lua 149 to 153), and A and B there are the game's.
--   The game's own warning for a changed offer reads C_TradeInfo.ShouldShowTradeOfferWarning (no
--   restriction, TradeInfoDocumentation.lua 39 to 47; TradeFrame.lua 89 to 98); the one of
--   C_SecureTransfer has HasRestrictions (SecureTransferDocumentation.lua 95 to 104). Neither is
--   called here: the module tells a change from the accepts and the change events.
--   Proof from an addon: Deathlog, made for the Classic game, sets its own click script on the Trade
--   button and calls AcceptTrade from it, inside the player's mouse press
--   (soulmate_research/src/Deathlog/Deathlog/utils.lua 2440 to 2452). Nothing shows a call from no
--   press, so the module calls it only at a key's press down on a button of ours.
--   A call the game refuses brings ADDON_ACTION_FORBIDDEN or ADDON_ACTION_BLOCKED with the addon's
--   name and the call (RestrictedActionsDocumentation.lua 74 to 94; the game shows the first value as
--   the addon's name, Blizzard_Game/Shared/EventImplementation.lua 90 to 92; Core/Log.lua reads it so).
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

local function event(name)
    return C_EventUtils.IsEventValid(name) == true
end

Adapter.Check("tradeHint", function()
    return TradeFrame.IsShown and TradeFrameTradeButton.IsEnabled and AcceptTrade and UnitName and ContainerFrameCombinedBags
        and GamepadMode.FrameControlsManager and event("TRADE_SHOW") and event("TRADE_CLOSED") and event("TRADE_ACCEPT_UPDATE")
        and event("TRADE_PLAYER_ITEM_CHANGED") and event("TRADE_TARGET_ITEM_CHANGED") and event("TRADE_MONEY_CHANGED")
        and event("ADDON_ACTION_FORBIDDEN") and event("ADDON_ACTION_BLOCKED")
end)

-- The game's trade window while a trade is open, or nil.
function Adapter.TradeWindow()
    local ok, shown = pcall(function()
        return results().tradeHint and TradeFrame:IsShown()
    end)
    return ok and shown and TradeFrame or nil
end

-- True while a trade is open and its window or the bag window has the controller.
function Adapter.TradeHasPad()
    local window = Adapter.TradeWindow()
    return window ~= nil and (Adapter.WindowHasPad(window) or Adapter.WindowHasPad(ContainerFrameCombinedBags))
end

-- True while the game's Trade button is on: a click of it could accept now.
function Adapter.TradeButtonOn()
    local ok, on = pcall(function()
        return results().tradeHint and TradeFrameTradeButton:IsEnabled()
    end)
    return ok and on and true or false
end

-- The other player of the trade, or nil (no name, or a hidden one).
function Adapter.TradePartner()
    local ok, name = pcall(UnitName, "NPC")
    if not ok or (issecretvalue ~= nil and issecretvalue(name)) or type(name) ~= "string" or name == "" then
        return nil
    end
    return name
end

-- Accepts the trade, as the Trade button's click does. Call it only from the click that a key's
-- press DOWN makes on a button of ours, out of combat. True when the call was made with no error;
-- the game's answer is TRADE_ACCEPT_UPDATE.
function Adapter.AcceptTrade()
    if not results().tradeHint or InCombatLockdown() then
        return false
    end
    return (pcall(AcceptTrade))
end
