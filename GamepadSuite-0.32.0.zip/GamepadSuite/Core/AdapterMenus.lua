-- The adapter, the part for the binds Target Menu and My Menu and the row Friendly Player Menu (Auto/UnitMenus.lua):
-- the game's own menu of a unit, opened the way the game opens it. PlayerFrame and TargetFrame are the game's secure
-- unit buttons: a right click runs their "menu" action at the let-go, in the game's secure code
-- (Blizzard_FrameXML/SecureTemplates.lua 262 to 266 and 828 to 839; Blizzard_UnitFrame/Mainline/PlayerFrame.lua 100,
-- TargetFrame.lua 115). A key bound to "CLICK TargetFrame:RightButton" clicks it that way, so the menu is the game's
-- and its entries that only the game may run (Set Focus) still work; a menu opened by addon code would block them.
-- The game's own gamepad bar opens the same target menu from its fixed Inspect button
-- (Blizzard_GamepadActionBars/MainActionBarFrame.lua 475 to 490).
local _, ns = ...
local Adapter = ns.Adapter

Adapter.TARGET_MENU, Adapter.SELF_MENU = "CLICK TargetFrame:RightButton", "CLICK PlayerFrame:RightButton"

Adapter.Check("unitMenus", function()
    return PlayerFrame ~= nil and TargetFrame ~= nil and PlayerFrame:GetAttribute("*type2") == "menu"
        and TargetFrame:GetAttribute("*type2") == "menu"
end)

-- True when the target is another player who is friendly. Asked out of combat (the game's restricted code cannot
-- tell a player from an NPC); a value the game hides gives false.
function Adapter.FriendlyPlayerTarget()
    local ok, yes = pcall(function()
        return UnitExists("target") and UnitIsPlayer("target") and UnitIsFriend("player", "target")
            and not UnitIsUnit("target", "player")
    end)
    return ok and yes and true or false
end
