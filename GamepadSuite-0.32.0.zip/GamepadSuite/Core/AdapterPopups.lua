-- The adapter's part for the pop-ups (Screen/Popup.lua, Screen/WhisperPopup.lua, Auto/RareNearby.lua): who a whisper
-- came from and what is known of them, if the player may invite them, and if a unit is a rare the player can still
-- fight. Only read, but for the invite (C_PartyInfo.InviteUnit): nothing of the game's is written or run.
--
-- Hidden ("secret") values. In the game's chat lock the text, the name and the GUID of a whisper can be hidden from
-- addon code (SecretInChatMessagingLockdown: ChatInfoDocumentation.lua 1088 and 2594), and a unit's GUID and name
-- can be hidden too (UnitDocumentation.lua 1241 and 2489); the group's leader and assistant marks are hidden while
-- a unit's identity is (SecretWhenUnitIdentityRestricted, UnitDocumentation.lua 2023 to 2056). Every answer is tested
-- with issecretvalue before it is compared or joined to a text, and a hidden one counts as no.
local _, ns = ...

local Adapter = ns.Adapter

local MAX_RAID = 40      -- MAX_RAID_MEMBERS (Blizzard_FrameXMLBase/Shared/Constants.lua 1)

local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- a text from the game that can be shown: not hidden and not empty
local function plain(value)
    return not hidden(value) and type(value) == "string" and value ~= "" and value or nil
end

local function number(value)
    return not hidden(value) and type(value) == "number" and value > 0 and value or nil
end

Adapter.Check("whisperPopup", function()
    return Ambiguate and GetPlayerInfoByGUID ~= nil
end)
Adapter.Check("rareNearby", function()
    return UnitClassification and UnitIsDead and UnitCanAttack and UnitGUID and UnitName ~= nil
end)

local told = {}
local function note(kind, text)
    if not told[kind] then
        told[kind] = true
        ns.Log.Add("whisper", text)
    end
end

-- The class colour, class and race of the player with this GUID, and the level when the game gives it
-- (GetPlayerInfoByGUID: localizedClass, englishClass, localizedRace, englishRace, sex, name, realmName, level;
-- MayReturnNothing while the game does not know the player yet, PlayerScriptDocumentation.lua 837).
local function byGUID(guid)
    if not plain(guid) then
        return {}
    end
    local ok, className, class, race, _, _, _, _, level = pcall(GetPlayerInfoByGUID, guid)
    if not ok then
        return {}
    end
    local color = plain(class) and RAID_CLASS_COLORS and RAID_CLASS_COLORS[class]
    return { color = color and { color.r, color.g, color.b } or nil, class = plain(className), race = plain(race), level = number(level) }
end

-- True when the unit's name (with its realm) is name.
local function same(name, other)
    local short = Ambiguate(name, "none")
    return plain(other) ~= nil and (other == name or Ambiguate(other, "none") == short)
end

-- The group unit of the player named so, or nil.
local function member(name)
    if not IsInGroup() then
        return nil
    end
    local raid = IsInRaid()
    for i = 1, GetNumGroupMembers() do
        local unit = raid and ("raid" .. i) or ("party" .. i)
        local unitName, realm = UnitName(unit)
        if plain(unitName) and same(name, plain(realm) and (unitName .. "-" .. realm) or unitName) then
            return unit
        end
    end
end

-- The sender's level and zone when the game knows them: a member of the group, a friend or a member of the guild.
-- A whisper does not carry them, and asking the game's /who for a stranger would show the game's own list.
-- GetGuildRosterInfo is not in the notes of this build: its 4th value (the level) is read in the game today; its 6th,
-- the zone, is read only when it is a plain text, and the first one goes in the log.
local function known(name)
    local unit = member(name)
    if unit then
        return { level = number(UnitLevel(unit)) }
    end
    local friend = C_FriendList.GetFriendInfo(Ambiguate(name, "none"))
    if type(friend) == "table" and friend.connected then
        return { level = number(friend.level), zone = plain(friend.area) }
    end
    if IsInGuild() then
        for i = 1, GetNumGuildMembers() do
            local who, _, _, level, _, zone = GetGuildRosterInfo(i)
            if same(name, who) then
                note("guild zone", "a whisper from a guild member: the roster's 4th value " .. tostring(level) .. ", 6th " .. tostring(zone))
                return { level = number(level), zone = plain(zone) }
            end
        end
    end
    return {}
end

-- The Battle.net friend's character (C_BattleNet.GetAccountInfoByID(bnSenderID).gameAccountInfo:
-- BattleNetDocumentation.lua 99 to 114, 493 to 524).
local function bnet(id)
    if not (C_BattleNet and C_BattleNet.GetAccountInfoByID) or not number(id) then
        return {}
    end
    local ok, info = pcall(C_BattleNet.GetAccountInfoByID, id)
    local game = ok and type(info) == "table" and type(info.gameAccountInfo) == "table" and info.gameAccountInfo or {}
    return { name = plain(game.characterName), level = number(game.characterLevel), class = plain(game.className), zone = plain(game.areaName) }
end

-- A whisper, from the game's event and its values (1 the text, 2 the name, 6 the special flags, 12 the sender's GUID,
-- 13 the Battle.net sender: ChatInfoDocumentation.lua 2594 to 2618). Gives { key, to, name, text, color, facts, gm,
-- bnet } or nil and why ("hidden", "empty", "own"). key: the sender as the game names it, which is also the name a
-- whisper of the player's to them comes with; to: the name to whisper back, nil for a Battle.net whisper (its name is
-- the game's own code for the friend: it shows as the name but cannot be typed); name: what the pop-up shows,
-- without the player's own realm; color: { r, g, b } of the class, or nil; facts: { name, level, race, class, zone },
-- each one known or nil (Screen/PopupModel.lua Facts words them); gm: a Game Master's flag ("GM" or "DEV", as the
-- game's own chat reads them, Blizzard_ChatFrameBase/Shared/ChatFrameUtil.lua 326 to 330).
function Adapter.Whisper(event, ...)
    local text, sender = ...
    local flag, guid, bnSender = select(6, ...), select(12, ...), select(13, ...)
    if hidden(text) or hidden(sender) then
        return nil, "hidden"
    elseif not (plain(text) and plain(sender)) then
        return nil, "empty"
    elseif Adapter.FromPlayer(guid) then
        return nil, "own"
    end
    flag = plain(flag)
    if flag then
        note("flag " .. flag, "a whisper came with the flag " .. flag)
    end
    local gm = flag == "GM" or flag == "DEV"
    if event == "CHAT_MSG_BN_WHISPER" then
        local ok, facts = pcall(bnet, bnSender)
        return { key = sender, name = sender, text = text, facts = ok and facts or {}, gm = gm, bnet = true }
    end
    local ok, name = pcall(Ambiguate, sender, "none")
    local fromGUID = byGUID(guid)
    local got, more = pcall(known, sender)
    more = got and more or {}
    local facts = { level = more.level or fromGUID.level, race = fromGUID.race, class = fromGUID.class, zone = more.zone }
    return { key = sender, to = sender, name = ok and plain(name) or sender, text = text, color = fromGUID.color, facts = facts, gm = gm }
end

-- The name a whisper of the player's went to (CHAT_MSG_WHISPER_INFORM and CHAT_MSG_BN_WHISPER_INFORM: the text,
-- then the name), or nil.
function Adapter.WhisperTo(_, name)
    return plain(name)
end

-- True when the player may invite the sender of this whisper now: a game whisper, not a Game Master, the sender not
-- in the group already, and the player in no group, or its leader or an assistant, with a raid not full. A full party
-- is no stop: the game then asks its own question to make a raid (PartyInfoDocumentation.lua 357 to 367). Else false
-- and why, for the log.
function Adapter.MayInvite(whisper)
    if whisper.bnet or not whisper.to then
        return false, "a Battle.net whisper"
    elseif whisper.gm then
        return false, "a Game Master"
    end
    local ok, why = pcall(function()
        if member(whisper.to) then
            return "in the group already"
        elseif IsInGroup() then
            local leader, assistant = UnitIsGroupLeader("player"), UnitIsGroupAssistant("player")
            if hidden(leader) or hidden(assistant) then
                return "the group's marks are hidden"
            elseif not (leader or assistant) then
                return "not the leader or an assistant"
            elseif IsInRaid() and GetNumGroupMembers() >= MAX_RAID then
                return "the raid is full"
            end
        end
    end)
    if not ok then
        return false, "the game gave no answer"
    end
    return why == nil, why
end

-- Asks the game to invite the player named so (C_PartyInfo.InviteUnit: no HasRestrictions, RequiresValidInviteTarget
-- only; the game's own friends list runs it from plain code, Blizzard_FriendsFrame/Camelot/FriendsFrame.lua 1251).
-- True when the call was made.
function Adapter.Invite(name)
    return (pcall(C_PartyInfo.InviteUnit, name))
end

-- True when the player named so is in the group now: for the log one second after an invite.
function Adapter.InGroupNamed(name)
    local ok, unit = pcall(member, name)
    return ok and unit ~= nil
end

-- True while a button of ours holds the game's key of ourKey (Adapter.TakeKey, Core/AdapterPlay.lua): another part
-- of the addon has that button now (the Destroy Gray Item prompt has Y), so a hold of it is that part's.
function Adapter.KeyTaken(ourKey)
    return Adapter.taken ~= nil and Adapter.taken[Adapter.KEY[ourKey]] ~= nil
end

-- Why the player cannot go to a rare now: "taxi" (on a flight path), "dead" (dead or a ghost), "hidden" (the game
-- hides the answer), or nil (UnitOnTaxi and UnitIsDeadOrGhost, UnitDocumentation.lua 2570 and 1931).
function Adapter.PlayerAway()
    local ok, taxi, dead = pcall(function()
        return UnitOnTaxi("player"), UnitIsDeadOrGhost("player")
    end)
    if not ok or hidden(taxi) or hidden(dead) then
        return "hidden"
    end
    return taxi and "taxi" or dead and "dead" or nil
end

-- The colour of a unit's level for the player, the game's own (C_PlayerInfo.GetContentDifficultyCreatureForPlayer
-- through GetDifficultyColor, as the game's target frame does: Blizzard_UnitFrame/Mainline/TargetFrame.lua 299 to
-- 300), or nil.
local function levelColor(unit)
    if not (C_PlayerInfo and C_PlayerInfo.GetContentDifficultyCreatureForPlayer and GetDifficultyColor) then
        return nil
    end
    local difficulty = C_PlayerInfo.GetContentDifficultyCreatureForPlayer(unit)
    local color = not hidden(difficulty) and difficulty ~= nil and GetDifficultyColor(difficulty)
    return type(color) == "table" and type(color.r) == "number" and { color.r, color.g, color.b } or nil
end

-- Reads one unit (in a pcall: a unit that is gone can make the game raise).
local function read(unit)
    local kind = UnitClassification(unit)
    if hidden(kind) then
        return nil, "hidden"
    elseif kind ~= "rare" and kind ~= "rareelite" then
        return nil, ""
    end
    local dead, foe = UnitIsDead(unit), UnitCanAttack("player", unit)
    local tapped = UnitIsTapDenied and UnitIsTapDenied(unit) or false
    local guid, name = UnitGUID(unit), UnitName(unit)
    if hidden(dead) or hidden(foe) or hidden(tapped) or not (plain(guid) and plain(name)) then
        return nil, "hidden"
    elseif dead then
        return nil, "dead"
    elseif not foe then
        return nil, "friendly"
    elseif tapped then
        return nil, "tapped"
    end
    local level = UnitLevel and UnitLevel(unit)
    local fighting = UnitAffectingCombat and UnitAffectingCombat(unit)
    local okColor, color = pcall(levelColor, unit)
    return { guid = guid, name = name, elite = kind == "rareelite",
        level = not hidden(level) and type(level) == "number" and (level > 0 or level == -1) and level or nil,
        fighting = not hidden(fighting) and fighting == true, color = okColor and color or nil }
end

-- The rare on unit (a name plate's unit, "softenemy", "target"): { guid, name, elite, level (-1 for a boss skull, nil
-- when hidden), fighting (in combat with someone), color (of its level) } for a rare or a rare elite that lives, that
-- the player can attack, and that no other player has tapped (UnitIsTapDenied: no loot or credit for the player).
-- Else nil and why: "" when it is no rare at all, else "hidden", "dead", "friendly" or "tapped".
function Adapter.Rare(unit)
    local ok, rare, why = pcall(read, unit)
    if not ok then
        return nil, "the game gave no answer"
    end
    return rare, why
end
