-- The one "after combat" queue. The game does not let an addon change binds or secure buttons
-- during a fight. A module gives such a job here with its own name. Out of combat the job runs
-- at once. In combat it runs once when the fight ends, and a later job from the same owner
-- takes the place of the earlier one.
local _, ns = ...

local Queue = ns.Module("Queue", nil, "Binds")
ns.Queue = Queue

local jobs, order = {}, {}

function Queue.Run(owner, fn)
    assert(type(owner) == "string" and type(fn) == "function", "Queue.Run(owner, fn)")
    if not ns.Adapter.InCombat() then
        return ns.Call(owner, fn)
    end
    if not jobs[owner] then
        order[#order + 1] = owner
    end
    jobs[owner] = fn
end

ns.On("PLAYER_REGEN_ENABLED", "Queue", function()
    local run, fns = order, jobs
    order, jobs = {}, {}
    for _, owner in ipairs(run) do
        ns.Call(owner, fns[owner])
    end
end)
