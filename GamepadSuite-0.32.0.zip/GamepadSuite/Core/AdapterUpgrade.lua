-- The adapter's part for the upgrade arrows (Screen/Upgrades.lua): what the game says of a
-- piece of gear and of the character, what the character wears, and the frames of the game
-- that show an item.
-- In the gamepad mode the bags are one window, ContainerFrameCombinedBags; with the mouse and
-- keyboard interface each bag is one of the frames in ContainerFrameContainer. Both keep their
-- item buttons in the list Items (Blizzard_UIPanels_Game/Mainline/ContainerFrame.lua 1048 to
-- 1081). The loot window is LootFrame in both: a scroll list whose rows have the loot slot and
-- the button Item (Mainline/LootFrame.lua 64 to 100 and 431 to 436). A loot roll has the button
-- IconFrame (Mainline/GroupLootFrame.xml 319).
-- We read these frames and hook after Blizzard's own code. None of Blizzard's own calls that
-- can keep a value is made (ContainerFrameUtil_EnumerateContainerFrames builds a list of its
-- own at the first call, and GetBagSize can write the bag's size): a value kept by an addon's
-- call would make the game refuse the use of an item from the bags.
-- An item's stats: C_Item.GetItemStats(link) gives a table, the game's name of each stat -> its
-- amount (Blizzard_APIDocumentationGenerated/ItemDocumentation.lua 1004 to 1018; no restriction
-- mark; it may give nothing). It is not in the login check: a game without it, or an item that
-- shows no stat we weigh, keeps the item level rule.
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("upgrades", function()
    return C_Item.GetItemInfoInstant and C_Item.GetItemInfo and C_Item.GetDetailedItemLevelInfo and C_Item.GetItemSpell
        and C_PlayerInfo.CanUseItem and C_Container.GetContainerItemInfo and C_Texture.GetAtlasInfo
        and GetInventoryItemID and GetInventoryItemLink and UnitLevel and hooksecurefunc
        and C_EventUtils.IsEventValid("BAG_UPDATE_DELAYED") and C_EventUtils.IsEventValid("PLAYER_EQUIPMENT_CHANGED")
        and C_EventUtils.IsEventValid("GET_ITEM_INFO_RECEIVED") and C_EventUtils.IsEventValid("LOOT_SLOT_CHANGED")
        and C_EventUtils.IsEventValid("PLAYER_LEVEL_UP") == true
end)
local results = Adapter.Results

-- The game's own arrow for a better item: its bag buttons and the list of gear at a worn place
-- carry it (Mainline/ContainerFrame.xml 109, Blizzard_FrameXML/Camelot/EquipmentFlyout.xml 12).
local ARROW = "bags-greenarrow"
-- The game's number for a loot slot that holds an item, and the last place a character wears gear in.
local LOOT_ITEM, LAST_PLACE = 1, 18

-- The game's names of the stats that Screen/UpgradeModel.lua weighs -> its short names. Two
-- names of one stat add up. RESISTANCE0_NAME is the armor.
local STATS = {
    ITEM_MOD_STRENGTH_SHORT = "str", ITEM_MOD_AGILITY_SHORT = "agi", ITEM_MOD_STAMINA_SHORT = "sta",
    ITEM_MOD_INTELLECT_SHORT = "int", ITEM_MOD_SPIRIT_SHORT = "spi",
    ITEM_MOD_ATTACK_POWER_SHORT = "ap", ITEM_MOD_MELEE_ATTACK_POWER_SHORT = "ap", ITEM_MOD_RANGED_ATTACK_POWER_SHORT = "rap",
    ITEM_MOD_SPELL_POWER_SHORT = "sp", ITEM_MOD_SPELL_DAMAGE_DONE_SHORT = "sp", ITEM_MOD_SPELL_HEALING_DONE_SHORT = "heal",
    RESISTANCE0_NAME = "armor", ITEM_MOD_DAMAGE_PER_SECOND_SHORT = "dps",
}

-- The stats of an item the game has loaded: our short names -> amounts, or nil when it shows
-- none that is weighed; and the game's names of the others, for the log, or nil.
local function stats(link)
    local ok, list = false, nil
    if C_Item.GetItemStats then
        ok, list = pcall(C_Item.GetItemStats, link)
    end
    if not (ok and type(list) == "table") then
        return nil
    end
    local mine, other = nil, {}
    for name, amount in pairs(list) do
        if not STATS[name] then
            other[#other + 1] = name
        elseif type(amount) == "number" then
            mine = mine or {}
            mine[STATS[name]] = (mine[STATS[name]] or 0) + amount
        end
    end
    table.sort(other)
    return mine, #other > 0 and table.concat(other, ", ") or nil
end

-- True when the game's only "no" to an item is the level it asks for. The game's own answer
-- (C_PlayerInfo.CanUseItem) is no for a piece of a higher level too (the owner's saved file:
-- item 6324, "asks for level 23, the game says usable false"), so the item's tooltip is read: the
-- game writes in red what the character cannot meet, and here the one red text must be its line
-- "Requires Level N" (ITEM_MIN_LEVEL). Any other red text (the armor kind, a class, a skill, a
-- race) is a no. The lines come from C_TooltipInfo.GetHyperlink with leftText, leftColor,
-- rightText and rightColor (TooltipInfoDocumentation.lua 337, Blizzard_SharedXMLGame/Tooltip/
-- TooltipDataHandler.lua 338 to 350); EasyController reads the same colours on this game. A
-- game without the call or the words: false, so no item is gear for later.
local function red(color)
    return type(color) == "table" and type(color.r) == "number" and color.r > 0.9 and color.g < 0.2 and color.b < 0.2
end

local function onlyLevel(link, needs)
    local ok, data = pcall(function()
        return C_TooltipInfo.GetHyperlink(link)
    end)
    if not (ok and type(data) == "table" and type(data.lines) == "table" and type(ITEM_MIN_LEVEL) == "string") then
        return false
    end
    local words, seen = ITEM_MIN_LEVEL:format(needs), false
    for _, line in ipairs(data.lines) do
        if red(line.rightColor) and line.rightText then
            return false
        elseif red(line.leftColor) and line.leftText then
            if line.leftText ~= words then
                return false
            end
            seen = true
        end
    end
    return seen
end

-- What the game says of a piece of gear, by its link: the fields that Screen/UpgradeModel.lua
-- names, and other (the stats that are not weighed, for the log). nil for a thing that is not
-- worn in a place that counts. The place, the class and the subclass are known at once; level,
-- needs and stats are nil until the game has loaded the item. soon: the game's only "no" to it
-- is its level (read only for a piece that asks for a higher level than the character's).
function Adapter.Gear(link)
    local ok, id, _, _, place, _, class, sub = pcall(C_Item.GetItemInfoInstant, link)
    if not (ok and id and ns.UpgradeModel.PLACES[place]) then
        return nil
    end
    local got, name, _, _, _, needs = pcall(C_Item.GetItemInfo, link)
    local has, level = pcall(C_Item.GetDetailedItemLevelInfo, link)
    local can, wearable = pcall(C_PlayerInfo.CanUseItem, id)
    local used, spell = pcall(C_Item.GetItemSpell, link)
    local loaded = got and name ~= nil
    local weighed, other, soon
    if loaded then
        weighed, other = stats(link)
        soon = type(needs) == "number" and needs > Adapter.CharacterLevel() and onlyLevel(link, needs)
    end
    return { id = id, place = place, class = class, sub = sub, level = loaded and has and level or nil,
        needs = loaded and needs or nil, wearable = can and wearable and true or false, use = used and spell ~= nil,
        stats = weighed, other = other, soon = soon or false }
end

-- The character's class by the game's file name ("ROGUE"), as Core/Adapter.lua reads it; nil
-- when the game does not say.
function Adapter.CharacterClass()
    local ok, _, class = pcall(UnitClass, "player")
    if ok and type(class) == "string" and not (issecretvalue and issecretvalue(class)) then
        return class
    end
end

-- What the character wears: the game's place number -> the piece there. A place with an item
-- that the game cannot describe yet has a piece with no level, so it does not count as empty.
function Adapter.WornGear()
    local worn = {}
    for place = 1, results().upgrades and LAST_PLACE or 0 do
        local ok, id = pcall(GetInventoryItemID, "player", place)
        if ok and id then
            local got, link = pcall(GetInventoryItemLink, "player", place)
            worn[place] = got and link and Adapter.Gear(link) or { id = id, place = "", class = -1, sub = -1 }
        end
    end
    return worn
end

function Adapter.CharacterLevel()
    local ok, level = pcall(UnitLevel, "player")
    return ok and tonumber(level) or 1
end

-- The bag windows of the game, in either interface.
local function bagFrames()
    local frames = { type(ContainerFrameCombinedBags) == "table" and ContainerFrameCombinedBags or nil }
    local held = type(ContainerFrameContainer) == "table" and ContainerFrameContainer.ContainerFrames
    for _, frame in ipairs(type(held) == "table" and held or {}) do
        frames[#frames + 1] = frame
    end
    return frames
end

-- Each of these calls add(frame, link) for every item its windows show now, and gives a few
-- words for the log, or nil when none of its windows shows.
local SOURCE = {
    bags = function(add)
        local shown = 0
        for _, frame in ipairs(bagFrames()) do
            if frame:IsShown() and type(frame.Items) == "table" then
                shown = shown + 1
                for _, button in ipairs(frame.Items) do
                    if button:IsShown() then
                        local info = C_Container.GetContainerItemInfo(button:GetBagID(), button:GetID())
                        add(button, info and info.hyperlink)
                    end
                end
            end
        end
        return shown > 0 and shown .. " bag windows" or nil
    end,
    loot = function(add)
        local frame = LootFrame
        if not (type(frame) == "table" and frame:IsShown() and frame.ScrollBox) then
            return nil
        end
        frame.ScrollBox:ForEachFrame(function(row)
            local slot = row.Item and row:IsShown() and row:GetSlotIndex()
            if slot and GetLootSlotType(slot) == LOOT_ITEM then
                add(row.Item, GetLootSlotLink(slot))
            end
        end)
        return "the loot window"
    end,
    rolls = function(add)
        local rolls, seen = Adapter.Rolls()
        for _, roll in ipairs(rolls) do
            add(roll.frame.IconFrame, GetLootRollItemLink(roll.id))
        end
        return seen and "loot rolls" or nil
    end,
}
local faulted = {}

-- The items that the windows of a source ("bags", "loot", "rolls") show now: each { frame =
-- the game's button with the item's picture, link = the item's link }. A protected button is
-- left out: nothing of ours is put on one. The second value is for the log, nil when no window
-- of the source shows.
function Adapter.UpgradeSpots(source)
    local spots, locked = {}, 0
    local ok, seen = pcall(SOURCE[source], function(frame, link)
        if type(frame) ~= "table" or type(link) ~= "string" then
            return
        elseif frame:IsProtected() then
            locked = locked + 1
        else
            spots[#spots + 1] = { frame = frame, link = link }
        end
    end)
    if not ok then
        if not faulted[source] then
            faulted[source] = true
            ns.Log.Add("upgrades", "the game's frames for " .. source .. " could not be read: " .. tostring(seen))
        end
        return {}, nil
    end
    return spots, seen and (seen .. ", " .. #spots .. " items" .. (locked > 0 and ", " .. locked .. " on a protected button" or ""))
end

-- Tells fn(source) each time the items a source shows can have changed with no event of the
-- game for it: a bag window shows or hides, the loot list is drawn or scrolled, a roll comes or
-- goes. Hooks after Blizzard's own code.
function Adapter.OnUpgradeSpotsChanged(fn)
    if not results().upgrades then
        return
    end
    for _, frame in ipairs(bagFrames()) do
        Adapter.OnShownOrHidden(frame, function()
            fn("bags")
        end)
    end
    local box = type(LootFrame) == "table" and LootFrame.ScrollBox
    if box and type(box.Update) == "function" then
        hooksecurefunc(box, "Update", function()
            fn("loot")
        end)
    end
    Adapter.OnRollsChanged(function()
        fn("rolls")
    end)
end

-- Puts the arrow's picture on a texture of ours: the game's own arrow in its own size, or a
-- plain arrow in green on a game that does not have it. Returns which, for the log.
function Adapter.UpgradeArt(texture)
    local ok, info = pcall(C_Texture.GetAtlasInfo, ARROW)
    if ok and info then
        texture:SetAtlas(ARROW, true)
        return "the game's own arrow"
    end
    texture:SetTexture("Interface\\Buttons\\Arrow-Up-Up")
    texture:SetVertexColor(0.3, 1, 0.3)
    texture:SetSize(16, 16)
    return "a plain green arrow: this game has no " .. ARROW
end
