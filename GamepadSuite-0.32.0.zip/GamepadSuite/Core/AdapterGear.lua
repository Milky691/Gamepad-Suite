-- The adapter, the part for equipment sets as binds (Auto/GearSets.lua).
--
-- This game has the equipment manager of the modern game: the calls (Blizzard_APIDocumentationGenerated/
-- EquipmentManagerDocumentation.lua), a tab of the character window where the player makes, names,
-- saves and deletes a set (Blizzard_UIPanels_Game/Camelot/PaperDollFrame.lua 2802 to 3220), the
-- chat command /equipset (Blizzard_ChatFrameBase/Shared/SlashCommands.lua 812 to 820), and an
-- action of the game's secure buttons that wears a set by its name (Blizzard_FrameXML/
-- SecureTemplates.lua 441 to 448). No working addon on this game uses the calls, and the game's
-- files do not say what the server answers: the log of the module has that.
local _, ns = ...

local Adapter = ns.Adapter

Adapter.Check("gearSets", function()
    local sets = C_EquipmentSet
    return sets and sets.GetEquipmentSetIDs and sets.GetEquipmentSetInfo and sets.GetEquipmentSetID and sets.UseEquipmentSet
        and sets.GetItemIDs and sets.GetItemLocations and sets.GetIgnoredSlots and GetInventoryItemID ~= nil
end)

-- The game's own numbers: the places of worn items, head to tabard, and its marks for an item of
-- a set that it cannot find, for a place that a set leaves as it is, and for a place that a set
-- wants empty: 0 (Blizzard_FrameXMLBase/Constants.lua 136 to 155 and 183 to 185). The picture is
-- the one the game shows for a set that has none (PaperDollFrame.lua 3130 to 3134).
local PLACES, GONE, LEFT = 19, -1, 1
local NO_PICTURE = "Interface\\Icons\\INV_Misc_QuestionMark"

-- A value that the game hides from an addon in a fight is not known here: a compare with one is
-- an error.
local function plain(value)
    return not (issecretvalue and issecretvalue(value)) and value or nil
end

-- Every equipment set of the character, in the game's order (Auto/GearModel.lua says what a set
-- is). Empty when the game gives none. A set that the game does not answer for is left out.
function Adapter.GearSets()
    local out = {}
    pcall(function()
        for _, id in ipairs(C_EquipmentSet.GetEquipmentSetIDs()) do
            local name, icon, _, worn, _, _, _, lost = C_EquipmentSet.GetEquipmentSetInfo(id)
            if type(name) == "string" and name ~= "" then
                local set = { id = id, name = name, icon = icon or NO_PICTURE, worn = worn == true, lost = tonumber(lost) or 0, items = {}, gone = {} }
                local items, left = C_EquipmentSet.GetItemIDs(id) or {}, C_EquipmentSet.GetIgnoredSlots(id) or {}
                local where = C_EquipmentSet.GetItemLocations(id) or {}
                for place = 1, PLACES do
                    -- A place that the set leaves as it is has no item here: the game says so in
                    -- its list of such places, or with its mark in the list of items.
                    if not left[place] and items[place] ~= LEFT then
                        set.items[place] = items[place]
                    end
                    if where[place] == GONE then
                        set.gone[#set.gone + 1] = place
                    end
                end
                out[#out + 1] = set
            end
        end
    end)
    return out
end

-- What the character wears: { place = item number, 0 for an empty place }.
function Adapter.GearWorn()
    local worn = {}
    for place = 1, PLACES do
        local ok, id = pcall(GetInventoryItemID, "player", place)
        worn[place] = ok and plain(id) or 0
    end
    return worn
end

-- The click's button name is the set's key, as the wheels' button hears which wheel it opens
-- (Core/BindSecure.lua). An addon cannot change a secure button in a fight. So the name of every
-- set stands on the button under its key ("set-" and the key), and this piece of the game's
-- restricted code puts the name for the key of the click where the game's action reads it, before
-- each click. A key with no set gives no name, and the click does nothing.
local PICK = [[
    self:SetAttribute("equipmentset", self:GetAttribute("set-" .. button))
]]

-- Makes the button that wears a set. The game makes the call, in a fight too: there it changes
-- what its own rule lets it change.
function Adapter.GearButton(name)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate")
    -- the set goes on when the key goes down, whatever the game's setting for casts on key down says
    button:RegisterForClicks("AnyDown")
    button:SetAttribute("useOnKeyDown", true)
    button:SetAttribute("type", "equipmentset")
    SecureHandlerWrapScript(button, "OnClick", button, PICK)
    return button
end

-- Wears a set by its name, as a call of the addon. Out of a fight only: in one, the game's own
-- button makes the call. True when the game took the call and said that the set goes on; else
-- false and why.
function Adapter.WearGearSet(name)
    if InCombatLockdown() then
        return false, "a fight is on"
    end
    local ok, done = pcall(function()
        return C_EquipmentSet.UseEquipmentSet(C_EquipmentSet.GetEquipmentSetID(name))
    end)
    if not ok then
        return false, tostring(done)
    end
    return done == true, done ~= true and ("the game said " .. tostring(done)) or nil
end

-- For the log: the game's own word on whether this character can use sets.
function Adapter.GearSetsAllowed()
    local ok, can = pcall(C_EquipmentSet.CanUseEquipmentSets)
    return ok and tostring(can) or "not told"
end

-- Tells fn when the game says that the character's sets changed: one was made, saved, named anew
-- or deleted.
function Adapter.OnGearSets(fn)
    pcall(ns.On, "EQUIPMENT_SETS_CHANGED", "GearSets", fn)
end

-- Tells fn(done, setID) when the game ends a swap of a set: done is false when it could not put
-- all of it on (EQUIPMENT_SWAP_FINISHED, EquipmentManagerDocumentation.lua 311 to 320; the game's
-- own pane hears it, Blizzard_UIPanels_Game/Camelot/PaperDollFrame.lua 3086).
function Adapter.OnGearSwap(fn)
    pcall(ns.On, "EQUIPMENT_SWAP_FINISHED", "GearSets", function(result, setID)
        fn(plain(result) == true, plain(setID))
    end)
end
