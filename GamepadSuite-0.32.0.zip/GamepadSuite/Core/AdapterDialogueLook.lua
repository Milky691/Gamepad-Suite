-- The adapter's part for the look of the dialogue view (Screen/DialogueDraw.lua and
-- DialogueSide.lua): the NPC's portrait, the small picture of a row, the look of an item, and
-- the tooltips of a reward. Its login check is the one of AdapterDialogue.lua. The last part
-- is for Screen/DialogueStage.lua, with a login check of its own.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- The name of the speaker of a talk. nil when the unit has none, and when the game hides the
-- name (a hidden value cannot be compared or measured: it counts as no name).
function Adapter.DialogueName(unit)
    local ok, name = pcall(UnitName, unit)
    if ok and type(name) == "string" and not (issecretvalue ~= nil and issecretvalue(name)) then
        return name
    end
end

-- ---------------------------------------------------------------- the portrait
-- The NPC's own 3D model, from the waist up, in a model frame of ours. "npc" and "questnpc"
-- are the units of the game's own two windows (GossipFrameShared.lua 285, QuestFrame.lua 114).
-- The calls are in the game's notes (FrameAPICharacterModelBaseDocumentation.lua 143, 219 and
-- 240, SimpleModelAPIDocumentation.lua 497 and 563). The zoom is the game's own for its quest
-- model (Blizzard_FrameXML/QuestNPCModelFrameMixin.lua 8). The light is warm and comes from
-- the front, above and one side; the game's own plain front light is in
-- Blizzard_Collections/Shared/Blizzard_Wardrobe_Sets.lua 751.
local BOOK = "Interface\\QuestFrame\\UI-QuestLog-BookIcon"

local function light(model)
    model:SetLight(true, { omnidirectional = false, point = CreateVector3D(-1, 0.6, -0.6),
        ambientIntensity = 0.75, ambientColor = CreateColor(1, 0.96, 0.88),
        diffuseIntensity = 0.85, diffuseColor = CreateColor(1, 0.93, 0.80) })
end

-- The model's file is there: the camera and the light are set up. Else, at the first look, the
-- caller asks again one frame later (the game can give the file a moment after the unit); at
-- that second look the unit's flat picture.
local function settle(model, picture, unit, late)
    local file = model:GetModelFileID()
    if file then
        model:SetPortraitZoom(0.6)
        model:SetCamDistanceScale(1.1)
        model:SetFacing(0.3)
        local lit, err = pcall(light, model)
        return "model", "file " .. tostring(file) .. (lit and "" or ", no light: " .. tostring(err))
    elseif not late then
        return "wait", "no file yet: asked again one frame later"
    end
    SetPortraitTexture(picture, unit, true)
    return "picture", "no file one frame later"
end

-- Puts the speaker of a talk into the portrait. model is a PlayerModel frame of ours, picture a
-- texture of ours, unit the speaker or nil. Returns what shows, and a few words for the log:
--   "model"    the unit's own model, in the model frame
--   "wait"     the model frame shows and has the unit; the game gave no file yet: the caller
--              calls again one frame later with late set
--   "picture"  the unit's flat portrait, on the texture (the game gave no model)
--   "book"     the game's book picture, on the texture: a quest with no NPC (from an item, or
--              shared by a player). The game's own windows show the same (QuestFrame.lua 118).
-- The model frame is shown before the unit goes into it: a model frame that is not in sight does
-- not take a unit (Immersion keeps the same guard), so after a talk with the book picture the
-- next NPC would have no model for the rest of the session.
function Adapter.DialogueFace(model, picture, unit, late)
    local ok, kind, note = pcall(function()
        if not (unit and UnitExists(unit)) then
            return "book", "no unit"
        end
        if not late then
            model:Show()
            model:ClearModel()
            if model:SetUnit(unit, false) == false then
                SetPortraitTexture(picture, unit, true)
                return "picture", "SetUnit gave false"
            end
        end
        return settle(model, picture, unit, late)
    end)
    if not ok then
        kind, note = "book", tostring(kind)
    end
    if kind == "book" then
        picture:SetTexture(BOOK)
    end
    return kind, note
end

-- True when the game says that a text of ours is cut off (IsTruncated). A value the game hides
-- counts as no.
function Adapter.DialogueCut(text)
    local ok, cut = pcall(text.IsTruncated, text)
    return ok and not (issecretvalue ~= nil and issecretvalue(cut)) and cut == true
end

-- ---------------------------------------------------------------- rows and items

-- The small picture of a row of the list, on a texture of ours: the game's own picture of the
-- choice (GossipFrameShared.lua 87 to 91), or of the quest. For a quest the game's two plain
-- rules are asked (Blizzard_FrameXMLUtil/Mainline/QuestUtils.lua 136 and 169): they give a file
-- or the name of a part of a sheet, and keep nothing. The rule by the quest's number (229 to
-- 248) is not used: it puts the quest into the game's own store of quests, as an addon's.
function Adapter.DialogueRowArt(texture, row)
    return (pcall(function()
        local art, sheet = row.icon, false
        local quest = row.quest
        if quest and (row.act == "gossipActive" or row.act == "greetActive") then
            art, sheet = QuestUtil.GetQuestIconActive(quest.isComplete, quest.isLegendary, quest.frequency, quest.repeatable,
                false, false, quest.isImportant, quest.isMeta)
        elseif quest then
            art, sheet = QuestUtil.GetQuestIconOffer(quest.isLegendary, quest.frequency, quest.repeatable, false, false,
                quest.isImportant, quest.isMeta)
        end
        texture:SetTexCoord(0, 1, 0, 1)
        if sheet then
            texture:SetAtlas(art)
        else
            texture:SetTexture(art)
        end
    end))
end

-- The game's color for an item that is green or better: red, green, blue. nil for a plain item.
function Adapter.DialogueQuality(quality)
    local ok, r, g, b = pcall(C_Item.GetItemQualityColor, quality)
    if ok and (quality or 0) >= 2 and type(b) == "number" then
        return r, g, b
    end
end

-- A number as the game writes it: 1,150.
function Adapter.DialogueNumber(number)
    local ok, text = pcall(BreakUpLargeNumbers, number)
    return ok and text or tostring(number)
end

-- The size of a thin line on a frame of ours: as near to size (in the frame's units) as a whole
-- number of screen pixels can be, and one pixel at least, so the line is sharp on every screen.
function Adapter.DialogueThin(frame, size)
    local ok, thin = pcall(function()
        local _, high = GetPhysicalScreenSize()
        local pixel = 768 / high / frame:GetEffectiveScale()
        return math.max(1, math.floor(size / pixel + 0.5)) * pixel
    end)
    return ok and thin or size
end

-- ---------------------------------------------------------------- the tooltips of a reward
-- The item with the focus has the game's own tooltip, and at its left what the character wears
-- in that place, as the loot roll has (AdapterRolls.lua says why the frames are the addon's own
-- and why the worn items are written here). The game fills the item's tooltip with the call of
-- its own quest window (Mainline/QuestInfo.lua 1297).
local tips
local SCALE, GAP = 1.2, 8.5   -- (GAP: 10 of the view's units, in the game's)

function Adapter.DialogueTipHide()
    for _, tip in ipairs(tips or {}) do
        tip:Hide()
    end
end

-- Shows the tooltips of an item of the quest at its window (item: kind, index, link). corner is
-- a frame of ours: its bottom right corner is the place of the item's tooltip. Returns true
-- when the item's tooltip shows, and a few words for the log.
function Adapter.DialogueTip(item, corner)
    Adapter.DialogueTipHide()
    local ok, shown = pcall(function()
        tips = tips or { CreateFrame("GameTooltip", "GamepadSuiteDialogueTip", UIParent, "GameTooltipTemplate"),
            CreateFrame("GameTooltip", "GamepadSuiteDialogueWorn1", UIParent, "ShoppingTooltipTemplate"),
            CreateFrame("GameTooltip", "GamepadSuiteDialogueWorn2", UIParent, "ShoppingTooltipTemplate") }
        local tip = tips[1]
        tip:SetOwner(UIParent, "ANCHOR_NONE")
        -- (the game's interface is out of sight during a talk: the tooltips of the view are not)
        tip:SetIgnoreParentAlpha(true)
        tip:SetScale(SCALE)
        tip:ClearAllPoints()
        tip:SetPoint("BOTTOMRIGHT", corner, "BOTTOMRIGHT")
        tip:SetQuestItem(item.kind, item.index)
        return tip:IsShown()
    end)
    if not (ok and shown) then
        return false, ok and "the game gave the tooltip no lines" or tostring(shown)
    end
    -- a fault from here on leaves the item's tooltip as it is, with no worn item beside it
    local fine, count = pcall(function()
        local new = { hyperlink = item.link }
        local info = item.link and C_TooltipComparison.GetItemComparisonInfo(new)
        if not info then
            return 0
        end
        local METHOD, worn = Enum.TooltipComparisonMethod, 0
        local single, both = info.method == METHOD.Single, info.method == METHOD.WithBothHands
        local second = (single or both) and info.additionalItems[1] or nil
        for n, other in ipairs({ info.item, second }) do
            local data = other.guid and C_TooltipInfo.GetItemByGUID(other.guid)
                or other.hyperlink and C_TooltipInfo.GetHyperlink(other.hyperlink)
            if not data then
                break
            end
            local tip = tips[n + 1]
            tip:SetOwner(tips[1], "ANCHOR_NONE")
            tip:SetIgnoreParentAlpha(true)
            tip:SetScale(SCALE)
            tip:ClearAllPoints()
            tip:SetPoint("BOTTOMRIGHT", tips[n], "BOTTOMLEFT", -GAP / SCALE, 0)
            tip.CompareHeader.Label:SetText(EQUIPPED)
            tip.CompareHeader:SetWidth(tip.CompareHeader.Label:GetWidth() + 30)
            tip.CompareHeader:Show()
            tip:ProcessInfo({ tooltipData = data, append = true })
            local lines = (single or both and n == 1)
                and C_TooltipComparison.GetItemComparisonDelta(new, other, both and second or nil, false)
            if lines and #lines > 0 then
                GameTooltip_AddBlankLineToTooltip(tip)
                GameTooltip_AddNormalLine(tip, both and ITEM_DELTA_MULTIPLE_COMPARISON_DESCRIPTION or ITEM_DELTA_DESCRIPTION)
                for _, line in ipairs(lines) do
                    GameTooltip_AddHighlightLine(tip, line)
                end
            end
            tip:Show()
            worn = n
        end
        return worn
    end)
    if not fine then
        tips[2]:Hide()
        tips[3]:Hide()
    end
    return true, fine and count .. " worn beside it" or "no worn item beside it: " .. tostring(count)
end

-- ---------------------------------------------------------------- the game's interface out of sight
-- Screen/DialogueStage.lua takes the strength of the game's root frame down during a talk. It
-- needs: the frame calls for a strength and for a child that keeps its own; the game's list of
-- the windows and questions that are on the screen (Blizzard_GamepadSharedUtility/
-- FrameControlsManager.lua 397 to 473 and 482 to 555: every window that ShowUIPanel shows, every
-- popup, the bags); and the four events at which a player must have the interface.
Adapter.Check("dialogueStage", function()
    local manager = GamepadMode.FrameControlsManager
    for _, event in ipairs({ "CINEMATIC_START", "PLAY_MOVIE", "LOADING_SCREEN_ENABLED", "PLAYER_LEAVING_WORLD" }) do
        if not C_EventUtils.IsEventValid(event) then
            return false
        end
    end
    return UIParent.SetAlpha and UIParent.GetAlpha and UIParent.SetIgnoreParentAlpha and UIParent.GetEffectiveAlpha
        and manager.FrameShown and manager.FrameHidden and manager.GetShownFrameCount and hooksecurefunc ~= nil
end)

-- Tells fn each time a window or a question of the game comes on the screen or goes. The
-- game's two calls are watched, as its binds are in AdapterPlay.lua; nothing of the game's is
-- replaced. fn runs inside the game's code: it must only take note.
function Adapter.OnGameWindows(fn)
    local manager = GamepadMode.FrameControlsManager
    for _, name in ipairs({ "FrameShown", "FrameHidden" }) do
        hooksecurefunc(manager, name, function() fn() end)
    end
end

-- How many windows and questions of the game are on the screen now. 0 when the game cannot say.
function Adapter.GameWindows()
    local ok, count = pcall(function()
        return GamepadMode.FrameControlsManager:GetShownFrameCount()
    end)
    return ok and tonumber(count) or 0
end

-- Tells fn each time a question of the game (a popup) opens or closes, in either style of the
-- game's windows: the game's own messages for it (Blizzard_StaticPopup/StaticPopup.lua 106 to
-- 112, 616 and 659). The game calls a listener of an addon apart from its own code
-- (Blizzard_SharedXMLBase/CallbackRegistry.lua 198 to 204). fn must only take note. Each listener
-- has its own owner: the list keeps one function for each owner and message.
function Adapter.OnPopups(fn)
    local owner = {}
    pcall(function()
        for _, message in ipairs({ "PopupOpened", "PopupClosed" }) do
            PopupEventManager:RegisterCallback(message, function() fn() end, owner)
        end
    end)
end

-- True while a question of the game shows (StaticPopup.lua 187 to 192: the game's own walk
-- over the questions that show; it keeps nothing).
function Adapter.PopupShown()
    local any = false
    pcall(StaticPopup_ForEachShownDialog, function()
        any = true
    end)
    return any
end

-- Tells fn(true) when a chat box takes the typing focus and fn(false) when it loses it or
-- hides: the game's own messages, as in AdapterKeyboard.lua, with a listener of this file's own.
-- fn runs inside the game's chat code: it must only take note.
local TYPING = {}
function Adapter.OnTyping(fn)
    if not results().chatBox then
        return
    end
    EventRegistry:RegisterCallback("ChatFrame.OnEditBoxFocusGained", function() fn(true) end, TYPING)
    for _, message in ipairs({ "ChatFrame.OnEditBoxFocusLost", "ChatFrame.OnEditBoxHide" }) do
        EventRegistry:RegisterCallback(message, function() fn(false) end, TYPING)
    end
end
