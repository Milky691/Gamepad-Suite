-- The adapter's part for three helpers on the game's own windows: the flight list
-- (Windows/FlightList.lua), learn all at the trainer (Windows/LearnAll.lua) and the names for
-- the To box of a letter (Windows/MailNames.lua). Each has its own login check. And what the
-- helpers by the game's windows share (Core/AdapterBank.lua and Core/AdapterDestroy.lua use it too).
--
-- What the game's code says about the controller while one of its windows has it:
--   The game's navigation finds every Button and every text box under the window, at any depth,
--   each time the window takes the controller (Blizzard_GamepadSmartNavigation/Utility.lua 196
--   to 260, SmartNavigation.lua 1612 to 1627). The D-pad goes to the nearest one in the pushed
--   direction (1138 to 1228). A presses the one in focus with a mouse press made by script, so
--   its own click script runs (1502 to 1515). The focus runs its enter and leave scripts (662 to
--   672). B clicks the window's close button, shown or not (1528 to 1559).
--   So a plain Button of ours under such a window is a stop of the game's D-pad, and the
--   game's A clicks it. Nothing more is needed, and nothing more is safe: every helper field
--   of that navigation (a jump to another button, a target button, its own select and click
--   methods) is read by the game's code, and a value an addon wrote there marks that code as
--   an addon's from the read on. The navigation would then write its own state as an addon
--   and stay marked for the session, and the game refuses an item or a spell that such code
--   uses. For the same reason no method of the navigation or of the game's window manager is
--   called from here, and no frame of ours is made under a window while that window has the
--   controller: the game looks through the window again at each frame made under it (203 to
--   209 and 1653 to 1658), inside our call.
--   A window blocks the D-pad and A, B, X, Y for everything else, with each modifier
--   (Blizzard_GamepadSharedUtility/FrameControlsManager.lua 205 and 206,
--   InputBindingStack/BindingSetFactory.lua 118 to 129). LT and RT go from window to window,
--   the right stick's click turns the tooltips off and on (200 to 202).
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

local function event(name)
    return C_EventUtils.IsEventValid(name) == true
end

-- ---------------------------------------------------------------- shared
-- An amount of copper in the game's own coin look: the numbers with the gold, silver and copper
-- pictures (Blizzard_SharedXML/FormattingUtil.lua 72). "" when the game cannot make it.
function Adapter.CoinText(copper)
    local ok, text = pcall(GetMoneyString, copper, true)
    return ok and type(text) == "string" and text or ""
end

-- The scale that makes a frame of ours, a child of the whole screen, as large as a game window's own parts.
function Adapter.ScaleBeside(frame)
    return frame:GetEffectiveScale() / UIParent:GetEffectiveScale()
end

-- True while a button of the controller is down. The game's own key state is asked first: it
-- takes no key and makes nothing new at each ask. The pad's own state is asked when that one
-- says no (on some setups only one of the two tells of a button). This is for one look at a
-- press, a slow watch, or a look each frame only while a button is held (View + Menu, Stick Zoom).
function Adapter.ButtonDown(ourKey)
    local ok, down = pcall(IsKeyDown, Adapter.KEY[ourKey])
    if ok and down then
        return true
    end
    local index = Adapter.PadIndex(ourKey)
    return index and Adapter.PadState()[index] and true or false
end

-- True while this window of the game has the controller: the game's window manager has it in
-- focus (Blizzard_GamepadSharedUtility/FrameControlsManager.lua 73 to 111; its GetActiveFrame
-- gives the same field, 792 to 794), and it shows. Not while another window of the game has it
-- (the bags beside a bank), not while the player walks with the window open, and not with the
-- mouse interface, where no window takes the controller (397 to 400). The suite's own windows
-- are no windows of that manager: Windows/ListLook.lua asks about those (Look.Free). The
-- manager is read; nothing of it is called or written. False for nil.
function Adapter.WindowHasPad(window)
    local ok, has = pcall(function()
        local manager = GamepadMode.FrameControlsManager
        return window ~= nil and manager.isUIFocused and manager.focusedFrame == window and window:IsShown()
    end)
    return ok and has and true or false
end

-- ---------------------------------------------------------------- the flight list
-- This game type loads the old flight window, a map picture with a button on each place
-- (Blizzard_UIPanels_Game/Shared/TaxiFrame.lua and .xml; the game shows it for a flight
-- master of the kind "taxi", Blizzard_Game/Mainline/EventImplementation.lua 734 to 740). The
-- window has no controller code of its own: the D-pad walks its place buttons, A clicks one, B
-- clicks its close button. X and Y are blocked and do nothing.
-- The rows of the list are made with this template of the game: a button that is not protected,
-- whose click runs the game's secure action code out of combat (SecureTemplates.xml 12 to 18).
Adapter.CLICK_TEMPLATE = "InsecureActionButtonTemplate"

Adapter.Check("flightList", function()
    return TaxiFrame.HookScript and TaxiFrame.CloseButton.SetShown and TaxiRouteMap.GetObjectType and NumTaxiNodes
        and TaxiNodeName and TaxiNodeGetType and TaxiNodeCost and TakeTaxiNode and hooksecurefunc and event("TAXIMAP_OPENED")
        and SecureActionButton_OnClick and C_XMLUtil.GetTemplateInfo(Adapter.CLICK_TEMPLATE)
end)

-- The game's flight window, and the frame that holds the buttons of the places on its map.
-- nil on a game build that has no such window.
function Adapter.TaxiWindow()
    if results().flightList then
        return TaxiFrame, TaxiRouteMap
    end
end

-- The places the character can fly to from here now: { { index = the place's number on the
-- map, name, cost (copper) } }. The game's own window asks the same things of each place
-- (TaxiFrame.lua 54 to 66 and 138 to 162).
function Adapter.TaxiPlaces()
    local places = {}
    pcall(function()
        for index = 1, results().flightList and NumTaxiNodes() or 0 do
            if TaxiNodeGetType(index) == "REACHABLE" then
                places[#places + 1] = { index = index, name = TaxiNodeName(index) or "", cost = TaxiNodeCost(index) or 0 }
            end
        end
    end)
    return places
end

-- The game's own button of a place on its map: made by the game at the first open that needs
-- it (TaxiFrame.lua 54 to 61), with the place's number as its ID. Its click asks for the flight
-- (TaxiFrame.xml 15 to 17). nil when the game has not made it.
function Adapter.TaxiButton(index)
    return _G["TaxiButton" .. index]
end

-- Marks a place on the game's map, or takes the mark off: the highlight of the place's own
-- button stays on, the ring the game shows on the place under the mouse. No more than that.
-- The button's own enter script would also show the route lines and the place's tooltip, but
-- it is the game's code (TaxiFrame.lua 135 to 209): run from here it would make the textures
-- of the route lines and set the game's count of them as an addon (165 to 171), and the game
-- reads both in its own code after (173, 236 to 241, 259 and 260), which can then close the
-- window. So no script of the game is run here. True when the highlight was set.
function Adapter.TaxiMark(index, on)
    return (pcall(function()
        local button = Adapter.TaxiButton(index)
        if on then
            button:LockHighlight()
        else
            button:UnlockHighlight()
        end
    end))
end

-- Tells fn(name) each time a flight is asked for, from the list or from the map: both are the
-- click of the game's own place button. The game's call is watched; nothing of the game's is
-- replaced.
function Adapter.OnTaxiTaken(fn)
    hooksecurefunc("TakeTaxiNode", function(index)
        local ok, name = pcall(TaxiNodeName, index)
        if ok and type(name) == "string" and name ~= "" then
            fn(name)
        end
    end)
end

-- True while the game's windows are made for the controller (and not for the mouse).
function Adapter.PadWindowStyle()
    local ok, on = pcall(function()
        return InputUtil.IsGamepadUIEnabled()
    end)
    return ok and on and true or false
end

-- Hides the flight window's close button, as the game hides it on the windows it made for the
-- controller (Blizzard_TrainerUI/Mainline/Blizzard_TrainerUI.lua 126 to 129, where B closes the
-- window all the same), or shows it again. It is hidden only while the windows are made for
-- the controller. With the button gone, the first row of the list is the highest button of the
-- window and the first one made, and that one gets the focus when the window opens
-- (SmartNavigation.lua 846 to 861 and 1572 to 1606). True when the button was hidden.
function Adapter.TaxiCloseButton(shown)
    local hide = not shown and Adapter.PadWindowStyle()
    return (pcall(function()
        TaxiFrame.CloseButton:SetShown(not hide)
    end)) and hide
end

-- ---------------------------------------------------------------- learn all at the trainer
-- The trainer's window is loaded at the first trainer (Blizzard_TrainerUI). With the
-- controller it uses A (Train), Y (Spellbook), Menu (Filter), B (Close), the D-pad and the
-- right stick (Blizzard_TrainerUI/Mainline/Blizzard_TrainerUI.lua 75 to 124). X is blocked and
-- has no job there, so the hold is on X; Windows/LearnAll.lua hears it through a key bind of a
-- button of its own, as the bank's hold does. The game's own Train button calls BuyTrainerService
-- with the place of a line (881 to 889) and draws its list again at TRAINER_UPDATE (293 to
-- 300). The game's notes have no entry for that call, and no addon on this game calls it: that
-- it runs from addon code is not proved, so Windows/LearnAll.lua writes what came of it.
Adapter.Check("learnAll", function()
    return GetNumTrainerServices and GetTrainerServiceInfo and GetTrainerServiceCost and BuyTrainerService and GetMoney
        and GamepadMode.FrameControlsManager
        and event("TRAINER_SHOW") and event("TRAINER_UPDATE") and event("TRAINER_CLOSED")
end)

-- The trainer's window while it shows, or nil.
function Adapter.TrainerWindow()
    local ok, frame = pcall(function()
        return ClassTrainerFrame:IsShown() and ClassTrainerFrame
    end)
    return ok and frame or nil
end

-- The lines of the open trainer, in the game's order: { { index, name, sub (the rank), kind
-- ("available", "unavailable" or "used"), cost (copper), profession (true for a new
-- profession, which the game's window asks about first: 27 to 51 and 708), reqLevel, skill,
-- rank, met (what a line waits for: the game's own list writes "Requires Level 24" and "Requires
-- Alchemy (75)" from them, Blizzard_TrainerUI.lua 634 to 660) } }, and the character's level
-- (nil when the game did not say). Empty for a pet trainer, whose lines cost training points.
function Adapter.TrainerServices()
    local list = {}
    pcall(function()
        local pet = C_Trainer and Enum.TrainerType and C_Trainer.GetTrainerType() == Enum.TrainerType.Pet
        for index = 1, results().learnAll and not pet and GetNumTrainerServices() or 0 do
            local name, kind, _, reqLevel, sub = GetTrainerServiceInfo(index)
            local cost, profession = GetTrainerServiceCost(index)
            if name then
                local line = { index = index, name = name, sub = sub or "", kind = kind, cost = cost or 0,
                    profession = profession and true or false, reqLevel = tonumber(reqLevel) }
                if GetTrainerServiceSkillReq then
                    local skill, rank, met = GetTrainerServiceSkillReq(index)
                    line.skill, line.rank, line.met = type(skill) == "string" and skill or nil, tonumber(rank), met and true or false
                end
                list[#list + 1] = line
            end
        end
    end)
    local ok, level = pcall(UnitLevel, "player")
    return list, ok and tonumber(level) or nil
end

-- Asks the trainer for the line at a place of the list. Not in a fight. True when the call was
-- made with no error. That does not say that the game took it: the game's answer is its word
-- that the trainer's list changed, with the line gone from what can be learned.
function Adapter.TrainerBuy(index)
    if not results().learnAll or InCombatLockdown() then
        return false
    end
    return (pcall(BuyTrainerService, index))
end

-- ---------------------------------------------------------------- names for a letter
-- The game's mail window is there from the start (Blizzard_MailFrame). On its Send Mail page A
-- presses the thing in focus, X sends, B closes, LB and RB change the page
-- (Blizzard_MailFrame/MailFrame.lua 1194 to 1232, Blizzard_GamepadSharedUtility/Tab/
-- TabIndicators.lua 9 to 11). A on the To box is a mouse press made by script
-- (SmartNavigation.lua 1510 and 1511); the box's mouse script hears it, as the game's own focus
-- area for the letter's text does (MailFrame.lua 1243 to 1247).
-- The game's Send button (MailFrame.lua 1255 to 1279) sets the money or the COD from its money
-- boxes and calls SendMail with the To box's text, the subject and the body; it is on while the
-- To box and the subject have text and a COD is not over MAX_COD_AMOUNT gold (1432 to 1460; 10).
-- SendMail is a global with no note in this build (the one SendMail with HasRestrictions is
-- C_SecureTransfer's, SecureTransferDocumentation.lua 91 to 94, which only the game's secure
-- window for a confirm calls). The game answers with MAIL_SEND_SUCCESS (and empties the letter by
-- its own code, 144 and 145) or MAIL_FAILED (MailInfoDocumentation.lua 86 to 139).
Adapter.Check("mailNames", function()
    return SendMailNameEditBox.HookScript and SendMailNameEditBox.GetText and SendMailFrame.HookScript and MailFrame.IsShown
        and SendMailSubjectEditBox.GetText and SendMailBodyEditBox.GetText and SendMailMoney and MoneyInputFrame_GetCopper
        and SendMailSendMoneyButton.GetChecked and SendMailCODButton.GetChecked and SetSendMailMoney and SetSendMailCOD and SendMail
        and C_FriendList.GetNumFriends and C_FriendList.GetFriendInfoByIndex and UnitFactionGroup and IsKeyDown
        and GamepadMode.FrameControlsManager and event("MAIL_SEND_SUCCESS") and event("MAIL_FAILED") and event("MAIL_CLOSED")
        and event("ADDON_ACTION_FORBIDDEN") and event("ADDON_ACTION_BLOCKED")
end)

-- The To box, for the place of the list. nil on a game build without it.
function Adapter.MailNameBox()
    return results().mailNames and SendMailNameEditBox or nil
end

-- Tells pressed() when the To box gets a mouse press (the game's A makes one), changed(text)
-- when its text changes, and hidden() when it hides. Hooks after the game's own scripts. Each
-- runs inside the game's code: it must only take note.
function Adapter.OnMailNameBox(pressed, changed, hidden)
    local box = SendMailNameEditBox
    box:HookScript("OnMouseUp", function()
        pressed()
    end)
    box:HookScript("OnTextChanged", function(self)
        changed(self:GetText() or "")
    end)
    box:HookScript("OnHide", function()
        hidden()
    end)
end

-- What the To box has now.
function Adapter.MailNameText()
    local ok, text = pcall(function()
        return SendMailNameEditBox:GetText()
    end)
    return ok and text or ""
end

-- The To box is never written: each way to fill it from the addon runs its text script as addon
-- code (MailFrame.xml 653 to 656), the game has no call for the name of a letter, and a typed line
-- of a macro (/run) can be closed to scripts on this game and asks the player first
-- (Blizzard_ChatFrameBase/Shared/SlashCommands.lua 1224 to 1236). The chat box's write ended in
-- "Gamepad Suite has been blocked" (0.21.0, decision 81). So the letter goes to the picked name
-- with the calls of the game's Send button (MailSendTo), and the box is only read.

-- The mail window, to stand the send hint by.
function Adapter.MailSendWindow()
    return results().mailNames and MailFrame or nil
end

-- True while the mail window has the controller with its Send Mail page.
function Adapter.MailSendPage()
    local ok, shown = pcall(function()
        return results().mailNames and SendMailFrame:IsVisible() and Adapter.WindowHasPad(MailFrame)
    end)
    return ok and shown and true or false
end

-- Tells fn each time the Send Mail page shows or hides. It runs inside the game's code: fn must only take note.
function Adapter.OnMailSendPage(fn)
    if results().mailNames then
        SendMailFrame:HookScript("OnShow", fn)
        SendMailFrame:HookScript("OnHide", fn)
    end
end

-- True when the letter can go by the game's own rule for its Send button, the To box aside: it
-- has a subject, and a COD is not over the most. Else why: "subject" or "cod".
function Adapter.MailSendReady()
    local ok, why = pcall(function()
        if SendMailSubjectEditBox:GetText() == "" then
            return "subject"
        elseif SendMailCODButton:GetChecked() and MoneyInputFrame_GetCopper(SendMailMoney) > (MAX_COD_AMOUNT or 10000) * 10000 then
            return "cod"
        end
        return true
    end)
    return ok and why or "subject"
end

-- Sends the letter to name, as the game's Send button does with the To box's text: the money or
-- the COD from the game's money boxes, then SendMail with the subject and the body. Call it only
-- from the click that a key's press DOWN makes on a button of ours, out of combat. True when the
-- calls ran with no error; the game's answer is MAIL_SEND_SUCCESS or MAIL_FAILED (a confirm of the
-- game's own may come first, with A and B the game's).
function Adapter.MailSendTo(name)
    if not results().mailNames or InCombatLockdown() or type(name) ~= "string" or name == "" then
        return false, "a fight, no name, or the game has no call for it"
    end
    local ok, err = pcall(function()
        local copper = MoneyInputFrame_GetCopper(SendMailMoney)
        SetSendMailCOD(0)
        SetSendMailMoney(0)
        if SendMailSendMoneyButton:GetChecked() then
            if copper > 0 then
                SetSendMailMoney(copper)
            end
        elseif copper > 0 then
            SetSendMailCOD(copper)
        end
        SendMail(name, SendMailSubjectEditBox:GetText(), SendMailBodyEditBox:GetText())
    end)
    return ok, not ok and tostring(err) or nil
end

-- "Alliance" or "Horde" for this character, or nil.
function Adapter.Faction()
    local ok, faction = pcall(UnitFactionGroup, "player")
    return ok and type(faction) == "string" and faction or nil
end

-- The names on the character's friend list.
function Adapter.Friends()
    local names = {}
    pcall(function()
        for index = 1, results().mailNames and C_FriendList.GetNumFriends() or 0 do
            local info = C_FriendList.GetFriendInfoByIndex(index)
            if info and info.name then
                names[#names + 1] = info.name
            end
        end
    end)
    return names
end

-- The guild members who are in the game now, as far as the game has the list already. The
-- game asks for the list by itself when a mailbox opens (MailFrame.lua 115 to 117); nothing is
-- asked of the server here. Empty with no guild, or on a game build without these calls
-- (Mastercraft reads the list the same way, behind the same test).
-- The second table: each name's status (the 10th value), by the same place.
function Adapter.GuildOnline()
    local names, status = {}, {}
    pcall(function()
        if not (IsInGuild() and GetNumGuildMembers and GetGuildRosterInfo) then
            return
        end
        for index = 1, GetNumGuildMembers() do
            -- (the 10th value: away or busy, for the chat keyboard's whisper list, Core/AdapterKeyboard.lua)
            local name, _, _, _, _, _, _, _, online, away = GetGuildRosterInfo(index)
            if name and online then
                names[#names + 1] = name
                status[#names] = away
            end
        end
    end)
    return names, status
end
