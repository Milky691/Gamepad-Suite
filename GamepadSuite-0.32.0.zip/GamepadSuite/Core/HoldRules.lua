-- Press and Hold Casting for every spell bind: the rules, with no game calls.
--
-- The game casts a spell again while its key is held only when the press comes through one of
-- its own bar slots as a key press. So with the value "All spell binds" each spell that the
-- player has on a button gets a slot of the game's keyboard bars, and the key gets that slot's
-- own key command (Core/HoldSlots.lua does it, Core/AdapterSlots.lua talks to the game).
-- One spell is one slot, however many buttons have it.
-- Only a slot that holds nothing is used. A slot that holds anything is the player's and is
-- never touched, so nothing of the player's is ever moved, and the way back is only: our spell
-- is taken out of the slot again.
local _, ns = ...

local Rules = {}

Rules.ALL = "All spell binds"

-- The spells that want a slot, in the order they get one: the binds of the layer with no trigger
-- first, then layer by layer; in a layer the Normal set first. A spell that is on more than one
-- button stands more than one time and gets one slot (Rules.Assign). A bind with a receiver of
-- its own ("cast on") is cast by our own button and wants none. Nor does a bind on a layer that
-- gets no slot command (noSlot[layer], Core/BindShape.lua), nor a form or a stance (forms[spell]):
-- cast again it leaves the form, and its press changes the binds, so a key that is held while it
-- takes effect must not keep the form's command (in a fight, A with Bear Form stayed Bear Form in
-- Bear Form, and its next press left the form).
-- each(fn) calls fn(bind, set, layer, key) for every bind (Binds.Each).
function Rules.Wanted(each, noSlot, forms)
    local found = {}
    each(function(bind, set, layer, key)
        if bind.kind == "spell" and type(bind.id) == "number" and not bind.on and not (noSlot and noSlot[layer]) and not (forms and forms[bind.id]) then
            found[#found + 1] = { id = bind.id, at = layer .. " " .. (set == "normal" and "" or set) .. " " .. key }
        end
    end)
    table.sort(found, function(a, b)
        return a.at < b.at
    end)
    local wanted = {}
    for i, one in ipairs(found) do
        wanted[i] = one.id
    end
    return wanted
end

-- What to do with the slots.
--   wanted: Rules.Wanted, or {} when the row has another value (our spells are taken out).
--   store: the slots that hold a spell of ours, { [slot] = { spell = number } }.
--   slots: the slots that could be read in this run, in the order of use, each
--          { slot, command, now }, where now is what the slot holds (false: nothing).
-- Gives:
--   map = { [spell] = command } for the slots of ours that stay as they are,
--   put = { slot, spell, command }: our spell goes into a slot that holds nothing,
--   back = slots of ours that are not needed: our spell is taken out,
--   taken = slots of ours that hold another thing now: they are the player's; only our record
--           of them goes, and nothing is changed there,
--   none = the spells with no empty slot left: they cast one time for each press,
--   empty = how many slots could be used: those that hold nothing, and those that hold a
--           spell of ours (they held nothing before).
-- A slot of ours that is not in slots (its bar could not be read) is left alone, record and all;
-- its spell casts one time for each press in this run.
function Rules.Assign(wanted, store, slots)
    local want, bySlot, has = {}, {}, {}
    for _, id in ipairs(wanted) do
        want[id] = true
    end
    for _, one in ipairs(slots) do
        bySlot[one.slot] = one
    end
    local out = { map = {}, put = {}, back = {}, taken = {}, none = {}, empty = 0 }
    for slot, ours in pairs(store) do
        local one = bySlot[slot]
        out.empty = out.empty + (one and 1 or 0)
        if not one then
            has[ours.spell] = true
        elseif one.now and not (one.now.kind == "spell" and one.now.id == ours.spell) then
            out.taken[#out.taken + 1], out.empty = slot, out.empty - 1
        elseif want[ours.spell] and not has[ours.spell] then
            has[ours.spell] = true
            if one.now then
                out.map[ours.spell] = one.command
            else
                -- (the slot of ours reads as empty: the spell goes in again)
                out.put[#out.put + 1] = { slot = slot, spell = ours.spell, command = one.command }
            end
        else
            out.back[#out.back + 1] = slot
        end
    end
    local free = {}
    for _, one in ipairs(slots) do
        if not one.now and not store[one.slot] then
            free[#free + 1] = one
        end
    end
    out.empty = out.empty + #free
    local at = 0
    for _, id in ipairs(wanted) do
        if not has[id] then
            has[id], at = true, at + 1
            if free[at] then
                out.put[#out.put + 1] = { slot = free[at].slot, spell = id, command = free[at].command }
            else
                out.none[#out.none + 1] = id
            end
        end
    end
    table.sort(out.taken)
    table.sort(out.back)
    return out
end

if ns then
    ns.HoldRules = Rules
end
return Rules
