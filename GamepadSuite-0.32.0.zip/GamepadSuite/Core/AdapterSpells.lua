-- The adapter, the part for a spell bind's name and number: which spell a bind means now, the name a secure button
-- casts it by, and its name for a chat command.
local _, ns = ...

local Adapter = ns.Adapter

-- True when the character knows the spell (the game's three ways to ask, as Adapter.KnownSpells asks).
function Adapter.SpellKnown(id)
    local ok, known = pcall(function()
        return (C_SpellBook and C_SpellBook.IsSpellKnown and C_SpellBook.IsSpellKnown(id))
            or (IsPlayerSpell and IsPlayerSpell(id)) or (IsSpellKnown and IsSpellKnown(id))
    end)
    return ok and known and true or false
end

-- The spell a bind of this number means now. A bind keeps one number. When the character no longer knows it but knows
-- a spell of the same name, the bind means that one: a talent or a patch of the game put another number in its place,
-- and the game says "Spell not learned" to the old one (Slam on Forever, a player's report of 2026-10-20;
-- ControllerForever's notes N1 found the same after Improved Slam). A number the character still knows stays, so a
-- lower rank chosen on purpose keeps its rank.
function Adapter.SpellNow(id)
    if type(id) ~= "number" or Adapter.SpellKnown(id) then
        return id
    end
    local ok, now = pcall(function()
        local name = C_Spell.GetSpellName(id)
        return name and C_Spell.GetSpellIDForSpellIdentifier(name)
    end)
    return ok and type(now) == "number" and now ~= id and Adapter.SpellKnown(now) and now or id
end

-- A spell's name as a chat command needs it: "Wrath(Rank 5)", or the name alone when it has no rank.
function Adapter.SpellCastName(id)
    id = Adapter.SpellNow(id)
    local name = type(id) == "number" and C_Spell.GetSpellName(id)
    if not name then
        return nil
    end
    local rank = Adapter.SpellRank(id)
    return rank ~= "" and (name .. "(" .. rank .. ")") or name
end

-- The name a secure button casts a spell by: the name the spellbook has for it. By its name the
-- game casts the version for the form the player is in, where a spell has more than one (the
-- game's notes: "Using name will always check for an override on that spell",
-- Blizzard_APIDocumentationGenerated/SpellDocumentation.lua 399 to 424; a secure button casts
-- a text by name and a number by number, Blizzard_FrameXML/SecureTemplates.lua 396 to 405).
-- nil when the name alone would cast another spell: a lower rank that the player chose keeps
-- its number, which is that rank and no other. nil too while the game or the player does not
-- know the spell: the button keeps the number, and casts nothing until the spell is known.
function Adapter.SpellBindName(id)
    local ok, name = pcall(function()
        id = Adapter.SpellNow(id)
        local name = C_Spell.GetSpellName(id)
        local cast = name and C_Spell.GetSpellIDForSpellIdentifier(name)
        return cast and (cast == id or C_Spell.GetOverrideSpell(id) == cast) and name or nil
    end)
    return ok and name or nil
end
