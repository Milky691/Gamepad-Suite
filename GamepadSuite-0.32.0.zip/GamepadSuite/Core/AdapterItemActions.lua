-- The adapter's part for Item Actions (Windows/ItemActions.lua): the item in the game's focus in the bag window, the
-- facts the menu needs about it, and the calls that equip, split and destroy it. The sale is Core/AdapterJunk.lua's
-- SellBagItem, the call Auto Sell Junk uses.
--
-- What the game's code says:
--   The bag window's slot in focus is SmartNavigation.currentButton, a slot of the bag window when its buttonContext
--   says so (Core/AdapterBank.lua and Core/AdapterJunk.lua read it the same way). While a game menu or the game's stack
--   split box is open the window manager has the bag window suspended (Blizzard_GamepadSharedUtility/
--   FrameControlsManager.lua 720 to 731, the field topSuspendedFrame, only read here).
--   Equip: C_Item.EquipItemByName(item, slot) has no restriction mark (ItemDocumentation.lua 251 to 259); this game has
--   it in C_Item (ControllerForever_Fishing.lua 216 to 218 uses it in the owner's game). The item's link picks this
--   very item. CanDualWield is a plain call (PlayerScriptDocumentation.lua 46).
--   Split: C_Container.SplitContainerItem puts the new stack on the pointer (ContainerDocumentation.lua 572 to 581; the
--   game's own split does so, Mainline/ContainerFrame.lua 3183 to 3185), and PickupContainerItem on an empty slot puts
--   it down there. Neither has a restriction mark.
--   Destroy: DeleteCursorItem and C_Item.ConfirmDeleteItem have HasRestrictions (GameCursorDocumentation.lua 54 to 57,
--   ItemDocumentation.lua 84 to 93): call ItemDestroy only from the click of a key's press DOWN. ConfirmDeleteItem is
--   what the game's own Destroy calls (ContainerFrame.lua 3242 to 3247); the game then asks with its own question
--   (event DELETE_ITEM_CONFIRM, Blizzard_Game/Camelot/EventImplementation.lua 48 to 69).
-- Everything else is read; nothing of the game is written.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

local SLOT = "ButtonContext_ContainerFrameItemButton"
local QUEST, BOP, QUEST_BIND = 12, 1, 4   -- the item class Quest; the bind types "on pickup" and "quest"
local FIRST, LAST = 0, 4                   -- the backpack to the last bag

local function event(name)
    return C_EventUtils.IsEventValid(name) == true
end

Adapter.Check("itemActions", function()
    return ContainerFrameCombinedBags and GamepadMode.FrameControlsManager and SmartNavigation.SelectButton
        and C_Container.GetContainerItemInfo and C_Container.GetContainerItemQuestInfo and C_Container.GetContainerNumSlots
        and C_Container.GetContainerNumFreeSlots and C_Container.SplitContainerItem and C_Container.PickupContainerItem
        and C_Item.GetItemInfo and C_Item.GetItemInfoInstant and C_Item.IsEquippableItem and C_Item.GetItemSpell
        and C_Item.EquipItemByName and C_Item.ConfirmDeleteItem and C_Item.GetItemGUID and ItemLocation.CreateFromBagAndSlot
        and DeleteCursorItem and GetCursorInfo and ClearCursor and CanDualWield and GetInventoryItemLink and event("BAG_UPDATE_DELAYED")
        and event("PLAYER_EQUIPMENT_CHANGED") and event("MERCHANT_SHOW") and event("MERCHANT_CLOSED") and event("DELETE_ITEM_CONFIRM")
end)

-- One bag slot as an item of Windows/ItemActionsModel.lua, with bag, slot, id, link, icon; nil when it is empty.
local function read(bag, slot)
    local info = C_Container.GetContainerItemInfo(bag, slot)
    if not (info and info.itemID) then
        return nil
    end
    local id = info.itemID
    local _, _, _, place = C_Item.GetItemInfoInstant(id)
    local name, _, _, _, _, _, _, _, _, _, price, class, _, bind = C_Item.GetItemInfo(id)
    local quest = C_Container.GetContainerItemQuestInfo(bag, slot)
    return { bag = bag, slot = slot, id = id, link = info.hyperlink, icon = info.iconFileID, name = info.itemName or name or ("Item " .. id),
        count = info.stackCount or 1, locked = info.isLocked or false, noValue = info.hasNoValue or false,
        equip = C_Item.IsEquippableItem(id) and place ~= "" and place or nil, usable = C_Item.GetItemSpell(id) ~= nil,
        -- (before the game has loaded the item, a bound item counts as bind on pickup: one in the bags always is bound)
        bop = bind == BOP or (name == nil and info.isBound == true), quest = (type(quest) == "table" and (quest.isQuestItem or quest.questID ~= nil)) or class == QUEST or bind == QUEST_BIND,
        price = name and price or nil }
end

-- The game's bag window of the controller, or nil.
function Adapter.ItemBags()
    return results().itemActions and ContainerFrameCombinedBags or nil
end

-- Tells fn each time the bag window shows or hides. It runs inside the game's code: fn must only take note.
function Adapter.OnItemBags(fn)
    if results().itemActions then
        Adapter.OnShownOrHidden(ContainerFrameCombinedBags, fn)
    end
end

-- True while the bag window has the controller and no game menu or box stands over it.
function Adapter.ItemBagsHavePad()
    local ok, free = pcall(function()
        return GamepadMode.FrameControlsManager.topSuspendedFrame == nil
    end)
    return Adapter.WindowHasPad(Adapter.ItemBags()) and ok and free or false
end

-- The item in the game's focus in the bag window, with the game's button (only read, for the place), or nil.
function Adapter.ItemFocus()
    local ok, thing = pcall(function()
        local button = SmartNavigation.currentButton
        if Adapter.ItemBagsHavePad() and button and button.buttonContext == SLOT then
            local thing = read(button:GetBagID(), button:GetID())
            if thing then
                thing.button = button
            end
            return thing
        end
    end)
    return ok and thing or nil
end

-- Where the item's button is on the screen, in pixels: { left, right, top, side }. side is "left" when the button's right
-- edge is in the right half of the screen (the menu then stands at its left), the game's rule for the slot's tooltip
-- (Mainline/ContainerFrame.lua 1621 to 1631): the tooltip stands above the slot's top edge, the menu under it. nil when
-- it cannot be read.
function Adapter.ItemPlace(thing)
    local ok, place = pcall(function()
        local b = thing.button
        local scale, whole = b:GetEffectiveScale(), UIParent:GetWidth() * UIParent:GetEffectiveScale()
        local left, right = b:GetLeft() * scale, b:GetRight() * scale
        return { left = left, right = right, top = b:GetTop() * scale, side = right < whole / 2 and "right" or "left" }
    end)
    return ok and place or nil
end

-- The first empty slot of a bag for any item (a quiver or a bag for one trade takes only its kind), or nil.
local function freeSlot()
    for bag = FIRST, LAST do
        local _, family = C_Container.GetContainerNumFreeSlots(bag)
        if (family or 0) == 0 then
            for slot = 1, C_Container.GetContainerNumSlots(bag) do
                if not C_Container.GetContainerItemInfo(bag, slot) then
                    return bag, slot
                end
            end
        end
    end
end

-- What the menu needs to know of the game for the model: dual, vendor, free, worn.
function Adapter.ItemGame()
    local game = { dual = false, vendor = false, free = false, worn = {} }
    pcall(function()
        game.dual = CanDualWield() and true or false
        game.vendor = (MerchantFrame:IsShown() or (ns.Merchant and ns.Merchant.Has())) and true or false
        game.free = freeSlot() ~= nil
        for slot = 1, 19 do
            local link = GetInventoryItemLink("player", slot)
            game.worn[slot] = link and link:match("%[(.-)%]") or nil
        end
    end)
    return game
end

-- The item is still in its slot as it was read: the same id, not locked.
local function still(thing)
    local now = read(thing.bag, thing.slot)
    return now and now.id == thing.id and not now.locked and now or nil
end

-- Asks the game to put the item on in a place (the game's number). Out of combat. True when the call ran, else false and why.
function Adapter.ItemEquip(thing, place)
    if not results().itemActions or InCombatLockdown() then
        return false, "combat, or the game has no call for it"
    end
    local ok, why = pcall(function()
        local now = still(thing)
        if not now then
            return "the slot holds something else now"
        end
        C_Item.EquipItemByName(now.link or now.id, place)
    end)
    if not ok then
        return false, tostring(why)
    end
    return why == nil, why
end

-- Splits amount off the stack into the first free slot of a bag. Out of combat. True and the bag and slot of the new
-- stack when it went down there; else false and why (a stack left on the pointer goes back).
function Adapter.ItemSplit(thing, amount)
    if not results().itemActions or InCombatLockdown() then
        return false, "combat, or the game has no call for it"
    end
    local ok, why, bag, slot = pcall(function()
        local now = still(thing)
        local bag, slot = freeSlot()
        if not now or now.count <= amount then
            return "the stack is not there or is too small now"
        elseif not bag then
            return "no free slot"
        elseif GetCursorInfo() then
            return "the pointer holds something"
        end
        C_Container.SplitContainerItem(thing.bag, thing.slot, amount)
        C_Container.PickupContainerItem(bag, slot)
        if GetCursorInfo() then
            ClearCursor()
            return "the free slot did not take the new stack"
        end
        return nil, bag, slot
    end)
    if not ok then
        pcall(ClearCursor)
        return false, tostring(why)
    end
    return why == nil, why, bag, slot
end

-- Destroys the item. Call it only from the click of a key's press DOWN. asks: the game asks first, with its own question
-- (a bind on pickup or quest item); else the item is picked up and destroyed at once. True when it was asked for; else
-- false and why, and a third value true when the game refused the destroy itself (the item is put back).
function Adapter.ItemDestroy(thing, asks)
    if not results().itemActions or InCombatLockdown() then
        return false, "combat, or the game has no call for it"
    end
    local ok, why, refused = pcall(function()
        if GetCursorInfo() then
            return "the pointer holds something"
        elseif not still(thing) then
            return "the slot holds something else now"
        elseif asks then
            C_Item.ConfirmDeleteItem(C_Item.GetItemGUID(ItemLocation:CreateFromBagAndSlot(thing.bag, thing.slot)))
            return nil
        end
        C_Container.PickupContainerItem(thing.bag, thing.slot)
        local kind, id = GetCursorInfo()
        if kind ~= "item" or id ~= thing.id then
            ClearCursor()
            return "the pointer did not take the item"
        end
        DeleteCursorItem()
        if GetCursorInfo() then
            ClearCursor()
            return "the game refused the destroy", true
        end
    end)
    if not ok then
        pcall(ClearCursor)
        return false, tostring(why)
    end
    return why == nil, why, refused
end

-- True while the pointer holds something (an item picked up in the bags).
function Adapter.ItemOnCursor()
    return GetCursorInfo() ~= nil
end

-- A frame's whole scale on the screen, to place the menu beside the item in screen units.
function Adapter.EffectiveScale(frame)
    return frame:GetEffectiveScale()
end

-- True while a bag slot still holds the item that was read there.
function Adapter.ItemHolds(thing)
    local ok, now = pcall(read, thing.bag, thing.slot)
    return ok and now ~= nil and now.id == thing.id
end
