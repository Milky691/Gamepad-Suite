-- The adapter, part 7: what the character has in its hands and what it can shoot with. For the
-- bind "Fishing Pole" and for the Interact button's two other jobs (Core/Hands.lua).
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- The game's own numbers: the item class "Weapon" and two of its kinds, the two hand slots, and
-- the spells. Fishing has four ranks with one name; any of them gives the name.
local WEAPON, WAND, POLE = 2, 19, 20
local MAIN, OFF, RANGED = 16, 17, 18
local ATTACK, AUTO_SHOT, SHOOT, FISHING = 6603, 75, 5019, { 7620, 7731, 7732, 18248 }
-- The lures, by item number, and how much Fishing each adds while it is on the pole. This build's
-- item table has these six under these numbers (Shiny Bauble, Nightcrawlers, Aquadynamic Fish
-- Lens, Bright Baubles, Flesh Eating Worm, Aquadynamic Fish Attractor), and its enchant table the
-- four sizes "Fishing Lure +25" to "+100".
local LURES = { [6529] = 25, [6530] = 50, [6811] = 50, [6532] = 75, [7307] = 75, [6533] = 100 }

local function isKind(id, wanted)
    if not id then
        return false
    end
    local ok, _, _, _, _, _, class, kind = pcall(C_Item.GetItemInfoInstant, id)
    return ok and class == WEAPON and kind == wanted
end

local function isPole(id)
    return isKind(id, POLE)
end

-- True while a fishing pole is in the hands, and while a wand is on (the game keeps a wand in
-- the slot for ranged weapons).
function Adapter.PoleWorn()
    local ok, id = pcall(GetInventoryItemID, "player", MAIN)
    return ok and isPole(id)
end

function Adapter.WandWorn()
    local ok, id = pcall(GetInventoryItemID, "player", RANGED)
    return ok and isKind(id, WAND)
end

local function poleInBags()
    for bag = 0, 4 do
        for slot = 1, C_Container.GetContainerNumSlots(bag) do
            local id = C_Container.GetContainerItemID(bag, slot)
            if isPole(id) then
                return id
            end
        end
    end
end

-- The lure of the bags that adds the most Fishing, of those the character can use (the game says
-- no to a lure that asks for more Fishing skill): { id =, bonus =, name = }, or nil. The second
-- answer: a lure of any kind is in the bags.
local function bestLure()
    local best, any
    for bag = 0, 4 do
        for slot = 1, C_Container.GetContainerNumSlots(bag) do
            local id = C_Container.GetContainerItemID(bag, slot)
            any = any or LURES[id] ~= nil
            if LURES[id] and (not best or LURES[id] > best.bonus) and C_Item.IsUsableItem(id) then
                best = { id = id, bonus = LURES[id], name = C_Item.GetItemNameByID(id) }
            end
        end
    end
    return best, any or false
end

-- What the hands hold: { main =, off = (item numbers; nil for an empty hand), worn = true while a
-- fishing pole is in the hands, pole = the number of that pole, or of the first one in the bags
-- (nil when the character has none), icon = the pole's picture, lure = the lure that can go on the
-- pole now (bestLure), else nil, lured = the pole in the hands has a lure on it, lures = a lure of any
-- kind is in the bags }. A lure can go on out of a fight, with the pole in the hands and no lure on
-- it; lure, lured and lures are read out of a fight only. The game's own aura code asks the same
-- call whether a hand has one (Blizzard_RestrictedAddOnEnvironment/SecureAuraHeader.lua 71).
function Adapter.Hands()
    local hands = {}
    pcall(function()
        hands.main, hands.off = GetInventoryItemID("player", MAIN), GetInventoryItemID("player", OFF)
        hands.worn = isPole(hands.main) or false
        hands.pole = hands.worn and hands.main or poleInBags()
        hands.icon = hands.pole and C_Item.GetItemIconByID(hands.pole) or nil
        if not InCombatLockdown() then
            hands.lured = hands.worn and C_PaperDollInfo.GetTemporaryEnchantmentInfo(MAIN) ~= nil
            local best, any = bestLure()
            hands.lure, hands.lures = hands.worn and not hands.lured and best or nil, any
        end
    end)
    return hands
end

-- The minutes left of the lure on the pole in the main hand (TemporaryItemEnchantInfo.remainingTimeMs,
-- PaperDollInfoDocumentation.lua 491 to 498), or nil: none on it, or the game hides the time.
function Adapter.LureLeft()
    local ok, info = pcall(C_PaperDollInfo.GetTemporaryEnchantmentInfo, MAIN)
    local ms = ok and type(info) == "table" and info.remainingTimeMs or nil
    if type(ms) ~= "number" or (issecretvalue and issecretvalue(ms)) then
        return nil
    end
    return math.max(1, math.ceil(ms / 60000))
end

-- Puts the item in the main hand into the first bag with a free place for it (a profession's bag
-- takes no pole), out of combat, at a press: the pole of a character that had no weapon to put
-- back. The game's own pickup and put, as its equipment sets do (Blizzard_FrameXML/Mainline/
-- EquipmentManager.lua 155 to 190); ControllerForever puts gear away so on this game
-- (ControllerForever_Profiles.lua 1215 to 1235). False when no bag has room.
function Adapter.PoleToBags()
    if InCombatLockdown() then
        return false
    end
    local ok, done = pcall(function()
        for bag = 0, 4 do
            local free, family = C_Container.GetContainerNumFreeSlots(bag)
            if (free or 0) > 0 and (family or 0) == 0 then
                ClearCursor()
                PickupInventoryItem(MAIN)
                if bag == 0 then
                    PutItemInBackpack()
                else
                    PutItemInBag(C_Container.ContainerIDToInventoryID(bag))
                end
                return true
            end
        end
        return false
    end)
    return ok and done or false
end

-- The restricted code of the pole's button, which the game runs at each press and let-go of its
-- key, in a fight too. In a fight, or with no pole in the hands, the press acts as the key goes
-- down, as the other binds do: the pole or the weapons ("swap"; none with no pole at all). With the
-- pole in the hands ("worn") out of a fight, nothing happens until the let-go: a tap is the
-- weapons, a hold ("long" = "lure", Core/Hands.lua tells it at the let-go) puts on the lure
-- ("lure") when one can go on, and else does nothing (Hands.lua says why), as does a hold let go
-- too late ("late"). A fight that starts during the hold makes the let-go the weapons. The game
-- runs "type" as the key goes down and "typerelease" as it comes up while "pressAndHoldAction" is
-- on (Blizzard_FrameXML/SecureTemplates.lua 724 and 802 to 826); the wheel's button uses the same.
local PRESS = [[
    self:SetAttribute("type", nil)
    self:SetAttribute("typerelease", nil)
    local calm = not PlayerInCombat()
    local lure = calm and self:GetAttribute("lure")
    if down then
        local wait = calm and (lure or self:GetAttribute("worn"))
        self:SetAttribute("waiting", wait and true or nil)
        if not wait then
            self:SetAttribute("macrotext", self:GetAttribute("swap"))
            self:SetAttribute("type", "macro")
        end
    elseif self:GetAttribute("waiting") then
        self:SetAttribute("waiting", nil)
        local long = calm and self:GetAttribute("long")
        local text = (not long and self:GetAttribute("swap")) or (long == "lure" and lure) or nil
        if text then
            self:SetAttribute("macrotext", text)
            self:SetAttribute("typerelease", "macro")
        end
    end
]]

-- Makes the pole's button. A key goes to it while a lure can go on (Core/Hands.lua). A button of
-- these two templates that runs its own restricted code works on this game (ControllerForever's
-- consumables button, ControllerForever_Consumables.lua 733 to 741).
function Adapter.PoleButton(name)
    local button = CreateFrame("Button", name, UIParent, "SecureActionButtonTemplate, SecureHandlerBaseTemplate")
    button:RegisterForClicks("AnyDown", "AnyUp")
    button:SetAttribute("pressAndHoldAction", true)
    SecureHandlerWrapScript(button, "OnClick", button, PRESS)
    return button
end

-- The game's own word for a kind of weapon ("Fishing Poles"), as a macro condition reads it.
local function kindName(kind)
    local ok, name = pcall(C_Item.GetItemSubClassInfo, WEAPON, kind)
    return ok and type(name) == "string" and name ~= "" and name or nil
end

-- The words the game's chat commands need, each nil when the game or the character does not have
-- it. poles and wands are the game's words for the two kinds of weapon. fishing, shot (Auto Shot)
-- and shoot (the wand's Shoot) are spells the character knows, and attack is the melee attack:
-- each { id, name, icon }.
function Adapter.HandWords()
    local function known(ids)
        return Adapter.KnownSpells(ids)[1]
    end
    local ok, name = pcall(C_Spell.GetSpellName, ATTACK)
    return {
        poles = kindName(POLE), wands = kindName(WAND),
        fishing = known(FISHING), shot = known({ AUTO_SHOT }), shoot = known({ SHOOT }),
        attack = ok and name and { id = ATTACK, name = name, icon = C_Spell.GetSpellTexture(ATTACK) } or nil,
    }
end

-- True when a spell number is Fishing, of any rank.
function Adapter.IsFishing(spell)
    local ok, name, fishing = pcall(function()
        return C_Spell.GetSpellName(spell), C_Spell.GetSpellName(FISHING[1])
    end)
    return ok and name ~= nil and name == fishing
end

-- Tells start(spell number) and stop() of the player's own channeled casts. Only the player's are
-- asked for: the game hides the unit of another unit's cast from an addon, and a compare with it
-- is an error.
function Adapter.OnPlayerChannel(start, stop)
    local watcher = CreateFrame("Frame")
    watcher:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_START", "player")
    watcher:RegisterUnitEvent("UNIT_SPELLCAST_CHANNEL_STOP", "player")
    watcher:SetScript("OnEvent", function(_, event, _, _, spell)
        if event == "UNIT_SPELLCAST_CHANNEL_START" then
            ns.Call("Hands", start, spell)
        else
            ns.Call("Hands", stop)
        end
    end)
end

-- While the fishing line is out, the bobber must be the thing the Interact button takes. The game
-- highlights what is near and in front of the character, and only what is in reach while the bind
-- core holds that (Core/BindCore.lua push). For that time it highlights always, all round the
-- character, further out and out of reach too (ControllerForever_RuleBar.lua 10488 to 10497). The
-- game's own gamepad mode and the bind core set these settings for the session (Blizzard_Gamepad/
-- Core.lua 14 to 33, Blizzard_GamepadTargeting/TargetLogic.lua 97 to 103), so they go back to
-- what they were, not to the player's saved value. Nothing is written to the player's settings
-- file. Hands.lua puts them back at logout too: a reload with the line out would keep them. While
-- the line is out they are lent (Adapter.HoldSetting): the bind core can build the binds again then
-- (its "only in reach" waits), and what it asked for is what comes back when the line is in.
local WIDE = { SoftTargetInteract = "3", SoftTargetInteractArc = "2", SoftTargetInteractRange = "40",
    SoftTargetInteractOnlyInRange = "0" }
-- The log has, one time, what the game reads back the first time the line is out.
local wide, told = false, nil
function Adapter.WideInteract(on)
    on = on and true or false
    if not results().tempSetting or on == wide then
        return
    end
    wide = on
    local lent = Adapter.lent
    for name, value in pairs(WIDE) do
        if on then
            local ok, now = pcall(GetCVar, name)
            lent[name] = ok and now or false
        end
        local back = lent[name]
        if not on then
            lent[name] = nil
        end
        pcall(function()
            if on or back then
                C_CVar.SetTempCVar(name, on and value or back)
            else
                C_CVar.RemoveTempCVar(name)
            end
        end)
    end
    if on and not told then
        told = {}
        for name in pairs(WIDE) do
            told[#told + 1] = name .. " " .. tostring(select(2, pcall(GetCVar, name)))
        end
        table.sort(told)
        ns.Log.Add("hands", "the fishing line is out; the game reads " .. table.concat(told, ", "))
    end
end

-- What one of the game's macro rules gives now ("1", "0"), for the log. The game's state drivers
-- read their rules the same way (Blizzard_RestrictedAddOnEnvironment/SecureStateDriver.lua 95).
function Adapter.RuleReads(rule)
    local ok, value = pcall(SecureCmdOptionParse, rule)
    return ok and tostring(value) or "an error"
end

-- What the game highlights to interact with, for the log: name (nil when nothing is), unit (an NPC
-- or a corpse; else a thing that is no unit, as a mailbox or the bobber), reach (in reach), and rule:
-- what the owner frame's rule for it gives (Core/BindSecure.lua). The game's own Interact asks the
-- same three calls (Blizzard_GamepadActionBars/MainActionBarFrame.lua 258 to 260).
function Adapter.Highlight()
    local seen = { rule = Adapter.RuleReads("[@softinteract,exists] 1; 0") }
    pcall(function()
        seen.unit = UnitExists("softinteract") and true or false
        if seen.unit or UnitIsGameObject("softinteract") then
            seen.name = UnitName("softinteract") or "a thing with no name"
            seen.reach = UnitIsInInteractRange("softinteract") and true or false
        end
    end)
    return seen
end
