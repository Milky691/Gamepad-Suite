-- The rules of the fixed slots, with no game calls. A fixed slot is an extra slot that stays on
-- the screen: it holds one action, and a held trigger, a form or the Combat set does not change
-- it. There are eight. A slot with no action does not show. Each slot with an action is in the
-- bind list as "Slot 3"; a button with that bind runs the slot's action.
local _, ns = ...

local Rules = {}

Rules.MOST = 8
Rules.LIST = "Fixed Slots" -- the name of their list in the bind list
-- A slot's place is two numbers, in the units of the on-screen buttons from the middle of the
-- screen (x to the right, y up; the screen is 1600 by 900 of them at UI scale 1, and 1600 / scale
-- by 900 / scale at another). The rows move it in steps of ten, out to the edge of the player's
-- screen (Screen/WheelPlace.lua fits them when the settings window opens); a place itself can be
-- out to the edge of a 32 to 9 screen at UI scale 0.5. Before the player moves it a slot is in one
-- of two columns, at the outer side of each group of on-screen buttons: slots 1 to 4 at the left,
-- 5 to 8 at the right.
Rules.X, Rules.Y = { min = -4000, max = 4000 }, { min = -2000, max = 2000 }
Rules.PLACE = {
    { -480, -130 }, { -480, -210 }, { -480, -290 }, { -480, -370 },
    { 480, -130 }, { 480, -210 }, { 480, -290 }, { 480, -370 },
}
-- The buttons held for each layer of the binds (Core/Binds.lua), in the order they show.
Rules.HELD = { [1] = {}, [2] = { "LT" }, [3] = { "RT" }, [4] = { "LT", "RT" }, [5] = { "LB", "RB" } }
local SET = { normal = 1, combat = 2 }

function Rules.Name(n)
    return "Slot " .. n
end

-- The slot's number from a row's value ("Slot 3"), or nil.
function Rules.Number(name)
    local n = tonumber(tostring(name):match("^Slot (%d+)$"))
    return n and n >= 1 and n <= Rules.MOST and n or nil
end

-- The buttons that show above a slot, held ones first: { "RT", "A" }. each(fn) calls
-- fn(bind, set, layer, key) for every bind of the store. A button with the bind "Slot n" comes
-- first; with none, a button that has the slot's own action as its bind, cast on the same one (bind.on,
-- nil for the target: Core/BindRules.lua Rules.ON). Of several, the one in the Normal set, then on the
-- lowest layer. nil when no button has either.
function Rules.Keys(each, n, action)
    local best, rank
    each(function(bind, set, layer, key)
        local direct = bind.kind == "fixed" and bind.id == n
        if direct or (action and bind.kind == action.kind and bind.id == action.id and bind.on == action.on) then
            local now = (direct and 0 or 1000) + (SET[set] or 3) * 100 + layer * 10
            if not rank or now < rank or (now == rank and key < best.key) then
                best, rank = { layer = layer, key = key }, now
            end
        end
    end)
    if not best then
        return nil
    end
    local keys = {}
    for i, held in ipairs(Rules.HELD[best.layer] or {}) do
        keys[i] = held
    end
    keys[#keys + 1] = best.key
    return keys, best.layer
end

-- True when a slot's action is a spell the character does not know now: a talent reset took it, and it
-- knows no spell of that name in its place. known(id) and now(id) are Adapter.SpellKnown and
-- Adapter.SpellNow (Core/AdapterSpells.lua); with none, every spell is known.
function Rules.Unknown(bind, known, now)
    return bind ~= nil and bind.kind == "spell" and type(bind.id) == "number" and known ~= nil and not known(now(bind.id))
end

-- The slots as entries for the bind list: one for each slot that has an action. icon gives the
-- picture of a bind as it is now.
function Rules.Binds(slots, icon)
    local out = {}
    for n = 1, Rules.MOST do
        local action = slots[n]
        if action then
            out[#out + 1] = { kind = "fixed", id = n, name = Rules.Name(n), detail = action.name or "", icon = icon(action) }
        end
    end
    return out
end

-- The lists the Fixed Slot Binds page offers: every list of the bind list but the slots' own (a slot
-- cannot hold a slot).
function Rules.Offer(lists)
    local out = {}
    for _, list in ipairs(lists) do
        if list.name ~= Rules.LIST then
            out[#out + 1] = list
        end
    end
    return out
end

-- The binds of ours that are held: their button acts at the press and at the let-go
-- (Auto/LookBehind.lua, Screen/Zoom.lua, Windows/PeekMap.lua).
Rules.HOLDS = { GamepadSuiteLookBehind = true, GamepadSuiteStickZoom = true, GamepadSuitePeekMap = true }

-- What a tap on a slot runs for a bind of ours ("CLICK GamepadSuiteMount:LeftButton"), as the
-- attributes of the tap's secure button: the chat command that clicks that button with the press
-- going down ("1"), as the bind's key does. The game's own click action gives no press
-- (Blizzard_FrameXML/SecureTemplates.lua 557 to 563), and the secure buttons of ours act only on
-- one. A held bind gets the let-go too, as its key does: the game runs "typerelease" at the let-go
-- of a button with "pressAndHoldAction" (788 to 818), and the press goes by a button name of its
-- own ("downbutton", 686 to 689), so press and let-go each have their own text ("-press" is the
-- game's suffix for that name, 101 to 117; "*" stands for any modifier key). nil for any other command.
function Rules.Click(command)
    local name, mouse = command:match("^CLICK (GamepadSuite[^:]+):(.+)$")
    if not name then
        return nil
    end
    local click = "/click " .. name .. " " .. mouse
    if not Rules.HOLDS[name] then
        return { type = "macro", macrotext = click .. " 1" }
    end
    return { type = "macro", downbutton = "press", ["*macrotext-press"] = click .. " 1", typerelease = "macro", macrotext = click, pressAndHoldAction = true }
end

function Rules.Count(slots)
    local count = 0
    for n = 1, Rules.MOST do
        count = count + (slots[n] and 1 or 0)
    end
    return count
end

if ns then
    ns.SlotRules = Rules
end
return Rules
