-- The adapter's part for the looks of the on-screen buttons (Screen/HudFace.lua, Screen/Hud.lua).
-- For Plate and Round: a mask that gives a picture soft corners or makes it round, a cooldown
-- sweep in that shape, and the font of a cooldown's number, and what a button of those looks is
-- made of with them (Adapter.Shaped). The game can refuse each of the three.
-- Then the picture stays square, the sweep and the number stay the game's own, and the log gets
-- one line for each kind of refusal.
-- For every look: the game's own word that a target went out of reach, and that one of its own
-- bar buttons was pressed, so that the buttons need not ask many times a second.
local _, ns = ...

local Adapter = ns.Adapter

-- The two shapes, each a file of the game. The shape is the part of the file from `from` to
-- `to`, across and down.
--   round: the circle of the game's own round gamepad buttons, which is also their cooldown
--   sweep (Blizzard_GamepadActionBars/ActionBarButton.lua:253).
--   soft: the mask of the game's own action buttons (the atlas UI-HUD-ActionBar-IconFrame-Mask,
--   Blizzard_ActionBar/Mainline/ActionButtonTemplate.xml:24). The file is 64 wide and its soft
--   square is the middle 40.4, which is why the game makes this mask larger than its picture
--   (Blizzard_ActionBar/Shared/ActionButton.lua:1745: 45 wide for a picture of 30).
local SHAPE = {
    round = { file = "Interface\\CharacterFrame\\TempPortraitAlphaMask", from = 0, to = 1 },
    soft = { file = "Interface\\HUD\\UIActionBarIconFrameMask", from = 11.5 / 64, to = 51.9 / 64 },
}
-- outside its file a mask is black: nothing shows there
local WRAP = "CLAMPTOBLACKADDITIVE"
local PLAIN = "Interface\\Buttons\\WHITE8X8"

local told = {}
local function refused(what, err)
    if not told[what] then
        told[what] = true
        ns.Log.Add("look", "The game refused " .. what .. ": " .. tostring(err) .. ". The on-screen buttons keep the square shape there.")
    end
end

-- Cuts a texture to a shape. width is the texture's width, in the units of its frame. True when
-- the game did it; with false the texture keeps its square shape. anchor: the region whose shape
-- it takes, for a part of it (a strip of a glow along one side of a picture); else the texture.
function Adapter.Shape(texture, shape, width, anchor)
    local s = SHAPE[shape]
    anchor = anchor or texture
    local ok, err = pcall(function()
        local mask = texture:GetParent():CreateMaskTexture()
        mask:SetTexture(s.file, WRAP, WRAP)
        -- the file stands out past the texture, so that its shape is as large as the texture
        local unit = width / (s.to - s.from)
        mask:SetPoint("TOPLEFT", anchor, "TOPLEFT", -s.from * unit, s.from * unit)
        mask:SetPoint("BOTTOMRIGHT", anchor, "BOTTOMRIGHT", (1 - s.to) * unit, (s.to - 1) * unit)
        texture:AddMaskTexture(mask)
    end)
    if not ok then
        refused("a mask", err)
    end
    return ok
end

-- Gives a cooldown frame a sweep in a shape and a color. The game's own way to use a part of a
-- file for a sweep: the file, then the part (Blizzard_UnitFrame/Mainline/RuneFrame.lua:152-156).
function Adapter.Sweep(cooldown, shape, r, g, b, a)
    local s = SHAPE[shape]
    local ok, err = pcall(function()
        cooldown:SetSwipeTexture(s.file)
        if s.from > 0 then
            cooldown:SetTexCoordRange({ x = s.from, y = s.from }, { x = s.to, y = s.to })
        end
        cooldown:SetSwipeColor(r, g, b, a)
    end)
    if not ok then
        -- (the file with no part of it chosen would be a small sweep in the middle: back to the plain square)
        pcall(cooldown.SetSwipeTexture, cooldown, PLAIN)
        pcall(cooldown.SetSwipeColor, cooldown, r, g, b, a)
        refused("a cooldown sweep in a shape", err)
    end
    return ok
end

-- The font, the size and the color of the number that the game draws on a cooldown frame. The
-- addon cannot draw that number itself: in a fight the game hides the time left from it.
function Adapter.CooldownNumber(cooldown, font, size, outline, r, g, b)
    local ok, err = pcall(function()
        local text = cooldown:GetCountdownFontString()
        text:SetFont(font, size, outline and "OUTLINE" or "")
        text:SetTextColor(r, g, b)
        text:SetShadowColor(0, 0, 0, 1)
        text:SetShadowOffset(1, -1)
    end)
    if not ok then
        refused("the font of a cooldown number", err)
    end
    return ok
end

-- What a look with a shape (Plate, Round) changes in an on-screen button of Screen/HudFace.lua:
-- the picture alone, cut to the shape; a dark plate for a button with no bind; the cooldown in the
-- shape, with the look's number (a size of the Theme for a main picture, smaller by as much for a
-- smaller one). size is the picture's size in units. Gives the arc of Round, or nil.
local function around(texture, b, by)
    texture:ClearAllPoints()
    texture:SetPoint("TOPLEFT", b, "TOPLEFT", -by, by)
    texture:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", by, -by)
end

function Adapter.Shaped(b, look, size)
    local Theme = ns.Theme
    local px = Theme.px
    local function shape(texture, width)
        Adapter.Shape(texture, look.shape, px(width))
    end
    local level = b:GetFrameLevel()
    -- the square edge and the well of the picture box are not shown
    for _, region in ipairs({ b.icon:GetRegions() }) do
        if region ~= b.icon.art then
            region:Hide()
        end
    end
    shape(b.icon.art, size)
    if look.emptyFill then
        b.fill = b.icon:CreateTexture(nil, "BACKGROUND")
        b.fill:SetColorTexture(0, 0, 0, look.emptyFill)
        b.fill:SetAllPoints()
        shape(b.fill, size)
    end
    -- from the bottom up: the arc of Round, the picture, the cooldown with its number
    b.icon:SetFrameLevel(level + 2)
    b.cooldown:SetFrameLevel(level + 3)
    if look.number then
        Adapter.CooldownNumber(b.cooldown, Theme.font.text, px(Theme.size[look.number[1]] * size / look.main), look.number[2], Theme.Color("white"))
    end
    if not look.arc then
        Adapter.Sweep(b.cooldown, look.shape, 0, 0, 0, 0.64)
        return nil
    end
    -- Round: on cooldown the picture goes dim. The dim is a part of the cooldown frame, which the
    -- game shows only while a cooldown runs.
    b.cooldown:SetDrawSwipe(false)
    local dim = b.cooldown:CreateTexture(nil, "BACKGROUND")
    dim:SetColorTexture(0, 0, 0, look.dim)
    dim:SetAllPoints()
    shape(dim, size)
    -- The time left is a thin light arc on the ring: a second cooldown frame under the picture,
    -- a little larger, with a round sweep. The picture covers all of the sweep but its rim.
    local width, out, gray = look.arc[1], look.arc[2], look.arc[3]
    local arc = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    arc:ClearAllPoints()
    arc:SetPoint("TOPLEFT", b, "TOPLEFT", -px(width), px(width))
    arc:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", px(width), -px(width))
    arc:SetFrameLevel(level + 1)
    arc:SetDrawEdge(false)
    arc:SetDrawBling(false)
    arc:SetHideCountdownNumbers(true)
    -- (a square sweep would show its corners past the round picture: then there is no arc)
    arc:SetDrawSwipe(Adapter.Sweep(arc, look.shape, gray, gray, gray, 1))
    -- the arc's dark outline, under the ring and the rims: a frame of the arc's own, so that it
    -- shows with the arc and at no other time
    local under = CreateFrame("Frame", nil, arc)
    under:SetAllPoints(b)
    under:SetFrameLevel(math.max(0, level - 1))
    local outline = under:CreateTexture(nil, "BACKGROUND")
    outline:SetColorTexture(0, 0, 0, look.line[2])
    around(outline, b, px(out))
    shape(outline, size + 2 * out)
    return arc
end

-- Names a bind's spell or action slot to the game. From then on the game tells with an event
-- when the target goes out of that action's reach or comes back (SPELL_RANGE_CHECK_UPDATE,
-- ACTION_RANGE_CHECK_UPDATE). The game's own bars do the same
-- (Blizzard_CooldownViewer/CooldownViewer.lua:736, Blizzard_ActionBar/Shared/ActionButton.lua:402).
-- An item has no such event. Neither call is a protected one in the game's notes. A macro names
-- the spell it would cast now (Core/AdapterMacro.lua); the buttons are drawn again at each change
-- of a modifier key, a form or the target, and then name the next one.
-- Limit: an action once named stays named. The event comes at a change only, and the game's
-- own bars name the same spells: taking a name back here could turn their event off.
local named = {}
function Adapter.WatchRange(bind)
    pcall(function()
        bind = Adapter.Now(bind)
        local slot = bind.kind == "slot" and bind.id
        local spell = bind.kind == "spell" and type(bind.id) == "number" and bind.id
        if slot and not named["slot" .. slot] then
            C_ActionBar.EnableActionRangeCheck(slot, true)
            named["slot" .. slot] = true
        elseif spell and not named[spell] then
            C_Spell.EnableSpellRangeCheck(spell, true)
            named[spell] = true
        end
    end)
end

-- Tells fn each time one of the game's own eight gamepad bar buttons goes down or comes up. The
-- game's binds for those buttons call this function of its bar
-- (Blizzard_GamepadActionBars/Bindings.xml:9). We watch the call and write nothing into the bar.
function Adapter.OnNativePress(fn)
    local bar = GamepadMainActionBarFrame
    if type(bar) == "table" and type(bar.PressActionButton) == "function" and hooksecurefunc then
        hooksecurefunc(bar, "PressActionButton", function()
            fn()
        end)
    end
end
