-- The adapter, part 12: the slots of the game's keyboard bars, for Press and Hold Casting with
-- every spell bind (Core/HoldSlots.lua).
--
-- The game has seven extra keyboard bars of twelve buttons. Each button has a key command of its
-- own (MULTIACTIONBAR1BUTTON1 and so on, Blizzard_FrameXML/Bindings_Camelot.xml 400 to 990). The
-- command presses the bar's button as a real key press (Blizzard_ActionBar/Shared/
-- MultiActionBars.lua 35 to 50, ActionButton.lua 109 to 112): the one way the game is asked to
-- cast the slot's spell again while the key is held, and the key's let-go ends it (the game's
-- own text: "a keyboard hotkey" does it, "clicking ... with the mouse" does not). The bars are
-- there in controller mode too, not shown (MultiActionBars.xml 45). An addon can put a thing
-- into a slot out of a fight, the way the game's own controller bar does it
-- (Blizzard_GamepadActionBars/ActionBindingUtil.lua 142 to 181).
local _, ns = ...

local Adapter = ns.Adapter

-- The bars by the number in their key commands.
local BARS = { "MultiBarBottomLeft", "MultiBarBottomRight", "MultiBarRight", "MultiBarLeft", "MultiBar5", "MultiBar6", "MultiBar7" }

-- What a slot holds: { kind, id }, or false for nothing.
function Adapter.SlotRead(slot)
    local ok, kind, id = pcall(GetActionInfo, slot)
    return ok and kind and { kind = kind, id = id } or false
end

-- Every slot that a key command of those bars presses: { { slot, command, now } }, the newest
-- bars first (a player uses them least). The slot is the one the button itself gives the game at
-- a press. A slot that the controller bar shows is left out: those are the player's bar in play.
-- Empty when the bars or their buttons are not there.
function Adapter.HoldBarSlots()
    local out = {}
    for number = #BARS, 1, -1 do
        pcall(function()
            local buttons = _G[BARS[number]].actionButtons
            for id = 1, 12 do
                local button = buttons[id]
                local slot = button.CalculateAction and button:CalculateAction("LeftButton") or button.action
                if type(slot) == "number" and not C_GamepadUI.IsValidGamepadActionStorageSlotIndex(slot) then
                    out[#out + 1] = { slot = slot, command = "MULTIACTIONBAR" .. number .. "BUTTON" .. id, now = Adapter.SlotRead(slot) }
                end
            end
        end)
    end
    return out
end

-- True while the mouse pointer carries a thing: the player is moving it, and no write of ours
-- may drop it or put it into a slot.
local function carrying()
    local ok, what = pcall(GetCursorInfo)
    return not ok or what ~= nil
end

-- Puts a spell into a slot that holds nothing. A slot that holds anything is the player's and is
-- not touched. The game refuses a write in a fight, so nothing is tried in one, and nothing is
-- tried while the pointer carries a thing. The spell is taken on the mouse pointer and put down,
-- as a hand does it; the pointer is empty after. With nothing on the pointer (the game does not
-- let that spell be taken) nothing is put down. True when the slot reads back as that very
-- spell. When the game put another thing there than was asked for (another rank), that is taken
-- out again: the slot held nothing before.
function Adapter.SlotPut(slot, spell)
    if InCombatLockdown() or Adapter.SlotRead(slot) or carrying() then
        return false
    end
    pcall(function()
        ClearCursor()
        C_Spell.PickupSpell(spell)
        if GetCursorInfo() then
            PlaceAction(slot)
        end
    end)
    pcall(ClearCursor)
    local now = Adapter.SlotRead(slot)
    if now and not (now.kind == "spell" and now.id == spell) then
        pcall(PickupAction, slot)
        pcall(ClearCursor)
        return false
    end
    return now and true or false
end

-- Takes our spell out of a slot. Only a slot that still holds that very spell is touched, not in
-- a fight and not while the pointer carries a thing. True when the slot holds nothing after.
function Adapter.SlotTake(slot, spell)
    local now = Adapter.SlotRead(slot)
    if now and now.kind == "spell" and now.id == spell and not InCombatLockdown() and not carrying() then
        pcall(PickupAction, slot)
        pcall(ClearCursor)
        now = Adapter.SlotRead(slot)
    end
    return not now
end

-- The spells of the character's forms and stances, Prowl and Stealth too: spell -> true.
function Adapter.FormSpells()
    local out = {}
    pcall(function()
        for _, form in ipairs(Adapter.Forms()) do
            out[tonumber(form.id:match("%d+")) or 0] = true
        end
        for index = 1, GetNumShapeshiftForms() do
            out[select(4, GetShapeshiftFormInfo(index)) or 0] = true
        end
    end)
    return out
end

-- The slot of the game's own bar button of that name, to run it from a button of ours. A press
-- of the game's button itself does nothing while Shift is down: Shift is the game's key to pick up
-- an action (ActionButton.lua 1409 to 1419, PICKUPACTION, Bindings_Camelot.xml 1548), and LT is
-- Shift on most setups, so LT + a button did nothing through it. A button of ours runs the slot
-- with no such rule (SecureTemplates.lua 341 to 359). nil for a slot of the game's own fixed jobs
-- (Jump, Interact), which run a script of their own (ActionBindingUtil.lua 46 to 49), and for a
-- spellbook pop-out (portals, demons, totems): the game opens it on the button that ran the slot
-- (SecureTemplates.lua 348 to 354, SpellFlyout.lua 384), and ours has none of a bar button's parts,
-- a Lua error in play (ControllerForever's CHANGELOG 116). The key clicks the game's button then.
function Adapter.NativeAction(name)
    local ok, slot = pcall(function()
        local button = _G[name]
        if GamepadActionBarBindingUtil.IsReservedPageUnitSlotID(button.pageUnitSlotID or 0) then
            return nil
        end
        local slot = button:CalculateAction()
        return GetActionInfo(slot) ~= "flyout" and slot or nil
    end)
    return ok and type(slot) == "number" and slot > 0 and slot or nil
end

-- Stealth, Prowl and Shadowform, which this game does not end on a second cast (ControllerForever
-- found it in play: its CHANGELOG 78 and 163-167): gives the game's word for the state in a chat
-- command ("stealth", or "form" for a priest, whose one form is Shadowform) and the spell's name.
-- Any rank, by the name of the first. Nothing for any other spell.
local TOGGLES = { [1784] = "stealth", [5215] = "stealth", [15473] = "form" }
function Adapter.ToggleSpell(id)
    local name = type(id) == "number" and C_Spell.GetSpellName(id)
    for first, word in pairs(name and TOGGLES or {}) do
        if C_Spell.GetSpellName(first) == name then
            return word, name
        end
    end
end

-- The modifier key of the game's Self Cast click: ALT at the start
-- (Blizzard_FrameXML/Bindings_Camelot.xml 1537). A press of one of the game's bar buttons with
-- that key down casts on the player (Blizzard_FrameXML/SecureTemplates.lua 190 to 193). nil when
-- the player has set it to none; ALT when the game cannot be asked.
function Adapter.SelfCastModifier()
    local ok, key = pcall(GetModifiedClick, "SELFCAST")
    key = ok and type(key) == "string" and key:upper() or "ALT"
    return key ~= "NONE" and key or nil
end

-- Tells fn(command, down) at each press and each let-go that the game runs for a key command of
-- those bars. The game's two calls are heard, not replaced. True when the game has them.
function Adapter.OnHoldBarKey(fn)
    if type(MultiActionButtonDown) ~= "function" or type(MultiActionButtonUp) ~= "function" then
        return false
    end
    local number = {}
    for index, name in ipairs(BARS) do
        number[name] = index
    end
    for call, down in pairs({ MultiActionButtonDown = true, MultiActionButtonUp = false }) do
        hooksecurefunc(call, function(bar, id)
            if number[bar] then
                fn("MULTIACTIONBAR" .. number[bar] .. "BUTTON" .. tostring(id), down)
            end
        end)
    end
    return true
end

-- A number the game hides in a fight is no number here (a compare with it is an error).
local function plain(value)
    return not (issecretvalue and issecretvalue(value)) and value or nil
end

-- Tells fn(slot, keyPress, spell, pad) each time the game uses an action slot, and fn(slot) when
-- it lets one go: the two calls that every action button of the game ends in, its bars and the
-- buttons of ours alike (Blizzard_FrameXML/SecureTemplates.lua 342 to 367). keyPress is the
-- game's word that a key was pressed, the one that lets it cast again while the key is held
-- (806 to 818); spell is the spell in the slot, nil for another thing; pad is true for a slot of
-- the game's controller bar, whose buttons give that word themselves
-- (Blizzard_GamepadActionBars/ActionBarButton.lua 1096 to 1114). The calls are heard after the
-- game ran them, not replaced: the hook that the game allows for its protected calls.
-- True when the game has them.
function Adapter.OnActionUse(fn)
    if type(UseAction) ~= "function" or type(ReleaseAction) ~= "function" then
        return false
    end
    hooksecurefunc("UseAction", function(slot, _, _, keyPress)
        local ok, kind, id = pcall(GetActionInfo, slot)
        local pad = keyPress and select(2, pcall(function() return C_GamepadUI.IsValidGamepadActionStorageSlotIndex(slot) end)) == true
        fn(slot, keyPress and true or false, ok and kind == "spell" and plain(id) or nil, pad)
    end)
    hooksecurefunc("ReleaseAction", function(slot)
        fn(slot)
    end)
    return true
end

-- Tells fn(spell, what) at each step of a cast of the player's while it is set: what is "start"
-- (a cast with a cast time began), "done" (it landed), "refused" (the game did not let it go)
-- or "stop" (it was cut off). spell is nil while the game hides it. fn = nil ends it: the events
-- are heard only while a held press is measured.
local STEP = { UNIT_SPELLCAST_START = "start", UNIT_SPELLCAST_SUCCEEDED = "done", UNIT_SPELLCAST_FAILED = "refused",
    UNIT_SPELLCAST_FAILED_QUIET = "refused", UNIT_SPELLCAST_INTERRUPTED = "stop" }
local ear
function Adapter.HearCasts(fn)
    ear = ear or CreateFrame("Frame")
    ear:UnregisterAllEvents()
    ear:SetScript("OnEvent", fn and function(_, event, _, _, spell)
        fn(plain(spell), STEP[event])
    end or nil)
    for event in pairs(fn and STEP or {}) do
        pcall(ear.RegisterUnitEvent, ear, event, "player")
    end
end

-- How many buttons of the pad are down now, the four holding buttons not counted.
function Adapter.PadKeysDown()
    local holding, count = {}, 0
    for _, ourKey in ipairs({ "LT", "RT", "LB", "RB" }) do
        holding[Adapter.PadIndex(ourKey) or 0] = true
    end
    for index, down in pairs(Adapter.PadState()) do
        count = count + ((down and not holding[index]) and 1 or 0)
    end
    return count
end
