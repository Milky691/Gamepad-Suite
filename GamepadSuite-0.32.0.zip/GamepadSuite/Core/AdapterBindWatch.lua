-- The adapter, part 3b: what the bind core and Core/Pad.lua hear of the game's keys during play. A
-- change of the game's window binds, another writer of a controller key, the let-go of the game's
-- Jump, the game's own controller bar switched off, a key of ours left over, and the windows whose
-- two buttons A and B press. Every hook here runs after the game's own code and writes nothing of
-- the game's.
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- A controller key, with or without modifiers in its name: "PAD1", "SHIFT-PADDUP".
local function padKey(key)
    return type(key) == "string" and key:match("[^-]*$"):find("^PAD") ~= nil
end

-- A frame of ours: every frame of the suite that owns a key is named so.
local function ours(owner)
    local ok, name = pcall(owner.GetName, owner)
    return ok and type(name) == "string" and name:find("^GamepadSuite") ~= nil
end

-- Tells fn each time Blizzard's stack of window binds changes (a window took the controller, or
-- gave it back), and each time another writer sets a controller key or clears its keys: its bind
-- is newer than ours and wins until ours are checked again (ConsolePort's Controller/Input.lua 324
-- to 345 and ControllerForever's RuleBar.lua 5539 to 5556 watch the same calls). fn runs inside the
-- game's own call: the listener waits a frame before it reads anything. We watch Blizzard's own
-- calls and put nothing into its tables. (Its own listener list, BindToCoreBindingActive, is a
-- Blizzard table, and a listener of ours in it would run inside the code that binds A for a window.)
-- The game's restricted code sets keys through calls of its own (RestrictedFrames.lua 24 to 31),
-- so the bind core's owner frame is never heard here.
function Adapter.OnPadStackChanged(fn)
    if not results().padStack then
        return
    end
    local manager = GamepadSharedUtility.InputBindingManager
    for _, name in ipairs({ "AddBindingSet", "RemoveSet", "ClearBindings", "AssumeCoreBindingsAreUsable" }) do
        if type(manager[name]) == "function" then
            hooksecurefunc(manager, name, function() fn() end)
        end
    end
    for _, name in ipairs({ "SetOverrideBinding", "SetOverrideBindingClick", "SetOverrideBindingSpell", "SetOverrideBindingItem", "SetOverrideBindingMacro" }) do
        if type(_G[name]) == "function" then
            hooksecurefunc(name, function(owner, _, key)
                if padKey(key) and not ours(owner) then
                    fn()
                end
            end)
        end
    end
    if type(ClearOverrideBindings) == "function" then
        hooksecurefunc("ClearOverrideBindings", function(owner)
            if not ours(owner) then
                fn()
            end
        end)
    end
end

-- Tells fn at each let-go of the game's Jump: its key command runs AscendStop on the key's let-go
-- (Blizzard_FrameXML/Bindings_Camelot.xml 53 to 59).
function Adapter.OnJumpUp(fn)
    if type(AscendStop) == "function" then
        hooksecurefunc("AscendStop", function() fn() end)
    end
end

-- The game's own controller bar is switched off while the controller interface is on, its Edit Mode
-- is closed and no fight is on: every button with no bind of ours then does nothing
-- (ControllerForever CHANGELOG.md 80: the game's Edit Mode can do this at load). The game hides it
-- itself only when the controller interface goes off (MainActionBarFrame.lua 72 to 76). Its own
-- shown state is asked, so a hidden interface (Alt + Z) does not count.
function Adapter.NativeBarOff()
    local ok, off = pcall(function()
        local bar = results().nativeBar and GamepadMainActionBarFrame
        local editing = EditModeManagerFrame and EditModeManagerFrame:IsShown()
        return bar and not bar:IsShown() and not editing and not InCombatLockdown() and Adapter.ControllerUI()
    end)
    return ok and off and true or false
end

-- Tells fn each time the game's controller bar hides. A hook after the game's own script.
function Adapter.OnNativeBarHidden(fn)
    local bar = results().nativeBar and GamepadMainActionBarFrame
    if bar then
        bar:HookScript("OnHide", function() fn() end)
    end
end

-- A key that reads a click on a button of ours (now: what the key reads) that no part of the addon
-- holds now (Adapter.taken, Core/AdapterPlay.lua TakeKey) is left over: that button's bind for the
-- key goes, out of a fight. True when it went.
function Adapter.DropLeftOver(key, now)
    local name = type(now) == "string" and now:match("^CLICK (GamepadSuite[^:]*):")
    local button = name and _G[name]
    if not button or Adapter.taken[key] == now or InCombatLockdown() then
        return false
    end
    pcall(SetOverrideBinding, button, true, key, nil)
    return GetBindingAction(key, true) ~= now
end

-- Blizzard windows with two buttons that the game's gamepad mode gives no control. first is the
-- button A presses, second the one B presses: the bind core gives A and B to them (Screen/Popups.lua).
-- words name the window in the log. The battleground's ready dialog is shown by StaticPopupSpecial_Show
-- (Blizzard_LFGUtil/Mainline/PVPHelper.lua 436), which only shows the frame (Blizzard_StaticPopup/StaticPopup.lua 945
-- to 954): the game's gamepad handler hears only StaticPopup_Show (StaticPopup.lua 620, StaticPopupGamepad.lua 210 and
-- 265), so it gives that dialog no A and B. Its buttons run the game's own AcceptBattlefieldPort (PVPHelper.lua 445
-- to 470) inside the key bind's click. Blizzard_LFGUtil is always loaded (Blizzard_FrameXML.toc 16).
Adapter.POPUPS = {
    { frame = "GuildInviteFrame", first = "GuildInviteFrameJoinButton", second = "GuildInviteFrameDeclineButton", words = "the guild invite" },
    { frame = "PVPReadyDialog", first = "PVPReadyDialogEnterBattleButton", second = "PVPReadyDialogLeaveQueueButton", words = "the battleground dialog" },
}

-- The two buttons of the first listed window that is shown, and its row, or nil.
function Adapter.ShownPopup()
    for _, popup in ipairs(Adapter.POPUPS) do
        local frame = _G[popup.frame]
        if frame and frame:IsShown() then
            local first, second = _G[popup.first], _G[popup.second]
            return first and first:IsShown() and first or nil, second and second:IsShown() and second or nil, popup
        end
    end
end

-- Tells fn when one of the listed windows shows or hides. A hook after Blizzard's own script:
-- nothing of Blizzard's is replaced or written.
function Adapter.OnPopupShownOrHidden(fn)
    for _, popup in ipairs(Adapter.POPUPS) do
        local frame = _G[popup.frame]
        if frame and frame.HookScript then
            frame:HookScript("OnShow", fn)
            frame:HookScript("OnHide", fn)
        end
    end
end
