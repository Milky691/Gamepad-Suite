-- The adapter, the part for two small features: the bind Minimap Zoom (Auto/MinimapZoom.lua) and the
-- hearthstone pip of the info bar (Screen/InfoBar.lua).
local _, ns = ...

local Adapter = ns.Adapter
local results = Adapter.Results

-- ---------------------------------------------------------------- Minimap Zoom
-- The minimap counts its zoom steps. They run from 0 (all the way out) to the count less one (all the
-- way in): the game's own zoom buttons clamp to exactly that (Blizzard_Minimap/Mainline/Minimap.lua
-- 280 to 283 and 305 to 307). The notes of the game mark none of the three calls as restricted or
-- secret (Blizzard_APIDocumentationGenerated/MinimapFrameAPIDocumentation.lua 23 to 47, 301 to 311).
-- Minimap_ZoomIn and Minimap_ZoomOut are what the game's own binds for the zoom call
-- (Blizzard_FrameXML/Bindings_Camelot.xml 1296 to 1301; Minimap.lua 323 to 329).
Adapter.Check("minimapZoom", function()
    return Minimap and Minimap.GetZoom and Minimap.SetZoom and Minimap.GetZoomLevels
        and type(Minimap_ZoomIn) == "function" and type(Minimap_ZoomOut) == "function"
end)

-- The zoom now and how many steps there are. nil when the game does not answer.
function Adapter.MinimapZoom()
    local ok, zoom, levels = pcall(function()
        return Minimap:GetZoom(), Minimap:GetZoomLevels()
    end)
    if ok and type(zoom) == "number" and type(levels) == "number" then
        return zoom, levels
    end
    return nil
end

-- Sets the zoom to a step. The game's two + and - buttons keep their own idea of which one can still
-- be pressed, and only a click on them updates it. So the zoom jumps to one step short of the aim, and
-- the game's own click makes the last step: its sound plays one time, and its buttons stay right for
-- the game's own binds. If the click did not get there, the zoom is set to the step itself.
-- True when it ran; when it did not, the second value is what the game said.
function Adapter.SetMinimapZoom(step)
    local ok, err = pcall(function()
        local zoom = Minimap:GetZoom()
        if step == zoom then
            return
        end
        local up = step > zoom
        Minimap:SetZoom(up and step - 1 or step + 1)
        if up then
            Minimap_ZoomIn()
        else
            Minimap_ZoomOut()
        end
        if Minimap:GetZoom() ~= step then
            Minimap:SetZoom(step)
        end
    end)
    return ok, not ok and tostring(err) or nil
end

-- ---------------------------------------------------------------- Hearthstone pip
-- The game's own call names the hearth item that the player has (ContainerDocumentation.lua 430 to 438);
-- where it names none, the Hearthstone (item 6948, the same on every Classic client) counts when it is in
-- the bags. The cooldown of an item is asked by its number: the call may return nothing
-- (ContainerDocumentation.lua 336 to 352), and the game says when an item's cooldown starts or the
-- bags change with BAG_UPDATE_COOLDOWN and BAG_UPDATE_DELAYED (ContainerDocumentation.lua 668 to 678;
-- the game's own bags redraw their cooldowns on the first, ContainerFrame.lua 609). That an item's cooldown
-- numbers are given in a fight is not in the notes; they are checked the way Adapter.Cooling does.
Adapter.Check("hearth", function()
    return C_Container and C_Container.GetItemCooldown and C_Item and C_Item.GetItemCount
        and C_Item.GetItemInfoInstant ~= nil
end)

local HEARTHSTONE = 6948
-- the picture of the Hearthstone, for a game that does not give the item's own
local STONE = "Interface\\Icons\\INV_Misc_Rune_01"
-- The short cooldown that every cast starts also shows on items: it is no cooldown of the stone
-- (as in Adapter.Cooling, AdapterHud.lua: 3 s, as a wand's shot puts a little more than 2 s on items).
local SHARED = 3

local fault

local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- The hearth item that the player has, its picture, if it cools down, and when that ends (the game's
-- clock). nil when there is no hearth item. cooling is nil when the game does not tell: in a fight it
-- can hide the numbers, and then no compare is made with them.
function Adapter.Hearth()
    if not results().hearth then
        return nil
    end
    local ok, item, icon, cooling, ends = pcall(function()
        local item = C_Container.PlayerHasHearthstone and C_Container.PlayerHasHearthstone()
        if type(item) ~= "number" then
            item = C_Item.GetItemCount(HEARTHSTONE) > 0 and HEARTHSTONE or nil
        end
        if not item then
            return nil
        end
        local _, _, _, _, icon = C_Item.GetItemInfoInstant(item)
        local start, duration = C_Container.GetItemCooldown(item)
        if start == nil or hidden(start) or hidden(duration) then
            return item, icon or STONE, nil
        end
        return item, icon or STONE, duration > SHARED and start + duration > GetTime(), start + duration
    end)
    if ok then
        return item, icon, cooling, ends
    end
    -- one line for one kind of fault: a read comes with every word of the game on a cooldown
    if fault ~= tostring(item) then
        fault = tostring(item)
        ns.Log.Add("hearth", "the hearth could not be read: " .. fault)
    end
    return nil
end
