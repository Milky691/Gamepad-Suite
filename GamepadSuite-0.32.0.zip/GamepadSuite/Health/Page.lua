-- Health Check: a report of what this game build has, and its page in the settings window.
-- The report is in the saved file after a reload: WTF\Account\<name>\SavedVariables\GamepadSuite.lua
-- The bind core writes its own proof lines in the log (Core/BindCore.lua), so this page asks the
-- player for no test.
local _, ns = ...

local Adapter, Registry, Widgets = ns.Adapter, ns.Registry, ns.Widgets

local Health = ns.Module("Health", {}, "Health Check")
ns.Health = Health

local store, page

function Health.Report()
    local version, build, interface = Adapter.Build()
    local checks, modules = {}, {}
    for name, ok in pairs(Adapter.Results()) do
        checks[name] = ok
    end
    -- by the name the player knows a feature by; a feature with a part that is off reads off
    for name, module in pairs(ns.modules) do
        if not module.on then
            modules[module.label] = "off, missing " .. tostring(module.missing) .. " (" .. name .. ")"
        end
        modules[module.label] = modules[module.label] or "on"
    end
    local settings = Adapter.ConsoleSettings({ "pad", "camera", "softtarget", "autodismount", "autostand", "autounshift", "actionbutton", "interact" })
    local count = 0
    for _ in pairs(settings) do
        count = count + 1
    end
    store.report = {
        when = date("%Y-%m-%d %H:%M:%S"), addon = Adapter.Version(), game = version, build = build, interface = interface,
        device = Adapter.DeviceInfo(), picture = Widgets.PadStyle(), checks = checks, modules = modules,
        uiScale = select(3, Adapter.PointerSpace()),
        gameplayHasPad = Adapter.GameplayHasPad(), errors = ns.Log.ErrorCount(),
        settingCount = count, settings = settings,
    }
    Health.RefreshValues()
    ns.Print("Report saved: " .. count .. " game settings. Run Reload, the row under it, or type /reload, so the game writes the file.")
end

function Health.RefreshValues()
    if page then
        page.rows[1].value = store.report and ("Saved, " .. store.report.settingCount .. " settings") or "Not yet"
    end
end

function Health.OnLogin()
    store = Registry.Store("health")
    Health.store = store
    local file = "WTF, Account, SavedVariables, GamepadSuite.lua"
    page = {
        title = "Health Check",
        line = "A report of what this game build has.",
        rows = {
            {
                key = "health.report", name = "Save a Report", kind = "run", action = "Save", built = true, run = Health.Report,
                sum = "Writes what this game build has to the saved file.",
                text = "This lists the controller the game sees, every hidden controller and camera setting, and which of the addon's checks passed. Nothing is sent anywhere. It goes into the addon's saved file.",
                steps = { { keys = { "A" }, text = "Press A" }, { keys = {}, text = "Then run Reload, below" } },
                facts = { { "File", file } },
            },
            {
                key = "health.reload", name = "Reload", kind = "run", action = "Reload", built = true, value = "",
                run = Adapter.Reload,
                sum = "Reloads the game screen so the saved file is written.",
                text = "The game writes an addon's saved file only when the screen reloads or you log out. Run this after the report. If nothing happens, type /reload in chat.",
                steps = { { keys = { "A" }, text = "Press A" } },
                facts = { { "Takes", "a few seconds" } },
            },
            ns.SettingsBack,
        },
    }
    for _, chapter in ipairs(ns.SettingsData) do
        for _, row in ipairs(chapter.rows) do
            if row.key == "system.health_check" then
                row.sub = page
            end
        end
    end
    Health.RefreshValues()
end
