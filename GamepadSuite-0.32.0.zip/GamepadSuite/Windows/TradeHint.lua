-- Trade Hold: while a trade is open and the trade window or the bag window has the controller, a
-- hint stands over the trade window's top right corner (Windows/ListLook.lua: the place of a hold):
-- the picture of Y and "Hold, let go, press once more to trade with Bob". Y held for one second
-- fills the gold line under the hint (the bar of every hold); let go, then press Y once more: that
-- press accepts the trade, as the game's Trade button does. A let-go before the line is full does
-- nothing, and the press once more counts only within five seconds of the let-go. The words follow
-- the trade: "Waiting for Bob" after the player's accept (dim: Y does nothing then), "Bob accepted.
-- Hold, let go, press once more to trade" when Bob accepted first, and "The offer changed. Look,
-- then hold, let go, press once more" when the offer changed after an accept. With no name (or a
-- hidden one) the words say "the other player" or name nobody. Not in combat, not while the
-- settings window, the on-screen keyboard or a wheel is open, nor in Mouse Mode (Look.Free).
-- Core/AdapterTrade.lua has the game's facts, with file and line.
--
-- Why three steps (Screen/Destroy.lua 10 to 16): the Trade button's click is the global AcceptTrade
-- (Blizzard_UIPanels_Game/Mainline/TradeFrame.xml 422), which has no entry in the game's notes; the
-- one addon seen to call it does so inside a mouse press (Core/AdapterTrade.lua). A hold is full
-- in the hint's frame script, which is no press, and no source says that a let-go counts as one.
-- So the hold only makes the hint ready, and AcceptTrade is called at a key's press DOWN on our
-- button and nowhere else: safe with no proof. Should the game refuse it (ADDON_ACTION_FORBIDDEN or
-- ADDON_ACTION_BLOCKED with this addon's name and the call), the hint is off for the session and one
-- chat line says so.
--
-- Why Y: the trade window gives Y no job (Core/AdapterTrade.lua). In the bag window Y opens the
-- game's menu "More actions" on an item (Blizzard_UIPanels_Game/Mainline/ContainerFrame.lua 3431 to
-- 3444; its conditions, 3115 to 3133, are not stopped by a trade, only by a vendor, 3066 to 3068)
-- and "Manage bag" on a bag's picture (3350 to 3355). Mail Attach keeps that menu for every item
-- its Y does not act on, as its Y acts on one stack. The trade's act is one for the whole window,
-- and the player's hands are in the bags while trading: so Y is ours in the whole bag window while
-- a trade is open and the hold could accept, and the game's again the moment it closes. Of that
-- menu, split and destroy are on Menu (Windows/ItemActions.lua); while that menu is open (message
-- "items:menu") Y is its own, and the hint is dim. Y is a key bind of a plain button of ours
-- (Look.Key): no frame of ours hears the controller. It is taken only while the hold could accept
-- (the game's Trade button is on: off after the player's accept, with more money typed than the
-- player has, or while the game asks about a bind enchant), and given back otherwise.
--
-- Nothing runs while nothing happens: the line is drawn each frame only between Y down and the
-- full line; one timer waits the five seconds of the press once more. The hint and the key change
-- one frame after the game's word (C_Timer.After(0)), never inside a press, and the key not between
-- Y down and Y up (Look.Key). The log (kind "trade") says once if Y was set, and at the end of the
-- first trade in which our call was made: what the game answered, and if it asked to confirm.
local ADDON, ns = ...

local Trade = ns.Module("TradeHint", { "tradeHint" }, "Trade Hold")
ns.TradeHint = Trade

local Model, Look = ns.WindowsModel, ns.ListLook

local KEY, ROW = "Y", "windows.trade_hold"
local PRESS_WITHIN = 5  -- seconds after a full hold's let-go in which the press once more accepts
local MAX_NOTES = 10    -- lines for the log in one session
local STEPS = "hold, let go, press once more"
local REFUSED = "Trade Hold is off for this session: the game did not let Gamepad Suite accept the trade. Use the Trade button."

local hint, frame, keys
-- the open trade, or nil: mine and theirs (the accepts now), seen (an accept was on in it), changed
-- (the offer changed after an accept; the player's next accept ends it), and for the log calls (our
-- AcceptTrade calls), after (playerAccepted at the game's first answer after one), confirm (the game
-- asked to confirm), reads (what Y read when it was taken)
local trade
local held, full        -- when the hold that runs now began, and if its line is full
local armed = 0         -- 0, or the number of the full hold whose let-go waits for the press once more
local holds = 0         -- counts the full holds, so that a timer knows if its hold is still the newest
local dead = false      -- the game refused AcceptTrade: no hint again in this session
local itemMenu = false  -- the item menu of Item Actions is open (message "items:menu")
local due = false       -- a look is due at the next frame
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("trade", text)
    end
end

-- (a row that is not in Settings/Data.lua yet has its start value, On)
local function wanted()
    return not ns.Registry.Has(ROW) or ns.Registry.Get(ROW) ~= false
end

-- True while the hint has its place: a trade is open, its window or the bags have the controller,
-- nothing of the suite has it, and no fight is on.
local function can()
    return trade ~= nil and not dead and wanted() and ns.Adapter.TradeHasPad() and Look.Free()
end

-- True when a press of Y could act now: the hint has its place, the game's Trade button is on, and
-- the item menu of Item Actions is shut.
local function ready()
    return can() and not itemMenu and ns.Adapter.TradeButtonOn()
end

-- The words for the trade as it is now. name: the other player's, or nil.
local function words(name)
    if trade.mine then
        return "Waiting for " .. (name or "the other player")
    elseif full then
        return "Let go, then press once more to trade"
    elseif armed > 0 then
        return "Press once more to trade" .. (name and " with " .. name or "")
    elseif trade.changed then
        return "The offer changed. Look, then " .. STEPS
    elseif trade.theirs then
        return (name or "The other player") .. " accepted. Hold, let go, press once more to trade"
    end
    return "Hold, let go, press once more to trade" .. (name and " with " .. name or "")
end

local function draw()
    if trade and frame:IsShown() then
        hint.label:SetText(words(ns.Adapter.TradePartner()))
        frame:SetAlpha(ready() and 1 or 0.4)
        hint.Fit()
    end
end

local later

-- ---------------------------------------------------------------- the hold
-- The hold is over, full or not: the gold line goes, and nothing is drawn each frame any more.
local function rest()
    held, full = nil, false
    if frame then
        hint.line:SetPart(0)
        frame:SetScript("OnUpdate", nil)
    end
end

-- Each frame between Y down and the full line: the line grows. Full, it stays so until the let-go,
-- and nothing more is drawn each frame.
local function grow()
    local part, done = Model.HoldPart(held, GetTime())
    if done then
        full = true
        frame:SetScript("OnUpdate", nil)
        -- (the new words first: the line is as wide as the hint they make)
        draw()
    end
    hint.line:SetPart(part)
end

-- (a fault here would come every frame: it is logged once, and the hold stops)
local function tick()
    if not ns.Call("TradeHint", grow) then
        rest()
    end
end

-- The press once more: the trade is accepted, inside the press down of Y.
local function accept()
    armed = 0
    if ns.Adapter.AcceptTrade() then
        trade.calls = trade.calls + 1
    else
        note("AcceptTrade could not be called at a key-down", "failed")
    end
end

-- Y went down or up on the key of ours. A let-go ends a hold and does nothing more; after a full
-- hold it makes the next press down the one that accepts.
local function press(down)
    if not down then
        if full then
            holds = holds + 1
            armed = holds
            local mine = holds
            C_Timer.After(PRESS_WITHIN, function()
                if armed == mine then
                    armed = 0
                    later()
                end
            end)
        end
        if held then
            rest()
        end
        draw()
        return
    elseif not ready() then
        return
    elseif armed > 0 then
        accept()
        draw()
        return
    end
    note("Y went down on the hint: a hold began", "seen")
    held, full = GetTime(), false
    hint.line:SetPart(0.001)
    frame:SetScript("OnUpdate", tick)
end

-- ---------------------------------------------------------------- the trade
local function fresh()
    return { mine = false, theirs = false, seen = false, changed = false, calls = 0 }
end

-- One frame after the game's word: the hint shows while it has its place, and Y is ours while a
-- press could act. Not inside a press.
local function look()
    if not frame then
        return
    end
    if ns.Adapter.TradeWindow() then
        -- (a reload with a trade open: the trade is known from its window)
        trade = trade or fresh()
    end
    local shown = can()
    if not shown then
        rest()
        armed = 0
    elseif not frame:IsShown() then
        hint.Place(ns.Adapter.TradeWindow())
        note("the trade window opened and the bags or the trade window have the controller: the hint shows", "shown")
    end
    frame:SetShown(shown)
    draw()
    local want = shown and ready()
    keys.Set(want)
    if want then
        trade.reads = (trade.reads == "set" or keys.Ours()) and "set" or "not set"
    end
end

-- The game said that something changed, maybe inside a press: one look, at the next frame.
function later()
    if not due then
        due = true
        C_Timer.After(0, function()
            due = false
            ns.Call("TradeHint", look)
        end)
    end
end

-- The game's word on the accepts (numbers, 1 for an accept that is on).
local function accepted(player, target)
    if trade then
        trade.mine, trade.theirs = player == 1, target == 1
        trade.seen = trade.seen or trade.mine or trade.theirs
        trade.changed = trade.changed and not trade.mine
        if trade.calls > 0 and trade.after == nil then
            trade.after = player
        end
    end
    later()
end

-- An item or the money of either side changed. A hold that runs, or a full one that waits for the
-- press once more, is over: that press must not accept an offer the player has not seen. After an
-- accept (the game then clears both) the words say that the offer changed.
local function changed()
    if trade then
        trade.changed = trade.changed or trade.seen
        armed = 0
        rest()
    end
    later()
end

-- The trade closed: it went through or was cancelled. The first trade with a call of ours in this
-- session writes what came of it.
local function closed()
    if trade and trade.calls > 0 then
        note("the trade window opened; Y reads " .. tostring(trade.reads) .. "; AcceptTrade called at a key-down: playerAccepted "
            .. tostring(trade.after or "none") .. " after; the game asked to confirm: " .. (trade.confirm and "yes" or "no")
            .. "; closed by TRADE_CLOSED", "proof")
    end
    trade, armed = nil, 0
    rest()
    later()
end

-- The game refused an action of an addon: when it is our AcceptTrade, the hint is off for the session.
local function blocked(addon, call)
    if addon == ADDON and not dead and tostring(call):find("AcceptTrade", 1, true) then
        dead = true
        note("the game refused AcceptTrade (" .. tostring(call) .. "): the hint is off for this session")
        ns.Print(REFUSED)
        later()
    end
end

-- The hint, hidden, and the key of ours that Y clicks.
local function build()
    hint = Look.Hint("GamepadSuiteTradeHint", KEY, true)
    frame = hint.frame
    keys = Look.Key("TradeHint", "GamepadSuiteTradeHintKey", KEY, press, note)
    later()
end

function Trade.OnLogin()
    -- the key's button is made out of combat (Look.Key): after a reload in combat it is made when combat ends
    ns.Queue.Run("TradeHint", build)
    ns.On("TRADE_SHOW", "TradeHint", function()
        trade, armed = fresh(), 0
        rest()
        later()
    end)
    ns.On("TRADE_CLOSED", "TradeHint", closed)
    ns.On("TRADE_ACCEPT_UPDATE", "TradeHint", accepted)
    for _, event in ipairs({ "TRADE_PLAYER_ITEM_CHANGED", "TRADE_TARGET_ITEM_CHANGED", "TRADE_MONEY_CHANGED" }) do
        ns.On(event, "TradeHint", changed)
    end
    -- the game's own window that asks to confirm a trade (Core/AdapterTrade.lua): A and B there are the game's
    ns.On("SECURE_TRANSFER_CONFIRM_TRADE_ACCEPT", "TradeHint", function()
        if trade and trade.calls > 0 then
            trade.confirm = true
        end
    end)
    ns.On("ADDON_ACTION_FORBIDDEN", "TradeHint", blocked)
    ns.On("ADDON_ACTION_BLOCKED", "TradeHint", blocked)
    -- combat starts: the hold ends and the hint goes at once; Look.Key gives Y back
    ns.On("PLAYER_REGEN_DISABLED", "TradeHint", function()
        armed = 0
        rest()
        if frame then
            frame:Hide()
        end
    end)
    ns.On("PLAYER_REGEN_ENABLED", "TradeHint", later)
    -- a window took the controller or gave it back, the settings window opened or closed, Mouse
    -- Mode, a wheel or the on-screen keyboard came or went
    Look.Watch("TradeHint", later)
    -- the item menu of Item Actions opened or closed: Y is its own while it is open
    ns.Listen("items:menu", "TradeHint", function(open)
        itemMenu = open and true or false
        later()
    end)
    ns.Listen("setting", "TradeHint", function(key)
        if key == ROW then
            later()
        end
    end)
end
