-- Bank, deposit trade goods: while the bank window has the controller, a hint stands over its
-- bottom left corner (Windows/ListLook.lua, decision 112): the picture of X and "Hold to
-- deposit". It shows only with a trade good in the bags; when none of them fits the bank it is
-- dim and reads "Bank full".
-- X held for one second moves every stack of trade goods from the bags into the character's bank,
-- one after the other, each when the game has answered for the one before: onto stacks of the
-- same item that have room, else into an empty place, also of a bag of a profession in the bank
-- (a herb bag) whose family the item shares. A gold line under the hint (the bar of every hold)
-- fills while X is held; let go before it is full and nothing moves. Then the hint counts
-- ("Moving 2 of 5"). The run ends when no trade good is left, when the bank takes no more, when
-- the game gives no answer for three seconds, when a fight starts and when the bank closes. A
-- thing that a quest needs stays in the bags.
-- The game picks the place in the bank (Core/AdapterBank.lua): a stack is asked for only when a
-- place it fits is free, and the first run of a session writes to the log what the bags of a
-- profession took ("family bags in the bank: 1; stacks that fit one: 3; moved into them: 3").
--
-- The bank window gives X no job with the controller (Core/AdapterBank.lua), so the hold is on X.
-- X is a key bind of a button of ours (Windows/ListLook.lua Look.Key): its press and its let-go
-- are the hold. It is ours only while a hold could move a stack, and given back otherwise: no
-- frame of ours hears the controller, and every other button is the game's. The hint shows only
-- while the bank window has the controller, not while the settings window, the on-screen
-- keyboard or a wheel is open, in Mouse Mode or in a fight. The hint and the key change one frame
-- after the game's word, never inside a press, and the key not between X down and X up.
--
-- Nothing runs while nothing happens: the line is drawn each frame between X down and X up
-- only, and the bags are read when the game says that they changed, while the bank is open.
-- That the bank takes a stack from addon code with no press is not proved in the game: the log
-- (kind "bank") says what the bags held, what was asked for, how many moved and why any stayed.
local _, ns = ...

local BankDeposit = ns.Module("BankDeposit", { "bankDeposit" }, "Deposit Trade Goods")
ns.BankDeposit = BankDeposit

local Goods, Model, Look = ns.GoodsModel, ns.WindowsModel, ns.ListLook

local KEY, ROW = "X", "windows.bank_deposit"
local MAX_NOTES = 20    -- lines for the log in one session

local hint, frame, keys
local open = false      -- the bank window shows
local things, bank = {}, { free = 0, room = {}, bags = {} }
local held              -- when the hold that runs now began
-- nil, or the run: { total, moved, asked (the stack asked for last), only (only a bag of a profession had room
-- for it), bags and fit (the bags of a profession in the bank, and the stacks that fit one, at the start), into }
local run
local due = false       -- a look is due at the next frame
local notes, told = 0, {}

-- (the first run's line on the bags of a profession is written past the cap: once per session)
local function note(text, once)
    if (notes < MAX_NOTES or once == "family") and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("bank", text)
    end
end

-- True while the hint has its place and X can be ours: the bank window has the controller,
-- nothing of the suite has it, and no fight is on.
local function can()
    return open and ns.Registry.Get(ROW) and ns.Adapter.WindowHasPad(ns.Adapter.BankWindow()) and Look.Free()
end

-- True when a hold would move a stack now.
local function ready()
    return not run and Goods.Next(things, bank) ~= nil
end

-- What the hint says now, and if it is bright; nil when there is nothing to say: no trade good is
-- in the bags.
local function words()
    if run then
        return "Moving " .. math.min(run.moved + 1, run.total) .. " of " .. run.total, true
    end
    local thing, why = Goods.Next(things, bank)
    if thing then
        return "Hold to deposit", true
    elseif why == "full" then
        return "Bank full", false
    end
end

local refresh, step, later

-- ---------------------------------------------------------------- the hold
-- The hold is over, full or not: the gold line goes, and nothing is drawn each frame any more.
local function rest()
    held = nil
    hint.line:SetPart(0)
    frame:SetScript("OnUpdate", nil)
end

-- Each frame between X down and X up: the gold line grows. When it is full the run begins, if
-- the bank window still has the controller.
local function grow()
    local part, full = Model.HoldPart(held, GetTime())
    if not full then
        hint.line:SetPart(part)
        return
    end
    rest()
    if can() and ready() then
        run = { total = Goods.Count(things), moved = 0, into = 0, bags = #bank.bags, fit = Goods.FitFamily(things, bank) }
        note("the hold was full: " .. run.total .. " stacks to move, the bank has " .. bank.free .. " empty places")
        step()
    end
end

-- (a fault here would come every frame: it is logged once, and the hold stops)
local function tick()
    if not ns.Call("BankDeposit", grow) then
        rest()
    end
end

-- X went down or up on the key of ours.
local function press(down)
    if not down then
        if held then
            rest()
        end
    elseif not held and can() and ready() then
        note("X was seen on the hint: a hold began", "seen")
        held = GetTime()
        hint.line:SetPart(0.001)
        frame:SetScript("OnUpdate", tick)
    end
end

-- ---------------------------------------------------------------- the run
local function finish(why)
    note("moved " .. run.moved .. " of " .. run.total .. " stacks of trade goods; " .. Goods.Count(things) .. " stayed: " .. why)
    note("family bags in the bank: " .. run.bags .. "; stacks that fit one: " .. run.fit .. "; moved into them: " .. run.into, "family")
    run = nil
end

-- One step of a run, after the game's word that the bags changed: the stack asked for has left
-- its place, so the bank took it, and the next one is asked for. An ask alone says nothing: the
-- game may give no answer. Three seconds after an ask that is still the one waited for, the run
-- ends, and the player can hold again.
local function advance()
    if run.asked then
        if not Goods.Moved(things, run.asked) then
            return
        end
        run.moved, run.asked = run.moved + 1, nil
        run.into = run.into + (run.only and 1 or 0)
    end
    local thing, why = Goods.Next(things, bank)
    if not thing then
        finish(why == "full" and "the bank takes no more" or "nothing is left")
    elseif ns.fightStarted or ns.Adapter.InCombat() then
        finish("a fight started")
    elseif ns.Adapter.BankDeposit(thing) then
        run.asked, run.only = thing, why == "family"
        note("asked the bank for " .. thing.name .. " x" .. thing.count, "asked")
        local mine = run
        C_Timer.After(Model.ANSWER, function()
            if run == mine and run.asked == thing then
                ns.Call("BankDeposit", function()
                    finish("the game gave no answer for " .. thing.name .. " in " .. Model.ANSWER .. " seconds")
                    refresh()
                end)
            end
        end)
    else
        finish("the call for " .. thing.name .. " could not be made")
    end
end

-- ---------------------------------------------------------------- the bank
-- Shows the hint or not by who has the controller now, and X is ours while a hold could move a
-- stack. Not inside a press.
function refresh()
    local text, bright = words()
    local shown = can() and text ~= nil
    if not shown then
        rest()
    end
    frame:SetShown(shown)
    if text then
        hint.label:SetText(text)
        frame:SetAlpha(bright and 1 or 0.4)
        hint.Fit()
    end
    keys.Set(shown and ready())
end

-- Reads the bags and the bank, makes the next step of a run, and sets the hint.
function step()
    things, bank = ns.Adapter.BagItems(), ns.Adapter.BankRoom()
    if run then
        advance()
    end
    refresh()
end

-- One frame after the game's word: the bank window shows or not, and what the bags hold now.
local function look()
    local window = ns.Adapter.BankWindow()
    if not frame then
        return
    elseif window and not open then
        open, run = true, nil
        hint.Place(window)
        ns.On("BAG_UPDATE_DELAYED", "BankDeposit", later)
        step()
        note("the bank opened: " .. Goods.Count(things) .. " stacks of trade goods in the bags, " .. bank.free
            .. " empty places in the bank; the hint shows: " .. tostring(frame:IsShown()))
    elseif open and not window then
        open = false
        ns.Off("BAG_UPDATE_DELAYED", "BankDeposit")
        if run then
            finish(run.asked and "the bank closed before the game answered for " .. run.asked.name or "the bank closed")
        end
        rest()
        frame:Hide()
        keys.Set(false)
    elseif open then
        step()
    end
end

-- The game said that something changed. It can say so several times in one frame, and inside a
-- press: one look is made, at the next frame.
function later()
    if not due then
        due = true
        C_Timer.After(0, function()
            due = false
            ns.Call("BankDeposit", look)
        end)
    end
end

-- The hint, hidden, and the key of ours that X clicks.
local function build()
    hint = Look.Hint("GamepadSuiteBankDeposit", KEY, true)
    hint.inside = true
    frame = hint.frame
    keys = Look.Key("BankDeposit", "GamepadSuiteBankDepositKey", KEY, press, note)
    later()
end

function BankDeposit.OnLogin()
    -- the key's button is made out of a fight (Look.Key): after a reload in one it is made when
    -- the fight ends
    ns.Queue.Run("BankDeposit", build)
    ns.Adapter.OnBankWindow(later)
    -- a fight starts: the run ends and the hint goes at once; Look.Key gives X back
    ns.On("PLAYER_REGEN_DISABLED", "BankDeposit", function()
        if run then
            finish("a fight started")
        end
        if frame then
            rest()
            frame:Hide()
        end
    end)
    ns.On("PLAYER_REGEN_ENABLED", "BankDeposit", later)
    -- a window took the controller or gave it back, the settings window opened or closed, Mouse
    -- Mode, a wheel or the on-screen keyboard came or went
    Look.Watch("BankDeposit", later)
    ns.Listen("setting", "BankDeposit", function(key)
        if key == ROW then
            later()
        end
    end)
end
