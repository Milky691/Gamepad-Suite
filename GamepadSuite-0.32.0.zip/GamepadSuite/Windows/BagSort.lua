-- Sort Bags: while the game's bag window has the controller, a hint stands over its top left
-- corner (Windows/ListLook.lua: the place of a tap): the picture of L3 and "Sort bags". L3 sorts the bags at the press, with the game's own
-- sort (the Clean Up Bags of the bag's menu) and its sound. Not in a fight, and not while the
-- pointer holds an item (the game's own menu does not offer it then). L3 with LB, RB, LT or RT
-- held sorts nothing, so L3 with a shoulder stays free for other jobs.
--
-- L3 has no job in the bag window, A, B, X, Y, LT, RT and R3 have (Core/AdapterBags.lua). L3 is a
-- key bind of a button of ours (Windows/ListLook.lua Look.Key), taken while the hint shows and
-- given back otherwise: no frame of ours hears the controller, and every other button is the
-- game's. The hint and the key are there only while the bag window has the controller, and not
-- while the settings window, the on-screen keyboard or a wheel is open, in Mouse Mode, in a fight,
-- or with the mouse interface (no window takes the controller there). They show or go one frame
-- after the game's word, never inside a press. The hints of a letter and of junk
-- (Windows/MailAttach.lua, JunkMark.lua) stand in a row after it.
--
-- Nothing runs while nothing happens. After a sort, and only then, the game's word that the
-- bags changed is heard once, for the log (kind "bags"): it is the proof that the game sorted.
local _, ns = ...

local BagSort = ns.Module("BagSort", { "bagSort" }, "Sort Bags")
ns.BagSort = BagSort

local Look = ns.ListLook

local KEY = "LS"
local HELD = { "LB", "RB", "LT", "RT" }   -- with one of these held, L3 sorts nothing
local MAX_NOTES = 10    -- lines for the log in one session

local hint, frame, keys
local due = false       -- a look is due at the next frame
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("bags", text)
    end
end

-- True while L3 can be ours: the bag window has the controller, nothing of the suite has it,
-- and no fight is on.
local function can()
    return ns.Adapter.WindowHasPad(ns.Adapter.SortBagsWindow()) and Look.Free()
end

-- L3 went down (down true) or up on the key of ours. The sort is at the press.
local function press(down)
    if not (down and can()) then
        return
    end
    for _, key in ipairs(HELD) do
        if ns.Adapter.ButtonDown(key) then
            note("L3 with a shoulder or a trigger held: no sort", "held")
            return
        end
    end
    if ns.Adapter.PointerHoldsItem() then
        note("L3 while the pointer holds an item: no sort", "pointer")
        return
    end
    local asked, why = ns.Adapter.SortBags()
    if not asked then
        note("L3: the sort could not be asked for: " .. why)
        return
    end
    note("L3 asked the game to sort the bags", "asked")
    ns.On("BAG_UPDATE_DELAYED", "BagSort", function()
        ns.Off("BAG_UPDATE_DELAYED", "BagSort")
        note("the bags changed after the sort", "changed")
    end)
end

-- One frame after the game's word: the hint shows, and L3 is ours, while L3 can sort.
local function look()
    if not frame then
        return
    end
    local shown = can()
    if shown and not frame:IsShown() then
        hint.Place(ns.Adapter.SortBagsWindow())
        note("the bag window has the controller: the hint shows", "shown")
    elseif not shown then
        ns.Off("BAG_UPDATE_DELAYED", "BagSort")
    end
    frame:SetShown(shown)
    keys.Set(shown)
end

-- The game said that something changed, maybe inside a press: one look, at the next frame.
local function later()
    if not due then
        due = true
        C_Timer.After(0, function()
            due = false
            ns.Call("BagSort", look)
        end)
    end
end

-- The hint, hidden, and the key of ours that L3 clicks.
local function build()
    hint = Look.Hint("GamepadSuiteBagSort", KEY)
    hint.label:SetText("Sort bags")
    hint.Fit()
    frame = hint.frame
    keys = Look.Key("BagSort", "GamepadSuiteBagSortKey", KEY, press, note)
    later()
end

function BagSort.OnLogin()
    -- the key's button is made out of a fight (Look.Key): after a reload in one it is made when
    -- the fight ends
    ns.Queue.Run("BagSort", build)
    ns.Adapter.OnSortBagsWindow(later)
    -- a fight starts: the hint goes at once, and L3 is the game's (Look.Key gives it back)
    ns.On("PLAYER_REGEN_DISABLED", "BagSort", function()
        ns.Off("BAG_UPDATE_DELAYED", "BagSort")
        if frame then
            frame:Hide()
        end
    end)
    ns.On("PLAYER_REGEN_ENABLED", "BagSort", later)
    -- a window took the controller or gave it back, the settings window opened or closed, Mouse
    -- Mode, a wheel or the on-screen keyboard came or went
    Look.Watch("BagSort", later)
end
