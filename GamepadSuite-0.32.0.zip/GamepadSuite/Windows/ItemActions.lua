-- Item Actions: while the game's bag window has the controller and its focus is on an item, a hint stands over the
-- window's top left corner with the hints of a tap (Windows/ListLook.lua): the picture of Menu and "Item actions".
-- Menu opens our own small list for that item, beside it: Equip to (one entry for each place it can be worn in: Ring 1
-- and Ring 2, Trinket 1 and Trinket 2, Main Hand and Off Hand with dual wield), Put on a Wheel (an item with a use: one
-- of the player's own wheels, then one of its eight slots), Split (the count with the D-pad, into the first free bag
-- slot), Sell (at a vendor) and Destroy (hold A one second, let go, press A again). Windows/ItemActionsModel.lua says
-- which entries an item gets; Windows/ItemActionsDraw.lua draws the list.
--
-- Why Menu: the bag window gives Menu no job (Blizzard_UIPanels_Game/Mainline/ContainerFrame.lua 3346 to 3471 binds
-- A, X, Y, B, View, LB and RB; Blizzard_GamepadSharedUtility/FrameControlsManager.lua 206 to 213 LT, RT, R3 and the
-- D-pad and face buttons), so it falls through to the player's bind (Main Menu at first, Core/Binds.lua 152). The
-- game's own More Actions menu (Y) is made with no tag, so no addon can add to it: this menu is our own.
--
-- Menu is a key bind of a plain button of ours (Look.Key), taken only while the bag window has the controller, no
-- game menu stands over it, the focus is on an item that is not locked, nothing of the suite has the controller and
-- no fight is on. While the menu is open the D-pad, A, B, X and Y are ours the same way (X and Y do nothing), and Menu
-- closes it. No frame of ours hears the controller. Keys change one frame after the game's word, never inside a press
-- nor between a press and its let-go, and go back at once when a fight starts. The menu closes when the game's focus
-- or the item changes, the bag window loses the controller, a fight starts, or the suite takes the controller.
-- Destroy runs only at the press down of A that follows a full hold, inside that press: the game takes its destroy
-- calls only inside a press of the player (Core/AdapterItemActions.lua).
--
-- Nothing runs while nothing happens: the bar of the hold is drawn each frame only between A down and the full hold;
-- the game's words for the bags, the vendor and the worn gear are heard only while the hint shows. The log (kind
-- "items") says once if Menu is ours, that the menu opened, and what the game did after each kind of action.
local _, ns = ...

local Items = ns.Module("ItemActions", { "itemActions" }, "Item Actions")
ns.ItemActions = Items

local Model, Draw, Look = ns.ItemActionsModel, ns.ItemActionsDraw, ns.ListLook

local NAV = { "A", "B", "X", "Y", "DU", "DD", "DL", "DR" }
local ALL = { "MN", "A", "B", "X", "Y", "DU", "DD", "DL", "DR" }
local HEARD = { "BAG_UPDATE_DELAYED", "MERCHANT_SHOW", "MERCHANT_CLOSED", "PLAYER_EQUIPMENT_CHANGED", "CURSOR_CHANGED" }
local MAX_NOTES = 16

local hint, keys            -- the hint (Look.Hint); our key name -> its key of ours (Look.Key)
local menu                  -- nil, or { thing, page, at = { [page] = line }, entries, wheels, wheel, slots, amount, hold, since }
local noDestroy = false     -- the game refused a destroy: none is offered again this session
local due, hearing = false, false
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("items", text)
    end
end

-- One answer of the game after an action, for the log and the chat: fn runs at the next word of that event.
local function after(event, fn)
    ns.On(event, "ItemActionsAfter", function(...)
        ns.Off(event, "ItemActionsAfter")
        fn(...)
    end)
end

-- ---------------------------------------------------------------- the pages
local function draw()
    local list, page = Draw.Lines(menu), menu.page
    menu.at[page] = math.max(1, math.min(menu.at[page] or 1, #list))
    Draw.Show({ icon = menu.thing.icon, name = menu.thing.name, count = menu.thing.count, title = Model.Title(page, menu.wheel and menu.wheel.name),
        lines = list, at = menu.at[page], words = Model.Words(page, page == "item" and menu.entries[menu.at.item] or nil, menu.hold) })
end

-- The entries are made again from the item and the game as they are now.
local function fill()
    local game = ns.Adapter.ItemGame()
    game.noDestroy = noDestroy
    menu.entries = Model.Entries(menu.thing, game)
    if menu.page == "split" and menu.thing.count < 2 then
        menu.page = "item"
    end
    menu.amount = menu.amount and Model.SplitStep(menu.amount, 0, menu.thing.count)
end

-- The hold on Destroy is over: the bar goes and nothing is drawn each frame.
local function rest()
    menu.hold = nil
    Draw.Part(0)
    Draw.Frame():SetScript("OnUpdate", nil)
end

local later

local function close(why)
    if menu then
        rest()
        menu = nil
        Draw.Hide()
        ns.Send("items:menu", false)
        note("the menu closed: " .. why, "closed")
        later()
    end
end

-- ---------------------------------------------------------------- the hint and the keys
-- True while the bag window has the controller with no game menu over it, and the suite is free.
local function free()
    return ns.Adapter.ItemBagsHavePad() and Look.Free()
end

local function hear(on)
    if on ~= hearing then
        hearing = on
        for _, event in ipairs(HEARD) do
            if on then
                ns.On(event, "ItemActions", later)
            else
                ns.Off(event, "ItemActions")
            end
        end
    end
end

-- One frame after the game's word: the item in focus is read again, the menu follows it or closes, the hint shows
-- or goes, and the keys are ours or the player's.
local function look()
    if not keys then
        return
    end
    local shown = free()
    -- (an item on the pointer: Menu would do nothing, so the hint hides and Menu stays the player's)
    local thing = shown and not ns.Adapter.ItemOnCursor() and ns.Adapter.ItemFocus() or nil
    if menu then
        local was = menu.thing
        if thing and thing.bag == was.bag and thing.slot == was.slot and thing.id == was.id and not thing.locked then
            menu.thing = thing
            fill()
            draw()
        else
            close(shown and "the focus or the item changed" or "the bag window or the suite took the controller")
        end
    end
    if shown and not hint.frame:IsShown() then
        hint.Place(ns.Adapter.ItemBags())
        note("the bag window has the controller: the hint shows", "shown")
    end
    hint.frame:SetShown(shown)
    hint.frame:SetAlpha(thing and not thing.locked and 1 or 0)
    hear(shown)
    keys.MN.Set(thing ~= nil and not thing.locked)
    for _, key in ipairs(NAV) do
        keys[key].Set(menu ~= nil)
    end
end

function later()
    if not due then
        due = true
        C_Timer.After(0, function()
            due = false
            ns.Call("ItemActions", look)
        end)
    end
end

-- ---------------------------------------------------------------- the actions
local function opened()
    local thing = free() and ns.Adapter.ItemFocus()
    if not thing then
        return
    elseif ns.Adapter.PointerHoldsItem() then
        note("Menu while the pointer holds an item: no menu", "pointer")
        return
    end
    menu = { thing = thing, page = "item", at = { item = 1 } }
    fill()
    if not menu.entries[1] then
        menu = nil
        return
    end
    Draw.Place(ns.Adapter.ItemBags(), ns.Adapter.ItemPlace(thing))
    draw()
    ns.Send("items:menu", true)
    note("the menu opened for " .. thing.name .. " (" .. #menu.entries .. " entries)", "opened")
    later()
end

local function destroy(entry)
    local thing = menu.thing
    local ok, why, refused = ns.Adapter.ItemDestroy(thing, entry.asks)
    note("A destroyed " .. thing.name .. ": " .. (ok and (entry.asks and "the game was asked" or "the destroy was asked for") or tostring(why)), "destroy")
    if ok and entry.asks then
        after("DELETE_ITEM_CONFIRM", function() note("the game asked its own question", "asked") end)
    elseif ok then
        after("BAG_UPDATE_DELAYED", function()
            if ns.Adapter.ItemHolds(thing) then
                note("after the destroy the slot still holds " .. thing.name, "kept")
            else
                ns.Print(Model.DestroyedLine(thing.count, thing.name))
            end
        end)
    elseif refused then
        noDestroy = true
        ns.Print(Model.REFUSED)
    end
    close("Destroy")
end

-- A went down on an entry of the first page.
local function choose(entry)
    local thing = menu.thing
    if entry.off then
        return
    elseif entry.kind == "equip" then
        local ok, why = ns.Adapter.ItemEquip(thing, entry.slot)
        note("A equipped " .. thing.name .. " to place " .. entry.slot .. ": " .. (ok and "asked" or tostring(why)), "equip")
        if ok then
            after("PLAYER_EQUIPMENT_CHANGED", function() note("the worn gear changed after the equip", "equipped") end)
        end
        close("Equip")
    elseif entry.kind == "sell" then
        local ok, why = ns.Adapter.SellBagItem(thing)
        note("A sold " .. thing.name .. ": " .. (ok and "asked" or tostring(why)), "sell")
        close("Sell")
    elseif entry.kind == "wheel" then
        menu.page, menu.at.wheels = "wheels", 1
        menu.wheels = Model.Wheels(ns.Wheels.Mine(), ns.WheelRules)
        draw()
    elseif entry.kind == "split" then
        menu.page, menu.amount = "split", Model.SplitStart(thing.count)
        draw()
    end
end

-- A went down on a slot of a wheel: the item goes there, as My Wheels puts a bind there.
local function place()
    local thing, wheel, slot = menu.thing, menu.wheel, menu.at.slots
    local id = ns.Wheels.SetEntry(wheel.id, slot, { kind = "item", id = thing.id, name = thing.name, icon = thing.icon, detail = "" })
    note("A put " .. thing.name .. " on slot " .. slot .. " of " .. tostring(id or "no wheel"), "wheel")
    if id then
        ns.Print(Model.WheelLine(thing.name, slot, wheel.new and ns.WheelRules.Name(id) or wheel.name))
    end
    close("Put on a Wheel")
end

local function split()
    local thing = menu.thing
    local ok, why, bag, slot = ns.Adapter.ItemSplit(thing, menu.amount)
    note("A split " .. menu.amount .. " off " .. thing.name .. ": " .. (ok and ("into bag " .. bag .. " slot " .. slot) or tostring(why)), "split")
    if ok then
        after("BAG_UPDATE_DELAYED", function()
            note("the bags changed after the split; the new slot holds it: " .. tostring(ns.Adapter.ItemHolds({ bag = bag, slot = slot, id = thing.id })), "split done")
        end)
    end
    close("Split")
end

-- Each frame between A down on Destroy and the full hold: the bar grows. Then it stops: the next step is the let-go.
local function grow()
    local part = (GetTime() - menu.since) / Model.HOLD
    Draw.Part(math.max(part, 0.001))
    if part >= 1 then
        menu.hold = "full"
        Draw.Frame():SetScript("OnUpdate", nil)
        draw()
    end
end

local function tick()
    if not (menu and ns.Call("ItemActions", grow)) then
        Draw.Frame():SetScript("OnUpdate", nil)
    end
end

-- A went down (true) or up on the first page's Destroy.
local function hold(down)
    if down and menu.hold == "armed" then
        destroy(menu.entries[menu.at.item])
    elseif down then
        menu.hold, menu.since = "held", GetTime()
        Draw.Part(0.001)
        Draw.Frame():SetScript("OnUpdate", tick)
    elseif menu.hold == "full" then
        menu.hold = "armed"
        draw()
    elseif menu.hold == "held" then
        rest()
        draw()
    end
end

local SPLIT = { DL = -1, DR = 1, DU = Model.BIG, DD = -Model.BIG }
local BACK = { split = "item", wheels = "item", slots = "wheels" }

-- A button of the menu went down (true) or up, while it is ours.
local function press(key, down)
    if key == "MN" then
        if down then
            if menu then close("Menu") else opened() end
        end
        return
    elseif not menu then
        return
    end
    local page = menu.page
    local entry = page == "item" and menu.entries[menu.at.item]
    if key == "A" and entry and entry.kind == "destroy" then
        hold(down)
    elseif not down then
        return
    elseif key == "A" then
        if page == "item" then
            choose(entry)
        elseif page == "wheels" then
            menu.wheel = menu.wheels[menu.at.wheels]
            local slots
            for _, wheel in ipairs(ns.Wheels.Mine()) do
                slots = wheel.id == menu.wheel.id and wheel.slots or slots
            end
            menu.page, menu.at.slots, menu.slots = "slots", 1, Model.Slots(slots, menu.thing.id, ns.WheelRules)
            draw()
        elseif page == "slots" then
            place()
        else
            split()
        end
    elseif key == "B" then
        if BACK[page] then
            menu.page = BACK[page]
            draw()
        else
            close("B")
        end
    elseif page == "split" and SPLIT[key] then
        menu.amount = Model.SplitStep(menu.amount, SPLIT[key], menu.thing.count)
        draw()
    elseif key == "DU" or key == "DD" then
        if menu.hold then
            rest()
        end
        menu.at[page] = Model.Move(menu.at[page], #Draw.Lines(menu), key == "DU" and -1 or 1)
        draw()
    end
end

-- The hint, the list, and the keys of ours, made out of a fight.
local function build()
    hint = Look.Hint("GamepadSuiteItemActions", "MN")
    hint.label:SetText("Item actions")
    hint.Fit()
    Draw.Build()
    keys = {}
    for _, key in ipairs(ALL) do
        keys[key] = Look.Key("ItemActions", "GamepadSuiteItemActions" .. key, key, function(down)
            press(key, down)
        end, key == "MN" and note or function() end)
    end
    later()
end

-- True while the menu is open. The message "items:menu" (true or false) tells when it opens or closes.
function Items.IsOpen()
    return menu ~= nil
end

function Items.OnLogin()
    ns.Queue.Run("ItemActions", build)
    ns.Adapter.OnItemBags(later)
    -- the game's focus moved: while the hint shows, the key and the menu follow it
    ns.Adapter.OnFocusMoved(function()
        if hint and hint.frame:IsShown() then
            later()
        end
    end)
    -- a fight starts: the menu and the hint go at once, and Look.Key gives every key back
    ns.On("PLAYER_REGEN_DISABLED", "ItemActions", function()
        if keys then
            close("combat")
            hint.frame:Hide()
        end
    end)
    ns.On("PLAYER_REGEN_ENABLED", "ItemActions", later)
    Look.Watch("ItemActions", later)
end
