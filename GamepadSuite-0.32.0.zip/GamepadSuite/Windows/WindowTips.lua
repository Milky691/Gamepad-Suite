-- Window Tooltips: the game hides the tooltips of its windows while its option for that is on, and the press that
-- turns it off often does nothing (Core/AdapterBags.lua says where). So the tooltips of every window can stay hidden.
-- Two fixes:
--   - While a window of the game has the controller and the game's own R3 for the tooltips does not work, R3 turns
--     them on and off; in Professions L3 does too, as its footer says. A tooltip turned on shows at the next move: the
--     game's window navigation is not touched. While the player walks with a window open, R3 is the player's bind.
--   - At the login, and each time the last window of the game closes, the option goes back off: the next window
--     shows its tooltips.
-- R3 and L3 are key binds of two buttons of ours (Windows/ListLook.lua Look.Key), taken only while they do the job and
-- given back at once otherwise. No frame of ours hears the controller's other presses: an earlier build had such a
-- frame in every window, and the game's own clicks after a press it handed on (a window's close button) ran as the
-- addon's. Not in a fight (the keys go when one starts), and not while the settings window, the on-screen keyboard or
-- a wheel is open, nor in Mouse Mode (Look.Free). Keys change one frame after the game's word, never inside a press.
local _, ns = ...

local WindowTips = ns.Module("WindowTips", { "windowTips" }, "Window Tooltips")
ns.WindowTips = WindowTips

local Look = ns.ListLook

local MAX_NOTES = 10    -- lines for the log in one session

local keys = {}         -- our key name (RS, LS) -> its key of ours (Look.Key)
local open = true       -- a window of the game showed at the last look (true at the start: the login resets too)
local due = false
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("windows", text)
    end
end

-- R3 or L3 was pressed while it is ours: the tooltips go on or off.
local function press(key)
    local on = ns.Adapter.WindowTipsHidden()
    ns.Adapter.SetWindowTips(on)
    note(key .. " turned the window tooltips " .. (on and "on" or "off"))
end

-- One frame after the game's word: the option goes back off when the last window closed, and R3 (L3 in Professions) is
-- ours while it does the job (the game's window binds change: the message "pad:stack").
local function look()
    local count = ns.Adapter.GameWindows()
    if open and count == 0 and ns.Adapter.WindowTipsHidden() then
        ns.Adapter.SetWindowTips(true)
        note("no window of the game is open: the window tooltips are on again")
    end
    open = count > 0
    if not keys.RS then
        return
    end
    local window = ns.Adapter.FocusedWindow()
    local mine = window ~= nil and Look.Free()
    keys.RS.Set(mine and not ns.Adapter.GameTogglesTips())
    keys.LS.Set(mine and window == ns.Adapter.ProfessionsWindow())
end

-- The game said that something changed, maybe inside a press: one look, at the next frame.
local function later()
    if not due then
        due = true
        C_Timer.After(0, function()
            due = false
            ns.Call("WindowTips", look)
        end)
    end
end

function WindowTips.OnLogin()
    -- the keys' buttons are made out of a fight (Look.Key): after a reload in one they are made when it ends
    ns.Queue.Run("WindowTips", function()
        for _, key in ipairs({ "RS", "LS" }) do
            keys[key] = Look.Key("WindowTips", "GamepadSuiteWindowTips" .. key, key, function(down)
                if down then
                    press(key)
                end
            end, note)
        end
        later()
    end)
    ns.Adapter.OnGameWindows(later)
    -- a fight starts: Look.Key gives the keys back at once; it ends: they can be ours again
    ns.On("PLAYER_REGEN_ENABLED", "WindowTips", later)
    -- a window took the controller or gave it back, the settings window opened or closed, Mouse Mode, a wheel or
    -- the on-screen keyboard came or went
    Look.Watch("WindowTips", later)
    later()
end
