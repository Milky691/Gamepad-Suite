-- Peek Map: a bind, in the list Game Menus. Hold its button and the game's map shows; let go and it closes. It is the
-- game's own Map and Quest Log window, opened by the quest log's button and closed by the window's close button, both
-- clicked by the game's own code at the press and at the let-go (Core/AdapterWorld.lua PeekButton). In a fight the
-- game opens and closes a window only from a secure path (Blizzard_UIParentPanelManager/Shared/UIParentPanelManager.lua
-- 854 to 858, 886, 920): the secure button is one, so it works in a fight too. Our code only reads the map.
--
-- While the map is open it has the controller, and its own binds cover a key of ours (A, B, X, Y, the D-pad, LB, RB,
-- L3, View, Menu: Blizzard_WorldMap/Blizzard_WorldMap.lua 1127 to 1200). A peek key that is one of them can send its
-- let-go to the map's bind: the map stays open until B. No code of ours closes it then, because a close from addon
-- code runs the window's close path as the addon (decision 114).
--
-- The log (kind "peek") has each kind of press and let-go one time, in and out of a fight, with the map open or not
-- after it, and a let-go that never reached the button (seen at the next press). One try in the game answers it.
local _, ns = ...

local Peek = ns.Module("PeekMap", { "peekMap" }, "Peek Map")
ns.PeekMap = Peek

local BUTTON = "GamepadSuitePeekMap"
-- a map with a red mark on it: World Map has the game's other map picture, Track Nearest Quest a third one
local ART = "Interface\\Icons\\INV_Misc_Map03"

local held = false  -- the button heard a press and no let-go since
local told = {}     -- the lines in the log

-- The bind list's entry (Core/Catalog.lua).
function Peek.Bind()
    return { kind = "command", id = "CLICK " .. BUTTON .. ":LeftButton", name = "Peek Map", detail = "Hold to see the map. Best on a back button.", icon = ART }
end

local function note(text)
    if not told[text] then
        told[text] = true
        ns.Log.Add("peek", text)
    end
end

-- After the game ran the button's click for a press (down) or a let-go.
local function after(down)
    if down and held then
        note("the let-go of the last press did not reach the button: the map's own binds had the key")
    end
    held = down
    note(("%s %s: the map is %s"):format(down and "press" or "let-go", ns.Adapter.InCombat() and "in a fight" or "out of a fight",
        ns.Adapter.MapShown() and "open" or "closed"))
end

function Peek.OnLogin()
    -- A secure button, so the bind core can hear its press too (Sticky Layers, Core/BindCore.lua).
    ns.Queue.Run("PeekMap", function()
        ns.Adapter.PeekButton(BUTTON):HookScript("PostClick", function(_, _, down)
            ns.Call("PeekMap", after, down and true or false)
        end)
    end)
end
