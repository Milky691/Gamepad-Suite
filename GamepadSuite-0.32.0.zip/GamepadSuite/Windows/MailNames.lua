-- Mail, pick a name: on the Send Mail page of the game's mail window, A on the To box opens a
-- list of names under the box, over the window. First the player's other characters of this
-- realm (the one played last first), then the five people written to last, then the friends
-- of this realm, then the guild members who are in the game now. Up and down move the focus
-- (it goes round at the ends), left and right move a page, A picks the name and closes the
-- list, B closes it with no change. The last entry, "Type a name", opens the suite's on-screen
-- keyboard, and the typed name is the pick.
--
-- The pick is not written into the To box: addon code never writes a box of the game (its text
-- script would run as the addon's, as the chat box's did in 0.21.0, decision 81). The letter goes
-- to the pick in the way the on-screen keyboard sends a chat line itself: a hint over the mail
-- window's top left corner (Windows/ListLook.lua: the place of a tap), the picture of X and "Send
-- to Bob", and X sends the letter to Bob with the calls of the game's own Send button
-- (Core/AdapterGameWindows.lua MailSendTo), at the press down of a key of ours (Look.Key), while
-- the mail window has the controller. The hint is dim and says why while the letter cannot go by
-- the game's own rule (no subject, a COD over the most), and "Sending to Bob" until the game's
-- answer. The pick goes when the letter went (and is kept as a person written to last), when the
-- To box gets a name (typed, or the game's reply: then the game's own X sends), when the mailbox
-- closes, and for the session when the game refuses the send (one chat line). Not in combat: X is
-- the game's again at once.
--
-- The game's A on the To box is a mouse press made by script; the box's mouse script hears it
-- (Core/AdapterGameWindows.lua). A click of the real mouse comes with A up, and opens no list.
-- The list is over the game's window and must keep the D-pad for itself, so it is a frame of
-- ours that takes every button of the controller while it shows, as the on-screen keyboard
-- does: none goes on to the game. What keeps the game's code safe is the keyboard's rule too
-- (Screen/Keyboard.lua): inside the game's press only a note is taken; the list shows or goes,
-- and the name is written, one frame later, from a timer. The typing focus is never moved from
-- here: the game's own press gave it to the box, and addon code that moves the focus inside a
-- window that the game's navigation has can make the game block the addon. The list has no key
-- bind; the send hint's X is one. The list closes when a fight starts.
--
-- The people written to last are kept for the character: the To box's text is noted when it
-- changes, and the name is kept when the game says that the letter went. The faction of each
-- character is kept when it logs in, so a character of the other faction is left out.
--
-- Not proved in the game: that the box's mouse script runs at the game's A, and that A reads as
-- down in that moment; that the game sends a letter from the calls of its Send button made by
-- addon code at a key's press. The Windows touch keyboard, which the game's press can bring up,
-- stays while the box has the typing focus. The log (kind "mail") says what happened.
local ADDON, ns = ...

local MailNames = ns.Module("MailNames", { "mailNames" }, "Pick a Name")
ns.MailNames = MailNames

local Model, Look, Theme = ns.WindowsModel, ns.ListLook, ns.Theme

local WIDTH, ROW, EDGE, HEAD, FOOT, ROWS = 280, 26, 8, 26, 30, 10   -- in the units of the game's window
local STEP = { DU = -1, DD = 1, DL = -ROWS, DR = ROWS }
local NAME_MOST = 40    -- the most letters of a typed name ("Name-Realm")
local MAX_NOTES = 20    -- lines for the log in one session

local frame, counter
local rows = {}
local state             -- nil while the list is closed; open: { list, focus, top }
local picked            -- the name the letter goes to with X, or nil
local sending           -- the name of the letter X sent, until the game's answer
local dead = false      -- the game refused the send: no hint again in this session
local hint, keys        -- the send hint and its key of ours (Windows/ListLook.lua)
local due = false       -- a look is due at the next frame
local lastTo            -- what the To box had last, when it was not empty
local saved             -- the people written to last, the newest first
local factions          -- "Name-Realm" -> the faction of each character that logged in
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("mail", text)
    end
end

-- The rows of the panel: the part of the list from its top entry, the focus, and where the
-- focus is in the list ("3 of 12").
local function draw()
    for i, row in ipairs(rows) do
        local at = state.top + i - 1
        local entry = state.list[at]
        row.button:SetShown(entry ~= nil)
        if entry then
            row.name:SetText(entry.name)
            row.SetRight(entry.tag or "")
            row.Focus(at == state.focus)
            -- the entry that goes to the keyboard has a gold name, as a row that opens a page
            if entry.type then
                row.name:SetTextColor(Theme.Color("gold"))
            end
        end
    end
    counter:SetText(state.focus .. " of " .. #state.list)
    frame:SetHeight(2 * EDGE + HEAD + math.min(#state.list, ROWS) * ROW + FOOT)
end

-- The panel shows while the list is open. This runs from a timer, never inside a press.
local function follow()
    frame:SetShown(state ~= nil)
end

-- ---------------------------------------------------------------- the send hint
-- The hint's words, and if X can send now: "Send to Bob", or dim with the reason.
local WHY = { subject = "add a subject", cod = "the COD is too high" }

-- One frame after the game's word: the hint shows while a name is picked, the mail window has the
-- controller on its Send Mail page, the list is closed and nothing of the suite has the controller;
-- X is ours while the letter can go.
local function look()
    if not hint then
        return
    end
    local shown = picked ~= nil and not dead and not state and ns.Adapter.MailSendPage() and Look.Free()
    local ready = shown and not sending and ns.Adapter.MailSendReady()
    if shown and not hint.frame:IsShown() then
        hint.Place(ns.Adapter.MailSendWindow())
    end
    hint.label:SetText(sending and "Sending to " .. sending or "Send to " .. tostring(picked) .. (shown and ready ~= true and WHY[ready] and ": " .. WHY[ready] or ""))
    hint.Fit()
    hint.frame:SetAlpha(ready == true and 1 or 0.4)
    hint.frame:SetShown(shown or false)
    keys.Set(ready == true)
end

-- The game said that something changed, maybe inside a press: one look, at the next frame.
local function later()
    if not due then
        due = true
        C_Timer.After(0, function()
            due = false
            ns.Call("MailNames", look)
        end)
    end
end

-- X went down (down true) or up on the key of ours: at the press down the letter goes to the pick.
local function send(down)
    local name = picked
    if not (down and name and not sending and ns.Adapter.MailSendPage() and Look.Free() and ns.Adapter.MailSendReady() == true) then
        return
    end
    local ok, why = ns.Adapter.MailSendTo(name)
    note("X sent the letter to " .. name .. ": " .. (ok and "the call was made" or tostring(why)), "send")
    if ok then
        sending = name
        C_Timer.After(Model.ANSWER, function()
            if sending == name then
                note("the game gave no answer to the letter for " .. name .. " in " .. Model.ANSWER .. " seconds", "answer")
                sending = nil
                later()
            end
        end)
    end
    later()
end

-- The game refused an action of an addon: when it is our send, the hint is off for the session.
local function blocked(addon, call)
    if addon == ADDON and not dead and tostring(call):find("SendMail", 1, true) then
        dead, sending = true, nil
        note("the game refused the send (" .. tostring(call) .. "): the hint is off for this session")
        ns.Print("Pick a Name cannot send the letter on this game. Type the name in the To box, then send.")
        later()
    end
end

-- ---------------------------------------------------------------- the list
local function close()
    if state then
        state = nil
        C_Timer.After(0, follow)
        later()
    end
end

-- A name is picked (how: its tag, or "typed"): the letter goes to it with X.
local function choose(text, how)
    text = (text or ""):match("^%s*(.-)%s*$")
    picked = text ~= "" and text or picked
    note("a name (" .. how .. ") was picked for the letter: " .. tostring(text ~= ""), "picked " .. how)
    later()
end

-- One frame after the press on an entry: the name is picked, or the keyboard opens.
local function use(entry)
    if not entry.type then
        choose(entry.name, entry.tag)
    elseif not ns.Keyboard.Ask("To", picked or ns.Adapter.MailNameText(), NAME_MOST, function(text) choose(text, "typed") end) then
        -- no on-screen keyboard on this game build: the box still has the typing focus of the game's press
        note("the on-screen keyboard did not open: a keyboard types into the To box", "keyboard")
    end
end

local function pick(index)
    local entry = state and state.list[index]
    if entry then
        close()
        C_Timer.After(0, function()
            ns.Call("MailNames", use, entry)
        end)
    end
end

-- A button of the controller went down while the list shows, by our name for it.
local function press(button)
    if not state then
        return
    elseif STEP[button] then
        state.focus, state.top = Model.MailMove(state.focus, state.top, STEP[button], #state.list, ROWS)
        ns.Adapter.Sound("U_CHAT_SCROLL_BUTTON")
        draw()
    elseif button == "A" then
        pick(state.focus)
    elseif button == "B" then
        close()
    end
end

-- Who can get a letter: the player's other characters from the profiles, the people written to
-- last, the friends and the guild.
local function who()
    local me, alts = ns.Adapter.Character(), {}
    me.faction = ns.Adapter.Faction()
    for _, entry in ipairs(ns.Profiles and ns.Profiles.on and ns.Profiles.List() or {}) do
        if entry.kind == "char" then
            alts[#alts + 1] = { name = entry.profile.name, realm = entry.profile.realm, faction = factions[entry.id] }
        end
    end
    return { me = me, alts = alts, recent = saved, friends = ns.Adapter.Friends(), guild = ns.Adapter.GuildOnline() }
end

-- One frame after A on the To box: the list opens under the box.
local function open()
    local box = ns.Adapter.MailNameBox()
    if state or not frame or not box:IsVisible() or ns.Adapter.InCombat() then
        return
    end
    state = { list = Model.MailList(who()), focus = 1, top = 1 }
    frame:SetScale(ns.Adapter.ScaleBeside(box))
    frame:ClearAllPoints()
    frame:SetPoint("TOPLEFT", box, "BOTTOMLEFT", -8, -2)
    draw()
    frame:Show()
    frame:Raise()
    note("the list opened with " .. #state.list - 1 .. " names")
end

-- The To box got a mouse press. This runs inside the game's own press: only a look at the
-- controller and a note. With A down it was the game's A; the real mouse comes with A up.
local function pressed()
    if state or not frame or ns.Adapter.InCombat() then
        return
    elseif not ns.Adapter.ButtonDown("A") then
        note("the To box was pressed with A up (the mouse): no list", "mouse")
        return
    end
    note("A on the To box: the list opens one frame later", "press")
    C_Timer.After(0, function()
        ns.Call("MailNames", open)
    end)
end

-- The panel, hidden. While it shows it gets the controller's buttons before the game's binds
-- do, and keeps every one of them.
local function build()
    frame = CreateFrame("Frame", "GamepadSuiteMailNames", UIParent)
    frame:SetFrameStrata("DIALOG")
    frame:SetWidth(WIDTH)
    frame:SetClampedToScreen(true)
    -- a click on the panel is not a click on what is under it
    frame:EnableMouse(true)
    frame:Hide()
    Look.Panel(frame)
    local title = Theme.Text(frame, "small", "gold")
    title:SetPoint("TOPLEFT", EDGE + 4, -EDGE - 4)
    title:SetText("Pick a name")
    counter = Theme.Text(frame, "small", "muted")
    counter:SetPoint("TOPRIGHT", -EDGE - 8, -EDGE - 5)
    for i = 1, ROWS do
        local row = Look.Row(frame, WIDTH - 2 * EDGE, ROW)
        row.button:SetPoint("TOPLEFT", EDGE, -EDGE - HEAD - (i - 1) * ROW)
        -- the mouse: hover gives the focus, a click is A
        row.button:SetScript("OnEnter", function()
            if state and state.focus ~= state.top + i - 1 then
                state.focus = state.top + i - 1
                ns.Call("MailNames", draw)
            end
        end)
        row.button:SetScript("OnClick", function()
            ns.Call("MailNames", pick, state and state.top + i - 1)
        end)
        rows[i] = row
    end
    -- the buttons at the foot, in the strip of every part (Widgets.Legend)
    local legend = ns.Widgets.Legend(frame, "LEFT")
    legend:SetPoint("BOTTOMLEFT", EDGE + 4, EDGE)
    legend.Set({ { keys = { "A" }, text = "Pick" }, { keys = { "B" }, text = "Close" } })
    frame:EnableGamePadButton(true)
    frame:SetScript("OnGamePadButtonDown", function(_, name)
        -- a fault at a press must not leave the list up with the controller
        if not ns.Call("MailNames", press, ns.Adapter.NAME[name]) then
            close()
        end
        return false
    end)
    -- the send hint, hidden, and the key of ours that X clicks
    hint = Look.Hint("GamepadSuiteMailSend", "X")
    keys = Look.Key("MailNames", "GamepadSuiteMailSendKey", "X", send, note)
end

function MailNames.OnLogin()
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    GamepadSuiteCharDB.mailed = GamepadSuiteCharDB.mailed or {}
    saved = GamepadSuiteCharDB.mailed
    local store = ns.Registry.Store("mail")
    store.factions = store.factions or {}
    factions = store.factions
    factions[ns.Adapter.Character().key] = ns.Adapter.Faction()
    -- a frame that hears the controller is not made in a fight: after a reload in one it is
    -- made when the fight ends
    ns.Queue.Run("MailNames", build)
    ns.Adapter.OnMailNameBox(function()
        ns.Call("MailNames", pressed)
    end, function(text)
        lastTo = text ~= "" and text or lastTo
        -- a name in the box (typed, or the game's reply): the game's own X sends to it now
        if text ~= "" and picked then
            picked = nil
            later()
        end
    end, close)
    -- the game says that the letter went: the name it went to is the first of the recent ones
    ns.On("MAIL_SEND_SUCCESS", "MailNames", function()
        if sending then
            Model.Remember(saved, sending)
            picked, sending, lastTo = nil, nil, nil
            later()
        elseif lastTo then
            Model.Remember(saved, lastTo)
            lastTo = nil
        end
    end)
    -- the game could not send it (its red line says why): the pick stays for another try
    ns.On("MAIL_FAILED", "MailNames", function()
        if sending then
            note("the game did not send the letter for " .. sending, "failed")
            sending = nil
            later()
        end
    end)
    ns.On("MAIL_CLOSED", "MailNames", function()
        picked, sending = nil, nil
        later()
    end)
    ns.On("ADDON_ACTION_FORBIDDEN", "MailNames", blocked)
    ns.On("ADDON_ACTION_BLOCKED", "MailNames", blocked)
    -- a fight starts: the list and the hint go at once, and the controller is the game's (Look.Key gives X back)
    ns.On("PLAYER_REGEN_DISABLED", "MailNames", function()
        state = nil
        if frame then
            frame:Hide()
        end
        if hint then
            hint.frame:Hide()
        end
    end)
    ns.On("PLAYER_REGEN_ENABLED", "MailNames", later)
    -- the Send Mail page shows or hides; a window took the controller or gave it back, the settings
    -- window, Mouse Mode, a wheel or the on-screen keyboard came or went
    ns.Adapter.OnMailSendPage(later)
    Look.Watch("MailNames", later)
end
