-- The look of Item Actions (Windows/ItemActions.lua): a small list in the look of the lists by a game window
-- (Windows/ListLook.lua): the dark panel with its thin gold edge, the item's picture and name at the top, the title of
-- the page under it, rows with the settings window's focus mark, the strip of hints at the foot, and the gold bar of
-- a hold along the foot. No new art. Sizes are in the units of the game's windows, as the bag window's own.
-- The panel is a child of the whole screen, never of the game's window (the game's D-pad then never stops on its
-- rows), placed by the item's place on the screen, which is only read.
local _, ns = ...

local Theme, Look, Model = ns.Theme, ns.ListLook, ns.ItemActionsModel

local Draw = {}
ns.ItemActionsDraw = Draw

local WIDTH, ROW, EDGE, HEAD, TITLE, FOOT, GAP = 260, 26, 8, 42, 20, 36, 6
local MOST = 8          -- rows at most: the eight slots of a wheel

local panel, icon, name, title, legend, line
local rows = {}

function Draw.Build()
    panel = CreateFrame("Frame", "GamepadSuiteItemActionsMenu", UIParent)
    panel:SetFrameStrata("DIALOG")
    panel:SetClampedToScreen(true)
    panel:SetWidth(WIDTH)
    panel:Hide()
    Look.Panel(panel)
    icon = ns.Widgets.Icon(panel, 30)
    icon:SetPoint("TOPLEFT", EDGE + 4, -EDGE - 2)
    name = Theme.Text(panel, "row", "cream")
    name:SetPoint("LEFT", icon, "RIGHT", 8, 0)
    name:SetPoint("RIGHT", panel, "RIGHT", -EDGE - 4, 0)
    title = Theme.Text(panel, "small", "gold")
    title:SetPoint("TOPLEFT", EDGE + 12, -EDGE - HEAD)
    for i = 1, MOST do
        rows[i] = Look.Row(panel, WIDTH - 2 * EDGE, ROW)
    end
    legend = ns.Widgets.Legend(panel, "LEFT")
    legend:SetPoint("BOTTOMLEFT", EDGE + 4, 9)
    line = ns.Widgets.HoldLine(panel, 4)
    Draw.rows = rows
    return panel
end

-- The lines of the page the menu is on: { { name, right, off } }. menu: Windows/ItemActions.lua's.
function Draw.Lines(menu)
    local page = menu.page
    if page == "wheels" then
        return menu.wheels
    elseif page == "slots" then
        return menu.slots
    elseif page == "split" then
        local name, right = Model.SplitLine(menu.amount, menu.thing.count)
        return { { name = name, right = right } }
    end
    local out = {}
    for i, entry in ipairs(menu.entries) do
        local right = entry.right
        if entry.kind == "sell" then
            right = ns.Adapter.CoinText(entry.copper)
        elseif entry.kind == "destroy" then
            right = Model.DestroyRight(menu.hold)
        end
        out[i] = { name = entry.name, right = right, off = entry.off }
    end
    return out
end

-- Draws a page. view: { icon, name, count, title, lines = { { name, right, off } }, at (the line in focus), words (for
-- Widgets.Legend) }. Draw.view keeps the last one.
function Draw.Show(view)
    Draw.view = view
    icon:SetIcon(view.icon)
    name:SetText(view.count > 1 and (view.count .. " " .. view.name) or view.name)
    title:SetText(view.title)
    title:SetShown(view.title ~= "")
    local top = EDGE + HEAD + (view.title ~= "" and TITLE or 0)
    for i, row in ipairs(rows) do
        local entry = view.lines[i]
        row.button:SetShown(entry ~= nil)
        if entry then
            row.button:ClearAllPoints()
            row.button:SetPoint("TOPLEFT", panel, "TOPLEFT", EDGE, -top - (i - 1) * ROW)
            row.name:SetText(entry.name)
            row.SetRight(entry.right or "")
            row.Focus(i == view.at)
            row.button:SetAlpha(entry.off and 0.4 or 1)
        end
    end
    legend.Set(view.words)
    panel:SetHeight(top + #view.lines * ROW + FOOT)
    panel:Show()
end

-- Puts the panel by the item, scaled as the game's window beside it. place: Adapter.ItemPlace's (pixels), or nil.
function Draw.Place(window, place)
    panel:SetScale(ns.Adapter.ScaleBeside(window))
    panel:ClearAllPoints()
    if not place then
        panel:SetPoint("CENTER")
        return
    end
    local scale = ns.Adapter.EffectiveScale(panel)
    if place.side == "left" then
        panel:SetPoint("TOPRIGHT", UIParent, "BOTTOMLEFT", place.left / scale - GAP, place.top / scale)
    else
        panel:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", place.right / scale + GAP, place.top / scale)
    end
end

-- The gold bar of a hold: 0 to 1.
function Draw.Part(part)
    line:SetPart(part)
end

function Draw.Hide()
    Draw.view = nil
    line:SetPart(0)
    panel:Hide()
end

function Draw.Frame()
    return panel
end
