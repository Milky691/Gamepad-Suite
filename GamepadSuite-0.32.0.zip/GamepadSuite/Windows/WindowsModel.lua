-- The rules of three helpers on the game's own windows, with no game calls: the order of the
-- flight list, the hold and the order of a learn-all run at a trainer, and the list of names
-- for the To box of a letter.
local _, ns = ...

local Model = {}

-- ---------------------------------------------------------------- the last ones used
-- The flight list keeps the places flown to last, the mail list the people written to last:
-- five each, the newest first.
Model.RECENT = 5

-- name goes to the front of the list. A name is in the list one time, whatever its capitals,
-- and the list keeps RECENT names.
function Model.Remember(list, name)
    for i = #list, 1, -1 do
        if list[i]:lower() == name:lower() then
            table.remove(list, i)
        end
    end
    table.insert(list, 1, name)
    for i = #list, Model.RECENT + 1, -1 do
        list[i] = nil
    end
    return list
end

-- ---------------------------------------------------------------- the flight list
-- places: { { index, name, cost } }, the places the character can fly to now. recent: names,
-- the one flown to last first. Gives the places in the order of the list: the recent ones that
-- can be reached from here, the newest first (each gets recent = true), then the others by name.
function Model.FlightOrder(places, recent)
    local byName, out = {}, {}
    for _, place in ipairs(places) do
        byName[place.name] = place
    end
    for _, name in ipairs(recent) do
        local place = byName[name]
        if place and not place.recent and #out < Model.RECENT then
            place.recent = true
            out[#out + 1] = place
        end
    end
    local rest = {}
    for _, place in ipairs(places) do
        if not place.recent then
            rest[#rest + 1] = place
        end
    end
    table.sort(rest, function(a, b)
        local first, second = a.name:lower(), b.name:lower()
        if first ~= second then
            return first < second
        end
        return a.index < b.index
    end)
    for _, place in ipairs(rest) do
        out[#out + 1] = place
    end
    return out
end

-- The game closes its flight window when a flight begins. A window that closes within this
-- many seconds of an ask is the game's yes to that ask: the place counts as flown to. One that
-- closes later was closed by the player.
Model.FLIGHT_TOOK = 2

function Model.FlightTaken(askedAt, closedAt)
    return closedAt - askedAt <= Model.FLIGHT_TOOK
end

-- Where the entry i of the list stands: its column and its line, both from 0. The list fills a
-- column from the top and then starts the next one to the right.
function Model.FlightCell(i, lines)
    return math.floor((i - 1) / lines), (i - 1) % lines
end

-- ---------------------------------------------------------------- learn all
-- The button is held this many seconds before the first spell is bought.
Model.HOLD = 1
-- A run waits this many seconds for the game's answer to one buy, and then ends.
Model.ANSWER = 3

-- A line of the trainer counts for a run when the game says it can be learned now and it is no
-- new profession: the game's own window asks the player before it teaches one.
local function counts(service)
    return service.kind == "available" and not service.profession
end

-- A line by its name and rank: its place in the list changes when the list is drawn again.
function Model.TrainerKey(service)
    return service.name .. "|" .. service.sub
end

-- What every line that counts costs together, in copper, and how many they are.
function Model.TrainerSum(services)
    local sum, count = 0, 0
    for _, service in ipairs(services) do
        if counts(service) then
            sum, count = sum + service.cost, count + 1
        end
    end
    return sum, count
end

-- The next line to buy: the first that counts and that the gold pays for. asked is the key of
-- the line that was asked for last. With no line to buy the second value says why: "wait"
-- (the line asked for is in the list as it was: the game has not answered yet), "gold" (lines
-- are left and the gold pays for none of them) or "done".
function Model.TrainerNext(services, money, asked)
    local left = false
    for _, service in ipairs(services) do
        if counts(service) and Model.TrainerKey(service) == asked then
            return nil, "wait"
        end
    end
    for _, service in ipairs(services) do
        if counts(service) then
            if service.cost <= money then
                return service
            end
            left = true
        end
    end
    return nil, left and "gold" or "done"
end

-- With nothing to learn: what the lines that cannot be learned yet wait for, as the hint's words,
-- and how many wait on a level and on a skill. The smallest level above the character's first
-- ("Nothing now. Next at level 24"); with none, the smallest rank of a skill that is not high
-- enough ("Nothing now. Next at Alchemy 75"); else "Nothing now". services: of
-- Adapter.TrainerServices ({ kind, reqLevel, skill, rank, met }); level: the character's, nil
-- when the game did not say.
function Model.TrainerWait(services, level)
    local next, skill, onLevel, onSkill = nil, nil, 0, 0
    for _, line in ipairs(level and services or {}) do
        if line.kind == "unavailable" and (line.reqLevel or 0) > level then
            onLevel, next = onLevel + 1, math.min(next or line.reqLevel, line.reqLevel)
        elseif line.kind == "unavailable" and line.skill and line.rank and not line.met then
            onSkill = onSkill + 1
            skill = (not skill or line.rank < skill.rank) and line or skill
        end
    end
    local words = next and "Nothing now. Next at level " .. next or skill and "Nothing now. Next at " .. skill.skill .. " " .. skill.rank
    return words or "Nothing now", onLevel, onSkill
end

-- How far a hold is that began at `since`: from 0 to 1, and true when it is full.
function Model.HoldPart(since, now)
    local part = (now - since) / Model.HOLD
    if part >= 1 then
        return 1, true
    end
    return part, false
end

-- ---------------------------------------------------------------- names for a letter
Model.MAIL_MOST = 40            -- the most names in the list
Model.TYPE = "Type a name"      -- its last entry

-- A name as the To box takes it for a character of the player's own realm: the name alone. nil
-- for a character of another realm ("Name-Realm").
function Model.OnRealm(name, realm)
    local plain, other = name:match("^([^%-]+)%-(.+)$")
    if not plain then
        return name
    end
    return other == realm and plain or nil
end

local function inOrder(names)
    local sorted = {}
    for i, name in ipairs(names) do
        sorted[i] = name
    end
    table.sort(sorted, function(a, b)
        return a:lower() < b:lower()
    end)
    return sorted
end

-- The list for the To box. who = { me = { name, realm, faction }, alts = { { name, realm,
-- faction } } (the one played last first), recent = { names }, friends = { names }, guild =
-- { names } }. In order: the player's other characters of this realm (and of this faction,
-- where the faction of both is known), the people written to last, the friends of this realm,
-- the guild members of this realm; friends and guild by name. A name is in the list one time,
-- in its first group, and the character's own name is not in it. Each entry is { name, tag };
-- the last one is { name = TYPE, type = true }.
function Model.MailList(who)
    local out, seen = {}, { [who.me.name:lower()] = true }
    local function add(name, tag, anyRealm)
        local plain = type(name) == "string" and name ~= "" and (anyRealm and name or Model.OnRealm(name, who.me.realm))
        if plain and not seen[plain:lower()] and #out < Model.MAIL_MOST then
            seen[plain:lower()] = true
            out[#out + 1] = { name = plain, tag = tag }
        end
    end
    for _, alt in ipairs(who.alts) do
        if alt.realm == who.me.realm and (not alt.faction or not who.me.faction or alt.faction == who.me.faction) then
            add(alt.name, "Your character")
        end
    end
    for _, name in ipairs(who.recent) do
        -- a name the player wrote to is kept as it was written, with its realm
        add(name, "Recent", true)
    end
    for _, name in ipairs(inOrder(who.friends)) do
        add(name, "Friend")
    end
    for _, name in ipairs(inOrder(who.guild)) do
        add(name, "Guild")
    end
    out[#out + 1] = { name = Model.TYPE, type = true }
    return out
end

-- The focus moves in a list of count entries, of which the panel shows `rows` at a time from
-- the entry top. One step up or down goes round at the ends of the list; a bigger step (a
-- page) stops there. Gives the new focus and the new top: the top follows so that the focus
-- stays on the panel.
function Model.MailMove(focus, top, step, count, rows)
    if step == 1 or step == -1 then
        focus = (focus - 1 + step) % count + 1
    else
        focus = math.max(1, math.min(count, focus + step))
    end
    if focus < top then
        top = focus
    elseif focus > top + rows - 1 then
        top = focus - rows + 1
    end
    return focus, top
end

if ns then
    ns.WindowsModel = Model
end
return Model
