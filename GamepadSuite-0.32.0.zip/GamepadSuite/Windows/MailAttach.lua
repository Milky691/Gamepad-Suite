-- Mail, attach a stack: while a letter is written (the Send Mail page of the game's mail window)
-- and the bag window beside it has the controller, a hint stands over the bag window's top left
-- corner, after Sort bags (Windows/ListLook.lua: the place of a tap): the picture of Y and "Attach
-- trade goods", seen only while the game's focus is on a stack that can go in. Y on such a stack puts
-- the whole stack into the letter, in its first free item place. Y on anything else does what the
-- game's Y does there. Not in combat. A stack that is bound to the character, already in the
-- letter, or needed for a quest is not taken. When all 12 places of the letter hold a stack, the
-- hint on such a stack reads "Letter full", dim, and Y stays the game's, until a place frees.
--
-- In the game's bag window Y opens the menu "More actions" for every item
-- (Blizzard_UIPanels_Game/Mainline/ContainerFrame.lua 3338 to 3350), and X acts only on an item
-- that can be used, worn, read, opened or sold (3281 to 3316). So Y is ours only on a stack that
-- can go into the letter, and only while one is written: the menu stays for every other item.
-- Y is a key bind of a button of ours (Windows/ListLook.lua Look.Key), taken only while the
-- game's focus is on a stack that can go in, and given back otherwise: no frame of ours hears the
-- controller. The stack goes in inside the press of Y. The key follows the focus with no watch
-- on a timer: the game's navigation moves its focus in one call, which is watched
-- (Core/AdapterBank.lua OnFocusMoved), and the slot in focus is read again one frame after each
-- move, and after the bags change, a stack is locked or freed (it goes into the letter, or
-- comes out of it), or the letter's items change (MAIL_SEND_INFO_UPDATE, heard only while the
-- hint shows; Blizzard_MailFrame/MailFrame.lua 32 and 142 to 143). The hint shows while a letter
-- is written and the bag window has the controller: seen while Y is ours, dim on a stack that
-- finds the letter full, else drawn at alpha 0. It and the key change one frame after the game's
-- word, never inside a press.
--
-- Not proved in the game: that the letter takes a stack from addon code, and that the slot read
-- is the one in the game's focus. The log (kind "mail") says what Y did.
local _, ns = ...

local MailAttach = ns.Module("MailAttach", { "mailAttach" }, "Attach Trade Goods")
ns.MailAttach = MailAttach

local Goods, Look = ns.GoodsModel, ns.ListLook

local KEY = "Y"
local MAX_NOTES = 10    -- lines for the log in one session

local hint, frame, keys
local due = false       -- a look is due at the next frame
local itemMenu = false   -- the item menu of Item Actions is open (message "items:menu")
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("mail", text)
    end
end

-- True while Y can be ours: a letter is written, the bag window has the controller, nothing of
-- the suite has it, and no fight is on.
local function can()
    return ns.Adapter.MailWriting() and ns.Adapter.WindowHasPad(ns.Adapter.BagWindow()) and Look.Free()
end

local later

-- Y went down (down true) or up on the key of ours: at the press, a stack that can go into a
-- letter goes in.
local function press(down)
    local thing = down and can() and ns.Adapter.BagFocus()
    if not (thing and Goods.Mailable(thing)) then
        return
    end
    local took, why = ns.Adapter.MailAttach(thing)
    note(took and "Y put " .. thing.name .. " x" .. thing.count .. " into the letter" or "Y on " .. thing.name .. ": " .. why,
        took and "took" or nil)
    later()
end

-- One frame after the game's word, a move of the focus or a press: the hint shows while a letter
-- is written and the bag window has the controller, and is seen, and Y is ours, while the game's
-- focus is on a stack that can go into the letter and the letter has a free place. With no free
-- place the hint on such a stack is dim, "Letter full", and Y is the game's.
local function look()
    if not frame then
        return
    end
    local shown = can()
    if shown and not frame:IsShown() then
        hint.Place(ns.Adapter.BagWindow())
        note("a letter is written and the bag window has the controller: the hint shows", "shown")
    end
    local thing = shown and ns.Adapter.BagFocus()
    local mailable = thing and Goods.Mailable(thing) or false
    local mine = mailable and ns.Adapter.MailFreePlace() ~= nil
    if mailable and not mine then
        note("the letter has no free place: the hint reads Letter full, and Y is the game's", "full")
    end
    hint.label:SetText(mailable and not mine and "Letter full" or "Attach trade goods")
    hint.Fit()
    frame:SetAlpha(mine and 1 or mailable and 0.4 or 0)
    frame:SetShown(shown)
    keys.Set(mine and not itemMenu)
    -- with the focus still on it, the stack can go into the letter or come out of it, the bags can change, and a
    -- place of the letter can fill or free
    for _, event in ipairs({ "ITEM_LOCK_CHANGED", "BAG_UPDATE_DELAYED", "MAIL_SEND_INFO_UPDATE" }) do
        if shown then
            ns.On(event, "MailAttach", later)
        else
            ns.Off(event, "MailAttach")
        end
    end
end

-- The game said that something changed, maybe inside a press: one look, at the next frame.
function later()
    if not due then
        due = true
        C_Timer.After(0, function()
            due = false
            ns.Call("MailAttach", look)
        end)
    end
end

-- The hint, hidden, and the key of ours that Y clicks.
local function build()
    hint = Look.Hint("GamepadSuiteMailAttach", KEY)
    hint.label:SetText("Attach trade goods")
    hint.Fit()
    frame = hint.frame
    keys = Look.Key("MailAttach", "GamepadSuiteMailAttachKey", KEY, press, note)
    later()
end

function MailAttach.OnLogin()
    -- the key's button is made out of a fight (Look.Key): after a reload in one it is made when
    -- the fight ends
    ns.Queue.Run("MailAttach", build)
    ns.Adapter.OnMailWriting(later)
    -- the focus moved, in any window of the game: while the hint shows, Y follows it
    ns.Adapter.OnFocusMoved(function()
        if frame and frame:IsShown() then
            later()
        end
    end)
    -- a fight starts: the hint goes at once, and Y is the game's (Look.Key gives it back)
    ns.On("PLAYER_REGEN_DISABLED", "MailAttach", function()
        if frame then
            frame:Hide()
        end
    end)
    ns.On("PLAYER_REGEN_ENABLED", "MailAttach", later)
    -- a window took the controller or gave it back, the settings window opened or closed, Mouse
    -- Mode, a wheel or the on-screen keyboard came or went
    Look.Watch("MailAttach", later)
    -- the item menu of Item Actions opened or closed: Y is its while it is open
    ns.Listen("items:menu", "MailAttach", function(open)
        itemMenu = open and true or false
        later()
    end)
end
