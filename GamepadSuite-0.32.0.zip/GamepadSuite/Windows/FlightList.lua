-- The flight list: at a flight master a list stands to the right of the game's flight map,
-- with every place the character can fly to from here now, by name, with its cost. The places
-- flown to last come first (five at most, kept for the character), then the others by name.
-- The D-pad's up and down move through the list, and the map follows: the place of the row in
-- focus has the highlight ring on the map that the game shows on the place under the mouse.
-- (The route lines and the map's tooltip are the game's own code and are not run from here:
-- the row has the name and the cost.) A flies there. B closes the window. Left goes to the
-- map, which works as it always did, and right comes back. Down on the last row can go to a
-- place of the map: the game's D-pad goes to the nearest button within 45 degrees of the push
-- (SmartNavigation.lua 3 and 1138 to 1228), and the list has no say in it. Over the list's top
-- left corner two hints say so (Windows/ListLook.lua): A "Fly" and left "Map". They hear no
-- button. The switch is Flight List.
--
-- The list takes no key and hears no button. Its rows are buttons under the game's own flight
-- window, so the game's own D-pad stops on them, its A clicks them and its B closes the window
-- (Core/AdapterGameWindows.lua has the lines of the game's code). What a row does:
--   the focus or the mouse comes to it: the place's button on the map gets its highlight;
--   the focus leaves it: the highlight goes;
--   a click: the game's own button of that place on the map is clicked, and that button asks
--     for the flight with its own code, as at a click of the mouse on the map. No code of the
--     suite asks for it. The row is made with the game's own template for a click that does a
--     secure action out of combat (InsecureActionButtonTemplate, Blizzard_FrameXML/
--     SecureTemplates.xml 12 to 18, its click action 557 to 564): the template's code clicks
--     the button named in the row's attribute "clickbutton". The template is not protected, so
--     the game's flight window does not become a protected frame; ForeverDungeonJournal puts
--     its buttons on the game's world map with the same template on this game, for the same
--     reason (Systems/MapMarkers.lua 223 to 230). In combat the template does nothing, and one
--     chat line says why.
-- The game's answer to an ask is that its flight window closes. A window that closes within
-- two seconds of an ask, from the list or from the map, makes the place the first of the list
-- from then on; one that the player closes later does not.
-- For the first row to have the focus when the window opens, three things hold: the list's
-- frame is made at login, before the game makes the buttons of its map's places; its first row
-- is at the very top, higher than any place of the map can be; and the window's close button
-- is hidden while the list shows, as on the windows the game made for the controller. Every
-- row is made at login, hidden, before the game makes a button for a place: no frame of ours is
-- made under the window while it opens or has the controller (Core/AdapterGameWindows.lua says
-- why). The open only puts the places on the rows.
--
-- The open and the first focus are proved in the game (log of 0.21.0: "opened with 3 places
-- ... the focus is on row 1"). The log (kind "flight") says for each open how many places the
-- list has and where the focus is one frame later, for each A on a row whether the game's own
-- button asked for the flight, and how long after the ask the window closed. When the game
-- shows another flight window than this one, the log says so.
local _, ns = ...

local FlightList = ns.Module("FlightList", { "flightList" }, "Flight List")
ns.FlightList = FlightList

local Model, Look = ns.WindowsModel, ns.ListLook

-- In the units of the game's window. A row's bottom edge is EDGE + ROW under the window's top:
-- that is higher than the lowest edge a place button of the map can have (32 under the top).
local WIDTH, ROW, EDGE, COLUMNS = 270, 26, 3, 3
-- The game's pointer stands to the left of the row in focus: the gap keeps it off the map.
local GAP = 24
local MAX_NOTES = 20    -- lines for the log in one session

local window            -- the game's flight window
local panel, divider
local hints = {}        -- the hints over the list (Look.Hint): A flies, left goes to the map
local rows = {}         -- Look.Row, as many as the list has room for, made at login
local entries = {}      -- the places in the list's order (Model.FlightOrder)
local saved             -- the names of the places flown to last, the newest first
local focus             -- the row the game's focus or the mouse is on
local asked             -- the flight asked for last while the window is open: { name, at }
local lastAsk           -- the flight asked for last, kept when the window closes: { name, at }
local hidClose = false  -- the list hid the window's close button
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("flight", text)
    end
end

-- The focus of the game's D-pad, or the mouse, came to a row: the map marks its place.
local function enter(i)
    if entries[i] then
        focus = i
        rows[i].Focus(true)
        local lit = ns.Adapter.TaxiMark(entries[i].index, true)
        if i > 1 then
            note("the focus came to row " .. i .. " (" .. entries[i].name .. "); the map marks its place: " .. tostring(lit), "moved")
        end
    end
end

local function leave(i)
    if entries[i] then
        focus = focus ~= i and focus or nil
        rows[i].Focus(false)
        ns.Adapter.TaxiMark(entries[i].index, false)
    end
end

-- After the click of a row, the template's and the game's code are done: this only tells
-- what came of it. The game's own place button asks for the flight inside that click, and the
-- watch on the game's call (OnTaxiTaken) has noted it in the same frame.
local function clicked(i)
    local entry = entries[i]
    if not entry then
        return
    elseif ns.Adapter.InCombat() then
        ns.Print("You cannot fly in combat.")
    elseif lastAsk and lastAsk.at == GetTime() and lastAsk.name == entry.name then
        note("A on a row: the game's own button of " .. entry.name .. " asked for the flight")
    else
        note("A on a row: the game's own button of " .. entry.name .. " asked for no flight")
    end
end

-- A row clicks the game's own button of its place, through the template, on the let-go of the
-- click (the game's A presses and lets go at once). No click script of ours runs before it.
local function newRow(i)
    local row = Look.Row(panel, WIDTH - 2 * EDGE, ROW, ns.Adapter.CLICK_TEMPLATE)
    local button = row.button
    button:RegisterForClicks("AnyUp")
    button:SetAttribute("useOnKeyDown", false)
    button:SetAttribute("type", "click")
    button:SetScript("OnEnter", function()
        ns.Call("FlightList", enter, i)
    end)
    button:SetScript("OnLeave", function()
        ns.Call("FlightList", leave, i)
    end)
    button:SetScript("PostClick", function()
        ns.Call("FlightList", clicked, i)
    end)
    return row
end

-- The rows of one column: as many as the window is high.
local function perColumn()
    return math.max(1, math.floor((window:GetHeight() - 2 * EDGE) / ROW))
end

-- Reads the places and puts them on the rows. Gives how many rows show, and how many of them
-- are places flown to before.
local function fill()
    entries = Model.FlightOrder(ns.Adapter.TaxiPlaces(), saved)
    local lines = perColumn()
    -- Limit: three columns of rows, no scrolling; a fourth column when a map has more places
    local count, recent = math.min(#entries, lines * COLUMNS, #rows), 0
    if count < #entries then
        note("the list has room for " .. count .. " of " .. #entries .. " places", "room")
    end
    for i, row in ipairs(rows) do
        if i > count then
            row.button:Hide()
        else
            local entry = entries[i]
            local column, line = Model.FlightCell(i, lines)
            row.button:ClearAllPoints()
            row.button:SetPoint("TOPLEFT", panel, "TOPLEFT", EDGE + column * WIDTH, -EDGE - line * ROW)
            row.button:SetAttribute("clickbutton", ns.Adapter.TaxiButton(entry.index))
            row.name:SetText(entry.name)
            row.SetRight(entry.cost > 0 and ns.Adapter.CoinText(entry.cost) or "")
            row.Focus(false)
            row.button:Show()
            recent = recent + (entry.recent and 1 or 0)
        end
    end
    panel:SetSize(math.max(1, math.ceil(count / lines)) * WIDTH, 2 * EDGE + math.min(count, lines) * ROW)
    -- a thin line parts the places flown to last from the others
    divider:SetShown(recent > 0 and recent < math.min(count, lines))
    divider:SetPoint("TOPLEFT", panel, "TOPLEFT", EDGE + 10, -EDGE - recent * ROW)
    panel:SetShown(count > 0)
    return count, recent
end

-- The list goes, and the map and the window's close button are as the game left them.
local function hide()
    if focus then
        leave(focus)
    end
    panel:Hide()
    for _, hint in ipairs(hints) do
        hint.frame:Hide()
    end
    if hidClose then
        hidClose = false
        ns.Adapter.TaxiCloseButton(true)
    end
end

-- The flight window closed. Soon after an ask, that is the game's yes: the place is the first
-- of the list from now on.
local function closed()
    hide()
    if asked then
        local took = Model.FlightTaken(asked.at, GetTime())
        if took then
            Model.Remember(saved, asked.name)
        end
        note(string.format("the flight window closed %.1f s after the ask for %s: %s", GetTime() - asked.at, asked.name,
            took and "the game took the flight" or "that is too late for the game's answer, the place is not kept"))
        asked = nil
    end
end

-- The flight window opened. This runs inside the game's own show of the window, after the game
-- has put the places on its map and before its navigation looks for the first button.
local function opened()
    asked, focus = nil, nil
    if not ns.Registry.Get("windows.flight_list") then
        return
    end
    local count, recent = fill()
    if count == 0 then
        return
    end
    hidClose = ns.Adapter.TaxiCloseButton(false)
    for _, hint in ipairs(hints) do
        hint.Place(panel)
        hint.frame:Show()
    end
    C_Timer.After(0, function()
        note(string.format("opened with %d places, %d of them flown to before; one frame later the focus is on %s; the windows are made for the controller: %s",
            count, recent, focus and ("row " .. focus) or "no row of the list", tostring(hidClose)))
    end)
end

function FlightList.OnLogin()
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    GamepadSuiteCharDB.flights = GamepadSuiteCharDB.flights or {}
    saved = GamepadSuiteCharDB.flights
    local map
    window, map = ns.Adapter.TaxiWindow()
    panel = CreateFrame("Frame", "GamepadSuiteFlightList", map)
    panel:SetPoint("TOPLEFT", window, "TOPRIGHT", GAP, 0)
    -- a click on the panel is not a click on what is under it
    panel:EnableMouse(true)
    panel:Hide()
    Look.Panel(panel)
    divider = ns.Theme.Fill(panel, "ARTWORK", 1, 0.94, 0.78, 0.14)
    divider:SetSize(WIDTH - 2 * EDGE - 20, 1)
    for i = 1, perColumn() * COLUMNS do
        rows[i] = newRow(i)
        rows[i].button:Hide()
    end
    for n, hint in ipairs({ { "A", "Fly" }, { "DL", "Map" } }) do
        hints[n] = Look.Hint("GamepadSuiteFlightHint" .. n, hint[1])
        hints[n].label:SetText(hint[2])
        hints[n].Fit()
    end

    ns.Adapter.OnShownOrHidden(window, function()
        ns.Call("FlightList", window:IsShown() and opened or closed)
    end)
    -- a flight is asked for, from the list or from the map: what the game does next tells
    ns.Adapter.OnTaxiTaken(function(name)
        asked = { name = name, at = GetTime() }
        lastAsk = asked
    end)
    -- the game can show a flight map of another kind: the list knows the old window only
    ns.On("TAXIMAP_OPENED", "FlightList", function(kind)
        C_Timer.After(0, function()
            if not window:IsShown() then
                note("the game opened a flight window of the kind " .. tostring(kind) .. " that is not the old flight window: no list", "other")
            end
        end)
    end)
    ns.Listen("setting", "FlightList", function(key)
        if key == "windows.flight_list" and panel:IsShown() and not ns.Registry.Get(key) then
            hide()
        end
    end)
end
