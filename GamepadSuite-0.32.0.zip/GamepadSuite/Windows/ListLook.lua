-- The look of a list of ours beside or over one of the game's windows (the flight list, the
-- names for a letter): a dark panel with a thin gold edge, and rows with a name at the left
-- and a short text at the right. The row in focus has the settings window's mark: a soft light
-- over the row, a gold bar at its left, and the name in white. And the look of a hint by a
-- game window: a button of the controller and what it does there, and where it stands; and the
-- key bind of ours through which a hint hears its button (Look.Key).
-- Sizes here are in the units of the game's own windows, so a list fits the window it stands by;
-- the type and the button pictures are the Theme's (Theme.size, scaled by Theme.px).
local _, ns = ...

local Theme = ns.Theme

local Look = {}
ns.ListLook = Look

local SIDES = {
    { "TOPLEFT", "TOPRIGHT", "SetHeight" }, { "BOTTOMLEFT", "BOTTOMRIGHT", "SetHeight" },
    { "TOPLEFT", "BOTTOMLEFT", "SetWidth" }, { "TOPRIGHT", "BOTTOMRIGHT", "SetWidth" },
}

-- The dark ground and the thin gold edge, on a frame.
function Look.Panel(frame)
    Theme.Fill(frame, "BACKGROUND", Theme.Color("ground", 0.96)):SetAllPoints()
    for _, side in ipairs(SIDES) do
        local bar = Theme.Fill(frame, "BORDER", Theme.Color("goldDeep"))
        bar:SetPoint(side[1])
        bar:SetPoint(side[2])
        bar[side[3]](bar, 1)
    end
end

-- One row: { button, name, right, Focus(on) }. The button is a button of the game with nothing
-- of ours written on it: under one of the game's windows the game's own D-pad stops on it and
-- the game's own A clicks it (Core/AdapterGameWindows.lua says why no field is written on it).
-- template: a template of the game for the button, or nil for a plain one.
function Look.Row(parent, width, height, template)
    local button = CreateFrame("Button", nil, parent, template)
    button:SetSize(width, height)
    local light = button:CreateTexture(nil, "BACKGROUND")
    light:SetTexture(Theme.art.rowLight)
    light:SetBlendMode("ADD")
    light:SetAlpha(0.42)
    light:SetAllPoints()
    local bar = Theme.Fill(button, "ARTWORK", Theme.Color("gold"))
    bar:SetWidth(3)
    bar:SetPoint("TOPLEFT", 0, -4)
    bar:SetPoint("BOTTOMLEFT", 0, 4)
    local right = Theme.Text(button, "small", "muted")
    right:SetPoint("RIGHT", -8, 0)
    right:SetJustifyH("RIGHT")
    -- a long name ends in dots before the text at the right
    local name = Theme.Text(button, "body", "cream")
    name:SetPoint("LEFT", 12, 0)
    name:SetPoint("RIGHT", right, "LEFT", -8, 0)

    local row = { button = button, name = name, right = right }
    -- The text at the right, at the whole width of its words: a long name then ends in dots and never takes room
    -- from it (the owner: "flight list is clipping prices when names are big enough").
    function row.SetRight(words)
        right:SetWidth(0)
        right:SetText(words)
        local wide = right.GetUnboundedStringWidth and right:GetUnboundedStringWidth()
        if type(wide) ~= "number" then
            wide = right:GetStringWidth()
        end
        if type(wide) == "number" then
            right:SetWidth(math.ceil(wide) + 2)
        end
    end
    function row.Focus(on)
        light:SetShown(on)
        bar:SetShown(on)
        name:SetTextColor(Theme.Color(on and "white" or "cream"))
    end
    row.Focus(false)
    return row
end

-- ---------------------------------------------------------------- a hint by a game window
local wheel   -- the wheel that is open, or nil

-- True while nothing of the suite has the controller and no fight is on: the settings window,
-- the on-screen keyboard and the wheels are closed, and Mouse Mode is off. A hint by a game
-- window (learn all, the bank, a letter) shows and takes its button only then.
function Look.Free()
    return not (ns.Settings.IsOpen() or ns.Pointer.IsOn() or wheel ~= nil or ns.Keyboard.IsOpen()
        or ns.fightStarted or ns.Adapter.InCombat())
end

-- Tells fn each time Look.Free() can have changed, and each time the game set or cleared its
-- window binds (a window of the game, or the settings window, took the controller or gave it back).
function Look.Watch(owner, fn)
    ns.Listen("pad:stack", owner, fn)
    ns.Listen("pointer", owner, fn)
    ns.Listen("keyboard", owner, fn)
    ns.Listen("wheel", owner, function(id)
        wheel = id
        fn()
    end)
end

local hints = {}   -- every hint, in the order they were made

-- Where the hints of one window stand, the one rule for all: outside the window, above its top
-- edge; a tap's at the left, a hold's at the right (the bank's hint is the one the owner placed
-- inside its window, decision 112); the shown hints of one side in a row, in the
-- order they were made. Laid out each time a hint of that window shows, goes or gets new words.
local function arrange(window)
    local x = { tap = 10, hold = 10 }
    for _, hint in ipairs(hints) do
        local frame, side = hint.frame, hint.hold and "hold" or "tap"
        if window and hint.window == window and frame:IsShown() then
            frame:ClearAllPoints()
            if hint.inside then
                -- (a hint the owner placed inside its window: the bank's, at its bottom left, decision 112)
                frame:SetPoint("BOTTOMLEFT", window, "BOTTOMLEFT", 16, 8)
            elseif hint.hold then
                frame:SetPoint("BOTTOMRIGHT", window, "TOPRIGHT", -x.hold, 6)
            else
                frame:SetPoint("BOTTOMLEFT", window, "TOPLEFT", x.tap, 6)
            end
            x[side] = x[side] + (hint.inside and 0 or frame:GetWidth() + 16)
        end
    end
end

-- A key of ours while a hint can act: the one button of the controller a hint hears, as a key bind
-- of a plain button of ours (Core/AdapterPlay.lua TakeKey), so every other press is the game's as
-- it is. No frame of ours hears the controller: such a frame keeps every press (0.25.0), and the
-- game's own clicks after a press it handed on ran as the addon's (0.26.5).
--   owner: the module's name; name: the button's name (it starts with GamepadSuite); key: our key
--   name ("X"); press(down): runs at the key's press (true) and at its let-go (false), inside the
--   press; note(text, once): the module's log.
-- Gives { button, Set(on), Ours() }. Set(on) says if the hint's press would act now: the key is
-- taken then (again each time, so a newer bind of another writer never stays above it), and given
-- back otherwise. Call it from a look one frame after the game's word, never inside a press.
-- Between the key's press and its let-go the key does not change: a key whose bind changes while
-- it is down sends its let-go to the new bind, and a hold would never end. The change waits for
-- the let-go and is made one frame after it, or at the first look after another writer's newer
-- bind took the key (the let-go goes to that bind: press(false) is told then, from the look). A
-- fight takes the key back at once, held or not, and none is taken in one (TakeKey refuses); nor
-- while Look.Free() is false.
function Look.Key(owner, name, key, press, note)
    local keys = { button = CreateFrame("Button", name, UIParent) }
    local click = "CLICK " .. name .. ":LeftButton"   -- what the key reads while it is ours
    -- (set: a bind was asked for, which can be there under a newer one even when it did not read back as ours)
    local want, set, taken, down = false, false, false, false
    local function apply()
        -- the key is down, but a newer bind of another writer is on it now (a question of the game sets X, Y and
        -- R3 for its buttons, Blizzard_StaticPopup/StaticPopupGamepad.lua 20 to 42): its let-go goes there and never
        -- comes here, so the press is over now. Else ours would stay under the game's binds, held, until a fight.
        if down and ns.Adapter.EffectiveBinding(ns.Adapter.KEY[key]) ~= click then
            down = false
            ns.Call(owner, press, false)
        end
        if down then
            return
        end
        if set then
            ns.Adapter.GiveKeys(keys.button)
            set, taken = false, false
        end
        if want and Look.Free() then
            set = true
            taken = ns.Adapter.TakeKey(keys.button, key) and true or false
            note(key .. " is a key of ours: " .. (taken and "set" or "not set, it does " .. tostring(ns.Adapter.EffectiveBinding(ns.Adapter.KEY[key]))), "key " .. key)
        end
    end
    function keys.Set(on)
        want = on and true or false
        apply()
    end
    function keys.Ours()
        return taken
    end
    -- the press and the let-go both click the button; a let-go with no press of ours before it is
    -- none of ours (the key was taken while the button was down)
    keys.button:RegisterForClicks("AnyDown", "AnyUp")
    keys.button:SetScript("OnClick", function(_, _, isDown)
        if isDown then
            down = true
            ns.Call(owner, press, true)
        elseif down then
            ns.Call(owner, press, false)
            down = false
            C_Timer.After(0, function()
                ns.Call(owner, apply)
            end)
        end
    end)
    -- a fight starts: the key goes back before the game locks keys
    ns.On("PLAYER_REGEN_DISABLED", name, function()
        ns.Adapter.GiveKeys(keys.button)
        set, taken, down = false, false, false
    end)
    return keys
end

-- A hint by one of the game's windows, hidden: the picture of a button of the controller and a
-- short text, in the look of every strip of hints (Widgets.Legend), and under them the bar of a
-- hold (Widgets.HoldLine). hold: the button is held. { frame, glyph, label, line, Fit(),
-- Place(window) }: Fit makes the frame as wide as its parts after a new text; Place puts it by a
-- window, before it shows. It is no child of the game's window, so the game's D-pad does not
-- stop on it.
function Look.Hint(name, key, hold)
    local px, size = Theme.px, Theme.size
    local frame = CreateFrame("Frame", name, UIParent)
    frame:SetFrameStrata("DIALOG")
    frame:Hide()
    local glyph = ns.Widgets.Glyph(frame, key, px(size.glyph))
    glyph:SetPoint("TOPLEFT")
    local label = Theme.Text(frame, "body", "cream")
    label:SetPoint("LEFT", glyph, "RIGHT", px(6), 0)
    local hint = { frame = frame, glyph = glyph, label = label, line = ns.Widgets.HoldLine(frame), hold = hold }
    function hint.Fit()
        -- (the line of a hold runs under the picture)
        frame:SetSize(px(size.glyph + 6) + label:GetStringWidth(), px(size.glyph + 5))
        if frame:IsShown() then
            arrange(hint.window)
        end
    end
    function hint.Place(window)
        hint.window = window
        frame:SetScale(ns.Adapter.ScaleBeside(window))
        arrange(window)
    end
    frame:SetScript("OnShow", function() arrange(hint.window) end)
    frame:SetScript("OnHide", function() arrange(hint.window) end)
    hint.Fit()
    hints[#hints + 1] = hint
    return hint
end
