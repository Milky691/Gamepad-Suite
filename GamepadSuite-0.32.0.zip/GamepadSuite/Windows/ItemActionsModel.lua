-- The rules of Item Actions (Windows/ItemActions.lua), with no game calls: which entries an item gets, the pages
-- of a wheel and of a split, the moves in a list, and the words.
-- An item here: { name, count, locked, equip (the game's place word, "INVTYPE_FINGER", or nil when it cannot be
-- worn), usable (it has a use), bop (bind on pickup), quest, noValue, price (what a vendor pays for one, or nil) }.
-- The game here: { dual (the character can dual wield), vendor (one is open), free (a free bag slot for any item),
-- worn ({ [slot] = the name of what is worn there }), noDestroy (the game refused a destroy this session) }.
local _, ns = ...

local Model = {}

-- A hold of this many seconds makes Destroy ready; the next press of A destroys.
Model.HOLD = 1
-- Up and down change the count of a split by this many; left and right by 1.
Model.BIG = 10

-- The game's numbers of the places for gear, and their names.
local NAME = { [1] = "Head", [2] = "Neck", [3] = "Shoulders", [4] = "Shirt", [5] = "Chest", [6] = "Waist", [7] = "Legs",
    [8] = "Feet", [9] = "Wrists", [10] = "Hands", [11] = "Ring 1", [12] = "Ring 2", [13] = "Trinket 1", [14] = "Trinket 2",
    [15] = "Back", [16] = "Main Hand", [17] = "Off Hand", [18] = "Ranged", [19] = "Tabard" }
local PLACES = {
    INVTYPE_HEAD = { 1 }, INVTYPE_NECK = { 2 }, INVTYPE_SHOULDER = { 3 }, INVTYPE_BODY = { 4 }, INVTYPE_CHEST = { 5 },
    INVTYPE_ROBE = { 5 }, INVTYPE_WAIST = { 6 }, INVTYPE_LEGS = { 7 }, INVTYPE_FEET = { 8 }, INVTYPE_WRIST = { 9 },
    INVTYPE_HAND = { 10 }, INVTYPE_FINGER = { 11, 12 }, INVTYPE_TRINKET = { 13, 14 }, INVTYPE_CLOAK = { 15 },
    INVTYPE_WEAPON = { 16, 17 }, INVTYPE_2HWEAPON = { 16 }, INVTYPE_WEAPONMAINHAND = { 16 }, INVTYPE_WEAPONOFFHAND = { 17 },
    INVTYPE_SHIELD = { 17 }, INVTYPE_HOLDABLE = { 17 }, INVTYPE_RANGED = { 18 }, INVTYPE_RANGEDRIGHT = { 18 },
    INVTYPE_THROWN = { 18 }, INVTYPE_RELIC = { 18 }, INVTYPE_TABARD = { 19 },
}
-- a weapon in the off hand needs dual wield; a shield or a held item does not
local DUAL = { INVTYPE_WEAPON = true, INVTYPE_WEAPONOFFHAND = true }
local OFF = 17

-- The slots of a wheel, top first and then clockwise (Settings/WheelsModel.lua says them so).
Model.DIRECTIONS = { "Top", "Top right", "Right", "Bottom right", "Bottom", "Bottom left", "Left", "Top left" }

-- The places an item can be worn in, in the game's numbers.
function Model.Places(equip, dual)
    local out = {}
    for _, slot in ipairs(PLACES[equip] or {}) do
        if slot ~= OFF or dual or not DUAL[equip] then
            out[#out + 1] = slot
        end
    end
    return out
end

-- The entries of the first page, in their order: { kind, name, right, off, slot, copper, asks }.
-- The window puts the coins of copper at the right of Sell.
function Model.Entries(item, game)
    local out = {}
    if item.locked then
        return out
    end
    for _, slot in ipairs(Model.Places(item.equip, game.dual)) do
        out[#out + 1] = { kind = "equip", slot = slot, name = "Equip to " .. NAME[slot], right = game.worn[slot] or "Empty" }
    end
    if item.usable then
        out[#out + 1] = { kind = "wheel", name = "Put on a Wheel" }
    end
    if item.count > 1 then
        out[#out + 1] = { kind = "split", name = "Split", off = not game.free, right = not game.free and "No free slot" or nil }
    end
    -- (bind on pickup gear sells too: the Merchant View's Sell tab and the game's own X at its window sell it with no question)
    if game.vendor and not (item.noValue or item.quest) and (item.price or 0) > 0 then
        out[#out + 1] = { kind = "sell", name = "Sell", copper = item.price * item.count }
    end
    if not game.noDestroy then
        out[#out + 1] = { kind = "destroy", name = "Destroy", right = "Hold A", asks = (item.bop or item.quest) and true or false }
    end
    return out
end

-- Page 2: the player's own wheels ({ id, name, slots }), then "New wheel" while there is room for one more.
-- rules: Core/WheelRules.lua (MOST, MOST_OWN).
function Model.Wheels(mine, rules)
    local out = {}
    for _, wheel in ipairs(mine) do
        local count = 0
        for place = 1, rules.MOST do
            count = count + (wheel.slots[place] and 1 or 0)
        end
        out[#out + 1] = { id = wheel.id, name = wheel.name, right = count .. " of " .. rules.MOST }
    end
    if #mine < rules.MOST_OWN then
        out[#out + 1] = { new = true, name = "New wheel" }
    end
    return out
end

-- Page 3: the slots of a wheel (nil for a new one), each with what it holds now. id: the item's.
function Model.Slots(slots, id, rules)
    local out = {}
    for place = 1, rules.MOST do
        local bind = slots and slots[place]
        local same = bind and bind.kind == "item" and bind.id == id
        out[place] = { place = place, name = Model.DIRECTIONS[place], right = same and "This item" or bind and bind.name or "Empty" }
    end
    return out
end

-- The line in focus after a move up (-1) or down (1) in a list of count lines: it wraps at the ends.
function Model.Move(at, count, step)
    if count < 1 then
        return 1
    end
    return (at - 1 + step) % count + 1
end

-- The count of a split: at first half the stack, then from 1 to one less than the stack.
function Model.SplitStart(count)
    return math.max(1, math.floor(count / 2))
end

function Model.SplitStep(amount, step, count)
    return math.max(1, math.min(count - 1, amount + step))
end

-- The line of page 4: the new stack, and what stays.
function Model.SplitLine(amount, count)
    return "New stack: " .. amount, (count - amount) .. " stay"
end

-- The title of a page under the item's name.
function Model.Title(page, wheelName)
    return page == "wheels" and "Put on a Wheel" or page == "slots" and wheelName or page == "split" and "Split" or ""
end

-- The strip of hints of a page. entry: the entry in focus on the first page. hold: "held" while A is held on
-- Destroy, "full" once the hold is long enough and A is still down, "armed" after the let-go.
function Model.Words(page, entry, hold)
    local a
    if page == "split" then
        return { { keys = { "DPAD" }, text = "Count" }, { keys = { "A" }, text = "Split" }, { keys = { "B" }, text = "Back" } }
    elseif page == "wheels" then
        a = "Choose"
    elseif page == "slots" then
        a = "Put here"
    elseif not entry then
        return { { keys = { "B" }, text = "Close" } }
    elseif entry.kind == "destroy" then
        a = hold == "armed" and "Destroy" or hold == "full" and "Let go" or "Hold to destroy"
    else
        a = ({ equip = "Equip", wheel = "Choose", split = "Choose", sell = "Sell" })[entry.kind]
    end
    return { { keys = { "A" }, text = a, off = entry and entry.off }, { keys = { "B" }, text = page == "item" and "Close" or "Back" } }
end

-- The right side of the Destroy row for each step of the hold.
function Model.DestroyRight(hold)
    return hold == "armed" and "Press A again" or hold == "full" and "Let go" or "Hold A"
end

-- The chat lines.
function Model.WheelLine(name, place, wheel)
    return name .. " is on the " .. Model.DIRECTIONS[place]:lower() .. " slot of " .. wheel .. "."
end

function Model.DestroyedLine(count, name)
    return "Destroyed " .. (count > 1 and count .. " " or "") .. name .. "."
end

Model.REFUSED = "The game did not let Gamepad Suite destroy the item. Destroy is gone from Item Actions until you reload."

if ns then
    ns.ItemActionsModel = Model
end
return Model
