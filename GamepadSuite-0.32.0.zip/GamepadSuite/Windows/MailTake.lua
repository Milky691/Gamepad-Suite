-- Mail, take all: while the inbox of the game's mail window has the controller, a hint stands over the window's top
-- right corner (Windows/ListLook.lua: the place of a hold): the picture of Y and "Hold to take all". It is dim when
-- nothing can be taken. Y held for one second takes the gold and the items of the letters, one thing at a time, each
-- when the game has answered for the one before: the gold of a letter first, then its items, from the top letter down.
-- A gold line under the hint fills while Y is held; let go before it is full and nothing is taken. Then the hint counts
-- ("Taking 2 of 9"). Letters with cash on delivery are never paid and stay; so do letters from a Game Master and letters
-- with only a text. With full bags no more items are taken, but the gold of the other letters is. The run ends when
-- nothing is left, when the inbox goes, when a fight starts, when the game gives no answer for three seconds, and at
-- a second full hold of Y. One chat line says what was taken, what sold, who sent what, and what is left
-- (Windows/MailTakeModel.lua).
--
-- The game's own X ("Open All Mail") takes one thing per press with the controller (Core/AdapterMail.lua says why),
-- and Y has no job in the inbox, so the hold is on Y. Y is a key bind of a plain button of ours (Windows/ListLook.lua
-- Look.Key), as every hint by a game window: no frame of ours hears the controller. The button hears the press and the
-- let-go. Y is ours only while the inbox has the controller, nothing of the suite has it (Look.Free) and no fight is
-- on; it changes one frame after the game's word, never inside a press nor between Y down and Y up, and goes back at
-- once when a fight starts.
-- The run goes on while the controller is on the bags: the takes need no key.
--
-- Nothing runs while nothing happens: the line is drawn each frame between Y down and Y up only, and the inbox is read
-- when the game says that something changed. That the game gives mail to addon code is not proved in the game: the log
-- (kind "mail") says what the first run took and why it ended, and what kinds of letter it read.
local _, ns = ...

local MailTake = ns.Module("MailTake", { "mailTake" }, "Take All Mail")
ns.MailTake = MailTake

local Model, Mail, Look = ns.WindowsModel, ns.MailTakeModel, ns.ListLook

local KEY, ROW = "Y", "windows.mail_take"
local MAX_NOTES = 10    -- lines for the log in one session
-- the game's words that the inbox or the bags changed, or that a take was answered or refused
local ANSWERS = { "MAIL_INBOX_UPDATE", "MAIL_SUCCESS", "BAG_UPDATE_DELAYED", "MAIL_FAILED", "UI_ERROR_MESSAGE" }

local hint, frame, keys          -- the hint, its frame, the key of ours for Y (Look.Key)
local open = false              -- the inbox page shows
local letters, total = {}, 0    -- the inbox at the last look, and the game's count of every letter
local held                      -- when the hold that runs now began
local down                      -- when the hold that was heard last began (for the log)
local run                       -- nil, or the run that is on
local due = false               -- a look is due at the next frame
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("mail", text)
    end
end

-- (before the row is in the settings, its start value: On)
local function rowOn()
    return not ns.Registry.Has(ROW) or ns.Registry.Get(ROW)
end

-- True while Y can be ours: the inbox shows and has the controller, nothing of the suite has it, no fight is on, and
-- the row is on.
local function can()
    local inbox = ns.Adapter.MailInbox()
    return inbox ~= nil and rowOn() and ns.Adapter.WindowHasPad(inbox) and Look.Free()
end

-- ---------------------------------------------------------------- the hint
-- True when a hold would take something now: not while the game is still on a mail call (one asked for before, or its
-- own X), which a new run could not wait out.
local function ready()
    return not ns.Adapter.MailBusy() and Mail.Next(letters, total, ns.Adapter.MailBagFree() == 0, {}) ~= nil
end

local function draw()
    hint.label:SetText(run and ("Taking " .. math.min(run.done + 1, run.total) .. " of " .. run.total) or "Hold to take all")
    frame:SetAlpha((run or ready()) and 1 or 0.4)
    hint.Fit()
end

-- ---------------------------------------------------------------- the run
local later

-- The run ends: one chat line with what was taken, what sold and who sent what, and why it ended when something is
-- left. The first run of a session goes to the log too.
local function finish(why)
    local items, copper, _, cod, soon = Mail.Left(letters)
    ns.Print(Mail.Line(run.got, { items = items, copper = copper, cod = cod, soon = soon }, Mail.WHY[why], ns.Adapter.CoinText,
        ns.Adapter.MailWords()))
    local ids = {}
    for id in pairs(run.failed) do
        ids[#ids + 1] = tostring(id)
    end
    local gotItems, gotCopper = Mail.Totals(run.got)
    note("the first run took " .. gotItems .. " items and " .. gotCopper .. " copper from " .. #run.got
        .. " letters; it ended: " .. (Mail.WHY[why] or "nothing is left"):lower() .. "; " .. run.asks .. " takes asked; refused: "
        .. (ids[1] and table.concat(ids, " ") or "none") .. "; free bag slots now " .. ns.Adapter.MailBagFree(), "run")
    run = nil
end

-- One step of a run, one frame after the game's word: the thing asked for counts once the inbox shows that it went,
-- and the next one is asked for when the game is no longer on a mail call. An ask alone says nothing: the game may give
-- no answer. Three seconds after an ask that is still the one waited for, the run ends, and the player can hold again.
local function advance()
    local ask = run.ask
    if ask then
        local went, letterWent = Mail.Gone(letters, total, ask)
        if went then
            -- (a new letter: another place in the list, or the same place after the letter there went)
            Mail.Got(run.got, ask, run.at ~= ask.index or run.went)
            run.at, run.went = ask.index, letterWent
            run.done, run.ask = run.done + 1, nil
        end
    end
    if run.ask then
        return
    elseif ns.Adapter.MailBusy() then
        -- the game is still on a call and may say nothing at its end: look again soon, as its Open All does
        -- (MailFrame.lua 1644 to 1656); still busy after the answer time, the run ends
        run.busy = (run.busy or 0) + 0.15
        if run.busy > Model.ANSWER then finish("silent") else C_Timer.After(0.15, later) end
        return
    end
    run.busy = 0
    local full = run.full or ns.Adapter.MailBagFree() == 0
    local take = Mail.Next(letters, total, full, run.failed)
    if not take then
        local items = Mail.Left(letters)
        finish(items == 0 and "done" or full and "full" or "refused")
        return
    elseif not ns.Adapter.MailTake(take) then
        finish("call")
        return
    end
    run.ask, run.asks = take, run.asks + 1
    local mine = run
    C_Timer.After(Model.ANSWER, function()
        if run == mine and run.ask == take then
            ns.Call("MailTake", function()
                finish("silent")
                draw()
            end)
        end
    end)
end

-- (the kinds of letter go to the log once a session: does the game give an invoice for a letter not opened)
local function start()
    local items, _, golds = Mail.Left(letters)
    note(Mail.Census(letters, ns.Adapter.MailWords()), "headers")
    run = { total = items + golds, done = 0, got = {}, asks = 0, failed = {}, full = false }
    advance()
end

-- The game did not give the thing asked for. An item is passed for the rest of the run, as the game's Open All does;
-- refused gold ends the run.
local function refused()
    local ask = run and run.ask
    if ask then
        run.ask = nil
        if ask.slot then
            run.failed[ask.id] = true
            note("the game refused " .. ask.name, "refused")
        else
            finish("gold")
        end
    end
    later()
end

-- A red error text of the game: the one for full bags stops the items of the run.
local function failed(_, message)
    if run and ns.Adapter.MailBagsFull(message) then
        run.full = true
        if run.ask and run.ask.slot then
            run.ask = nil
        end
        later()
    end
end

-- The game's words are heard while the inbox shows.
local function hear(on)
    local own = { MAIL_FAILED = refused, UI_ERROR_MESSAGE = failed }
    for _, name in ipairs(ANSWERS) do
        if on then
            ns.On(name, "MailTake", own[name] or later)
        else
            ns.Off(name, "MailTake")
        end
    end
end

-- ---------------------------------------------------------------- the hold
-- The hold is over, full or not: the gold line goes, and nothing is drawn each frame any more.
local function rest()
    held = nil
    hint.line:SetPart(0)
    frame:SetScript("OnUpdate", nil)
end

-- Each frame between Y down and Y up: the gold line grows. When it is full the run begins, or the one that is on stops.
local function grow()
    local part, full = Model.HoldPart(held, GetTime())
    if not full then
        hint.line:SetPart(part)
        return
    end
    rest()
    if run then
        finish("stopped")
    elseif can() and ready() then
        start()
    end
    draw()
end

-- (a fault here would come every frame: it is logged once, and the hold stops)
local function tick()
    if not ns.Call("MailTake", grow) then
        rest()
    end
end

-- Y went down or up on the key of ours.
local function press(isDown)
    if not isDown then
        if down then
            note("the let-go of Y reached the button after " .. string.format("%.1f", GetTime() - down) .. " s", "up")
            down = nil
        end
        if held then
            rest()
        end
    elseif not held and can() and (run or ready()) then
        note("Y went down on the inbox: a hold began", "down")
        held, down = GetTime(), GetTime()
        hint.line:SetPart(0.001)
        frame:SetScript("OnUpdate", tick)
    end
end

-- ---------------------------------------------------------------- the inbox
-- One frame after the game's word: the inbox is read, a run makes its next step, Y is ours or the game's, and the hint
-- shows or goes.
local function look()
    if not keys then
        return
    end
    local inbox = ns.Adapter.MailInbox()
    if (inbox ~= nil) ~= open then
        open = inbox ~= nil
        hear(open)
    end
    if inbox then
        letters, total = ns.Adapter.MailLetters()
    elseif run then
        finish("closed")
    end
    if run then
        advance()
    end
    local mine = can()
    keys.Set(mine)
    if mine then
        note("the inbox has the controller: Y is ours: " .. tostring(keys.Ours()), "taken")
    end
    if not mine then
        rest()
    elseif not frame:IsShown() then
        hint.Place(inbox)
    end
    frame:SetShown(mine)
    draw()
end

-- The game said that something changed. It can say so several times in one frame, and inside a press: one look is
-- made, at the next frame.
function later()
    if not due then
        due = true
        C_Timer.After(0, function()
            due = false
            ns.Call("MailTake", look)
        end)
    end
end

function MailTake.OnLogin()
    -- the hint, and the button that Y clicks while it is ours, at the press and at the let-go; made out of a fight
    -- (Look.Key): after a reload in one they are made when it ends. (The look's own log line says if Y is
    -- ours, so the helper's is not written.)
    ns.Queue.Run("MailTake", function()
        hint = Look.Hint("GamepadSuiteMailTake", KEY, true)
        frame = hint.frame
        keys = Look.Key("MailTake", "GamepadSuiteMailTakeY", KEY, press, function() end)
        later()
    end)
    -- the mailbox opens or closes, a tab is picked, a window of the game comes or goes
    ns.Adapter.OnMailInbox(later)
    ns.Adapter.OnGameWindows(later)
    -- a fight starts: Look.Key gives Y back at once, before the game locks it, and the run ends
    ns.On("PLAYER_REGEN_DISABLED", "MailTake", function()
        if run then
            finish("fight")
        end
        if keys then
            rest()
            frame:Hide()
        end
    end)
    ns.On("PLAYER_REGEN_ENABLED", "MailTake", later)
    -- a window took the controller or gave it back, the settings window opened or closed, Mouse Mode, a wheel or the
    -- on-screen keyboard came or went
    Look.Watch("MailTake", later)
    ns.Listen("setting", "MailTake", function(key)
        if key == ROW then
            later()
        end
    end)
    later()
end
