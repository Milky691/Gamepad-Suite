-- Mark Junk, and the bag window's X held back on an item a quest needs (Quest Item Guard).
--
-- At a vendor, while the bag window has the controller, a hint stands over the bag window's top
-- left corner, after Sort bags (Windows/ListLook.lua: the place of a tap): the picture of Y and
-- "Mark junk". Y on an item in the bags marks it as junk, or
-- not junk any more, with one chat line; the mark is by item id and kept for the character, and
-- Auto Sell Junk sells marked items (Auto/JunkSell.lua). An item a quest needs, a gray item and
-- one a vendor does not buy are refused (Auto/JunkModel.lua). Each bag slot whose item is marked
-- and sells has the game's own junk coin at its top right corner, in every bag window, at a
-- vendor or not (the upgrade arrow has the top left).
-- X on an item a quest needs is held back once: a chat line says so, the hint says it for three
-- seconds (the picture of X and "Again: sell a quest item"), and X again on that slot sells it
-- with the game's own X. The focus on another slot first, or Y, and the next X is held back again.
--
-- Why Y: in the bag window Y is the game's "More actions" menu only while the game's vendor
-- window does not show, and "Manage bag" only on a bag's picture
-- (Blizzard_UIPanels_Game/Mainline/ContainerFrame.lua 3066 to 3074, 3132 to 3135, 3259 to 3265,
-- 3338 to 3344); the window blocks Y for everything else
-- (Blizzard_GamepadSharedUtility/FrameControlsManager.lua 205 and 206). So with the vendor's
-- window up Y has no job on a bag slot. With the Merchant View (Screen/Merchant.lua) that window
-- stays shut, and the bags opened at the vendor keep the game's menu on Y: there the mark is a
-- hold of Y on the view's Sell tab (Screen/MerchantModel.lua Markable), and Mark.Later draws the
-- coins again after it. X sells at the game's window (CanSellItems, ContainerFrame.lua 3127 to
-- 3129, 3281 to 3286).
-- Y and X are key binds of two buttons of ours (Windows/ListLook.lua Look.Key), each taken only
-- while its press would act, for the item in the game's focus: Y on an item, X on an item a quest
-- needs that was not held back just before. Otherwise they are the game's: no frame of ours hears
-- the controller. They follow the focus as Windows/MailAttach.lua's Y does (Core/AdapterBank.lua
-- OnFocusMoved), and the bags. With Mark Junk off and Quest Item Guard on the hint shows nothing
-- but the guard's words, and X is still ours on such an item. Not in a fight. The hint and the
-- keys change one frame after the game's word, never inside a press.
--
-- The coins are frames of ours made under the whole screen and then put on the game's item
-- buttons, as the upgrade arrows are (Screen/Upgrades.lua): nothing is written on the game's
-- button, a protected button gets none. They are drawn when a bag window shows or hides, when
-- the bags change while one shows, and after a mark. Nothing runs on a timer.
local _, ns = ...

local Mark = ns.Module("JunkMark", { "questNeeds", "junkMark" }, "Mark Junk")
ns.JunkMark = Mark

local Model, Look = ns.JunkModel, ns.ListLook
local get = ns.Registry.Get

local MARK, GUARD = "helpers.mark_junk", "helpers.quest_guard"
local MAX_NOTES = 10
-- the hint's words, and the guard's words for GUARD_SECONDS after it held an X back
local WORD, GUARD_WORD, GUARD_SECONDS = "Mark junk", "Again: sell a quest item", 3

local hint, frame
local saying = false    -- the hint says the guard's words now
local said = 0          -- counts the guard's words, so that a timer knows if it is still the newest
local vendor = false    -- a vendor is open: between its two events
local mark, guard       -- the keys of ours for Y and X (Look.Key)
local held              -- the slot whose X was held back last: "bag:slot:item id"
local itemMenu = false   -- the item menu of Item Actions is open (message "items:menu")
local due = false       -- a look is due at the next frame
local coinsDue = false  -- and the coins are drawn again in it
local coins = {}
Mark.coins = coins
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("junk", text)
    end
end

local function needs()
    return Model.Needs(ns.Adapter.QuestLog())
end

local function buzz()
    if ns.Rumble and ns.Rumble.Pulse then
        ns.Rumble.Pulse(0.2, "X held back on a quest item")
    end
end

-- ---------------------------------------------------------------- the coins
local function coin()
    local mark = CreateFrame("Frame", nil, UIParent)
    local art = mark:CreateTexture(nil, "OVERLAY")
    art:SetPoint("TOPRIGHT")
    ns.Adapter.JunkCoin(art)
    return mark
end

-- A coin on each bag slot whose item is marked and sells. The bags' event is heard only while a
-- bag window shows.
local function drawCoins()
    local spots, shows, locked = {}, false, 0
    if get(MARK) then
        spots, shows, locked = ns.Adapter.BagSlotButtons()
    end
    if shows then
        ns.On("BAG_UPDATE_DELAYED", "JunkMark", Mark.Later)
    else
        ns.Off("BAG_UPDATE_DELAYED", "JunkMark")
    end
    local used, marks, known = 0, ns.Adapter.JunkMarks(), nil
    for _, spot in ipairs(spots) do
        if marks[spot.thing.id] then
            known = known or needs()
            if Model.Sells(spot.thing, marks, known) then
                used = used + 1
                coins[used] = coins[used] or coin()
                local mark = coins[used]
                mark:SetParent(spot.frame)
                mark:ClearAllPoints()
                mark:SetAllPoints(spot.frame)
                mark:SetFrameLevel(spot.frame:GetFrameLevel() + 2)
                mark:Show()
            end
        end
    end
    for n = used + 1, #coins do
        coins[n]:Hide()
    end
    if shows then
        note("a bag window shows: " .. #spots .. " items, " .. locked .. " on a protected button, " .. used .. " coins", used > 0 and "coins" or "bags")
    end
end

-- ---------------------------------------------------------------- the hint
-- True while Y marks: Mark Junk is on and the game's own vendor window shows (only then has the
-- bag window's Y no job of the game's).
local function marking()
    return get(MARK) and ns.Adapter.VendorWindowShown()
end

-- A bag slot and its item, to know the X held back last.
local function spot(thing)
    return thing.bag .. ":" .. thing.slot .. ":" .. thing.id
end

-- The hint's words: Y and "Mark junk", or (guard true) X and the guard's words, which go three
-- seconds later. Shown at all while Y marks or the guard's words are up.
local function words(guard)
    saying = guard
    hint.glyph:SetKey(guard and "X" or "Y")
    hint.label:SetText(guard and GUARD_WORD or WORD)
    hint.Fit()
    frame:SetAlpha((guard or marking()) and 1 or 0)
    if guard then
        said = said + 1
        local mine = said
        C_Timer.After(GUARD_SECONDS, function()
            if mine == said and saying then
                ns.Call("JunkMark", words, false)
            end
        end)
    end
end

-- The X held back is forgotten: the next X on that item is held back again.
local function forget()
    held = nil
    if saying then
        words(false)
    end
end

-- True while the hint shows: a vendor is open, one of the two rows is on, the bag window has the
-- controller, nothing of the suite has it, and no fight is on.
local function can()
    return vendor and (get(MARK) or get(GUARD)) and ns.Adapter.WindowHasPad(ns.Adapter.JunkBagWindow()) and Look.Free()
end

-- One frame after the game's word or a move of the focus: the hint and the two keys, and the coins
-- when they can have changed (coinsToo). The X held back is forgotten when the focus is on another
-- slot or item.
local function look(coinsToo)
    if frame then
        local shown = can()
        if shown and not frame:IsShown() then
            hint.Place(ns.Adapter.JunkBagWindow())
            note("a vendor is open and the bag window has the controller: the hint shows", "shown")
        end
        local thing = shown and ns.Adapter.JunkFocus()
        if not (thing and spot(thing) == held) then
            forget()
        end
        frame:SetAlpha((marking() or saying) and 1 or 0)
        frame:SetShown(shown)
        mark.Set(thing and marking() and not itemMenu)
        guard.Set(thing and get(GUARD) and not thing.noValue and Model.Needed(thing, needs()) and spot(thing) ~= held and not itemMenu)
    end
    if coinsToo then
        drawCoins()
    end
end

-- One look at the next frame, for a burst of the game's words.
local function soon()
    if not due then
        due = true
        C_Timer.After(0, function()
            due = false
            local coins = coinsDue
            coinsDue = false
            ns.Call("JunkMark", look, coins)
        end)
    end
end

-- The game said that something changed, maybe inside a press: one look, with the coins, at the next frame.
function Mark.Later()
    coinsDue = true
    soon()
end

-- ---------------------------------------------------------------- the presses
-- Y went down (down true) or up on its key of ours: at the press, the item in focus is marked or
-- not any more, and the X held back is forgotten.
local function markPress(down)
    local thing = down and marking() and ns.Adapter.JunkFocus()
    if not thing then
        return
    end
    forget()
    local text = Model.Toggle(ns.Adapter.JunkMarks(), thing, needs())
    ns.Print(text)
    note("Y: " .. text, "marked")
    Mark.Later()
end

-- X went down (down true) or up on its key of ours: at the press, X on an item a quest needs that
-- a vendor buys, not held back just before on the same slot, is held back. One frame after the
-- let-go X is the game's again, so the next X sells.
local function sellPress(down)
    local thing = down and get(GUARD) and ns.Adapter.JunkFocus()
    local quest = thing and not thing.noValue and Model.Needed(thing, needs())
    if not quest or spot(thing) == held then
        return
    end
    held = spot(thing)
    ns.Print(Model.HeldLine(thing.name, quest))
    words(true)
    buzz()
    note("X on " .. thing.name .. " was held back", "held")
    soon()
end

-- The hint, hidden, and the keys of ours that Y and X click.
local function build()
    hint = Look.Hint("GamepadSuiteJunkMark", "Y")
    frame = hint.frame
    words(false)
    mark = Look.Key("JunkMark", "GamepadSuiteJunkMarkY", "Y", markPress, note)
    guard = Look.Key("JunkMark", "GamepadSuiteJunkMarkX", "X", sellPress, note)
    Mark.Later()
end

function Mark.OnLogin()
    -- the keys' buttons are made out of a fight (Look.Key): after a reload in one they are made
    -- when the fight ends
    ns.Queue.Run("JunkMark", build)
    ns.Adapter.OnBagWindows(Mark.Later)
    -- the focus moved, in any window of the game: while the hint shows, the keys follow it (the coins do not change)
    ns.Adapter.OnFocusMoved(function()
        if frame and frame:IsShown() then
            soon()
        end
    end)
    -- (the vendor can close inside the game's own press of B)
    ns.On("MERCHANT_SHOW", "JunkMark", function()
        vendor = true
        Mark.Later()
    end)
    ns.On("MERCHANT_CLOSED", "JunkMark", function()
        vendor = false
        Mark.Later()
    end)
    -- a fight starts: the hint goes at once, and X and Y are the game's (Look.Key gives them back)
    ns.On("PLAYER_REGEN_DISABLED", "JunkMark", function()
        if frame then
            forget()
            frame:Hide()
        end
    end)
    ns.On("PLAYER_REGEN_ENABLED", "JunkMark", Mark.Later)
    -- a window took the controller or gave it back, the settings window opened or closed, Mouse
    -- Mode, a wheel or the on-screen keyboard came or went
    Look.Watch("JunkMark", Mark.Later)
    -- the item menu of Item Actions opened or closed: X and Y are its while it is open
    ns.Listen("items:menu", "JunkMark", function(open)
        itemMenu = open and true or false
        soon()
    end)
    ns.Listen("setting", "JunkMark", function(key)
        if key == MARK or key == GUARD then
            Mark.Later()
        end
    end)
    Mark.Later()
end
