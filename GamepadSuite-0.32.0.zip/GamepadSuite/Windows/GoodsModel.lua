-- The rules for trade goods in the bags, with no game calls: which stacks the bank deposit
-- moves and in what order (Windows/BankDeposit.lua), and which stack Y puts into a letter
-- (Windows/MailAttach.lua).
-- A thing in the bags: { bag, slot, id, name, count, locked, bound, class, quest, family (the
-- item's family, C_Item.GetItemFamily, or nil) }.
local _, ns = ...

local Model = {}

-- The game's number of the item class "Trade Goods"
-- (Blizzard_APIDocumentationGenerated/ItemConstantsDocumentation.lua 283).
Model.TRADE = 7

-- A trade good, and nothing a quest needs.
function Model.IsGood(thing)
    return thing.class == Model.TRADE and not thing.quest
end

-- How many stacks of trade goods the bags hold.
function Model.Count(things)
    local count = 0
    for _, thing in ipairs(things) do
        if Model.IsGood(thing) then
            count = count + 1
        end
    end
    return count
end

-- True when two families share a bit: the bit compare bit.band(a, b) ~= 0, in plain maths so
-- the rules run outside the game too. The game's own Lua has no such compare (it counts only
-- plain bags, bagFamily 0: Blizzard_StoreUI/Blizzard_Shared_StoreUISecure.lua 1813 and 1814).
local function share(a, b)
    while a > 0 and b > 0 do
        if a % 2 == 1 and b % 2 == 1 then
            return true
        end
        a, b = math.floor(a / 2), math.floor(b / 2)
    end
    return false
end

-- True when a bag of a profession in the bank (a herb bag) has an empty place for the stack:
-- the bag's family shares a bit with the item's. With no family for the item, none.
function Model.FamilyRoom(thing, bank)
    for _, bag in ipairs(bank.bags or {}) do
        if bag.free > 0 and share(thing.family or 0, bag.family) then
            return true
        end
    end
    return false
end

-- How many stacks of trade goods a bag of a profession in the bank has an empty place for.
function Model.FitFamily(things, bank)
    local count = 0
    for _, thing in ipairs(things) do
        if Model.IsGood(thing) and Model.FamilyRoom(thing, bank) then
            count = count + 1
        end
    end
    return count
end

-- The stack the bank takes next: the first trade good in the bags, in the bags' order, that is
-- not on its way somewhere (locked) and that fits. bank: { free (empty places that take any
-- item), room (item id -> how many more the stacks of that item in the bank take), bags (the
-- bags of a profession: { family, free }) }. A stack fits when the stacks of the same item take
-- all of it, or an empty place is there, or a bag of a profession has a place for it; the second
-- value is "family" when only such a bag has. With none, the second value says why: "full"
-- (trade goods are left and none fits) or "done".
function Model.Next(things, bank)
    local left = false
    for _, thing in ipairs(things) do
        if Model.IsGood(thing) and not thing.locked then
            if (bank.room[thing.id] or 0) >= thing.count or bank.free > 0 then
                return thing
            elseif Model.FamilyRoom(thing, bank) then
                return thing, "family"
            end
            left = true
        end
    end
    return nil, left and "full" or "done"
end

-- True when the stack that was asked for is no longer in its place as it was: the game moved it,
-- or a part of it.
function Model.Moved(things, asked)
    for _, thing in ipairs(things) do
        if thing.bag == asked.bag and thing.slot == asked.slot then
            return thing.id ~= asked.id or thing.count ~= asked.count
        end
    end
    return true
end

-- A stack that Y can put into a letter: a trade good that is not bound to the character (the
-- game sends no such item) and not on its way somewhere already (a stack in the letter is
-- locked in the bags).
function Model.Mailable(thing)
    return Model.IsGood(thing) and not thing.bound and not thing.locked
end

if ns then
    ns.GoodsModel = Model
end
return Model
