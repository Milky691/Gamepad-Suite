-- Learn all at the trainer: while the trainer's window has the controller, a hint stands over
-- its top right corner (Windows/ListLook.lua: the place of a hold): the picture of X and "Hold to
-- learn all" with the cost of everything the character can learn now, in the game's coins. The
-- cost is red when the gold does not pay for all of it. With nothing to learn the hint is dim and
-- says what the lines in red wait for: "Nothing now. Next at level 24" or "Nothing now. Next at
-- Alchemy 75" (Windows/WindowsModel.lua TrainerWait), so the player knows when to come back.
-- X held for one second buys every spell that can be learned now, one after the other, each
-- when the game has answered for the one before. A gold line under the hint (the bar of every
-- hold) fills while X is held; let go before it is full and nothing is bought. After the first spell the run goes on
-- by itself, and the hint counts ("Learning 2 of 5"). It ends when nothing is left, when the
-- gold pays for no more, when the game gives no answer for three seconds, when a fight starts,
-- and when the window closes (the game's B). The player can hold again after it ended.
-- A new profession is never bought: the game's window asks the player about one first.
--
-- Y is the game's Spellbook in this window, so the hold is on X, which the game blocks there
-- and gives no job (Core/AdapterGameWindows.lua).
--
-- X is a key bind of a button of ours (Windows/ListLook.lua Look.Key), as the bank's hold
-- (Windows/BankDeposit.lua): its press and its let-go are the hold. It is ours only while a hold
-- could begin, and given back otherwise: no frame of ours hears the controller, and every other
-- button is the game's. The hint shows only while the trainer's own window has the controller,
-- and not while the settings window (X clears a bind there), the on-screen keyboard (X deletes a
-- letter) or a wheel is open, in Mouse Mode, in a fight, while another window of the game has the
-- controller, or with the mouse interface. The hint and the key change one frame after the
-- game's word, never inside a press, and the key not between X down and X up.
-- Between X down and X up, and only then, the gold line is drawn each frame. Nothing else runs
-- on a timer, and nothing while no trainer is open. The hint is no child of the game's window,
-- so the game's D-pad does not stop on it.
--
-- That the game learns a spell at a call from addon code is not proved. The log (kind
-- "trainer") says for each trainer what could be learned, when X began a hold, what was asked
-- for, and how a run ended.
local _, ns = ...

local LearnAll = ns.Module("LearnAll", { "learnAll" }, "Learn All")
ns.LearnAll = LearnAll

local Model, Theme, Look = ns.WindowsModel, ns.Theme, ns.ListLook

local KEY = "X"
local MAX_NOTES = 20            -- lines for the log in one session

local look, keys                -- the hint of every game window and the key of ours (Windows/ListLook.lua)
local hint, label, cost, line   -- its frame, its words, the cost after them, the bar of a hold
local open = false      -- a trainer's window is open
local waiting = false   -- the game said that a trainer opened, and its window was not shown yet
local services, money, level = {}, 0, nil
local held              -- when the hold that runs now began
local run               -- nil, or the run: { total, bought, spent, asked (the key of the line asked for), name, cost }
local due = false       -- a look is due at the next frame
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("trainer", text)
    end
end

-- True while the hint has its place and X can be ours: the trainer's own window has the
-- controller, nothing of the suite has it, and no fight is on.
local function can()
    return open and ns.Adapter.WindowHasPad(ns.Adapter.TrainerWindow()) and Look.Free()
end

-- True when a hold would begin a run now.
local function ready()
    local _, count = Model.TrainerSum(services)
    return not run and count > 0
end

-- The hint as it is now: the words, the cost and its color, dim or not, as wide as its parts.
local function draw()
    local sum, count = Model.TrainerSum(services)
    if run then
        label:SetText("Learning " .. math.min(run.bought + 1, run.total) .. " of " .. run.total)
        cost:SetText("")
    else
        label:SetText(count > 0 and "Hold to learn all" or (Model.TrainerWait(services, level)))
        cost:SetText(count > 0 and ns.Adapter.CoinText(sum) or "")
        cost:SetTextColor(Theme.Color(sum > money and "red" or "cream"))
    end
    hint:SetAlpha((run or count > 0) and 1 or 0.4)
    look.Fit()
    hint:SetWidth(hint:GetWidth() + Theme.px(6) + cost:GetStringWidth())
end

local refresh, step, changed

-- ---------------------------------------------------------------- the run
local function finish(why)
    note("the run ended: " .. why .. ". The game learned " .. run.bought .. " of " .. run.total .. " for " .. run.spent .. " copper.")
    run = nil
end

-- One step of a run, after the game's word that the trainer's list changed: the line asked for
-- is gone from the list, so the game learned it, and the next one is asked for. An ask alone
-- says nothing: the game may give no answer (the call is not proved, and a buy can be refused).
-- Three seconds after an ask that is still the one waited for, the run ends, and the player
-- can hold again.
local function advance()
    local service, why = Model.TrainerNext(services, money, run.asked)
    if why == "wait" then
        return
    end
    if run.asked then
        run.bought, run.spent, run.asked = run.bought + 1, run.spent + run.cost, nil
    end
    if not service then
        finish(why == "gold" and "the gold pays for no more" or "nothing is left")
    elseif ns.fightStarted or ns.Adapter.InCombat() then
        finish("a fight started")
    elseif ns.Adapter.TrainerBuy(service.index) then
        run.asked, run.name, run.cost = Model.TrainerKey(service), service.name, service.cost
        note("asked the trainer for " .. service.name .. " (" .. service.cost .. " copper)", "asked")
        local mine, asked = run, run.asked
        C_Timer.After(Model.ANSWER, function()
            if run == mine and run.asked == asked then
                ns.Call("LearnAll", function()
                    finish("the game gave no answer for " .. mine.name .. " in " .. Model.ANSWER .. " seconds")
                    refresh()
                end)
            end
        end)
    else
        finish("the call for " .. service.name .. " could not be made")
    end
end

-- ---------------------------------------------------------------- the hold
-- The hold is over, full or not: the gold line goes, and nothing is drawn each frame any more.
local function rest()
    held = nil
    line:SetPart(0)
    hint:SetScript("OnUpdate", nil)
end

-- Each frame between X down and X up: the gold line grows. When it is full the run begins,
-- if the trainer's window still has the controller.
local function grow()
    local part, full = Model.HoldPart(held, GetTime())
    if not full then
        line:SetPart(part)
        return
    end
    rest()
    if can() and ready() then
        local _, count = Model.TrainerSum(services)
        run = { total = count, bought = 0, spent = 0 }
        step()
    end
end

-- (a fault here would come every frame: it is logged once, and the hold stops)
local function frame()
    if not ns.Call("LearnAll", grow) then
        rest()
    end
end

-- X went down or up on the key of ours.
local function press(down)
    if down then
        -- the first press, once: the log then tells a press that never came from a hold that could not begin
        note("a press reached the hint: " .. ns.Adapter.KEY[KEY] .. "; it can begin a hold: " .. tostring(can() and ready()), "reach")
    end
    if not down then
        if held then
            rest()
        end
    elseif not held and can() and ready() then
        note("X was seen on the hint: a hold began", "seen")
        held = GetTime()
        line:SetPart(0.001)
        hint:SetScript("OnUpdate", frame)
    end
end

-- ---------------------------------------------------------------- the trainer
-- Shows the hint or not by who has the controller now and by what is known of the trainer's
-- list, and X is ours while a hold could begin. Nothing is asked of the trainer here. Not inside
-- a press.
function refresh()
    local shown = can()
    if not shown then
        rest()
    end
    hint:SetShown(shown)
    draw()
    keys.Set(shown and ready())
end

-- Reads the trainer's list and the gold, makes the next step of a run, and sets the hint.
function step()
    services, level = ns.Adapter.TrainerServices()
    money = ns.Adapter.Money() or 0
    if run then
        advance()
    end
    refresh()
end

local function closed()
    waiting = false
    if not open then
        return
    end
    open = false
    for _, event in ipairs({ "TRAINER_UPDATE", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED" }) do
        ns.Off(event, "LearnAll")
    end
    rest()
    if run then
        finish(run.asked and "the window closed before the game answered for " .. run.name or "the window closed")
    end
    -- the hint goes one frame later: the window can close inside the game's press of B
    changed()
end

-- One frame after the game's word that a trainer opened: its window is loaded and shown by then.
local function opened()
    local window = ns.Adapter.TrainerWindow()
    if open then
        -- the game says "a trainer opened" again for the one that is open
        step()
        return
    elseif not window then
        -- it is looked for again when a window takes the controller
        waiting = true
        note("the trainer's window was not shown one frame after the game's word: no hint yet", "window")
        return
    end
    open, waiting, run = true, false, nil
    look.Place(window)
    ns.On("TRAINER_UPDATE", "LearnAll", changed)
    -- a fight starts: the hint goes at once and Look.Key gives X back; it ends: the hold can begin again
    ns.On("PLAYER_REGEN_DISABLED", "LearnAll", refresh)
    ns.On("PLAYER_REGEN_ENABLED", "LearnAll", changed)
    step()
    local sum, count = Model.TrainerSum(services)
    note("a trainer opened: " .. count .. " to learn for " .. sum .. " copper, the gold is " .. money .. "; the hint shows: " .. tostring(hint:IsShown()))
    if count == 0 then
        local words, onLevel, onSkill = Model.TrainerWait(services, level)
        note("nothing to learn; " .. (words:match("Next at (.*)") and "next at " .. words:match("Next at (.*)") or "nothing waits")
            .. " (" .. onLevel .. " lines wait on a level, " .. onSkill .. " on a skill)", "next")
    end
end

-- Something changed: the trainer's list (it can say so several times in one frame), who has the
-- controller, a part of the suite. One look is made, at the next frame, never inside a press.
-- With no trainer and no hint nothing is done.
function changed()
    if not due and (open or waiting or hint:IsShown()) then
        due = true
        C_Timer.After(0, function()
            due = false
            if open then
                ns.Call("LearnAll", step)
            elseif waiting then
                ns.Call("LearnAll", opened)
            else
                rest()
                hint:Hide()
                keys.Set(false)
            end
        end)
    end
end

-- The hint, hidden, the key of ours that X clicks, and what the module hears.
local function build()
    -- the hint hangs on the screen and is put by the trainer's window when one opens
    look = Look.Hint("GamepadSuiteLearnAll", KEY, true)
    hint, label, line = look.frame, look.label, look.line
    cost = Theme.Text(hint, "body", "cream")
    cost:SetPoint("LEFT", label, "RIGHT", Theme.px(6), 0)
    keys = Look.Key("LearnAll", "GamepadSuiteLearnAllKey", KEY, press, note)

    ns.On("TRAINER_SHOW", "LearnAll", function()
        C_Timer.After(0, function()
            ns.Call("LearnAll", opened)
        end)
    end)
    ns.On("TRAINER_CLOSED", "LearnAll", closed)
    -- a window of the game or the settings window took the controller or gave it back, Mouse
    -- Mode, a wheel or the on-screen keyboard came or went
    Look.Watch("LearnAll", changed)
end

function LearnAll.OnLogin()
    -- the key's button is made out of a fight (Look.Key): after a reload in one it is made when
    -- the fight ends
    ns.Queue.Run("LearnAll", build)
end
