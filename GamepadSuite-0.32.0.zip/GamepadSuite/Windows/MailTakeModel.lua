-- The rules of Take All Mail (Windows/MailTake.lua), with no game calls: the next thing a run takes, what the letters
-- still hold, a take that went, what each letter gave, and the one chat line at the end of a run. The line names the
-- auction sales and who sent what, so the player does not open each letter to learn it.
--
-- A letter (Core/AdapterMail.lua): { money, cod, gm, items = { { slot, id, name, count } }, from, subject, days (the
-- days it has left), back (it came back to the player), reply (the game lets the player answer it: a player sent it),
-- invoice = { kind, item, count } or nil }. The game's own window reads the invoice of the open letter only
-- (Blizzard_MailFrame/MailFrame.lua 790); with none, a sale is read from the subject the game writes,
-- AUCTION_SOLD_MAIL_SUBJECT ("Auction successful: %s" in GlobalStrings.db2 of this build).
local _, ns = ...

local Model = {}

-- The room of the line: 240 letters with "Gamepad Suite: " before it.
Model.LIMIT = 225

-- Why a run ended with something left, for the chat line.
Model.WHY = { full = "Your bags are full", closed = "The inbox closed", fight = "Combat started", stopped = "You stopped it",
    silent = "The game gave no answer", refused = "The game refused some items", gold = "The game refused the gold of a letter",
    call = "The game did not take the call" }

local function plural(count, word)
    return count .. " " .. word .. (count == 1 and "" or "s")
end

-- The letters a player sees: a colour code is none, a picture (a coin) is one.
function Model.Width(text)
    return #(text:gsub("|T.-|t", "x"):gsub("|c%x%x%x%x%x%x%x%x", ""):gsub("|r", ""))
end

-- ---------------------------------------------------------------- the steps of a run
-- The next thing to take: the gold of the first letter that has some, else its first item. Letters with cash on
-- delivery or from a Game Master are passed. full: no item; failed: the items the game refused in this run. The take
-- keeps the letter as it was read: a letter can go when it is empty.
function Model.Next(letters, total, full, failed)
    for index, letter in ipairs(letters) do
        if not (letter.cod or letter.gm) then
            if letter.money > 0 then
                return { index = index, money = letter.money, total = total, letter = letter }
            end
            for _, item in ipairs(letter.items) do
                if not (full or failed[item.id]) then
                    return { index = index, slot = item.slot, id = item.id, name = item.name, count = item.count, total = total,
                        letter = letter }
                end
            end
        end
    end
end

-- What the letters that can be taken from still hold: items, copper, how many of them have gold; how many letters with
-- cash on delivery stay; and how many letters that still hold gold or items end within a day (a letter with only a
-- text loses nothing).
function Model.Left(letters)
    local items, copper, golds, cod, soon = 0, 0, 0, 0, 0
    for _, letter in ipairs(letters) do
        if letter.cod then
            cod = cod + 1
        elseif not letter.gm then
            items, copper = items + #letter.items, copper + letter.money
            golds = golds + (letter.money > 0 and 1 or 0)
        end
        if (letter.days or 1) < 1 and (letter.money > 0 or letter.items[1]) then
            soon = soon + 1
        end
    end
    return items, copper, golds, cod, soon
end

-- True when the thing asked for has left the inbox: its place is empty or holds another thing, its gold is 0, or the
-- letter is gone (the game's count of letters went down: a letter with no text of its own goes when it is empty; the
-- ones under it move up). The second value is true when the letter went.
function Model.Gone(letters, total, ask)
    local letter = letters[ask.index]
    if total < ask.total or not letter then
        return true, true
    elseif not ask.slot then
        return letter.money ~= ask.money, false
    end
    for _, item in ipairs(letter.items) do
        if item.slot == ask.slot then
            return item.id ~= ask.id or item.count ~= ask.count, false
        end
    end
    return true, false
end

-- A thing asked for came: it counts for its letter. fresh: the first thing of a letter.
function Model.Got(got, ask, fresh)
    if fresh or not got[1] then
        got[#got + 1] = { letter = ask.letter, copper = 0, items = {} }
    end
    local into = got[#got]
    if ask.slot then
        into.items[#into.items + 1] = { name = ask.name, count = ask.count }
    else
        into.copper = into.copper + (ask.money or 0)
    end
end

-- The items and the copper of a run.
function Model.Totals(got)
    local items, copper = 0, 0
    for _, each in ipairs(got) do
        items, copper = items + #each.items, copper + each.copper
    end
    return items, copper
end

-- ---------------------------------------------------------------- the letters
-- The game's format as a pattern: its magic letters as themselves, %s and %d caught.
local function pattern(format)
    return "^" .. format:gsub("[%(%)%.%+%-%*%?%[%]%^%$]", "%%%0"):gsub("%%s", "(.+)"):gsub("%%d", "(%%d+)") .. "$"
end

-- What a letter sold, with the count when the game says it: from a seller's invoice, else from the subject. nil for
-- a letter that is no sale (a buyer's invoice, a sale whose gold comes later, an auction that came back).
function Model.Sale(letter, words)
    local invoice = letter.invoice
    if invoice then
        if invoice.kind == "seller" and invoice.item then
            return invoice.item, invoice.count
        end
        return nil
    end
    local name = words.sold and letter.subject and letter.subject:match(pattern(words.sold))
    if not name then
        return nil
    end
    local item, count = nil, nil
    if words.stack then
        item, count = name:match(pattern(words.stack))
    end
    return item or name, count and tonumber(count)
end

-- The player who sent a letter, or nil: the auction house and the people of the game cannot be answered, a Game
-- Master is not named, and a letter of the player's own that came back is not from the one it went to.
function Model.Player(letter)
    return letter.reply and not (letter.gm or letter.back or letter.invoice) and letter.from or nil
end

-- The kinds of letter in the inbox, for the log: what the game gives for letters that are not open.
function Model.Census(letters, words)
    local invoices, counts, parts = {}, {}, {}
    for _, letter in ipairs(letters) do
        local kind = letter.invoice and tostring(letter.invoice.kind)
            or Model.Sale(letter, words) and "sale subject with no invoice"
            or not (letter.money > 0 or letter.items[1]) and "with text only"
            or Model.Player(letter) and "from a player" or "from no player"
        if letter.invoice and not counts[kind] then
            invoices[#invoices + 1] = kind
        end
        counts[kind] = (counts[kind] or 0) + 1
    end
    for _, kind in ipairs(invoices) do
        parts[#parts + 1] = plural(counts[kind], "invoice") .. " (" .. kind .. ")"
    end
    for _, kind in ipairs({ "sale subject with no invoice", "from a player", "with text only", "from no player" }) do
        if counts[kind] then
            parts[#parts + 1] = counts[kind] .. " " .. kind
        end
    end
    return "the run read " .. plural(#letters, "header") .. ": " .. table.concat(parts, ", ")
end

-- ---------------------------------------------------------------- the line
-- "Linen Cloth x20", or the name alone for one.
local function named(name, count)
    return name .. ((count or 1) > 1 and (" x" .. count) or "")
end

-- The sales ("Linen Cloth x20 for 1g 20s"; the same item is one, with a count only when every sale had one) and the
-- senders ({ name, list }: gold first, the same item is one), in the order of the run.
local function lists(got, coin, words)
    local sales, sold, senders, from = {}, {}, {}, {}
    for _, each in ipairs(got) do
        local item, count = Model.Sale(each.letter, words)
        local player = not item and Model.Player(each.letter)
        if item then
            if not sold[item] then
                sold[item] = { item = item, count = 0, copper = 0 }
                sales[#sales + 1] = sold[item]
            end
            local sale = sold[item]
            sale.count = count and sale.count and sale.count + count or nil
            sale.copper = sale.copper + each.copper
        elseif player then
            if not from[player] then
                from[player] = { name = player, copper = 0, order = {}, counts = {} }
                senders[#senders + 1] = from[player]
            end
            local sender = from[player]
            sender.copper = sender.copper + each.copper
            for _, thing in ipairs(each.items) do
                if not sender.counts[thing.name] then
                    sender.order[#sender.order + 1] = thing.name
                end
                sender.counts[thing.name] = (sender.counts[thing.name] or 0) + thing.count
            end
        end
    end
    for i, sale in ipairs(sales) do
        sales[i] = named(sale.item, sale.count) .. (sale.copper > 0 and (" for " .. coin(sale.copper)) or "")
    end
    for _, sender in ipairs(senders) do
        sender.list = { sender.copper > 0 and coin(sender.copper) or nil }
        for _, name in ipairs(sender.order) do
            sender.list[#sender.list + 1] = named(name, sender.counts[name])
        end
    end
    return sales, senders
end

-- "Sold: a, b and 3 more." with as many of list as fit in room letters; with none, zero.
local function cut(head, list, room, zero)
    for shown = #list, 1, -1 do
        local text = head .. table.concat(list, ", ", 1, shown) .. (shown < #list and (" and " .. (#list - shown) .. " more") or "") .. "."
        if Model.Width(text) <= room then
            return text
        end
    end
    return zero
end

local function things(items, copper, coin)
    local parts = {}
    if items > 0 then
        parts[#parts + 1] = plural(items, "item")
    end
    if copper > 0 then
        parts[#parts + 1] = coin(copper)
    end
    return parts[1] and table.concat(parts, " and ") or nil
end

-- The one chat line at the end of a run: what was taken, what sold, who sent what, why the run ended and what is left,
-- the letters with COD, and the letters left that end within a day. rest: { items, copper, cod, soon } (Model.Left);
-- why: a text of Model.WHY or nil; coin: copper to the game's coin text. The lists are cut to keep the line in its room;
-- the rest is never cut.
function Model.Line(got, rest, why, coin, words)
    local items, copper = Model.Totals(got)
    local took = things(items, copper, coin)
    local parts = { took and ("took " .. took .. " from " .. plural(#got, "letter") .. ".") or "took nothing." }
    local tail = {}
    if why then
        local left = things(rest.items, rest.copper, coin)
        local verb = (rest.items > 1 or (rest.items > 0 and rest.copper > 0)) and " are" or " is"
        tail[#tail + 1] = why .. (left and (": " .. left .. verb .. " left.") or ".")
    end
    if rest.cod > 0 then
        tail[#tail + 1] = plural(rest.cod, "letter") .. " with COD " .. (rest.cod == 1 and "stays." or "stay.")
    end
    if rest.soon > 0 then
        tail[#tail + 1] = plural(rest.soon, "letter") .. " left in the inbox " .. (rest.soon == 1 and "expires" or "expire")
            .. " within a day."
    end
    local sales, senders = lists(got, coin, words)
    local room = Model.LIMIT - Model.Width(parts[1] .. " " .. table.concat(tail, " "))
    local function add(text)
        parts[#parts + 1] = text
        room = room - Model.Width(text) - 1
    end
    local more = senders[1] and Model.Width("From " .. #senders .. " more players.") + 1 or 0
    if sales[1] then
        add(cut("Sold: ", sales, room - 1 - more, plural(#sales, "auction") .. " sold."))
    end
    for i, sender in ipairs(senders) do
        local text = cut("From " .. sender.name .. ": ", sender.list, room - 1 - (i < #senders and more or 0))
        if not text then
            add("From " .. plural(#senders - i + 1, i == 1 and "player" or "more player") .. ".")
            break
        end
        add(text)
    end
    for _, text in ipairs(tail) do
        parts[#parts + 1] = text
    end
    return table.concat(parts, " ")
end

if ns then
    ns.MailTakeModel = Model
end
return Model
