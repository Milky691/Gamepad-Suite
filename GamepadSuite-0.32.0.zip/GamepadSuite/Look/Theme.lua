-- The look, in one place: the colours, the type sizes, two fonts, the game's own art by path.
-- Sizes in the windows are written as they are in the approved mockup (a 1600 x 900 screen)
-- and scaled here to the game's 768-high screen.
local _, ns = ...

local Theme = {}
ns.Theme = Theme

local K = 768 / 900
function Theme.px(n)
    return n * K
end

Theme.color = {
    gold = { 0.957, 0.800, 0.384 },
    goldDeep = { 0.765, 0.604, 0.271 },
    cream = { 0.937, 0.898, 0.792 },
    muted = { 0.647, 0.612, 0.525 },
    dim = { 0.435, 0.408, 0.345 },
    ink = { 0.114, 0.067, 0.031 },
    inkRed = { 0.239, 0.063, 0.024 },
    white = { 1, 0.973, 0.886 },
    -- the green of the A button's letter: the plus of an empty slot of a wheel ("press A here")
    green = { 0.624, 0.851, 0.369 },
    -- the one red (too far, an interrupt, a target past every reach or under attack, short of gold), the one blue
    -- (short of mana, rage or energy) and the one grey ("cannot be used now", HudFace.Unusable) of every part: the
    -- numbers of the game's own action buttons
    red = { 0.85, 0.15, 0.15 },
    blue = { 0.5, 0.5, 1 },
    grey = { 0.4, 0.4, 0.4 },
    -- the edge of the parchment page, the edge of a picture, the veil under a box, the dark ground of a panel
    paperEdge = { 0.42, 0.37, 0.29 },
    iconEdge = { 0.84, 0.70, 0.38 },
    veil = { 0.016, 0.012, 0.008 },
    ground = { 0.035, 0.03, 0.025 },
}

-- The type sizes, mockup units (Theme.Text scales them). Every line of text uses one of these.
-- glyph is the size of a button picture in a strip of hints. talk is the reading text of Dialogue View (decision 95).
Theme.size = { tiny = 13, small = 15, body = 16.5, row = 18, name = 21, title = 34, head = 40, glyph = 26, talk = 28 }

Theme.font = {
    text = "Fonts\\FRIZQT__.TTF",
    display = "Fonts\\MORPHEUS.TTF",
}

Theme.art = {
    marble = "Interface\\FrameGeneral\\UI-Background-Marble",
    edgeGold = "Interface\\DialogFrame\\UI-DialogBox-Gold-Border",
    edgeThin = "Interface\\Tooltips\\UI-Tooltip-Border",
    levelUp = "Interface\\LevelUp\\LevelUpTex",
    rowLight = "Interface\\QuestFrame\\UI-QuestTitleHighlight",
    parchment = "Interface\\AchievementFrame\\UI-Achievement-Parchment-Horizontal",
    circle = "Interface\\CharacterFrame\\TempPortraitAlphaMask",
    white = "Interface\\Buttons\\WHITE8X8",
    padXbox = "Interface\\AddOns\\GamepadSuite\\Art\\PadXbox.tga",
    padDeck = "Interface\\AddOns\\GamepadSuite\\Art\\PadDeck.tga",
    padPS = "Interface\\AddOns\\GamepadSuite\\Art\\PadPS.tga",
    padSwitch = "Interface\\AddOns\\GamepadSuite\\Art\\PadSwitch.tga",
}
-- the gold line piece inside LevelUpTex
Theme.goldLineCoords = { 0.00195313, 0.81835938, 0.01953125, 0.03320313 }

function Theme.Color(name, alpha)
    local c = Theme.color[name]
    return c[1], c[2], c[3], alpha or 1
end

-- A colour as the code a chat line or a text uses in front of coloured words: "|cfff4cc62".
function Theme.Hex(name)
    local c = Theme.color[name]
    return string.format("|cff%02x%02x%02x", c[1] * 255 + 0.5, c[2] * 255 + 0.5, c[3] * 255 + 0.5)
end

-- A line of text. size is a mockup size, or the name of one of Theme.size. On dark ground it gets the game's
-- usual black shadow.
function Theme.Text(parent, size, colorName, display, onPaper)
    size = Theme.size[size] or size
    local text = parent:CreateFontString(nil, "OVERLAY")
    text:SetFont(display and Theme.font.display or Theme.font.text, Theme.px(size), "")
    text:SetTextColor(Theme.Color(colorName))
    if not onPaper then
        text:SetShadowColor(0, 0, 0, 1)
        text:SetShadowOffset(1, -1)
    end
    text:SetJustifyH("LEFT")
    text:SetWordWrap(false)
    return text
end

function Theme.Fill(parent, layer, r, g, b, a)
    local texture = parent:CreateTexture(nil, layer or "BACKGROUND")
    texture:SetColorTexture(r, g, b, a or 1)
    return texture
end
