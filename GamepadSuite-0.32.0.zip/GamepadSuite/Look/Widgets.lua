-- Shared parts: a button picture, and the controller picture with button pictures on top.
local _, ns = ...

local Theme, Adapter = ns.Theme, ns.Adapter
local Widgets = {}
ns.Widgets = Widgets

local LABEL = {
    A = "A", B = "B", X = "X", Y = "Y", LB = "LB", RB = "RB", LT = "LT", RT = "RT",
    DU = "+", DD = "+", DL = "+", DR = "+", DPAD = "+", LS = "L", RS = "R", VW = "=", MN = "=", GD = "O",
    L4 = "L4", L5 = "L5", R4 = "R4", R5 = "R5",
}
local LABEL_COLOR = {
    A = { 0.62, 0.85, 0.37 }, B = { 0.94, 0.44, 0.36 }, X = { 0.41, 0.70, 0.96 }, Y = { 0.96, 0.80, 0.29 },
}
local live = {} -- every button picture, so all can follow a change of controller

-- A button picture. It shows the game's own picture when the game has one for this button,
-- and a plain drawn one when it has none (back grips, or an old game build).
function Widgets.Glyph(parent, key, size)
    local glyph = CreateFrame("Frame", nil, parent)
    glyph:SetSize(size, size)

    -- a lit button gets the game's own gold ring (the one around an equipped item on a bar)
    glyph.glow = glyph:CreateTexture(nil, "OVERLAY")
    glyph.glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    glyph.glow:SetVertexColor(Theme.Color("gold"))
    glyph.glow:SetBlendMode("ADD")
    glyph.glow:SetPoint("CENTER")
    glyph.glow:Hide()

    glyph.disc = glyph:CreateTexture(nil, "BORDER")
    glyph.disc:SetTexture(Theme.art.circle)
    glyph.disc:SetVertexColor(0.09, 0.09, 0.11, 1)
    glyph.disc:SetAllPoints()

    glyph.icon = glyph:CreateTexture(nil, "ARTWORK")
    glyph.icon:SetAllPoints()

    glyph.label = glyph:CreateFontString(nil, "OVERLAY")
    glyph.label:SetPoint("CENTER")

    function glyph:SetKey(newKey)
        self.key = newKey
        local atlas = Adapter.IconAtlas(newKey)
        local drawn = false
        if atlas then
            drawn = pcall(self.icon.SetAtlas, self.icon, atlas)
        end
        self.icon:SetShown(drawn)
        self.disc:SetShown(not drawn)
        self.label:SetShown(not drawn)
        if not drawn then
            local text = LABEL[newKey] or newKey
            local width = self:GetWidth()
            self.label:SetFont(Theme.font.text, width * (#text > 1 and 0.40 or 0.52), "")
            self.label:SetText(text)
            local c = LABEL_COLOR[newKey] or Theme.color.cream
            self.label:SetTextColor(c[1], c[2], c[3])
        end
    end

    function glyph:SetGlyphSize(newSize)
        self.baseSize = newSize
        self:SetSize(newSize, newSize)
        self.glow:SetSize(newSize * 1.7, newSize * 1.7)
        if self.key then
            self:SetKey(self.key)
        end
    end

    -- A lit button grows by its size, not by its scale: a scale would also move it.
    function glyph:SetLit(lit)
        self.glow:SetShown(lit and true or false)
        local size = self.baseSize * (lit and 1.2 or 1)
        self:SetSize(size, size)
    end

    glyph:SetGlyphSize(size)
    glyph:SetKey(key)
    live[#live + 1] = glyph
    return glyph
end

-- Where each button sits on each drawing. Numbers are in the drawing's own units.
local PAD = {
    xbox = {
        art = "padXbox", width = 600, height = 400, bottom = 683 / 1024, glyph = 0.0545,
        at = {
            LT = { 132, 22 }, RT = { 468, 22 }, LB = { 176, 68 }, RB = { 424, 68 },
            LS = { 172, 150 }, RS = { 366, 226 },
            DU = { 238, 198 }, DD = { 238, 254 }, DL = { 210, 226 }, DR = { 266, 226 },
            Y = { 430, 116 }, X = { 396, 150 }, B = { 464, 150 }, A = { 430, 184 },
            VW = { 272, 150 }, MN = { 328, 150 }, GD = { 300, 104 },
        },
        order = { "LT", "LB", "LS", "VW", "DU", "DL", "DR", "DD", "RT", "RB", "Y", "B", "MN", "X", "A", "RS" },
    },
    ps = {
        art = "padPS", width = 600, height = 400, bottom = 683 / 1024, glyph = 0.0545,
        at = {
            LT = { 130, 42 }, RT = { 470, 42 }, LB = { 160, 86 }, RB = { 440, 86 },
            DU = { 150, 122 }, DD = { 150, 178 }, DL = { 122, 150 }, DR = { 178, 150 },
            LS = { 222, 226 }, RS = { 378, 226 },
            Y = { 450, 118 }, X = { 418, 150 }, B = { 482, 150 }, A = { 450, 182 },
            VW = { 214, 96 }, MN = { 386, 96 }, GD = { 300, 174 },
        },
    },
    switch = {
        art = "padSwitch", width = 600, height = 400, bottom = 683 / 1024, glyph = 0.0545,
        at = {
            LT = { 132, 34 }, RT = { 468, 34 }, LB = { 172, 76 }, RB = { 428, 76 },
            LS = { 168, 156 }, RS = { 372, 232 },
            DU = { 231, 204 }, DD = { 231, 260 }, DL = { 203, 232 }, DR = { 259, 232 },
            Y = { 436, 122 }, X = { 402, 156 }, B = { 470, 156 }, A = { 436, 190 },
            VW = { 262, 136 }, MN = { 338, 136 }, GD = { 326, 186 },
        },
    },
    deck = {
        art = "padDeck", width = 1000, height = 400, bottom = 410 / 512, glyph = 0.036,
        at = {
            LT = { 150, 14 }, RT = { 850, 14 }, LB = { 172, 36 }, RB = { 828, 36 },
            DU = { 126, 99 }, DD = { 126, 149 }, DL = { 101, 124 }, DR = { 151, 124 },
            LS = { 218, 140 }, RS = { 782, 140 },
            Y = { 874, 94 }, A = { 874, 154 }, X = { 844, 124 }, B = { 904, 124 },
            VW = { 250, 82 }, MN = { 750, 82 },
            L4 = { 118, 365 }, L5 = { 182, 368 }, R4 = { 882, 365 }, R5 = { 818, 368 },
        },
        order = { "LT", "LB", "DU", "DL", "DR", "DD", "LS", "VW", "L4", "L5", "RT", "RB", "Y", "B", "X", "A", "RS", "MN", "R4", "R5" },
    },
}
Widgets.PAD = PAD

-- The controller picture: our own body art, with a button picture on each button.
function Widgets.Pad(parent, width)
    local pad = CreateFrame("Frame", nil, parent)
    pad.body = pad:CreateTexture(nil, "ARTWORK")
    pad.body:SetAllPoints()
    pad.glyphs = {}

    function pad:SetStyle(styleName, newWidth)
        local style = PAD[styleName] or PAD.xbox
        self.style, self.styleName = style, styleName
        width = newWidth or width
        self:SetSize(width, width * style.height / style.width)
        self.body:SetTexture(Theme.art[style.art])
        self.body:SetTexCoord(0, 1, 0, style.bottom)
        local unit = width / style.width
        for _, glyph in pairs(self.glyphs) do
            glyph:Hide()
        end
        for key, at in pairs(style.at) do
            local glyph = self.glyphs[key]
            if not glyph then
                glyph = Widgets.Glyph(self, key, 10)
                self.glyphs[key] = glyph
            end
            glyph:SetGlyphSize(width * style.glyph)
            glyph:ClearAllPoints()
            glyph:SetPoint("CENTER", self, "TOPLEFT", at[1] * unit, -at[2] * unit)
            glyph:SetLit(false)
            glyph:Show()
        end
    end

    -- keys: a list of our key names to light. Others go dark.
    function pad:SetLit(keys)
        local lit = {}
        for _, key in ipairs(keys or {}) do
            lit[key] = true
        end
        for key, glyph in pairs(self.glyphs) do
            if glyph:IsShown() then
                glyph:SetLit(lit[key])
            end
        end
    end

    -- Where a button is, as an offset from the picture's top left corner.
    function pad:ButtonOffset(key)
        local at = self.style.at[key]
        if not at then
            return nil
        end
        local unit = self:GetWidth() / self.style.width
        return at[1] * unit, -at[2] * unit
    end

    pad:SetStyle("xbox", width)
    return pad
end

-- Which drawing fits the controller in use. The player can set it by hand in System.
function Widgets.PadStyle()
    local choice = ns.Registry.Get("system.controller")
    local byChoice = { ["Steam Deck"] = "deck", ["Xbox style"] = "xbox", ["PlayStation style"] = "ps", ["Nintendo style"] = "switch" }
    if byChoice[choice] then
        return byChoice[choice]
    end
    local info = Adapter.DeviceInfo()
    local name = ((info.name or "") .. " " .. (info.rawName or "")):lower()
    if name:find("deck", 1, true) or (info.screenWidth == 1280 and info.screenHeight == 800) then
        return "deck"
    end
    -- the game's own name for the button style of the controller: shapes, or the reversed letters
    local byLabel = { Shapes = "ps", Reverse = "switch" }
    return byLabel[info.labelStyle or ""] or "xbox"
end

-- A row of small button pictures, left to right: the buttons of a bind, held ones first (RT, A). size and gap are
-- in the mockup's units. The frame is as wide as its pictures (row.glyphs), so it can sit centered above a fixed
-- slot or at the right end of a line. row.Set(keys) shows them; with no keys the row does not show.
function Widgets.Keys(parent, size, gap)
    local px = Theme.px
    local row = CreateFrame("Frame", nil, parent)
    row:SetSize(1, px(size))
    local glyphs = {}
    row.glyphs = glyphs
    function row.Set(keys)
        local count = keys and #keys or 0
        row:SetShown(count > 0)
        row:SetWidth(math.max(1, px(count * size + (count - 1) * gap)))
        for i = 1, math.max(count, #glyphs) do
            if i > count then
                glyphs[i]:Hide()
            else
                glyphs[i] = glyphs[i] or Widgets.Glyph(row, keys[i], px(size))
                glyphs[i]:SetKey(keys[i])
                glyphs[i]:SetPoint("LEFT", row, "LEFT", px((i - 1) * (size + gap)), 0)
                glyphs[i]:Show()
            end
        end
    end
    return row
end

-- A strip of button hints, the one look of every strip: button pictures (Theme.size.glyph) and a word (body, cream)
-- for each entry, from the strip's side ("LEFT" or "RIGHT"). strip.Set({ { keys, text, off (dim), br (a new line) } })
-- makes it as wide as they are; strip.items[i] is { keys, text, key } of the i-th entry from that side. onClick(key),
-- when given: a click on a picture presses its button, a click on a word the entry's first one (mouse mode's click too).
function Widgets.Legend(parent, side, onClick)
    local px, size = Theme.px, Theme.size
    local strip = CreateFrame("Frame", nil, parent)
    strip:SetSize(1, px(size.glyph))
    strip.items = {}
    local function item(i)
        local it = strip.items[i]
        if not it then
            it = CreateFrame(onClick and "Button" or "Frame", nil, strip)
            it:SetHeight(px(size.glyph))
            it.keys = Widgets.Keys(it, size.glyph, 4)
            it.keys:SetPoint("LEFT")
            it.text = Theme.Text(it, "body", "cream")
            it.text:SetPoint("LEFT", it.keys, "RIGHT", px(6), 0)
            if onClick then
                it:RegisterForClicks("LeftButtonUp")
                it:SetScript("OnClick", function(_, mouse) if mouse == "LeftButton" then onClick(it.key) end end)
            end
            strip.items[i] = it
        end
        return it
    end
    function strip.Set(entries)
        local x, y, widest, count = 0, 0, 0, #entries
        for i = 1, math.max(count, #strip.items) do
            local entry, it = entries[side == "RIGHT" and count + 1 - i or i], item(i)
            it:SetShown(entry ~= nil)
            if entry then
                if entry.br and x > 0 then widest, x, y = math.max(widest, x - px(24)), 0, y - px(size.glyph + 8) end
                it.key = entry.keys[1]
                it.keys.Set(entry.keys)
                it.text:SetText(entry.text)
                it.text:SetTextColor(Theme.Color("cream"))
                it:SetAlpha(entry.off and 0.35 or 1)
                it:SetWidth(it.keys:GetWidth() + px(6) + it.text:GetStringWidth())
                it:ClearAllPoints()
                it:SetPoint(side, strip, side, side == "RIGHT" and -x or x, y)
                x = x + it:GetWidth() + px(24)
                for _, glyph in ipairs(onClick and it.keys.glyphs or {}) do
                    glyph:EnableMouse(true)
                    glyph:SetScript("OnMouseUp", function(_, mouse) if mouse == "LeftButton" then onClick(glyph.key) end end)
                end
            end
        end
        strip:SetWidth(math.max(1, widest, x - px(24)))
    end
    return strip
end

-- The bar of every hold: a gold line along parent's foot, inset in from its sides and foot. line:SetPart(0 to 1).
function Widgets.HoldLine(parent, inset)
    inset = Theme.px(inset or 0)
    local line = Theme.Fill(parent, "OVERLAY", Theme.Color("gold"))
    line:SetHeight(Theme.px(3))
    line:SetPoint("BOTTOMLEFT", inset, inset)
    line:Hide()
    function line:SetPart(part)
        self:SetShown(part > 0)
        if part > 0 then
            self:SetWidth(math.max(1, (parent:GetWidth() - 2 * inset) * math.min(part, 1)))
        end
    end
    return line
end

function Widgets.RefreshGlyphs()
    for _, glyph in ipairs(live) do
        if glyph.key then
            glyph:SetKey(glyph.key)
        end
    end
end

-- The look of a control that goes to another page (a row that opens a page, More, Next, Back): the spellbook's
-- page arrow at its right edge with a soft gold glow behind it, and (by the caller) a gold name. A control that
-- changes a value has neither. One frame for each row or cell: nav:Set("next"), nav:Set("back") or nav:Set(nil).
local NAV_ART = { next = "Interface\\Buttons\\UI-SpellbookIcon-NextPage-Up", back = "Interface\\Buttons\\UI-SpellbookIcon-PrevPage-Up" }

function Widgets.Nav(parent)
    local px = Theme.px
    local nav = CreateFrame("Frame", nil, parent)
    nav:SetSize(px(26), px(26))
    nav:SetPoint("RIGHT", -px(14), 0)
    local glow = nav:CreateTexture(nil, "ARTWORK")
    glow:SetTexture("Interface\\Buttons\\UI-ActionButton-Border")
    glow:SetBlendMode("ADD")
    glow:SetVertexColor(Theme.Color("gold", 0.7))
    glow:SetSize(px(54), px(54))
    glow:SetPoint("CENTER")
    local arrow = nav:CreateTexture(nil, "OVERLAY")
    arrow:SetAllPoints()

    function nav:Set(way)
        self:SetShown(way ~= nil)
        arrow:SetTexture(NAV_ART[way])
    end

    nav:Set(nil)
    return nav
end

-- Puts a picture on a texture: a file of the game (a path or a file number, cut in a little to hide the icon's own
-- edge), or the name of a part of one of the game's sheets (no backslash: the game's own Jump picture), whole.
function Widgets.Art(texture, icon)
    if type(icon) == "string" and not icon:find("\\", 1, true) then
        if not pcall(texture.SetAtlas, texture, icon) then
            texture:SetTexture(nil)
        end
    else
        texture:SetTexture(icon)
        texture:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    end
end

-- A square picture box for a spell, an item or a game action: the game's icon, cut in a little to hide the icon's
-- own edge, in a dark well with a thin edge. With no icon the edge is faint.
function Widgets.Icon(parent, size)
    local px = Theme.px
    local box = CreateFrame("Frame", nil, parent)
    box:SetSize(size, size)
    box.edge = box:CreateTexture(nil, "BACKGROUND", nil, 1)
    box.edge:SetPoint("TOPLEFT", -px(2), px(2))
    box.edge:SetPoint("BOTTOMRIGHT", px(2), -px(2))
    local black = box:CreateTexture(nil, "BACKGROUND", nil, 2)
    black:SetColorTexture(0, 0, 0, 1)
    black:SetPoint("TOPLEFT", -px(1), px(1))
    black:SetPoint("BOTTOMRIGHT", px(1), -px(1))
    local well = box:CreateTexture(nil, "BORDER")
    well:SetColorTexture(Theme.Color("ground"))
    well:SetAllPoints()
    box.art = box:CreateTexture(nil, "ARTWORK")
    box.art:SetAllPoints()
    box.art:SetTexCoord(0.08, 0.92, 0.08, 0.92)

    -- icon is a texture path or a file number, or nil for an empty box. carried gives the full gold edge.
    function box:SetIcon(icon, carried)
        Widgets.Art(self.art, icon)
        self.art:SetShown(icon ~= nil)
        if carried then
            self.edge:SetColorTexture(Theme.Color("gold"))
        elseif icon then
            self.edge:SetColorTexture(Theme.Color("iconEdge", 0.5))
        else
            self.edge:SetColorTexture(1, 0.94, 0.78, 0.14)
        end
    end

    -- How strongly the picture shows: 1 for a bind of its own; less, and grey, for one that comes from another set.
    function box:SetStrength(alpha, grey)
        self.art:SetAlpha(alpha)
        self.art:SetDesaturated(grey)
    end

    -- A colour over the picture: red for a target too far, blue for short of mana, grey for cannot be used.
    function box:SetTint(r, g, b)
        self.art:SetVertexColor(r, g, b)
    end

    box:SetIcon(nil)
    return box
end
