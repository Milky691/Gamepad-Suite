-- The form or stance the player is in, shown between the two groups of on-screen buttons: the game's picture of it,
-- in the shape of the buttons, and its name under it (the owner, 2026-10-17: "there's no stance indicator on warriors
-- ... i dont know what stance im in"). The game's own stance bar is hidden in gamepad mode
-- (Blizzard_ActionBar/Shared/MainActionBar.lua 31 to 40), and the Form Ring marks only the buttons with a bind of
-- their own in the form, which a warrior often has none of. It follows the row Form Ring, and dims and hides with the
-- buttons (it is a part of their frame). Nothing runs on a timer: the game's events for a form tell of each change.
local _, ns = ...

local Form = ns.Module("FormIcon", { "forms" }, "Form and Stance Picture")
ns.HudForm = Form

local Theme = ns.Theme
local px = Theme.px

local SIZE = 34
local holder, icon, name
local told = false

-- The picture, made again when the buttons' look changes (its shape is the look's).
local function picture()
    if icon then
        icon:Hide()
    end
    icon = holder:CreateTexture(nil, "ARTWORK")
    icon:SetAllPoints()
    ns.HudFace.Shape(icon, ns.HudModel.Look(ns.Registry.Get("screen.look")), SIZE)
end

local function update()
    local form = ns.Registry.Get("screen.form_ring") and ns.Adapter.ActiveForm() or nil
    holder:SetShown(form ~= nil)
    if form then
        icon:SetTexture(form.icon)
        name:SetText(form.name)
        if not told then
            told = true
            ns.Log.Add("form", "the form or stance shows between the buttons: " .. form.name)
        end
    end
end

function Form.OnLogin()
    local screen = _G.GamepadSuiteScreen
    if not screen then
        return
    end
    holder = CreateFrame("Frame", "GamepadSuiteFormIcon", screen)
    holder:SetSize(px(SIZE), px(SIZE))
    holder:SetPoint("BOTTOM", screen, "BOTTOM", 0, px(28))
    picture()
    name = Theme.Text(holder, "small", "cream")
    name:SetPoint("TOP", holder, "BOTTOM", 0, -px(3))
    for _, event in ipairs({ "UPDATE_SHAPESHIFT_FORM", "UPDATE_SHAPESHIFT_FORMS", "PLAYER_ENTERING_WORLD" }) do
        pcall(ns.On, event, "FormIcon", update)
    end
    ns.Listen("setting", "FormIcon", function(key)
        if key == "screen.look" then
            picture()
            update()
        elseif key == "screen.form_ring" then
            update()
        end
    end)
    update()
end
