-- A button above the game menu that opens the settings: Y on the controller, or a click. The
-- game menu is the one window a controller player can always reach.
-- The button is no child of the game menu: it is a child of the whole screen, placed over the
-- menu and shown and hidden with it, one frame after the menu shows or hides. The game's
-- navigation takes in every button under a window it has (Core/AdapterGameWindows.lua), and
-- ControllerForever found that a button of its own in the game menu made the game block the
-- addon at the menu's own buttons (ControllerForever_Menu.lua 7496 to 7502). So the game's D-pad
-- does not stop on it; Y and the mouse do.
-- The game menu is left open under the settings window. Addon code that closes it would run
-- Blizzard's own code for "a window closed" as addon code, and that code writes the bar in use of
-- the game's own gamepad bar: the next press of a game action could then be refused. The menu
-- keeps the game's focus, so the game's arrow beside its selected button is hidden while the
-- settings window shows (Core/AdapterWindow.lua, HideFocusArrow).
-- Y: while the game menu shows, Blizzard has the controller and holds Y with a priority bind that
-- does nothing. For that time this button takes Y with a priority bind of its own. It is set one
-- frame after the menu shows, so that it is the newer of the two. Out of a fight only. The log
-- says if Y is set: only the game can tell which of two such binds wins.
-- In a fight the window does not open and Y is not ours, so the button is not shown then.
-- The game's radial Main Menu (Blizzard_Gamepad/UI/Radials/GamepadRadial.lua) gets a small hint of
-- ours in the same way: Y, the addon's picture and "Gamepad Suite", over the menu's title, while the
-- menu shows. The game tells of its show and hide by two messages of its own (GamepadRadial.lua 553
-- and 563); nothing of ours goes into its frames, which are only read for the place. Y on that menu is
-- the game's Report Issue on this beta (Blizzard_PTRFeedback/Blizzard_PTRFeedback_Gamepad.lua 14, a
-- priority bind of the game's): while the hint shows, Y is the hint's, taken as on the game menu, and
-- opens the settings over the radial menu. Every other button stays the game's: a bind takes one key,
-- and no frame of ours hears the buttons. In a fight, and while the settings window shows, the hint is
-- gone and Y is the game's Report Issue again.
local _, ns = ...

local Menu = ns.Module("MenuButton", { "backdrop" }, "Game Menu Button")
ns.MenuButton = Menu

local button, menu, hint
local told, toldRadial
local radial = false   -- the game's radial Main Menu shows
-- clicked: the mouse went down on a button of ours, so the click that comes is the mouse's; a click
-- with no mouse before it comes from the bind on Y. heard: the ways already in the log.
local clicked, heard = false, {}

-- what: the button or the hint, for the log
local function open(what)
    return function()
        local by = clicked and "a click" or "Y"
        clicked = false
        if not heard[what .. by] then
            heard[what .. by] = true
            ns.Log.Add("menu", what .. " was pressed by " .. by .. ": the settings window is asked to open")
        end
        if not ns.Adapter.InCombat() then
            ns.Send("settings:open")
        end
    end
end

local function mouseDown()
    clicked = true
end

-- The button is as wide as the game menu (256 of the game's units) and higher than one of the
-- menu's own buttons (51 units to their 36), so the player sees it at once. It stands over the
-- menu's top edge, clear of the menu's title plate, which reaches 11 units over that edge
-- (Blizzard_SharedXML/Shared/Dialog/DialogTemplates.xml 21). The menu's own buttons are all
-- under the edge, so it covers none of them at any UI scale.
local function build()
    local Theme, px = ns.Theme, ns.Theme.px
    button = CreateFrame("Button", "GamepadSuiteMenuButton", UIParent)
    button:SetFrameStrata("DIALOG")
    button:Hide()
    button:SetSize(px(300), px(60))
    button:SetPoint("BOTTOM", menu, "TOP", 0, px(16))
    Theme.Fill(button, "BACKGROUND", 0.04, 0.035, 0.03, 0.92):SetAllPoints()
    -- a soft gold ground, and a full gold line round it
    Theme.Fill(button, "BORDER", Theme.Color("gold", 0.14)):SetAllPoints()
    for _, side in ipairs({ { "TOPLEFT", "TOPRIGHT" }, { "BOTTOMLEFT", "BOTTOMRIGHT" }, { "TOPLEFT", "BOTTOMLEFT" }, { "TOPRIGHT", "BOTTOMRIGHT" } }) do
        local line = Theme.Fill(button, "ARTWORK", Theme.Color("gold"))
        line:SetPoint(side[1])
        line:SetPoint(side[2])
        line:SetSize(px(2.5), px(2.5))
    end
    local glyph = ns.Widgets.Glyph(button, "Y", px(40))
    glyph:SetPoint("LEFT", button, "LEFT", px(18), 0)
    -- the addon's own picture, the one the game's addon list shows: it is the picture of the
    -- key binding that this button runs. The game says if the file loaded, and the log keeps it.
    local art = button:CreateTexture(nil, "ARTWORK")
    local loaded = art:SetTexture(ns.Catalog.CommandIcon("GAMEPADSUITE_TOGGLE"))
    ns.Log.Add("menu", "the addon's picture " .. (loaded and "loaded" or "did not load: is Art\\Icon.tga in the addon folder"))
    art:SetSize(px(40), px(40))
    art:SetPoint("LEFT", glyph, "RIGHT", px(12), 0)
    local label = Theme.Text(button, "name", "gold", true)
    label:SetPoint("LEFT", art, "RIGHT", px(12), 0)
    label:SetText("Gamepad Suite")
    button:SetScript("OnMouseDown", mouseDown)
    button:SetScript("OnClick", open("the button"))
end

-- The hint on the radial menu: the parts of the button, smaller and with no plate, as the game's own
-- hints of a button stand on its menus. It is kept on the screen at any UI scale.
local function buildHint()
    local Theme, px = ns.Theme, ns.Theme.px
    hint = CreateFrame("Button", "GamepadSuiteRadialButton", UIParent)
    hint:SetFrameStrata("DIALOG")
    hint:SetClampedToScreen(true)
    hint:Hide()
    hint:SetSize(px(190), px(34))
    local glyph = ns.Widgets.Glyph(hint, "Y", px(26))
    glyph:SetPoint("LEFT", hint, "LEFT", 0, 0)
    local art = hint:CreateTexture(nil, "ARTWORK")
    art:SetTexture(ns.Catalog.CommandIcon("GAMEPADSUITE_TOGGLE"))
    art:SetSize(px(26), px(26))
    art:SetPoint("LEFT", glyph, "RIGHT", px(8), 0)
    local label = Theme.Text(hint, "row", "gold", true)
    label:SetPoint("LEFT", art, "RIGHT", px(8), 0)
    label:SetText("Gamepad Suite")
    hint:SetScript("OnMouseDown", mouseDown)
    hint:SetScript("OnClick", open("the hint on the radial menu"))
end

-- The button shows while the game menu shows, out of a fight (the menu has no scale of its own:
-- the button's units are the menu's). The hint shows while the radial menu shows, out of a fight,
-- with the settings window shut. Y is the one that shows then, and nobody's of ours when neither does.
function Menu.Keys()
    local fight = ns.fightStarted or ns.Adapter.InCombat()
    if button then
        button:SetShown(menu:IsShown() and not fight)
    end
    hint:SetShown(radial and not fight and not (ns.Settings and ns.Settings.IsOpen()))
    if fight then
        return
    end
    if button then
        ns.Adapter.GiveKeys(button)
        if menu:IsShown() then
            local ours = ns.Adapter.TakeKey(button, "Y")
            if told ~= ours then
                told = ours
                ns.Log.Add("menu", "Y on the game menu " .. (ours and "is set" or "is not set: another bind has the key"))
            end
        end
    end
    ns.Adapter.GiveKeys(hint)
    if hint:IsShown() then
        local ours = ns.Adapter.TakeKey(hint, "Y")
        if toldRadial ~= ours then
            toldRadial = ours
            ns.Log.Add("menu", "Y on the game's radial menu " .. (ours and "is set" or "is not set: another bind has the key"))
        end
    end
end

-- The game's work for a show or a hide is done when the next frame comes: the keys are set then.
local function later()
    C_Timer.After(0, function()
        ns.Call("MenuButton", Menu.Keys)
    end)
end

-- The radial menu shows or hides. The hint hangs over the menu's title ("Main Menu", 25 of the game's
-- units over the menu's top edge in its large font, GamepadRadial.xml 126 to 131), as the button hangs
-- over the game menu; the menu is the game's own frame (GamepadRadial.xml 119).
local function radialShown(shown)
    return function()
        radial = shown
        if shown then
            hint:ClearAllPoints()
            hint:SetPoint("BOTTOM", GamepadRadial, "TOP", 0, ns.Theme.px(60))
        end
        later()
    end
end

function Menu.OnLogin()
    buildHint()
    menu = ns.Adapter.GameMenu()
    if menu then
        build()
        ns.Adapter.OnShownOrHidden(menu, later)
    end
    ns.On("PLAYER_REGEN_ENABLED", "MenuButton", Menu.Keys)
    -- a fight starts: Y is given back while that is still allowed, so it is not held for the fight,
    -- and the button and the hint go, because neither Y nor a click can open the window in a fight
    ns.On("PLAYER_REGEN_DISABLED", "MenuButton", function()
        hint:Hide()
        ns.Adapter.GiveKeys(hint)
        if button then
            button:Hide()
            ns.Adapter.GiveKeys(button)
        end
    end)
    -- Blizzard set its window binds again: ours must be the newer one again
    ns.Listen("pad:stack", "MenuButton", Menu.Keys)
    -- the settings window opens over the radial menu, or closes with it still open
    ns.Listen("settings:opened", "MenuButton", Menu.Keys)
    ns.Listen("settings:closed", "MenuButton", Menu.Keys)
    local ok, why = pcall(function()
        EventRegistry:RegisterCallback("Gamepad.ShowMainMenu", radialShown(true), hint)
        EventRegistry:RegisterCallback("Gamepad.HideMainMenu", radialShown(false), hint)
    end)
    if not ok then
        ns.Log.Add("menu", "the game's radial menu cannot be heard (" .. tostring(why) .. "): it has no Y hint")
    end
end
