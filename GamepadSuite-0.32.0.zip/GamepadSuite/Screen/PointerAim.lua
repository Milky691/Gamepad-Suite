-- Mouse mode's aim: what LT and RT do where the pointer rests. Screen/Pointer.lua makes them the
-- two mouse buttons: the game's own pointer is put under our picture and the game clicks its
-- mouse button there. That reaches all that a mouse reaches, but only with the game's pointer
-- under ours, and in 0.21.0 the game held its pointer in the middle of the screen (CameraLook in
-- Core/AdapterPointer.lua). So while the right stick rests, LT and RT go straight onto what is
-- under the pointer, each in the way that is proved for that kind of thing. When the stick moves
-- the pointer on, they are the mouse buttons again. Every click comes whole at the let-go.
--   A button (of the game's windows, of an addon, of the suite: a bag slot, a vendor's goods, a
--     quest, a talent, a check box, a loot slot, a bar button, a button the game protects, a unit
--     frame under its bar): a secure button of ours clicks it the game's own way
--     (Adapter.PointerClicker). It needs no pointer of the game's.
--   The world: RT is the game's interact, with what is under the game's pointer while that is
--     under ours, else with what it highlights near the player. LT stays the left mouse button,
--     which clicks only while the game's pointer is under ours (select a unit, place a spell).
--   Anything else (a text box, a slider, the face of a window, the map): the mouse buttons.
-- The suite's windows that take the controller (the settings window, Pick a Name) hear every
-- button and the right stick themselves while they are open, so the pointer has no part there.
-- What is under the pointer: the game's own answer while its pointer is under ours, else our own
-- look at the open windows (Screen/PointerMagnet.lua lists them). Nothing changes while LT or RT
-- is down (its let-go is its click): a small frame waits for the let-go, each frame only then.
-- Out of a fight only: mouse mode is off in one.
-- The log (kind "pointer", "aim: ...") says, each time mouse mode is on, once for each frame, what
-- LT and RT were put on, and what the first click on it did.
local _, ns = ...

local Aim = ns.Module("PointerAim", { "pointer" }, "Mouse Mode")
ns.PointerAim = Aim

local Model = ns.PointerModel

local KEYS = { { "LT", "LeftButton" }, { "RT", "RightButton" } }
local SIDE = { LeftButton = "LT", RightButton = "RT" }

local clicker, watch       -- the secure button that clicks a button; the frame that waits for a trigger's let-go
local on, resting = false, true
local kind, target         -- what LT and RT are on ("button", "world", "near"; nil: the mouse buttons), and the frame
local last                 -- what the last look found (the frame, "world", "near" or "face"); nil after a drop
local said, lines = {}, 0  -- the log's lines since mouse mode came on, by what each tells; how many
local waiting = false      -- a look waits for the next frame
local heard = {}           -- the frames LT and RT were put on whose hide is heard: a hidden one is never clicked

-- One line for each thing told (an aim on a frame, a click on it), at most 24 each time mouse mode is on.
local function note(key, text)
    if not said[key] and lines < 24 then
        said[key], lines = true, lines + 1
        ns.Log.Add("pointer", "aim: " .. text)
    end
end

local function held()
    return ns.Adapter.ButtonDown("LT") or ns.Adapter.ButtonDown("RT")
end

local function at(x, y)
    return math.floor(x) .. ", " .. math.floor(y)
end

-- LT and RT leave what they were on (under it they are the mouse buttons of Screen/Pointer.lua)
-- and go onto the new aim. Gives what the keys read back, for the log.
local function set(newKind, newTarget)
    ns.Adapter.GiveKeys(clicker)
    kind, target = newKind, newTarget
    clicker:SetAttribute("clickbutton", kind == "button" and target or nil)
    if not kind then
        return "the mouse buttons"
    end
    -- the world: RT is the game's interact (Adapter.WORLD says which and why), LT the left mouse button
    if kind ~= "button" then
        return "RT " .. tostring(ns.Adapter.TakeKeyFor(clicker, "RT", ns.Adapter.WORLD[kind]))
    end
    -- the button hides (its window closed): the next frame looks again, so LT and RT leave it
    if not heard[target] then
        heard[target] = true
        pcall(ns.Adapter.OnShownOrHidden, target, function(frame)
            if frame == target then
                Aim.Later()
            end
        end)
    end
    local taken = {}
    for _, key in ipairs(KEYS) do
        taken[#taken + 1] = key[1] .. " " .. tostring(ns.Adapter.TakeKey(clicker, key[1], key[2]))
    end
    return table.concat(taken, ", ")
end

-- The stick moves the pointer on, or mouse mode ends: LT and RT are the mouse buttons again.
local function drop()
    if clicker and not ns.Adapter.InCombat() then
        set(nil, nil)
        last = nil
    end
end

-- What the pointer rests on now: LT and RT go onto it. While a trigger is down, the watch waits.
local function settle()
    if not (on and resting and clicker) or ns.Adapter.InCombat() or ns.fightStarted then
        return
    end
    if held() then
        watch:Show()
        return
    end
    local x, y = ns.Pointer.Spot()
    local gx, gy = ns.Adapter.PointerPlace()
    local there = Model.Near(x, y, gx, gy)
    local under, how = there and ns.Adapter.PointerFocus(), "the game says what is under its pointer"
    if not under then
        -- (with no list of the open windows a window and the world cannot be told apart)
        local look = ns.PointerMagnet and ns.PointerMagnet.Look
        local found = look and Model.Under(x, y, look())
        under = not look and "face" or found == nil and "world" or found.frame or "face"
        how = found and found.slot and "fixed slot " .. found.slot .. ", found by our look" or "found by our look at the open windows"
    end
    local frame = under ~= "world" and under ~= "face" and under or nil
    local button = frame and ns.Adapter.ClickTarget(frame)
    local newKind = under == "world" and (there and "world" or "near") or button and "button" or nil
    if (button or frame or newKind or "face") == last then
        return
    end
    last = button or frame or newKind or "face"
    local keys = set(newKind, button)
    local name = (button or frame) and ns.Adapter.FrameName(button or frame) or under == "face" and "the face of a window" or "the world"
    local words = {
        button = "LT and RT click " .. name .. " with the secure button (" .. how .. ")",
        world = "RT is the game's interact with what is under its pointer, which is under ours, over: " .. ns.Adapter.UnitLabel("mouseover")
            .. "; LT is the left mouse button there",
        near = "the game's pointer is not under ours (ours at " .. at(x, y) .. ", the game's at " .. at(gx, gy)
            .. "): RT is the game's interact with what it highlights: " .. ns.Adapter.UnitLabel("softinteract") .. "; LT clicks nothing",
    }
    note("aim " .. tostring(newKind) .. " " .. name, (words[newKind] or "LT and RT are the mouse buttons on " .. name .. " (" .. how .. ")") .. "; keys: " .. keys)
end

-- The next frame looks at what the pointer rests on: by then the game has moved its own pointer
-- and placed a window that just showed. One look for any number of asks in a frame.
function Aim.Later()
    if waiting or not on then
        return
    end
    waiting = true
    C_Timer.After(0, function()
        waiting = false
        ns.Call("PointerAim", settle)
    end)
end

function Aim.OnLogin()
    -- (a secure button is made out of a fight: after a login in one, when it ends)
    ns.Queue.Run("PointerAim", function()
        clicker = ns.Adapter.PointerClicker("GamepadSuitePointerUse", function(mouse, frame)
            local name = frame and ns.Adapter.FrameName(frame) or "nothing"
            note("click " .. tostring(SIDE[mouse]) .. " " .. name, tostring(SIDE[mouse]) .. " clicked " .. name .. " with the secure button")
            -- (and a frame later the pointer's log says if the game shows its own pointer too)
            ns.Pointer.LookAfter(tostring(SIDE[mouse]) .. " click of " .. name)
        end)
    end)
    -- the let-go of a trigger, looked for each frame only while one holds a look back
    watch = CreateFrame("Frame")
    watch:Hide()
    watch:SetScript("OnUpdate", function(self)
        if not held() then
            self:Hide()
            if resting then
                Aim.Later()
            else
                ns.Call("PointerAim", drop)
            end
        end
    end)
    ns.Adapter.OnInteract(function(unit)
        if on and (kind == "world" or kind == "near") then
            note("interact " .. kind .. " " .. tostring(unit), "RT: the game's interact (" .. tostring(unit) .. ") ran, over: " .. ns.Adapter.UnitLabel("mouseover")
                .. ", highlighted: " .. ns.Adapter.UnitLabel("softinteract"))
        end
    end)
    ns.Listen("pointer", "PointerAim", function(now)
        on, resting = now, true
        watch:Hide()
        if now then
            said, lines = {}, 0
            Aim.Later()
        else
            drop()
        end
    end)
    ns.Listen("pointer:stick", "PointerAim", function(rest)
        resting = rest
        if rest then
            Aim.Later()
        elseif held() then
            watch:Show()
        else
            drop()
        end
    end)
    -- Screen/Pointer.lua took LT and RT anew (the game's binds changed): they are the mouse buttons
    -- now, and the next frame puts them back on the aim, after the let-go of a held trigger, whose
    -- click is still the secure button's
    ns.Listen("pointer:keys", "PointerAim", function()
        last = nil
        Aim.Later()
    end)
end
