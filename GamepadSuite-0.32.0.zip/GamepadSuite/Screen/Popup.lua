-- The pop-up: one small piece near the top middle of the screen that tells of a thing the player must not miss
-- while the hands are on the controller: a whisper (Screen/WhisperPopup.lua), a quest to share (Auto/ShareQuest.lua),
-- an item the game waits for (Auto/WeaponItem.lua), the hungry pet (Auto/PetHungry.lua), a rare (Auto/RareNearby.lua).
-- It has the Dialogue View's look (Screen/DialogueDraw.lua): a piece of the view's dark band whose edge fades out on
-- all sides, a gold title over the gold rule that fades to the right, words in cream (a first line of facts in the
-- muted colour), the strip of button hints of every part and the gold bar of every hold. No new art: the soft square
-- of Art/HudShadow.tga in the band's tone, as under the view's portrait. It sits under the info bar and over the
-- game's red error text.
--
-- One item shows at a time; the others wait in a short list (Screen/PopupModel.lua has the order and the waits). It
-- shows only while play has the controller (no game window, no settings window, no Dialogue or Merchant View:
-- Core/Pad.lua) and no wheel and no keyboard is open; an item that says so (calm) also not in combat. An item that
-- comes then waits, up to its own `wait` seconds, and shows when they close; an item with no wait is not shown. An
-- item that shows goes for good when the screen gets busy; a calm one goes back to the list when combat starts. An
-- item can say it is no longer true (valid): it is then dropped from the list. It goes after its seconds: one timer
-- for each showing, and a newer showing makes an older timer do nothing. A hold (Popup.Keep) keeps it until the hold
-- ends. Each change of what shows is told ("popup:shown", the item or nil; "popup" alone is the guild invite's word to
-- the Dialogue and Merchant Views, Screen/Popups.lua). It is a plain frame: it takes no key and no mouse, and nothing
-- of it runs on each frame. The hints and the holds of an item's acts are Screen/PopupHold.lua's.
--
-- An item: { owner, title, color = { r, g, b } or nil for gold, facts or nil, text or nil, seconds, wait or nil, calm,
-- valid = function or nil, each (items of this owner are kept one for each who: three quests to share wait in turn),
-- acts (Screen/PopupHold.lua) or key and hint (the button and the words of a plain hint; keys
-- for more than one button: { "RT", "A" }), who, and the owner's own fields }.
local _, ns = ...

local Popup = ns.Module("Popup", nil, "Pop-ups")
ns.Popup = Popup

local Model = ns.PopupModel
local Theme = ns.Theme
local px = Theme.px

local SHADOW = "Interface\\AddOns\\GamepadSuite\\Art\\HudShadow.tga"
local TONE = { 0.04, 0.035, 0.03, 0.9 }          -- the band of the Dialogue View, at its strength there
-- in the units of the sample sheet (mockups/popups_sample.py): the width, the place under the screen's top (under
-- the info bar's 28; the foot stays over the game's red error text at 143), the height with words and without, and how far the soft ground reaches past the piece, so
-- that its fade lies outside the words (the art fades over its outer 10 of 64 pixels)
local WIDTH, TOP, TALL, SHORT, OUT_X, OUT_Y = 620, 34, 106, 54, 140, 24
local DONE = 2                                   -- the seconds the words of an act done stay ("Invited", "Shared")

local ui = {}
local shown                     -- the item that shows
local list = {}                 -- the items that wait for the place
local kept, due = false, false  -- a hold keeps the item; its time ran out during that hold
local shows = 0                 -- counts each showing and each going, so an older timer does nothing
local gameplay, wheel, keyboard = true, nil, false

local function fight()
    return ns.fightStarted or ns.Adapter.InCombat()
end

-- True while an item can show: play has the controller, and no wheel and no keyboard is open.
function Popup.Free()
    return gameplay and not wheel and not keyboard
end

-- True while this item can show: the screen is free, and for a calm item no combat is on.
local function free(item)
    return Popup.Free() and not (item.calm and fight())
end

-- The item that shows now, or nil.
function Popup.Shown()
    return shown
end

-- The hints of the item that shows: { { keys, text, off } }.
function Popup.Hints(entries)
    ui.legend.Set(entries or {})
end

-- The plain hint of the item that shows: its buttons (keys, or its one key) and these words (dim when off), or none.
function Popup.Hint(text, off)
    local keys = shown and (shown.keys or shown.key and { shown.key })
    Popup.Hints(keys and text and { { keys = keys, text = text, off = off } } or {})
end

-- The gold bar of a hold, 0 (none) to 1 (full).
function Popup.Hold(part)
    ui.bar:SetPart(part or 0)
end

local function draw(item)
    ui.title:SetText(item.title)
    if item.color then
        ui.title:SetTextColor(item.color[1], item.color[2], item.color[3])
    else
        ui.title:SetTextColor(Theme.Color("gold"))
    end
    local words = item.facts and (Theme.Hex("muted") .. item.facts .. "|r" .. (item.text and "\n" .. item.text or "")) or item.text
    ui.words:SetShown(words ~= nil)
    ui.words:SetText(words or "")
    ui.frame:SetHeight(px(words and TALL or SHORT))
    if item.acts then
        local entries = {}
        for _, act in ipairs(item.acts) do
            entries[#entries + 1] = { keys = { act.key }, text = type(act.words) == "function" and act.words(item) or act.words }
        end
        Popup.Hints(entries)
    else
        Popup.Hint(item.hint)
    end
    Popup.Hold(0)
    ui.frame:Show()
    ui.comesIn:Stop()
    ui.comesIn:Play()
end

local follow

-- the item's seconds begin now: one timer for each showing, and a newer one makes an older timer do nothing
local function clock(item)
    shows = shows + 1
    local mine = shows
    C_Timer.After(item.seconds, function()
        if mine == shows then
            if kept then
                due = true
            else
                Popup.Hide(item.owner, item.who)
            end
        end
    end)
end

local function show(item)
    shown, kept, due = item, false, false
    draw(item)
    clock(item)
    ns.Send("popup:shown", item)
end

-- The item that shows stays its seconds from now (a hold of the press grammar is full: the player wants it).
function Popup.Renew()
    if shown then
        due = false
        clock(shown)
    end
end

-- the item that shows goes; with back, it goes back to the list (when it has a wait)
local function gone(back)
    if shown then
        local item = shown
        shown, kept, due = nil, false, false
        shows = shows + 1
        ui.frame:Hide()
        if back and item.wait then
            Model.Put(list, item)
        end
        ns.Send("popup:shown", nil)
    end
end

-- Shows an item: true when it shows now, "wait" when it waits for the place, false when it is not shown.
function Popup.Show(item)
    if not ui.frame then
        return false
    end
    item.at = GetTime()
    local place = Model.Place(shown, item, free(item))
    if place == "show" then
        for i = #list, 1, -1 do
            if Model.Same(list[i], item) then
                table.remove(list, i)
            end
        end
        local before = shown
        if before and not Model.Same(before, item) and before.wait then
            Model.Put(list, before)
        end
        show(item)
        return true
    elseif place == "wait" then
        Model.Put(list, item)
        return "wait"
    end
    return false
end

-- The item of owner goes, the one that shows and the one that waits (any owner for nil); with who, only an item
-- whose who is that. The next one that waits may show then.
function Popup.Hide(owner, who)
    local function fits(item)
        return item and (owner == nil or item.owner == owner) and (who == nil or item.who == who)
    end
    for i = #list, 1, -1 do
        if fits(list[i]) then
            table.remove(list, i)
        end
    end
    if fits(shown) then
        gone()
        follow()
    end
end

-- The act of the item that shows is done: these words stand in place of its hints for 2 seconds, with no act, and
-- then it goes.
function Popup.Done(words)
    if not shown then
        return
    end
    local item = {}
    for key, value in pairs(shown) do
        item[key] = value
    end
    item.acts, item.key, item.keys, item.hint, item.wait, item.seconds = nil, nil, nil, nil, nil, DONE
    show(item)
    Popup.Hints({ { keys = {}, text = words } })
end

-- A hold runs (on) or ended (off): while it runs, the item stays past its time; after it, it goes if the time ran out.
function Popup.Keep(on)
    kept = on
    if not on and due then
        gone()
        follow()
    end
end

-- The screen is busy now (the item goes), combat started (a calm item goes back to the list), or the place is free
-- again (the next item that waits shows, if it is still true and not too old).
function follow()
    if shown and not Popup.Free() then
        gone()
    elseif shown and not free(shown) then
        gone(true)
    end
    if shown then
        return
    end
    for i = #list, 1, -1 do
        if list[i].valid and not list[i].valid() then
            table.remove(list, i)
        end
    end
    local item = Model.Next(list, GetTime(), free)
    if item then
        show(item)
    end
end

-- For the tests and the log: how many items wait now.
function Popup.Waiting()
    return #list
end

local function build()
    local frame = CreateFrame("Frame", nil, UIParent)
    frame:SetFrameStrata("HIGH")
    frame:SetSize(px(WIDTH), px(TALL))
    frame:SetPoint("TOP", UIParent, "TOP", 0, -px(TOP))
    frame:Hide()
    local ground = frame:CreateTexture(nil, "BACKGROUND")
    ground:SetTexture(SHADOW)
    ground:SetTexCoord(0, 0.5, 0, 1)
    ground:SetVertexColor(TONE[1], TONE[2], TONE[3], TONE[4])
    ground:SetPoint("TOPLEFT", -px(OUT_X), px(OUT_Y))
    ground:SetPoint("BOTTOMRIGHT", px(OUT_X), -px(OUT_Y))
    ui.legend = ns.Widgets.Legend(frame, "RIGHT")
    ui.legend:SetPoint("TOPRIGHT", -px(20), -px(10))
    ui.title = Theme.Text(frame, "name", "gold")
    ui.title:SetPoint("TOPLEFT", px(24), -px(12))
    ui.title:SetPoint("RIGHT", ui.legend, "LEFT", -px(16), 0)
    local rule = Theme.Fill(frame, "ARTWORK", 1, 1, 1, 1)
    rule:SetGradient("HORIZONTAL", CreateColor(Theme.Color("gold", 0.7)), CreateColor(Theme.Color("gold", 0)))
    rule:SetPoint("TOPLEFT", px(24), -px(40))
    rule:SetSize(px(320), ns.Adapter.DialogueThin(frame, px(1)))
    ui.words = Theme.Text(frame, "row", "cream")
    ui.words:SetPoint("TOPLEFT", px(24), -px(46))
    ui.words:SetWidth(px(WIDTH - 48))
    ui.words:SetWordWrap(true)
    ui.words:SetMaxLines(2)
    ui.words:SetSpacing(px(4))
    ui.words:SetJustifyV("TOP")
    ui.bar = ns.Widgets.HoldLine(frame, 12)
    -- it comes in over 0.15 seconds, as the parts of the Dialogue View: the game runs it, no script of ours does
    ui.comesIn = frame:CreateAnimationGroup()
    local fade = ui.comesIn:CreateAnimation("Alpha")
    fade:SetFromAlpha(0)
    fade:SetToAlpha(1)
    fade:SetDuration(0.15)
    ui.frame = frame
end

function Popup.OnLogin()
    build()
    ns.PopupHold.Start()
    gameplay = ns.Pad.Gameplay()
    ns.Listen("pad", "Popup", function(now)
        gameplay = now
        follow()
    end)
    ns.Listen("wheel", "Popup", function(id)
        wheel = id
        follow()
    end)
    ns.Listen("keyboard", "Popup", function(open)
        keyboard = open
        follow()
    end)
    -- (at the game's word that combat starts: a calm item goes back to the list; at its end the list may show)
    ns.On("PLAYER_REGEN_DISABLED", "Popup", function()
        C_Timer.After(0, follow)
    end)
    ns.On("PLAYER_REGEN_ENABLED", "Popup", function()
        C_Timer.After(0, follow)
    end)
end
