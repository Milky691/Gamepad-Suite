-- A spell, an item or a macro that the player carries with the mouse (from the spellbook, a bag,
-- the macro window) can be dropped on an on-screen button. It becomes that button's bind on the
-- layer in view, in the set in use: the form's set in a form, else Normal. Undo Last Bind takes
-- it back.
-- The on-screen buttons take the mouse only while the pointer carries such a thing, so at every
-- other time a click at their place goes to the game. They show while it does, also while the
-- spellbook or a bag has the controller: the game's window keeps the controller while the
-- pointer carries a thing (Blizzard_GamepadSharedUtility/FrameControlsManager.lua 681-687),
-- and the buttons step back at any other time a window has it.
local _, ns = ...

local Drop = ns.Module("Drop", { "cursorDrop" }, "Drop on an On-Screen Button")
ns.Drop = Drop

-- carried: the pointer carries a spell, an item or a macro now. told: the first drop is in the log.
local carried, told = false, false

function Drop.Carrying()
    return carried
end

local function take(b)
    local bind = ns.Adapter.CursorBind()
    local _, _, layer = ns.Screen.State()
    -- with Bars every layer has its own buttons: a drop goes to the layer of the bar it lands on
    layer = b.layer or layer
    if not bind then
        return
    end
    -- the LB + RB layer has ten buttons
    if layer == 5 then
        local inLayer = false
        for _, key in ipairs(ns.BindRules.IN_HOLD) do
            inLayer = inLayer or key == b.key
        end
        if not inLayer then
            return
        end
    end
    local get = ns.Registry.Get
    local state = ns.Adapter.BindState(get("layers.combat_set"), get("layers.forms_and_stances") ~= "Off" and ns.Adapter.Forms() or {}, get("layers.forms_and_stances") == "Combat First")
    ns.Binds.Begin()
    ns.Binds.Change(state.form or "normal", layer, b.key, bind)
    ns.Adapter.CursorClear()
    if not told then
        -- one play tells what the game gave for the thing on the pointer, and that the button got it
        told = true
        ns.Log.Add("screen", "A drop on " .. b.key .. ": the game gave " .. bind.kind .. " " .. tostring(bind.id) .. "; it is the bind on layer "
            .. layer .. " in the set " .. (state.form or "normal") .. "; a window had the controller: " .. tostring(not ns.Pad.Gameplay()))
    end
end

-- The buttons take the mouse while the pointer carries a bind, and at no other time. A change
-- of that draws them again: they show while it carries one.
local wired = {}
local function follow()
    local carrying = ns.Adapter.CursorBind() ~= nil
    if carrying ~= carried then
        carried = carrying
        ns.Send("drop")
    end
    ns.Screen.Each(function(b)
        if not wired[b] then
            wired[b] = true
            b:SetScript("OnReceiveDrag", take)
            b:SetScript("OnMouseUp", take)
        end
        b:EnableMouse(carrying)
    end)
end

function Drop.OnLogin()
    ns.Adapter.OnCursorChanged("Drop", follow)
    -- the buttons are drawn again (another layer, a new button): the same rule for the new ones
    ns.Listen("screen", "Drop", follow)
end
