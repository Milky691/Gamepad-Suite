-- The rules of the range finder, with no game calls. The game does not tell an addon how far an
-- enemy is. It tells, for a thing with a reach (a spell, an item), if the target is inside
-- that reach. From a few of these answers comes a band: "5-30 yd" is farther than the melee
-- reach and inside the reach of a 30 yard spell.
local _, ns = ...

local Model = {}

-- The most things that are watched at one time.
Model.MOST = 6

-- The longest reach of an attack, in yards. No attack of this game reaches past 41 yards. A
-- harmful spell that reaches farther is no attack (a hunter's mark at 100 yards, a priest's
-- Mind Vision across the world), so it is left out: of the band, the red text and the tick.
-- (A design value: the reaches of spells come from the server, not from the game's files.)
Model.FARTHEST = 45

-- The things to watch: one for each reach, the nearest reach first. spells is the adapter's
-- list ({ spell =, name =, min =, max = }); melee is the item of the melee reach, or nil. Two
-- things with the same reach tell the same, so the first one stands for both: a spell of the
-- melee reach stands for the item, because the game tells when a spell's answer changes. With
-- more than MOST, the nearest one stays and the next nearest go: the far end is what a ranged
-- character needs. A spell that reaches past FARTHEST is left out.
function Model.Probes(spells, melee)
    local out = {}
    local function add(probe)
        for _, have in ipairs(out) do
            if have.min == probe.min and have.max == probe.max then
                return
            end
        end
        out[#out + 1] = probe
    end
    for _, spell in ipairs(spells) do
        if spell.max <= Model.FARTHEST then
            add(spell)
        end
    end
    if melee then
        add(melee)
    end
    table.sort(out, function(a, b)
        if a.max ~= b.max then
            return a.max < b.max
        end
        return a.min < b.min
    end)
    while #out > Model.MOST do
        table.remove(out, 2)
    end
    return out
end

-- The band the target is in: { lo =, hi = } in yards, hi nil for "farther than every reach".
-- states[i] is the game's answer for probes[i]: true (inside its reach, from min to max), false
-- (not inside: nearer than min, or farther than max), nil (the game cannot tell). nil when no
-- answer is known, or when the answers cannot all be true at one distance.
-- Every stretch between two reaches is asked: can the target be there? The band goes from the
-- first stretch that can be to the last one.
function Model.Band(probes, states)
    local cuts = { 0 }
    for i, probe in ipairs(probes) do
        if states[i] ~= nil then
            cuts[#cuts + 1], cuts[#cuts + 2] = probe.min, probe.max
        end
    end
    if #cuts == 1 then
        return nil
    end
    table.sort(cuts)
    local lo, hi, open
    for k = 1, #cuts do
        -- the stretch from this reach to the next one; the last stretch has no far end
        local from, to = cuts[k], cuts[k + 1]
        if to == nil or to > from then
            local fits = true
            for i, probe in ipairs(probes) do
                local inside = from >= probe.min and to ~= nil and to <= probe.max
                local outside = (to ~= nil and to <= probe.min) or from >= probe.max
                if (states[i] == true and not inside) or (states[i] == false and not outside) then
                    fits = false
                end
            end
            if fits then
                lo = lo or from
                hi, open = to, to == nil
            end
        end
    end
    if not lo then
        return nil
    end
    return { lo = lo, hi = not open and hi or nil }
end

-- The band as the player reads it, and true when the target is farther than every reach:
-- "0-5 yd", "5-30 yd", "30+ yd". nil for no band.
function Model.Text(band)
    if not band then
        return nil
    end
    local lo = string.format("%d", math.floor(band.lo + 0.5))
    if not band.hi then
        return lo .. "+ yd", true
    end
    return lo .. "-" .. string.format("%d", math.floor(band.hi + 0.5)) .. " yd", false
end

-- The rumble tick: one short pulse, of TICK seconds, when the target comes into reach of the
-- longest attack. Going out of reach gives none. A target that went out of reach less than REST
-- seconds ago gives none when it comes back: one that stands at the edge of the reach, in and
-- out each second, does not buzz.
-- TICK is the one tick length of the suite, the same as the wheel's (WheelModel.TICK says why).
Model.TICK = 0.06
Model.REST = 2

-- True when the tick plays now. seen is what is known of this target, a new empty table for each
-- new target: { reach = the last answer, out = when it last went out of reach }. reach is what
-- the game tells now: true (in reach), false (past every reach), nil (the game cannot tell: the
-- last answer stands). A new target gives no tick at its first answer: it was not followed
-- before. now is the time in seconds. busy is true while another pulse plays (a low health
-- warning, a spell that lights up): the game has one rumble at a time, and a tick would end that
-- pulse early, so the tick is left out. The longest attack is the longest reach that Model.Probes
-- keeps (FARTHEST says which are left out).
function Model.Tick(seen, reach, now, busy)
    if reach == nil then
        return false
    end
    local before = seen.reach
    seen.reach = reach
    if before == true and not reach then
        seen.out = now
    end
    return before == false and reach and now - (seen.out or -math.huge) >= Model.REST and not busy or false
end

if ns then
    ns.RangeModel = Model
end
return Model
