-- Blizzard windows that the game's gamepad mode gives no control. The guild invite is one: it is
-- on screen and no button of the controller reaches it. The battleground's ready dialog is another:
-- A enters, B leaves the queue, before the game's own time runs out. While such a window is shown, A presses
-- its first button and B its second, and the two buttons show the controller's own pictures.
-- It acts out of a fight only: an addon cannot change a bind in a fight. A window that the game's
-- gamepad mode does handle is left alone, because then the game has the controller, not play.
-- During a talk in Dialogue View the view has A and B: the window shows (the view hears "popup"),
-- with no pictures, and gets A and B when the talk ends (Core/Pad.lua says "pad" then).
-- The list of windows is in the adapter (Adapter.POPUPS).
local _, ns = ...

local Popups = ns.Module("Popups", { "secure" }, "Guild Invite Buttons")
ns.Popups = Popups

local hints = {}
local told = {}

-- One line for each answer, the first time in a session: such a window showed, and what A and
-- B did then. Read from the saved file.
local function note(kind, text)
    if not told[kind] then
        told[kind] = true
        ns.Log.Add("popups", text)
    end
end

local function hint(key, button)
    local glyph = hints[key]
    if not glyph then
        glyph = ns.Widgets.Glyph(UIParent, key, ns.Theme.px(26))
        hints[key] = glyph
    end
    glyph:SetShown(button ~= nil)
    if button then
        glyph:SetParent(button)
        glyph:ClearAllPoints()
        glyph:SetPoint("RIGHT", button, "LEFT", -ns.Theme.px(4), 0)
    end
end

-- The first listed window that is shown gets A and B. Called when one of them shows or hides,
-- when the controller goes to a window or back, and when a fight ends.
function Popups.Update()
    local first, second, row = ns.Adapter.ShownPopup()
    local what = row and row.words or "a window with two buttons"
    local wait = ns.Adapter.InCombat() and "combat is on"
        or not ns.Pad.Gameplay() and "a talk, a game window or the settings window has the controller"
    if first and wait then
        note(what .. wait, what .. " showed, and A and B wait: " .. wait)
    end
    if ns.Adapter.InCombat() then
        return
    end
    if wait then
        first, second = nil, nil
    end
    ns.BindCore.Popup(first and first:GetName(), second and second:GetName())
    hint("A", first)
    hint("B", second)
    if first then
        local KEY = ns.Adapter.KEY
        note("set " .. what, what .. " showed: A is " .. tostring(ns.Adapter.EffectiveBinding(KEY.A))
            .. ", B is " .. tostring(ns.Adapter.EffectiveBinding(KEY.B)))
    end
end

function Popups.OnLogin()
    ns.Adapter.OnPopupShownOrHidden(function()
        ns.Call("Popups", Popups.Update)
        -- told to Dialogue View: the game shows such a window as no question of its own (no
        -- message of its popups), and the view brings the interface back while one is shown
        ns.Send("popup")
    end)
    ns.Listen("pad", "Popups", Popups.Update)
    ns.On("PLAYER_REGEN_ENABLED", "Popups", Popups.Update)
end
