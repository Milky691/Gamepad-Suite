-- The fixed slots on the screen (Core/Slots.lua has what they hold and where they sit). A fixed
-- slot is the on-screen button of Hud.lua in the chosen Button Look, and above it the small
-- pictures of its buttons: the held ones first, then the button (RT, A). A slot with no button
-- has none; a slot with no action does not show. A press of its button goes from the key to the
-- bind core, as for every bind. A tap or a click on a slot runs its action too: over each slot
-- sits a button of the game's own secure kind, with nothing to see.
-- They are drawn with the on-screen buttons, and step back and dim with them. While the player
-- changes a place or the size in the settings window, they show above it for three seconds (the
-- peek of Hud.lua), and the slot that moves has a gold rim, also when it is empty.
-- The sizes are the ones of the sample the user saw (mockups/slots_sample.py).
local _, ns = ...

local View = ns.Module("SlotView", nil, "Fixed Slots")
ns.SlotView = View

local Theme, Widgets, Rules, Store = ns.Theme, ns.Widgets, ns.SlotRules, ns.Slots
local px = Theme.px

-- In the units of the on-screen buttons, at Slot Size 100%.
local SIZE, GLYPH, GAP, ABOVE = 48, 20, 3, 5
-- the strength of the picture of a spell the character does not know now: that of a bind from another set on the
-- Binds page (Settings/BindsDraw.lua)
local UNKNOWN = 0.55

local holder
local slots, taps = {}, {}
local tapsShown      -- were the on-screen buttons shown when the tap buttons were last written
local holds = {}     -- slot -> true when its tap is a hold (a held bind of ours: the press and the let-go)
local told = {}      -- the log's lines of this session, by what each tells

-- Every attribute a tap can have (Slots.Tap, SlotRules.Click); each write sets all of them.
local ATTRIBUTES = { "type", "spell", "item", "macro", "macrotext", "unit", "action",
    "downbutton", "*macrotext-press", "typerelease", "pressAndHoldAction" }

-- A tap reached a slot's button: one line for each slot and kind of click, in and out of a
-- fight, in a session.
local function heard(n, button, down)
    local what = (holds[n] and (down and "the press of a hold" or "the let-go of a hold") or "a tap") .. " (" .. tostring(button) .. ") reached its button"
        .. (ns.Adapter.InCombat() and ", in a fight" or "")
    if not told[n .. what] then
        told[n .. what] = true
        local action = Store.Get(n)
        ns.Log.Add("slots", "slot " .. n .. " (" .. tostring(action and action.name) .. "): " .. what)
    end
end

-- The buttons that take a tap or a click. The game lets such a button change only out of a
-- fight: its place, its size and what it runs follow the slot when no fight is on. It is not
-- tied to the slot's own frame, because a frame that such a button is tied to cannot move or
-- hide in a fight either. With the on-screen buttons gone (a window has the controller), a tap
-- does nothing. In a fight it is another thing: fight is true at the start of one, and then every
-- slot with an action takes a tap until the fight ends (see follow).
-- A tap acts at the let-go of the click, as the game's own bar buttons do for a mouse click
-- (SecureActionButton_OnClick, Blizzard_FrameXML/SecureTemplates.lua 788 to 818): mouse mode
-- clicks a button with the game's click action, which gives the let-go only (557 to 563). A held
-- bind of ours acts at the press and at the let-go ("pressAndHoldAction", SlotRules.Click).
-- The slots are on the screen: shown, and not out of sight on a mount or at rest (Screen/HudHide.lua
-- gives the buttons no strength then). A slot out of sight takes no tap or click.
local function onScreen()
    local shown, alpha = ns.Screen.State()
    return shown and alpha > 0
end

-- Gives how many taps run something now.
local function setTaps(fight)
    local shown = fight == true or onScreen()
    tapsShown = shown
    local count = 0
    local size = px(SIZE * ns.Registry.Get("slots.size") / 100)
    for n in ipairs(slots) do
        local tap = taps[n]
        if not tap then
            tap = CreateFrame("Button", "GamepadSuiteSlotTap" .. n, UIParent, "SecureActionButtonTemplate")
            tap:RegisterForClicks("AnyDown", "AnyUp")
            tap:SetAttribute("useOnKeyDown", false)
            -- the click that ran the action flashes the slot's rim
            tap:HookScript("PostClick", function(_, button, down)
                local acted = (down and true or false) == (holds[n] or false)
                if acted or holds[n] then
                    heard(n, button, down)
                end
                if acted then
                    ns.Send("press", slots[n].Face().signature)
                end
            end)
            taps[n] = tap
        end
        local action = shown and Store.Tap(n) or nil
        holds[n] = action and action.pressAndHoldAction or nil
        for _, name in ipairs(ATTRIBUTES) do
            tap:SetAttribute(name, action and action[name] or nil)
        end
        tap:SetShown(action ~= nil)
        if action then
            count = count + 1
            local x, y = Store.Place(n)
            tap:SetSize(size, size)
            tap:ClearAllPoints()
            tap:SetPoint("CENTER", UIParent, "CENTER", px(x), px(y))
        end
    end
    return count
end

-- The tap buttons, by slot: mouse mode's aim clicks the one under its pointer (Screen/PointerMagnet.lua).
function View.Taps()
    return taps
end

-- The slots show and dim with the on-screen buttons. In a fight they stay when the buttons step
-- back for a window: the game lets no tap button change in a fight, so a tap still runs a slot
-- then, and what a tap can run must be on the screen.
local function follow()
    local shown, alpha = ns.Screen.State()
    local stay = not shown and ns.Adapter.InCombat() and ns.Adapter.PadActive()
    local peek = ns.Screen.Peeking("SlotView", holder)
    holder:SetShown(peek or shown or stay)
    holder:SetAlpha((peek or stay) and 1 or alpha)
end

-- One fixed slot: the on-screen button in the chosen look, with the gold rim of the slot that the
-- position rows move, and the row of button pictures above it. The Slot Binds page shows the same
-- thing. A button keeps the look it was made in, so the slot holds one for each look it was shown
-- in. slot.Face() gives the one of the look now (Screen.Fill and Screen.Look draw it): a SIZE button
-- scaled to the slot's size, so its shape and its rims stay true at every Slot Size.
function View.Make(parent)
    local slot, faces = CreateFrame("Frame", nil, parent), {}
    function slot.Face()
        local look = ns.HudModel.Look(ns.Registry.Get("screen.look"))
        local face = faces[look.name]
        if not face then
            face = ns.Screen.Face(slot, look, SIZE)
            face:SetSize(px(SIZE), px(SIZE))
            face:SetPoint("CENTER")
            face.moving = face:CreateTexture(nil, "BACKGROUND")
            face.moving:SetColorTexture(Theme.Color("gold"))
            face.moving:SetPoint("TOPLEFT", -px(4), px(4))
            face.moving:SetPoint("BOTTOMRIGHT", px(4), -px(4))
            ns.HudFace.Shape(face.moving, look, SIZE + 8)
            face.moving:Hide()
            -- (each button of the slot knows the slot's row of button pictures)
            face.top = slot.top
            faces[look.name] = face
        end
        for name, each in pairs(faces) do
            each:SetShown(name == look.name)
        end
        -- (a slot not yet given its size keeps the scale it had)
        local wide = slot:GetWidth()
        if wide > 0 then
            face:SetScale(wide / px(SIZE))
        end
        return face
    end
    -- A spell the character does not know now (Slots.Unknown): its picture is dim, in its own colours, not the grey of
    -- "cannot be used now", which is for a spell that can be used later. After Screen.Look, which gives the colour.
    function slot.Dim(unknown)
        local art = slot.Face().icon.art
        art:SetAlpha(unknown and UNKNOWN or 1)
        if unknown then
            art:SetVertexColor(1, 1, 1)
        end
    end
    slot.top = Widgets.Keys(slot, GLYPH, GAP)
    slot.top:SetPoint("BOTTOM", slot, "TOP", 0, px(ABOVE))
    return slot
end

function View.Draw()
    if not holder then
        return
    end
    local size = ns.Registry.Get("slots.size") / 100
    local numbers = ns.Registry.Get("screen.cooldown_numbers")
    local moving = ns.Screen.Peeking("SlotView") and Store.Moving() or nil
    for n, slot in ipairs(slots) do
        local action = Store.Get(n)
        slot:SetShown(action ~= nil or n == moving)
        if slot:IsShown() then
            local x, y = Store.Place(n)
            slot:SetSize(px(SIZE * size), px(SIZE * size))
            slot:ClearAllPoints()
            slot:SetPoint("CENTER", UIParent, "CENTER", px(x), px(y))
            ns.Screen.Fill(slot, action and ns.BindRules.Real(action) or nil, numbers)
            ns.Screen.Look(slot)
            slot.unknown = action ~= nil and Store.Unknown(n)
            slot.Dim(slot.unknown)
            slot:SetAlpha(action and 1 or 0.35)
            slot.Face().moving:SetShown(n == moving)
            -- the pictures keep their size next to the slot's: both follow Slot Size
            slot.top:SetScale(size)
            local keys, layer
            if action then
                keys, layer = Store.Keys(n)
            end
            slot.top.Set(keys)
            -- its button and that button's layer: the slot goes dark while the button is held
            slot.index = keys and ns.Adapter.PadIndex(keys[#keys]) or false
            slot.layer = layer or false
        end
    end
    follow()
end

-- A slot's action, its place or its size changed: the slots are drawn, and the tap buttons are
-- written again. In a fight the writing waits for the end of the fight.
local function change()
    View.Draw()
    ns.Queue.Run("SlotView", setTaps)
end

-- A place or the size changed: the slots show above the settings window for a moment.
local function peek()
    ns.Screen.Peek("SlotView", View.Draw)
    change()
end

function View.OnLogin()
    holder = CreateFrame("Frame", "GamepadSuiteSlots", UIParent)
    holder:SetAllPoints()
    for n = 1, Rules.MOST do
        slots[n] = View.Make(holder)
    end
    -- The on-screen buttons were drawn in full. A slot shows and dims with them. sets: the set of
    -- binds in use changed (a fight, a form), so a slot can have another button now. The tap
    -- buttons are written again only when the buttons came or went (a window took the controller).
    -- A slot with a macro shows what the macro would use now, and that follows a modifier key, a
    -- form or the target: at each of those the buttons are drawn in full, and those slots follow.
    ns.Listen("screen", "SlotView", function(sets)
        if sets then
            View.Draw()
        else
            follow()
            local numbers = ns.Registry.Get("screen.cooldown_numbers")
            for n, slot in ipairs(slots) do
                local action = slot:IsShown() and Store.Get(n)
                if action and action.kind == "macro" then
                    ns.Screen.Fill(slot, action, numbers)
                    ns.Screen.Look(slot)
                end
            end
        end
        if onScreen() ~= tapsShown then
            ns.Queue.Run("SlotView", setTaps)
        end
    end)
    -- a cooldown began or ended, or the bags changed (count): the clock and the count of each slot
    ns.Listen("screen:cool", "SlotView", function(count)
        for n, slot in ipairs(slots) do
            if slot:IsShown() and Store.Get(n) then
                ns.Screen.Cool(slot.Face())
                if count then
                    ns.Screen.Count(slot.Face())
                end
            end
        end
    end)
    ns.Listen("screen:look", "SlotView", function()
        if not ns.Screen.Peeking("SlotView") then
            follow()
        end
        for n, slot in ipairs(slots) do
            if slot:IsShown() and Store.Get(n) then
                ns.Screen.Look(slot)
                slot.Dim(slot.unknown)
            end
        end
    end)
    -- A spell learned or lost (a talent reset, a new rank): the look of each slot whose spell came or went. The log
    -- tells once a session for each event that changed a slot: one play shows which one a talent reset sends.
    for _, event in ipairs({ "SPELLS_CHANGED", "PLAYER_TALENT_UPDATE" }) do
        ns.On(event, "SlotView", function()
            for n, slot in ipairs(slots) do
                if slot:IsShown() and Store.Get(n) and Store.Unknown(n) ~= slot.unknown then
                    slot.unknown = not slot.unknown
                    ns.Screen.Look(slot)
                    slot.Dim(slot.unknown)
                    if not told[event] then
                        told[event] = true
                        ns.Log.Add("slots", "slot " .. n .. " (" .. tostring(Store.Get(n).name) .. "): " .. (slot.unknown and "not known now" or "known again") .. ", at " .. event)
                    end
                end
            end
        end)
    end
    -- a slot, a bind, or a wheel changed
    ns.Listen("slots", "SlotView", change)
    ns.Listen("bind", "SlotView", change)
    ns.Listen("wheels", "SlotView", change)
    ns.Listen("setting", "SlotView", function(key)
        if key:find("^slots%.") and not Store.quiet then
            peek()
        elseif key == "screen.cooldown_numbers" or key == "screen.look" then
            -- (another look: each slot shows its button of that look)
            View.Draw()
        end
    end)
    -- the picture goes dark while the slot's button is held, on the layer in view
    ns.Listen("screen:poll", "SlotView", function(down)
        local _, _, layer = ns.Screen.State()
        for _, slot in ipairs(slots) do
            if slot:IsShown() then
                slot.Face().shade:SetShown(slot.index and slot.layer == layer and down[slot.index] == true or false)
            end
        end
    end)
    -- The start of a fight is the last moment that the game lets a tap button change (it tells
    -- of the fight before it locks them; ControllerForever makes its item list again there).
    ns.On("PLAYER_REGEN_DISABLED", "SlotView", function()
        if ns.Adapter.PadActive() and not ns.Adapter.InCombat() then
            local count = setTaps(true)
            if not told.fight then
                told.fight = true
                ns.Log.Add("slots", "a fight began: the tap buttons of " .. count .. " slots were written for it (with no blocked line after this one, the game took them)")
            end
        end
    end)
    -- a pet came, went or its bar changed: a tap on a pet command presses its new slot there
    ns.On("PET_BAR_UPDATE", "SlotView", function()
        ns.Queue.Run("SlotView", setTaps)
    end)
    ns.Listen("press", "SlotView", function(signature)
        for _, slot in ipairs(slots) do
            local face = slot:IsShown() and slot.Face()
            if face and face.signature and face.signature == signature then
                face.flash:Show()
                C_Timer.After(0.12, function() face.flash:Hide() end)
            end
        end
    end)
    change()
end
