-- The small pictures of the other layers (the row Other Layers). With the row on, each main
-- on-screen button has three small pictures in a row above it (under it for a bottom button of
-- Plate and Round), outside its picture: what the
-- button does with LT (left), with LT + RT (middle) and with RT (right). A small picture shows
-- what the main picture shows when that layer is in view: a bind of ours, or the game's own
-- action for the layer, or nothing. In a form they show the form's binds.
-- They keep their order while a trigger is held, so they do not jump under the thumb; the one of
-- the layer in view has a gold line. A small picture goes dark while its action cools down (not
-- for the short cooldown that every cast starts) and has the one look of "cannot be used now" and
-- "short of mana" (HudFace.Unusable). It has no number, no sweep and no color for reach.
-- Nothing is made before the row is on. Hud.lua tells this file of each full draw; the dark and
-- the colors follow the same passes as the main pictures, with no bind lookup.
-- The places and the sizes for each look are in HudModel.lua (MiniRow).
local _, ns = ...

local Theme, Widgets, Model = ns.Theme, ns.Widgets, ns.HudModel
local px = Theme.px

-- sets: a main button -> its three small pictures and their frame, or false where it has no
-- room for them. shown: the sets in use now.
local sets, shown = {}, {}

-- A line round a small picture of this size, in the look's shape.
local function line(holder, art, look, size, by, r, g, b, a)
    local texture = holder:CreateTexture(nil, "BACKGROUND")
    texture:SetColorTexture(r, g, b, a)
    texture:SetPoint("TOPLEFT", art, "TOPLEFT", -px(by), px(by))
    texture:SetPoint("BOTTOMRIGHT", art, "BOTTOMRIGHT", px(by), -px(by))
    ns.HudFace.Shape(texture, look, size + 2 * by)
    return texture
end

local function make(b, look)
    local size, at = Model.MiniRow(look, b.key)
    if not size then
        sets[b] = false
        return false
    end
    local m = look.mini
    -- a frame of the buttons' frame and not of the button: a button with no bind is dim, and
    -- its small pictures are not
    local holder = CreateFrame("Frame", nil, b:GetParent())
    holder:SetAllPoints(b)
    holder:SetFrameLevel(b.cooldown:GetFrameLevel() + 3)
    local set = { holder = holder }
    for i, place in ipairs(at) do
        local mini = { art = holder:CreateTexture(nil, "ARTWORK") }
        mini.art:SetSize(px(size), px(size))
        mini.art:SetPoint("CENTER", holder, "CENTER", px(place[1]), px(place[2]))
        ns.HudFace.Shape(mini.art, look, size)
        mini.rim = line(holder, mini.art, look, size, m.rim, 0, 0, 0, 0.85)
        mini.live = line(holder, mini.art, look, size, m.live, Theme.Color("gold"))
        -- Dark while the action cools down: a part of a cooldown frame, which the game shows
        -- only while a cooldown runs. The game keeps it right in a fight, where it hides the
        -- time left from the addon.
        mini.cooldown = CreateFrame("Cooldown", nil, holder, "CooldownFrameTemplate")
        mini.cooldown:ClearAllPoints()
        mini.cooldown:SetAllPoints(mini.art)
        mini.cooldown:SetDrawSwipe(false)
        mini.cooldown:SetDrawEdge(false)
        mini.cooldown:SetDrawBling(false)
        mini.cooldown:SetHideCountdownNumbers(true)
        local dark = mini.cooldown:CreateTexture(nil, "BACKGROUND")
        dark:SetColorTexture(0, 0, 0, 0.6)
        dark:SetAllPoints()
        ns.HudFace.Shape(dark, look, size)
        -- the proc glow and the interrupt glow (Screen/HudCues.lua), smaller
        if ns.HudCues then ns.HudCues.Small(mini, holder, look, size) end
        set[i] = mini
    end
    sets[b] = set
    return set
end

local function cool(mini)
    ns.Adapter.ShowCooldown(mini.cooldown, mini.bind or nil, true)
end

local function tint(mini)
    ns.HudFace.Unusable(mini.art, ns.Adapter.Usable(mini.bind))
end

-- Runs fn for each small picture that shows an action now.
local function each(fn)
    for _, set in pairs(shown) do
        for _, mini in ipairs(set) do
            if mini.bind then
                fn(mini)
            end
        end
    end
end

-- The on-screen buttons were drawn in full. find is Hud.lua's lookup of the bind in use for a
-- layer and a button, or false while the row is off; game, look, layer (the one in view), slots
-- and buttons are that draw's.
ns.Listen("screen:minis", "HudMini", function(find, game, look, layer, slots, buttons)
    for b, set in pairs(shown) do
        set.holder:Hide()
        shown[b] = nil
    end
    if not find then
        return
    end
    for _, slot in ipairs(slots) do
        if slot.main then
            local b = buttons[look.name .. slot.key]
            local set = sets[b]
            if set == nil then
                set = make(b, look)
            end
            if set then
                shown[b] = set
                set.holder:Show()
                for i, mini in ipairs(set) do
                    local bind = Model.Shown(find, game, Model.MINI_LAYERS[i], slot.key)
                    local live = bind ~= nil and layer == Model.MINI_LAYERS[i]
                    mini.bind = bind or false
                    if ns.HudCues then ns.HudCues.Fill(mini, bind) end
                    Widgets.Art(mini.art, bind and ns.Adapter.BindIcon(bind) or nil)
                    mini.art:SetShown(bind ~= nil)
                    mini.rim:SetShown(bind ~= nil and not live)
                    mini.live:SetShown(live)
                    cool(mini)
                    if bind then
                        tint(mini)
                    end
                end
            end
        end
    end
end)
-- a cooldown began or ended; an action can be used or not
ns.Listen("screen:cool", "HudMini", function()
    each(cool)
end)
ns.Listen("screen:look", "HudMini", function()
    each(tint)
end)
