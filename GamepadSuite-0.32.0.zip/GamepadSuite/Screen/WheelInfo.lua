-- What a wheel tells of its entries, so that two pictures that look alike are not mixed up and a
-- flick is not spent on a thing that cools:
--   the name of the entry the stick points at, in the middle of the ring (two lines at most), half
--   dim while the game says that the entry cannot be used now, on a soft dark backing with Wheel
--   Background None (Screen/WheelPlate.lua Backing);
--   on each entry that cools down, the game's own cooldown swipe (Adapter.ShowCooldown: the game's
--   duration object for a spell, never a sum of ours), without the short cooldown of every cast;
--   an entry that the game says cannot be used now is grey, and blue while only the mana, rage or
--   energy is short: the one look of the on-screen buttons (HudFace.Unusable, decision 50);
--   a short rumble tick when the gold frame goes to another entry (Rumble.Pulse: the strength of the
--   Rumble row, none with Rumble Off), one for a quick sweep over a few (Screen/WheelModel.lua);
--   in a fight food and drink are gray, and the name reads "<name>, after combat" (ConsumableRules CALM);
--   the raid markers are gray with no target ("No target" in the middle), for a target that takes no mark,
--   and in a raid for a player who is not the leader or an assistant ("Leader or assistant only"); the
--   mark the target has now has a gold edge, the suite's look of a thing in use (Adapter.MarkState).
-- The quick chat wheel has its line in the middle already, and each member of the party wheel has
-- its name on its plate (Screen/WheelPlate.lua): neither has the name line. A line of words and a
-- member have nothing to ask the game about. The test wheel of the settings window asks nothing.
-- Screen/Wheel.lua says when it draws a wheel and when the stick points at another entry. The
-- swipes and the looks follow the game's events while a wheel is open, and only then. No timer.
local _, ns = ...

local Info = ns.Module("WheelInfo", nil, "Wheels")
ns.WheelInfo = Info

local Theme, Rules, Model, Plate = ns.Theme, ns.WheelRules, ns.WheelModel, ns.WheelPlate
local px = Theme.px

local ROUND = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
local DIM = 0.5         -- the name of an entry that cannot be used now
local MAX_NOTES = 6     -- lines for the log in one session
-- The game's events that change a cooldown or what can be used. They are heard while a wheel is open.
Info.EVENTS = { "SPELL_UPDATE_COOLDOWN", "BAG_UPDATE_COOLDOWN", "ACTIONBAR_UPDATE_COOLDOWN", "SPELL_UPDATE_USABLE", "ACTIONBAR_UPDATE_USABLE",
    "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "PLAYER_TARGET_CHANGED", "RAID_TARGET_UPDATE", "GROUP_ROSTER_UPDATE" }
local name              -- the line in the middle
local drawn = { cells = {}, entries = {} }   -- the wheel drawn last
local aimed, ticked     -- the entry the stick points at; when the last tick played
local told, notes = {}, 0
local marks             -- what a mark can do now, while the raid marker wheel is open (Adapter.MarkState)

-- A fight: from the game's word that it starts (at that word the game's lock is not on yet, Core/Core.lua).
local function fight()
    return ns.fightStarted or ns.Adapter.InCombat()
end

-- The edge of a picture: on the mark the target has now gold and two lines wide (thinner than the frame of the pick);
-- else black and one line, as Screen/Wheel.lua draws it, shown with Background Dark only.
local function edge(c, lit)
    if lit then
        c.edge:SetColorTexture(Theme.Color("gold"))
    elseif c.lit then
        c.edge:SetColorTexture(0, 0, 0, 1)
    end
    local by = px((lit and 2 or 1) * drawn.line)
    c.edge:ClearAllPoints()
    c.edge:SetPoint("TOPLEFT", c, "TOPLEFT", -by, by)
    c.edge:SetPoint("BOTTOMRIGHT", c, "BOTTOMRIGHT", by, -by)
    c.lit = lit
    c.edge:SetShown(lit or ns.Registry.Get("wheels.background") == "Dark")
end

-- What an entry uses, as a bind the game can be asked about: its own bind (a wheel of the player's
-- own), the item of a consumable or a quest item, the spell of a portal. nil for nothing to ask.
function Info.Bind(entry)
    return entry.bind or entry.item and { kind = "item", id = entry.item } or entry.spell and { kind = "spell", id = entry.spell } or nil
end

-- A picture of the ring gets the game's cooldown frame, round as the picture, and the count of an
-- item is lifted over the swipe.
local function make(c)
    c.cool = CreateFrame("Cooldown", nil, c, "CooldownFrameTemplate")
    c.cool:SetAllPoints(c.art)
    c.cool:SetSwipeTexture(ROUND)
    c.cool:SetSwipeColor(0, 0, 0, 0.7)
    c.cool:SetDrawEdge(false)
    local top = CreateFrame("Frame", nil, c)
    top:SetAllPoints()
    top:SetFrameLevel(c.cool:GetFrameLevel() + 1)
    c.count:SetParent(top)
end

-- An entry's swipe and look, again. (A member's portrait keeps its gray of the reach: not touched.) c.game is what the
-- game answered, for the log.
local function look(c)
    local usable
    if c.bind then
        usable = ns.Adapter.Usable(c.bind)
        ns.Adapter.ShowCooldown(c.cool, c.bind, true)
    else
        c.cool:Clear()
    end
    c.game = usable
    if c.calm and fight() then
        usable = false
    elseif c.marker and marks then
        usable = marks.can
    end
    if c.marker or c.lit then
        edge(c, c.marker ~= nil and marks ~= nil and marks.on == c.marker)
    end
    ns.HudFace.Unusable(c.art, usable)
    c.usable = usable
end

-- The line in the middle: the name of the entry in the gold frame, or why no mark can go on now.
local function say()
    local entry, c = drawn.entries[aimed], drawn.cells[aimed]
    local why, text = marks and marks.why, entry and entry.name
    name:SetText(why or text and c and c.calm and fight() and text .. ", after combat" or text or "")
    name:SetAlpha(not why and c and (c.bind or c.marker) and c.usable ~= true and DIM or 1)
    Plate.ShowBack(name.back, (why ~= nil or text ~= nil) and name:IsShown())
end

-- One try in the game tells what it answers in a fight: can each entry be used now, and does it hide
-- an item's cooldown (then no swipe shows). A line for each new set of answers, six in a session.
local function note()
    if notes >= MAX_NOTES or not ns.Adapter.InCombat() then
        return
    end
    local parts = {}
    for i, entry in ipairs(drawn.entries) do
        local bind = drawn.cells[i].bind
        if bind then
            parts[#parts + 1] = tostring(entry.name) .. " " .. tostring(drawn.cells[i].game)
                .. (bind.kind == "item" and ns.Adapter.ItemCooldownHidden(bind.id) and " (its cooldown is hidden: no swipe)" or "")
        end
    end
    local text = table.concat(parts, ", ")
    if text ~= "" and not told[text] then
        told[text], notes = true, notes + 1
        ns.Log.Add("wheel", "A wheel in a fight; can each entry be used now: " .. text .. ".")
    end
end

-- Screen/Wheel.lua drew a wheel: its ring, its pictures (cells), its entries, the entry in the gold frame, the size
-- of a picture and of the ring, and true for the test wheel of the settings window.
local function drew(ring, cells, entries, pointed, size, radius, test)
    if not name then
        name = Theme.Text(ring, "small", "cream")
        name:SetPoint("CENTER")
        name:SetJustifyH("CENTER")
        name:SetWordWrap(true)
        name:SetMaxLines(3)
        name.back = Plate.Backing(ring, name)
    end
    local first, line = entries[1] or {}, size / Rules.PICTURE
    drawn, aimed = { cells = cells, entries = entries, line = line }, pointed
    marks = first.mark and not test and ns.Adapter.MarkState() or nil
    name:SetShown(not (first.text or first.unit or first.blank))
    -- as wide as the inside of the ring; the letters fit about sixteen to a line, so the long names of
    -- the game's potions and bandages take two lines at most ("Heavy Runecloth" / "Bandage"), a drink
    -- in a fight three ("Conjured Crystal" / "Water, after" / "combat")
    name:SetFont(Theme.font.text, px(Theme.size.small * line / Rules.GAME), "")
    name:SetWidth(px(2 * radius - size - 2 * line))
    Plate.PlaceBack(name.back, px(10 * line), px(7 * line))
    for i, entry in ipairs(entries) do
        local c = cells[i]
        if not c.cool then
            make(c)
        end
        c.bind, c.calm, c.marker = Info.Bind(entry), entry.calm, entry.mark
        look(c)
    end
    say()
    note()
end

-- The game told of a change of a cooldown, of what can be used, of the fight or the target, while a wheel is open.
local function again()
    marks = marks and ns.Adapter.MarkState()
    for i in ipairs(drawn.entries) do
        if drawn.cells[i].bind or drawn.cells[i].marker then
            look(drawn.cells[i])
        end
    end
    say()
end

-- The gold frame went to another entry (nil: to none).
local function aim(pointed)
    aimed = pointed
    say()
    local now = GetTime()
    -- (a tick is left out while another pulse plays, as the range tick is: it would cut that one short)
    if pointed and not ns.Rumble.Busy() and Model.Tick(ticked, now) then
        ticked = now
        ns.Rumble.Pulse(Model.TICK, "the stick points at another entry of a wheel")
    end
end

function Info.OnLogin()
    ns.Listen("wheel:drawn", "WheelInfo", drew)
    ns.Listen("wheel:aim", "WheelInfo", aim)
    ns.Listen("wheel", "WheelInfo", function(id)
        for _, event in ipairs(Info.EVENTS) do
            if id then
                ns.On(event, "WheelInfo", again)
            else
                ns.Off(event, "WheelInfo")
            end
        end
    end)
end
