-- Whisper Pop-up: a whisper shows on the pop-up (Screen/Popup.lua) with the sender, in the colour of the class, a
-- line of what is known of them in the muted colour ("Level 23 Night Elf Hunter, Westfall"; a Battle.net friend's
-- character: "Bobchar, level 40 Mage, Orgrimmar"), and the words, for 8 seconds or until the next whisper. A whisper
-- that comes while a window, a wheel or the keyboard is open waits for it to close (60 seconds at most). The
-- player's own whispers out are never shown; a whisper of the player's to the sender takes that sender's pop-up
-- away. A Game Master's whisper reads "[GM] Bob whispers". The rumble of a whisper is the row Whispers of Rumble
-- Events (Auto/RumbleEvents.lua), not this file's.
--
-- Reply: hold Y for one second and let go. The chat keyboard opens with the chip Reply lit, to that sender
-- (Screen/KeyboardChat.lua, Chat.Reply: no chat box of the game's is opened or written).
-- Invite: hold X for one second and let go: the game invites the sender (Core/AdapterPopups.lua Adapter.Invite), and
-- the pop-up reads "Invited" for 2 seconds. The hint shows only when the player may invite that person now: a game
-- whisper, not a Game Master, the sender not in the group, the player in no group or its leader or an assistant, a
-- raid not full (Adapter.MayInvite). A call the game refuses turns the invite hold off for the session, with one
-- chat line. The holds are the pop-up's (Screen/PopupHold.lua): no key is taken, a tap of Y or X does its bind as
-- always. In combat the pop-up shows, its hints are dim, and no press is heard.
local _, ns = ...

local Whisper = ns.Module("WhisperPopup", { "whisperPopup" }, "Whisper Pop-up")
ns.WhisperPopup = Whisper

local ROW = "windows.whisper_popup"   -- the row; On while the settings lack it
local SECONDS, WAIT = 8, 60

local told = {}

-- One line in the log (kind "whisper") for each kind of thing, the first time in a session. Read from the saved file.
local function note(kind, text)
    if not told[kind] then
        told[kind] = true
        ns.Log.Add("whisper", text)
    end
end

local function on()
    return not ns.Registry.Has(ROW) or ns.Registry.Get(ROW) == true
end

-- A full hold of Y was let go: the keyboard opens for a reply to the whisper of the pop-up.
local function reply(item)
    local who = item.from
    ns.Popup.Hide("whisper")
    local chat = ns.KeyboardChat
    local opened = chat and chat.Reply and chat.Reply(who.to or true, who.name) or false
    note("reply", "a hold of Y asked the chat keyboard for a reply " .. (who.to and "by name" or "to the last whisper (Battle.net)")
        .. ": opened " .. tostring(opened))
    if not opened then
        ns.Print("Whisper Pop-up (Screen, Pop-ups) could not open the chat keyboard. Reply in the game's chat.")
    end
end

-- A full hold of X was let go: the game is asked to invite the sender. One second later the log says if they joined.
local function invite(item)
    local name = item.from.to
    local made = ns.Adapter.Invite(name)
    C_Timer.After(1, function()
        note("invite", "a hold of X asked the game to invite " .. tostring(item.from.name) .. ": the call was made: " .. tostring(made)
            .. "; in the group one second later: " .. tostring(ns.Adapter.InGroupNamed(name)))
    end)
    return made
end

local ACTS = {
    { key = "Y", words = "Hold to reply", go = "Let go to reply", fight = "Reply after combat", done = reply, log = "whisper reply" },
    { key = "X", words = "Hold to invite", go = "Let go to invite", fight = "Invite after combat", after = "Invited", log = "whisper invite",
        line = "Whisper Pop-up (Screen, Pop-ups): the invite hold is off for this session. The game did not let Gamepad Suite invite.",
        can = function(item)
            local may, why = ns.Adapter.MayInvite(item.from)
            if not may then
                note("no invite " .. why, "no invite hint: " .. why)
            end
            return may
        end,
        done = invite },
}

-- A whisper came.
local function heard(event, ...)
    if not on() then
        return
    end
    local whisper, why = ns.Adapter.Whisper(event, ...)
    if not whisper then
        note(why, "a whisper is not shown: " .. why .. " (" .. event .. ")")
        return
    end
    local got = ns.Popup.Show({ owner = "whisper", title = (whisper.gm and "[GM] " or "") .. whisper.name .. ns.Theme.Hex("cream")
        .. " whispers|r", color = whisper.color, facts = ns.PopupModel.Facts(whisper.facts or {}), text = whisper.text,
        seconds = SECONDS, wait = WAIT, acts = ACTS, key = "Y", from = whisper, who = whisper.key })
    note("came " .. tostring(got), "a whisper came (" .. event .. "): the pop-up "
        .. (got == true and "shows" or got == "wait" and "waits for the screen" or "does not show"))
end

-- The player whispered someone: a pop-up of that person goes, shown or waiting.
local function sent(...)
    local to = ns.Adapter.WhisperTo(...)
    if to then
        ns.Popup.Hide("whisper", to)
    end
end

function Whisper.OnLogin()
    for _, event in ipairs({ "CHAT_MSG_WHISPER", "CHAT_MSG_BN_WHISPER" }) do
        ns.On(event, "WhisperPopup", function(...)
            heard(event, ...)
        end)
    end
    ns.On("CHAT_MSG_WHISPER_INFORM", "WhisperPopup", sent)
    ns.On("CHAT_MSG_BN_WHISPER_INFORM", "WhisperPopup", sent)
    -- the group changed: who may be invited now
    ns.On("GROUP_ROSTER_UPDATE", "WhisperPopup", ns.PopupHold.Sync)
    ns.Listen("setting", "WhisperPopup", function(key)
        if key == ROW and not on() then
            ns.Popup.Hide("whisper")
        end
    end)
end
