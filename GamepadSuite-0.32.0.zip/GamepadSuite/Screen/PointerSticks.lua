-- Mouse mode's two stick frames (Screen/Pointer.lua has the pointer). They work as a wheel's do
-- (Screen/WheelModel.lua says why): the ear hears every stick and hands it on to the game, and
-- the wall, up for a moment, takes the camera's stick. So the right stick moves the pointer and
-- not the camera, and the left stick still walks. The frames are up only while mouse mode is on.
local _, ns = ...

local Sticks = {}
ns.PointerSticks = Sticks

local ear, wall
local up = false           -- mouse mode is on: the frames hear the sticks
local seen = { kept = 0, leaked = 0, walked = 0, stolen = 0 }   -- what the two frames saw (WheelModel.Stick)
local earOn = false        -- the ear's switch reads "on": it hands the sticks on to the game
local holdAll = false      -- the wall keeps every stick (see heard)
local moved, note          -- the pointer's side: fn(name, x, y) for each stick; fn(text) for the log

-- The game told one of the two frames of a stick (onWall: the wall). The wall goes up or down
-- for the next stick (Screen/WheelModel.lua), and the pointer hears the stick.
local function heard(name, onWall, sx, sy)
    if not up then
        return
    end
    sx, sy = sx or 0, sy or 0
    local raise = holdAll or ns.WheelModel.Stick(seen, name, onWall, GetTime(), true, sx * sx + sy * sy)
    -- The wall came too late for the camera's stick, time after time: from here on it keeps
    -- every stick while mouse mode is on, so that the camera stands still at least.
    if not holdAll and ns.WheelModel.TooLate(seen) then
        holdAll, raise = true, true
        note("the wall came too late for the camera's stick (" .. seen.leaked .. " passed, " .. seen.kept
            .. " taken): from now on it keeps every stick, and the left stick does not walk in mouse mode")
    end
    if raise ~= wall:IsShown() then
        wall:SetShown(raise)
    end
    moved(name, sx, sy)
end

-- Makes the two frames, hidden. onMove hears each stick while they are up, onNote writes a line
-- for the log, and onFault ends mouse mode. The wall is above the ear, so the game tells the
-- wall first while it is up. The ear's switch is set out of a fight: the game refuses it in one.
function Sticks.Build(onMove, onNote, onFault)
    moved, note = onMove, onNote
    ear = CreateFrame("Frame", "GamepadSuitePointerEar", UIParent)
    ear:SetFrameStrata("BACKGROUND")
    wall = CreateFrame("Frame", "GamepadSuitePointerWall", UIParent)
    wall:SetFrameStrata("TOOLTIP")
    for stickFrame, onWall in pairs({ [ear] = false, [wall] = true }) do
        stickFrame:Hide()
        stickFrame:EnableGamePadStick(true)
        stickFrame:SetScript("OnGamePadStick", function(_, name, sx, sy)
            -- a fault here would come at every move of a stick: it is logged once and mouse mode ends
            if not ns.Call("Pointer", heard, name, onWall, sx, sy) then
                onFault()
            end
        end)
    end
    ns.Queue.Run("PointerEar", function()
        earOn = ns.Adapter.HandSticksOn(ear)
    end)
end

-- Mouse mode came on: the ear hears the sticks. Gives what the ear's switch reads, for the log.
function Sticks.Start()
    up, seen = true, { kept = 0, leaked = 0, walked = 0, stolen = 0 }
    ear:Show()
    wall:SetShown(holdAll)
    return earOn
end

-- Mouse mode went off: no frame hears a stick. Gives what the frames saw, for the log.
function Sticks.Stop()
    up = false
    ear:Hide()
    wall:Hide()
    return string.format("Camera's stick: the wall took it %d times, it passed %d times. Walking stick: it passed %d times, the wall took it %d times.%s",
        seen.kept, seen.leaked, seen.walked, seen.stolen, holdAll and " The wall keeps every stick." or "")
end
