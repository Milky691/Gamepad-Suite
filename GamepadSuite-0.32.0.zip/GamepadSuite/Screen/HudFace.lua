-- One on-screen button: its parts, and what they show of a bind (a fixed slot is the same button: Screen/Slots.lua). A
-- button is made for one look (the row Button Look) and keeps it: the look's table in HudModel.lua says how large each
-- part is and which parts there are. Square is the plain button. Plate and Round cut the picture, its line and its rims
-- to a shape with a mask of the game (Core/AdapterLook.lua) and put a soft shadow under it. Also here: what those two looks
-- show behind and between the buttons of a group, the look of "cannot be used now" (Face.Unusable), and the peek over the
-- settings window (Face.Peek, ns.Screen.Peek). Colours and sizes are the Theme's; the cues in a fight are Screen/HudCues.lua.
local _, ns = ...

local Face = {}
ns.HudFace = Face

local Theme, Widgets, Model = ns.Theme, ns.Widgets, ns.HudModel
local px = Theme.px

-- our own two pictures, made by tools/art/make_hud_art.py: the soft shadows (the square one in the
-- left half, the round one in the right half), and a thin circle line for the edge of the plate
local SHADOW = "Interface\\AddOns\\GamepadSuite\\Art\\HudShadow.tga"
local RING = "Interface\\AddOns\\GamepadSuite\\Art\\HudRing.tga"
-- the circle line is 62 of the 64 units from the middle of its picture to the edge
local RING_GROW = 64 / 62
-- a shadow is half as large again as its button and sits three units lower
local SHADOW_GROW, SHADOW_DOWN = 0.25, 3
local RUN_LOW, RUN_GLOW = 0.75, 0.8   -- a queued or running action: its rim pulses down to this strength; its glow's strength

-- each button's look; the cooldown frame of the arc of a button of Round
local looks, arcs = {}, {}
-- what a look shows behind and between the buttons of a group: "Plate" .. "left" -> the frame
local backs = {}

-- A texture that stands out from a button by `by` on every side.
local function around(texture, b, by)
    texture:ClearAllPoints()
    texture:SetPoint("TOPLEFT", b, "TOPLEFT", -by, by)
    texture:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", by, -by)
end

-- Cuts a texture to the look's shape. width is the texture's width in units (anchor: Adapter.Shape).
local function shape(texture, look, width, anchor)
    if look.shape ~= "square" then
        ns.Adapter.Shape(texture, look.shape, px(width), anchor)
    end
end

Face.Shape = shape

-- A colored rim round a button's picture, in the look's shape. size is the picture's size. In
-- Square the picture's own edge covers the first two units of a rim.
local function rim(b, look, size, width, r, g, bl, a, level)
    local texture = b:CreateTexture(nil, "BACKGROUND", nil, level or 0)
    texture:SetColorTexture(r, g, bl, a)
    around(texture, b, px(width))
    texture:Hide()
    shape(texture, look, size + 2 * width)
    return texture
end

-- The parts of one on-screen button in a look (Square with none), without its place and without the picture of its
-- controller button. size is the picture's size in units: the shaped looks need it; a Square button can have any size.
function Face.Make(parent, look, size)
    look = look or Model.LOOKS.Square
    size = size or look.main
    local b = CreateFrame("Frame", nil, parent)
    looks[b] = look
    if look.shadow then
        b.shadow = b:CreateTexture(nil, "BACKGROUND", nil, -2)
        b.shadow:SetTexture(SHADOW)
        local left = look.shape == "round" and 0.5 or 0
        b.shadow:SetTexCoord(left, left + 0.5, 0, 1)
        b.shadow:SetVertexColor(0, 0, 0, look.shadow)
        local grow = px(size * SHADOW_GROW)
        b.shadow:SetPoint("TOPLEFT", b, "TOPLEFT", -grow, grow - px(SHADOW_DOWN))
        b.shadow:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", grow, -grow - px(SHADOW_DOWN))
    end
    if look.line then
        -- the dark line or ring round the picture; Face.Fill gives it its width and color
        b.line = rim(b, look, size, look.line[1], 0, 0, 0, 1, -1)
        b.line:Show()
    end
    b.icon = Widgets.Icon(b, px(48))
    b.icon:SetAllPoints()
    b.cooldown = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cooldown:SetAllPoints()
    b.cooldown:SetDrawEdge(false)
    if look.shape ~= "square" then
        -- the picture cut to the shape, the cooldown in it (Core/AdapterLook.lua)
        arcs[b] = ns.Adapter.Shaped(b, look, size)
    end
    if ns.HudCues then ns.HudCues.Make(b, look, size) end
    -- A frame of its own above the picture and the cooldown, for the count and the dark shade.
    -- The cooldown frame is hidden while no cooldown runs, so they cannot sit on it.
    b.over = CreateFrame("Frame", nil, b)
    b.over:SetAllPoints()
    b.over:SetFrameLevel(b.cooldown:GetFrameLevel() + 1)
    if look.shade then
        -- the picture goes dark while the controller button is held down
        b.shade = b.over:CreateTexture(nil, "ARTWORK")
        b.shade:SetColorTexture(0, 0, 0, look.shade)
        b.shade:SetAllPoints()
        b.shade:Hide()
        shape(b.shade, look, size)
    else
        -- Round: the picture stays bright, and the held button has the gold ring of a press
        b.shade = rim(b, look, size, look.flash, Theme.Color("gold"))
    end
    b.count = Theme.Text(b.over, "tiny", "cream")
    b.count:SetPoint("TOPRIGHT", -px(2), -px(2))
    -- a short gold rim when a bind of ours runs
    b.flash = rim(b, look, size, look.flash, Theme.Color("gold"))
    -- a gold rim that pulses while the action runs: a cast, a queued attack, auto attack, the form in use
    b.run = rim(b, look, size, look.run, Theme.Color("gold"))
    b.pulse = b.run:CreateAnimationGroup()
    b.pulse:SetLooping("BOUNCE")
    local alpha = b.pulse:CreateAnimation("Alpha")
    alpha:SetFromAlpha(1)
    alpha:SetToAlpha(RUN_LOW)
    alpha:SetDuration(0.7)
    -- and a soft gold glow round it (the shadow art in gold), so a queued attack is easy to see
    b.runGlow = b:CreateTexture(nil, "BACKGROUND", nil, -1)
    b.runGlow:SetTexture(SHADOW)
    local half = look.shape == "round" and 0.5 or 0
    b.runGlow:SetTexCoord(half, half + 0.5, 0, 1)
    b.runGlow:SetVertexColor(Theme.Color("gold", RUN_GLOW))
    local out = px(size * SHADOW_GROW)
    b.runGlow:SetPoint("TOPLEFT", b, "TOPLEFT", -out, out)
    b.runGlow:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", out, -out)
    b.runGlow:Hide()
    -- a green rim on an item that is worn
    b.worn = rim(b, look, size, look.worn, 0, 1, 0, 0.5)
    return b
end

-- What a button of the two groups has and a fixed slot has not: a thin rim in the form's color on a button whose bind is
-- the form's own (the row Form Ring), and the game's own picture of its controller button. slot: its HudModel.Buttons entry.
function Face.Badge(b, look, slot)
    b.form = rim(b, look, slot.size, look.form, 1, 1, 1, 0.9)
    local x, y, size = Model.KeyPlace(look, slot.size, slot.main)
    if x then
        b.glyph = Widgets.Glyph(b, slot.key, px(size))
        b.glyph:SetPoint("CENTER", b, "CENTER", px(x), px(y))
        b.glyph:SetFrameLevel(b.cooldown:GetFrameLevel() + 3)   -- (over the face of Screen/HudParty.lua)
    end
end

-- A cooldown began or ended: the button's clock and nothing else, as the game's own buttons do at its cooldown events
-- (Blizzard_ActionBar/Shared/ActionButton.lua:1010). b.noShared (a cooldown list line) leaves out every cast's short one.
function Face.Cool(b)
    ns.Adapter.ShowCooldown(b.cooldown, b.bind or nil, b.noShared)
    if arcs[b] then
        ns.Adapter.ShowCooldown(arcs[b], b.bind or nil, b.noShared)
    end
    if ns.HudCues then ns.HudCues.Cool(b) end
    if ns.HudSwing then ns.HudSwing.Show(b, arcs[b]) end
end

-- The bags changed: the button's count, and nothing else.
function Face.Count(b)
    ns.Adapter.ShowCount(b.count, b.bind or nil)
end

-- What a button shows of its bind: the picture, the cooldown and the count. numbers is the setting Cooldown Numbers.
function Face.Fill(b, bind, numbers)
    local look = looks[b]
    b.bind = bind or false
    local icon = bind and ns.Adapter.BindIcon(bind)
    b.icon:SetIcon(icon)
    if ns.HudCues then ns.HudCues.Fill(b, bind or nil, icon) end
    b.signature = bind and ns.BindCore.Signature(bind) or nil
    b.cooldown:SetHideCountdownNumbers(numbers == "Off")
    b.cooldown:SetScale(numbers == "Small" and 0.75 or 1)
    Face.Cool(b)
    Face.Count(b)
    if bind then
        -- the game tells with an event when the target goes out of this action's reach
        ns.Adapter.WatchRange(bind)
    end
    -- a button with no bind: a faint cream line, a dark plate in place of the picture, no shadow
    if look.line then
        local line = bind and look.line or look.emptyLine
        around(b.line, b, px(line[1]))
        if bind then
            b.line:SetColorTexture(0, 0, 0, line[2])
        else
            b.line:SetColorTexture(Theme.Color("cream", line[2]))
        end
    end
    if look.emptyFill then
        b.fill:SetShown(not bind)
    end
    if look.shadow then
        b.shadow:SetShown(bind and true or false)
    end
end

-- Puts a button of the two groups at its place in its group and shows its bind. slot is its entry of HudModel.Buttons.
-- interact: it is the button of Dynamic Interact and something is in reach. ring: the color of its form ring, or nil.
local INTERACT = { kind = "interact", icon = "Interface\\Cursor\\Interact" }
function Face.Show(b, look, slot, group, interact, numbers, ring)
    local bind = interact and INTERACT or slot.bind
    local size = px(slot.size)
    b:SetSize(size, size)
    b:ClearAllPoints()
    b:SetPoint("CENTER", group, "CENTER", px(slot.x), px(slot.y))
    b:Show()
    Face.Fill(b, bind, numbers)
    if interact then
        -- the game's own picture for the thing in reach: speech bubble, loot bag, letter
        ns.Adapter.InteractPicture(b.icon.art)
    end
    -- a button with no action stays, so each group keeps its shape: dim in Square, a faint plate
    -- in the other looks. One that is not in the LB + RB layer steps back while LB + RB is held.
    b:SetAlpha((not bind and look.faint) or (slot.back and 0.3) or 1)
    b.form:SetShown(ring ~= nil)
    if ring then
        b.form:SetColorTexture(ring[1], ring[2], ring[3], 0.9)
    end
    Face.Look(b)
end

-- "Cannot be used now", drawn one way on every picture of an action: the on-screen buttons, the fixed slots and the
-- cooldown list (Face.Look), Other Layers, a wheel's entries and the party wheel's spell. The picture takes the Theme's red
-- for a target too far, blue while only the mana, rage or energy is short, grey while the game says it cannot be used
-- (HudModel.Tint), else its own colours; a dim of its own is the part's. usable: Adapter.Usable's answer, nil for none; far: too far.
function Face.Unusable(texture, usable, far)
    local name = Model.Tint(usable, far)
    if name then
        texture:SetVertexColor(Theme.Color(name))
    else
        texture:SetVertexColor(1, 1, 1)
    end
    return name
end

-- The looks that change with no new picture: the target moves out of reach, mana runs out, an
-- attack waits for the next swing.
function Face.Look(b)
    local bind, usable, far = not rawget(b, "who") and b.bind or nil, nil, nil   -- (who: a face of Screen/HudParty.lua covers it)
    if bind then
        usable, far = ns.Adapter.Usable(bind), ns.Adapter.OutOfRange(bind)
    end
    Face.Unusable(b.icon.art, usable, far)
    local running = bind and ns.Adapter.Running(bind) or false
    b.run:SetShown(running)
    b.runGlow:SetShown(running)
    -- the pulse runs only while the rim shows
    if running and b.pulsing ~= true then
        b.pulse:Play()
    elseif not running and b.pulsing == true then
        b.pulse:Stop()
    end
    b.pulsing = running
    b.worn:SetShown(bind and ns.Adapter.Equipped(bind) or false)
end

-- The peek: after a change of a part's place or size in the settings window, that part shows over
-- the window for three seconds from the last change of any of them. One timer for every part (the
-- buttons, the fixed slots, the cooldown list, the test wheel); at its end each part is told once.
local PEEK, peekEnd, peekers, timing = 3, 0, {}, false
local function peekOver()
    if GetTime() < peekEnd then
        return C_Timer.After(peekEnd - GetTime(), peekOver)
    end
    local done = peekers
    peekers, timing = {}, false
    for name, fn in pairs(done) do
        ns.Call(name, fn)
    end
end
-- name: the part's module; done: what it draws when the peek ends. With no done its peek ends now.
function Face.Peek(name, done)
    peekers[name] = done
    if done then
        peekEnd = GetTime() + PEEK
        if not timing then
            timing = true
            C_Timer.After(PEEK, peekOver)
        end
    end
end
-- True while the part peeks. frame: it stands over the settings window then, else in normal (MEDIUM).
function Face.Peeking(name, frame, normal)
    local on = peekers[name] ~= nil and GetTime() < peekEnd
    if frame then
        frame:SetFrameStrata(on and "TOOLTIP" or normal or "MEDIUM")
    end
    return on
end

-- A flat disc: the game's circle as a texture, in a color.
local function disc(parent, layer, size, r, g, bl, a)
    local texture = parent:CreateTexture(nil, layer)
    texture:SetTexture(Theme.art.circle)
    texture:SetVertexColor(r, g, bl, a)
    texture:SetSize(px(size), px(size))
    texture:SetPoint("CENTER")
    return texture
end

-- The mark in the middle of the A B X Y group of Round: a dark disc with a dot for each of the
-- four, where that button sits in the group.
local function mark(parent, size)
    local frame = CreateFrame("Frame", nil, parent)
    frame:SetSize(px(size), px(size))
    disc(frame, "BACKGROUND", size, 0, 0, 0, 1)
    disc(frame, "BORDER", size - 2, 0.05, 0.05, 0.05, 1)
    local dots = {}
    for _, key in ipairs({ "Y", "X", "B", "A" }) do
        local place, reach = Model.PLACE[key], size * Model.DOTS.reach
        dots[key] = disc(frame, "ARTWORK", size * Model.DOTS.size, 1, 1, 1, 1)
        dots[key]:SetPoint("CENTER", frame, "CENTER", px(place[2] * reach), px(place[3] * reach))
    end
    return frame, dots
end

local function makeBack(group, look, name)
    local back = CreateFrame("Frame", nil, group)
    back:SetAllPoints()
    -- under the buttons; the pictures in the middle are over the buttons' shadows
    local level = group:GetFrameLevel()
    back:SetFrameLevel(math.max(0, level - 1))
    if look.plate then
        local plate = look.plate
        disc(back, "BACKGROUND", 2 * plate.radius, plate.fill[1], plate.fill[2], plate.fill[3], plate.fill[4])
        local edge = disc(back, "BORDER", 2 * plate.radius * RING_GROW, Theme.Color("cream", plate.edge))
        edge:SetTexture(RING)
    end
    if look.label then
        -- the name of the layer in view, on a dark strip with a half circle at each end
        local label = look.label
        local high, fill = px(label.height), label.fill
        local strip = back:CreateTexture(nil, "ARTWORK")
        back.named = { strip }
        strip:SetColorTexture(fill[1], fill[2], fill[3], fill[4])
        strip:SetSize(px(label.width) - high, high)
        strip:SetPoint("CENTER", back, "CENTER", 0, px(Model.LabelRow(look)))
        for _, side in ipairs({ "LEFT", "RIGHT" }) do
            local half = side == "LEFT" and 0 or 0.5
            local cap = disc(back, "ARTWORK", label.height, fill[1], fill[2], fill[3], fill[4])
            cap:SetTexCoord(half, half + 0.5, 0, 1)
            cap:SetWidth(high / 2)
            cap:ClearAllPoints()
            cap:SetPoint(side == "LEFT" and "RIGHT" or "LEFT", strip, side)
            back.named[#back.named + 1] = cap
        end
        back.label = Theme.Text(back, label.text, "cream")
        back.label:SetPoint("CENTER", strip, "CENTER")
        back.named[#back.named + 1] = back.label
    end
    back.mids = {}
    for i, mid in ipairs(Model.Middle(look, name)) do
        local frame, dots
        if mid.key == "MARK" then
            frame, dots = mark(back, mid.size)
        else
            frame = Widgets.Glyph(back, mid.key, px(mid.size))
        end
        frame:SetPoint("CENTER", back, "CENTER", px(mid.x), px(mid.y))
        frame:SetFrameLevel(level + 1)
        back.mids[i] = { key = mid.key, frame = frame, dots = dots }
    end
    return back
end

-- Shows what a look has behind and between the buttons of each group: the plate, the name of the layer in view (the names
-- of the bind list; nothing while no trigger is held), the pictures of the four main buttons. bound[key] is true for a
-- button that has an action now: the picture or the dot of one with none is dim.
function Face.Backs(groups, look, layer, bound)
    for _, back in pairs(backs) do
        back:Hide()
    end
    if not look.middle then
        return
    end
    for name, group in pairs(groups) do
        local id = look.name .. name
        backs[id] = backs[id] or makeBack(group, look, name)
        local back = backs[id]
        back:Show()
        if look.label then
            back.label:SetText(layer > 1 and ns.BindsModel.LAYERS[layer] or "")
            for _, part in ipairs(back.named) do
                part:SetShown(layer > 1)
            end
        end
        for _, mid in ipairs(back.mids) do
            if mid.dots then
                for key, dot in pairs(mid.dots) do
                    local color = bound[key] and Model.DOTS[key] or Model.DOTS.none
                    dot:SetVertexColor(color[1], color[2], color[3])
                end
            else
                -- (the game's picture of the D-pad is one picture: its arms cannot light one by one)
                local lit = bound[mid.key]
                if mid.key == "DPAD" then
                    lit = bound.DU or bound.DD or bound.DL or bound.DR
                end
                mid.frame:SetAlpha(lit and 1 or look.middle.faint)
            end
        end
    end
end
