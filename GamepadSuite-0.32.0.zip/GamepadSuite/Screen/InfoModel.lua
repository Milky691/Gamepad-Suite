-- The rules of the info bar, with no game calls: what each reading says. InfoBar.lua draws them.
local _, ns = ...

local Model = {}

-- The sizes of the approved sample (mockups/infobar_sample.py), in its units.
Model.STRIP, Model.ROW, Model.LINE_AT, Model.LINE = 28, 22, 22, 480
Model.GAP, Model.MARK, Model.COIN = 36, 12, 8
-- The hearthstone pip is a small round picture, a little larger than a coin.
Model.PIP = 12
-- Seconds added to the wait for the end of a cooldown: a read made at the very second can still see it.
Model.SLACK = 0.2

-- Money in copper, as gold, silver and copper.
function Model.Money(copper)
    return math.floor(copper / 10000), math.floor(copper % 10000 / 100), copper % 100
end

-- The state of the gear in percent: the piece that is worn down most. pieces is a list of
-- { now, most }. nil when the character wears nothing that can wear down.
function Model.Gear(pieces)
    local worst
    for _, piece in ipairs(pieces) do
        if piece[2] and piece[2] > 0 then
            local part = piece[1] / piece[2]
            if not worst or part < worst then
                worst = part
            end
        end
    end
    return worst and math.floor(worst * 100 + 0.5) or nil
end

-- The place on the map as the game's own maps show it: "52.0, 30.0". x and y run from 0 to 1.
function Model.Place(x, y)
    return string.format("%.1f, %.1f", x * 100, y * 100)
end

-- The zone and the place in it, as the game names them: "Westfall, Sentinel Hill". A place with no name of its own,
-- or with the zone's own name, is not said twice. nil with no zone.
function Model.Zone(zone, sub)
    if type(zone) ~= "string" or zone == "" then
        return nil
    end
    return type(sub) == "string" and sub ~= "" and sub ~= zone and zone .. ", " .. sub or zone
end

-- The hearthstone pip after a read of the game. read = { item = the number of the hearth item the
-- character has (nil for none), cooling = true or false, nil when the game hides it (in a fight some
-- numbers are hidden), ends = the game's clock at the end of the cooldown }. last is the state before
-- (nil at the first read) and now is the game's clock. Gives the state, { ready =, ends = }, and the
-- seconds to wait before the cooldown is read again, nil when no end is awaited. A hidden answer
-- keeps what was known, and the clock decides when a known end has come. With nothing known, no pip.
function Model.Hearth(read, last, now)
    if not read.item then
        return { ready = false }
    end
    local ready, ends
    if read.cooling == nil then
        ready, ends = last and last.ready or false, last and last.ends
        if not ready and ends and ends <= now then
            ready, ends = true, nil
        end
    else
        ready, ends = not read.cooling, read.cooling and read.ends or nil
    end
    local wait = not ready and ends and math.max(ends - now, 0) + Model.SLACK or nil
    return { ready = ready, ends = ends }, wait
end

-- The experience toward the next level in whole percent, rounded down so it never says 100 before the level
-- comes, and the next level. xp = { now, most, level, top = the top level, off = turned off at an NPC }. nil at the
-- top level, while it is turned off (the game's own bar hides then), and while the game has no numbers yet.
function Model.Experience(xp)
    if xp.off or not (xp.level and xp.top and xp.most) or xp.level >= xp.top or xp.most <= 0 then
        return nil
    end
    return math.min(math.floor(xp.now / xp.most * 100), 99), xp.level + 1
end

-- The readings to show, from left to right. game = { paused = the automation is paused, money = copper, bags = free
-- bag slots, gear = pieces, zone = Model.Zone, x =, y =, xp = the experience (Model.Experience), latency = milliseconds, frames = frames
-- per second, hearth = the picture of the hearthstone while it is in the bags and ready }. A reading the game cannot
-- give now is left out (the numbers of the place inside a dungeon, the gear of a character with none, the experience at
-- the top level, the hearthstone that cools down). The place is the zone, then the numbers: "Westfall, Sentinel Hill  52.0, 30.0".
-- Each reading is { mark = "paused" | "money" | "bags" | "gear" | "place" | "xp" | "latency" | "frames" | "hearth",
-- text =, unit = }, and money has gold, silver, copper in place of text; the hearth has icon in place of text.
function Model.Readings(game)
    local out = {}
    if game.paused then
        out[#out + 1] = { mark = "paused", text = "Automation paused" }
    end
    if game.money then
        local gold, silver, copper = Model.Money(game.money)
        out[#out + 1] = { mark = "money", gold = gold, silver = silver, copper = copper }
    end
    if game.bags then
        out[#out + 1] = { mark = "bags", text = tostring(game.bags), unit = "free" }
    end
    local gear = game.gear and Model.Gear(game.gear)
    if gear then
        out[#out + 1] = { mark = "gear", text = tostring(gear), unit = "%" }
    end
    local at = game.x and game.y and Model.Place(game.x, game.y)
    if game.zone or at then
        out[#out + 1] = { mark = "place", text = game.zone and at and game.zone .. "  " .. at or game.zone or at }
    end
    local percent, nextLevel
    if game.xp then
        percent, nextLevel = Model.Experience(game.xp)
    end
    if percent then
        -- (blue while the character is rested, the colour the game gives rested experience)
        out[#out + 1] = { mark = "xp", text = tostring(percent), unit = "% toward " .. nextLevel, color = game.xp.rested and "blue" or nil }
    end
    if game.latency then
        out[#out + 1] = { mark = "latency", text = tostring(math.floor(game.latency + 0.5)), unit = "ms" }
    end
    if game.frames then
        out[#out + 1] = { mark = "frames", text = tostring(math.floor(game.frames + 0.5)), unit = "fps" }
    end
    if game.hearth then
        out[#out + 1] = { mark = "hearth", icon = game.hearth }
    end
    return out
end

if ns then
    ns.InfoModel = Model
end
return Model
