-- The rules of mouse mode, with no game calls: how the stick moves the pointer, and which
-- controller button is which mouse button.
local _, ns = ...

local Model = {}

Model.DEAD = 0.12   -- a stick pushed less than this does not move the pointer
Model.SPEED = 1200  -- units of the screen in a second, with the stick pushed all the way

-- The mouse button of a controller button in mouse mode, by the game's names.
Model.BUTTON = { PADLTRIGGER = "LeftButton", PADRTRIGGER = "RightButton" }

-- The stick that moves the pointer, by the names the game gives it.
Model.STICK = { Right = true, Camera = true, Look = true }

-- The names of the layers of a bind, for the player.
Model.FRONT = { "", "LT + ", "RT + ", "LT + RT + ", "LB + RB + " }

-- View + Menu: how the pair hears View now. action is what View's key does with no key of ours on
-- it: the name of a button it clicks (a bind of the player's, or the game's own button for its
-- party frames or a window), "" for none (then the game's own Focus UI runs, a call that can be
-- heard), nil for another command of the game. layer is the layer of a bind of the player's on
-- View that can come in use, windows how many windows of the game are open, gameplay false
-- while one of them has the controller.
-- Gives "ours" while View has no job (no bind, no window: the game's Focus UI would only say that
-- there is nothing to focus), "heard" while View keeps its job and its press is heard, or nil:
-- the pair rests.
function Model.ViewWay(action, layer, windows, gameplay)
    if action == "" and not layer and windows == 0 and gameplay then
        return "ours"
    end
    return action and "heard" or nil
end

-- The pair rests: View runs a command of the game, which no addon can hear, and a key of ours on
-- View would take it away. The words for the log and the player: where the bind is (the layer
-- and the set of the player's bind on View; none: a window of the game put it there), and what
-- works in place of the pair.
function Model.Rests(layer, set)
    local where = layer and (Model.FRONT[layer] .. "View has a command of the game in "
        .. (set == "normal" and "your binds" or set == "combat" and "Combat Binds" or "Form and Stance Binds"))
    return "Mouse Mode Buttons (View + Menu) does not work now: " .. (where or "one of the game's windows gave View its own command")
        .. ", and Gamepad Suite cannot see that press. The bind Mouse Mode, in the list Game Actions, works on any button."
end

-- The pointer's next place. sx and sy are the stick (-1 to 1, up is more), elapsed the seconds
-- since the last step. The speed grows with the square of the push: a small push is slow, for a
-- small target. The pointer stays on the screen (0 to width, 0 to height).
function Model.Step(x, y, sx, sy, elapsed, width, height)
    local push = math.sqrt(sx * sx + sy * sy)
    if push <= Model.DEAD then
        return x, y
    end
    local part = math.min(1, (push - Model.DEAD) / (1 - Model.DEAD))
    local move = Model.SPEED * part * part * elapsed
    return math.max(0, math.min(width, x + sx / push * move)), math.max(0, math.min(height, y + sy / push * move))
end

-- The game's notes do not say in which units it wants the pointer's place: the units of
-- GetCursorPosition, or those of our frames (scale times smaller). want is what was asked for
-- and got what the game then said, both for one axis. Gives the number to multiply a place by
-- from now on (1 when what was asked for is what came), or nil when the two fit in no way: the
-- game had not moved its pointer yet.
function Model.Units(want, got, scale)
    if want == 0 then
        return nil
    elseif math.abs(got - want) <= 2 then
        return 1
    elseif math.abs(got / scale - want) <= 2 then
        -- the game took the number as units of our frames
        return 1 / scale
    elseif math.abs(got * scale - want) <= 2 then
        return scale
    end
    return nil
end

-- The magnet (Screen/PointerMagnet.lua): when the stick comes back to the middle, the pointer
-- slides onto the nearest thing of an open window that takes a click.
Model.REACH = 120   -- it pulls from this far at most, in units of our frames
Model.INSET = 10    -- it goes this far into a thing past the edge nearest to it (to the middle of a small one)
Model.SLIDE = 0.15  -- seconds the slide takes
-- The game's frame layers, low to high: a window on a higher one is drawn over a lower one.
Model.STRATA = { BACKGROUND = 1, LOW = 2, MEDIUM = 3, HIGH = 4, DIALOG = 5, FULLSCREEN = 6, FULLSCREEN_DIALOG = 7, TOOLTIP = 8 }

-- True when the place x, y is on the box { left, bottom, right, top }.
function Model.On(x, y, box)
    return x >= box[1] and x <= box[3] and y >= box[2] and y <= box[4]
end

-- True when the place x, y of a thing is not under a window of a higher layer.
local function seen(x, y, thing, windows)
    for _, window in ipairs(windows) do
        if window.layer > thing.layer and Model.On(x, y, window) then
            return false
        end
    end
    return true
end

-- Where the pointer at x, y slides to: the nearest place within reach that is inset into one of
-- the things (boxes, each with the layer of its window). A thing under a window of a higher layer
-- cannot be seen, so it does not count. A pointer that is on a thing already stays where it is.
-- nil when no thing is in reach (the pointer is over the world).
function Model.Magnet(x, y, things, windows, reach, inset)
    local best, toX, toY = reach * reach
    for _, thing in ipairs(things) do
        local inX, inY = math.min(inset, (thing[3] - thing[1]) / 2), math.min(inset, (thing[4] - thing[2]) / 2)
        local tx = math.max(thing[1] + inX, math.min(thing[3] - inX, x))
        local ty = math.max(thing[2] + inY, math.min(thing[4] - inY, y))
        local far = (tx - x) * (tx - x) + (ty - y) * (ty - y)
        if far <= best and seen(tx, ty, thing, windows) then
            best, toX, toY = far, tx, ty
        end
    end
    return toX, toY
end

-- What the pointer at x, y rests on (Screen/PointerAim.lua): the thing under it that is seen, on
-- the highest layer, and of those the smallest (a button in a row, not the row); else the window
-- under it (its face: no button there); else nil, the world.
function Model.Under(x, y, things, windows)
    local best, size
    for _, thing in ipairs(things) do
        local area = (thing[3] - thing[1]) * (thing[4] - thing[2])
        if Model.On(x, y, thing) and seen(x, y, thing, windows)
            and (not best or thing.layer > best.layer or thing.layer == best.layer and area < size) then
            best, size = thing, area
        end
    end
    if best then
        return best
    end
    for _, window in ipairs(windows) do
        if Model.On(x, y, window) then
            return window
        end
    end
end

-- True when the game's pointer (gx, gy) is where ours is (x, y): a click of the game's then goes
-- under our picture. The game rounds a place it takes, so a few units off still count.
Model.NEAR = 3
function Model.Near(x, y, gx, gy)
    return math.abs(gx - x) <= Model.NEAR and math.abs(gy - y) <= Model.NEAR
end

-- The place on a slide from fromX, fromY to toX, toY, t seconds after it began: slow at the start
-- and at the end, so a stick that only passes the middle (a turn) hardly moves it. The third value
-- is true when it has arrived.
function Model.Slide(fromX, fromY, toX, toY, t)
    local part = math.min(1, t / Model.SLIDE)
    local eased = part * part * (3 - 2 * part)
    return fromX + (toX - fromX) * eased, fromY + (toY - fromY) * eased, part >= 1
end

if ns then
    ns.PointerModel = Model
end
return Model
