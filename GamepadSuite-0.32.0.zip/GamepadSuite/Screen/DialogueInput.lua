-- The buttons of the dialogue view (Screen/Dialogue.lua): the frame that hears the controller
-- while a talk shows, the keyboard's Escape (leave) and Space (as A), and the clicks on the rows,
-- the rewards and the button hints (Screen/DialogueSide.lua, DialogueFoot.lua).
-- The frame keeps every button of the controller: each script says false, "not for the game".
-- It takes no stick, so the camera turns and the character can walk away. Inside a press only
-- the view's own state, its own drawing and the game's interface sounds change; a step of the
-- game is handed to the module, which makes it one frame later.
local _, ns = ...

local Model, Side, Foot = ns.DialogueModel, ns.DialogueSide, ns.DialogueFoot

local Input = {}
ns.DialogueInput = Input

-- the game's own sounds of its gossip and quest windows (GossipFrameShared.lua 170 and 182,
-- Mainline/QuestFrame.lua 172 and 475), by the step a press asks for
local SELECT, OPEN = "IG_QUEST_LIST_SELECT", "IG_QUEST_LIST_OPEN"
local SOUND = { option = SELECT, gossipOffer = SELECT, gossipActive = SELECT, greetOffer = SELECT, greetActive = SELECT,
    accept = OPEN, ack = OPEN, complete = OPEN, leave = "IG_QUEST_LIST_CLOSE" }

local view                  -- the module's side: talk(), note, guarded, step(name, value, leave), draw(how), fail(why)
local input, ear
local aDown, sentAt, signs = false, 0, 0

-- A press of A that cannot act: what is missing lights up for 0.2 seconds (Side.Sign, Foot.Sign).
local function sign(talk)
    signs = signs + 1
    local mine = signs
    Side.Sign(talk, true)
    Foot.Sign(true)
    C_Timer.After(0.2, function()
        if mine == signs then
            Side.Sign(nil, false)
            Foot.Sign(false)
        end
    end)
end

-- What a press or a click changed (Model.Press, Model.Click) shows, and a step of the game is
-- handed on. button: the button or the click, for the log.
local function act(talk, button, what, name, value)
    if talk.manual and Foot.Timing() then
        -- the player turns the text by hand: it no longer moves on by itself in this talk
        Foot.Time(nil)
        view.note(button .. ": the text no longer moves on by itself in this talk", "manual")
    end
    if what == "do" then
        view.note(button .. ": " .. name .. (value and " " .. tostring(value) or ""))
        sentAt = GetTime()
        if SOUND[name] then
            ns.Adapter.Sound(SOUND[name])
        end
        view.step(name, value, name == "leave")
    elseif what == "focus" then
        view.note(button .. ": the focus is on " .. talk.focus)
        local tip = Side.Focus(talk)
        if tip then
            view.note(tip, "tip")
        end
        Foot.Hints(Model.Hints(talk))
    elseif what == "sign" then
        view.note(button .. ": nothing to do yet: the " .. talk.kind .. " shows what is missing", "sign" .. talk.kind)
        if name then
            view.draw("part")
        end
        sign(talk)
    elseif what then
        if what == "confirm" then
            sentAt = GetTime()
        end
        view.note(button .. ": " .. (what == "part" and "part " .. talk.part .. " of " .. talk.count or "the game's question, " .. tostring(talk.confirm)))
        view.draw("part")
    else
        view.note(button .. ": nothing", "nothing" .. button)
    end
end

-- A button went down, by our name for it.
local function press(button)
    local talk = view.talk()
    if not (button and talk) then
        return
    elseif ns.PointerPair and ns.PointerPair.Heard(button) then
        -- mouse mode's press (View + Menu, or the bind Mouse Mode): Screen/PointerPair.lua
        return
    elseif button == "A" then
        -- a held A is one press, and an A in the half second after a step of the game, or after
        -- a talk opened, is none
        if aDown or GetTime() - sentAt < 0.5 then
            return
        end
        aDown = true
    end
    act(talk, button, Model.Press(talk, button))
end

local function release(button)
    if button == "A" then
        aDown = false
    end
end

-- A key or a click that does what a button does: Space (A), Escape (B), a click on a button
-- hint, the mouse wheel over the list (up or down).
function Input.Key(button)
    view.guarded(press, button)
    view.guarded(release, button)
end

-- A left click on row or item n at the right (Model.Click), by the mouse or by mouse mode's
-- LT. The view keeps no button in mouse mode, so this is how a row is taken there. Like A, a
-- click in the half second after a step of the game, or after a talk opened, does nothing.
function Input.Click(n)
    view.guarded(function()
        local talk = view.talk()
        if talk and GetTime() - sentAt >= 0.5 then
            act(talk, "click on " .. n, Model.Click(talk, n))
        end
    end)
end

-- A talk ended: no button is down for the next one, and every key of the keyboard goes on to
-- the game again (Escape and Space took that away for themselves). Not at the start of combat:
-- the game refuses the switch in combat.
function Input.Rest()
    aDown = false
    if ear and not (ns.fightStarted or ns.Adapter.InCombat()) then
        ear:SetPropagateKeyboardInput(true)
    end
end

-- A new talk shows. A press of A in its first half second does nothing (the button that opened
-- the talk, pressed twice, does not accept a quest unread). Every key but Escape and Space goes
-- on to the game from the first key on. (The view does not open in combat.)
function Input.Fresh()
    sentAt = GetTime()
    if ear and not ns.Adapter.InCombat() then
        ear:SetPropagateKeyboardInput(true)
    end
end

-- Makes the frames under root, hidden, and gives the one that hears the controller: it is
-- shown while the view has the controller. Made out of combat: the game refuses a frame's
-- switch for the controller in combat. module: the module's side (see above).
function Input.Build(root, module)
    view = module
    input = CreateFrame("Frame", nil, root)
    input:SetSize(1, 1)
    input:SetPoint("BOTTOMLEFT")
    input:Hide()
    input:EnableGamePadButton(true)
    input:SetScript("OnGamePadButtonDown", function(_, name)
        view.guarded(press, ns.Adapter.NAME[name])
        return false
    end)
    input:SetScript("OnGamePadButtonUp", function(_, name)
        view.guarded(release, ns.Adapter.NAME[name])
        return false
    end)
    -- The frame hears no let-go while it is hidden. So when it shows, A is down or not as the
    -- controller itself says: else an A that was let go between two windows of a talk would
    -- count as held, and the next press of A would do nothing.
    input:SetScript("OnShow", function()
        aDown = ns.Adapter.ButtonDown("A")
    end)
    -- Escape leaves, as B does, and Space does what A does. The ear hands every other key on to
    -- the game, and it hears the keys only when the game took the switch for that. In combat
    -- the game refuses the switch: the keys are the game's there.
    local keys = CreateFrame("Frame", nil, input)
    keys:SetSize(1, 1)
    keys:SetPoint("BOTTOMLEFT")
    if ns.Adapter.HandSticksOn(keys) then
        ear = keys
        ear:EnableKeyboard(true)
        ear:SetScript("OnKeyDown", function(self, key)
            if not ns.Adapter.InCombat() then
                local button = key == "ESCAPE" and "B" or key == "SPACE" and "A" or nil
                self:SetPropagateKeyboardInput(button == nil)
                if button then
                    Input.Key(button)
                end
            end
        end)
    end
    view.note("Escape leaves the view and Space does what A does: " .. tostring(ear ~= nil))
    return input
end
