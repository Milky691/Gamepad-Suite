-- Camera zoom with the right stick. A controller has no scroll wheel, so while a hold is on, the
-- right stick pushed up zooms the camera in and pushed down zooms it out, faster the harder it is
-- pushed. For that time the camera does not turn, and the left stick still walks. Two holds do it.
--
-- The bind Stick Zoom, in the list Camera: while its button is held, the stick zooms. It is the
-- way for a player who has binds on LB and RB.
--
-- LB + RB, with the setting Stick Zoom on: hold LB, then press RB. LB and RB keep their own binds.
-- RB held first and LB pressed after it zooms too: the two often come down in the same moment.
-- With no bind on either, LB and RB are the game's own two targeting buttons: held together they
-- are the game's own zoom, and one alone lets the stick choose a target
-- (Blizzard_GamepadTargeting/TargetLogic.lua 74 to 84 and 132 to 216). While the game does one of
-- those the addon stays out, so the two never add up. Where LB or RB has a bind, LB goes to a
-- button of ours that tells when LB and RB are held (Core/BindHolds.lua), and the zoom is ours.
--
-- The right stick has one job at a time. In mouse mode it moves the pointer, and while a wheel is
-- open it chooses on the wheel: it does not zoom then, in either hold.
--
-- Nothing looks at the controller while no hold is on. The bind's button tells of its press and
-- its let-go. For LB + RB the owner frame of the binds tells (the message "hold"); from then on the
-- frame looks at the pad each frame for as long as LB or RB is down.
--
-- The camera stands still in one of two ways. The first takes no stick from the game: the game's
-- two turn speeds for the stick are held at 0 for the time of the zoom, so nothing can stop the
-- left stick from walking. On a game that does not take those two settings, two frames of ours
-- keep the camera's stick from the game and hand the walking stick on, as the wheels' frames do
-- (Screen/WheelModel.lua has the rule, and it is used as it is). The stick itself is read from
-- the pad in both ways.
--
-- The game's notes say nothing about the zoom calls in a fight: if the game refuses one, the stick
-- is the camera again there, and the log says so. The log (kind "zoom") has one line at login,
-- one for each time the stick zoomed (with what held the camera, and what the two frames took and
-- passed), and one for each reason the stick did not zoom.
local _, ns = ...

local Zoom = ns.Module("Zoom", { "padButtons", "cameraZoom" }, "Stick Zoom")
ns.Zoom = Zoom

local Model = ns.ZoomModel

local BUTTON = "GamepadSuiteStickZoom"
local COMMAND = "CLICK " .. BUTTON .. ":LeftButton"
local ART = "Interface\\Icons\\INV_Misc_Spyglass_02"
local NAME = { bind = "the bind Stick Zoom", both = "LB + RB" }
local MAX_NOTES = 12    -- lines for the log in one session

local frame, button, ear, wall
local how               -- the hold that is on: "bind" (the bind's button) or "both" (LB + RB); nil when none is
local wheel             -- the wheel that is open, if one is: the right stick is the wheel's then
local zooms = false     -- the stick zooms now, and the camera stands still for it
local armed = false     -- a hold of the bind: the pad has shown a button down (ZoomModel.LetGo)
local ready = false     -- the ear's switch is set: it hands every stick on to the game
local now = {}          -- what Model.Refusal asks, read again each frame of a hold
local started, before, fight, net, calls, most   -- this time with the stick: when it began, the camera's distance, in a fight, yards asked for (plus is in), calls, the stick's largest push
local holds, sticks     -- this time with the stick: what holds the camera, and what the two stick frames counted (WheelModel.Stick)
local gameSince, gameBefore   -- the game's own zoom has the stick: since when, and the camera's distance then
local denied = {}       -- [true]: the game refused the zoom call in a fight; [false]: out of a fight
local notes, told = 0, {}
local dead = false      -- a fault: stick zoom is off for the session

-- A line for the log. A line with a name (once) is written one time in a session; of the other
-- lines the log gets twelve.
local function note(text, once)
    if once and told[once] or not once and notes >= MAX_NOTES then
        return
    end
    if once then
        told[once] = true
    else
        notes = notes + 1
    end
    ns.Log.Add("zoom", text)
end

-- The bind list's entry (Core/Catalog.lua).
function Zoom.Bind()
    return { kind = "command", id = COMMAND, name = "Stick Zoom", detail = "Hold and push the right stick", icon = ART }
end

-- What held the camera in the time with the stick that ends, for the log.
local function heldBy()
    if holds ~= "the two stick frames" then
        return holds
    end
    return string.format("%s (camera's stick: the wall took it %d times, it passed %d times; walking stick: it passed %d times, the wall took it %d times)",
        holds, sticks.kept, sticks.leaked, sticks.walked, sticks.stolen)
end

-- The stick zooms (true), or is the camera again. While it zooms the camera stands still: the
-- game's two turn speeds are held at 0, and where the game does not take them the two stick
-- frames come up. A time with the stick goes in the log when it ends.
local function keep(on)
    if on == zooms then
        return
    end
    zooms = on
    local still = ns.Adapter.CameraStill(on)
    local frames = on and not still and ready and ns.WheelModel ~= nil
    ear:SetShown(frames)
    wall:Hide()
    if on then
        started, fight, before, net, calls, most = GetTime(), ns.Adapter.InCombat(), ns.Adapter.ZoomText(), 0, 0, 0
        sticks = { kept = 0, leaked = 0, walked = 0, stolen = 0 }
        holds = still and "the turn speeds at 0" or frames and "the two stick frames" or "nothing: the game did not take the turn speeds, and the two stick frames are not ready"
    elseif started and calls > 0 then
        note(string.format("%s held %.1f s, in a fight: %s; the pad gave the stick, largest push up or down %.2f; zoom calls: %d, yards asked: %+.1f (plus is in); camera %s -> %s; the camera was held by %s",
            NAME[how], GetTime() - started, tostring(fight or ns.Adapter.InCombat()), most, calls, net, before, ns.Adapter.ZoomText(), heldBy()))
    elseif started then
        note(string.format("%s held %.1f s and no zoom was asked: the pad gave the stick, largest push up or down %.2f (it zooms from %.2f)",
            NAME[how], GetTime() - started, most, Model.DEAD), "no push")
    end
end

-- The game told one of the two stick frames of a stick (onWall: the wall). The wall goes up or
-- comes down for the next stick: it is up only while the camera's stick is still to come.
local function stick(name, onWall, x, y)
    x, y = x or 0, y or 0
    wall:SetShown(ns.WheelModel.Stick(sticks, name, onWall, GetTime(), true, x * x + y * y))
end

-- The hold is over.
local function finish()
    keep(false)
    how = nil
    frame:Hide()
end

-- Why the stick does not zoom now, or nil when it does (ZoomModel.Refusal). For LB + RB the two
-- buttons are read before this.
local function refusal()
    now.mouse, now.wheel, now.gameplay, now.denied = ns.Pointer and ns.Pointer.IsOn(), wheel ~= nil, ns.Pad.Gameplay(), denied[ns.Adapter.InCombat()]
    if how == "both" then
        now.lt, now.rt = ns.Adapter.Held()
        now.enabled, now.game = ns.Registry.Get("feel.stick_zoom"), ns.Adapter.GameStick()
    end
    return Model.Refusal(how, now)
end

-- One look at the hold, each frame of it: it ends, it waits, or the stick zooms. True while it zooms.
local function look()
    if how == "bind" then
        local over
        over, armed = Model.LetGo(armed, ns.Adapter.PadState())
        if over then
            finish()
            return false
        end
    else
        now.lb, now.rb = ns.Adapter.Shoulders()
        if not (now.lb or now.rb) then
            finish()
            return false
        end
    end
    local stop = refusal()
    if stop and how == "both" and now.lb and now.rb then
        note("LB + RB are held and the stick does not zoom: " .. stop, stop)
    elseif stop and how == "bind" then
        note("the bind Stick Zoom is held and the stick does not zoom: " .. stop, "bind: " .. stop)
    end
    keep(not stop)
    return zooms
end

local function update(elapsed)
    if not look() then
        return
    end
    local _, y = ns.Adapter.RightStick()
    most = math.max(most, math.abs(y))
    local amount = Model.Amount(y, elapsed)
    if amount == 0 then
        return
    end
    local done, why = ns.Adapter.CameraZoom(amount)
    if done then
        net, calls = net + amount, calls + 1
        return
    end
    local inFight = ns.Adapter.InCombat()
    denied[inFight] = true
    note("the game refused the zoom call " .. (inFight and "in a fight" or "out of a fight") .. " (" .. tostring(why) .. "): the stick is the camera there")
    started = nil
    keep(false)
end

-- The button with the bind Stick Zoom went down or came up.
local function held(isDown)
    if dead then
        return
    end
    if isDown or how == "bind" then
        finish()
    end
    if isDown then
        how, armed = "bind", false
        frame:Show()
        keep(not refusal())
    end
end

-- The owner frame of the binds told of a change of LB (or of LB and RB): the watch for LB + RB
-- starts when both are held. RB held first does not start the owner frame's LB + RB, so the
-- controller itself is asked too.
local function shoulder()
    if how then
        return
    end
    local lb, rb = ns.Adapter.Shoulders()
    local chord = ns.BindHolds.Both()
    if Model.Watch(ns.Registry.Get("feel.stick_zoom"), chord or (lb and rb)) then
        how = "both"
        frame:Show()
        if not chord then
            note("LB + RB: RB was held first, and the controller says both are down: the stick zooms", "rb first")
        end
    end
end

-- The game's own zoom took the stick, or gave it back. One line for the log tells what the
-- camera did in that time.
local function game(live)
    if live and not gameSince then
        gameSince, gameBefore = GetTime(), ns.Adapter.ZoomText()
    elseif not live and gameSince then
        local after = ns.Adapter.ZoomText()
        note(string.format("LB + RB were held %.1f s as the game's own two targeting buttons: the game's own zoom had the stick; camera %s -> %s",
            GetTime() - gameSince, gameBefore, after), after == gameBefore and "the game's zoom, no move" or nil)
        gameSince = nil
    end
end

function Zoom.OnLogin()
    frame = CreateFrame("Frame")
    frame:Hide()
    -- A fault would come every frame: it is logged once, and stick zoom is off for the session,
    -- with the camera's turn speeds given back. (The bind's secure button is left as it is: the
    -- game does not let an addon change it in a fight, and the bind core watches its press.)
    local function fault()
        dead = true
        frame:SetScript("OnUpdate", nil)
        ns.Listen("hold", "Zoom", function() end)
        ns.Call("Zoom", finish)
    end
    -- The two stick frames, for a game that does not take the turn speeds (see keep). The wall is
    -- above the ear, so the game tells the wall first while it is up. The ear hands every stick
    -- on to the game, and for that its switch must be set, which the game refuses in a fight:
    -- until it is set the two frames are not used.
    ear, wall = CreateFrame("Frame", "GamepadSuiteZoomEar", UIParent), CreateFrame("Frame", "GamepadSuiteZoomWall", UIParent)
    ear:SetFrameStrata("BACKGROUND")
    wall:SetFrameStrata("TOOLTIP")
    for hears, onWall in pairs({ [ear] = false, [wall] = true }) do
        hears:Hide()
        hears:EnableGamePadStick(true)
        hears:SetScript("OnGamePadStick", function(_, name, x, y)
            if not ns.Call("Zoom", stick, name, onWall, x, y) then
                fault()
            end
        end)
    end
    ns.Queue.Run("ZoomEar", function()
        ear:SetPropagateKeyboardInput(true)
        ready = true
    end)
    frame:SetScript("OnUpdate", function(_, elapsed)
        if not ns.Call("Zoom", update, elapsed) then
            fault()
        end
    end)
    -- The button that the bind clicks: it hears the press and the let-go. A secure button (made out
    -- of a fight), so the bind core can hear its press too (Sticky Layers, Core/BindCore.lua).
    ns.Queue.Run("StickZoom", function()
        button = CreateFrame("Button", BUTTON, UIParent, "SecureActionButtonTemplate")
        button:RegisterForClicks("AnyDown", "AnyUp")
        button:SetScript("OnClick", function(_, _, isDown)
            if not ns.Call("Zoom", held, isDown and true or false) then
                fault()
            end
        end)
    end)
    ns.Listen("hold", "Zoom", shoulder)
    -- a wheel opened or closed: the next frame of a hold gives the stick to the wheel, or takes it back
    ns.Listen("wheel", "Zoom", function(id)
        wheel = id or nil
    end)
    ns.Adapter.OnGameZoom(function(live)
        ns.Call("Zoom", game, live)
    end)
    -- the game tells of a fight before it locks anything: the turn speeds are given back, and
    -- the next frame of a hold asks for them again
    ns.On("PLAYER_REGEN_DISABLED", "Zoom", function()
        keep(false)
    end)
    ns.On("PLAYER_LOGOUT", "Zoom", finish)
    -- for the log: why LB + RB does or does not zoom on this character, and where the bind is
    local on = {}
    ns.Binds.Each(function(bind, _, _, key)
        if bind.kind == "command" and bind.id == COMMAND then
            on[#on + 1] = key
        end
    end)
    table.sort(on)
    note("at login: the setting Stick Zoom is " .. (ns.Registry.Get("feel.stick_zoom") and "on" or "off")
        .. "; the bind Stick Zoom is on " .. (#on > 0 and table.concat(on, ", ") or "no button"))
end
