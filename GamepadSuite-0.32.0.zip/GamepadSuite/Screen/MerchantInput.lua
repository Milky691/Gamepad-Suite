-- The buttons of the merchant view (Screen/Merchant.lua): the frame that hears the controller
-- while a vendor shows, the hold of A, the keyboard's Escape (close) and Space (as A), and the
-- clicks on the cards and on the button hints (Screen/MerchantCards.lua, MerchantDraw.lua).
-- The frame keeps every button of the controller: at each press it sets the game's switch to
-- "not for the game" (SetPropagateKeyboardInput false, out of combat), and it shows only while
-- the view has the controller. It takes no stick, so the camera turns and the character can walk
-- away (the vendor then closes). Inside a press only the view's own state, its own drawing and
-- its line change; a step of the game is handed to the module, which makes it one frame later.
-- A hold of A on a thing that stacks: the let-go before Model.HOLD buys one lot, a full hold buys
-- a stack at once. The let-go buys, not the press: only the let-go tells a tap from a hold, and a
-- tap must still buy one. A hold of Y on a card of the Sell tab that can be marked is the same:
-- the let-go before Model.MARK (one second) is a tap of Y, which repairs, and a full hold marks
-- the card as junk or takes the mark off (Mark Junk). The script runs on each frame only during
-- a hold, and stops itself.
local _, ns = ...

local Model, Draw = ns.MerchantModel, ns.MerchantDraw

local Input = {}
ns.MerchantInput = Input

local view                  -- the module's side: shop(), note, guarded, step, draw, say, coins
local input, ear
local aDown, openedAt = false, 0
local hold                  -- the hold that runs now: { time, key (the card's), button ("A" or "Y") }; nil for none

local function stop(s)
    if hold then
        hold = nil
        input:SetScript("OnUpdate", nil)
        if s then
            Draw.Hold(0, s)
        end
    end
end

local tick

-- A card's key: its place in the vendor's list, or for a thing in the bags its bag, slot and item.
local function key(entry)
    return entry and (entry.index or entry.bag .. ":" .. entry.slot .. ":" .. entry.id)
end

-- The end of a hold: a full one, or a let-go before it was full.
local function ending(s, full)
    if hold.button == "Y" then
        return Model.Mark(s, full)
    end
    return Model.Hold(s, full)
end

-- What a press, a let-go, a hold or a click changed (Model.Press) shows, and a step of the game
-- is handed on. button: what it was, for the log.
local function act(s, button, what, a, b, c)
    if what == "do" then
        view.note(button .. ": " .. a .. (b and " " .. (type(b) == "table" and tostring(b.name) or tostring(b)) or "") .. (c and " x" .. c or ""))
        view.say(nil)
        view.step(a, b, c)
    elseif what == "hold" then
        hold = { time = 0, key = key(Model.Focus(s)), button = button }
        view.say(nil)
        input:SetScript("OnUpdate", tick)
    elseif what == "say" or what == "ask" then
        view.note(button .. ": the line says '" .. tostring(a) .. "'", what .. tostring(a))
        view.say(a, what)
    elseif what then
        view.note(button .. ": " .. what .. ", " .. s.tab .. " card " .. s.at[s.tab], what .. button)
        view.say(nil)
        view.draw()
    else
        view.note(button .. ": nothing", "nothing" .. button)
    end
end

-- Each frame during a hold: the line on the card grows; when it is full a stack is bought, or the
-- card is marked. A list that changed under the hold (another card in focus) ends it with nothing done.
function tick(_, elapsed)
    view.guarded(function()
        local s = view.shop()
        if not (hold and s and key(Model.Focus(s)) == hold.key) then
            return stop(s)
        end
        local long = hold.button == "Y" and Model.MARK or Model.HOLD
        hold.time = hold.time + elapsed
        if hold.time < long then
            Draw.Hold(hold.time / long, s)
            return
        end
        local button, what, a, b, c = hold.button, ending(s, true)
        stop(s)
        act(s, "a full hold of " .. button, what, a, b, c)
    end)
end

-- A button went down, by our name for it.
local function press(button)
    local s = view.shop()
    if not (button and s) then
        return
    elseif ns.PointerPair and ns.PointerPair.Heard(button) then
        -- mouse mode's press (View + Menu, or the bind Mouse Mode): Screen/PointerPair.lua
        return
    elseif button == "A" then
        -- a held A is one press, and an A in the first half second of the view is none (the press
        -- that opened the vendor)
        if aDown or GetTime() - openedAt < Model.FRESH then
            return
        end
        aDown = true
    end
    -- another button during a hold ends it, and nothing is bought
    stop(s)
    act(s, button, Model.Press(s, button, view.coins))
end

local function release(button)
    if button == "A" then
        aDown = false
    end
    local s = view.shop()
    if hold and s and hold.button == button then
        local same = key(Model.Focus(s)) == hold.key
        local what, a, b, c = ending(s, false)
        stop(s)
        if same then
            act(s, button .. " let go before the hold was full", what, a, b, c)
        end
    end
end

-- A key or a click that does what a button does: Space (A), Escape (B), a click on a button hint.
function Input.Key(button)
    view.guarded(press, button)
    view.guarded(release, button)
end

-- A left click on card n of the page (Model.Click), by the mouse or by mouse mode's LT. The view
-- keeps no button in mouse mode, so this is how a card is bought there. Like A, a click in the
-- first half second of the view does nothing.
function Input.Click(n)
    view.guarded(function()
        local s = view.shop()
        if s and GetTime() - openedAt >= Model.FRESH then
            stop(s)
            act(s, "click on card " .. n, Model.Click(s, n, view.coins))
        end
    end)
end

-- The mouse wheel over the cards (up: delta 1) turns the page (Model.Turn), so a card of another
-- page can be clicked in mouse mode.
function Input.Wheel(delta)
    view.guarded(function()
        local s = view.shop()
        if s then
            stop(s)
            act(s, "mouse wheel", Model.Turn(s, delta > 0 and -1 or 1))
        end
    end)
end

-- A left click on a page control (way "back" or "next") turns the page, as A on it does.
function Input.Page(way)
    view.guarded(function()
        local s = view.shop()
        if s then
            stop(s)
            act(s, "click on the page control " .. way, Model.PageClick(s, way))
        end
    end)
end

-- The view went: no button is down and no hold runs for the next vendor, and every key of the
-- keyboard goes on to the game again. Not at the start of combat: the game refuses the switch.
function Input.Rest()
    aDown = false
    stop(nil)
    if ear and not (ns.fightStarted or ns.Adapter.InCombat()) then
        ear:SetPropagateKeyboardInput(true)
    end
end

-- A new vendor shows. A press of A in its first half second does nothing. Every key but Escape and
-- Space goes on to the game from the first key on.
function Input.Fresh()
    openedAt = GetTime()
    if ear and not ns.Adapter.InCombat() then
        ear:SetPropagateKeyboardInput(true)
    end
end

-- The game's switch for a press of the frame: kept ("not for the game"). The game takes the
-- switch out of combat only; the view is gone in combat.
local function keep(self)
    if not ns.Adapter.InCombat() then
        self:SetPropagateKeyboardInput(false)
    end
    return false
end

-- Makes the frames under root, hidden, and gives the one that hears the controller: it is shown
-- while the view has the controller. Made out of combat: the game refuses a frame's switch for the
-- controller in combat. module: the module's side (see above).
function Input.Build(root, module)
    view = module
    input = CreateFrame("Frame", nil, root)
    input:SetSize(1, 1)
    input:SetPoint("BOTTOMLEFT")
    input:Hide()
    input:EnableGamePadButton(true)
    input:SetPropagateKeyboardInput(false)
    input:SetScript("OnGamePadButtonDown", function(self, name)
        view.guarded(press, ns.Adapter.NAME[name])
        return keep(self)
    end)
    input:SetScript("OnGamePadButtonUp", function(self, name)
        view.guarded(release, ns.Adapter.NAME[name])
        return keep(self)
    end)
    -- The frame hears no let-go while it is hidden: when it shows, A is down or not as the
    -- controller says, so the A that opened the vendor and is let go here buys nothing.
    input:SetScript("OnShow", function()
        aDown = ns.Adapter.ButtonDown("A")
    end)
    input:SetScript("OnHide", function()
        stop(view.shop())
    end)
    -- Escape closes, as B does, and Space does what A does. The ear hands every other key on to
    -- the game, and it hears the keys only when the game took the switch for that.
    local keys = CreateFrame("Frame", nil, input)
    keys:SetSize(1, 1)
    keys:SetPoint("BOTTOMLEFT")
    if ns.Adapter.HandSticksOn(keys) then
        ear = keys
        ear:EnableKeyboard(true)
        ear:SetScript("OnKeyDown", function(self, key)
            if not ns.Adapter.InCombat() then
                local button = key == "ESCAPE" and "B" or key == "SPACE" and "A" or nil
                self:SetPropagateKeyboardInput(button == nil)
                if button then
                    Input.Key(button)
                end
            end
        end)
    end
    view.note("Escape closes the view and Space does what A does: " .. tostring(ear ~= nil), "ear")
    return input
end
