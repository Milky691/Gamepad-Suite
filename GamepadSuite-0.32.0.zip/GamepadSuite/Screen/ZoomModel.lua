-- The rules of camera zoom with the right stick, with no game calls: when the watch for LB + RB
-- starts, why the stick does not zoom now, when a hold of the bind is over, and how far the
-- camera zooms in one frame.
local _, ns = ...

local Model = {}

Model.DEAD = 0.2     -- a stick pushed up or down less than this does not zoom
Model.SPEED = 12     -- yards of zoom in a second, with the stick pushed all the way
Model.LONGEST = 0.1  -- the longest frame that counts: after a hitch the camera does not jump

-- The sticks that zoom, by the names the game gives them. The left stick walks.
Model.STICK = { Right = true, Camera = true, Look = true }

-- Does the watch for LB + RB start now? It starts when the setting is on and the owner frame of
-- the binds says that LB and RB are held (Core/BindHolds.lua).
function Model.Watch(enabled, both)
    return (enabled and both) and true or false
end

-- Why the right stick does not zoom now, in words for the log, or nil when it zooms. how is
-- "bind" while the button with the bind Stick Zoom is held, "both" for LB + RB. now has: mouse
-- (mouse mode is on: the stick moves the pointer), wheel (a wheel is open: the stick chooses on
-- it), gameplay (no window has the controller), denied (the game refused the zoom call here),
-- and for LB + RB: enabled (the setting), lb and rb (down now), lt and rt (a trigger is another
-- layer), game (what the game does with the stick by itself for its own LB or RB, "zoom" or
-- "targeting": one use of the stick is enough).
function Model.Refusal(how, now)
    if now.mouse then
        return "mouse mode is on"
    elseif now.wheel then
        return "a wheel is open"
    elseif not now.gameplay then
        return "a window has the controller"
    elseif now.denied then
        return "the game refused the zoom call"
    elseif how == "bind" then
        return nil
    elseif not now.enabled then
        return "the setting Stick Zoom is off"
    elseif not (now.lb and now.rb) then
        return "LB and RB are not both held"
    elseif now.lt or now.rt then
        return "a trigger is held"
    elseif now.game then
        return "the game's own " .. now.game .. " has the stick"
    end
    return nil
end

-- The watch for a let-go of the bind's button that the game did not tell of (the key went to a
-- window, or to another set of binds, while it was held). buttons is the pad's own table: place
-- -> true for a button that is down. armed is true once the pad has shown a button down in this
-- hold. Returns two things: is the hold over, and armed for the next look. The hold is over when
-- the pad showed a button down and now shows none. A pad that cannot be read, or that never
-- shows the button, ends nothing: the click of the let-go does.
function Model.LetGo(armed, buttons)
    for _, on in pairs(buttons) do
        if on then
            return false, true
        end
    end
    return armed, armed
end

-- The yards to zoom in this frame for a stick at y (-1 to 1, up is more). Up gives a number above
-- 0 (zoom in), down one below 0 (zoom out), and a push inside the dead zone gives 0. The speed grows
-- with the push, from nothing at the dead zone to SPEED at the end of the stick.
function Model.Amount(y, elapsed)
    local push = math.abs(y)
    if push <= Model.DEAD then
        return 0
    end
    local part = math.min(1, (push - Model.DEAD) / (1 - Model.DEAD))
    local yards = part * Model.SPEED * math.min(elapsed, Model.LONGEST)
    return y > 0 and yards or -yards
end

if ns then
    ns.ZoomModel = Model
end
return Model
