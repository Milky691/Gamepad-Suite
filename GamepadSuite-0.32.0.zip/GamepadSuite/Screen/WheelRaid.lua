-- The raid's healer wheel on screen (the owner: "I want one wheel to contain 10 players but like a 5 on top of the
-- radial and 5 on the bottom of the radial. So like 2 groups per radial. 4 radials (40 player raids) I'd also like the
-- wheels to be stacks so 2 on top of 2 in the ui."). In a raid a party wheel is one radial for each pair of groups that
-- has members (Core/Wheels.lua, "heal774:2"; Screen/WheelRaidModel.lua has the rules). Its bind opens the player's own
-- pair ("heal774"), and LB, RB and the D-pad open another one in the game's restricted code (Core/BindPlan.lua CYCLE),
-- in a fight too. Screen/Wheel.lua draws all of it as one ring of many plates, each at its own radial's size: this file
-- gives it every radial's places and where each radial stands, and draws what is the raid's own: a dark disc behind
-- each radial (Background Dark), a thin split line across its middle with "Group N" over it and "Group M" under it, the
-- gold ring round the chosen radial, the dimmed look of the others (each plate's dim: the reach's look of
-- Core/AdapterPlate.lua comes on top), and the game's LB and RB pictures (Widgets.Glyph) at the radials those bumpers go
-- to. An empty place shows nothing. The stick points only at the chosen radial (WheelRules.PickOf leaves out an entry
-- with off, and points at nothing on a blank). Every mark of a party plate stays (Screen/WheelPlate.lua). The roster is
-- the one of the wheels: in a fight it stays as it was when the fight began, and a plate shows who its unit is now.
-- Nothing here runs on a timer: it is drawn when the ring is.
local _, ns = ...

local Raid = {}
ns.WheelRaid = Raid

local Theme, Model = ns.Theme, ns.WheelRaidModel
local px = Theme.px
local RING = "Interface\\AddOns\\GamepadSuite\\Art\\HudRing.tga"   -- our thin circle line (Screen/HudFace.lua), here in gold
local RING_GROW = 64 / 62   -- the line is 62 of the 64 units from the middle of that picture to its edge
local SPLIT = 0.6           -- how strong the split line is
local looks, glyphs = {}, {}   -- what is drawn for each radial: { disc, rings, split, labels }; the LB and RB pictures

-- The entries of a raid's party wheel and where they stand, or nil for any other wheel (and for one in a party). open
-- is the wheel that is open ("heal774", or a pair's "heal774:2"), percent the setting Wheel Size. Gives the fit of
-- WheelRaidModel.Fit with entries (every place of every radial: dx, dy is the middle of its radial, size and radius its
-- radial's, off is set on a radial not chosen) and radials ({ pair, entries, groups = { [group] = has members }, spot }).
function Raid.Entries(open, percent)
    local kind, _, pair = ns.WheelRules.HealOf(open)
    if not kind then
        return nil
    end
    local base, radials, chosen = tostring(open):match("^heal%a*%d+"), {}, 1
    for p = 1, Model.PAIRS do
        local entries = ns.Wheels.Entries(base .. ":" .. p)
        if #entries > 0 then
            local one = { pair = p, entries = entries, groups = {} }
            for _, entry in ipairs(entries) do
                one.groups[entry.group or 0] = one.groups[entry.group or 0] or not entry.blank
                -- (the bind's own wheel is the player's own pair: the radial with the player in it)
                pair = pair or entry.unit == "player" and p or nil
            end
            radials[#radials + 1] = one
            chosen = one.pair == pair and #radials or chosen
        end
    end
    if #radials == 0 then
        return nil
    end
    local wide, high = ns.Adapter.ScreenUnits()
    local fit = Model.Fit(#radials, chosen, percent, wide, high)
    fit.entries, fit.radials, fit.chosen = {}, radials, chosen
    for k, one in ipairs(radials) do
        local spot = fit.spots[k]
        one.spot = spot
        for _, entry in ipairs(one.entries) do
            entry.dx, entry.dy, entry.size, entry.radius, entry.off = spot.x, spot.y, spot.size, spot.radius, spot.off
            fit.entries[#fit.entries + 1] = entry
        end
    end
    return fit
end

-- What is drawn for one radial, on the ring: a dark disc (the Healer Wheel's own), the gold ring (two of the thin
-- lines side by side, so it reads as a ring at a glance), the split line and the two labels.
local function make(ring)
    local look = { disc = ns.WheelPlate.Piece(ring, "BACKGROUND", 1), rings = {}, split = ring:CreateTexture(nil, "BORDER"), labels = {} }
    look.disc:SetColorTexture(0, 0, 0, 0.62)
    ns.WheelPlate.Round(look.disc, true)
    look.split:SetColorTexture(Theme.Color("cream"))
    for i = 1, 2 do
        look.rings[i] = ring:CreateTexture(nil, "BORDER")
        look.rings[i]:SetTexture(RING)
        look.rings[i]:SetVertexColor(Theme.Color("gold"))
        look.labels[i] = Theme.Text(ring, "small", "gold")
    end
    return look
end

-- Draws one radial's parts (one: of Raid.Entries' radials, or nil: none), its measures from a cell of its size.
local function lay(ring, look, one, plain)
    look.disc:SetShown(one and not plain or false)
    look.split:SetShown(one ~= nil)
    for i = 1, 2 do
        look.rings[i]:SetShown(one and not one.spot.off or false)
        look.labels[i]:SetShown(one and one.groups[2 * one.pair - 2 + i] or false)
    end
    if not one then
        return
    end
    local spot, dim = one.spot, one.spot.off and Model.DIM or 1
    local cell = Model.Cell(spot.size / ns.WheelRules.PICTURE / ns.WheelRules.GAME * 100)
    local across = 2 * cell.radius + cell.size + 12 * cell.line
    look.disc:SetSize(px(across), px(across))
    look.disc:SetPoint("CENTER", ring, "CENTER", px(spot.x), px(spot.y))
    look.disc:SetAlpha(dim)
    look.split:SetSize(px(2 * cell.split), px(math.max(cell.line, 1)))
    look.split:SetPoint("CENTER", ring, "CENTER", px(spot.x), px(spot.y))
    look.split:SetAlpha(SPLIT * dim)
    for i = 1, 2 do
        local across = 2 * (cell.ring - 1.5 * (i - 1) * cell.line) * RING_GROW
        look.rings[i]:SetSize(px(across), px(across))
        look.rings[i]:SetPoint("CENTER", ring, "CENTER", px(spot.x), px(spot.y))
        local label = look.labels[i]
        label:SetFont(Theme.font.text, px(Theme.size.small * cell.line / ns.WheelRules.GAME), "")
        label:SetPoint("CENTER", ring, "CENTER", px(spot.x), px(spot.y + (i == 1 and 1 or -1) * cell.label))
        label:SetText(Model.Title(2 * one.pair - 2 + i, GROUP_NUMBER))
        label:SetTextColor(Theme.Color(spot.off and "cream" or "gold"))
        label:SetAlpha(dim)
    end
end

-- Draws the raid's own parts on the ring, and gives each plate (cells, for the entries) its dim. raid is what
-- Raid.Entries gave, or nil for any other wheel: then nothing of a raid is left on the ring. plain: Background None.
-- LB's picture stands in the middle of the radial before the chosen one, RB's in the middle of the one after (round
-- from the last to the first), between its two labels: a picture at a corner would stand as near to the next radial.
-- With two radials both go to the other one, side by side; with one radial there is none.
function Raid.Lay(ring, cells, entries, raid, plain)
    for i, entry in ipairs(entries) do
        local dim = raid and entry.off and Model.DIM or nil
        cells[i].dim = dim
        cells[i]:SetAlpha(dim or 1)
        cells[i]:SetShown(not entry.blank)
    end
    local count = raid and #raid.radials or 0
    for k = 1, math.max(#looks, count) do
        local one = raid and raid.radials[k]
        looks[k] = looks[k] or one and make(ring)
        lay(ring, looks[k], one, plain)
    end
    for side, key in ipairs({ "LB", "RB" }) do
        local k = count > 1 and (raid.chosen + 2 * side - 4) % count + 1
        glyphs[key] = glyphs[key] or k and ns.Widgets.Glyph(ring, key, px(Theme.size.glyph))
        if glyphs[key] then
            glyphs[key]:SetShown(k and true or false)
        end
        if k then
            local spot, size = raid.radials[k].spot, Theme.size.glyph * raid.line / ns.WheelRules.GAME
            glyphs[key]:SetSize(px(size), px(size))
            glyphs[key]:SetPoint("CENTER", ring, "CENTER", px(spot.x + (count == 2 and (side * 2 - 3) * 0.6 * size or 0)), px(spot.y))
        end
    end
end

-- The first moves from radial to radial go in the log, with what moved it (the restricted code says: "LB", "RB",
-- "D-pad up" and so on) and if a fight was on: one try in the game shows that LB, RB and the D-pad work, in a fight too.
local moves = 0
ns.Listen("wheel", "WheelRaid", function(id, why)
    local pair = tonumber(tostring(id):match("^heal%a*%d+:(%d)$") or "")
    if pair and moves < 8 and tostring(why):find("^[LRD]") then
        moves = moves + 1
        ns.Log.Add("wheel", ("the raid's healer wheel went to groups %d and %d by %s, in a fight: %s"):format(2 * pair - 1, 2 * pair, tostring(why), tostring(ns.Adapter.InCombat())))
    end
end)
