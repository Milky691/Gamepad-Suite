-- The word guesses of the chat keyboard, with no game calls: the word being typed, the guesses for it, a
-- guess put into the line, and the words learned from the lines the player sent. The learned words are a
-- table word -> count that the module keeps in the saved file (Screen/KeyboardChat.lua). The names of the
-- group, the friends and the guild are guessed too; they are never saved (Words.names).
local _, ns = ...

local Words = {}

-- The most words learned; a new word past it takes the place of the least used one.
Words.MOST = 400
local SHORT, LONG = 3, 20   -- a learned word has this many letters, or more, and at most that many

-- Common chat and game words, most useful first. Our own list, in lower case.
Words.LIST = {
    "the", "you", "and", "for", "are", "can", "any", "anyone", "need", "thanks", "thank", "please", "sorry", "sure",
    "yes", "yeah", "okay", "hello", "have", "what", "where", "when", "who", "why", "how", "with", "that", "this",
    "there", "they", "them", "then", "than", "just", "want", "will", "would", "could", "should", "know", "like",
    "going", "good", "great", "nice", "here", "wait", "back", "come", "coming", "help", "follow", "ready", "pull",
    "pulling", "group", "groups", "party", "raid", "guild", "dungeon", "instance", "quest", "quests", "tank",
    "healer", "heals", "heal", "damage", "looking", "more", "invite", "join", "leave", "mana", "drink", "drinking",
    "rest", "buff", "buffs", "loot", "greed", "pass", "roll", "item", "items", "gold", "silver", "sell", "selling",
    "buy", "buying", "trade", "price", "bags", "bank", "mail", "auction", "vendor", "repair", "level", "spell",
    "spells", "talent", "talents", "gear", "weapon", "armor", "boss", "mobs", "kill", "dead", "died", "wipe",
    "corpse", "rez", "summon", "portal", "mount", "flight", "zone", "city", "town", "road", "north", "south",
    "east", "west", "near", "careful", "patrol", "behind", "ahead", "left", "right", "first", "next", "last",
    "again", "still", "almost", "done", "start", "minute", "minutes", "second", "later", "tonight", "today",
    "tomorrow", "maybe", "really", "very", "much", "many", "some", "every", "everyone", "someone", "something",
    "nothing", "think", "thought", "said", "tell", "told", "ask", "talk", "find", "found", "lost", "look", "see",
    "give", "take", "make", "made", "use", "try", "work", "play", "time", "long", "fast", "slow", "busy", "afk",
    "brb", "bye", "welcome", "congrats", "grats", "friend", "friends", "people", "player", "players", "warrior",
    "mage", "priest", "rogue", "hunter", "warlock", "paladin", "shaman", "druid", "horde", "alliance",
    "stormwind", "ironforge", "darnassus", "orgrimmar", "undercity", "barrens", "westfall", "deadmines",
    "stockade", "wailing", "scarlet", "monastery", "ragefire", "shadowfang", "blackfathom", "gnomeregan",
    "uldaman", "maraudon", "stratholme", "scholomance", "molten", "onyxia", "about", "after", "before",
    "because", "from", "your", "were", "been", "does", "doing", "don't", "can't", "won't", "i'm", "it's",
    "that's", "you're", "i'll", "let's", "didn't", "isn't", "lfg", "lfm", "dps", "inv", "omw", "oom", "wts", "wtb",
}

-- A letter of a word: an English letter, a byte of a letter that is not English, or an apostrophe.
local LETTERS = "[%a\128-\255']+"

-- The word being typed: the letters at the end of the line, or "" (a space, a mark or a number at the end,
-- or the end of a link or a color, "|r").
function Words.Started(text)
    local at = text:match("()" .. LETTERS .. "$")
    if not at or text:sub(at - 1, at - 1) == "|" then
        return ""
    end
    return text:sub(at)
end

-- The names that the guesses offer besides words: the people of the group, the friends and the guild who
-- are in the game (Screen/KeyboardNames.lua sets them while a chat keyboard is open, and clears them at its
-- close). Texts only, as the game gives them: with their capitals, and with the realm ("Bob-Realm") when it
-- is not the player's own.
Words.names = {}

function Words.SetNames(list)
    Words.names = {}
    for _, name in ipairs(list or {}) do
        if type(name) == "string" and name ~= "" then
            Words.names[#Words.names + 1] = name
        end
    end
end

-- Up to `most` (3) guesses for the word being typed, from the learned words that start with it (the most
-- used first), the built-in words, and the names (`names`, or the ones Words.names holds). Each once. The
-- word as typed is no guess, nor is the name as typed (with the same capitals). A started capital stays one
-- on a word; a name has its own capitals. The three places are shared like this:
--   The words keep their order and the first place. The names take the places that are free, and a name
--   keeps the last place when the words would fill all three. (RB puts the first guess in: a name that only
--   shares two letters must not take the place of a common word.)
--   After a capital letter in the middle of a line the player means a name: the names come first. A capital
--   at the start of a line is a sentence start, and the words come first.
--   A word that is the name in small letters ("mage" for a player named Mage) is left out.
function Words.Guess(text, learned, most, names)
    most = most or 3
    local started = Words.Started(text)
    local low = started:lower()
    if low == "" then
        return {}
    end
    local capital = started:find("^%u") ~= nil
    local taken, named, hits, isName = { [low] = true }, {}, {}, {}
    -- ponytail: lower() of each name at each key. A few hundred names cost nothing; keep the small-letter names
    -- in SetNames if the lists ever reach thousands.
    for _, name in ipairs(names or Words.names) do
        local key = name:lower()
        if name ~= started and key:sub(1, #low) == low and not named[key] then
            named[key], taken[key], isName[name] = true, true, true
            hits[#hits + 1] = name
        end
    end
    local mine = {}
    for word, count in pairs(learned or {}) do
        if word:sub(1, #low) == low and not taken[word] then
            mine[#mine + 1] = { word, count }
        end
    end
    table.sort(mine, function(a, b) return a[2] > b[2] or a[2] == b[2] and a[1] < b[1] end)
    local words = {}
    local function take(word)
        if #words < most and not taken[word] and word:sub(1, #low) == low then
            taken[word] = true
            words[#words + 1] = capital and word:sub(1, 1):upper() .. word:sub(2) or word
        end
    end
    for _, pair in ipairs(mine) do
        take(pair[1])
    end
    for _, word in ipairs(Words.LIST) do
        take(word)
    end
    local first, second = words, hits
    if capital and #text > #started then
        first, second = hits, words
    end
    local out, hasName = {}, false
    for _, group in ipairs({ first, second }) do
        for _, guess in ipairs(group) do
            if #out < most then
                out[#out + 1] = guess
                hasName = hasName or isName[guess] == true
            end
        end
    end
    if hits[1] and not hasName then
        out[#out] = hits[1]
    end
    return out
end

-- The line with the started word replaced by `word` and a space, or nil when no word is started or the
-- line would then be longer than `limit` letters (bytes count here: a guess is English letters).
function Words.Use(text, word, limit)
    local started = Words.Started(text)
    if started == "" then
        return nil
    end
    local new = text:sub(1, #text - #started) .. word .. " "
    if limit and #new:gsub("[\128-\191]", "") > limit then
        return nil
    end
    return new
end

-- Counts each word of a sent line in `learned` (a table word -> count) and gives it back. Not a line that
-- starts with a command, not links or colors, numbers, or words shorter than three letters or longer than
-- twenty, and not a name (`names`, or the ones Words.names holds; each part of one, so "Bob-Realm" teaches
-- neither Bob nor Realm). Past Words.MOST words, the least used ones that are not in this line go.
function Words.Learn(learned, line, names)
    if line:find("^%s*/") then
        return learned
    end
    local skip = {}
    for _, name in ipairs(names or Words.names) do
        for part in name:gmatch(LETTERS) do
            skip[part:lower()] = true
        end
    end
    line = line:gsub("|H.-|h.-|h", " "):gsub("|c%x%x%x%x%x%x%x%x", " "):gsub("|r", " ")
    local here, count = {}, 0
    for word in line:gmatch(LETTERS) do
        word = word:lower()
        if #word >= SHORT and #word <= LONG and not skip[word] then
            learned[word] = (learned[word] or 0) + 1
            here[word] = true
        end
    end
    for _ in pairs(learned) do
        count = count + 1
    end
    while count > Words.MOST do
        local least
        for word, n in pairs(learned) do
            if not here[word] and (not least or n < learned[least]) then
                least = word
            end
        end
        learned[least] = nil
        count = count - 1
    end
    return learned
end

if ns then
    ns.KeyboardWords = Words
end
return Words
