-- Dialogue View: the suite's own view of a talk with an NPC and of a quest, in place of the
-- game's gossip window and quest window. A dark band at the foot of the screen has the NPC's
-- portrait, its words in large type, and at the right the choices, the rewards or the items a
-- quest needs. A acts at once (takes, accepts, goes on, completes), B leaves, X turns the text,
-- Y and the D-pad move the focus, LB goes back a part; a left click on a row, a reward or a hint
-- does the same (mouse mode too). The text moves on until the player turns it. Its other files: DialogueModel.lua and DialogueKeys.lua (the rules),
-- DialogueDraw.lua, DialogueSide.lua and DialogueFoot.lua (the frames), DialogueInput.lua (the
-- buttons), DialogueStage.lua (the game's interface out of sight), DialogueTake.lua (who has the
-- talks), DialogueWatch.lua (what the game says), Core/AdapterDialogue*.lua.
--
-- How it stays out of the game's way:
--   The view has the talks only with the row on, out of combat, while a controller is in use,
--   and when no other addon (Immersion) has the game's windows (DialogueTake.lua).
--   Combat, a movie, a loading screen, another window of the game (a vendor, the trainer's box to
--   unlearn talents) and a controller that goes away end a talk at once: every button is free.
--   While a window or a question of the game has the controller, the view steps aside.
--   Nothing is shown, hidden or asked of the game inside a press or inside the game's own
--   code: it is noted, and done one frame later, from a timer.
--   A fault ends the talk, gives the events back and turns the view off until the next login.
--   No work is done while no talk is on, and a script runs on each frame only for a fade or
--   while the time of a part runs.
-- The log (kind "dialogue") says which events came, if the game's window stayed away, what the
-- portrait shows, and what each press did.
local _, ns = ...

local Dialogue = ns.Module("Dialogue", { "dialogue" }, "Dialogue View")
ns.Dialogue = Dialogue

local Model, Draw, Side, Foot = ns.DialogueModel, ns.DialogueDraw, ns.DialogueSide, ns.DialogueFoot
local Input, Stage, Watch, Take = ns.DialogueInput, ns.DialogueStage, ns.DialogueWatch, ns.DialogueTake

-- the two windows of a talk that are a list of rows -> the adapter's call that reads each
local LIST = { gossip = "DialogueGossip", greeting = "DialogueGreeting" }

local root, input          -- the view's frame, and its child that hears the controller
local built = false        -- the parts of the view are made at the first talk
local talk                 -- the talk in view (Model.Open), with source and speaker; nil with no talk
local wait                 -- a talk that the game has opened and the view has not drawn yet
local turn = 0             -- goes up at each event of a talk: a timer that waits for the next one compares it
local closing = false      -- the talk ended: the band waits a moment for the next window of the same NPC
local chosenAt = 0         -- when a choice of a gossip was last taken
local notes, told = 0, {}  -- the lines written to the log, and the names of those written once

-- A line for the saved file, eighty at most. A line with a name (once) is written one time only.
local function note(text, once)
    if notes < 80 and not (once and told[once]) then
        notes, told[once or 0] = notes + 1, true
        ns.Log.Add("dialogue", text)
    end
end

function Dialogue.IsOpen()
    return talk ~= nil
end

-- True for a window of a gossip, false for one of a quest (a quest list is a quest's).
local function gossip(window)
    return window.kind == "gossip" and window.source ~= "greeting"
end

local function sync()
    Take.Sync(talk or wait or not root)
end

-- The controller is the view's while a talk shows. It is not while a window or a question of
-- the game has it, or while the settings window is open. Where the game's windows are made for
-- the mouse, no question of the game takes the controller by itself: there the view gives it
-- away while a question shows, so the player's own way to click has its buttons. With the
-- controller the view has the screen (Screen/DialogueStage.lua); between two windows of one
-- talk the interface stays as it is. soft: the view closed. Never called inside a press.
local function follow(soft)
    local mine = talk ~= nil and not closing and ns.Adapter.GameplayHasPad() ~= false and not (ns.Settings and ns.Settings.IsOpen())
        and (ns.Adapter.PadWindowStyle() or not ns.Adapter.PopupShown())
    input:SetShown(mine and not (ns.Pointer and ns.Pointer.IsOn()))   -- mouse mode has LT, RT and B
    if mine or not closing then
        Stage.Want(mine, soft)
    end
end

local draw, guarded

-- The time of a part ran out: the next part shows, as X shows it.
local function onward()
    if talk and not closing and talk.part < talk.count then
        talk.part = talk.part + 1
        note("the text moved on by itself to part " .. talk.part .. " of " .. talk.count, "auto")
        draw("part")
    end
end

-- Draws the part of the talk in view. how: "state" for a new window of the talk, "part" for
-- another part of the text, nil for the same part again. A part before the last one moves on
-- by itself (the row Text Moves On By Itself) until the player turns the text in this talk.
function draw(how)
    local view = Model.View(talk)
    local cut = Draw.Part(talk, view, how)
    if cut then
        note(cut, cut)
    end
    local tip = Side.Show(talk, view)
    if tip then
        note(tip, "tip")
    end
    Foot.Hints(Model.Hints(talk))
    if how or not Foot.Timing() then
        local ok, auto = pcall(ns.Registry.Get, "windows.dialogue_auto")
        auto = not (ok and auto == false) and not talk.manual and view.more and view.words
        Foot.Time(auto and Model.Time(view.words) or nil, view.width, auto and function() guarded(onward) end)
    end
end

-- What the game says of the window of a talk, and a problem in words ("" for none).
local function read(source)
    return ns.Adapter[LIST[source] or "DialogueQuest"](source)
end

-- The talk in view is read again and drawn again, with its part and its focus as they were
-- (Screen/DialogueWatch.lua asks for it when the game says that something changed).
local function reread()
    if not talk or closing then
        return
    end
    local source, speaker, manual = talk.source, talk.speaker, talk.manual
    local data, problem = read(source)
    if problem == "" then
        talk = Model.Open(talk.kind, data, Draw.Lines, talk)
        talk.source, talk.speaker, talk.manual = source, speaker, manual
        draw()
    end
end

-- A fault of the view, or the game's own window showed all the same. The view is off until
-- the next login. Its frames go one frame later (this can run inside a press), the game's
-- windows hear their events again, and the talk ends unless the game's own window has it.
local function fail(why)
    if Take.Off() then
        return
    end
    Take.Stop(why)
    note("the view is off until the next login: " .. tostring(why))
    local close = (talk or wait) ~= nil
    talk, wait, closing = nil, nil, false
    C_Timer.After(0, function()
        pcall(function()
            root:SetScript("OnUpdate", nil)
            root:Hide()
            input:Hide()
            Input.Rest()
            Watch.Set(false)
            if built then
                Draw.Rest()
            end
        end)
        local back = Take.Back()
        local game = ns.Adapter.DialogueGameWindow()
        if close and not game then
            ns.Adapter.DialogueDo("leave")
        end
        note("the game's windows hear their events again: " .. tostring(back) .. "; the game's own window has the talk: " .. tostring(game))
        -- told always: a fault inside finish() comes after the talk is gone, and the rest of the
        -- suite must not keep reading that the view has the controller
        ns.Send("dialogue:closed")
        ns.Print(game and "Dialogue View is off until you type /reload. The game's own windows are back."
            or "Dialogue View had a fault and is off until you type /reload. Talk to the NPC again for the game's own window.")
    end)
end

-- The talk is over: the view goes, and the controller is the game's again. now: at once, with
-- no fade (combat, a movie, a loading screen, another window of the game).
local function finish(now)
    local shown = talk ~= nil
    talk, wait, closing = nil, nil, false
    Input.Rest()
    if shown then
        Watch.Set(false)
        Draw.Rest()
        if now then
            Draw.Gone()
        else
            Draw.Fade(0, fail)
        end
        follow(true)
        ns.Send("dialogue:closed")
    end
    sync()
end

function guarded(fn, ...)
    if not ns.Call("Dialogue", fn, ...) then
        fail("a fault in the view")
    end
end

-- Combat, a movie, a loading screen, another window of the game or a controller that went: a
-- talk ends at once, in the view and in the game, and nothing of the view keeps a button. Every
-- call here is a plain one: frames of the addon's own hide, and the game is told that the
-- gossip and the quest are closed.
local function quit(why)
    if talk or wait then
        note(why .. ": the talk ends at once")
        guarded(finish, true)
        ns.Adapter.DialogueDo("leave")
    end
end

-- ---------------------------------------------------------------- a talk opens and ends

local function show(source, data)
    local kind = LIST[source] and "gossip" or source
    if not built then
        Draw.Build(root)
        built = true
    end
    Draw.Scale(ns.Registry.Get("windows.dialogue_size"))
    -- shown first: the game counts the lines of a text of a frame that shows
    root:Show()
    local before = talk
    local speaker = data.unit and ns.Adapter.DialogueName(data.unit) or data.title or ""
    talk = Model.Open(kind, data, Draw.Lines, before and before.kind == kind and before or nil)
    -- (a talk that the player turned by hand stays so)
    talk.source, talk.speaker, talk.manual = source, speaker, before and before.manual or nil
    -- the portrait stays while the same NPC talks on
    if not before or before.speaker ~= speaker then
        local face, words = Draw.Face(data.unit, data.title, note)
        note("the portrait shows the " .. face .. " of " .. tostring(data.unit) .. " (" .. tostring(words) .. ")")
    end
    note(source .. ": " .. talk.count .. " parts, " .. (kind == "gossip" and #data.rows .. " rows" or #data.fixed + #data.choices .. " rewards"))
    if data.goals then   -- (the game's code does not say where the count stands in an objective's text)
        note("quest " .. tostring(data.id) .. " has " .. #data.goals .. " objectives; the first reads '" .. tostring(data.goals[1] and data.goals[1].text) .. "'",
            "goals" .. tostring(data.id))
    end
    draw("state")
    if not before then
        Watch.Set(true)
        Input.Fresh()
        ns.Adapter.Sound("IG_QUEST_LIST_OPEN")
        note("the game says the last input came from the " .. ns.Adapter.DialogueLastInput(), "input")
        ns.Send("dialogue:opened")
    end
    Draw.Fade(1, fail)
    follow()
end

-- One frame after the game opened a window of a talk (late: half a second after, when a choice
-- was taken inside the event).
local function begin(late)
    local now = wait
    if not now then
        return
    elseif talk then
        -- the talk in view goes on: its buttons are back, whatever comes of this window
        follow()
    end
    if ns.Adapter.DialogueGameWindow() then
        fail("the game's own window showed for " .. now.event)
        return
    end
    note("the game's own window stayed away at " .. now.event, "away")
    if now.source == "gossip" and not late and chosenAt >= now.at then
        -- Skip Gossip took the only choice: no view for a vendor that opens in a moment
        note("a choice was taken inside the event: the view waits half a second")
        local mine = turn
        C_Timer.After(0.5, function()
            if mine == turn and wait == now then
                guarded(begin, true)
            end
        end)
        return
    elseif now.source == "offer" then
        -- An offer for which the game's own window does not show. One from the adventure map is
        -- left alone. One that a looted item starts, and one that the game took by itself at a
        -- place, show in the view: the game's window sends them to the quest tracker through the
        -- tracker's own code, and from an addon the tracker would draw the notice only at the
        -- next change of the quest log, so the player would see nothing happen.
        local special = ns.Adapter.DialogueSpecial(now.startItem)
        if special then
            note("a quest offer of the kind '" .. special .. "' has no window in the game")
        end
        if special == "map" then
            wait = nil
            return
        end
    end
    local data, problem = read(now.source)
    if problem ~= "" then
        error("the game's answers for " .. now.source .. " could not be read: " .. problem)
    end
    if now.source == "gossip" and data.auto and not late then
        wait = nil
        note("the one choice is of the kind the game takes by itself: taken, no view")
        ns.Adapter.DialogueDo("option", data.auto)
        return
    end
    -- (the talk waits until it is drawn: a fault in the drawing then still ends it)
    show(now.source, data)
    wait = nil
end

-- The game opened a window of a talk (source: "gossip", "greeting", "offer", "progress", "handin").
local function opened(source, event, startItem)
    if not Take.Has() then
        return
    end
    turn = turn + 1
    local mine = turn
    wait, closing = { source = source, kind = LIST[source] and "gossip" or source, event = event, at = GetTime(), startItem = startItem }, false
    note(event .. " came" .. (startItem and startItem ~= 0 and " with the item " .. tostring(startItem) or ""))
    -- not inside the event: Skip Gossip can take the only choice in it, and the game's window would show in it
    C_Timer.After(0, function()
        if mine == turn then
            guarded(begin)
        end
    end)
end

-- The game ended a gossip (ofGossip true) or a quest's window. more: the game says that
-- another window of the same NPC follows.
local function ended(ofGossip, event, more)
    local now = talk or wait
    if not now then
        -- a talk in the game's own window ended: the view can have the next one
        if not Take.Has() and root then
            C_Timer.After(0, sync)
        end
        return
    elseif ofGossip ~= gossip(wait or now) then
        -- The end of another window. The game can tell of the next window first and of the old
        -- window's end after it (a quest's offer, then the end of the gossip it came from): the
        -- window that waits to be drawn is not this one, and it stays.
        return
    end
    note(event .. " came" .. (more and ": the game says more follows" or ""))
    turn = turn + 1
    local mine = turn
    wait = nil
    if not talk then
        return
    end
    -- the controller is free at once; the band waits for the next window of the same NPC
    closing = true
    C_Timer.After(0, function()
        if talk then
            follow()
        end
    end)
    C_Timer.After(more and 0.5 or 0.1, function()
        if mine == turn then
            guarded(finish)
        end
    end)
end

-- A step of the game, one frame after the press that asked for it. Leave always ends the
-- view, whatever the game answers.
local function step(name, value, last)
    C_Timer.After(0, function()
        local ok, err = ns.Adapter.DialogueDo(name, value)
        if not ok then
            note(name .. " did not run: " .. err)
        end
        if last then
            guarded(finish)
        end
    end)
end

-- A window or a question of the game took the controller or gave it back, or a question of
-- the game opened or closed. Both are told from inside the game's code, so the view follows
-- one frame later. With no talk this does nothing.
local function later()
    if talk then
        C_Timer.After(0, function()
            if talk and closing and ns.Adapter.GameplayHasPad() == false then
                -- the next window of the NPC is one of the game's (a vendor): the band goes now
                guarded(finish)
            elseif talk then
                follow()
            end
        end)
    end
end

function Dialogue.OnLogin()
    local side = { note = note, guarded = guarded, step = step, draw = draw, reread = reread, fail = fail, opened = opened, ended = ended,
        quit = quit, sync = sync, later = later, talk = function() return not closing and talk or nil end,
        busy = function() return talk or wait end, chosen = function() chosenAt = GetTime() end }
    -- another addon that has the game's windows: the view stays off (asked before the first take)
    Take.Login(note)
    -- the frames are made at login and out of combat (Screen/DialogueInput.lua says why)
    ns.Queue.Run("Dialogue", function()
        root = CreateFrame("Frame", "GamepadSuiteDialogue", UIParent)
        root:SetAlpha(0)
        root:Hide()
        input = Input.Build(root, side)
        Stage.Build(root, note, quit)
        sync()
    end)
    -- what the view hears of the game from now on (Screen/DialogueWatch.lua)
    Watch.Login(side)
end
