-- The on-screen keyboard's chat part (the keyboard itself is Screen/Keyboard.lua). It opens the
-- keyboard for a chat line when the game's chat box takes the focus while the player's hands are on
-- the controller, and sends the line at Send (Menu, or A on the key Send) through a secure button of
-- ours that the game runs as a macro line, to the channel the chat box shows. The chat box is only
-- read (Core/AdapterKeyboard.lua says why).
--
-- The flow of a chat line:
--   Word guesses: a row of up to three over the keys, for the word being typed, from the words the
--   player sent (learned for the account, at most 400) and a short built-in list
--   (Screen/KeyboardWords.lua). RB puts the first one in; D-pad up from the top row of keys reaches
--   them, and A puts in the one in focus. The row Word Guess turns them off.
--   It stays open after a send: the line clears when the game ran it, and the next one can be typed.
--   B or the key Close closes it; the game's chat box then stays for the game's own B.
--   The channel row under the keys: the channels that work now, then Close
--   (Screen/KeyboardChannels.lua). A picks one: the line then goes with its chat command in front.
--   The channel picked last stays for the next chat line of the session, as the game's own chat box
--   keeps its channel.
--   Whisper opens a list of names beside the keyboard: the group, online friends, the guild.
--   A line that a fight or the game closed is kept: after the fight the keyboard opens again with it
--   while the chat box still has the focus, else the next chat line within 10 minutes starts with it.
--   The chat bind in a fight opens the game's box only: one chat line a fight says that the keyboard
--   opens after combat, and it opens then for that box while the box still has the focus.
--   A reply from the whisper pop-up opens the keyboard with no chat box of the game's (Chat.Reply).
local _, ns = ...

local Keyboard = ns.Keyboard
local Chat = {}
ns.KeyboardChat = Chat

local Model, Words, Channels = ns.KeyboardModel, ns.KeyboardWords, ns.KeyboardChannels
local note = Keyboard.Note

local GUESS = "keyboard.word_guess"   -- the row Word Guess (build_plan/round_0_25/glue/keyboard_flow.md)
local KEEP = 600                      -- seconds a kept line waits for the next chat line

local sender              -- the secure button that sends a chat line
local bound = false       -- Menu and A are bound to the send button: the keyboard is open for chat
local again = false       -- Menu and A are to be taken anew at the next frame
local pending             -- the button of a Send whose line the send button has not yet run
local sending             -- the line of that Send, learned when the game ran it
local chat                -- the chat text box that has the focus now
local kept                -- a line that a fight or the game closed: { text, channel, at }
local back                -- the chat box of a keyboard that a fight closed, or that a fight kept closed
local toldFight = false   -- this fight's line "opens after combat" was said
local last                -- the channel picked last in this session (no whisper, no reply)
local store               -- the account's saved table of the keyboard: { words = { word = count } }

-- Word Guess is on (it is, while the row is not in the settings yet).
local function guessOn()
    return not ns.Registry.Has(GUESS) or ns.Registry.Get(GUESS) == true
end

-- Menu and A are bound to the send button, given back first so that they are the newest binds
-- on their keys. Gives what each reads back as.
local function take()
    ns.Adapter.GiveKeys(sender)
    return ns.Adapter.TakeKey(sender, "MN"), ns.Adapter.TakeKey(sender, "A")
end

-- The guesses for the line as it is now.
function Chat.Typed(state)
    state.words = state.guess and Words.Guess(state.text, store.words) or {}
    Model.Settle(state)
end

-- The channel the line goes to: a picked one (a chip), or nil for the chat box's own. The title and
-- the lit chip follow it.
local function use(state, channel)
    state.channel = channel
    state.title = channel and channel.title or state.boxTitle
    state.lit = channel and Channels.At(state.chips, channel.id) or state.boxLit
end

-- The channel of a reply from the whisper pop-up (Chat.Reply): the chip Reply, with the line to the
-- sender's name (the game's whisper command), so a whisper that comes in the meantime does not take
-- it. A Battle.net whisper has no name to type (to is true): the chip as it is, the game's /r to its
-- last whisper (Blizzard_ChatFrameBase/Mainline/ChatFrameOverrides.lua 693).
local function replyTo(chips, facts, to, shown)
    local chip = chips[Channels.At(chips, "reply") or 0]
    local slash = facts and facts.slash.whisper
    if type(to) == "string" and slash then
        return { id = "reply", label = "Reply", target = to, prefix = slash .. " " .. to, title = "To " .. (shown or to) .. ":" }
    end
    return chip
end

-- The keyboard is open for a chat line and its panel shows now. The game puts the line that it
-- opened the box with (a whisper from a menu) into the box at the box's next frame, so the box is
-- read here, before anything is typed. Then the channel row, a reply, a kept line or the channel
-- picked last, and the guesses.
local function start(state)
    local box = state.box
    state.boxTitle, state.text = ns.Adapter.ChatLine(box)
    local kind, tell, number = ns.Adapter.ChatBoxKind(box)
    local whisper = kind == "WHISPER" or kind == "BN_WHISPER"
    local facts = ns.Adapter.ChatFacts()
    if facts then
        facts.canWhisper = whisper or #Channels.Names(ns.Adapter.ChatNames()) > 0
        ns.Adapter.AskGuildList()
    end
    state.chips = Channels.Chips(facts)
    state.boxLit = Channels.Find(state.chips, kind, number)
    state.tell = kind == "WHISPER" and tell or nil
    state.guess = guessOn()
    local channel
    if state.reply then
        channel = replyTo(state.chips, facts, state.reply, state.shown)
    elseif kept and not whisper and GetTime() - kept.at < KEEP and kept.text:sub(1, #state.text) == state.text then
        state.text, channel, kept = kept.text, Channels.Keep(state.chips, kept.channel), nil
    elseif not whisper then
        channel = Channels.Keep(state.chips, last)
    end
    -- the chat box's own channel needs no chat command in front: the plain line the game proved
    if channel and state.boxLit and state.chips[state.boxLit].id == channel.id and channel.id ~= "whisper" then
        channel = nil
    end
    use(state, channel)
    Chat.Typed(state)
    Keyboard.Redraw()
end

-- The keyboard's panel shows or goes (Screen/Keyboard.lua, one frame after the change). Menu, and A
-- on the key Send, send a chat line: they are bound to the send button while the keyboard is open
-- for chat, and given back when it goes.
function Chat.Follow(state)
    if pending then
        note("Done with " .. pending .. ": the press did not reach the send button, so the line was not sent", "lost")
        pending = nil
    end
    local want = state and state.box ~= nil
    if want and not state.started then
        state.started, bound = true, true
        start(state)
        local menu, a = take()
        note("Menu sends a chat line: " .. tostring(menu) .. "; A on Done sends it: " .. tostring(a), "keys")
    elseif bound and not want then
        bound = false
        ns.Adapter.GiveKeys(sender)
    end
end

-- Send on a chat line, by Menu or by A on the key Send. The line goes on the send button and true
-- lets this press go on to that button's bind, so the game sends the line now. An empty line closes
-- the keyboard and sends nothing. While the key does not click the send button (another bind is
-- over it, or LT is held: Core/AdapterKeyboard.lua) the press is kept and so is the line.
function Chat.Send(state, button)
    local text = state.text
    if not text:find("%S") then
        Keyboard.Close()
        return false
    end
    local ok, said = ns.Adapter.ChatToSend(sender, button, text, state.box, state.channel and state.channel.prefix)
    if not ok then
        note("Done with " .. tostring(button) .. " sent nothing: " .. tostring(said), "kept " .. tostring(said))
        return false
    end
    pending, sending = button, text
    note("Done with " .. button .. ": a line of " .. Model.Length(text) .. " letters goes to the game"
        .. (said ~= "" and ", with " .. said .. " in front" or ""), "done " .. button .. said)
    -- the keyboard stays for the next line; one frame later the panel keeps every press again
    Keyboard.Follow()
    return true
end

-- The game ran the line of the send button (its click, inside the press of Send). The line's words
-- are learned, and the keyboard waits with an empty line.
local function ran(text)
    pending = nil
    note("the game ran the chat line: " .. Model.Length(text or "") .. " letters", "ran")
    local state = Keyboard.State()
    if state and state.box and sending then
        if state.guess then
            Words.Learn(store.words, sending)
        end
        state.text, sending = "", nil
        Chat.Typed(state)
        Keyboard.Redraw()
    end
end

-- A on a guess (or RB), on a chip of the channel row, or on a whisper name.
function Chat.Pick(state, what, place)
    if what == "word" then
        local new = Words.Use(state.text, state.words[place], state.limit)
        if new then
            state.text = new
            Chat.Typed(state)
        end
        return
    elseif what == "name" then
        local entry = state.names[place]
        if entry then
            use(state, Channels.Whisper(state.chips, entry.name))
            state.zone = nil
        end
        return
    end
    local chip = state.chips[place]
    if chip.id == "close" then
        Keyboard.Close()
    elseif chip.id == "whisper" then
        state.names = Channels.Names(ns.Adapter.ChatNames(), state.channel and state.channel.target or state.tell)
        state.zone, state.name = "names", 1
        local count = { away = 0, busy = 0 }
        for _, entry in ipairs(state.names) do
            count[entry.state or "none"] = (count[entry.state or "none"] or 0) + 1
        end
        note("whisper list: " .. #state.names .. " names, away " .. count.away .. ", busy " .. count.busy, "names")
    else
        use(state, place ~= state.boxLit and chip or nil)
        if chip.id ~= "reply" then
            last = chip
        end
        state.zone = nil
    end
end

-- The keyboard closes, not by the player: its line is kept (with its channel), and after a fight
-- (fight true) the keyboard opens again for the same chat box.
function Chat.Keep(state, fight)
    if fight then
        back = state.box
    end
    if state.text:find("%S") then
        local channel = state.channel
        -- a reply to a name is kept as a whisper to that name: the chip Reply would send it to whoever whispered last
        if channel and channel.id == "reply" and channel.target then
            channel = { id = "whisper", label = "Whisper", target = channel.target, prefix = channel.prefix, title = channel.title }
        end
        kept = { text = state.text, channel = channel, at = GetTime() }
    end
end

-- The keyboard opens for a chat line: the line that the chat box has is the text so far, and the
-- title is where the line goes. Its panel shows one frame later (start above).
local function chatOpen(box)
    if chat ~= box or Keyboard.IsOpen() or ns.Adapter.InCombat() then
        return
    end
    local name, text = ns.Adapter.ChatLine(box)
    Keyboard.Open({ title = name, text = text, limit = ns.Adapter.CHAT_MOST, box = box })
end

-- A reply to a whisper, from the whisper pop-up (Screen/WhisperPopup.lua, at the let-go of its hold,
-- out of any press). The keyboard opens for a chat line with no chat box of the game's: REPLY stands
-- where the box would be, and the adapter reads nothing from it. The line goes through the send button
-- as every chat line does, with the reply's chat command in front. to: the sender as the game names it,
-- or true for a Battle.net whisper; shown: the name to show. Out of a fight only, and not over an open
-- keyboard. True when it opened.
local REPLY = {}
function Chat.Reply(to, shown)
    if not sender or Keyboard.IsOpen() or ns.Adapter.InCombat() then
        return false
    end
    note("the whisper pop-up opens the keyboard for a reply", "reply")
    Keyboard.Open({ title = "", text = "", limit = ns.Adapter.CHAT_MOST, box = REPLY, reply = to, shown = shown })
    return true
end

-- The fight is over (the game's event, out of any press): a keyboard that the fight closed opens
-- again, with its line, while its chat box still has the focus.
function Chat.Back()
    local box = back
    back, toldFight = nil, false
    if box and chat == box and sender and not Keyboard.IsOpen() then
        note("the fight is over: the keyboard opens again for the chat line" .. (kept and ", with the kept line" or ""), "back")
        chatOpen(box)
    end
end

-- A chat text box took the focus. The game tells of it from inside its own chat code (and that
-- code runs inside the press of the bind that opened the box), so here the controller is only
-- looked at: the button of the bind is still down, or the stick of a wheel is still pushed. Then
-- the keyboard opens one frame later. A real keyboard or a mouse click opens the box with the
-- controller at rest: no keyboard. None in a fight, and none over another keyboard.
local function chatGained(box)
    chat = box
    if Keyboard.IsOpen() or not sender then
        return
    elseif ns.Adapter.InCombat() then
        -- the bind of the controller in a fight: the box stays the game's, the keyboard comes
        -- after it for this box (Chat.Back), and one line a fight says so (windows.md 10)
        if ns.Adapter.PadInUse() then
            back = box
            if not toldFight then
                toldFight = true
                ns.Print("The chat keyboard opens after combat.")
            end
        end
        return
    elseif not ns.Adapter.PadInUse() then
        note("the chat box took the focus: no keyboard, the controller was at rest", "rest")
        return
    end
    note("the chat box took the focus: the controller was in use, the keyboard opens", "open")
    C_Timer.After(0, function() ns.Call("Keyboard", chatOpen, box) end)
end

-- A chat text box lost the focus or hid. Told from inside the game's own chat code too: the
-- keyboard for that box closes one frame later, if the box did not take the focus again. The line
-- is kept: the game closed the box, not the player.
local function chatLost(box)
    if chat == box then
        chat = nil
    end
    local state = Keyboard.State()
    if state and state.box == box then
        C_Timer.After(0, function()
            local now = Keyboard.State()
            if chat ~= box and now and now.box == box then
                Keyboard.Close(true, true)
            end
        end)
    end
end

-- The send button, made with the panel (out of a fight).
function Chat.Build()
    sender = ns.Adapter.ChatSender("GamepadSuiteKeyboardSend", function(text)
        ns.Call("Keyboard", ran, text)
    end)
end

-- The row Forget Typed Words: the learned words go.
function Keyboard.ForgetWords()
    ns.Registry.Store("keyboard").words = {}
end

function Chat.Login()
    store = ns.Registry.Store("keyboard")
    store.words = type(store.words) == "table" and store.words or {}
    ns.Adapter.OnChatBox(function(box) ns.Call("Keyboard", chatGained, box) end, function(box) ns.Call("Keyboard", chatLost, box) end)
    -- The game set its window binds again (a popup, a window): its newest bind would win over
    -- Menu and A. One frame later they are the send button's again, while the keyboard is open
    -- for chat.
    ns.Listen("pad:stack", "Keyboard", function()
        if bound and not again then
            again = true
            C_Timer.After(0, function()
                again = false
                if bound and not ns.Adapter.InCombat() then
                    ns.Call("Keyboard", take)
                end
            end)
        end
    end)
end
