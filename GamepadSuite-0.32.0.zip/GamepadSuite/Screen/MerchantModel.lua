-- The rules of the merchant view, with no game calls: the three tabs, the grid of cards and its
-- pages, what each button does, how much a tap and a hold of A buy, which button hints show, and
-- the words. The facts of the game's vendor window behind each rule are in
-- build_plan/packs/P18_merchant_view.md.
--
-- A vendor in view is a state: { tab ("buy", "sell" or "buyback"), lists = { buy, sell, buyback },
-- at = { the card in focus of each tab }, money (copper), repairs (the vendor repairs), repair
-- ({ cost, gold, guild }, nil while nothing needs it), canJunk (the game's sale of junk is on),
-- junk (its count), marking (Mark Junk is on: a hold of Y marks a card of the Sell tab, and X
-- sells the marks too), ask (the card whose question shows in the line), edge ("back" or "next": a
-- page control has the focus, not a card), words }.
-- A thing to buy: { index, name, icon, price (one lot), lot, stack, left, buyable, usable, afford,
-- costs, questStart }. A thing to buy back: { index, name, icon, price (the stack), count, usable }.
-- A thing in the bags: { bag, slot, id, name, icon, count, price (one), quality, noValue, locked,
-- need (the quest that needs it, or true for a quest item), junk, hasLoot }.
local _, ns = ...

local Model = {}

Model.COLS, Model.ROWS = 5, 2
Model.PER = Model.COLS * Model.ROWS     -- ten cards a page, as the game's MERCHANT_ITEMS_PER_PAGE (MerchantFrame.lua 1)
Model.HOLD = 0.5                        -- the seconds A is held for a stack
Model.MARK = 1                          -- the seconds Y is held to mark junk: the suite's hold (Screen/RollsModel.lua HOLD)
Model.FRESH = 0.5                       -- an A this soon after the view opened does nothing
Model.HIGH = 1500000                    -- 150 gold: asked first, as the game's MERCHANT_HIGH_PRICE_COST (MerchantFrame.lua 672)
Model.TABS = { "buy", "sell", "buyback" }
Model.TITLE = { buy = "Buy", sell = "Sell", buyback = "Buyback" }
Model.EMPTY = { buy = "This vendor has nothing to sell.", sell = "Nothing in your bags sells here.", buyback = "Nothing to buy back." }
Model.WORDS = { soldOut = "Sold out.", cannot = "You can't buy this yet.", money = "You don't have enough money.",
    short = "You don't have enough to pay for this.", repair = "You don't have enough money to repair.", junk = "You have no junk to sell." }

local COLS, PER = Model.COLS, Model.PER
local DPAD = { DU = true, DD = true, DL = true, DR = true }

-- A new vendor. words: the game's own words that take the place of ours (money).
function Model.New(words)
    local s = { tab = "buy", lists = { buy = {}, sell = {}, buyback = {} }, at = { buy = 1, sell = 1, buyback = 1 }, money = 0, junk = 0, words = {} }
    for key, text in pairs(Model.WORDS) do
        s.words[key] = (words or {})[key] or text
    end
    return s
end

-- A tab's list is new: the focus stays at its place, or goes to the last card of a shorter list.
function Model.Fill(s, tab, list)
    s.lists[tab] = list
    s.at[tab] = math.max(1, math.min(s.at[tab], #list))
    if tab == s.tab and s.edge and not select(s.edge == "back" and 1 or 2, Model.Edges(s)) then
        s.edge = nil
    end
end

-- The card in focus, or nil on an empty tab and while a page control has the focus.
function Model.Focus(s)
    return not s.edge and s.lists[s.tab][s.at[s.tab]] or nil
end

-- The page in view and the count of pages (one at least), and the place in the list of the
-- page's first card.
function Model.Page(s)
    local page = math.ceil(s.at[s.tab] / PER)
    return page, math.max(1, math.ceil(#s.lists[s.tab] / PER)), (page - 1) * PER + 1
end

-- Which page controls show: back (a page before this one) and next (a page after it).
function Model.Edges(s)
    local page, pages = Model.Page(s)
    return page > 1, page < pages
end

-- True when a thing of the vendor comes in more than one lot in one call, so a hold buys more
-- than a tap. A thing with an extra cost (tokens, items) is bought one lot at a time.
function Model.Stacks(item)
    return not item.costs[1] and item.stack >= 2 * item.lot
end

-- The items a full stack is, in whole lots.
function Model.Stack(item)
    return math.max(1, math.floor(item.stack / item.lot)) * item.lot
end

-- How many items a tap (stack false) or a full hold (stack true) of A buys: whole lots, no more
-- than one stack, than the gold pays for, and than the vendor has. 0 when the gold pays for no lot.
function Model.Amount(item, money, stack)
    local lots = stack and math.max(1, math.floor(item.stack / item.lot)) or 1
    if item.price > 0 then
        lots = math.min(lots, math.floor(money / item.price))
    end
    if item.left > 0 then
        lots = math.min(lots, item.left)
    end
    return math.max(0, lots) * item.lot
end

-- True when the price of a card is more than the player can pay (its price is red).
function Model.Short(s, entry)
    return s.tab ~= "sell" and (entry.price > s.money or entry.afford == false)
end

-- What a thing costs, in words: "Costs 2 Badge of Justice and 1g." coins(copper) writes gold.
function Model.Costs(item, coins)
    local parts = {}
    if item.price > 0 then
        parts[1] = coins(item.price)
    end
    for _, cost in ipairs(item.costs) do
        parts[#parts + 1] = cost.value .. (cost.name and " " .. cost.name or "")
    end
    return "Costs " .. table.concat(parts, " and ") .. "."
end

-- The Sell tab: the stacks a vendor buys (not the game's "no value"), junk first (gray, or marked
-- by Mark Junk: marks is item id -> true), then in the bags' order.
function Model.Sellable(things, marks)
    local junk, rest = {}, {}
    for _, thing in ipairs(things) do
        if not thing.noValue then
            thing.junk = thing.quality == 0 or marks[thing.id] == true
            table.insert(thing.junk and junk or rest, thing)
        end
    end
    for _, thing in ipairs(rest) do
        junk[#junk + 1] = thing
    end
    return junk
end

-- True when a hold of Y can mark the card in focus as junk or take its mark off: Mark Junk is on, the
-- Sell tab shows, and the card is no gray item and no item a quest needs (JunkModel.Toggle refuses both).
function Model.Markable(s)
    local thing = s.marking and s.tab == "sell" and Model.Focus(s)
    return thing and thing.quality ~= 0 and not thing.need and true or false
end

-- What X sells, the count of its hint: the game's gray items while its sale of junk is on, and the
-- marked stacks of the Sell tab that Auto/JunkSell.lua sells. Gives both, and the marked ones alone.
function Model.Junk(s)
    local marked = 0
    for _, thing in ipairs(s.marking and s.lists.sell or {}) do
        marked = marked + ((thing.junk and thing.quality ~= 0 and not thing.need) and 1 or 0)
    end
    return (s.canJunk and s.junk or 0) + marked, marked
end

-- ---------------------------------------------------------------- the buttons
-- The D-pad over the grid of five cards a row and two rows, with a page control at each side
-- while there is a page that way (the settings window's rule: moving past the end never turns a
-- page; a control with an arrow and a glow does). Right at a row's end puts the focus on the
-- control Next, left at a row's start on the control Back; the other way goes back to the card.
-- Up and down stay on the page.
local function move(s, button)
    local n, at = #s.lists[s.tab], s.at[s.tab]
    local pos = (at - 1) % PER
    local row, col, base = math.floor(pos / COLS), pos % COLS, (math.ceil(at / PER) - 1) * PER
    local back, after = Model.Edges(s)
    if s.edge then
        if button == (s.edge == "next" and "DL" or "DR") then
            s.edge = nil
            return "focus"
        end
        return nil
    end
    local to
    if button == "DR" and col == COLS - 1 and after or button == "DL" and col == 0 and back then
        s.edge = button == "DR" and "next" or "back"
        return "focus"
    elseif button == "DR" and col < COLS - 1 then
        to = at + 1
    elseif button == "DL" and col > 0 then
        to = at - 1
    elseif button == "DD" and row == 0 then
        to = math.min(at + COLS, n)
        to = to > base + COLS and to or nil
    elseif button == "DU" and row == 1 then
        to = at - COLS
    end
    if not to or to < 1 or to > n or to == at then
        return nil
    end
    s.at[s.tab] = to
    return "focus"
end

-- A on a page control: the page turns, and the focus is on the card of the new page nearest the
-- control (the same row; the last card of a shorter last page).
local function turn(s)
    local n, at = #s.lists[s.tab], s.at[s.tab]
    local page, row = math.ceil(at / PER), math.floor((at - 1) % PER / COLS)
    s.at[s.tab] = s.edge == "next" and math.min(page * PER + row * COLS + COLS, n) or (page - 2) * PER + row * COLS + 1
    s.edge = nil
    return "page"
end

local function buy(s, item, coins)
    if item.left == 0 then
        return "say", s.words.soldOut
    elseif not item.buyable then
        return "say", s.words.cannot
    elseif item.price > s.money then
        return "say", s.words.money
    elseif item.afford == false then
        return "say", s.words.short
    end
    local key = "buy " .. item.index .. " " .. item.name
    if (item.costs[1] or item.price >= Model.HIGH) and s.ask ~= key then
        s.ask = key
        return "ask", Model.Costs(item, coins) .. " Press A again to buy."
    end
    s.ask = nil
    if Model.Stacks(item) then
        return "hold"
    end
    return "do", "buy", item.index, item.lot
end

-- Y: everything is repaired where the vendor repairs, by the guild when its money covers all.
local function repair(s)
    local r = s.repair
    if not (s.repairs and r) then
        return nil
    end
    local guild = (r.guild or 0) >= r.cost
    if not guild and r.gold < r.cost then
        return "say", s.words.repair
    end
    return "do", "repair", guild
end

local function sell(s, thing)
    if thing.locked then
        return nil
    end
    local key = "sell " .. thing.bag .. " " .. thing.slot .. " " .. thing.id
    if thing.need and s.ask ~= key then
        s.ask = key
        return "ask", (thing.need == true and thing.name .. " is a quest item." or "Needed for " .. thing.need .. ".") .. " Press A again to sell it."
    end
    s.ask = nil
    return "do", "sell", thing
end

-- A button went down: "A", "B", "X", "Y", "DU", "DD", "DL", "DR", "LB", "RB" or "MN". coins(copper)
-- writes gold. Returns what changed:
--   "tab"            another tab shows
--   "focus", "page"  the focus moved, on the page or to another page
--   "say", text      the press cannot act: the line gives the reason
--   "ask", text      the line asks first: A again on the same card acts
--   "hold"           A on a stack, Y on a card to mark: the let-go is the tap, a full hold more (Model.Hold, Mark)
--   "do", step, ...  a step of the game, to be made one frame later (Adapter.MerchantDo)
-- or nil when the button does nothing now.
function Model.Press(s, button, coins)
    button = button == "MN" and "B" or button
    if button ~= "A" then
        s.ask = nil
    end
    if button == "B" then
        return "do", "close"
    elseif button == "LB" or button == "RB" then
        local i = 1
        for n, tab in ipairs(Model.TABS) do
            i = tab == s.tab and n or i
        end
        s.tab, s.edge = Model.TABS[(i - 1 + (button == "LB" and -1 or 1)) % #Model.TABS + 1], nil
        return "tab"
    elseif DPAD[button] then
        return move(s, button)
    elseif button == "X" then
        if not (s.canJunk or s.marking) then
            return nil
        end
        local count = Model.Junk(s)
        return count > 0 and "do" or "say", count > 0 and "junk" or s.words.junk
    elseif button == "Y" then
        if Model.Markable(s) then
            return "hold"
        end
        return repair(s)
    elseif button ~= "A" then
        return nil
    elseif s.edge then
        return turn(s)
    end
    local entry = Model.Focus(s)
    if not entry then
        return nil
    elseif s.tab == "buy" then
        return buy(s, entry, coins)
    elseif s.tab == "sell" then
        return sell(s, entry)
    elseif entry.price > s.money then
        return "say", s.words.money
    end
    return "do", "buyback", entry.index
end

-- The end of a hold of A on the Buy tab: a let-go before Model.HOLD (full false) buys one lot, a
-- full hold a stack. Returns what Model.Press returns.
function Model.Hold(s, full)
    local item = s.tab == "buy" and Model.Focus(s)
    if not item then
        return nil
    end
    local amount = Model.Amount(item, s.money, full)
    if amount == 0 then
        return "say", s.words.money
    end
    return "do", "buy", item.index, amount
end

-- The end of a hold of Y on the Sell tab: a let-go before Model.MARK (full false) is a tap, which
-- repairs; a full hold marks the card in focus or takes its mark off ("do", "mark", thing).
function Model.Mark(s, full)
    if not full then
        return repair(s)
    elseif Model.Markable(s) then
        return "do", "mark", Model.Focus(s)
    end
end

-- The mouse wheel over the cards: a page back (step -1) or on (step 1), the focus at the same
-- place of that page, or at the last card of a shorter last page. Returns "page", or nil.
function Model.Turn(s, step)
    local n, at = #s.lists[s.tab], s.at[s.tab]
    local to = math.min(at + step * PER, n)
    if to < 1 or math.ceil(to / PER) == math.ceil(at / PER) then
        return nil
    end
    s.at[s.tab], s.ask, s.edge = to, nil, nil
    return "page"
end

-- A left click on a page control (way "back" or "next"): the page turns, as A on it does.
function Model.PageClick(s, way)
    if not select(way == "back" and 1 or 2, Model.Edges(s)) then
        return nil
    end
    s.edge, s.ask = way, nil
    return turn(s)
end

-- A left click (of the mouse, or of mouse mode's LT) on card n of the page. A card that is not in
-- focus gets the focus; the card in focus does what A does, and a thing that stacks buys one lot
-- (a click has no hold). Returns what Model.Press returns.
function Model.Click(s, n, coins)
    local _, _, first = Model.Page(s)
    local at = first + n - 1
    if not s.lists[s.tab][at] then
        return nil
    elseif at ~= s.at[s.tab] or s.edge then
        s.at[s.tab], s.ask, s.edge = at, nil, nil
        return "focus"
    end
    local what, a, b, c = Model.Press(s, "A", coins)
    if what == "hold" then
        return Model.Hold(s, false)
    end
    return what, a, b, c
end

-- The button hints from the left: { keys, text, off (the button does nothing now) }.
function Model.Hints(s, coins)
    local out = {}
    local function add(keys, text, off)
        out[#out + 1] = { keys = keys, text = text, off = off and true or nil }
    end
    local item = Model.Focus(s)
    if #s.lists[s.tab] > 1 then
        add({ "DPAD" }, "Move")
    end
    add({ "LB", "RB" }, "Tab")
    local mark = Model.Markable(s) and (item.junk and "hold to unmark" or "hold to mark junk")
    local r = s.repairs and s.repair
    if r then
        add({ "Y" }, "Repair " .. coins(r.cost) .. ((r.guild or 0) >= r.cost and " (guild)" or "") .. (mark and ", " .. mark or ""))
    elseif mark or s.repairs then
        add({ "Y" }, mark and (mark:gsub("^%l", string.upper)) or "Repair", not mark)
    end
    if s.canJunk or s.marking then
        local count = Model.Junk(s)
        add({ "X" }, count > 0 and "Sell junk (" .. count .. ")" or "Sell junk", count == 0)
    end
    if s.edge then
        add({ "A" }, s.edge == "next" and "Next page" or "Previous page")
    elseif s.tab == "buy" then
        add({ "A" }, item and Model.Stacks(item) and "Buy, hold for " .. Model.Stack(item) or "Buy", not item or item.left == 0 or not item.buyable)
    elseif s.tab == "sell" then
        add({ "A" }, "Sell", not item or item.locked)
    else
        add({ "A" }, "Buy back", not item)
    end
    add({ "B" }, "Close")
    return out
end

if ns then
    ns.MerchantModel = Model
end
return Model
