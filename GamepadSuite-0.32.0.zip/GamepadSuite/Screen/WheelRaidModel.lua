-- The rules of the raid's healer wheel, with no game calls (Core/Wheels.lua fills it, Core/BindHolds.lua writes its
-- moves for the game's restricted code, Screen/WheelRaid.lua draws it). The owner: "I want one wheel to contain 10
-- players but like a 5 on top of the radial and 5 on the bottom of the radial. So like 2 groups per radial."
-- In a raid each party wheel of healer mode is one radial for each pair of raid groups that has members (1 + 2, 3 + 4,
-- 5 + 6, 7 + 8). A radial has ten places, 36 degrees apart: the first group's five on the top half and the second
-- group's five on the bottom half, each half from left to right. A member's place is its index in its group, so it
-- does not move while its group stays (the party wheel's rule, decision 56). An empty place is blank: the stick
-- points at nothing there, and a flick there casts nothing.
-- One radial stands at the Healer Wheel's place, two side by side, three as two on top and one centred below, four as
-- two on top of two, in reading order. The chosen radial is full size; the others are SMALL of it, in their own
-- places, so nothing moves when the choice changes. LB and RB go to the radial before and after in reading order, round
-- from the last to the first; the D-pad goes to the radial that lies that way.
local _, ns = ...

local Model = {}

Model.GROUPS = 8        -- the game's raid groups (MAX_RAID_GROUPS, Blizzard_RaidUI.lua 1)
Model.PAIRS = 4         -- two groups on each radial
Model.HALF = 5          -- the places of one half: a group of five
Model.RING = 3          -- the pictures stand this many pictures from the middle (see Cell)
Model.SMALL = 0.85      -- a radial that is not chosen is this much of the chosen one's size
Model.DIM = 0.45        -- and this dim
Model.MARGIN = 20       -- the least room between the block and the screen's edge, in the units of a place

-- Where member k of a half points (1: the top half, 2: the bottom half), as a step of length 1: x is right, y is up.
-- The top half from upper left (-72 degrees) to upper right (72), the bottom half from lower left (252) to lower right
-- (108). A split line across the middle has the first group over it and the second under it.
function Model.Spot(half, k)
    local angle = (half == 1 and k - 3 or 8 - k) * math.pi / 5
    return math.sin(angle), math.cos(angle)
end

-- The pair of the player's own group (the group whose first unit is the player), or nil.
function Model.Own(groups)
    for group = 1, Model.GROUPS do
        if groups[group] and groups[group][1] == "player" then
            return math.ceil(group / 2)
        end
    end
end

-- The pairs that have members, in reading order.
function Model.Pairs(groups)
    local out = {}
    for pair = 1, Model.PAIRS do
        out[#out + 1] = (groups[2 * pair - 1] or groups[2 * pair]) and pair or nil
    end
    return out
end

-- The ten places of one radial: groups is { [group] = its units, the player first in the player's own }. Each member is
-- a party wheel's entry (WheelRules.Party: it casts on that unit, a stop first); an empty place is { blank, icon } with
-- nothing to cast. Every place has its direction (x, y), of (10) and its group. Empty for a pair with no members.
function Model.Radial(groups, pair, kind, id, icon, cast)
    local top, bottom, out = groups[2 * pair - 1], groups[2 * pair], {}
    if not (top or bottom) then
        return out
    end
    for half, units in ipairs({ top or {}, bottom or {} }) do
        local members = ns.WheelRules.Party(units, kind, id, icon, cast)
        for k = 1, Model.HALF do
            local entry = members[k] or { blank = true, icon = icon }
            entry.x, entry.y = Model.Spot(half, k)
            entry.of, entry.group = 2 * Model.HALF, 2 * pair - 2 + half
            out[#out + 1] = entry
        end
    end
    return out
end

-- Where the radials stand for 1 to 4 of them, in reading order: half steps of a column (x) and of a row (y).
local GRID = {
    { { 0, 0 } },
    { { -1, 0 }, { 1, 0 } },
    { { -1, 1 }, { 1, 1 }, { 0, -1 } },
    { { -1, 1 }, { 1, 1 }, { -1, -1 }, { 1, -1 } },
}
local WAY = { up = { 0, 1 }, down = { 0, -1 }, left = { -1, 0 }, right = { 1, 0 } }

-- Where each step goes from each radial: present is the pairs with members in reading order (Pairs). Gives
-- { [pair] = { prev =, next =, up =, down =, left =, right = } }, each a pair or nil. prev and next go round. A D-pad
-- direction goes to the nearest radial that lies within 45 degrees of it (the straight one before a slanted one, then
-- the first in reading order), and nowhere when none lies that way.
function Model.Moves(present)
    local n, grid, out = #present, GRID[#present], {}
    for k, pair in ipairs(present) do
        local moves = {}
        if n > 1 then
            moves.prev, moves.next = present[(k - 2) % n + 1], present[k % n + 1]
        end
        for step, way in pairs(WAY) do
            local far, side
            for j, other in ipairs(present) do
                local dx, dy = grid[j][1] - grid[k][1], grid[j][2] - grid[k][2]
                local along, across = dx * way[1] + dy * way[2], math.abs(dx * way[2] - dy * way[1])
                if along > 0 and across <= along and (not far or along < far or along == far and across < side) then
                    moves[step], far, side = other, along, across
                end
            end
        end
        out[pair] = moves
    end
    return out
end

-- The measures of one radial at a size in percent (the Wheel Size, times the fit): a picture (the Healer Wheel's own at
-- 100%), one line of a plate (Screen/WheelPlate.lua), how far the pictures stand from the middle (RING pictures: then a
-- name under the 36-degree plate, up to 1.1 pictures wide, clears the plate beside it), the gold ring (just outside the
-- pictures' gold frames), and the box from the middle: half its width (the side plates and their names, 1.6 pictures
-- wide, or the gold ring), up (the gold ring, over your buffs 5 lines over the top plate) and down (the bottom plate's
-- bar 4 to 10 lines under it, its name 3 lines under the bar, 13 of the theme's units high). label: how far "Group N"
-- stands over the middle and "Group M" under it (clear of the spell's picture there); split: half the split line
-- (short of the side plates' names).
function Model.Cell(percent)
    local Rules = ns.WheelRules
    local size = Rules.PICTURE * Rules.GAME * percent / 100
    local line, radius = size / Rules.PICTURE, Model.RING * size
    local side, ring = radius * math.sin(2 * math.pi / 5), radius + size / 2 + 6 * line
    return {
        size = size, line = line, radius = radius, ring = ring,
        half = math.max(side + 0.8 * size, ring + 2 * line),
        up = ring + 2 * line,
        down = radius + size / 2 + 13 * line + 13 * line / Rules.GAME,
        label = 0.35 * size + 3 * line + 7.5 * line / Rules.GAME,
        split = side - 0.8 * size - 4 * line,
    }
end

-- Where n radials stand at the setting Wheel Size (percent) on a screen of wide x high units (Core/AdapterWheel.lua
-- ScreenUnits), number `chosen` of them full size. The block is as large as the Wheel Size, smaller when the screen is
-- too small for it; its frame is round its middle (the Healer Wheel's place): wide x high. Gives the chosen radial's
-- measures (Cell), its middle (x, y), scale, wide, high, and spots: for each radial its middle, size, radius, line and
-- off (not chosen). The places do not depend on the choice: two neighbours are apart whichever of them is chosen.
function Model.Fit(n, chosen, percent, wide, high)
    local grid, cols, rows = GRID[n], n > 1 and 2 or 1, n > 2 and 2 or 1
    local function block(scale)
        local big, small = Model.Cell(percent * scale), Model.Cell(percent * scale * Model.SMALL)
        local gap = 6 * big.line
        local across, tall = big.half + small.half + gap, big.down + small.up + gap
        return 2 * big.half + (cols - 1) * across, 2 * big.down + (rows - 1) * tall, across, tall, big, small
    end
    local w, h = block(1)
    local fit = { scale = math.min(1, (wide - 2 * Model.MARGIN) / w, (high - 2 * Model.MARGIN) / h), spots = {} }
    local across, tall, big, small
    fit.wide, fit.high, across, tall, big, small = block(fit.scale)
    for key, value in pairs(big) do
        fit[key] = value
    end
    for k = 1, n do
        local one = k == chosen and big or small
        fit.spots[k] = { x = grid[k][1] * across / 2, y = grid[k][2] * tall / 2, size = one.size, radius = one.radius, line = one.line, off = k ~= chosen or nil }
    end
    fit.x, fit.y = fit.spots[chosen].x, fit.spots[chosen].y
    return fit
end

-- The label of a group: the game's own words (GROUP_NUMBER, "Group %d") when it has them.
function Model.Title(group, words)
    return type(words) == "string" and words:find("%d", 1, true) and words:format(group) or "Group " .. group
end

if ns then
    ns.WheelRaidModel = Model
end
return Model
