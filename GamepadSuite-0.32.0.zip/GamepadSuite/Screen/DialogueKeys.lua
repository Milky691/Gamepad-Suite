-- The buttons of the dialogue view, with no game calls: what each button does in each state of a
-- talk, and which button hints show. It adds Model.Press and Model.Hints to the rules of
-- Screen/DialogueModel.lua.
--   A acts at once, at any part: it takes the row with the focus, accepts, goes on or completes.
--   X shows the next part, and at the last part the first part again. LB shows the part before,
--   RB the next. Y puts the focus on the rewards, as the D-pad does at the last part. B and the
--   menu button leave.
--   The safety stays: a hand-in with a choice takes only the reward with the focus. With none in
--   focus, A shows the rewards and gives a sign, and no reward gets the focus by it. A quest in
--   progress that is not done does the same. At an offer with a full quest log A does nothing and
--   its hint reads "Quest log full", dim: the game would only write its red line.
--   A press of X, LB, RB or the D-pad stops the text that moves on by itself, for that talk.
--   A click on a row, a reward or a button hint does what the buttons do (Model.Click).
local _, ns = ...

local Model = ns.DialogueModel

local HAND = { X = true, LB = true, RB = true, DU = true, DD = true, DL = true, DR = true }

-- True when the talk has items that the focus can stand on.
local function rewards(s)
    local first, final = Model.Span(s)
    return s.side == "rewards" and final >= first
end

-- A button went down: "A", "B", "X", "Y", "DU", "DD", "DL", "DR", "LB", "RB" or "MN". Returns what changed:
--   "part"     another part of the text shows
--   "focus"    the focus moved
--   "confirm"  the question before the last step shows, or went
--   "sign", moved   A cannot act yet: the last part shows (moved: it was not in view) for a sign
--   "do", act, value   a step of the game (the adapter's name for it), to be made one frame later
-- or nil when the button does nothing now.
function Model.Press(s, button)
    button = button == "MN" and "B" or button
    s.manual = s.manual or HAND[button]
    local last = s.part == s.count
    if s.confirm then
        if button == "A" then
            return "do", s.kind == "offer" and "accept" or "reward", s.kind == "handin" and Model.Choice(s) or nil
        elseif button == "B" then
            s.confirm = nil
            return "confirm"
        end
        return nil
    elseif button == "B" then
        return "do", "leave"
    elseif button == "X" or button == "LB" or button == "RB" then
        local to = button == "X" and (last and 1 or s.part + 1) or s.part + (button == "LB" and -1 or 1)
        if to < 1 or to > s.count or to == s.part then
            return nil
        end
        s.part = to
        return "part"
    elseif s.kind == "gossip" then
        local rows = s.data.rows
        if button == "A" then
            if rows[s.focus] and not rows[s.focus].off then
                return "do", rows[s.focus].act, rows[s.focus].id
            end
            return nil
        end
        local to = s.focus + (button == "DU" and -1 or button == "DD" and 1 or 0)
        if to == s.focus or to < 1 or to > #rows then
            return nil
        end
        -- the list moves by whole rows, so the row with the focus shows
        s.focus, s.top = to, math.max(math.min(s.top, to), to - Model.ROWS + 1)
        return "focus"
    elseif button == "Y" or (button == "DL" or button == "DR") and last then
        if not rewards(s) then
            return nil
        end
        local first, final = Model.Span(s)
        local to = s.focus == 0 and first or button == "Y" and s.focus or s.focus + (button == "DL" and -1 or 1)
        if to < first or to > final or to == s.focus and last then
            return nil
        end
        s.part, s.focus = s.count, to
        return last and "focus" or "part"
    elseif button ~= "A" then
        return nil
    elseif s.kind == "progress" and not s.data.completable or s.kind == "handin" and Model.Choice(s) == nil then
        s.part = s.count
        return "sign", not last
    elseif s.kind == "progress" then
        return "do", "complete"
    elseif s.kind == "offer" and s.data.full and not s.data.auto then
        -- (with a full quest log the game would only write its red line: A waits for room)
        return nil
    elseif s.data.confirm then
        s.part, s.confirm = s.count, s.data.confirm
        return "confirm"
    elseif s.kind == "offer" then
        return "do", s.data.auto and "ack" or "accept"
    end
    return "do", "reward", Model.Choice(s)
end

-- A left click (of the mouse, or of mouse mode's LT) on row or item n at the right, as Immersion
-- takes a click. A row of a gossip is taken, as A takes it; a row that cannot be taken only gets
-- the focus. An item gets the focus, as the D-pad gives it; at a hand-in a click on the reward
-- that has the focus completes, as A does, so two clicks on a reward hand in. Returns what
-- Model.Press returns.
function Model.Click(s, n)
    s.manual = true
    if s.kind == "gossip" then
        local row = s.data.rows[n]
        if not row then
            return nil
        end
        s.focus = n
        if row.off then
            return "focus"
        end
        return "do", row.act, row.id
    end
    local first, final = Model.Span(s)
    if s.confirm or not rewards(s) or n < first or n > final or s.focus == n and s.part == s.count and s.kind ~= "handin" then
        return nil
    elseif s.focus == n and s.part == s.count then
        return Model.Press(s, "A")
    end
    s.part, s.focus = s.count, n
    return "focus"
end

-- The button hints of the state, from the left: { keys = { our key names }, text, off (the
-- button does nothing now) }. The words of B are the suite's: "Close" where it closes the talk
-- (it tells the game only that the window closed), "Cancel" where it takes back the question
-- before the last step; "Back" is always LB, the part before.
function Model.Hints(s)
    local out = {}
    local function add(keys, text, off)
        out[#out + 1] = { keys = keys, text = text, off = off and true or nil }
    end
    local last = s.part == s.count
    if s.confirm then
        add({ "A" }, s.kind == "offer" and "Accept" or "Complete")
        add({ "B" }, "Cancel")
        return out
    end
    if s.kind == "gossip" then
        if #s.data.rows > 1 then
            add({ "DPAD" }, "Move")
        end
    elseif rewards(s) then
        -- at a hand-in with a choice the D-pad chooses; else Y goes to the rewards and then the D-pad moves
        if last and (s.focus > 0 or s.kind == "handin" and #s.data.choices > 1) then
            add({ "DPAD" }, "Move")
        else
            add({ "Y" }, "Rewards")
        end
    end
    if s.part > 1 then
        add({ "LB" }, "Back")
    end
    if s.count > 1 then
        add({ "X" }, last and "Read again" or "Next")
    end
    if s.kind == "gossip" then
        local row = s.data.rows[s.focus]
        add({ "A" }, "Choose", not row or row.off)
    elseif s.kind == "offer" and s.data.auto then
        add({ "A" }, "Continue")
    elseif s.kind == "offer" then
        add({ "A" }, s.data.full and "Quest log full" or "Accept", s.data.full)
    else
        add({ "A" }, s.kind == "handin" and "Complete" or "Continue",
            s.kind == "handin" and Model.Choice(s) == nil or s.kind == "progress" and not s.data.completable)
    end
    add({ "B" }, "Close")
    return out
end
