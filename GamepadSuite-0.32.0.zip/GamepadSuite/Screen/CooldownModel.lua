-- The rules of the cooldown list, with no game calls. The list shows every action of the
-- player's buttons that is cooling down, on any layer: the layer in view too, the game's own bar
-- where a button has no bind of ours, and what a bound wheel holds. A fixed slot always shows its
-- action, so that one is not in the list. The soonest is on top; the list has five lines at most.
-- (The idea of such a list is ControllerForever's. The code is ours.)
local _, ns = ...

local Model = {}

Model.MOST = 5
local LISTED = { spell = true, item = true, macro = true }

-- One name for an action, so that the same spell on two buttons is one line.
function Model.Id(bind)
    return bind.kind .. ":" .. tostring(bind.id)
end

-- The actions that the buttons have now, each one time, in the order of the layers:
--   { { id =, bind =, keys = { "LT", "A" } (its first button, held ones first) } }.
-- find(layer, key) gives what a button runs on a layer now, or nil. buttons are our key names,
-- layers the layers that are on, held the buttons held for each layer. inside(wheel) gives the
-- binds a wheel holds: they come after the actions of all the buttons, with the wheel's button.
function Model.Actions(find, buttons, layers, held, inside)
    local out, seen, wheels = {}, {}, {}
    local function add(bind, layer, key)
        local id = bind and LISTED[bind.kind] and Model.Id(bind)
        if id and not seen[id] then
            local keys = {}
            for i, button in ipairs(held[layer] or {}) do
                keys[i] = button
            end
            keys[#keys + 1] = key
            seen[id] = true
            out[#out + 1] = { id = id, bind = bind, keys = keys }
        end
    end
    for _, layer in ipairs(layers) do
        for _, key in ipairs(buttons) do
            local bind = find(layer, key)
            add(bind, layer, key)
            if bind and bind.kind == "wheel" and inside then
                wheels[#wheels + 1] = { binds = inside(bind), layer = layer, key = key }
            end
        end
    end
    for _, wheel in ipairs(wheels) do
        for _, bind in ipairs(wheel.binds) do
            add(bind, wheel.layer, wheel.key)
        end
    end
    return out
end

-- The lines of the list: each action that cools down. cooling[id] = { since = when it was first
-- seen cooling, ends = when it ends, or nil when the game does not tell }. fixed[id] is true for
-- an action that a fixed slot shows. The soonest end is on top. When the end of even one line is
-- not known, all are in the order they started: an end that is known cannot be put before or
-- after one that is not.
function Model.Lines(actions, cooling, fixed)
    local lines = {}
    for _, action in ipairs(actions) do
        if cooling[action.id] and not fixed[action.id] then
            lines[#lines + 1] = action
        end
    end
    local known = true
    for _, action in ipairs(lines) do
        known = known and cooling[action.id].ends ~= nil
    end
    table.sort(lines, function(a, b)
        local first, second = cooling[a.id], cooling[b.id]
        if known and first.ends ~= second.ends then
            return first.ends < second.ends
        elseif first.since ~= second.since then
            return first.since < second.since
        end
        return a.id < b.id
    end)
    for i = #lines, Model.MOST + 1, -1 do
        lines[i] = nil
    end
    return lines
end

-- Where the list's top left corner goes, for the frame's own scale: x and y are the rows List X
-- Position and List Y Position in units of the screen, size is the row List Size in percent. A
-- frame's place is counted in its own scale, so the two numbers are divided by it: the corner
-- stays where the rows put it at any size.
function Model.Place(x, y, size)
    local scale = size / 100
    return scale, x / scale, y / scale
end

if ns then
    ns.CooldownModel = Model
end
return Model
