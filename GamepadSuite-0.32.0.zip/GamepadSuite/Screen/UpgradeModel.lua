-- The rules of the upgrade arrows, with no game calls: when a piece of gear gets the green arrow.
-- One sentence for the player: gear you can wear that is better for your class than what you
-- wear in that place. Better means a higher score from its stats, weighed for the class
-- (Model.WEIGHTS); where a piece shows no stat that is weighed, a higher item level. The arrow
-- must never be plainly wrong, so it is left out where the numbers say too little:
--   the game says the character cannot use the item, or the item asks for a higher level;
--   the item has a use effect (most trinkets): its worth is the effect, not the numbers;
--   a weapon is compared with the same hand only: one hand against one hand, two hands against
--   two hands, and nothing for the off hand while a two-hand weapon is worn;
--   a weapon for the off hand needs a worn one to compare with (an empty off hand can mean that
--   the character cannot fight with two weapons);
--   armor of a lighter kind than the worn piece (cloth against leather) gets no arrow.
-- A ring or a trinket has two places: it is compared with the weaker of the two worn. So is a
-- one-hand weapon while a weapon is worn in the off hand (a character that fights with two). A
-- place with nothing in it makes anything that goes there better.
-- Gear for later (Model.Later): a piece held back by its level alone, better once the character
-- reaches that level, gets a dim arrow with the level.
-- The game knows an item's place, class and subclass at once. Its two levels and its stats come
-- only when the game has loaded the item: until then there is no arrow, and the third answer
-- says to wait.
local _, ns = ...

local Model = {}

-- The game's word for where an item goes -> the game's numbers of the places. A shirt, a
-- tabard, a bag and ammunition are not here: no arrow for them.
Model.PLACES = {
    INVTYPE_HEAD = { 1 }, INVTYPE_NECK = { 2 }, INVTYPE_SHOULDER = { 3 }, INVTYPE_CHEST = { 5 }, INVTYPE_ROBE = { 5 },
    INVTYPE_WAIST = { 6 }, INVTYPE_LEGS = { 7 }, INVTYPE_FEET = { 8 }, INVTYPE_WRIST = { 9 }, INVTYPE_HAND = { 10 },
    INVTYPE_FINGER = { 11, 12 }, INVTYPE_TRINKET = { 13, 14 }, INVTYPE_CLOAK = { 15 },
    INVTYPE_WEAPON = { 16 }, INVTYPE_WEAPONMAINHAND = { 16 }, INVTYPE_2HWEAPON = { 16 },
    INVTYPE_WEAPONOFFHAND = { 17 }, INVTYPE_SHIELD = { 17 }, INVTYPE_HOLDABLE = { 17 },
    INVTYPE_RANGED = { 18 }, INVTYPE_RANGEDRIGHT = { 18 }, INVTYPE_THROWN = { 18 }, INVTYPE_RELIC = { 18 },
}
local MAIN, OFF, RANGED, TWO_HAND, OFF_WEAPON = 16, 17, 18, "INVTYPE_2HWEAPON", "INVTYPE_WEAPONOFFHAND"
local ONE_HAND, BOTH_HANDS = "INVTYPE_WEAPON", { MAIN, OFF }
-- The game's number of the class Armor. Its subclasses 1 to 4 are cloth, leather, mail and
-- plate, the lightest first.
local ARMOR = 4

-- What each class gets from a point of each stat, as a ROUGH GUIDE for a character that levels,
-- in points of the class's main stat. Our own numbers, not measured: a stat that the class has no
-- use for is left out (0). str, agi, sta, int, spi: the five stats; ap, rap: attack power, melee
-- and ranged; sp, heal: spell damage and healing; armor: a point of armor; dps, rdps: a point of
-- a weapon's damage per second, for a melee weapon and for a ranged one (bow, gun, crossbow,
-- thrown, wand). Casters weigh a wand's damage and not a staff's.
-- Limit: one set for each class, so a hybrid weighs both of its sides (a paladin weighs
-- strength and intellect); this game gives addons no talent tree to pick a set by
-- (GetSpecialization is nil on Forever). Crit, hit and regeneration are not weighed: their unit
-- on this client is not known yet (the log names them).
Model.WEIGHTS = {
    WARRIOR = { str = 1, agi = 0.5, sta = 0.5, ap = 0.5, dps = 5, rdps = 0.5, armor = 0.02 },
    ROGUE = { agi = 1, str = 0.5, sta = 0.4, ap = 0.5, dps = 5, rdps = 0.5, armor = 0.01 },
    HUNTER = { agi = 1, sta = 0.4, int = 0.3, spi = 0.1, ap = 0.2, rap = 0.5, dps = 1, rdps = 5, armor = 0.01 },
    MAGE = { int = 1, spi = 0.6, sta = 0.4, sp = 1, rdps = 2, armor = 0.005 },
    WARLOCK = { int = 0.8, spi = 0.5, sta = 0.7, sp = 1, rdps = 2, armor = 0.005 },
    PRIEST = { int = 1, spi = 0.8, sta = 0.4, sp = 0.8, heal = 0.6, rdps = 2, armor = 0.005 },
    PALADIN = { str = 1, int = 0.6, sta = 0.5, agi = 0.3, spi = 0.2, ap = 0.4, sp = 0.3, heal = 0.3, dps = 4, armor = 0.02 },
    SHAMAN = { str = 0.8, int = 0.8, agi = 0.5, sta = 0.5, spi = 0.3, ap = 0.4, sp = 0.6, heal = 0.4, dps = 4, armor = 0.015 },
    DRUID = { agi = 0.8, str = 0.8, int = 0.7, sta = 0.5, spi = 0.5, ap = 0.4, sp = 0.6, heal = 0.4, dps = 0.5, armor = 0.02 },
}
-- A score must be this much higher to be clearly better: 5 %, and at least half a point. A score
-- that is higher by less lets the item level decide.
local SHARE, LEAST = 0.05, 0.5

local function weight(piece)
    return piece.class == ARMOR and piece.sub >= 1 and piece.sub <= 4 and piece.sub or nil
end

-- A number for the log, with one decimal at most.
local function num(x)
    return ("%g"):format(math.floor(x * 10 + 0.5) / 10)
end

-- The score of a piece with stats (our short names -> amounts) for a class's weights.
function Model.Score(piece, weights)
    local score = 0
    for stat, amount in pairs(piece.stats) do
        if stat == "dps" and Model.PLACES[piece.place] and Model.PLACES[piece.place][1] == RANGED then
            stat = "rdps"
        end
        score = score + amount * (weights[stat] or 0)
    end
    return score
end

-- item: place (the game's word), class, sub, level (the item level), needs (the level it asks
-- for), wearable (the game's answer: the character can use it), use (it has a use effect),
-- stats (our short names -> amounts, nil when it shows no stat that is weighed).
-- worn: the game's place number -> what is worn there, with the same fields; nothing for an
-- empty place. level: the character's level. weights: the class's (Model.WEIGHTS), or nil for
-- the item level alone.
-- Returns true for an arrow, the reason in a few words for the log, true as the third answer
-- when the game has not loaded an item yet and the answer can change, and with an arrow the
-- place it was compared with: the empty one, or the weaker of two (Screen/WearReward.lua puts
-- the piece there).
function Model.Better(item, worn, level, weights)
    local places = Model.PLACES[item.place]
    if not places then
        return false, "no place that counts"
    elseif item.level == nil or item.needs == nil then
        return false, "the game has not loaded it", true
    elseif item.use then
        return false, "it has a use effect"
    elseif not item.wearable then
        return false, "the game says the character cannot use it"
    elseif item.needs > level then
        return false, "it asks for level " .. item.needs
    end
    local main, off = worn[MAIN], worn[OFF]
    local two = main ~= nil and main.place == TWO_HAND
    if places[1] >= MAIN and places[1] <= OFF and main and main.level == nil then
        return false, "the game has not loaded the worn weapon", true
    elseif places[1] == MAIN and main and (item.place == TWO_HAND) ~= two then
        return false, "one hand against two hands"
    elseif places[1] == OFF and two then
        return false, "a two-hand weapon is worn"
    elseif item.place == ONE_HAND and off and (off.place == ONE_HAND or off.place == OFF_WEAPON) then
        places = BOTH_HANDS
    end
    for _, place in ipairs(places) do
        if not worn[place] then
            if item.place == OFF_WEAPON then
                return false, "no weapon in the off hand to compare with"
            end
            return true, "the place is empty", nil, place
        end
    end
    for _, place in ipairs(places) do
        if worn[place].level == nil then
            return false, "the game has not loaded the worn item", true
        end
    end
    -- by the class's stats only when every piece shows some; the worn piece to beat is the weaker
    local byStats = weights ~= nil and item.stats ~= nil
    for _, place in ipairs(places) do
        byStats = byStats and worn[place].stats ~= nil
    end
    local function worth(piece)
        return byStats and Model.Score(piece, weights) or piece.level
    end
    local lowest, at
    for _, place in ipairs(places) do
        if not lowest or worth(worn[place]) < worth(lowest) then
            lowest, at = worn[place], place
        end
    end
    local why = "item level " .. item.level .. " against " .. lowest.level
    if byStats then
        local new, old = worth(item), worth(lowest)
        if new < old then
            return false, "class stats " .. num(new) .. " against " .. num(old)
        elseif new > old + math.max(LEAST, old * SHARE) then
            why = "class stats " .. num(new) .. " against " .. num(old)
        elseif item.level <= lowest.level then
            return false, "class stats near, " .. why
        else
            why = "class stats near, " .. why
        end
    elseif item.level <= lowest.level then
        return false, why
    end
    if weight(item) and weight(lowest) and weight(item) < weight(lowest) then
        return false, "a lighter kind of armor than the worn piece"
    end
    return true, why, nil, at
end

-- Gear for later: the level an item asks for, when that level is the one reason it gets no
-- arrow: the game's only "no" to it is that level (item.soon, Core/AdapterUpgrade.lua), and at
-- that level the rule above gives it the arrow. Then the reason at that level, for the log.
-- nil for any other item.
function Model.Later(item, worn, level, weights)
    if item.needs and item.needs > level and (item.wearable or item.soon) then
        local better, why = Model.Better(setmetatable({ wearable = true }, { __index = item }), worn, item.needs, weights)
        if better then
            return item.needs, why
        end
    end
end

if ns then
    ns.UpgradeModel = Model
end
return Model
