-- The right side of the dialogue view: the list of a gossip, the rewards of a quest, and the
-- objectives of a quest in progress. Screen/DialogueDraw.lua makes the rest and calls
-- Side.Build. Sizes are in the units of the sample sheet (mockups/dialogue_sample.py); the
-- places in the comments are from the top left corner of the block.
local _, ns = ...

local Theme, Widgets, Model = ns.Theme, ns.Widgets, ns.DialogueModel
local px = Theme.px

local Side = {}
ns.DialogueSide = Side

local ARROW = "Interface\\Buttons\\Arrow-Down-Up"
local SHORT = { 0.94, 0.44, 0.36 }   -- the red of a count that is too low: the B button's letter
local UNUSABLE = { 0.9, 0.25, 0.25 } -- the tint of an item that the character cannot use
local LIST_X, GAIN_X = 864, 824      -- the list of a gossip; the right column of a quest
local ui = {}
local rows, tiles, goals = {}, {}, {}
local shown, compact = {}, false     -- the items the rewards show now, and if they are pictures only
local top = 1                        -- the row of the list that shows first

-- A left click on row or item n: Screen/DialogueInput.lua (loaded later) takes it. A right
-- click does nothing, as on the rows of the game's own gossip window.
local function clicks(button, n)
    button:RegisterForClicks("LeftButtonUp")
    button:SetScript("OnClick", function(_, mouse)
        if mouse == "LeftButton" then
            ns.DialogueInput.Click(n())
        end
    end)
end

local function place(region, parent, x, y)
    region:ClearAllPoints()
    region:SetPoint("TOPLEFT", parent, "TOPLEFT", px(x), -px(y))
    return region
end

-- parent: the frame of all that is at the right of the portrait. at(region, x, y) puts a region
-- at a place of the block. thin: the size of a line of one unit. corner: the place of a tooltip.
function Side.Build(parent, at, thin, corner)
    ui.corner = corner
    ui.split = at(Theme.Fill(parent, "ARTWORK", Theme.Color("cream", 0.14)), LIST_X - 18, 4)
    ui.split:SetSize(thin, px(200))
    ui.list = at(CreateFrame("Frame", nil, parent), LIST_X, 0)
    ui.list:SetSize(px(536), px(Model.ROWS * 40))
    -- the mouse wheel moves the focus as the D-pad does, so a row under the first five can be clicked
    ui.list:EnableMouseWheel(true)
    ui.list:SetScript("OnMouseWheel", function(_, delta)
        ns.DialogueInput.Key(delta > 0 and "DU" or "DD")
    end)
    -- rows hide over the list's top or under its foot: the game's small arrow says so
    for name, up in pairs({ up = true, down = false }) do
        local arrow = ui.list:CreateTexture(nil, "OVERLAY")
        arrow:SetTexture(ARROW)
        arrow:SetSize(px(16), px(16))
        arrow:SetPoint(up and "TOPRIGHT" or "BOTTOMRIGHT")
        if up then
            arrow:SetTexCoord(0, 1, 1, 0)
        end
        ui[name] = arrow
    end

    ui.gain = at(CreateFrame("Frame", nil, parent), GAIN_X, 0)
    ui.gain:SetSize(px(576), px(208))
    -- the rewards: money and experience, and one label, over the items to choose from
    ui.money = place(Theme.Text(ui.gain, "name", "cream"), ui.gain, 0, 0)
    ui.rest = Theme.Text(ui.gain, "name", "cream")
    ui.pick = Theme.Text(ui.gain, "body", "muted")
    ui.bar = Theme.Fill(ui.gain, "ARTWORK", Theme.Color("cream", 0.14))
    ui.bar:SetSize(thin, px(152))
    -- with more than four items the pictures have no names: the item with the focus has its name here
    ui.one = place(Theme.Text(ui.gain, "name", "cream"), ui.gain, 0, 150)
    ui.one:SetWidth(px(576))
    -- a quest in progress
    ui.head = place(Theme.Text(ui.gain, "body", "muted"), ui.gain, 0, 0)
    ui.head:SetText("Objectives")
end

-- ---------------------------------------------------------------- the list of a gossip

local function row(n)
    if not rows[n] then
        local r = CreateFrame("Button", nil, ui.list)
        clicks(r, function() return top + n - 1 end)
        r:SetSize(px(536), px(40))
        r:SetPoint("TOPLEFT", 0, -px((n - 1) * 40))
        -- the focus is the row light of the settings window: the game's row light, added, and a gold bar
        r.light = r:CreateTexture(nil, "BACKGROUND")
        r.light:SetTexture(Theme.art.rowLight)
        r.light:SetBlendMode("ADD")
        r.light:SetAlpha(0.42)
        r.light:SetAllPoints()
        r.bar = Theme.Fill(r, "ARTWORK", Theme.Color("gold"))
        r.bar:SetWidth(px(3))
        r.bar:SetPoint("TOPLEFT", 0, -px(7))
        r.bar:SetPoint("BOTTOMLEFT", 0, px(7))
        r.icon = r:CreateTexture(nil, "ARTWORK")
        r.icon:SetPoint("LEFT", px(14), 0)
        r.text = Theme.Text(r, "name", "cream")
        r.text:SetPoint("LEFT", px(46), 0)
        r.text:SetWidth(px(478))
        rows[n] = r
    end
    return rows[n]
end

local function list(state)
    local data = state.data.rows
    top = state.top
    for n = 1, Model.ROWS do
        local at = state.top + n - 1
        local item = data[at]
        if item then
            local r = row(n)
            ns.Adapter.DialogueRowArt(r.icon, item)
            r.icon:SetSize(px(20), px(20))
            r.text:SetText(item.head or item.text)
            r.text:SetTextColor(Theme.Color(at == state.focus and "white" or item.off and "dim" or item.dim and "muted" or "cream"))
            r.light:SetShown(at == state.focus)
            r.bar:SetShown(at == state.focus)
            r:Show()
        elseif rows[n] then
            rows[n]:Hide()
        end
    end
    ui.up:SetShown(state.top > 1)
    ui.down:SetShown(state.top + Model.ROWS - 1 < #data)
end

-- ---------------------------------------------------------------- the rewards of a quest

-- The mark of each item, as in the bags (Screen/Upgrades.lua Judge): true for the arrow, a
-- level for the dim arrow of gear for later, false for none. None while the row Gear Upgrade
-- Indicator is off, and on a game build without that feature.
local function arrows(items)
    local A, judge, out = ns.Adapter, ns.Upgrades and ns.Upgrades.Judge, {}
    if judge and A.Results().upgrades then
        local worn, level = A.WornGear(), A.CharacterLevel()
        for n, item in ipairs(items) do
            local gear = item.link and A.Gear(item.link)
            out[n] = gear and judge(gear, worn, level) or false
        end
    end
    return out
end

local function tile(n)
    if not tiles[n] then
        local t = CreateFrame("Button", nil, ui.gain)
        clicks(t, function() return n end)
        -- the focus: a gold light behind the item, and a gold line of two units round it, inside its edge
        t.back = Theme.Fill(t, "BACKGROUND", Theme.Color("gold", 0.2))
        t.back:SetAllPoints()
        t.ring = {}
        for i, side in ipairs({ { "TOPLEFT", "TOPRIGHT" }, { "BOTTOMLEFT", "BOTTOMRIGHT" }, { "TOPLEFT", "BOTTOMLEFT" }, { "TOPRIGHT", "BOTTOMRIGHT" } }) do
            t.ring[i] = Theme.Fill(t, "BORDER", Theme.Color("gold"))
            t.ring[i]:SetPoint(side[1])
            t.ring[i]:SetPoint(side[2])
            t.ring[i]:SetSize(px(2), px(2))
        end
        t.box = Widgets.Icon(t, px(64))
        t.box:SetPoint("TOP", 0, -px(6))
        t.count = t.box:CreateFontString(nil, "OVERLAY")
        t.count:SetFont(Theme.font.text, px(Theme.size.row), "OUTLINE")
        t.count:SetTextColor(1, 1, 1)
        t.count:SetPoint("BOTTOMRIGHT", -px(4), px(2))
        t.arrow = t.box:CreateTexture(nil, "OVERLAY")
        if ns.Adapter.UpgradeArt then
            ns.Adapter.UpgradeArt(t.arrow)
        end
        t.arrow:SetSize(px(20), px(21))
        t.arrow:ClearAllPoints()
        t.arrow:SetPoint("TOPLEFT", px(3), -px(3))
        t.later = t.box:CreateFontString(nil, "OVERLAY")
        t.later:SetFont(Theme.font.text, px(Theme.size.tiny), "OUTLINE")
        t.later:SetTextColor(Theme.Color("white"))
        t.later:SetPoint("LEFT", t.arrow, "RIGHT", px(1), 0)
        t.name = Theme.Text(t, "row", "cream")
        t.name:SetPoint("TOP", t.box, "BOTTOM", 0, -px(8))
        t.name:SetWidth(px(124))
        t.name:SetSpacing(px(4))
        t.name:SetJustifyH("CENTER")
        t.name:SetWordWrap(true)
        t.name:SetMaxLines(2)
        tiles[n] = t
    end
    return tiles[n]
end

-- The edge of an item's picture: the game's color of its quality for a green item or better,
-- kept soft so the gold of the focus is the one strong color; with the focus a black line and
-- full gold, one unit wider.
local function edge(t, item, focus)
    local grow = px(focus and 3 or 2)
    t.box.edge:ClearAllPoints()
    t.box.edge:SetPoint("TOPLEFT", -grow, grow)
    t.box.edge:SetPoint("BOTTOMRIGHT", grow, -grow)
    t.box:SetIcon(item.icon, focus)
    -- an item that the character cannot use has a red tint, as in the game's own window
    if item.unusable then
        t.box.art:SetVertexColor(UNUSABLE[1], UNUSABLE[2], UNUSABLE[3])
    else
        t.box.art:SetVertexColor(1, 1, 1)
    end
    local r, g, b = ns.Adapter.DialogueQuality(item.quality)
    if r and not focus then
        t.box.edge:SetColorTexture(r, g, b, 0.45)
    end
end

-- Money and experience on one line. Under it the item you get for sure, a thin line, and the
-- items to choose from under their one label. More than four items: pictures only.
local function rewards(state)
    local data = state.data
    local _, _, fixed = Model.Span(state)
    local choices = math.min(#data.choices, Model.TILES)
    shown = {}
    for n = 1, fixed + choices do
        shown[n] = n > fixed and data.choices[n - fixed] or data.fixed[n]
    end
    compact = #shown > 4
    local step = compact and 72 or 142
    -- the items to choose from start after the thin line, when there is an item for sure
    local gap = not compact and fixed > 0 and choices > 0 and 11 or 0
    local better = arrows(shown)

    local coins = data.money > 0 and ns.Adapter.CoinText(data.money) or ""
    local rest = { data.xp > 0 and ns.Adapter.DialogueNumber(data.xp) .. " experience" or nil }
    for _, words in ipairs(data.more) do
        rest[#rest + 1] = words
    end
    ui.money:SetText(coins)
    ui.rest:SetText(table.concat(rest, "   "))
    ui.rest:ClearAllPoints()
    ui.rest:SetPoint("LEFT", ui.money, coins ~= "" and "RIGHT" or "LEFT", coins ~= "" and px(30) or 0, 0)
    ui.pick:SetShown(choices > 0)
    ui.pick:SetText(state.kind == "handin" and "Choose one" or "And one of these")
    place(ui.pick, ui.gain, fixed * step + gap + 4, 40)
    ui.bar:SetShown(fixed > 0 and choices > 0)
    place(ui.bar, ui.gain, fixed * step + (compact and -4 or 0), 40)

    for n = 1, math.max(#shown, #tiles) do
        local item = shown[n]
        if item then
            local t = tile(n)
            place(t, ui.gain, (n - 1) * step + (n > fixed and gap or 0), 64)
            t:SetSize(px(compact and 68 or 132), px(compact and 76 or 128))
            t.count:SetText(item.count > 1 and item.count or "")
            t.arrow:SetShown(better[n] and true or false)
            local later = type(better[n]) == "number" and better[n] or nil
            if ns.Upgrades then
                ns.Upgrades.Later(t.arrow, t.later, later)
            end
            t.name:SetShown(not compact)
            t.name:SetText(item.name)
            t:Show()
        else
            tiles[n]:Hide()
        end
    end
end

-- ---------------------------------------------------------------- the objectives of a quest in progress

local function goal(n)
    if not goals[n] then
        local r = CreateFrame("Frame", nil, ui.gain)
        r.box = Widgets.Icon(r, px(52))
        r.box:SetPoint("CENTER")
        -- an objective that is no item has a small square mark in the picture's place
        r.mark = Theme.Fill(r, "ARTWORK", Theme.Color("goldDeep"))
        r.mark:SetSize(px(10), px(10))
        r.mark:SetPoint("CENTER")
        r.name = Theme.Text(r, "talk", "cream")
        r.name:SetPoint("LEFT", r, "RIGHT", px(18), 0)
        r.count = Theme.Text(r, "talk", "cream")
        r.count:SetPoint("LEFT", r.name, "RIGHT", px(22), 0)
        goals[n] = r
    end
    return goals[n]
end

-- A row for each objective (Model.Goals): the picture of a needed item or a mark, the name
-- (dim when the objective is done), and "2 of 6", red while the player has too few. Money that
-- the quest needs is a row with the coins. Four rows are smaller. A name is one line: one too
-- long for the column with its count gets the room that is left, and the game cuts it with dots.
local function objectives(state)
    local tight = state.tight
    local high, pic, size = tight and 44 or 56, tight and 40 or 52, tight and Theme.size.name or Theme.size.talk
    for n = 1, math.max(#state.goals, #goals) do
        local item = state.goals[n]
        if item then
            local r = goal(n)
            r:SetSize(px(pic), px(pic))
            place(r, ui.gain, 2, 30 + (n - 1) * high + (high - pic) / 2)
            r.box:SetSize(px(pic), px(pic))
            r.box:SetShown(item.icon ~= nil)
            r.box:SetIcon(item.icon)
            r.mark:SetShown(item.icon == nil and not item.coins)
            r.name:SetFont(Theme.font.text, px(size), "")
            r.name:SetText(item.name)
            r.done = item.done
            r.name:SetTextColor(Theme.Color(item.done and "muted" or "cream"))
            r.count:SetFont(Theme.font.text, px(size), "")
            r.count:SetText(item.coins and "" or (item.have .. " of " .. item.need))
            -- the column is 576 wide: the picture's place and 18, the name, 22, the count
            local room = px(576 - 2 - pic - 18 - 22) - r.count:GetStringWidth()
            r.name:SetWidth(0)
            if r.name:GetStringWidth() > room then
                r.name:SetWidth(room)
            end
            if item.coins or item.have >= item.need then
                r.count:SetTextColor(Theme.Color("cream"))
            else
                r.count:SetTextColor(SHORT[1], SHORT[2], SHORT[3])
            end
            r:Show()
        else
            goals[n]:Hide()
        end
    end
end

-- ---------------------------------------------------------------- what the view calls

-- Draws the side of the part in view (Model.View). Returns what Side.Focus returns.
function Side.Show(state, view)
    local side = view.side
    ui.split:SetShown(side == "list")
    ui.list:SetShown(side == "list")
    ui.gain:SetShown(side == "rewards" or side == "goals")
    for _, part in ipairs({ ui.money, ui.rest, ui.pick, ui.bar, ui.one }) do
        part:SetShown(side == "rewards")
    end
    ui.head:SetShown(side == "goals")
    for _, frames in ipairs({ side ~= "rewards" and tiles or {}, side ~= "goals" and goals or {} }) do
        for _, frame in ipairs(frames) do
            frame:Hide()
        end
    end
    shown = {}
    if side == "rewards" then
        rewards(state)
    elseif side == "goals" then
        objectives(state)
    end
    return Side.Focus(state)
end

-- The focus moved: the list or the rewards show it. The reward with the focus has the game's
-- tooltip over the band. Returns a few words about the tooltip for the log, or nil for none.
function Side.Focus(state)
    if state.kind == "gossip" then
        list(state)
        return nil
    end
    local last = state.part == state.count and not state.confirm
    for n, item in ipairs(shown) do
        local focus = last and n == state.focus
        tiles[n].back:SetShown(focus)
        for _, line in ipairs(tiles[n].ring) do
            line:SetShown(focus)
        end
        tiles[n].name:SetTextColor(Theme.Color(focus and "white" or "cream"))
        edge(tiles[n], item, focus)
    end
    local item = last and shown[state.focus]
    ui.one:SetShown(compact and item and true or false)
    ui.one:SetText(item and item.name or "")
    if not item then
        ns.Adapter.DialogueTipHide()
        return nil
    end
    local up, words = ns.Adapter.DialogueTip(item, ui.corner)
    return "the tooltip of " .. item.kind .. " " .. item.index .. (up and " shows, " or " does not show: ") .. tostring(words)
end

-- A press of A that cannot act (on) and 0.2 seconds after it (off): at a hand-in the label
-- "Choose one" lights up, in a quest in progress the names of the objectives that are not done.
function Side.Sign(state, on)
    ui.pick:SetTextColor(Theme.Color(on and state.kind == "handin" and "gold" or "muted"))
    for _, r in ipairs(goals) do
        r.name:SetTextColor(Theme.Color(r.done and "muted" or on and state.kind == "progress" and "gold" or "cream"))
    end
end
