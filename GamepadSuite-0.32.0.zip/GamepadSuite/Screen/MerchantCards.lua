-- The cards of the merchant view: ten to a page, five to a row and two rows, under the tabs row,
-- with a page control at each side while there is a page that way. Screen/MerchantDraw.lua makes
-- the rest and calls Cards.Build. A card: the item's picture in the suite's picture box (its count,
-- the vendor's stock as "2 left", the junk coin, or the game's yellow mark of an item that starts a
-- quest over it), the name in two lines at most, and under it the price. A thing in the bags that
-- holds things (a clam) says so in gold in the place of the price, and its name keeps one line. A card has a faint ground and a faint line round it, so it reads on a dark world
-- too; the focus is the dialogue view's: a gold light behind it and a gold line of two units round
-- it. A page control is the settings window's: the spellbook's page arrow with a soft gold glow
-- (Widgets.Nav), on a plate as tall as the two rows. Sizes are in the units of the sample sheet
-- (mockups/merchant_sample.py); places are from the top left corner of the block.
local _, ns = ...

local Theme, Widgets, Model = ns.Theme, ns.Widgets, ns.MerchantModel
local px = Theme.px

local Cards = {}
ns.MerchantCards = Cards

local CARD_W, CARD_H, GAP, CARDS_Y = 200, 78, 8, 44   -- a card, the room between two, the first row's top
local PAGE_W, PAGE_GAP, ARROW = 36, 4, 32              -- a page control at each side of the cards, the room to the cards, its arrow
local PIC, PAD, TEXT_GAP = 56, 11, 12                  -- the picture, its room from the card's edge, the room before the words
local NAME_Y, NAME_LEAD, PRICE_Y = 6, 20, 7            -- the name's top and its line (two lines end at 46), the price over the card's foot
local GROUND, EDGE = 0.07, 0.14                        -- the strength of a card's cream ground and of its faint line
local SHORT = { 0.94, 0.44, 0.36 }    -- the red of a price the player cannot pay: the dialogue view's short count
local UNUSABLE = { 0.9, 0.25, 0.25 }  -- the red of an item the character cannot use or buy (picture and name): the dialogue view's
local HOLDS = "Holds things. Open it first."   -- a thing in the bags that holds loot (17_MASTERCLASS.md item 16)
local ui = {}
local cards = {}
local held                            -- the card whose hold line shows

-- A plate with the faint ground, its line round it (faint, or gold for the focus) and the gold light
-- of the focus behind it.
local function plate(frame)
    frame.plate = Theme.Fill(frame, "BACKGROUND", Theme.Color("cream", GROUND))
    frame.plate:SetAllPoints()
    frame.back = Theme.Fill(frame, "BACKGROUND", Theme.Color("gold", 0.2))
    frame.back:SetAllPoints()
    frame.ring = {}
    for i, side in ipairs({ { "TOPLEFT", "TOPRIGHT" }, { "BOTTOMLEFT", "BOTTOMRIGHT" }, { "TOPLEFT", "BOTTOMLEFT" }, { "TOPRIGHT", "BOTTOMRIGHT" } }) do
        frame.ring[i] = Theme.Fill(frame, "BORDER", 1, 1, 1, 1)
        frame.ring[i]:SetPoint(side[1])
        frame.ring[i]:SetPoint(side[2])
    end
end

local function lit(frame, focus)
    frame.back:SetShown(focus)
    local size = focus and px(2) or ui.thin
    for _, line in ipairs(frame.ring) do
        line:SetColorTexture(Theme.Color(focus and "gold" or "cream", focus and 1 or EDGE))
        line:SetSize(size, size)
    end
end

local function card(n)
    if cards[n] then
        return cards[n]
    end
    local c = CreateFrame("Button", nil, ui.area)
    c:SetSize(px(CARD_W), px(CARD_H))
    local col, row = (n - 1) % Model.COLS, math.floor((n - 1) / Model.COLS)
    c:SetPoint("TOPLEFT", ui.area, "TOPLEFT", px(col * (CARD_W + GAP)), -px(row * (CARD_H + GAP)))
    -- a left click puts the focus on the card, a second one does what A does (Screen/MerchantInput.lua)
    c:RegisterForClicks("LeftButtonUp")
    c:SetScript("OnClick", function(_, mouse)
        if mouse == "LeftButton" then
            ns.MerchantInput.Click(n)
        end
    end)
    plate(c)
    c.box = Widgets.Icon(c, px(PIC))
    c.box:SetPoint("LEFT", px(PAD), 0)
    c.count = c.box:CreateFontString(nil, "OVERLAY")
    c.count:SetFont(Theme.font.text, px(Theme.size.row), "OUTLINE")
    c.count:SetPoint("BOTTOMRIGHT", -px(3), px(2))
    c.stock = c.box:CreateFontString(nil, "OVERLAY")
    c.stock:SetFont(Theme.font.text, px(Theme.size.small), "OUTLINE")
    c.stock:SetPoint("TOPLEFT", px(3), -px(3))
    c.coin = c.box:CreateTexture(nil, "OVERLAY")
    c.coin:SetPoint("TOPRIGHT")
    pcall(ns.Adapter.JunkCoin, c.coin)
    -- the game's yellow mark over the whole picture, as its vendor window has it (MerchantFrame.xml 37 to 41)
    c.bang = c.box:CreateTexture(nil, "OVERLAY")
    c.bang:SetAllPoints()
    pcall(ns.Adapter.QuestBang, c.bang)
    local x = PAD + PIC + TEXT_GAP
    c.name = Theme.Text(c, "row", "cream")
    c.name:SetPoint("TOPLEFT", px(x), -px(NAME_Y))
    c.name:SetWidth(px(CARD_W - x - 8))
    c.name:SetWordWrap(true)
    c.name:SetMaxLines(2)
    c.name:SetSpacing(px(NAME_LEAD - Theme.size.row))
    c.price = Theme.Text(c, "body", "cream")
    c.price:SetPoint("BOTTOMLEFT", px(x), px(PRICE_Y))
    c.price:SetWidth(px(CARD_W - x - 8))
    c.price:SetWordWrap(true)
    c.price:SetMaxLines(2)
    c.hold = Widgets.HoldLine(c, 4)
    cards[n] = c
    return c
end

-- A page control (way "back" or "next") at x of the block: a click turns the page.
local function control(parent, at, x, way)
    local page = at(CreateFrame("Button", nil, parent), x, CARDS_Y)
    page:SetSize(px(PAGE_W), px(Model.ROWS * (CARD_H + GAP) - GAP))
    plate(page)
    page.nav = Widgets.Nav(page)
    page.nav:ClearAllPoints()
    page.nav:SetPoint("CENTER")
    page.nav:SetSize(px(ARROW), px(ARROW))
    page.nav:Set(way)
    page:RegisterForClicks("LeftButtonUp")
    page:SetScript("OnClick", function(_, mouse)
        if mouse == "LeftButton" then
            ns.MerchantInput.Page(way)
        end
    end)
    page:Hide()
    return page
end

-- parent: the frame of all at the right of the portrait. at(region, x, y): a place of the block.
-- left: where the page control Back stands; the cards start after it. thin: a line of one unit.
function Cards.Build(parent, at, left, thin)
    ui.thin = thin
    -- the frame of the cards: the mouse wheel over it turns the page too
    ui.area = at(CreateFrame("Frame", nil, parent), left + PAGE_W + PAGE_GAP, CARDS_Y)
    ui.area:SetSize(px(Model.COLS * (CARD_W + GAP) - GAP), px(Model.ROWS * (CARD_H + GAP) - GAP))
    ui.area:EnableMouseWheel(true)
    ui.area:SetScript("OnMouseWheel", function(_, delta)
        ns.MerchantInput.Wheel(delta)
    end)
    ui.empty = Theme.Text(ui.area, "name", "muted")
    ui.empty:SetPoint("CENTER")
    ui.back = control(parent, at, left, "back")
    ui.next = control(parent, at, left + PAGE_W + 2 * PAGE_GAP + Model.COLS * (CARD_W + GAP) - GAP, "next")
end

-- The price line of a card: gold in the game's coin pictures, and each extra cost with its
-- picture. A thing in the bags shows what the whole stack brings; nothing while the game has not
-- loaded its price.
local function price(entry, tab, coins)
    if tab == "sell" then
        return entry.price and entry.price > 0 and coins(entry.price * entry.count) or ""
    end
    local parts = { entry.price > 0 and coins(entry.price) or nil }
    for _, cost in ipairs(entry.costs or {}) do
        parts[#parts + 1] = cost.value .. " |T" .. tostring(cost.icon) .. ":0|t"
    end
    return table.concat(parts, "  ")
end

-- One card: the entry (a thing of the tab's list), with the focus or not. An item the character
-- cannot use or buy is red, its picture and its name, as the game's own vendor window tints it
-- (Mainline/MerchantFrame.lua 369 to 397).
local function fill(c, entry, s, focus, coins)
    local soldOut = s.tab == "buy" and entry.left == 0
    c.box:SetIcon(entry.icon, focus)
    c.box:SetStrength(soldOut and 0.5 or 1, soldOut)
    local red = entry.usable == false or entry.buyable == false
    c.box.art:SetVertexColor(red and UNUSABLE[1] or 1, red and UNUSABLE[2] or 1, red and UNUSABLE[3] or 1)
    -- the edge of the picture: the game's color of its quality for a green item or better, kept
    -- soft; with the focus full gold, one unit wider
    local grow = px(focus and 3 or 2)
    c.box.edge:ClearAllPoints()
    c.box.edge:SetPoint("TOPLEFT", -grow, grow)
    c.box.edge:SetPoint("BOTTOMRIGHT", grow, -grow)
    local r, g, b = ns.Adapter.DialogueQuality(entry.quality)
    if r and not focus then
        c.box.edge:SetColorTexture(r, g, b, 0.45)
    end
    local count = s.tab == "buy" and entry.lot or entry.count or 1
    c.count:SetText(count > 1 and count or "")
    c.stock:SetText(s.tab == "buy" and entry.left > 0 and entry.left .. " left" or "")
    c.coin:SetShown(s.tab == "sell" and entry.junk or false)
    c.bang:SetShown(s.tab == "buy" and entry.questStart or false)
    local loot = s.tab == "sell" and entry.hasLoot
    c.name:SetMaxLines(loot and 1 or 2)
    c.name:SetText(entry.name)
    if red then
        c.name:SetTextColor(UNUSABLE[1], UNUSABLE[2], UNUSABLE[3])
    else
        c.name:SetTextColor(Theme.Color(focus and "white" or soldOut and "muted" or "cream"))
    end
    c.price:SetText(loot and HOLDS or price(entry, s.tab, coins))
    if loot then
        c.price:SetTextColor(Theme.Color("gold"))
    elseif Model.Short(s, entry) then
        c.price:SetTextColor(SHORT[1], SHORT[2], SHORT[3])
    else
        c.price:SetTextColor(Theme.Color("cream"))
    end
    lit(c, focus)
end

-- Draws the page in view of the tab in view, its page controls, and the game's tooltip of the card
-- in focus over the band (corner: its place). Returns a few words about the tooltip for the log.
function Cards.Show(s, coins, corner)
    local list, focus = s.lists[s.tab], not s.edge and s.at[s.tab]
    local _, _, first = Model.Page(s)
    for n = 1, math.max(Model.PER, #cards) do
        local entry = list[first + n - 1]
        if entry and n <= Model.PER then
            local c = card(n)
            fill(c, entry, s, first + n - 1 == focus, coins)
            c:Show()
        elseif cards[n] then
            cards[n]:Hide()
        end
    end
    local back, after = Model.Edges(s)
    for page, way in pairs({ [ui.back] = back and "back", [ui.next] = after and "next" }) do
        page:SetShown(way ~= false)
        lit(page, s.edge ~= nil and s.edge == way)
    end
    ui.empty:SetShown(#list == 0)
    ui.empty:SetText(Model.EMPTY[s.tab])
    Cards.Hold(0)
    local entry = Model.Focus(s)
    if not entry then
        ns.Adapter.MerchantTipHide()
        return s.edge and "the page control " .. s.edge .. " has the focus" or "no card in focus"
    end
    local up = ns.Adapter.MerchantTip(entry, s.tab, corner)
    return "the tooltip of " .. s.tab .. " card " .. s.at[s.tab] .. (up and " shows" or " does not show")
end

-- The thin gold line of a hold of A, along the foot of card n of the page: part 0 to 1.
function Cards.Hold(part, n)
    local now = part > 0 and n and cards[n] or nil
    if held and held ~= now then
        held.hold:SetPart(0)
    end
    held = now
    if held then
        held.hold:SetPart(part)
    end
end
