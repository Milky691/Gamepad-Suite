-- The panel of the on-screen keyboard: its frames, and what they show. What the buttons do is in
-- Screen/Keyboard.lua. The panel is dark with a thin gold edge, at the bottom middle of the
-- screen. It has a top line with what the text is for and the text so far, five rows of ten
-- keys with a gold light on the key in focus, and the hints for the controller's buttons in the
-- strip of every part (Widgets.Legend).
-- A chat line has two rows more: up to three word guesses over the keys, and the channel row under
-- them; and a list of whisper names beside the panel, while Whisper is picked.
-- Each part is drawn again only when it changed: the keys when LT goes down or up, the light
-- when the focus moves, the top line and the guesses when a letter comes or goes, the hints when
-- the panel opens or the whisper list opens or closes.
local _, ns = ...

local Theme, Model = ns.Theme, ns.KeyboardModel
local px = Theme.px

local Draw = {}
ns.KeyboardDraw = Draw

-- sizes in the units of the settings window's mockup (a 1600 x 900 screen)
local KEY_W, KEY_H, GAP, EDGE, LINE, HINT = 60, 46, 6, 20, 44, 34
local WIDTH = Model.COLS * KEY_W + (Model.COLS - 1) * GAP
local ROW = 34                     -- the row of guesses and the channel row
local GUESSES, CHIPS = 3, 16       -- the most guesses and the most chips of the channel row
local CHIP_MIN, CHIP_PAD = 56, 20  -- a chip is as wide as its word and this much more, and never less
local UNDER = 8                    -- the gold line under the chip in use stops this far from the chip's sides
local KEYS = Model.ROWS * (KEY_H + GAP)
local LIST_W, NAME_H, HEAD = 250, 28, 34
-- A button and its word: on a text that is asked for, on a chat line, and in the whisper list. No
-- word: no hint there. RB's hint shows only while Word Guess is on, LB's only where the game has
-- voice to text (Screen/KeyboardVoice.lua). B closes the keyboard (the text is not used), and in
-- the whisper list goes back to the keys. On a chat line the hints stand in two rows (the owner: "use
-- guess, send and close coming off the chat screen ... making it rows"): typing above, low the rest.
local HINTS = {
    { "A", "Type", "Type", "Pick" }, { "X", "Delete", "Delete" }, { "Y", "Space", "Space" },
    { "LT", "More keys", "More keys" }, { "LB", nil, "Hold to talk", voice = true, low = true }, { "RB", nil, "Use guess", guess = true, low = true },
    { "MN", "Done", "Send", low = true }, { "B", "Close", "Close", "Back", low = true },
}
local COLUMN = { plain = 2, chat = 3, names = 4 }

local frame, focus, title, line, wordRow, chipRow, list, counter, legend
local cells = {}              -- cells[row][col] = { frame, label }
local guesses, chips, rows = {}, {}, {}   -- each { fill, text }; rows of the list have a tag too

-- A thin line round a frame, at its edge.
local SIDES = {
    { "TOPLEFT", "TOPRIGHT", "SetHeight" }, { "BOTTOMLEFT", "BOTTOMRIGHT", "SetHeight" },
    { "TOPLEFT", "BOTTOMLEFT", "SetWidth" }, { "TOPRIGHT", "BOTTOMRIGHT", "SetWidth" },
}
local function rim(parent, r, g, b, a)
    for _, side in ipairs(SIDES) do
        local bar = Theme.Fill(parent, "BORDER", r, g, b, a)
        bar:SetPoint(side[1])
        bar:SetPoint(side[2])
        bar[side[3]](bar, px(2))
    end
end

-- A place of a row: a dark fill as a key has, and its word in the middle.
local function place(parent, size)
    local fill = Theme.Fill(parent, "BACKGROUND", 0.13, 0.115, 0.095, 1)
    local text = Theme.Text(parent, size, "cream")
    text:SetPoint("CENTER", fill)
    return { fill = fill, text = text }
end

-- The keys from this many units below the panel's top.
local function placeKeys(top)
    for row = 1, Model.ROWS do
        for col = 1, Model.COLS do
            local cell = cells[row][col].frame
            cell:ClearAllPoints()
            cell:SetPoint("TOPLEFT", px(EDGE + (col - 1) * (KEY_W + GAP)), -px(top + (row - 1) * (KEY_H + GAP)))
        end
    end
end

-- Makes the panel, hidden, and gives its frame. It is no protected frame and hangs on the
-- screen itself, so the game does not refuse to show or hide it.
function Draw.Build()
    frame = CreateFrame("Frame", "GamepadSuiteKeyboard", UIParent)
    -- over the settings window (FULLSCREEN_DIALOG) and over the game's own windows
    frame:SetFrameStrata("TOOLTIP")
    frame:SetFrameLevel(500)
    frame:SetSize(px(WIDTH + 2 * EDGE), px(LINE + KEYS + HINT + 2 * EDGE + GAP))
    frame:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, px(24))
    frame:SetClampedToScreen(true)
    -- a click on the panel is not a click on what is under it
    frame:EnableMouse(true)
    frame:Hide()
    Theme.Fill(frame, "BACKGROUND", Theme.Color("ground", 0.96)):SetAllPoints()
    rim(frame, Theme.Color("goldDeep"))

    local well = Theme.Fill(frame, "BORDER", Theme.Color("ground", 0.6))
    well:SetPoint("TOPLEFT", px(EDGE), -px(EDGE))
    well:SetSize(px(WIDTH), px(LINE))
    title = Theme.Text(frame, "small", "gold")
    title:SetPoint("LEFT", well, "LEFT", px(12), 0)
    line = Theme.Text(frame, "name", "white")
    line:SetPoint("LEFT", title, "RIGHT", px(12), 0)
    -- the place of the next letter
    local caret = Theme.Fill(frame, "ARTWORK", Theme.Color("gold"))
    caret:SetSize(px(2), px(24))
    caret:SetPoint("LEFT", line, "RIGHT", px(2), 0)

    for row = 1, Model.ROWS do
        cells[row] = {}
        for col = 1, Model.COLS do
            local cell = CreateFrame("Frame", nil, frame)
            cell:SetSize(px(KEY_W), px(KEY_H))
            Theme.Fill(cell, "BACKGROUND", 0.13, 0.115, 0.095, 1):SetAllPoints()
            local done = Model.Key(row, col) == "done"
            local label = Theme.Text(cell, done and "small" or "name", done and "gold" or "cream")
            label:SetPoint("CENTER")
            cells[row][col] = { frame = cell, label = label }
        end
    end
    placeKeys(EDGE + LINE + GAP)
    -- the key in focus: a gold rim and a gold light over the key
    focus = CreateFrame("Frame", nil, frame)
    focus:SetFrameLevel(frame:GetFrameLevel() + 5)
    Theme.Fill(focus, "BACKGROUND", Theme.Color("gold", 0.22)):SetAllPoints()
    rim(focus, Theme.Color("gold"))

    legend = ns.Widgets.Legend(frame, "LEFT")
    legend:SetPoint("LEFT", frame, "BOTTOMLEFT", px(EDGE), px(EDGE + HINT / 2 - 4))

    -- the guesses: three places as wide as a third of the keys, under the top line
    wordRow = CreateFrame("Frame", nil, frame)
    wordRow:SetPoint("TOPLEFT", px(EDGE), -px(EDGE + LINE + GAP))
    wordRow:SetSize(px(WIDTH), px(ROW))
    local width = (WIDTH - (GUESSES - 1) * GAP) / GUESSES
    for i = 1, GUESSES do
        guesses[i] = place(wordRow, "row")
        guesses[i].fill:SetPoint("TOPLEFT", px((i - 1) * (width + GAP)), 0)
        guesses[i].fill:SetSize(px(width), px(ROW))
        -- a long name with its realm ends in dots inside its place (the guess put in the line stays whole)
        guesses[i].text:SetWidth(px(width - 8))
        guesses[i].text:SetWordWrap(false)
    end
    -- the channel row, under the keys; its chips are placed when it is drawn
    chipRow = CreateFrame("Frame", nil, frame)
    chipRow:SetPoint("TOPLEFT", px(EDGE), -px(EDGE + LINE + GAP + ROW + GAP + KEYS))
    chipRow:SetSize(px(WIDTH), px(ROW))
    for i = 1, CHIPS do
        chips[i] = place(chipRow, "small")
        -- the chip of the channel in use: a gold line at its foot, so its word keeps the game's colour
        local mark = Theme.Fill(chipRow, "ARTWORK", Theme.Color("gold"))
        mark:SetPoint("BOTTOMLEFT", chips[i].fill, "BOTTOMLEFT", px(UNDER), px(4))
        mark:SetPoint("BOTTOMRIGHT", chips[i].fill, "BOTTOMRIGHT", -px(UNDER), px(4))
        mark:SetHeight(px(2))
        chips[i].mark = mark
    end

    -- the whisper names: a list beside the keys, eight names a page
    list = CreateFrame("Frame", nil, frame)
    list:SetFrameLevel(frame:GetFrameLevel() + 2)
    list:SetSize(px(LIST_W), px(KEYS + ROW))
    list:SetPoint("TOPLEFT", frame, "TOPRIGHT", px(8), -px(EDGE + LINE + GAP + ROW + GAP))
    Theme.Fill(list, "BACKGROUND", Theme.Color("ground", 0.96)):SetAllPoints()
    rim(list, Theme.Color("goldDeep"))
    local head = Theme.Text(list, "small", "gold")
    head:SetPoint("TOPLEFT", px(14), -px(11))
    head:SetText("Whisper to")
    for i = 1, Model.PAGE do
        rows[i] = place(list, "body")
        rows[i].fill:SetPoint("TOPLEFT", px(8), -px(HEAD + (i - 1) * (NAME_H + 2)))
        rows[i].fill:SetSize(px(LIST_W - 16), px(NAME_H))
        rows[i].text:ClearAllPoints()
        rows[i].text:SetPoint("LEFT", rows[i].fill, "LEFT", px(10), 0)
        rows[i].tag = Theme.Text(list, "tiny", "muted")
        rows[i].tag:SetPoint("RIGHT", rows[i].fill, "RIGHT", -px(10), 0)
    end
    counter = Theme.Text(list, "tiny", "muted")
    counter:SetPoint("BOTTOMRIGHT", -px(14), px(9))
    list:Hide()
    return frame
end

-- The panel for a text that is asked for, or for a chat line (chat true): the rows of a chat line
-- show, the keys move down under the guesses, and the panel grows upward from the screen's bottom.
function Draw.Mode(chat)
    local top = EDGE + LINE + GAP + (chat and ROW + GAP or 0)
    placeKeys(top)
    wordRow:SetShown(chat)
    chipRow:SetShown(chat)
    list:Hide()
    frame:SetHeight(px(top + KEYS + (chat and ROW + GAP + HINT or 0) + HINT + EDGE))
    -- (on a chat line the first row of hints stands one row higher, the second at the bottom)
    legend:ClearAllPoints()
    legend:SetPoint("LEFT", frame, "BOTTOMLEFT", px(EDGE), px(EDGE + (chat and HINT or 0) + HINT / 2 - 4))
end

-- What is on the keys: the second layer while LT is held. The last key is Send on a chat line.
function Draw.Keys(second, chat)
    for row = 1, Model.ROWS do
        for col = 1, Model.COLS do
            local key = Model.Key(row, col, second)
            cells[row][col].label:SetText(key == "done" and (chat and "Send" or "Done") or key)
        end
    end
end

-- The hints, from left to right: "plain" for a text that is asked for, "chat" for a chat line,
-- "names" while the whisper list is open. guess: Word Guess is on. voice: nil where the game has no
-- voice to text, "can", or "talking" while LB is held.
function Draw.Hints(mode, guess, voice)
    local entries, lowered = {}, nil
    for _, hint in ipairs(HINTS) do
        local word = (guess or not hint.guess) and (voice or not hint.voice) and hint[COLUMN[mode]] or nil
        word = word and hint.voice and voice == "talking" and "Talking" or word
        if word then
            local low = mode ~= "plain" and hint.low or nil
            entries[#entries + 1] = { keys = { hint[1] }, text = word, br = low and not lowered or nil }
            lowered = lowered or low
        end
    end
    legend.Set(entries)
end

-- The guesses for the word being typed: up to three, and empty places for the rest.
function Draw.Words(words)
    for i, part in ipairs(guesses) do
        part.text:SetText(words[i] or "")
    end
end

-- The colour of a chip's word: the game's own for its chat type (EasyController colours its chips the
-- same way), cream where the game has none and for Close. The log has the first row's colours.
local told = false
local function colour(chip)
    local kind = ns.KeyboardChannels.Kind(chip)
    local r, g, b
    if kind and ns.Adapter.ChatColor then
        r, g, b = ns.Adapter.ChatColor(kind)
    end
    if not r then
        return Theme.Color("cream")
    end
    return r, g, b
end

local function tell(list_)
    told = true
    local out = {}
    for _, chip in ipairs(list_) do
        local r, g, b = colour(chip)
        out[#out + 1] = ("%s %.2f %.2f %.2f"):format(chip.label, r, g, b)
    end
    ns.Log.Add("keyboard", "chip colours from the game (cream where it has none): " .. table.concat(out, "; "))
end

-- The channel row: each chip as wide as its word, in the colour of its channel, and the one of the
-- channel in use (lit) with a gold line under it. While the chip in focus (at) would be past the row's
-- end, the row moves left, and a chip that does not fit whole is not shown.
function Draw.Chips(list_, lit, at)
    if not told and list_[1] then
        tell(list_)
    end
    local spots, x = {}, 0
    for i, part in ipairs(chips) do
        local chip = list_[i]
        part.text:SetText(chip and chip.label or "")
        if chip then
            part.text:SetTextColor(colour(chip))
            spots[i] = { x, math.max(px(CHIP_MIN), part.text:GetStringWidth() + px(CHIP_PAD)) }
            x = x + spots[i][2] + px(GAP)
        end
    end
    local spot, shift = spots[at or lit or 1], 0
    if spot and spot[1] + spot[2] > px(WIDTH) then
        shift = spot[1] + spot[2] - px(WIDTH)
    end
    for i, part in ipairs(chips) do
        spot = spots[i]
        local show = spot ~= nil and spot[1] >= shift and spot[1] + spot[2] - shift <= px(WIDTH) + 0.5
        part.fill:SetShown(show)
        part.text:SetShown(show)
        part.mark:SetShown(show and i == lit)
        if show then
            part.fill:ClearAllPoints()
            part.fill:SetPoint("TOPLEFT", spot[1] - shift, 0)
            part.fill:SetSize(spot[2], px(ROW))
        end
    end
end

-- The whisper list, on the page of the name in focus (at), with "3 of 12" at its foot; nil hides it.
function Draw.Names(names, at)
    list:SetShown(names ~= nil)
    if not names then
        return
    end
    local first = math.floor((at - 1) / Model.PAGE) * Model.PAGE
    for i, part in ipairs(rows) do
        local entry = names[first + i]
        local empty = i == 1 and #names == 0
        part.fill:SetShown(entry ~= nil or empty)
        -- ("Bob (away)": a whisper to someone away is a wasted trip on the keys)
        part.text:SetText(entry and entry.name .. (entry.state and " (" .. entry.state .. ")" or "") or empty and "No one to whisper is online" or "")
        part.tag:SetText(entry and entry.tag or "")
    end
    counter:SetText(#names > 0 and at .. " of " .. #names or "")
end

-- The gold light goes to the key in focus, or the guess, the chip or the name in focus.
function Draw.Focus(state)
    local over
    if state.zone == "words" then
        over = guesses[state.word].fill
    elseif state.zone == "chips" then
        over = chips[state.chip].fill
    elseif state.zone == "names" then
        over = rows[(state.name - 1) % Model.PAGE + 1].fill
    else
        over = cells[state.row][state.col].frame
    end
    focus:ClearAllPoints()
    focus:SetAllPoints(over)
end

-- The top line: what the text is for, and the text so far. Of a long text it shows the end, as
-- many letters as fit beside the title.
function Draw.Line(name, text)
    title:SetText(name or "")
    local room, most = px(WIDTH - 40) - title:GetStringWidth(), 48
    repeat
        line:SetText(Model.Tail(text, most))
        most = most - 4
    until most < 8 or line:GetStringWidth() <= room
end
