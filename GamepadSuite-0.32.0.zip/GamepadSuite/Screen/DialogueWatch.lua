-- What the dialogue view hears of the game (Screen/Dialogue.lua has what it does with it).
--
-- Heard always, from login on. Each costs nothing while no talk is on:
--   the game opens a window of a talk, or ends one;
--   the game opens another window (a vendor, a trainer, a flight map): a talk ends at once;
--   the game asks in a box of its own before a choice of a talk (a price to pay, the inn, the
--   spirit healer): the box has the controller and the view waits behind it; for the unlearning
--   of the talents the talk ends at once, as in the game;
--   a controller comes or goes, or the game's controller interface is turned off or on: one
--   that goes during a talk ends it, as combat does;
--   combat starts or ends; a row of the settings changes;
--   a window or a question of the game takes the controller or gives it back, and a question of
--   the game opens or closes. These two come from inside the game's code.
-- Heard only while a talk is on:
--   the quest log or an item changed: the talk is read again, a moment later and one time for
--   many (the quest log for a list of rows, an item for a quest);
--   the NPC's model or the screen changed: the portrait is set up again;
--   the game wrote its red line ("Inventory is full", a full quest log). That line is a part of
--   the game's interface, which is out of sight during a talk: the interface comes back and
--   stays for the rest of the talk, so the player reads why a step did nothing.
local _, ns = ...

local Draw, Stage, Take = ns.DialogueDraw, ns.DialogueStage, ns.DialogueTake

local Watch = {}
ns.DialogueWatch = Watch

-- the game's event that opens a window of a talk -> the view's name for the window
local OPENS = { GOSSIP_SHOW = "gossip", QUEST_GREETING = "greeting", QUEST_DETAIL = "offer", QUEST_PROGRESS = "progress", QUEST_COMPLETE = "handin" }
local DURING = { QUEST_ITEM_UPDATE = "read", QUEST_LOG_UPDATE = "read", GET_ITEM_INFO_RECEIVED = "read",
    UNIT_MODEL_CHANGED = "face", UI_SCALE_CHANGED = "face", DISPLAY_SIZE_CHANGED = "face", UI_ERROR_MESSAGE = "line" }
local view            -- the module's side: its functions by name (Dialogue.OnLogin)
local again = false   -- the talk in view is to be read again

-- first and second are what the game sends with the event: the unit of a model, or the kind
-- and the words of its red line.
local function heard(event, first, second)
    local talk = view.talk()
    if not talk then
        return
    elseif DURING[event] == "face" then
        if event ~= "UNIT_MODEL_CHANGED" or first == talk.data.unit then
            Draw.FaceAgain()
        end
    elseif DURING[event] == "line" then
        view.note("the game wrote '" .. tostring(second) .. "': its interface is in sight for the rest of the talk", "line" .. tostring(second))
        Stage.Hold()
    elseif not again and (event == "QUEST_LOG_UPDATE") == (talk.kind == "gossip") then
        again = true
        C_Timer.After(0.2, function()
            again = false
            ns.Call("Dialogue", view.reread)
        end)
    end
end

-- A gossip with a texture kit, for the log: one line for each kit, and one more when the game
-- has a window of its own for it (the view shows a plain list).
local function kit(name)
    view.note("the gossip has the texture kit '" .. tostring(name) .. "'", "kit" .. tostring(name))
    if ns.Adapter.DialogueKitWindow(name) then
        view.note("the game has a window of its own for the kit '" .. tostring(name) .. "': the view shows a plain list", "window" .. tostring(name))
    end
end

-- A moment after a box of the game's came up for a choice of the talk, the log says if it is
-- still on the screen: the game hides some boxes by themselves (the one to unlearn the talents
-- while the trainer is not at hand), so one try in the game tells if the box could be answered.
local function boxLater(what)
    C_Timer.After(0.3, function()
        view.note("a moment later the game's box " .. what .. " is on the screen: " .. tostring(ns.Adapter.PopupShown()), "later " .. what)
    end)
end

-- A controller came or went. One that goes during a talk ends it, as combat does.
local function pad()
    if view.busy() and not ns.Adapter.DialoguePad() then
        view.quit("no controller is in use")
        ns.Print("Dialogue View closed because no controller is in use.")
    end
    view.sync()
end

-- A talk shows (on), or is over.
function Watch.Set(on)
    for event in pairs(DURING) do
        if on then
            ns.On(event, "Dialogue", function(...) heard(event, ...) end)
        else
            ns.Off(event, "Dialogue")
        end
    end
end

-- At login. module: the module's side.
function Watch.Login(module)
    view = module
    for event, source in pairs(OPENS) do
        -- (a quest offer comes with the item that started it, or 0; a gossip with its texture kit, or nil)
        ns.On(event, "Dialogue", function(item)
            view.opened(source, event, source == "offer" and item or nil)
            if source == "gossip" and item and view.busy() then
                kit(item)
            end
        end)
    end
    -- another window of the game opens: the talk ends one frame later, at once, in the view and in
    -- the game. A box of the game's for a choice (the inn, the spirit healer) takes the controller,
    -- and the view waits behind it, as the game's own gossip window does.
    ns.On("PLAYER_INTERACTION_MANAGER_FRAME_SHOW", "Dialogue", function(kind)
        local stays, box = ns.Adapter.DialogueStays(kind)
        if not view.busy() then
            return
        elseif not stays then
            C_Timer.After(0, function()
                view.quit("another window of the game opened (kind " .. tostring(kind) .. ")")
            end)
        elseif box then
            view.note("the game asks in its own box for the interaction of kind " .. tostring(kind) .. ": the view waits behind it", "box" .. tostring(kind))
            boxLater("for the interaction of kind " .. tostring(kind))
        end
    end)
    for _, event in ipairs({ "GAME_PAD_CONNECTED", "GAME_PAD_DISCONNECTED", "GAME_PAD_ACTIVE_CHANGED" }) do
        ns.On(event, "Dialogue", pad)
    end
    -- the game's own "Enable Gamepad UI" turned off or on (Core/Pad.lua tells it as "pad")
    ns.Listen("pad", "Dialogue", pad)
    -- A choice with a price asks first in the game's own box. The box takes the controller, so the
    -- view steps aside (Dialogue.lua, follow), and the game makes the choice when the player accepts
    -- (Blizzard_StaticPopup_Game/GameDialogDefs.lua 2564 to 2583).
    ns.On("GOSSIP_CONFIRM", "Dialogue", function(_, text, cost)
        if view.busy() then
            view.note("the game asks first in its own box: '" .. tostring(text) .. "', " .. tostring(cost) .. " copper")
        end
    end)
    -- The trainer's box to unlearn the talents. The game's own gossip window ends its talk before
    -- the box shows (Blizzard_Game/Mainline/EventImplementation.lua 427 to 430, Mainline/
    -- GossipFrameAPI.lua 1 to 3, Shared/GossipFrameShared.lua 176 to 185), and the box hides
    -- itself while the game says the trainer is not at hand (GameDialogDefs.lua 2384 to 2404). So
    -- the view does the same inside the event: the talk ends, and the box is alone with the
    -- controller. A on it unlearns the talents.
    ns.On("CONFIRM_TALENT_WIPE", "Dialogue", function(cost)
        local busy = view.busy()
        view.quit("the game asks in its own box to unlearn the talents for " .. tostring(cost) .. " copper")
        if busy then
            boxLater("to unlearn the talents")
        end
    end)
    ns.On("GOSSIP_CLOSED", "Dialogue", function(more) view.ended(true, "GOSSIP_CLOSED", more) end)
    ns.On("QUEST_FINISHED", "Dialogue", function() view.ended(false, "QUEST_FINISHED") end)
    ns.Adapter.OnGossipChosen(view.chosen)
    -- combat always wins: a talk in view ends at once, and the game's own windows have the talks of the combat
    ns.On("PLAYER_REGEN_DISABLED", "Dialogue", function()
        view.quit("combat started")
        view.sync()
    end)
    ns.On("PLAYER_REGEN_ENABLED", "Dialogue", view.sync)
    ns.Listen("setting", "Dialogue", function(key, value)
        Take.Setting(key, value)
        view.sync()
        view.later()
    end)
    ns.Listen("pad:stack", "Dialogue", view.later)
    ns.Listen("pointer", "Dialogue", view.later)
    ns.Adapter.OnPopups(view.later)
    ns.Listen("popup", "Dialogue", view.later)   -- the guild invite (Screen/Popups.lua) sends no message of the game's popups
end
