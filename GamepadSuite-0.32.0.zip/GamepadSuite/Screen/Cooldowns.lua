-- The cooldown list on the screen (the rules are in CooldownModel.lua): a short column of lines,
-- one for each action of the player's buttons that is cooling down, on any layer. A line is the
-- on-screen button of Hud.lua in the chosen Button Look, with its clock and the row Cooldown
-- Numbers, as the buttons and the fixed slots have them, and at its right the small pictures of
-- its buttons (LT, A). The row List Size makes the whole list larger or smaller.
-- The game always tells an addon if a spell is cooling down. In a fight it can hide the numbers:
-- the clock on a line is then still right, because the game draws it, but the addon cannot put
-- the lines in the order of their ends. They are then in the order they started.
--
-- A button runs what the on-screen buttons show for it (HudModel.Shown): a bind of ours, else the
-- game's own bar slot for that button and layer, read as the spell, item or macro it holds. A
-- bound wheel adds what it holds, with the wheel's button.
-- What each button has is kept, and read again only when it can be another thing: a bind, a
-- fixed slot or a wheel changed, a layer was switched on or off, the set of binds in use changed
-- (a fight, a form), or the game's bar changed a slot, its form bar or its page. The game's word
-- that a cooldown started or ended only asks, for each kept action, if it cools down. Each first
-- time (a line joins, in combat too, leaves, its clock runs out, the game is not sure) writes one log line.
-- A macro cools down when the spell or the item that it would
-- use now does, as on the game's own bar: each draw of the buttons (a modifier key, a form, the
-- target) asks the macros again. The list steps back, dims and moves with the on-screen
-- buttons; its lines do not wait for a draw of the buttons.
-- The sizes are the ones of the sample the user saw (mockups/slots_sample.py).
local _, ns = ...

local View = ns.Module("CooldownList", { "spellState" }, "Cooldown List")
ns.CooldownList = View

local Theme, Widgets, Model = ns.Theme, ns.Widgets, ns.CooldownModel
local px = Theme.px

-- In the units of the on-screen buttons.
local PICTURE, STEP, KEY, KEY_GAP, BESIDE = 30, 36, 20, 3, 6

local holder
local frames = {}    -- a look's name -> its lines (a button keeps the look it was made in)
local showing = {}   -- line -> the action it shows now (Model.Actions)
local actions = {}   -- Model.Actions, as of the last time the binds were read
local stale = true   -- what a button has can be another thing now: the binds are read again at the next use
local cooling = {}   -- id -> { since, ends }
local macros = false -- a kept action is a macro of the player's
local game           -- HudModel.Game: the game's own action for a button with no bind of ours
local top = {}       -- key -> the game's action for that button with no trigger, false for none

-- One play tells what only the game can show: each of these goes in the log one time.
local told = {}
local function tell(about, text)
    if not told[about] then
        told[about] = true
        ns.Log.Add("cooldowns", text)
    end
end

-- What a slot of the game's own bar holds, as a bind: the same spell on a bind of ours and on
-- the game's bar is then one line. Any other bind comes back as it is.
local function slotBind(bind)
    if not bind or bind.kind ~= "slot" then
        return bind
    end
    local now = ns.Adapter.SlotRead(bind.id)
    if now then
        tell("bar", "The game's bar slot " .. tostring(bind.id) .. " holds " .. now.kind .. " " .. tostring(now.id) .. ": the list watches it.")
    end
    return now or nil
end

-- The binds a wheel holds: a wheel of the player's own holds binds, the Consumables and Quest
-- Item wheels hold items.
local function inside(wheel)
    local out = {}
    local mine
    for _, each in ipairs(ns.Wheels.Mine()) do
        mine = each.id == wheel.id and each or mine
    end
    if mine then
        for _, bind in pairs(mine.slots) do
            out[#out + 1] = ns.BindRules.Real(bind)
        end
    else
        for _, entry in ipairs(ns.Wheels.Entries(wheel.id)) do
            out[#out + 1] = entry.item and { kind = "item", id = entry.item, icon = entry.icon } or nil
        end
    end
    if #out > 0 then
        tell("wheel", "The list watches what the wheel " .. tostring(wheel.id) .. " holds (entries: " .. #out .. ").")
    end
    return out
end

-- Which action each button has now, in the set of binds that is in use. Only when that can have
-- changed since the last time.
local function readActions()
    if not stale then
        return
    end
    stale = false
    local get = ns.Registry.Get
    local state = ns.Adapter.BindState(get("layers.combat_set"), get("layers.forms_and_stances") ~= "Off" and ns.Adapter.Forms() or {}, get("layers.forms_and_stances") == "Combat First")
    local layers, buttons = { 1, 2, 3, 4, get("layers.hold_lb_rb_set") and 5 or nil }, {}
    for key in pairs(ns.Adapter.KEY) do
        if key ~= "LT" and key ~= "RT" then
            buttons[#buttons + 1] = key
        end
    end
    table.sort(buttons)
    -- the bind in use, as Screen/Hud.lua finds it: false for a slot made empty on purpose
    local function find(layer, key)
        local bind, set = ns.BindRules.Find(ns.Binds.Get, state, layer, key)
        if bind then
            return ns.BindRules.Real(bind)
        elseif set then
            return false
        end
    end
    -- (a command is never in the list: it needs no picture here)
    game = game or ns.HudModel.Game(ns.Adapter, function() end)
    -- While a trigger is down, the game's bar in use is that trigger's (Blizzard_GamepadActionBars/
    -- PageUnit.lua 568 to 598): the action with no trigger is then the one of the last read with none down.
    local lt, rt = ns.Adapter.Held()
    local bar = { bar = game.bar, slot = function(layer, key)
        if layer ~= 1 then
            return game.slot(layer, key)
        elseif not (lt or rt) then
            top[key] = game.slot(1, key) or false
        end
        return top[key] or nil
    end }
    actions = Model.Actions(function(layer, key)
        return slotBind(ns.HudModel.Shown(find, bar, layer, key))
    end, buttons, layers, ns.SlotRules.HELD, inside)
    -- an action that no button has now (the spell of a form that ended) is forgotten
    local bound = {}
    macros = false
    for _, action in ipairs(actions) do
        bound[action.id] = true
        macros = macros or action.bind.kind == "macro"
    end
    for id in pairs(cooling) do
        cooling[id] = bound[id] and cooling[id] or nil
    end
end

local function named(action)
    return action.id .. " on " .. table.concat(action.keys, " + ")
end

-- Asks the game about each kept action. An action that cools no more leaves at once. One that
-- the game says is cooling, with no numbers, joins only when the game is sure: in its cooldown
-- event for spells that is about that spell, not the short cooldown of every cast and not a wand's
-- shot (Adapter.Cooling). event: the game's event that asks, or nil. told: what the cooldown event
-- for spells told, or nil. kind: only the actions of that kind are asked.
local function readCooling(event, kind, told)
    readActions()
    local now = GetTime()
    for _, action in ipairs(actions) do
        if not kind or action.bind.kind == kind then
            local active, ends, sure = ns.Adapter.Cooling(action.bind, told)
            local was = cooling[action.id]
            if not active and was and was.ends and was.ends > now + 1 and action.bind.kind == "item" then
                -- An item's cooldown never ends early. A "no" before the end the game gave is a
                -- hidden number in combat (ForeverCDM clears its clock then): the line stays to that end.
                tell("item", "The game says " .. named(action) .. " cools no more, " .. math.floor(was.ends - now) .. " s before its end (in combat: "
                    .. tostring(ns.Adapter.InCombat()) .. "). The line stays to its end.")
            elseif not active or (ends and ends <= now) then
                if was then
                    tell("leave", named(action) .. " left the list: " .. (active and "its end came" or "the game says it cools no more") .. ", told by " .. (event or "a draw") .. ".")
                end
                cooling[action.id] = nil
            elseif was then
                was.ends = ends
            elseif sure then
                cooling[action.id] = { since = now, ends = ends }
                local fight = ns.Adapter.InCombat()
                tell(fight and "combat" or "join", (fight and "In combat, " or "") .. named(action) .. " joined the list, told by " .. (event or "a draw")
                    .. ", its end " .. (ends and "known" or "hidden by the game") .. ".")
            elseif told then
                tell("not about", named(action) .. " cools with its end hidden, but " .. event .. " was for spell " .. tostring(told.spell)
                    .. " (start recovery category " .. tostring(told.recovery) .. "): it does not join.")
            end
        end
    end
end

-- The lines of the chosen look, made the first time that look shows; the lines of another look go.
local function linesOf()
    local look = ns.HudModel.Look(ns.Registry.Get("screen.look"))
    for name, lines in pairs(frames) do
        for _, line in ipairs(name ~= look.name and lines or {}) do
            line:Hide()
            showing[line] = nil
        end
    end
    if not frames[look.name] then
        local lines = {}
        for i = 1, Model.MOST do
            local line = ns.Screen.Face(holder, look, PICTURE)
            line:SetSize(px(PICTURE), px(PICTURE))
            line:SetPoint("TOPLEFT", 0, -px((i - 1) * STEP))
            -- the clock without the short cooldown that every cast starts
            line.noShared = true
            -- the game sends no event when a cooldown ends: its clock tells of it. The clock has no short
            -- cooldown in it, so a line with a hidden end leaves now, though a cast or a wand's shot holds the spell
            line.cooldown:HookScript("OnCooldownDone", function()
                tell("done", "The clock of a line ran out: the game sent OnCooldownDone.")
                local state = showing[line] and cooling[showing[line].id]
                if state and not state.ends then
                    cooling[showing[line].id] = nil
                end
                C_Timer.After(0.05, function()
                    ns.Call("CooldownList", View.Draw)
                end)
            end)
            line.keys = Widgets.Keys(line, KEY, KEY_GAP)
            line.keys:SetPoint("LEFT", line, "RIGHT", px(BESIDE), 0)
            line:Hide()
            lines[i] = line
        end
        frames[look.name] = lines
    end
    return frames[look.name]
end

-- The lines, from what is kept. A line's button is filled (picture, clock, count) and its buttons
-- set only when it shows another action; else its clock is set, because the game's word was about
-- a clock. A macro's line is filled each time: it can follow what the macro would use now.
local function drawLines(peek)
    -- a fixed slot always shows its action and its cooldown: that action is not in the list
    local fixed = {}
    for n = 1, ns.SlotRules.MOST do
        local action = ns.Slots.Get(n)
        if action then
            fixed[Model.Id(ns.BindRules.Real(action))] = true
        end
    end
    local lines = Model.Lines(actions, cooling, fixed)
    -- while the player moves the list or changes its size in the settings window and nothing
    -- cools down, three of the actions stand in, so the place and the size can be seen
    if peek and #lines == 0 then
        lines = { actions[1], actions[2], actions[3] }
    end
    local numbers = ns.Registry.Get("screen.cooldown_numbers")
    for i, line in ipairs(linesOf()) do
        local action = lines[i]
        line:SetShown(action ~= nil)
        if not action then
            showing[line] = nil
        -- (an action is a new table at each read of the binds: the same spell can be on other buttons now)
        elseif showing[line] ~= action or action.bind.kind == "macro" then
            showing[line] = action
            ns.Screen.Fill(line, action.bind, numbers)
            ns.Screen.Look(line)
            line.keys.Set(action.keys)
        else
            ns.Screen.Cool(line)
        end
    end
end

-- The list follows the on-screen buttons: shown or stepped back, how strong, and where. True
-- when it shows, and true again while it shows above the settings window. It shows there also
-- while its switch is off: the rows say that it shows while the player changes them.
local function follow()
    local get = ns.Registry.Get
    local shown, alpha = ns.Screen.State()
    local peek = ns.Screen.Peeking("CooldownList", holder)
    shown = peek or shown and get("cooldowns.list")
    holder:SetShown(shown)
    if not shown then
        return false
    end
    holder:SetAlpha(peek and 1 or alpha)
    local scale, x, y = Model.Place(get("cooldowns.x"), get("cooldowns.y"), get("cooldowns.size"))
    holder:SetScale(scale)
    holder:ClearAllPoints()
    holder:SetPoint("TOPLEFT", UIParent, "CENTER", px(x), px(y))
    return true, peek
end

-- Everything again: the place, what cools down, the lines.
function View.Draw()
    if not holder then
        return
    end
    local shown, peek = follow()
    if shown then
        readCooling()
        drawLines(peek)
    end
end

-- The on-screen buttons were drawn in full: the list follows them. Its lines are looked at again
-- only when it came back on the screen, or when the binds are to be read again. otherSet is false
-- when the set of binds in use is the same as at the draw before; a fight or a form makes it another.
local function buttonsDrawn(otherSet)
    stale = stale or otherSet ~= false
    local was = holder:IsShown()
    local shown, peek = follow()
    if shown and (stale or not was) then
        readCooling()
        drawLines(peek)
    elseif shown and macros then
        -- a draw follows a modifier key, a form, the target: a macro can use another spell now,
        -- so the macros alone are asked again
        readCooling(nil, "macro")
        drawLines(peek)
    end
end

-- The game's word that a cooldown started or ended: event is its name. The one for spells tells
-- for which spell, its base spell and its start recovery category (SpellBookDocumentation.lua 925-936).
local function changed(event, spell, base, _, recovery)
    if ns.Registry.Get("cooldowns.list") then
        readCooling(event, nil, event == "SPELL_UPDATE_COOLDOWN" and { spell = spell, base = base, recovery = recovery } or nil)
        if holder:IsShown() then
            drawLines(ns.Screen.Peeking("CooldownList"))
        end
    end
end

-- What a button has can be another thing now. The binds are read at the next use, one time for
-- all the changes of that moment.
local function forget()
    stale = true
end

function View.OnLogin()
    holder = CreateFrame("Frame", "GamepadSuiteCooldowns", UIParent)
    holder:SetSize(px(PICTURE), px(Model.MOST * STEP))
    -- a spell's cooldown, and an item's (an event this game version does not have is left out)
    for _, event in ipairs({ "SPELL_UPDATE_COOLDOWN", "BAG_UPDATE_COOLDOWN" }) do
        pcall(ns.On, event, "CooldownList", function(...)
            changed(event, ...)
        end)
    end
    ns.Listen("screen", "CooldownList", buttonsDrawn)
    -- a bind, a fixed slot or a wheel changed
    for _, message in ipairs({ "bind", "slots", "wheels" }) do
        ns.Listen(message, "CooldownList", forget)
    end
    -- the game's own bar: a slot changed, its bar for a form came or went, the world was entered,
    -- or it turned its page (it sends no event for that)
    for _, event in ipairs({ "ACTIONBAR_SLOT_CHANGED", "UPDATE_BONUS_ACTIONBAR", "PLAYER_ENTERING_WORLD" }) do
        pcall(ns.On, event, "CooldownList", forget)
    end
    ns.Adapter.OnNativeBarChanged(forget, true)
    -- between two draws: the list dims with the on-screen buttons, its pictures take the looks of
    -- the buttons (out of reach, short of mana, cannot be used now) and their counts, and a line whose end is known
    -- leaves at its end
    ns.Listen("screen:look", "CooldownList", function()
        local now = GetTime()
        if not holder:IsShown() or ns.Screen.Peeking("CooldownList") then
            return
        end
        local _, alpha = ns.Screen.State()
        holder:SetAlpha(alpha)
        for line in pairs(showing) do
            ns.Screen.Look(line)
            ns.Screen.Count(line)
        end
        for _, state in pairs(cooling) do
            if state.ends and state.ends <= now then
                return View.Draw()
            end
        end
    end)
    ns.Listen("setting", "CooldownList", function(key, value)
        if key:find("^layers%.") then
            forget()
        elseif key:find("^cooldowns%.") then
            -- (the switch turned off: the list goes at once)
            ns.Screen.Peek("CooldownList", (key ~= "cooldowns.list" or value) and View.Draw or nil)
            View.Draw()
        elseif key == "screen.look" or key == "screen.cooldown_numbers" then
            -- the lines in the buttons' new look, or with their new numbers
            for line in pairs(showing) do
                showing[line] = nil
            end
            View.Draw()
        end
    end)
    View.Draw()
end
