-- The rules of the on-screen keyboard, with no game calls: the keys, how the focus moves over
-- them, what each controller button does, and what a key does to the text.
local _, ns = ...

local Model = {}

-- Five rows of ten keys, in two layers: the keys as they are, and the keys while LT is held.
-- The last key of the last row is Done on both layers. The letters, digits and marks are those
-- of the English keyboard, less the bar: the game reads a bar in a text as the start of a color
-- or a link.
Model.LAYERS = {
    { "1234567890", "qwertyuiop", "asdfghjkl'", "zxcvbnm,./", "!?-=;[]`\\" },
    { "!@#$%^&*()", "QWERTYUIOP", 'ASDFGHJKL"', "ZXCVBNM<>?", "!?_+:{}~\\" },
}
Model.ROWS, Model.COLS = 5, 10
-- the key that has the focus when the keyboard opens: g, in the middle
Model.START = { 3, 5 }

-- What is on a key: one letter or mark, or "done".
function Model.Key(row, col, second)
    if row == Model.ROWS and col == Model.COLS then
        return "done"
    end
    return Model.LAYERS[second and 2 or 1][row]:sub(col, col)
end

-- The key that lies one step that way. Past an end of a row or a column the focus comes in again
-- at the other end.
Model.WAY = { up = { -1, 0 }, down = { 1, 0 }, left = { 0, -1 }, right = { 0, 1 } }

function Model.Move(row, col, way)
    local step = Model.WAY[way]
    return (row - 1 + step[1]) % Model.ROWS + 1, (col - 1 + step[2]) % Model.COLS + 1
end

-- What each button does, by our key names; the settings window gives a direction by its own word.
Model.ACT = {
    DU = "up", DD = "down", DL = "left", DR = "right", up = "up", down = "down", left = "left", right = "right",
    A = "type", X = "back", Y = "space", MN = "done", B = "cancel", RB = "word",
}

-- A chat line has two more rows, each a lane of the focus: the word guesses above the keys
-- (state.words) and the channel row under them (state.chips). Up and down go through the lanes and
-- round at the ends; a row with nothing on it is no lane. state.zone is the row the focus is on ("words",
-- "chips", or "names" for the whisper list), nil on the keys; state.word, state.chip and state.name are the
-- place in each. state.lit is the chip of the channel in use, where the focus lands on the channel row.
function Model.Lanes(state)
    local lanes = {}
    if state.words and #state.words > 0 then
        lanes[1] = "words"
    end
    for row = 1, Model.ROWS do
        lanes[#lanes + 1] = row
    end
    if state.chips and #state.chips > 0 then
        lanes[#lanes + 1] = "chips"
    end
    return lanes
end

-- the whisper list moves a page of this many names at a time
Model.PAGE = 8

local function upDown(state, step)
    local lanes, here = Model.Lanes(state), state.zone or state.row
    local at = 1
    for i, lane in ipairs(lanes) do
        if lane == here then
            at = i
        end
    end
    local lane = lanes[(at - 1 + step) % #lanes + 1]
    if type(lane) == "number" then
        state.zone, state.row = nil, lane
    elseif lane == "words" then
        -- the guess above the column of the key in focus
        state.zone, state.word = lane, math.min(#state.words, math.floor((state.col - 1) * #state.words / Model.COLS) + 1)
    else
        state.zone, state.chip = lane, math.min(#state.chips, state.lit or 1)
    end
end

local function inList(state, act)
    local step = ({ up = -1, down = 1, left = -Model.PAGE, right = Model.PAGE })[act]
    local count = #state.names
    if act == "up" or act == "down" then
        state.name = (state.name - 1 + step) % math.max(count, 1) + 1
    else
        state.name = math.max(1, math.min(count, state.name + step))
    end
end

-- The focus stays on the guesses while they have something: after they changed, a place past the end is
-- the last one, and an empty row sends the focus to the top row of keys.
function Model.Settle(state)
    if state.zone == "words" and #(state.words or {}) == 0 then
        state.zone, state.row = nil, 1
    elseif state.zone == "words" then
        state.word = math.min(state.word, #state.words)
    end
end

-- A button went down. state has the focus (row, col, and zone with its place); second is true while
-- LT is held. Gives what happened: "move" (the focus is on another key), "char" and the letter to add,
-- "back", "done", "cancel", "word" and the guess to put in, "chip" and the place of the channel to pick,
-- "name" and the place of the whisper name, or nil for a button with no use here.
function Model.Press(state, button, second)
    local act = Model.ACT[button]
    if state.zone == "names" then
        if Model.WAY[act] then
            inList(state, act)
        elseif act == "type" then
            return "name", state.name
        elseif act == "cancel" then
            state.zone = "chips"
        else
            return nil
        end
        return "move"
    elseif Model.WAY[act] then
        if act == "up" or act == "down" then
            upDown(state, act == "up" and -1 or 1)
        elseif state.zone then
            local place, count = state.zone == "words" and "word" or "chip", #state[state.zone]
            state[place] = (state[place] - 1 + (act == "left" and -1 or 1)) % count + 1
        else
            state.row, state.col = Model.Move(state.row, state.col, act)
        end
        return "move"
    elseif act == "word" then
        if state.words and state.words[1] then
            return "word", 1
        end
        return nil
    elseif act == "type" and state.zone then
        return state.zone == "words" and "word" or "chip", state.zone == "words" and state.word or state.chip
    elseif act == "type" then
        local key = Model.Key(state.row, state.col, second)
        if key == "done" then
            return "done"
        end
        return "char", key
    elseif act == "space" then
        return "char", " "
    end
    return act
end

-- How many letters a text has. A letter that is not English (typed on a real keyboard) is more
-- than one byte, and is one letter all the same.
function Model.Length(text)
    return #text:gsub("[\128-\191]", "")
end

-- The text with one more letter, or the same text when it is as long as it may be.
function Model.Add(text, char, limit)
    if limit and Model.Length(text) >= limit then
        return text
    end
    return text .. char
end

-- The text less its last letter. An empty text stays empty.
function Model.Back(text)
    return (text:gsub("[^\128-\191][\128-\191]*$", ""))
end

-- The end of a long text, for a line with room for `most` letters. No letter is cut in two.
function Model.Tail(text, most)
    if Model.Length(text) <= most then
        return text
    end
    return "..." .. text:sub(-most):gsub("^[\128-\191]+", "")
end

-- The left stick as a direction. Pushed past ON it gives one; it keeps that one (`was`) until
-- the stick is back inside OFF, so a stick that rests near the edge gives one step and no more.
Model.ON, Model.OFF = 0.6, 0.3

function Model.Dir(x, y, was)
    local push = math.sqrt(x * x + y * y)
    if push >= Model.ON then
        if math.abs(y) >= math.abs(x) then
            return y > 0 and "up" or "down"
        end
        return x > 0 and "right" or "left"
    end
    return push > Model.OFF and was or nil
end

if ns then
    ns.KeyboardModel = Model
end
return Model
