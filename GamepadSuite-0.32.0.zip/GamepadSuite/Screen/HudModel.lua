-- The rules of the on-screen buttons, with no game calls: where each button sits, which trigger
-- layer is in view, and what each button shows. Hud.lua draws what this file gives it.
local _, ns = ...

local Model = {}

-- Two groups, as the buttons sit on a controller: the D-pad side on the left and the A, B, X, Y
-- side on the right. A place is { group, x, y } in units from the middle of its group; y is up.
-- The four main buttons of a group are one step from its middle. The shoulder button is above
-- them, the stick click and the small button under them, the back grips at the bottom.
Model.STEP = 52
Model.PLACE = {
    DU = { "left", 0, 1 }, DL = { "left", -1, 0 }, DR = { "left", 1, 0 }, DD = { "left", 0, -1 },
    LB = { "left", -1.5, 2 }, LS = { "left", -1.5, -2 }, VW = { "left", 1.5, 2 },
    L4 = { "left", 0.5, -2 }, L5 = { "left", 1.5, -2 },
    Y = { "right", 0, 1 }, X = { "right", -1, 0 }, B = { "right", 1, 0 }, A = { "right", 0, -1 },
    RB = { "right", 1.5, 2 }, RS = { "right", 1.5, -2 }, MN = { "right", -1.5, 2 },
    R4 = { "right", -0.5, -2 }, R5 = { "right", -1.5, -2 },
}
-- The colour of the rim round a button whose bind is the form's own (the row Form Ring), by the
-- set's name: the form's spell number. A form with no colour of its own has gold.
Model.RING = {
    ["form:5487"] = { 0.90, 0.26, 0.20 }, -- Bear Form
    ["form:768"] = { 0.96, 0.55, 0.16 }, -- Cat Form (orange: a yellow reads as the gold rim of a press)
    ["form:5215"] = { 0.62, 0.70, 0.86 }, -- Prowl
    ["form:1066"] = { 0.25, 0.62, 0.95 }, -- Aquatic Form
    ["form:783"] = { 0.27, 0.78, 0.63 }, -- Travel Form (teal: a green reads as the rim of a worn item)
    ["form:24858"] = { 0.66, 0.42, 0.95 }, -- Moonkin Form
    ["form:2457"] = { 0.86, 0.86, 0.86 }, -- Battle Stance (silver: apart from the Berserker red)
    ["form:71"] = { 0.30, 0.56, 0.92 }, -- Defensive Stance
    ["form:2458"] = { 0.86, 0.16, 0.16 }, -- Berserker Stance
    ["form:1784"] = { 0.62, 0.70, 0.86 }, -- Stealth
    ["form:15473"] = { 0.58, 0.36, 0.82 }, -- Shadowform
}

-- The rim's colour for a bind that came from this set; nil for a set that is no form's.
function Model.Ring(set)
    return set and set:find("^form:") and (Model.RING[set] or { 0.86, 0.86, 0.86 }) or nil
end

-- The four main buttons of each group are drawn larger than the others.
local MAIN = { DU = true, DL = true, DR = true, DD = true, A = true, B = true, X = true, Y = true }

-- The three looks of the on-screen buttons (the row Button Look). Each is a table with the same
-- fields, in units; HudFace.lua draws a button and a group from it. The numbers of Plate and
-- Round are the ones of the sample the owner chose from (mockups/buttons_look_sample.py).
--   step, main, small   one step of a group, the size of a main picture and of the others
--   out                 how far the top and bottom rows move out, so nothing touches the plate
--   shape               the picture, its line and its rims: "square", "soft" (soft corners), "round"
--   line, emptyLine     the black line or ring behind the picture: { width, strength }; the faint
--                       line in the Theme's cream of a button with no bind, which also gets emptyFill
--   faint               how strongly a button with no bind shows
--   flash, run, worn, form   how far each rim stands out: a press, an action in progress, a worn
--                       item, the form ring. In Square the picture's own edge covers two units.
--   shade               how dark a held button's picture goes; false: it gets the press ring
--   shadow              the strength of the soft shadow under a button
--   key, keyAt, keyGap  the picture of a button's controller button: its size; "corner": on the
--                       corner of the art, keyGap inside it; "under": under a small button,
--                       keyGap below it, and the main four show in the middle of the group
--   middle              what the middle of a group shows: pad, the size of the D-pad's picture;
--                       face and reach, the size of the A B X Y pictures and how far they sit
--                       from the middle; mark, the size of the one disc with four dots; faint,
--                       how strongly the picture of a button with no bind shows there
--   plate, label        the round plate behind the main four (edge: the strength of its line in
--                       the Theme's cream); the label with the layer's name, over the top row
--                       (Model.LabelRow), its text one of the Theme's sizes
--   dim, arc            a cooldown: how dark the picture goes, and the arc on the ring:
--                       { width, how far its dark outline stands out, the gray of the arc }
--   number              the cooldown's number: { the Theme's size for a main picture (a smaller
--                       picture has it smaller by as much), outline or not }; false is the game's own
--   mini                the small pictures of the other layers on a main button (the row Other
--                       Layers), in a row above the button, outside its picture (Model.MiniRow):
--                       rim and live, how far the dark line and the gold line of the layer in
--                       view stand out; gap, from the button's edge to the row's lowest line;
--                       lean, how far the row of a button at the side of its group moves out,
--                       away from the group's top button; size, how large each is by the place of
--                       its button: top, side, bottom, in units; under: the row of a bottom button
--                       sits under it (the middle of the group holds a picture over it).
--                       A size is as large as fits, 24 units at most: the next unit more would
--                       touch a neighbor button, its button picture or a small picture of another
--                       button (the side size is one for both side buttons: the one with less room).
Model.LOOKS = {
    Square = {
        name = "Square", step = Model.STEP, main = 48, small = 36, out = 0, shape = "square",
        line = false, emptyLine = false, emptyFill = false, faint = 0.35,
        flash = 4, run = 5, worn = 4, form = 3, shade = 0.45, shadow = false,
        key = 20, keyAt = "corner", keyGap = 2, middle = false, plate = false, label = false,
        dim = false, arc = false, number = false,
        mini = { rim = 1, live = 2, gap = 3, lean = 12, size = { top = 24, side = 17, bottom = 9 } },
    },
    Plate = {
        name = "Plate", step = 52, main = 48, small = 36, out = 3, shape = "soft",
        line = { 1, 0.85 }, emptyLine = { 1, 0.16 }, emptyFill = 0.3, faint = 1,
        flash = 2, run = 3, worn = 2, form = 2, shade = 0.35, shadow = 0.5,
        key = 20, keyAt = "under", keyGap = 3, middle = { pad = 30, face = 18, reach = 14, faint = 0.35 },
        plate = { radius = 83, fill = { 0.031, 0.035, 0.043, 0.3 }, edge = 0.35 },
        label = { width = 80, height = 20, text = "tiny", fill = { 0.031, 0.035, 0.043, 0.6 } },
        dim = false, arc = false, number = { "row", true },
        mini = { rim = 1, live = 2, gap = 3, lean = 12, size = { top = 24, side = 22, bottom = 18 }, under = true },
    },
    Round = {
        name = "Round", step = 46, main = 52, small = 36, out = 0, shape = "round",
        line = { 2, 0.82 }, emptyLine = { 1, 0.16 }, emptyFill = 0.3, faint = 1,
        flash = 3, run = 4, worn = 3, form = 3, shade = false, shadow = 0.5,
        key = 20, keyAt = "under", keyGap = 5, middle = { pad = 24, mark = 24, faint = 0.35 }, plate = false, label = false,
        dim = 0.6, arc = { 2, 3, 0.812 }, number = { "row", false },
        mini = { rim = 1, live = 2, gap = 3, lean = 12, size = { top = 24, side = 13, bottom = 13 }, under = true },
    },
}
-- Bars (Screen/HudBars.lua): every layer at once, one bar for each, with the buttons of Square.
Model.LOOKS.Bars = {}
for field, value in pairs(Model.LOOKS.Square) do
    Model.LOOKS.Bars[field] = value
end
-- (its controller button pictures reach 4 units out of their buttons, so they stay in the space between two)
Model.LOOKS.Bars.name, Model.LOOKS.Bars.bars, Model.LOOKS.Bars.keyGap = "Bars", true, 6
-- The dots of the mark in the middle of the A B X Y group of Round, in the colors of the
-- letters; a button with no bind has a gray dot. reach (how far a dot is from the middle) and
-- size are parts of the mark's size.
Model.DOTS = { Y = { 1, 0.8, 0.078 }, X = { 0.161, 0.522, 0.961 }, B = { 0.929, 0.22, 0.2 }, A = { 0.38, 0.8, 0.161 },
    none = { 0.353, 0.345, 0.314 }, reach = 6.4 / 24, size = 5.6 / 24 }

-- The look of that name; Square for a name it does not know.
function Model.Look(name)
    return Model.LOOKS[name] or Model.LOOKS.Square
end

-- Where the picture of a button's controller button sits: x and y of its middle from the middle
-- of the button, and its size. nil for a main button of a look that shows the four in the middle.
function Model.KeyPlace(look, size, main)
    if look.keyAt == "corner" then
        return size / 2 - look.keyGap, look.keyGap - size / 2, look.key
    elseif not main then
        return 0, -(size / 2 + look.keyGap + look.key / 2), look.key
    end
end

-- What a look shows in the middle of a group: a list of { key, x, y, size }. key is a button,
-- "DPAD" for the game's picture of the whole D-pad, or "MARK" for the disc with the four dots.
function Model.Middle(look, group)
    local middle, list = look.middle, {}
    if not middle then
        return list
    elseif group == "left" then
        list[1] = { key = "DPAD", x = 0, y = 0, size = middle.pad }
    elseif middle.mark then
        list[1] = { key = "MARK", x = 0, y = 0, size = middle.mark }
    else
        for _, key in ipairs({ "Y", "X", "B", "A" }) do
            local place = Model.PLACE[key]
            list[#list + 1] = { key = key, x = place[2] * middle.reach, y = place[3] * middle.reach, size = middle.face }
        end
    end
    return list
end

-- How high the top row of a look is over the middle of its group: the label of Plate sits there.
function Model.TopRow(look)
    return 2 * look.step + look.out
end

-- The height of the middle of the layer's label: over the top row, clear of the bumpers, so the
-- small pictures over the top button have room under it.
function Model.LabelRow(look)
    return Model.TopRow(look) + look.small / 2 + 4 + look.label.height / 2
end

-- How far a look reaches under the middle of its groups: the bottom row with its button pictures.
function Model.Reach(look)
    local _, y, key = Model.KeyPlace(look, look.small, false)
    return Model.TopRow(look) - y + key / 2
end

-- The frame of the buttons is as high as Square reaches, and the row Buttons Y Position can put
-- its bottom edge near the screen's. A look that reaches farther down is lifted by this much,
-- so its lowest pictures stay on the screen. base: the frame's bottom edge over the screen's.
function Model.Lift(look, scale, base)
    return math.max(0, (Model.Reach(look) - Model.Reach(Model.LOOKS.Square)) * scale - base)
end

-- The buttons of the LB + RB layer. The other buttons show their own bind while it is held.
local IN_HOLD = { DU = true, DD = true, DL = true, DR = true, A = true, B = true, X = true, Y = true, LS = true, RS = true }

-- The layer in view: 1 no trigger, 2 LT, 3 RT, 4 LT + RT, 5 LB + RB. both is true while LB and
-- RB are held and that layer is switched on. It wins over a held trigger, as on the keys.
function Model.Layer(lt, rt, both)
    if both then
        return 5
    end
    return 1 + (lt and 1 or 0) + (rt and 2 or 0)
end

-- What a press runs on a layer. game tells about the game's own bar: game.bar(key) is true for
-- one of its eight buttons, game.slot(layer, key) gives the action it holds there, or nil.
--   A bind of ours on the layer comes first.
--   One of the eight bar buttons with no bind of ours on a trigger layer runs the game's own
--   action for that button and layer. It does not run the button's plain bind.
--   Another button (LB, a stick click) with no bind on a trigger layer runs its plain bind: the
--   game falls back from "LT + LB" to "LB".
--   The LB + RB layer is ten binds of its own: one of its ten buttons with no bind there does
--   nothing and shows nothing. Another button shows its plain press.
local NO_GAME = { bar = function() return false end, slot = function() return nil end }
--   find gives false for a slot that the player made empty on purpose in the set in use: the
--   press does nothing there, and the button shows nothing.
local function inUse(find, game, layer, key)
    local bind
    if layer == 5 then
        bind = find(IN_HOLD[key] and 5 or 1, key)
        if bind == nil and not IN_HOLD[key] then
            bind = game.slot(1, key)
        end
        return bind or nil
    end
    bind = find(layer, key)
    if bind == nil then
        if layer == 1 or game.bar(key) then
            bind = game.slot(layer, key)
        else
            bind = find(1, key)
        end
    end
    return bind or nil
end

-- With no trigger held, the four face buttons of the game's own bar have a fixed job where the
-- player has no bind: X interacts, Y inspects, B goes back (stops a cast, clears the target),
-- A jumps. The numbers are the game's own for those four buttons.
local FIXED = { [5] = "INTERACTTARGET", [6] = "INSPECT", [7] = "STOPCASTING", [8] = "JUMP" }
local FIXED_ICON = { INSPECT = "Interface\\Icons\\INV_Misc_Spyglass_02" }

-- The `game` of Model.Buttons: the game's own action for a button, where the bind core leaves
-- the key to the game or gives it to the game's own bar button. adapter answers for the game
-- (NativeSlot, NativeIndex, KeyCommand, NativeButtonName); icon(command) gives a command's
-- picture. A command's entry is made once and kept.
function Model.Game(adapter, icon)
    local commands = {}
    return {
        slot = function(layer, key)
            local slot = adapter.NativeSlot(key, layer)
            if slot or layer ~= 1 then
                return slot
            end
            -- a fixed face button, or a button outside the game's bar (LB, a stick click) with a
            -- game command of its own
            local command = FIXED[adapter.NativeIndex(key) or 0] or adapter.KeyCommand(key)
            if command and not commands[command] then
                commands[command] = { kind = "command", id = command, icon = FIXED_ICON[command] or icon(command) }
            end
            return commands[command]
        end,
        bar = function(key) return adapter.NativeButtonName(key, 2) ~= nil end,
    }
end

-- The colour over the picture of an action, the same on every part that shows one (HudFace.Unusable):
-- a target too far wins (red, as on ConsolePort), then short of mana, rage or energy (blue), then
-- "cannot be used now" (grey); Blizzard's own numbers, kept in the Theme. usable is true, false or
-- "power" (Adapter.Usable), nil for nothing to ask. Gives the name of the Theme's colour, or nil.
function Model.Tint(usable, tooFar)
    return tooFar and "red" or usable == "power" and "blue" or usable == false and "grey" or nil
end

-- The buttons of the on-screen groups, from the list of the controller picture in use: all but
-- the triggers, which are the layers.
function Model.Keys(order)
    local keys = {}
    for _, key in ipairs(order) do
        if key ~= "LT" and key ~= "RT" then
            keys[#keys + 1] = key
        end
    end
    return keys
end

-- The layers of the three small pictures on a main button, from left to right: LT, LT + RT, RT.
-- The left trigger's is on the left and the right trigger's on the right; both is between them.
Model.MINI_LAYERS = { 2, 4, 3 }

-- Where the three small pictures of a main button sit: their size, and { x, y } of each from the
-- middle of the button, LT first. They are a row above the button, look.mini.gap clear of its
-- picture and its line. The bottom button of a look with a picture in the middle of its group
-- has 6 units to that picture: its row sits under it (look.mini.under). The row of a top or
-- bottom button is centered on it. The top button of a group stands next to the upper corner of
-- a side button, so the row of a side button leans outward by look.mini.lean. nil for a button
-- that is not one of the main eight. size: another size than the look's, for the tests.
function Model.MiniRow(look, key, size)
    local m, place = look.mini, Model.PLACE[key]
    local at = MAIN[key] and (place[2] ~= 0 and "side" or place[3] > 0 and "top" or "bottom")
    size = at and (size or m.size[at])
    if not size then
        return nil
    end
    local pitch = size + m.rim + m.live
    local lean = place[2] == 0 and 0 or place[2] < 0 and -m.lean or m.lean
    local under = at == "bottom" and m.under
    -- (a row under a bottom button stands half a step outward: the back grips sit under it on the inner side)
    lean = under and (place[1] == "left" and -look.step or look.step) / 2 or lean
    local y = (under and -1 or 1) * (look.main / 2 + (look.line and look.line[1] or 2) + m.gap + m.live + size / 2)
    return size, { { lean - pitch, y }, { lean, y }, { lean + pitch, y } }
end

-- What a button would show on a layer: the rule of Model.Buttons for one button, so a small
-- picture of another layer shows what the main picture shows when that layer is in view.
function Model.Shown(find, game, layer, key)
    return inUse(find, game or NO_GAME, layer, key)
end

-- What every button shows now. find(layer, key) gives the bind in use for the state the player
-- is in (BindRules.Find with the store and the state already given). keys is the list of our key
-- names on the controller in use. A button with no action is in the list too, with bind = nil,
-- so the two groups keep their shape. game is told at inUse; with none, only our binds show.
-- look is a table of Model.LOOKS (Square with none): it gives the steps and the sizes.
function Model.Buttons(find, layer, keys, game, look)
    local buttons = {}
    look = look or Model.LOOKS.Square
    for _, key in ipairs(keys) do
        local place = Model.PLACE[key]
        if place then
            -- (the top and bottom rows are two steps from the middle)
            local out = math.abs(place[3]) == 2 and look.out * place[3] / 2 or 0
            buttons[#buttons + 1] = {
                key = key, group = place[1], x = place[2] * look.step, y = place[3] * look.step + out,
                main = MAIN[key] or false, size = MAIN[key] and look.main or look.small,
                bind = inUse(find, game or NO_GAME, layer, key),
                -- while LB + RB is held, a button that is not in that layer steps back
                back = layer == 5 and not IN_HOLD[key],
            }
        end
    end
    return buttons
end

-- The game's events, and the pass of Hud.lua that each asks for: "draw" when what a button shows
-- can change (a bind, a layer, a form, the set in use), "cool" the clocks, "count" the counts,
-- "near" the button of Dynamic Interact, "look" the colors and the rims. A cooldown event sets
-- the clocks and no more, as the game's own buttons do; the looks follow the events that the
-- game's own buttons hear (Blizzard_ActionBar/Shared/ActionButton.lua:263-266, 418, 1010).
Model.EVENTS = {
    draw = { "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_DISABLED", "PLAYER_REGEN_ENABLED", "UPDATE_SHAPESHIFT_FORM", "PLAYER_TARGET_CHANGED",
        "GAME_PAD_ACTIVE_CHANGED", "ACTIONBAR_SLOT_CHANGED", "UPDATE_MACROS", "PLAYER_EQUIPMENT_CHANGED", "UPDATE_STEALTH", "UPDATE_BONUS_ACTIONBAR" },
    -- (a swing of the player: the clock of one swing on Heroic Strike, Cleave and Maul, Screen/HudSwing.lua)
    cool = { "SPELL_UPDATE_COOLDOWN", "ACTIONBAR_UPDATE_COOLDOWN", "BAG_UPDATE_COOLDOWN", "PLAYER_SWING" },
    count = { "BAG_UPDATE" },
    near = { "PLAYER_SOFT_INTERACT_CHANGED" },
    look = { "SPELL_UPDATE_USABLE", "ACTION_USABLE_CHANGED", "CURRENT_SPELL_CAST_CHANGED", "ACTIONBAR_UPDATE_STATE",
        "START_AUTOREPEAT_SPELL", "STOP_AUTOREPEAT_SPELL", "PLAYER_ENTER_COMBAT", "PLAYER_LEAVE_COMBAT" },
}

-- How strongly the buttons show. After `idle` seconds with no press they dim to the setting Fade
-- When Idle ("Off", "Dim to 40%", "Dim to 20%"). They never dim in combat, not while an enemy
-- that can be attacked is the target, and not while the pointer carries a spell to drop on one
-- (inCombat is true for all three).
Model.IDLE = 4
function Model.Alpha(setting, inCombat, idle)
    if inCombat or setting == "Off" or idle < Model.IDLE then
        return 1
    end
    return setting == "Dim to 20%" and 0.2 or 0.4
end

if ns then
    ns.HudModel = Model
end
return Model
