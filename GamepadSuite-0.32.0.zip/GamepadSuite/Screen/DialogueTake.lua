-- Who has the talks with NPCs: the game's own gossip and quest windows, or the dialogue view
-- (Core/AdapterDialogueTake.lua has the game's side, and the head of Core/AdapterDialogue.lua
-- the proof). The view has them with the row Dialogue View on, out of combat, while a
-- controller is in use, with no fault, and with no other addon that has the game's windows.
-- Then the game's two windows do not hear the events that open them. Nothing changes during a
-- talk, or while a window of the game is up: a talk that has started cannot change hands.
local _, ns = ...

local Take = {}
ns.DialogueTake = Take

local taken = false   -- the game's windows do not hear their events: the talks are the view's
local off             -- why the view never takes the talks in this session; nil while it can
local other           -- the chat line when another addon has the game's windows
local note
local padTold -- the log has the first answer to "is a controller in use"

function Take.Has()
    return taken
end

function Take.Off()
    return off
end

-- The view is off until the next login (a fault).
function Take.Stop(why)
    off = off or why
end

-- The game's windows hear their events again; true when they do.
function Take.Back()
    if taken then
        taken = not ns.Adapter.DialogueTake(false)
    end
    return not taken
end

-- The game's windows hear their events, or the view has them, as is right now. busy: a talk is
-- on in the view; then nothing changes.
function Take.Sync(busy)
    if busy then
        return
    end
    if not padTold then
        padTold = true
        note("at the first look a controller is in use: " .. tostring(ns.Adapter.DialoguePad() and true or false), "padlogin")
    end
    local want = not off and ns.Registry.Get("windows.dialogue") and not (ns.fightStarted or ns.Adapter.InCombat())
        and ns.Adapter.DialoguePad() and not ns.Adapter.DialogueGameWindow()
    if want and not taken then
        taken = ns.Adapter.DialogueTake(true)
        note(taken and "the view has the events of the game's gossip window and quest window"
            or "the game did not let its windows' events be taken: the game's own windows stay", "take")
        if not taken then
            off = "the game keeps its windows"
            ns.Print("Dialogue View is off: this game build keeps its own gossip and quest windows.")
        end
    elseif taken and not want then
        taken = not ns.Adapter.DialogueTake(false)
    end
end

-- At login, before the first take: another addon that has the game's windows turns the view off
-- for the session. It never takes and never gives back. The chat says so one time for the
-- account, and again each time the player turns the row Dialogue View on.
function Take.Login(log)
    note = log
    local busy, name = ns.Adapter.DialogueOther()
    if not busy then
        return
    end
    off = "the addon " .. (name or "that has the game's windows") .. " is on"
    other = name and ("Dialogue View is off while the addon " .. name .. " is on. Turn " .. name .. " off in the addon list to use it.")
        or "Dialogue View is off while another addon has the game's gossip and quest windows. Turn that addon off to use it."
    note("the view stays off for this session: " .. off)
    local store = ns.Registry.Store("dialogue")
    if not store.toldOther then
        store.toldOther = true
        ns.Print(other)
    end
end

-- A row of the settings changed (key, value).
function Take.Setting(key, value)
    if other and key == "windows.dialogue" and value then
        ns.Print(other)
    end
end
