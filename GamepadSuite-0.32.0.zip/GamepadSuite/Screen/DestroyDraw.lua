-- The look of the Destroy Gray Item prompt (Screen/Destroy.lua): low on the screen, its foot just above the on-screen
-- buttons as the loot roll card's (Screen/Rolls.lua), so it covers no button group. The item's picture, its count and
-- name, its worth, Y and the steps in the strip of every part, and under it the bar of a hold. And the plain button
-- that Y clicks while the prompt shows.
local _, ns = ...

local Draw = {}
ns.DestroyDraw = Draw

local LOW, GAP = 200, 8 -- with no on-screen buttons the prompt's foot is LOW over the screen's foot; GAP: room above the buttons

-- Makes the prompt and the button. click(down) hears each press down and let-go of Y. Gives the prompt, the button,
-- the bar of a hold, the strip, the title, the worth and the picture.
function Draw.Build(click)
    local Theme, px = ns.Theme, ns.Theme.px
    local prompt = CreateFrame("Frame", "GamepadSuiteDestroyPrompt", UIParent)
    prompt:SetSize(px(560), px(112))
    local buttons = _G.GamepadSuiteScreen
    if buttons then
        prompt:SetPoint("BOTTOM", buttons, "TOP", 0, px(GAP))
    else
        prompt:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, px(LOW))
    end
    prompt:SetFrameStrata("HIGH")
    prompt:Hide()
    Theme.Fill(prompt, "BACKGROUND", Theme.Color("ground", 0.6)):SetAllPoints()
    local icon = ns.Widgets.Icon(prompt, px(52))
    icon:SetPoint("TOPLEFT", px(14), -px(12))
    local title = Theme.Text(prompt, "name", "cream")
    title:SetPoint("TOPLEFT", icon, "TOPRIGHT", px(14), -px(2))
    title:SetPoint("RIGHT", prompt, "RIGHT", -px(14), 0)
    local value = Theme.Text(prompt, "body", "muted")
    value:SetPoint("BOTTOMLEFT", icon, "BOTTOMRIGHT", px(14), px(2))
    -- the bar is full when the hold is long enough
    local legend = ns.Widgets.Legend(prompt, "LEFT")
    legend:SetPoint("BOTTOMLEFT", px(14), px(12))
    local bar = ns.Widgets.HoldLine(prompt, 6)
    local button = CreateFrame("Button", "GamepadSuiteDestroyY", UIParent)
    button:RegisterForClicks("AnyDown", "AnyUp")
    button:SetScript("OnClick", function(_, _, down)
        click(down)
    end)
    return prompt, button, bar, legend, title, value, icon
end
