-- Destroy Gray Item: when loot does not fit because the bags are full, a prompt low on the screen, just above the
-- on-screen buttons as the loot roll's card is, offers the cheapest gray item: its picture, its count and name, what a
-- vendor pays for it, and in the strip of button hints of every part the picture of Y with the steps. There are three:
-- hold Y for one second (the bar of a hold fills, as on every hold), let go, press Y once more. That press destroys the
-- item, the loot is asked for again, and one chat line says what was destroyed. A short press does nothing. The prompt
-- goes away after ten seconds, when the bags have room again, when the loot is closed and when a fight starts. In a
-- fight nothing is offered. Screen/DestroyModel.lua says which item is offered, and only when the loot holds a thing
-- worth its room. While a loot roll card shows (the same place) the prompt waits, up to its ten seconds, and shows when
-- the last roll ends while the loot is still open. Screen/DestroyDraw.lua draws it.
--
-- Why three steps: the game takes the call that destroys an item only inside a press of the
-- player (Core/AdapterDestroy.lua), and a call it refuses brings up its window "this addon was
-- blocked", where the first button turns the addon off. The moment a hold is full is no press.
-- No source says that a let-go counts as one, and the game's own controller binds act at the
-- press down. So the hold only makes the prompt ready, and the destroy is asked for at a press
-- down and nowhere else. Should the game refuse even that, nothing is offered again in the
-- session, and the chat says so.
--
-- Y is heard through a priority bind of a plain button of ours. It is ours only while the
-- prompt shows and all of this holds:
--   play has the controller, or the loot window has it. In any other window Y is that window's
--   (in the bags it opens the item's menu): the prompt goes, so no hold there can destroy.
--   no layer button is held. A trigger or LB that goes down gives Y back at the next step, so
--   the layer's bind on Y runs; when it is let go Y is taken again.
--   no fight: the key goes back at a fight's start, while the game still allows it.
-- The game's error text is listened to only while loot is open and out of a fight, the bags and
-- the modifier keys only while the prompt shows or a destroy waits for its answer, and the bar
-- is drawn each frame only during a hold.
--
-- The log (kind "destroy") says what was offered, if Y read back as set, if a press of Y came,
-- what the game did at the press that destroys, and if the bag slot was empty after.
local _, ns = ...

local Destroy = ns.Module("Destroy", { "destroyGray" }, "Destroy Gray Item")
ns.Destroy = Destroy

local Model = ns.DestroyModel

local MAX_NOTES = 16    -- lines for the log in one session
local prompt, button, bar, legend, title, value, icon
local offered           -- the thing the prompt shows; nil while it does not show
local came = 0          -- counts the times the prompt's ten seconds began, so that a timer knows if it is still the newest
local held, full        -- when the hold that runs now began, and if it is a full one already
local armed = false     -- a hold was full: the next press down destroys the item
local dead = false      -- the game refused a destroy: nothing is offered again in this session
local gone              -- the thing whose destroy was asked for and is not answered yet
local looting = false   -- loot is open
local none = false      -- at this loot the bags had nothing to offer: they are not read again for it
local due = false       -- a look at who has Y is due at the next step
local parked            -- while a roll card holds the prompt back: the end of its wait (Model.STAY)
local soon = false      -- a look at the rolls is due at the next step
local notes, awayTold, heard, told = 0, false, false, {}

-- True while the prompt shows: the place above the on-screen buttons is its (Screen/WearReward.lua waits).
function Destroy.Shown()
    return offered ~= nil
end

local function note(text)
    if notes < MAX_NOTES then
        notes = notes + 1
        ns.Log.Add("destroy", text)
    end
end

-- A line for the log once in a session, by its kind, outside the count of the others.
local function once(kind, text)
    if not told[kind] then
        told[kind] = true
        ns.Log.Add("destroy", text)
    end
end

local function coins(thing)
    return ns.RestockModel.Coins(Model.Worth(thing))
end

-- True when Y can be the prompt's: play has the controller, or the loot window has it.
local function free()
    return ns.Pad.Gameplay() or ns.Adapter.LootHasPad()
end

local bags, later

-- The bags are listened to while the prompt shows or a destroy waits for its answer, a
-- modifier key (a trigger that the game makes Shift, Ctrl or Alt) while the prompt shows.
local function listen()
    if offered or gone then
        ns.On("BAG_UPDATE_DELAYED", "Destroy", bags)
    else
        ns.Off("BAG_UPDATE_DELAYED", "Destroy")
    end
    if offered then
        ns.On("MODIFIER_STATE_CHANGED", "Destroy", later)
    else
        ns.Off("MODIFIER_STATE_CHANGED", "Destroy")
    end
end

-- The words beside the picture of Y.
local function say(text)
    legend.Set({ { keys = { "Y" }, text = text } })
end

-- The hold is over: the bar goes, the words are the ones at rest, and no frame is drawn any more.
local function rest()
    held, full = nil, false
    bar:SetPart(0)
    say(armed and Model.AGAIN or Model.WORDS)
    prompt:SetScript("OnUpdate", nil)
end

-- The prompt goes. The key goes back to the player: now, or after the fight when the game has
-- locked the binds already.
local function hide(why)
    if not offered then
        return
    end
    -- the key first: a fault in what comes after must not leave Y with us
    ns.Queue.Run("DestroyKey", function()
        ns.Adapter.GiveKeys(button)
    end)
    note("the prompt for " .. Model.Title(offered) .. " went: " .. why)
    offered, armed = nil, false
    rest()
    prompt:Hide()
    listen()
    ns.Send("destroy:shown", false)
end

-- Who has Y now. Returns a few words for the log.
local function claim()
    if not offered or ns.Adapter.InCombat() then
        return "nobody asked"
    elseif not free() then
        hide("a window took the controller")
        return "a window has the controller"
    end
    local lt, rt, lb, rb = ns.Adapter.Held()
    if lt or rt or lb or rb then
        rest()
        ns.Adapter.GiveKeys(button)
        return "a layer button is held: Y is that layer's"
    elseif held then
        return "a hold runs: Y stays as it is"
    end
    -- given back and taken again, so that it is the newest bind on that button
    ns.Adapter.GiveKeys(button)
    return ns.Adapter.TakeKey(button, "Y") and "set" or "not set: " .. tostring(ns.Adapter.EffectiveBinding(ns.Adapter.KEY.Y))
end

-- A trigger or LB went down or up: who has Y is looked at one step later, when the controller's
-- own state has the button. Many of these in one step make one look.
function later()
    if offered and not due then
        due = true
        C_Timer.After(0, function()
            due = false
            ns.Call("Destroy", claim)
        end)
    end
end

-- The prompt stays ten seconds from now.
local function stay()
    came = came + 1
    local mine = came
    C_Timer.After(Model.STAY, function()
        if mine == came and offered then
            ns.Call("Destroy", hide, "ten seconds went by")
        end
    end)
end

-- The item is destroyed. Only press, below, calls this, and only for a press DOWN of Y. The
-- answer is the bags' next change. When none comes in two seconds the destroy counts as not
-- done, so that a new prompt can come: full bags that stay full send no change.
local function destroy()
    local thing = offered
    local ok, why, refused = ns.Adapter.DestroyBagItem(thing)
    note("Y pressed once more: " .. (ok and "the destroy was asked for" or "nothing was destroyed: " .. tostring(why)))
    if ok then
        gone = thing
        C_Timer.After(Model.ANSWER, function()
            if gone == thing then
                gone = nil
                ns.Call("Destroy", function()
                    note("no answer to the destroy of " .. Model.Title(thing) .. " in " .. Model.ANSWER .. " seconds: the bag slot still holds it")
                    listen()
                end)
            end
        end)
        hide("its destroy was asked for")
        return
    end
    hide(tostring(why))
    if refused then
        dead = true
        ns.Print(Model.REFUSED)
    end
end

-- The bags changed. After a destroy: when the slot is empty the chat says so, and the loot is
-- asked for again; a slot that still holds the item waits for the next change. While the prompt
-- shows: bags with room again need no prompt.
function bags()
    if gone then
        if ns.Adapter.BagSlotHolds(gone) then
            return
        end
        local thing = gone
        gone = nil
        local again = looting and ns.Adapter.LootAgain() or 0
        note("after the destroy of " .. Model.Title(thing) .. " the bag slot is free; loot is open: " .. tostring(looting)
            .. ", loot slots asked for again: " .. again)
        ns.Print(Model.Line(thing, coins(thing)))
    elseif offered and ns.Adapter.FreeBagSlots() > 0 then
        hide("the bags have room again")
    end
    listen()
end

-- Loot did not fit: the cheapest gray item is offered. One step later Y is taken, so that it
-- is the newest bind on that button. Bags with nothing to offer are read one time for a loot:
-- auto loot sends the error for each thing that does not fit.
local function offer()
    if offered or gone or none or dead or not ns.Registry.Get("helpers.destroy_gray") or ns.Adapter.InCombat() or ns.fightStarted then
        return
    elseif not free() then
        if not awayTold then
            awayTold = true
            note("the bags are full while another window has the controller: nothing is offered")
        end
        return
    elseif #ns.Adapter.Rolls() > 0 then
        parked = parked or GetTime() + Model.STAY
        once("wait", "the prompt waits: a roll card shows")
        return
    end
    local things = ns.Adapter.BagThings()
    local thing = Model.Cheapest(things)
    if not thing then
        none = true
        note("the bags are full and no gray item can be offered (" .. #things .. " things in the bags)")
        return
    end
    local worthy, grays, most = Model.Worthy(ns.Adapter.LootThings(), thing)
    if not worthy then
        none = true
        once("worth", "nothing offered: the loot holds " .. grays .. " gray worth " .. ns.RestockModel.Coins(most)
            .. ", the cheapest gray in the bags is worth " .. coins(thing))
        return
    end
    offered, armed = thing, false
    icon:SetIcon(thing.icon)
    title:SetText(Model.Title(thing))
    value:SetText(Model.Value(coins(thing)))
    say(Model.WORDS)
    prompt:Show()
    stay()
    listen()
    ns.Send("destroy:shown", true)
    C_Timer.After(0, function()
        ns.Call("Destroy", function()
            if offered == thing then
                note("offered " .. Model.Title(thing) .. " worth " .. coins(thing) .. " (item " .. thing.id .. ", bag " .. thing.bag .. " slot " .. thing.slot
                    .. "); Y reads " .. claim())
            end
        end)
    end)
end

-- The rolls changed, one step after the game's word. A roll over the prompt makes it wait; when the last roll ends,
-- a prompt that waits shows while the loot is open and its ten seconds last.
local function rolled()
    soon = false
    local up = #ns.Adapter.Rolls() > 0
    if offered and up then
        hide("a roll card shows")
        parked = GetTime() + Model.STAY
    elseif parked and not up then
        local due = looting and GetTime() <= parked
        parked = nil
        if due then
            offer()
        end
    end
end

-- The work of the prompt's update script, each frame during a hold: the bar grows. When it is
-- full the prompt is ready for the press that destroys, the words say the next step, and the
-- prompt's ten seconds begin again: a player who holds wants it. A short press does not make
-- it stay.
local function grow()
    local seconds = GetTime() - held
    bar:SetPart(math.max(seconds / Model.HOLD, 0.001))
    if Model.Full(seconds) and not full then
        full, armed = true, true
        say(Model.LET_GO)
        stay()
    end
end

-- (a fault here would come every frame: it is logged once, and the hold stops)
local function tick(self)
    if not ns.Call("Destroy", grow) then
        held = nil
        self:SetScript("OnUpdate", nil)
    end
end

-- Y went down or up while the prompt shows. A let-go ends a hold and does nothing more,
-- whatever the hold was. A press down after a full hold is the one place that destroys.
local function press(down)
    if not offered then
        return
    elseif not down then
        rest()
        return
    end
    -- a held layer button: the press was for a bind of that layer, not for the prompt
    local lt, rt, lb, rb = ns.Adapter.Held()
    if lt or rt or lb or rb then
        return
    elseif armed then
        destroy()
        return
    end
    -- (one line a session: the press came through our bind, in play or in the loot window)
    if not heard then
        heard = true
        note("Y went down on the prompt: a hold began (" .. (ns.Pad.Gameplay() and "in play" or "in the loot window") .. ")")
    end
    held = GetTime()
    bar:SetPart(0.001)
    prompt:SetScript("OnUpdate", tick)
end

function Destroy.OnLogin()
    prompt, button, bar, legend, title, value, icon = ns.DestroyDraw.Build(function(down)
        ns.Call("Destroy", press, down)
    end)
    local function failed(_, message)
        if ns.Adapter.BagsFullError(message) then
            offer()
        end
    end
    -- the error text is heard while loot is open, out of a fight, with the row on
    local function hear()
        if looting and ns.Registry.Get("helpers.destroy_gray") and not (ns.fightStarted or ns.Adapter.InCombat()) then
            ns.On("UI_ERROR_MESSAGE", "Destroy", failed)
        else
            ns.Off("UI_ERROR_MESSAGE", "Destroy")
        end
    end
    -- a new loot, or the end of one: the bags are read again at the next error
    local function loot(open)
        looting, none, parked = open, false, nil
        hear()
    end
    ns.On("LOOT_OPENED", "Destroy", function()
        loot(true)
    end)
    -- the loot is closed: a destroy could not get it back, and Y is for the next window
    ns.On("LOOT_CLOSED", "Destroy", function()
        loot(false)
        hide("the loot was closed")
    end)
    -- a fight starts: the prompt goes and the key goes back while the game still allows it
    ns.On("PLAYER_REGEN_DISABLED", "Destroy", function()
        parked = nil
        hear()
        hide("a fight started")
    end)
    ns.On("PLAYER_REGEN_ENABLED", "Destroy", hear)
    ns.Listen("setting", "Destroy", function(key)
        if key == "helpers.destroy_gray" then
            hear()
            if not ns.Registry.Get(key) then
                hide("the row was turned off")
            end
        end
    end)
    -- a window took or gave the controller and set its own binds: in play and in the loot
    -- window Y is taken anew, to be the newest; any other window ends the prompt
    ns.Listen("pad:stack", "Destroy", claim)
    -- a watched trigger went down or up (the bind core tells of it)
    ns.Listen("hold", "Destroy", later)
    -- a roll card showed or went: looked at one step later, when the game has drawn its frames
    ns.Adapter.OnRollsChanged(function()
        if (offered or parked) and not soon then
            soon = true
            C_Timer.After(0, function()
                ns.Call("Destroy", rolled)
            end)
        end
    end)
end
