-- Upgrade arrows: a small green arrow at the top left of a piece of gear that is better than
-- what the character wears in that place. It shows on the items of the bags, of the loot window
-- and of a loot roll. Screen/UpgradeModel.lua says what "better" means. Gear for later (a
-- piece held back by its level alone, better at that level) gets the arrow dim, with the level
-- in small type, in the bags and the loot window; at that level it is the plain arrow.
--
-- An arrow is a frame of ours with one picture, made a child of the game's item button, so it
-- moves, hides and fades with that button. Nothing is written on the game's button. A button
-- that the game protects gets no arrow (Core/AdapterUpgrade.lua leaves it out), so no arrow can
-- be locked in a fight.
--
-- The arrows are worked out when the game says that something changed, and only for a window
-- that shows: a bag window opens, the bags change while one is open, the loot list is drawn, a
-- roll comes, the worn gear or the level changes. Many changes in one step make one look, a
-- step later, when the game has drawn its buttons. An item that the game has not loaded gets no
-- arrow yet; the game's word that an item is loaded makes a new look, and that word is heard
-- only while an item waits.
--
-- The log (kind "upgrades") has which picture the arrow is, the class the stats are weighed for,
-- what each window showed, and for each item one line: the game's numbers and stats for it, the
-- game's names of the stats that are not weighed, the game's answer to "can the character use
-- it", and why it has an arrow or none.
local _, ns = ...

local Upgrades = ns.Module("Upgrades", { "upgrades" }, "Gear Upgrade Indicator")
ns.Upgrades = Upgrades

local Model = ns.UpgradeModel

local SOURCES = { "bags", "loot", "rolls" }
local MAX_NOTES = 30    -- lines for the log in one session
local DIM = 0.5         -- the strength of the arrow of gear for later
local on = false        -- the row Gear Upgrade Indicator is on
local marks = { bags = {}, loot = {}, rolls = {} }   -- our arrows, by the kind of window they sit in
local due, timed = {}, false    -- the sources to look at in the next step, and if that step is asked for
local waits = {}        -- the sources that show an item the game has not loaded yet
local worn              -- what the character wears; nil when it must be read again
local weights           -- the class's weights of the stats (Screen/UpgradeModel.lua), nil for the item level alone
local picture           -- which picture the arrow is, for the log
local told, notes = {}, 0

local function note(key, text)
    if not told[key] and notes < MAX_NOTES then
        told[key], notes = true, notes + 1
        ns.Log.Add("upgrades", text)
    end
end

-- An item's stats for its log line: ", stats agi 5 sta 3" and "; not weighed: <the game's names>".
local function statsText(item)
    local text = ""
    if item.stats then
        local list = {}
        for stat in pairs(item.stats) do
            list[#list + 1] = stat
        end
        table.sort(list)
        for n, stat in ipairs(list) do
            list[n] = stat .. " " .. ("%g"):format(item.stats[stat])
        end
        text = ", stats " .. table.concat(list, " ")
    end
    return text .. (item.other and "; not weighed: " .. item.other or "")
end

local function arrow()
    local mark = CreateFrame("Frame", nil, UIParent)
    mark.art = mark:CreateTexture(nil, "OVERLAY")
    mark.art:SetPoint("TOPLEFT")
    picture = ns.Adapter.UpgradeArt(mark.art)
    note("picture", "the arrow is " .. picture)
    return mark
end

-- The level of gear for later in small type at the right of the arrow (made the first time
-- one is needed), and the arrow dim; with nil the plain arrow.
function Upgrades.Later(art, text, later)
    art:SetAlpha(later and DIM or 1)
    if text then
        text:SetText(later or "")
    end
end

local function laterText(mark)
    if not mark.levelText then
        local Theme = ns.Theme
        mark.levelText = mark:CreateFontString(nil, "OVERLAY")
        mark.levelText:SetFont(Theme.font.text, Theme.px(Theme.size.tiny), "OUTLINE")
        mark.levelText:SetTextColor(Theme.Color("white"))
        mark.levelText:SetPoint("LEFT", mark.art, "RIGHT", 1, 0)
    end
    return mark.levelText
end

-- The arrows of one kind of window, for what it shows now.
local function draw(source, level)
    local list, used = marks[source], 0
    local spots, seen = {}, nil
    if on then
        spots, seen = ns.Adapter.UpgradeSpots(source)
    end
    waits[source] = nil
    for _, spot in ipairs(spots) do
        local item = ns.Adapter.Gear(spot.link)
        if item then
            -- what the character wears is read only now, when a window shows a piece of gear
            worn = worn or ns.Adapter.WornGear()
            local better, why, wait = Model.Better(item, worn, level, weights)
            waits[source] = waits[source] or wait
            -- gear for later: in the bags and the loot window, not on a roll
            local later, reason = nil, nil
            if not better and source ~= "rolls" then
                later, reason = Model.Later(item, worn, level, weights)
            end
            -- (the line is put together only when the log will take it)
            if not wait and not told[item.id] and notes < MAX_NOTES then
                note(item.id, "item " .. item.id .. " (" .. tostring(item.class) .. "." .. tostring(item.sub) .. " " .. item.place .. ", item level "
                    .. tostring(item.level) .. ", asks for level " .. tostring(item.needs) .. ", the game says usable " .. tostring(item.wearable)
                    .. ", use effect " .. tostring(item.use) .. (item.needs and item.needs > level and ", the game says only the level stops it "
                    .. tostring(item.soon) or "") .. statsText(item) .. "): " .. (better and "arrow, " or later and "later arrow at level "
                    .. later .. ", " .. reason .. "; now " or "no arrow, ") .. why)
            end
            if better or later then
                used = used + 1
                list[used] = list[used] or arrow()
                local mark = list[used]
                mark:SetParent(spot.frame)
                mark:ClearAllPoints()
                mark:SetAllPoints(spot.frame)
                mark:SetFrameLevel(spot.frame:GetFrameLevel() + 2)
                Upgrades.Later(mark.art, (later or mark.levelText) and laterText(mark), later)
                mark:Show()
            end
        end
    end
    for n = used + 1, #list do
        list[n]:Hide()
    end
    local key = seen and source .. ": " .. seen
    if key and not told[key] and notes < MAX_NOTES then
        note(key, key .. ", " .. used .. " arrows")
    end
    return seen ~= nil
end

local changed

-- One look: the arrows of every source that is due. The bags' own event is heard only while
-- a bag window shows, and the game's word for a loaded item only while an item waits.
local function look()
    timed = false
    local sources = due
    due = {}
    local level = ns.Adapter.CharacterLevel()
    for _, source in ipairs(SOURCES) do
        if sources[source] then
            local shows = draw(source, level)
            if source == "bags" then
                if shows then
                    ns.On("BAG_UPDATE_DELAYED", "Upgrades", function()
                        changed("bags")
                    end)
                else
                    ns.Off("BAG_UPDATE_DELAYED", "Upgrades")
                end
            end
        end
    end
    if waits.bags or waits.loot or waits.rolls then
        -- a worn item can be the one that waits: it is read again at the next look
        worn = nil
        ns.On("GET_ITEM_INFO_RECEIVED", "Upgrades", function()
            for _, source in ipairs(SOURCES) do
                if waits[source] then
                    changed(source)
                end
            end
        end)
    else
        ns.Off("GET_ITEM_INFO_RECEIVED", "Upgrades")
    end
end

-- Something changed for a source, or for all of them with no name. The look is one step later.
function changed(source)
    for _, name in ipairs(SOURCES) do
        due[name] = due[name] or source == nil or source == name
    end
    if not timed then
        timed = true
        C_Timer.After(0, function()
            ns.Call("Upgrades", look)
        end)
    end
end

-- The mark of one piece (Adapter.Gear) on a view of ours, the Dialogue View's reward tiles: true
-- for the arrow, a level for the dim arrow of gear for later, nil for none, and nil for all
-- while the row Gear Upgrade Indicator is off. The same rule and weights as the bags.
function Upgrades.Judge(gear, worn, level)
    return on and (Model.Better(gear, worn, level, weights) or Model.Later(gear, worn, level, weights)) or nil
end

function Upgrades.OnLogin()
    -- the class does not change in a session: its weights are read once
    local class = ns.Adapter.CharacterClass()
    weights = class and Model.WEIGHTS[class]
    note("class", weights and "the arrows weigh the stats for " .. class or "no weights for the class " .. tostring(class) .. ": item level only")
    local function all()
        worn = nil
        changed()
    end
    local function turn()
        local now = ns.Registry.Get("helpers.upgrade_arrows")
        if now ~= on then
            on = now
            -- with the row off the game's events are not heard at all; the look hides the arrows
            for _, event in ipairs({ "PLAYER_EQUIPMENT_CHANGED", "PLAYER_LEVEL_UP" }) do
                if on then
                    ns.On(event, "Upgrades", all)
                else
                    ns.Off(event, "Upgrades")
                end
            end
            if on then
                ns.On("LOOT_SLOT_CHANGED", "Upgrades", function()
                    changed("loot")
                end)
            else
                ns.Off("LOOT_SLOT_CHANGED", "Upgrades")
            end
            all()
        end
    end
    ns.Adapter.OnUpgradeSpotsChanged(function(source)
        if on then
            changed(source)
        end
    end)
    ns.Listen("setting", "Upgrades", function(key)
        if key == "helpers.upgrade_arrows" then
            turn()
        end
    end)
    turn()
end
