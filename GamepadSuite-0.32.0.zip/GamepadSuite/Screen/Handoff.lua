-- Trackpad and Touch: the pointer comes free when the mouse, a trackpad or the touch screen is
-- used, and it stays the player's until the controller is used again.
--
-- This game plays with the stick as the camera, and for that it hides and locks the mouse
-- pointer. By itself it gives the pointer back only after the controller has been at rest for a
-- time, and a controller with a gyro, or with a trackpad that acts as a stick, is never at rest
-- (ControllerForever's notes say so; the idea of this hand-off is from there, the code is ours).
-- So the addon decides. A mouse button that goes down, or the pointer moved by hand while it is
-- free, makes the pointer the player's: from then on the lock is taken off each frame, but not
-- while a mouse button is down (a drag with the right button turns the camera). A button newly
-- pressed or a stick newly pushed gives the stick back to the camera (Screen/HandoffModel.lua).
-- The game's own wait is held short too, so that a controller at rest gives the pointer back fast.
--
-- The watch rests while nothing can start the hand-off. While the game has the pointer locked,
-- only a mouse button can, and the game tells of a mouse button: nothing is looked at then. The
-- watch wakes at that word, and at the game's words that can mean "the pointer is free now". It
-- looks at the pointer (20 times a second) only while the pointer is free, and at each frame
-- only while the pointer is the player's. A free pointer that does not move for two seconds lets
-- it rest again. A hand that then moves the pointer onto or off a unit or a thing of the world
-- wakes it: the game tells of that, and the pointer is not where it was when the watch rested
-- (a unit that walks under a still pointer is no hand). A move over empty ground needs a tap.
--
-- No frame of ours takes a stick or a button here. The controller is only looked at, so a
-- press that ends this state still does its own job. It works in a fight too: a tap on a fixed
-- slot must.
local _, ns = ...

local Handoff = ns.Module("Handoff", { "handoff", "padButtons" }, "Trackpad and Touch")
ns.Handoff = Handoff

local Model = ns.HandoffModel

local LOOK = 0.05      -- seconds between two looks while the pointer is free and not the player's
local QUIET = 2        -- seconds the pointer can be free and still, and not the player's, before the watch rests
local NONE = {}        -- the controller, at a look where it is not asked

local frame
local on = false       -- the setting
local state = Model.New()
local now = {}         -- what one look sees (Model.Look)
local click            -- the mouse button that went down since the last look
local lastX, lastY     -- where the pointer was at the last look
local restX, restY     -- where it was when the watch rested, if a look had read it
local since = 0        -- seconds since the last look
local woke             -- the game's word that woke the watch, until the next look
local quiet = 0        -- seconds the pointer has been free and still, and not the player's
local relocks = 0      -- frames in a row at which the game had locked the pointer again
local told, lines = {}, 0

-- One line for each kind of thing that happens, the first time in a session: what made the
-- pointer the player's, what gave it back, which word of the game told that the pointer came
-- free, and what the game said at that time. Read from the saved file.
local function note(kind, text)
    if not told[kind] and lines < 12 then
        told[kind], lines = true, lines + 1
        ns.Log.Add("handoff", text .. "; " .. ns.Adapter.HandoffState())
    end
end

-- The watch rests: its frame hides, and a hidden frame's update script does not run.
local function rest()
    restX, restY = lastX, lastY
    state.moves, lastX, woke, quiet = 0, nil, nil, 0
    frame:Hide()
end

local function look()
    local gap = since
    since = 0
    if ns.Pointer and ns.Pointer.IsOn() then
        -- mouse mode has the pointer, and takes the lock off itself
        state, click = Model.New(), nil
        return rest()
    end
    now.locked = ns.Adapter.PointerLocked()
    if now.locked and not state.on and not click then
        -- the game has the pointer for the camera, and no mouse button went down: nothing can
        -- start the hand-off until the game tells of one
        return rest()
    end
    if woke and not now.locked and not state.on then
        note("woke" .. woke, "the pointer is free, and the game told of it with " .. woke)
    end
    woke = nil
    local x, y = ns.Adapter.PointerPlace()
    now.click = click
    now.moved = lastX and math.max(math.abs(x - lastX), math.abs(y - lastY)) or 0
    lastX, lastY, click = x, y, nil
    -- The mouse buttons and the controller are asked only when their answer counts: while the
    -- pointer is the player's, at a press of a mouse button, and when the pointer moved.
    local stirred = now.moved > Model.MOVE
    now.held = stirred and not state.on and (ns.Adapter.PointerHeld("LeftButton") or ns.Adapter.PointerHeld("RightButton")) or false
    local ask = state.on or now.click or stirred
    now.buttons = ask and ns.Adapter.PadState() or NONE
    now.pushes = ask and ns.Adapter.StickPushes() or NONE
    local change, why = Model.Look(state, now)
    if change then
        note(change .. why, "the hand-off " .. change .. ": " .. why)
    end
    -- each frame: the game locks the pointer again as soon as the controller stirs
    -- (ControllerForever frees its trackpad pointer this way on this game. Mouse mode found the
    -- game holding the pointer while the controller moves, so the log tells when the lock comes
    -- back at every frame: then a walk while tapping does not keep the pointer free.)
    if state.on and ns.Adapter.PointerFree() then
        note("free", "the pointer was locked for the camera and is set free")
        relocks = relocks + 1
        if relocks == 20 then
            note("relock", "the game locked the pointer again at 20 frames in a row, and it was set free at each")
        end
    else
        relocks = 0
    end
    quiet = (state.on or stirred) and 0 or quiet + gap
    if quiet >= QUIET then
        rest()
    end
end

-- The game told of something that can start the hand-off: the watch looks again.
local function wake(why)
    if on and not frame:IsShown() then
        woke = why
        frame:Show()
    end
end

-- The watch can run while the setting is on. For that time the game's own wait is held short.
local function apply()
    on = ns.Registry.Get("controller.pointer_handoff") and true or false
    state, click = Model.New(), nil
    rest()
    ns.Adapter.PointerWait(on)
    wake()
end

function Handoff.OnLogin()
    -- a frame with nothing to show: it is there for its update script, which runs while it is shown
    frame = CreateFrame("Frame")
    frame:SetScript("OnUpdate", function(self, elapsed)
        since = since + elapsed
        if not state.on and not click and since < LOOK then
            return
        end
        -- a fault here would come every frame: it is logged once and the watch stops. Nothing
        -- is held, so the game has its pointer and its sticks as it had before.
        if not ns.Call("Handoff", look) then
            self:SetScript("OnUpdate", nil)
            state = Model.New()
        end
    end)
    ns.On(ns.Adapter.MOUSE_DOWN, "Handoff", function(button)
        -- (a click of mouse mode's own is not a hand on the mouse)
        if Model.Begins(button) and not (ns.Pointer and ns.Pointer.IsOn()) then
            click = button
            wake()
        end
    end)
    -- The game's words that can mean "the pointer is free now": the lock for the camera ended,
    -- the controller is not the device in use any more, the world came in. (An event this game
    -- version does not have is left out.) A window that takes the controller frees the pointer too.
    for _, event in ipairs(ns.Adapter.POINTER_FREED) do
        pcall(ns.On, event, "Handoff", function()
            wake(event)
        end)
    end
    -- The pointer went onto or off a unit or a thing of the world: the watch wakes when the
    -- pointer is free and not where it was at its last look, so a hand moved it. (With the
    -- camera stick the pointer is locked, and nothing wakes.)
    for _, event in ipairs(ns.Adapter.POINTER_OVER) do
        pcall(ns.On, event, "Handoff", function()
            if on and not frame:IsShown() and not ns.Adapter.PointerLocked() then
                local x, y = ns.Adapter.PointerPlace()
                if not restX or math.max(math.abs(x - restX), math.abs(y - restY)) > Model.MOVE then
                    wake(event)
                end
            end
        end)
    end
    ns.Listen("pad", "Handoff", function()
        wake("a window")
    end)
    ns.Listen("setting", "Handoff", function(key)
        if key == "controller.pointer_handoff" then
            apply()
        end
    end)
    -- (a reload: the game's own wait is let go first)
    ns.On("PLAYER_LOGOUT", "Handoff", function()
        ns.Adapter.PointerWait(false)
    end)
    apply()
end
