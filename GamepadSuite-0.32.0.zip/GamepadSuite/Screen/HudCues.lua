-- The cues on the on-screen buttons in a fight (the page Button Alerts of the Buttons tab):
--   Proc Glow: a gold glow inside the edge of a button whose spell the game lights (Overpower
--   after a dodge), for any rank of that spell.
--   Interrupt Glow: a red glow inside the edge of an interrupt while the enemy target casts
--   something that can be stopped. It stays dark while the interrupt's own cooldown runs.
--   Gray While Cooling: the picture is gray while its action cools down (the short cooldown of
--   every cast does not count).
--   Flash When Ready: one quick flash when that cooldown ends.
-- Every button of HudFace.lua has them: the main buttons of each look and the fixed slots. The
-- small pictures of the other layers get the two glows (HudMini.lua). The rules are in
-- HudCueModel.lua, the game's answers in Core/AdapterCue.lua. No timer and nothing each frame:
-- the game's events, the end of a cooldown frame, and the flash's animation while it plays. No
-- cooldown number is read: the game shows the gray copy only while its cooldown frame runs, the
-- same way as the dark of the small pictures. Pack: build_plan/packs/P15_button_cues.md.
local _, ns = ...

local Cue = ns.Module("ButtonCues", { "buttonCues" }, "Button Alerts")
ns.HudCues = Cue

local Theme, Widgets, Model = ns.Theme, ns.Widgets, ns.HudCueModel
local px = Theme.px

-- The parts of each button and small picture that has cues (it -> its parts). Weak: a thing that
-- is gone takes its parts with it.
local parts = setmetatable({}, { __mode = "k" })
-- the four rows, as the registry has them
local ROWS = { proc = "screen.proc_glow", kick = "screen.interrupt_glow", gray = "screen.gray_cooling", flash = "screen.flash_ready" }
local on = {}
-- the spells the game lights now (spell number -> key) and their keys; the target's cast
local litIds, lit = {}, {}
local cast = { casting = false, enemy = false }
-- the game's names of the interrupts (Model.KICKS); the log's lines of this session
local kicks, told = {}, {}

local function note(what, text)
    if not told[what] then
        told[what] = true
        ns.Log.Add("cues", text)
    end
end

local function read()
    for name, key in pairs(ROWS) do
        on[name] = ns.Registry.Get(key) and true or false
    end
end

-- A glow inside the edge of a picture, in the look's shape: the strips of Model.Strips, in a color
-- of the Theme (name), added as light (so it shows on an icon of its own color too). A button also gets a rim in that
-- color, as wide as the rim of an action in progress, made as HudFace makes its rims: a texture
-- behind the picture in the look's shape. A small picture has no room for one.
local function makeGlow(p, name)
    local color = Theme.color[name]
    local glow, frame = {}, p.frame or p.host.over
    if p.host then
        local b, width = p.host, p.look.run
        local rim = b:CreateTexture(nil, "BACKGROUND", nil, 1)
        rim:SetColorTexture(color[1], color[2], color[3], 1)
        rim:SetPoint("TOPLEFT", b, "TOPLEFT", -px(width), px(width))
        rim:SetPoint("BOTTOMRIGHT", b, "BOTTOMRIGHT", px(width), -px(width))
        ns.HudFace.Shape(rim, p.look, p.size + 2 * width)
        glow[5] = rim
    end
    for i, strip in ipairs(Model.Strips(p.size)) do
        local t = frame:CreateTexture(nil, p.layer)
        t:SetColorTexture(1, 1, 1, 1)
        t:SetBlendMode("ADD")
        t:SetGradient(strip.orient, CreateColor(color[1], color[2], color[3], strip.min), CreateColor(color[1], color[2], color[3], strip.max))
        t:SetPoint(strip.points[1], p.art, strip.points[1])
        t:SetPoint(strip.points[2], p.art, strip.points[2])
        if strip.width then
            t:SetWidth(px(strip.width))
        else
            t:SetHeight(px(strip.height))
        end
        ns.HudFace.Shape(t, p.look, p.size, p.art)
        glow[i] = t
    end
    return glow
end

-- Shows or hides one glow ("procGlow" or "kickGlow"); it is made at its first use. The interrupt
-- glow takes its strength from the game's "cannot be stopped", which can be hidden.
local function show(p, which, yes)
    local glow = p[which]
    if yes and not glow then
        glow = makeGlow(p, which == "procGlow" and Model.PROC or Model.KICK)
        p[which] = glow
    end
    for _, t in ipairs(glow or {}) do
        t:SetShown(yes)
        if yes and which == "kickGlow" and ns.Adapter.KickAlpha(t, cast.locked) then
            note("hidden", "whether the target's cast can be stopped is hidden from the addon: the value went to the game's SetAlphaFromBoolean")
        end
    end
end

-- Is the interrupt's own cooldown running? Adapter.Cooling leaves out the short cooldown of every
-- cast. In combat the game can hide the numbers: then only its word in its cooldown event about
-- this spell is sure (about: what that event named), and a cooldown it was sure of stays until the
-- game says it cools no more or the second cooldown frame ends (done).
local function cooling(p, about)
    if p.coolBind then
        local active, _, sure = ns.Adapter.Cooling(p.coolBind, about)
        p.cooling = active and (sure or p.cooling) or false
    end
end

-- Sets both glows of one button or small picture; true when its gold glow shows.
local function paint(p, about)
    cooling(p, about)
    local proc, kick = Model.Glows(on, p, lit, cast)
    show(p, "procGlow", proc)
    show(p, "kickGlow", kick)
    p.shows = proc or kick
    if kick then
        note("kick", "an interrupt glows: the enemy target casts something that can be stopped")
    elseif p.cooling and on.kick and cast.casting and cast.enemy then
        note("dark", "an interrupt was left dark: its cooldown runs")
    end
    return proc
end

-- The game lit a spell, or the target's cast changed: the glows are set again, and nothing else
-- is drawn. Gives how many gold glows show.
local function pass()
    local count = 0
    for _, p in pairs(parts) do
        if p.key or p.isKick or p.shows then
            count = count + (paint(p) and 1 or 0)
        end
    end
    return count
end

-- The cooldown ended (the game runs this at the end of the second cooldown frame, as its own
-- cooldown viewer does, CooldownViewer.lua 718 and 773): an interrupt glows again, and one quick
-- flash. Not while the addon sets or clears that frame itself (a new bind, a layer, a redraw).
local function done(p)
    if p.setting then
        return
    end
    if p.cooling then
        p.cooling = false
        paint(p)
    end
    if not (Cue.on and on.flash) then
        return
    end
    if not p.flash then
        local t = p.host.over:CreateTexture(nil, "ARTWORK", nil, 7)
        t:SetColorTexture(Theme.Color("white"))
        t:SetBlendMode("ADD")
        t:SetAllPoints(p.art)
        -- (seen only while the animation plays)
        t:SetAlpha(0)
        ns.HudFace.Shape(t, p.look, p.size)
        p.flash = t:CreateAnimationGroup()
        local fade = p.flash:CreateAnimation("Alpha")
        fade:SetFromAlpha(Model.FLASH.from)
        fade:SetToAlpha(0)
        fade:SetDuration(Model.FLASH.seconds)
    end
    p.flash:Stop()
    p.flash:Play()
    local fight = ns.Adapter.InCombat()
    note(fight and "flash fight" or "flash", "a cooldown ended and its button flashed, " .. (fight and "in a fight" or "out of a fight")
        .. ": the game ran the end of the cooldown frame")
end

-- The parts a button has from the start (HudFace.Make): a second cooldown frame between the
-- picture and the cooldown, which gets the action's cooldown without the short one of every cast.
-- It draws nothing of its own; it holds the gray copy of the picture, and its end is the flash.
function Cue.Make(b, look, size)
    local cooldown = CreateFrame("Cooldown", nil, b.icon, "CooldownFrameTemplate")
    cooldown:SetDrawSwipe(false)
    cooldown:SetDrawEdge(false)
    cooldown:SetDrawBling(false)
    cooldown:SetHideCountdownNumbers(true)
    cooldown:SetFrameLevel(b.icon:GetFrameLevel() + 1)
    b.cooldown:SetFrameLevel(math.max(b.cooldown:GetFrameLevel(), cooldown:GetFrameLevel() + 1))
    local gray = cooldown:CreateTexture(nil, "ARTWORK")
    gray:SetAllPoints(b.icon.art)
    gray:SetDesaturated(true)
    ns.HudFace.Shape(gray, look, size)
    local p = { host = b, art = b.icon.art, look = look, size = size, layer = "BORDER", cooldown = cooldown, gray = gray }
    cooldown:SetScript("OnCooldownDone", function() done(p) end)
    parts[b] = p
end

-- A small picture of another layer (HudMini.lua): the two glows, on its holder frame.
function Cue.Small(mini, holder, look, size)
    parts[mini] = { frame = holder, art = mini.art, look = look, size = size, layer = "OVERLAY" }
end

-- A button or a small picture shows a bind (HudFace.Fill, HudMini.lua): what its cues read from
-- it. icon: the button's picture, for the gray copy.
function Cue.Fill(it, bind, icon)
    local p = parts[it]
    if not p then
        return
    end
    if p.gray then
        Widgets.Art(p.gray, icon or nil)
    end
    local spell = Cue.on and bind and ns.Adapter.CueSpell(bind) or nil
    p.key = spell and ns.Adapter.SpellKey(spell, true) or nil
    p.isKick = Cue.on and bind and (spell and kicks[ns.Adapter.SpellKey(spell) or ""] or ns.Adapter.KickSlot(bind)) or false
    -- the interrupt's spell, for its cooldown (a slot of the game's bar by the spell in it). The
    -- same spell keeps what the game said of it: a redraw in combat (a layer) loses nothing.
    if not (p.isKick and spell) then
        p.coolBind, p.cooling = nil, false
    elseif not p.coolBind or p.coolBind.id ~= spell then
        p.coolBind, p.cooling = { kind = "spell", id = spell }, false
    end
    -- a spell that was lit before this draw (a reload in the middle of a proc)
    if p.key and on.proc and not lit[p.key] and ns.Adapter.SpellLit(spell) then
        litIds[spell] = p.key
        lit = Model.LitKeys(litIds)
    end
    paint(p)
end

-- A cooldown began or ended (HudFace.Cool): the second frame gets the action's cooldown again,
-- while Gray While Cooling or Flash When Ready is on, and on an interrupt for the end of its
-- cooldown; an interrupt's glow is set again.
function Cue.Cool(b)
    local p = parts[b]
    if not p then
        return
    end
    local feed = Cue.on and (on.gray or on.flash or p.coolBind ~= nil) and b.bind and true or false
    p.setting = true
    if feed then
        ns.Adapter.ShowCooldown(p.cooldown, b.bind, true)
    elseif p.fed then
        p.cooldown:Clear()
    end
    p.setting, p.fed = false, feed
    p.gray:SetShown(on.gray == true)
    if p.coolBind then
        paint(p)
    end
end

function Cue.OnLogin()
    read()
    local function names()
        for _, id in ipairs(Model.KICKS) do
            kicks[ns.Adapter.SpellKey(id) or ""] = true
        end
        kicks[""] = nil
    end
    names()
    local function target()
        cast.casting, cast.locked = ns.Adapter.TargetCast()
        cast.enemy = ns.Adapter.EnemyTargeted()
        pass()
    end
    ns.Adapter.OnSpellLit("ButtonCues", function(spell, lights)
        if spell then
            litIds[spell] = lights and ns.Adapter.SpellKey(spell, true) or nil
            lit = Model.LitKeys(litIds)
            local count = pass()
            if lights and count > 0 then
                note("lit", "the game lit spell " .. spell .. " (" .. tostring(litIds[spell]) .. "): " .. count .. " buttons glow")
            end
        end
    end)
    ns.Adapter.OnTargetCast("ButtonCues", target)
    -- the game's word on a cooldown, with the spell it names: an interrupt cast in combat goes dark
    ns.Adapter.OnSpellCooldown("ButtonCues", function(about)
        for _, p in pairs(parts) do
            if p.coolBind then
                paint(p, about)
            end
        end
    end)
    -- a loading screen ends every lit spell
    ns.On("PLAYER_ENTERING_WORLD", "ButtonCues", function()
        litIds, lit = {}, {}
        names()
        target()
    end)
    ns.Listen("setting", "ButtonCues", function(key)
        for _, row in pairs(ROWS) do
            if key == row then
                read()
                pass()
            end
        end
    end)
    target()
end
