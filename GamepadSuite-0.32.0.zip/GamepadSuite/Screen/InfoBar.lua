-- The info bar: a thin strip at the top edge of the screen with the money, the free bag slots, the state of the gear,
-- the zone and the place on the map ("Westfall, Sentinel Hill  52.0, 30.0"), the experience ("61% toward 24"), the latency and the frames per second, and "Automation
-- paused" first while Pause Automation holds the automation (the message "automation:paused", and
-- ns.Automation.Paused() at a full read where that module is there). It has no box: a soft dark ground
-- that thins out downward and toward both ends, the readings, and one short hairline. The look
-- is the approved sample (mockups/infobar_sample.py); the two art files are made by code
-- (tools/art/make_infobar.py). What each reading says is in InfoModel.lua.
--
-- Each reading is asked of the game when the game says that it changed: the money at the game's
-- word on money, the gear at its word on wear or on a piece put on, the experience at its word on experience or on
-- a level (PLAYER_XP_UPDATE, PLAYER_LEVEL_UP), the zone at its word on a new zone or place (ZONE_CHANGED, its
-- _INDOORS and _NEW_AREA: MapDocumentation.lua 650 to 667). The numbers of the place, the latency and
-- the frames change all the time and the game sends no word for them: those three are read once
-- a second, and only while the strip shows. The second is the game's: an animation of one second
-- on the strip that does nothing and starts again, so nothing of ours runs between two seconds.
-- A text, a mark or a place on the strip is set only when it is another one than before.
--
-- The hearthstone pip, at the right end, is the hearthstone's own picture, round and small. It shows
-- while the hearthstone is in the bags and ready, and it is gone while it cools down. It follows the
-- game's word on a cooldown or on the bags (BAG_UPDATE_COOLDOWN, BAG_UPDATE_DELAYED) and the end of
-- a fight. The game says nothing when a cooldown ends, so one timer waits for that end: the only
-- timer of the strip, and it exists only while a cooldown is in view. In a fight the game can hide
-- the numbers of a cooldown: then the pip keeps what it showed, and the known end decides
-- (InfoModel.Hearth). The log (kind "hearth") has the first changes of the pip and the game's word
-- that told of each.
local _, ns = ...

local Bar = ns.Module("InfoBar", nil, "Info Bar")
ns.InfoBar = Bar

local Theme, Model = ns.Theme, ns.InfoModel
local px = Theme.px

local ART = "Interface\\AddOns\\GamepadSuite\\Art\\"
local MASK = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
-- where each mark sits in the picture of the four marks, from the left
local MARK = { gear = 0, place = 1, latency = 2, frames = 3 }
local COIN = { Theme.color.gold, { 0.788, 0.776, 0.741 }, { 0.725, 0.467, 0.298 } }   -- gold (the Theme's), silver, copper
local COINS = { "gold", "silver", "copper" }
-- the free bag slots show the game's own backpack, round and small as the hearthstone pip (the marks are drawn art)
local BAG = "Interface\\Buttons\\Button-Backpack-Up"

local frame
local values = {}       -- the game's last answers: money, gear, x, y, latency, frames
local pool = { text = {}, mark = {}, coin = {}, pip = {} }
local used = { text = 0, mark = 0, coin = 0, pip = 0 }
-- what each piece is now, so that only a change is set: its words and their width, its size and
-- colour, its mark, its place from the left, and if it shows
local wrote, wide, styled, markOf, at, up = {}, {}, {}, {}, {}, {}
local x, rowWidth, groundWidth = 0, nil, nil
local GROUND = 800      -- the width of the dark ground in the approved sample
local beat, beating     -- the one-second animation that is the clock, and if it plays
local hearth            -- what the hearthstone pip knows: { ready =, ends = } (InfoModel.Hearth)
local hearthEnd         -- the end of the cooldown that the one timer waits for
local hearthNotes = 0   -- lines of the pip in the log
local zoneTold = false  -- the log has the first zone text

-- One more piece of a kind, made the first time it is needed.
local function piece(kind, make)
    used[kind] = used[kind] + 1
    local list = pool[kind]
    list[used[kind]] = list[used[kind]] or make(used[kind])
    return list[used[kind]]
end

local function newText()
    return Theme.Text(frame.row, "tiny", "cream")
end

local function newMark()
    local mark = frame.row:CreateTexture(nil, "ARTWORK")
    mark:SetTexture(ART .. "InfoBarGlyphs.tga")
    mark:SetVertexColor(Theme.Color("gold"))
    -- the mark is drawn in the middle three quarters of its cell
    mark:SetSize(px(Model.MARK * 4 / 3), px(Model.MARK * 4 / 3))
    return mark
end

-- A round picture: a texture seen through the game's round mask.
local function round(size)
    local row = frame.row
    local picture = row:CreateTexture(nil, "ARTWORK")
    picture.mask = row:CreateMaskTexture()
    picture.mask:SetTexture(MASK, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    picture.mask:SetAllPoints(picture)
    picture:AddMaskTexture(picture.mask)
    picture:SetSize(px(size), px(size))
    return picture
end

-- (the coins come in threes: gold, silver, copper)
local function newCoin(index)
    local colour = COIN[(index - 1) % 3 + 1]
    local coin = round(Model.COIN)
    coin:SetColorTexture(colour[1], colour[2], colour[3], 1)
    return coin
end

-- The pip: the game's item pictures have a dark edge, which is left out.
local function newPip()
    local pip = round(Model.PIP)
    pip:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    return pip
end

-- Puts a piece at the place the row has come to, and moves on by its width and a gap.
local function put(region, width, gapAfter)
    if at[region] ~= x then
        at[region] = x
        region:ClearAllPoints()
        region:SetPoint("LEFT", frame.row, "LEFT", x, 0)
    end
    if not up[region] then
        up[region] = true
        region:Show()
    end
    x = x + width + px(gapAfter)
end

local function text(words, size, colour, gapAfter)
    local t = piece("text", newText)
    local style = size .. colour
    if styled[t] ~= style then
        styled[t], wrote[t] = style, nil
        t:SetFont(Theme.font.text, px(Theme.size[size]), "")
        t:SetTextColor(Theme.Color(colour))
    end
    if wrote[t] ~= words then
        wrote[t] = words
        t:SetText(words)
        wide[t] = t:GetStringWidth()
    end
    put(t, wide[t], gapAfter)
end

-- Puts the pieces of every reading in one row, from the left edge of the row; the row is as
-- wide as its pieces and stands in the middle.
local function draw()
    used.text, used.mark, used.coin, used.pip = 0, 0, 0, 0
    x = 0
    for index, reading in ipairs(Model.Readings(values)) do
        if index > 1 then
            x = x + px(Model.GAP)
        end
        if reading.mark == "money" then
            for i, name in ipairs(COINS) do
                put(piece("coin", newCoin), px(Model.COIN), 5)
                text(tostring(reading[name]), "tiny", "cream", i < 3 and 10 or 0)
            end
        elseif reading.mark == "bags" then
            local pip = piece("pip", newPip)
            if markOf[pip] ~= BAG then
                markOf[pip] = BAG
                pip:SetTexture(BAG)
            end
            put(pip, px(Model.PIP), 5)
            text(reading.text, "tiny", "cream", 3)
            text(reading.unit, "tiny", "muted", 0)
        elseif reading.mark == "hearth" then
            local pip = piece("pip", newPip)
            if markOf[pip] ~= reading.icon then
                markOf[pip] = reading.icon
                pip:SetTexture(reading.icon)
            end
            put(pip, px(Model.PIP), 0)
        elseif reading.mark == "paused" then
            text(reading.text, "tiny", "gold", 0)
        else
            -- (the experience has no mark: the four marks are drawn art)
            if MARK[reading.mark] then
                local mark = piece("mark", newMark)
                if markOf[mark] ~= reading.mark then
                    markOf[mark] = reading.mark
                    mark:SetTexCoord(MARK[reading.mark] * 0.25, MARK[reading.mark] * 0.25 + 0.25, 0, 1)
                end
                put(mark, px(Model.MARK * 4 / 3), 5)
            end
            text(reading.text, "tiny", reading.color or "cream", reading.unit and (reading.unit:sub(1, 1) == "%" and 1 or 3) or 0)
            if reading.unit then
                text(reading.unit, "tiny", reading.color or "muted", 0)
            end
        end
    end
    for kind, list in pairs(pool) do
        for i = used[kind] + 1, #list do
            if up[list[i]] then
                up[list[i]] = false
                list[i]:Hide()
            end
        end
    end
    if x ~= rowWidth then
        rowWidth = x
        frame.row:SetWidth(math.max(x, 1))
        -- the dark ground is at least the approved width, and a long row (paused, the experience) is three
        -- quarters of it at most, so its first and last words still stand on the dark (mockups/small_sample.py)
        local ground = math.max(px(GROUND), x / 0.75)
        if ground ~= groundWidth then
            groundWidth = ground
            frame:SetWidth(ground)
        end
    end
end

-- The three readings that the game sends no word for.
local function tick()
    values.x, values.y = ns.Adapter.MapPlace()
    values.latency, values.frames = ns.Adapter.Latency(), ns.Adapter.FrameRate()
    draw()
end

-- The clock for them: once a second, and only while the strip shows.
local function run(on)
    if on and not beating then
        beat:Play()
    elseif not on and beating then
        beat:Stop()
    end
    beating = on and true or false
end

local hearthChanged  -- (below)

-- Asks the game about the hearthstone and keeps the one timer for the end of its cooldown. Gives
-- true when the pip is another one than before. why is what told of it, for the log.
local function readHearth(why)
    local item, icon, cooling, ends = ns.Adapter.Hearth()
    local now = GetTime()
    local wait
    hearth, wait = Model.Hearth({ item = item, cooling = cooling, ends = ends }, hearth, now)
    if not wait then
        hearthEnd = nil
    elseif hearth.ends ~= hearthEnd then
        local mine = hearth.ends
        hearthEnd = mine
        C_Timer.After(wait, function()
            -- (a timer for a cooldown that is not the one in view does nothing)
            if hearthEnd == mine then
                hearthEnd = nil
                ns.Call("InfoBar", hearthChanged, "the end of the cooldown")
            end
        end)
    end
    local pip = hearth.ready and icon or nil
    if pip == values.hearth then
        return false
    end
    values.hearth = pip
    hearthNotes = hearthNotes + 1
    if hearthNotes <= 6 then
        local known = cooling == nil and "the game does not tell" or cooling and "cooling" or "no cooldown"
        ns.Log.Add("hearth", (pip and "ready" or "gone") .. ": item " .. tostring(item) .. ", " .. known .. ", told by " .. why)
    end
    return true
end

-- The game says that a cooldown or the bags changed, or the timer for the end of a cooldown ran out.
function hearthChanged(why)
    if frame:IsShown() and ns.Adapter.Hearth and readHearth(why) then
        draw()
    end
end

-- The experience as the game says it now. level: the game's word of a new level, which its own UnitLevel can lag.
local function experience(level)
    if not ns.Adapter.Experience then
        return nil
    end
    local now, most, at, top, off, rested = ns.Adapter.Experience()
    return { now = now, most = most, level = level or at, top = top, off = off, rested = rested }
end

-- Reads everything and draws the strip: at login, when the world comes in, when the switch changes.
function Bar.Update()
    local on = ns.Registry.Get("screen.info_bar")
    frame:SetShown(on)
    run(on)
    if on then
        values.money, values.gear = ns.Adapter.Money(), ns.Adapter.GearWear()
        values.bags = ns.Adapter.BagSpace and ns.Adapter.BagSpace() or nil
        values.xp = experience()
        values.zone = ns.Adapter.ZoneText and Model.Zone(ns.Adapter.ZoneText()) or nil
        if ns.Automation and ns.Automation.Paused then
            values.paused = ns.Automation.Paused() and true or nil
        end
        if ns.Adapter.Hearth then
            readHearth("a full read")
        end
        tick()
    end
end

-- One reading changed, the game says: only that one is asked.
local function onChange(name, ask)
    return function()
        if frame:IsShown() then
            values[name] = ask()
            draw()
        end
    end
end

function Bar.OnLogin()
    frame = CreateFrame("Frame", "GamepadSuiteInfoBar", UIParent)
    frame:SetFrameStrata("LOW")
    frame:SetSize(px(GROUND), px(Model.STRIP))
    frame:SetPoint("TOP", UIParent, "TOP", 0, 0)
    local fade = frame:CreateTexture(nil, "BACKGROUND")
    fade:SetTexture(ART .. "InfoBarFade.tga")
    fade:SetAllPoints()
    -- the hairline: gold that fades out toward both ends
    local r, g, b = 0.839, 0.698, 0.384
    local parts = { { 0.45, 0, 0.5 }, { 0.10, 0.5, 0.5 }, { 0.45, 0.5, 0 } }
    local left = -px(Model.LINE) / 2
    for _, part in ipairs(parts) do
        local line = frame:CreateTexture(nil, "BORDER")
        line:SetColorTexture(1, 1, 1, 1)
        line:SetGradient("HORIZONTAL", CreateColor(r, g, b, part[2]), CreateColor(r, g, b, part[3]))
        line:SetSize(px(Model.LINE * part[1]), 1)
        line:SetPoint("TOPLEFT", frame, "TOP", left, -px(Model.LINE_AT))
        left = left + px(Model.LINE * part[1])
    end
    frame.row = CreateFrame("Frame", nil, frame)
    frame.row:SetHeight(px(Model.ROW))
    frame.row:SetPoint("TOP", frame, "TOP", 0, 0)
    beat = frame:CreateAnimationGroup()
    beat:CreateAnimation("Animation"):SetDuration(1)
    beat:SetLooping("REPEAT")
    beat:SetScript("OnLoop", function()
        -- a fault here would come every second: it is logged once and the clock stops
        if not ns.Call("InfoBar", tick) then
            run(false)
        end
    end)

    -- (an event this game version does not have is left out)
    pcall(ns.On, "PLAYER_MONEY", "InfoBar", onChange("money", ns.Adapter.Money))
    if ns.Adapter.BagSpace then
        pcall(ns.On, "BAG_UPDATE_DELAYED", "InfoBarBags", onChange("bags", ns.Adapter.BagSpace))
    end
    local gear = onChange("gear", ns.Adapter.GearWear)
    pcall(ns.On, "UPDATE_INVENTORY_DURABILITY", "InfoBar", gear)
    pcall(ns.On, "PLAYER_EQUIPMENT_CHANGED", "InfoBar", gear)
    pcall(ns.On, "PLAYER_XP_UPDATE", "InfoBar", onChange("xp", experience))
    -- (rested experience comes and goes: the colour follows)
    pcall(ns.On, "UPDATE_EXHAUSTION", "InfoBar", onChange("xp", experience))
    pcall(ns.On, "PLAYER_LEVEL_UP", "InfoBar", function(level)
        if frame:IsShown() then
            values.xp = experience(level)
            draw()
        end
    end)
    -- the zone and the place in it: the game's word for a new one (the log has the first one, so one walk tells)
    for _, event in ipairs(ns.Adapter.ZoneText and { "ZONE_CHANGED", "ZONE_CHANGED_INDOORS", "ZONE_CHANGED_NEW_AREA" } or {}) do
        pcall(ns.On, event, "InfoBarZone", function()
            if frame:IsShown() then
                values.zone = Model.Zone(ns.Adapter.ZoneText())
                draw()
                if values.zone and not zoneTold then
                    zoneTold = true
                    ns.Log.Add("screen", "zone text at " .. event .. ": " .. values.zone)
                end
            end
        end)
    end
    -- Pause Automation (true or false at each change): kept while the strip is off, drawn when it shows
    ns.Listen("automation:paused", "InfoBar", function(paused)
        values.paused = paused and true or nil
        if frame:IsShown() then
            draw()
        end
    end)
    -- (the end of a fight: the numbers that the game hid in it can be read again)
    for _, event in ipairs({ "BAG_UPDATE_COOLDOWN", "BAG_UPDATE_DELAYED", "PLAYER_REGEN_ENABLED" }) do
        pcall(ns.On, event, "InfoBar", function()
            hearthChanged(event)
        end)
    end
    ns.On("PLAYER_ENTERING_WORLD", "InfoBar", function()
        Bar.Update()
    end)
    ns.Listen("setting", "InfoBar", function(key)
        if key == "screen.info_bar" then
            Bar.Update()
        end
    end)
    Bar.Update()
end
