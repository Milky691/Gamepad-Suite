-- The swing clock of a next-swing attack. Heroic Strike, Cleave and Maul take the place of the
-- next swing of the main hand, so they land no sooner than that swing. After each swing of the
-- player's main hand, a button whose bind casts one of the three shows the cooldown sweep for the
-- length of one swing, from that swing. The game tells each swing and its full length
-- (PLAYER_SWING; its own swing bar counts down the same length: Blizzard_SwingTimer.lua,
-- ResetSwingTimer). The sweep goes on the button's clock alone: the gray and the flash of the cues
-- (Screen/HudCues.lua) read the real cooldown, and so does every other part. A line of the
-- cooldown list gets none. The spells are known by their names, so that every rank and every
-- language match. Raptor Strike is not one of them: it has a real cooldown of its own.
-- No timer: the swing is kept here, and the clock is drawn at each pass of the clocks (Face.Cool).
-- The row Next Melee Timer (Cooldowns tab) says when: Off, never (the start value); Queued, only while one of the three
-- waits for the swing, so the clock is the time to the swing that lands it; Always, after every swing.
local _, ns = ...

local Swing = {}
ns.HudSwing = Swing

-- Heroic Strike, Cleave and Maul; every rank of each has the same name
local SPELLS = { 78, 845, 6807 }
-- the main hand in the game's list of swings (SwingTimerDocumentation.lua, PlayerSwingType)
local MAIN_HAND = 0
local ROW = "cooldowns.next_melee"
-- the names of the three in the player's language; the last swing of the main hand
local names
local start, length = 0, 0
-- bind -> it casts one of the three; asked once for each bind in each swing, so a pass of the clocks in a fight asks the game little
local known = setmetatable({}, { __mode = "k" })

-- True for the name of one of the three. The names are read once the game gives all three.
local function nextSwing(name)
    if not names then
        local found = {}
        for _, spell in ipairs(SPELLS) do
            local key = ns.Adapter.SpellKey(spell)
            if not key then
                return false
            end
            found[key] = true
        end
        names = found
    end
    return name ~= nil and names[name] == true
end

-- True when a press of the bind casts one of the three now (a macro, a slot of the game's own
-- bar and a form's version of a spell too). A question the game does not answer means no.
local function casts(bind)
    if known[bind] == nil then
        local spell = ns.Adapter.CueSpell(bind)
        known[bind] = spell ~= nil and nextSwing(ns.Adapter.SpellKey(spell, true))
    end
    return known[bind]
end

-- True when the clock shows a real cooldown that ends after the swing. A value that the game
-- hides cannot be compared: then the swing shows.
local function longer(cooldown)
    local ok, yes = pcall(function()
        local from, ms = cooldown:GetCooldownTimes()
        if (from + ms) / 1000 > start + length then
            return true
        end
        return false
    end)
    return ok and yes
end

-- Each swing: its start and length. The game's values are plain on this build; a hidden one is
-- not kept (the comparison fails in the guarded call).
pcall(ns.On, "PLAYER_SWING", "HudSwing", function(duration, kind)
    pcall(function()
        if kind == MAIN_HAND and type(duration) == "number" and duration > 0 then
            start, length = GetTime(), duration
            known = setmetatable({}, { __mode = "k" })
        end
    end)
end)

-- Queued: one of the three was queued or let go. The game sends no cooldown event for that, so the clocks are drawn
-- again: the on-screen buttons, then the fixed slots and the rest (the message "screen:cool").
pcall(ns.On, "CURRENT_SPELL_CAST_CHANGED", "HudSwing", function()
    if ns.Registry.Get(ROW) == "Queued" and ns.Screen then
        ns.Screen.Each(ns.Screen.Cool)
        ns.Send("screen:cool")
    end
end)

-- Puts the swing on the button's clock, and on the arc of a button of Round, while the last swing
-- of the main hand runs and the bind casts one of the three. Called at the end of Face.Cool, after
-- the real cooldown: a real one that lasts longer stays. The sweep has no flash at its end (the
-- next swing comes at that moment); the flash is back for the button's next real cooldown.
function Swing.Show(b, arc)
    local mode = ns.Registry.Get(ROW)
    if mode ~= "Off" and not b.noShared and b.bind and GetTime() < start + length and casts(b.bind)
        and (mode ~= "Queued" or ns.Adapter.Running(b.bind)) and not longer(b.cooldown) then
        b.swinging = true
        pcall(function()
            b.cooldown:SetDrawBling(false)
            b.cooldown:SetCooldown(start, length)
            if arc then
                arc:SetCooldown(start, length)
            end
        end)
    elseif b.swinging then
        b.swinging = nil
        pcall(b.cooldown.SetDrawBling, b.cooldown, true)
    end
end
