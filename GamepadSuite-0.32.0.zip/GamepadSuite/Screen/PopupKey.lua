-- The key of the press grammar of the top pop-up (Screen/PopupHold.lua). Only after the let-go of a full hold (the act
-- is armed), out of combat, in play, the act's button is a priority key bind (Adapter.TakeKey) of the act's secure
-- button (the cast of Feed Pet, a weapon's slot) or of a plain button of ours, so the next press clicks it inside a
-- real press. Before that no key is taken: a tap stays the button's own bind (17_MASTERCLASS.md, the hold grammar).
-- It is given back one frame after that press, when the item goes, at once when combat starts, while a layer button
-- (LT, RT, LB, RB, or a modifier button) is held so that layer's bind runs, and while another part of ours holds that
-- button; it is taken again one frame after those two end, so it is the newest bind on that button.
local _, ns = ...

local Key = {}
ns.PopupKey = Key

local BUTTON = "GamepadSuitePopupKey"

local key             -- the plain button
local taking          -- { act, button } while a button of ours holds the act's button
local told = {}

local function note(kind, text)
    if not told[kind] then
        told[kind] = true
        ns.Log.Add("popups", text)
    end
end

-- The act whose button a button of ours holds now, and that button; nil while none.
function Key.Taking()
    return taking
end

-- True while a button of ours other than the press's own holds the game's key of ourKey (Destroy Gray Item has Y).
function Key.Others(ourKey)
    local now = ns.Adapter.taken and ns.Adapter.taken[ns.Adapter.KEY[ourKey]]
    return now ~= nil and not now:find("CLICK " .. BUTTON .. ":", 1, true)
        and not (taking and now:find("CLICK " .. taking.button:GetName() .. ":", 1, true))
end

-- The key goes back to the game (now, or after the fight when the game has locked the binds already).
function Key.Give()
    if taking then
        local button = taking.button
        taking = nil
        ns.Adapter.GiveKeys(button)
    end
end

-- The key goes back, and the modifier buttons are not heard any more: the armed act is over.
function Key.Stop()
    Key.Give()
    ns.Off("MODIFIER_STATE_CHANGED", "PopupKey")
end

-- Who has the key now. Given back and taken again, so that it is the newest bind on that button.
local function claim()
    local act = ns.PopupHold.Armed()
    if not act or ns.fightStarted or ns.Adapter.InCombat() or not ns.Popup.Free() then
        Key.Stop()
        return
    end
    -- (a modifier button that goes down or up: who has the key is looked at again, as Destroy Gray Item does)
    ns.On("MODIFIER_STATE_CHANGED", "PopupKey", Key.Later)
    local lt, rt, lb, rb = ns.Adapter.Held()
    if lt or rt or lb or rb or Key.Others(act.key) then
        Key.Give()
        return
    end
    local button = act.secure or key
    Key.Give()
    taking = { act = act, button = button }
    local set = ns.Adapter.TakeKey(button, act.key)
    note("take " .. button:GetName(), "the press grammar took " .. act.key .. " on " .. button:GetName() .. ": " .. tostring(set))
end

-- A look at who has the key, one frame later (after a press, a layer button, a window's own binds), and the hints.
local due = false
function Key.Later()
    if not due then
        due = true
        C_Timer.After(0, function()
            due = false
            ns.Call("PopupKey", function()
                claim()
                ns.PopupHold.Sync()
            end)
        end)
    end
end

-- A secure button of an act: its click by the press ends the act, and the key goes back.
local hooked = {}
function Key.Watch(button)
    if button and not hooked[button] then
        hooked[button] = true
        button:HookScript("PostClick", function()
            local act = taking and taking.button == button and taking.act
            if act then
                ns.PopupHold.Clicked(act)
            end
        end)
    end
end

-- Started by the pop-up at login (Screen/Popup.lua).
function Key.Start()
    key = CreateFrame("Button", BUTTON, UIParent)
    key:RegisterForClicks("AnyDown", "AnyUp")
    key:SetScript("OnClick", function(_, _, down)
        ns.Call("PopupKey", ns.PopupHold.Pressed, down)
    end)
    -- combat: the key goes back at the game's word, while the game still allows it
    ns.On("PLAYER_REGEN_DISABLED", "PopupKey", Key.Stop)
    ns.On("PLAYER_REGEN_ENABLED", "PopupKey", Key.Later)
    -- a window's own binds, a held trigger or LB, another part of ours that took or gave a key
    ns.Listen("pad:stack", "PopupKey", Key.Later)
    ns.Listen("hold", "PopupKey", Key.Later)
    -- (Core/AdapterPlay.lua says "keys" and the button's name at each TakeKey and GiveKeys: our own two kinds of
    -- button are left out, or each look would start the next one)
    ns.Listen("keys", "PopupKey", function(name)
        for button in pairs(hooked) do
            if button:GetName() == name then
                return
            end
        end
        if name ~= BUTTON then
            Key.Later()
        end
    end)
end
