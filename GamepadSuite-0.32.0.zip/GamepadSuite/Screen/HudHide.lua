-- Hide While Mounted and Hide While Resting (the page Fade and Hide of the Buttons tab): the
-- on-screen buttons go out of sight on a mount, in a travel form (Core/AdapterCue.lua Travel, the
-- forms of Auto Camera Zoom) or on a flight path, or in an inn or a city. They still
-- work: a press goes from the key to the bind core, not through these frames. They come back at
-- once in a fight or with an enemy as the target (Hud.lua's fade knows both), while a thing is
-- in reach (Dynamic Interact), and while the settings window or a wheel is open. Only the alpha of the buttons changes, as for Fade When
-- Idle, which a fight does not lock; the fixed slots and the cooldown list follow it. The rule is
-- HudCueModel.Hidden. The game's events drive it, merged in one frame; no clock.
local _, ns = ...

local Hide = ns.Module("HideButtons", { "hideButtons" }, "Hide While Mounted or Resting")
ns.HudHide = Hide

local Model = ns.HudCueModel

local switches, game = { mounted = false, resting = false }, { mounted = false, taxi = false, resting = false }
-- the settings window or a wheel is open; an update waits for the next frame; the log's lines
local opened, wheel, asked, told = false, false, false, {}

-- True while the buttons are out of sight by these two rows. busy: a fight, or an enemy target.
-- near: a thing is in reach, so the button of Dynamic Interact shows it (Hud.lua).
function Hide.Hidden(busy, near)
    return Hide.on and Model.Hidden(switches, game, busy, opened or wheel, near) or false
end

-- Runs fn, and tells the buttons (Hud.lua draws them again) when the answer changed.
local function change(fn)
    local before = Hide.Hidden(false)
    fn()
    local now = Hide.Hidden(false)
    if now ~= before then
        local what = now and "out of sight" or "back"
        if not told[what] then
            told[what] = true
            ns.Log.Add("hide", ("the on-screen buttons are %s: mounted %s, flight %s, resting %s, settings or wheel open %s"):format(what,
                tostring(game.mounted), tostring(game.taxi), tostring(game.resting), tostring(opened or wheel)))
        end
        ns.Send("screen:hide")
    end
end

-- What the game and the two rows say now.
local function update()
    asked = false
    change(function()
        switches.mounted, switches.resting = ns.Registry.Get("screen.hide_mounted") and true or false, ns.Registry.Get("screen.hide_resting") and true or false
        game.mounted, game.taxi, game.resting = ns.Adapter.Travel()
    end)
end

-- Many events can come together (a flight starts: the controls go, the flags change): one update,
-- on the next frame, when the game's answers are all in.
local function soon()
    if not asked then
        asked = true
        C_Timer.After(0, function()
            ns.Call("HideButtons", update)
        end)
    end
end

function Hide.OnLogin()
    ns.Adapter.OnTravel("HideButtons", soon)
    ns.Listen("settings:opened", "HideButtons", function() change(function() opened = true end) end)
    ns.Listen("settings:closed", "HideButtons", function() change(function() opened = false end) end)
    ns.Listen("wheel", "HideButtons", function(id) change(function() wheel = id and true or false end) end)
    ns.Listen("setting", "HideButtons", function(key)
        if key == "screen.hide_mounted" or key == "screen.hide_resting" then
            soon()
        end
    end)
    update()
end
