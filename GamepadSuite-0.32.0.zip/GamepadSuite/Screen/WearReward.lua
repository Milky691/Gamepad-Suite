-- Wear Quest Rewards. After a quest hand-in, a reward that gets the green arrow (Screen/UpgradeModel.lua, the class
-- weights) and lands in the bags gets one card above the on-screen buttons, in the place and look of the loot roll card
-- (Screen/Rolls.lua): the item's picture with the time left on it, its name in the colour of its quality, and the Y
-- picture with "Hold: wear it". Hold Y one second and let go: the piece is put on in the place the arrow compared it
-- with (the empty place, or the weaker ring, trinket or hand of two), and the game puts the old one in the bags. The
-- card goes after 10 seconds, at that let-go, or 60 seconds after the hand-in when it could not show. In combat it hides
-- and waits; after combat it shows again with 10 seconds of its own, while the piece is still better. B is not taken.
--
-- No key is taken, as on the roll card. A plain frame of ours hears each press of the controller while the card shows
-- and hands it on to the game (its switch is set out of combat), so a tap of Y does Y's bind as always and wears
-- nothing. The let-go is read from the controller's own state, one look a frame and only during a hold. The hold is
-- the roll card's (Screen/RollsModel.lua: a let-go between 1 and 2.5 seconds; a press with a layer button held, or in
-- the first 0.4 seconds of the card, does not count). The equip is the game's C_Item.EquipItemByName, which needs no
-- real press (Core/AdapterWear.lua), so the let-go makes it.
--
-- The card waits while play does not have the controller (a game window, the Dialogue View with the next quest, our
-- settings window), while a wheel, mouse mode or the keyboard is open, while a loot roll shows (its card has this
-- place, and so has the Destroy Gray Item prompt), while a whisper pop-up shows (its hold of Y replies), while the
-- game's controller interface is off, and in combat. Its 10 seconds start when it first shows (again after combat). Each
-- look checks that the piece is still in the bags and still better. The log (kind "wear") has the links read at a
-- hand-in, the offer, the call, and if the piece is worn one second later.
local _, ns = ...

local Wear = ns.Module("WearReward", { "upgrades", "wear" }, "Wear Quest Rewards")
ns.WearReward = Wear

local Model, Hold = ns.UpgradeModel, ns.RollsModel
local KEY = "windows.wear_rewards"
local TIME = 10                 -- the seconds the card shows
local LANDS = 5                 -- the seconds a reward has to land in the bags after the game's word
local WAIT = 60                 -- the seconds after the hand-in that a card that could not show yet still may
local LOW, GAP = 150, 8         -- the roll card's place: with no on-screen buttons LOW under the middle; GAP above them
local WORDS, LET_GO = "Hold: wear it", "Let go: wear it"
local MAX_NOTES = 12

local weights                   -- the class's weights of the stats
local links                     -- the reward links of the last hand-in, until the game says it went through
local coming                    -- { links, at }: a hand-in went through, its items are not in the bags yet
local offer                     -- the reward on the card: { link, id, icon, name, quality, place, handed (the hand-in), at
                                -- (its first show, nil again after combat), fought (it waited through combat) }
local held                      -- when Y went down for a hold, nil with no hold
local since = 0                 -- when the card showed
local ear, ready, card, icon, timer, name, legend, bar
local wheel, mouse, keyboard = nil, false, false
local waiting, said, notes, foughtTold = false, nil, 0, false
local changed, tick

local function note(text)
    notes = notes + 1
    if notes <= MAX_NOTES then
        ns.Log.Add("wear", text)
    end
end

local function enabled()
    return not ns.Registry.Has(KEY) or ns.Registry.Get(KEY) == true
end

-- The reward a link names, as it is in the bags now, when it is better than what is worn: the bag's item with the
-- place to wear it in. Else nil, and why for the log.
local function judge(link)
    local item = ns.Adapter.BagItem(link)
    local gear = item and ns.Adapter.Gear(item.link)
    if not gear then
        return nil, item and "no gear" or "not in the bags"
    end
    local better, why, _, place = Model.Better(gear, ns.Adapter.WornGear(), ns.Adapter.CharacterLevel(), weights)
    if not better then
        return nil, why
    end
    item.place = place
    return item, why
end

-- The bags and the worn gear are heard only while a reward is on its way or on the card.
local function listen()
    for _, event in ipairs({ "BAG_UPDATE_DELAYED", "PLAYER_EQUIPMENT_CHANGED" }) do
        if coming or offer then
            ns.On(event, "WearReward", changed)
        else
            ns.Off(event, "WearReward")
        end
    end
end

-- The words beside Y, and the bar of a hold: part is how far the hold is (1 or more: a let-go wears it).
local function shade(part)
    local text = part and part >= 1 and LET_GO or WORDS
    if text ~= said then
        said = text
        legend.Set({ { keys = { "Y" }, text = text } })
    end
    legend.items[1].keys.glyphs[1]:SetLit(part ~= nil)
    bar:SetPart(part and math.max(part, 0.001) or 0)
end

-- A hold starts now, or with nil it is over. The frame's update script is set only while a hold runs.
local function hold(at)
    held = at
    shade(at and 0 or nil)
    ear:SetScript("OnUpdate", at and tick or nil)
end

-- The card and the frame that hears the controller show, or hide. The 10 seconds start at the first show.
local function show(on)
    if on and not offer.at then
        offer.at = GetTime()
        local mine, at = offer, offer.at
        if mine.fought and not foughtTold then
            foughtTold = true
            ns.Log.Add("wear", "the card waited through a fight and shows now")
        end
        C_Timer.After(TIME, function()
            ns.Call("WearReward", function()
                -- (a card that combat hid has a new 10 seconds: this timer is not its own any more)
                if offer == mine and mine.at == at then
                    offer = nil
                    note("the card of item " .. mine.id .. " goes: its time is over")
                    show(false)
                    listen()
                end
            end)
        end)
        icon:SetIcon(offer.icon)
        name:SetText(offer.name or "")
        local r, g, b = ns.Adapter.DialogueQuality(offer.quality)
        if not r then
            r, g, b = ns.Theme.Color("white")
        end
        name:SetTextColor(r, g, b)
        -- the game's own clock runs the sweep and the seconds on the picture: nothing here each frame
        timer:SetCooldown(offer.at, TIME)
    end
    if on and not card:IsShown() then
        since = GetTime()
    end
    if not on and held then
        hold(nil)
    end
    card:SetShown(on)
    ear:SetShown(on)
end

-- A look. A reward on its way that is in the bags now becomes the offer; the offer is checked again; the card shows
-- when nothing else has the controller or this place.
local function sync()
    waiting = false
    if coming and GetTime() - coming.at > LANDS then
        coming = nil
    end
    -- (from the last link to the first: the chosen item, first in the list, wins over one given for sure)
    local found = false
    for n = #(coming and coming.links or {}), 1, -1 do
        local link = coming.links[n]
        if ns.Adapter.BagItem(link) then
            table.remove(coming.links, n)
            local item, why = judge(link)
            note("a reward in the bags: " .. (item and "offer item " .. item.id .. " for place " .. item.place .. ", " or "no card, ") .. why)
            if item then
                item.handed, item.fought = coming.at, ns.Adapter.InCombat()
            end
            offer, found = item or offer, found or item ~= nil
        end
    end
    if coming and (#coming.links == 0 or found) then
        coming = nil
    end
    if offer and not offer.at and GetTime() - offer.handed > WAIT then
        note("the card of item " .. offer.id .. " goes: " .. WAIT .. " seconds after the hand-in it could not show")
        offer = nil
    end
    if offer then
        local now = judge(offer.link)
        if now then
            offer.place = now.place
        else
            offer = nil
        end
    end
    listen()
    -- (a pop-up with a hold of Y, a whisper's reply: Y is the pop-up's while it shows, Screen/Popup.lua)
    local popup = ns.Popup and ns.Popup.Shown()
    local wait = not enabled() or ns.Adapter.InCombat() or not ns.Pad.Controller() or not ns.Pad.Gameplay()
        or wheel or mouse or keyboard or #ns.Adapter.Rolls() > 0 or not ready or popup and popup.key == "Y"
        or ns.Destroy and ns.Destroy.Shown()
    show(offer ~= nil and not wait)
end

function changed()
    if not waiting then
        waiting = true
        C_Timer.After(0, function()
            ns.Call("WearReward", sync)
        end)
    end
end

-- The let-go of a full hold: the piece goes on, and the card goes. One second later the log says if it is worn.
local function wear()
    local piece = offer
    if not piece or ns.Adapter.InCombat() then
        return
    end
    offer = nil
    show(false)
    listen()
    local ran, err = ns.Adapter.Wear(piece.link, piece.place)
    note("wear item " .. piece.id .. " in place " .. piece.place .. ": the call ran " .. tostring(ran) .. (err and ": " .. err or ""))
    C_Timer.After(1, function()
        ns.Call("WearReward", function()
            note("item " .. piece.id .. (ns.Adapter.WornID(piece.place) == piece.id and " is" or " is not") .. " worn in place "
                .. piece.place .. " 1 second after the call")
        end)
    end)
end

-- A button went down, as the frame heard it. Any press ends a hold. Y starts one, but not in the first moment of the
-- card, nor with a layer button held: that press was for a bind of the layer. While another part of ours holds Y (the
-- Destroy Gray Item prompt, Core/AdapterPopups.lua KeyTaken) a hold of Y is that part's.
local function press(key)
    if held then
        hold(nil)
    end
    if key ~= "Y" or not Hold.Ready(GetTime(), since) or ns.Adapter.KeyTaken("Y") then
        return
    end
    local lt, rt, lb, rb = ns.Adapter.Held()
    if not (lt or rt or lb or rb) then
        hold(GetTime())
    end
end

-- Each frame during a hold: the bar grows. The let-go after a full hold wears the piece; a hold too long was for a
-- spell that casts again while its button is held, and ends with nothing.
local function update()
    local seconds = GetTime() - held
    local stage = Hold.Stage(seconds)
    if not ns.Adapter.ButtonDown("Y") then
        hold(nil)
        if stage == "ready" then
            wear()
        end
    elseif stage == "long" then
        hold(nil)
    else
        shade(seconds / Hold.HOLD)
    end
end

-- A fault here would come every frame: it is logged once, and the hold stops.
function tick(self)
    if not ns.Call("WearReward", update) then
        held = nil
        self:SetScript("OnUpdate", nil)
    end
end

-- The card, in the roll card's place and look: above the on-screen buttons (Screen/Hud.lua's frame), strata HIGH, a
-- dark ground with a gold edge, the picture (56) with the game's clock, the name, Y with its words, and the bar of a
-- hold along the foot.
local function build()
    local Theme, px = ns.Theme, ns.Theme.px
    card = CreateFrame("Frame", nil, UIParent)
    card:SetSize(px(380), px(96))
    card:SetFrameStrata("HIGH")
    local buttons = _G.GamepadSuiteScreen
    if buttons then
        card:SetPoint("BOTTOM", buttons, "TOP", 0, px(GAP))
    else
        card:SetPoint("CENTER", UIParent, "CENTER", 0, -px(LOW))
    end
    card:Hide()
    Theme.Fill(card, "BACKGROUND", Theme.Color("ground", 0.8)):SetAllPoints()
    for _, side in ipairs({ { "TOPLEFT", "TOPRIGHT" }, { "BOTTOMLEFT", "BOTTOMRIGHT" },
        { "TOPLEFT", "BOTTOMLEFT", true }, { "TOPRIGHT", "BOTTOMRIGHT", true } }) do
        local line = Theme.Fill(card, "OVERLAY", Theme.Color("gold"))
        line:SetPoint(side[1])
        line:SetPoint(side[2])
        if side[3] then
            line:SetWidth(px(2))
        else
            line:SetHeight(px(2))
        end
    end
    icon = ns.Widgets.Icon(card, px(56))
    icon:SetPoint("TOPLEFT", px(14), -px(14))
    timer = CreateFrame("Cooldown", nil, icon, "CooldownFrameTemplate")
    timer:SetAllPoints()
    timer:SetDrawEdge(false)
    timer:SetHideCountdownNumbers(false)
    name = Theme.Text(card, "row", "white")
    name:SetPoint("TOPLEFT", icon, "TOPRIGHT", px(12), -px(4))
    name:SetPoint("RIGHT", -px(12), 0)
    legend = ns.Widgets.Legend(card, "LEFT")
    legend:SetPoint("BOTTOMLEFT", icon, "BOTTOMRIGHT", px(12), 0)
    bar = ns.Widgets.HoldLine(card, 12)
    shade(nil)
end

function Wear.OnLogin()
    local class = ns.Adapter.CharacterClass()
    weights = class and Model.WEIGHTS[class]
    build()
    ear = CreateFrame("Frame", nil, UIParent)
    ear:SetFrameStrata("BACKGROUND")
    ear:SetSize(1, 1)
    ear:SetPoint("TOPLEFT")
    ear:Hide()
    ear:SetScript("OnGamePadButtonDown", function(_, button)
        ns.Call("WearReward", press, ns.Adapter.NAME[button])
        return true
    end)
    -- Until the switch that hands each press on reads as set, the frame never shows: it would keep every press.
    ns.Queue.Run("WearReward", function()
        ear:EnableGamePadButton(true)
        ready = ns.Adapter.HandSticksOn(ear)
        ns.Log.Add("wear", "the frame that hears the controller hands each press on to the game: " .. tostring(ready))
        changed()
    end)
    ns.Adapter.OnQuestReward(function(list)
        ns.Call("WearReward", function()
            links = enabled() and list or nil
            note("a hand-in: " .. #list .. " reward links")
        end)
    end)
    ns.On("QUEST_TURNED_IN", "WearReward", function()
        if links then
            coming, links = { links = links, at = GetTime() }, nil
            listen()
            changed()
        end
    end)
    -- combat: the card hides and waits, and its 10 seconds start again when it shows after combat
    ns.On("PLAYER_REGEN_DISABLED", "WearReward", function()
        if offer then
            offer.at, offer.fought = nil, true
        end
        show(false)
    end)
    ns.On("PLAYER_REGEN_ENABLED", "WearReward", changed)
    ns.Adapter.OnRollsChanged(changed)
    ns.Listen("popup:shown", "WearReward", changed)
    ns.Listen("destroy:shown", "WearReward", changed)
    ns.Listen("pad", "WearReward", changed)
    ns.Listen("wheel", "WearReward", function(id)
        wheel = id
        changed()
    end)
    ns.Listen("pointer", "WearReward", function(on)
        mouse = on
        changed()
    end)
    ns.Listen("keyboard", "WearReward", function(open)
        keyboard = open
        changed()
    end)
    ns.Listen("setting", "WearReward", function(key)
        if key == KEY then
            changed()
        end
    end)
end
