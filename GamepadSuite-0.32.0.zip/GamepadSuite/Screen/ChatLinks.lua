-- Last Link: a bind, in the list Game Menus. A mouse player clicks a link in chat; a pad player cannot. One press shows
-- the tooltip of the newest item, quest or spell link that came through chat, with who sent it and "1 of 5"; each
-- press shows the one before, up to the last five; a press on the oldest closes it. An item shows what is worn in its
-- place beside it, as the loot roll card does. A quest link says under the sender if the player is on that quest
-- ("You are on this quest", "Done before", "Not on it"). The rules are in Screen/ChatLinksModel.lua, the game calls in
-- Core/AdapterChatLinks.lua.
--
-- The hold (17 item 6): the press that opens the tooltip acts at the key down. While it shows, the step to an older
-- link comes at the let-go of a tap; held 1 to 2.5 seconds, the let-go opens the chat keyboard to whisper the sender
-- of the link in view (Screen/KeyboardChat.lua Chat.Reply, as the whisper pop-up's reply), and the tooltip closes. A
-- longer hold does nothing. Only a line with a typable sender has the hint "Hold: whisper Bob": none for loot, a
-- Battle.net whisper or the player's own line. In a fight the keyboard does not open: the hint reads "Whisper after
-- combat", dim, and the hold does nothing. The bar of the hold is drawn on the panel each frame during a hold only.
--
-- The links come from the chat events as text (Model.EVENTS), the player's own lines too, and stay in memory only. In a
-- dungeon or raid the game hides party and raid chat from addons: those lines are skipped, and loot lines still count.
--
-- It closes by itself 15 seconds after the last press (long enough to read an item with two worn items beside it; each
-- press starts the time again), when the character starts to move, and when a window takes the controller. Out of a
-- fight B closes it too: B is a key bind of a plain button of ours (Windows/ListLook.lua Look.Key), taken one frame
-- after the press that opened it, only while it shows and nothing else of the suite has the controller, and given back
-- at once when a fight starts. No frame of ours hears the controller. In a fight it shows the same (a tooltip of ours is
-- no protected thing), the bind steps through and closes, and the time and a step close it.
--
-- The log (kind "links") says once: the first link kept from each kind of chat, the first hidden line, the first show
-- of each kind of link in and out of a fight with the worn items beside it, each reason of a close, and B.
local _, ns = ...

local Links = ns.Module("ChatLinks", { "chatLinks" }, "Last Link")
ns.ChatLinks = Links

local Model = ns.ChatLinksModel
local BUTTON = "GamepadSuiteLastLink"
local CLICK = "CLICK " .. BUTTON .. ":LeftButton"
-- a rolled scroll: no other bind of the list Game Menus has it
local ART = "Interface\\Icons\\INV_Scroll_03"
local MAX_NOTES = 30   -- lines for the log in one session, each one once

local list = {}        -- the newest five links, newest first
local shown, place     -- while the tooltip shows: the copy of the list that the presses walk, and the place on it
local keys             -- the bind's own buttons, read at the press that showed it (nil: not known)
local tip              -- the tooltip's frame while it shows
local count = 0        -- each press and each close start a new count, so an old timer closes nothing
local hidden = 0       -- chat lines this session whose text the game hid
local you              -- the player's own name
local closeKey, panel, from, number, legend, state, bar
local holdAt           -- the bind went down at this time while the tooltip showed: told at the let-go
local due = false
local notes, told = 0, {}

local function note(text, once)
    if notes < MAX_NOTES and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("links", text)
    end
end

-- The bind list's entry (Core/Catalog.lua).
function Links.Bind()
    return { kind = "command", id = CLICK, name = "Last Link", detail = "Press for the newest chat link, again for older ones. Hold to whisper the sender", icon = ART }
end

-- The panel above the tooltip: its size, and the strip of hints as things are now (B is ours or not).
local function fit()
    local px = ns.Theme.px
    local entries = Model.Hints(keys, place, #shown, closeKey ~= nil and closeKey.Ours(), shown[place].who, ns.Adapter.InCombat())
    legend.Set(entries)
    legend:SetShown(entries[1] ~= nil)
    local wide = tip and tip:GetWidth() * tip:GetScale() or 0
    local line = state:IsShown() and 22 or 0
    panel:SetSize(math.max(wide, from:GetStringWidth() + number:GetStringWidth() + px(40), state:GetStringWidth() + px(20), legend:GetWidth() + px(20)),
        px((entries[1] and 70 or 36) + line))
end

-- The bar of a hold: drawn each frame while the bind is down on a link with a sender, out of a fight.
local function stopBar()
    panel:SetScript("OnUpdate", nil)
    bar:SetPart(0)
end
local function grow()
    local seconds = holdAt and GetTime() - holdAt or Model.LIMIT + 1
    if seconds > Model.LIMIT then
        stopBar()
    else
        bar:SetPart(math.max(math.min(seconds / Model.HOLD, 1), 0.001))
    end
end

-- One frame after the game's word, never inside a press: B is ours while the tooltip shows (not when the bind itself
-- is on B: B steps through then), and the strip follows.
local function look()
    due = false
    if closeKey then
        closeKey.Set(shown ~= nil and not (keys and keys[#keys] == "B"))
    end
    if shown then
        fit()
    end
end

local function later()
    if not due then
        due = true
        C_Timer.After(0, function()
            ns.Call("ChatLinks", look)
        end)
    end
end

local function close(why)
    if not shown then
        return
    end
    shown, place, tip, count, holdAt = nil, nil, nil, count + 1, nil
    stopBar()
    ns.Adapter.HideLinkTip()
    panel:Hide()
    ns.Off("PLAYER_STARTED_MOVING", "ChatLinks")
    note("closed: " .. why, "close " .. why)
    later()
end

-- The link at the place, its tooltip and the panel above it. A tooltip that does not show leaves the panel at the
-- tooltip's place, so the player can still step on.
local function show()
    local entry = shown[place]
    local worn
    tip, worn = ns.Adapter.ShowLinkTip(entry)
    from:SetText(entry.from)
    number:SetText(Model.COUNT:format(place, #shown))
    local quest = Model.QuestID(entry.link)
    local known = quest and ns.Adapter.QuestState(quest)
    state:SetText(known and Model.STATE[known] or "")
    state:SetShown(known ~= nil)
    if known then
        note("a quest link showed with the state: " .. known, "quest state")
    end
    panel:ClearAllPoints()
    if tip then
        panel:SetPoint("BOTTOMLEFT", tip, "TOPLEFT", 0, ns.Theme.px(4))
    else
        panel:SetPoint("BOTTOM", UIParent, "BOTTOM", 0, 80)
    end
    panel:Show()
    fit()
    local fight = ns.Adapter.InCombat()
    note(("%s link showed %s: %s"):format(entry.kind, fight and "in a fight" or "out of a fight",
        tip and (type(worn) == "number" and "worn items beside it: " .. worn or tostring(worn)) or "the tooltip did not show: " .. tostring(worn)),
        entry.kind .. tostring(fight))
end

-- The time starts again: 15 seconds with no press close it.
local function restart()
    count = count + 1
    local mine = count
    C_Timer.After(Model.SECONDS, function()
        if mine == count then
            ns.Call("ChatLinks", close, "after " .. Model.SECONDS .. " seconds with no press")
        end
    end)
end

-- The newest link opens (nothing shows), or the one before shows; on the oldest it closes.
local function step()
    local nextPlace = Model.Next(place, shown and #shown or #list)
    if not nextPlace then
        if shown then
            close("a press on the oldest one")
        else
            ns.Print(Model.EMPTY .. (hidden > 0 and Model.HIDDEN or ""))
        end
        return
    end
    if not shown then
        -- a link that comes while it shows waits for the next opening: "2 of 5" does not move
        shown = {}
        for i, one in ipairs(list) do
            shown[i] = one
        end
        ns.On("PLAYER_STARTED_MOVING", "ChatLinks", function()
            close("the character moved")
        end)
    end
    place = nextPlace
    show()
    restart()
    later()
end

-- A full hold was let go: the tooltip closes, and one frame later (out of the press) the chat keyboard opens to
-- whisper the sender. Not in a fight: the keyboard does not open in one.
local function whisper()
    local who = shown[place].who
    if not who or ns.Adapter.InCombat() then
        return
    end
    close("a hold whispered the sender")
    C_Timer.After(0, function()
        ns.Call("ChatLinks", function()
            local chat = ns.KeyboardChat
            local opened = chat and chat.Reply and chat.Reply(who, who) or false
            note("a hold of the bind opened the chat keyboard to whisper the sender: opened " .. tostring(opened), "whisper " .. tostring(opened))
            if not opened then
                ns.Print("Last Link (Game Menus) could not open the chat keyboard. Whisper in the game's chat.")
            end
        end)
    end)
end

-- The bind went down (down true) or up. Down with nothing shown opens the newest at once; down while it shows starts
-- a hold, which the let-go ends: a short one steps, a full one whispers.
local function press(down)
    if not down then
        local at = holdAt
        holdAt = nil
        stopBar()
        local act = at and shown and Model.Let(GetTime() - at)
        -- (once: the game sends the let-go of the bind, as it does for the bind core's held buttons, BindSecure.lua)
        if at then
            note("the let-go of the bind came: " .. tostring(act or "held too long"), "let-go")
        end
        if act == "step" then
            step()
        elseif act == "whisper" then
            whisper()
        end
        return
    end
    keys = ns.Adapter.KeysOf(CLICK)
    note("the bind's button, read at the press for the hint: " .. (keys and table.concat(keys, " + ") or "not known"), "keys " .. tostring(keys ~= nil))
    if not shown then
        step()
        return
    end
    holdAt = GetTime()
    restart()
    later()
    if shown[place].who and not ns.Adapter.InCombat() then
        bar:SetPart(0.001)
        panel:SetScript("OnUpdate", grow)
    end
end

-- A chat line. The rest of the event's words: language, channel, second name, flags, zone, index, the channel's name.
local function heard(event, text, name, ...)
    local plain, who = ns.Adapter.ChatLine(text, name)
    if not plain then
        hidden = hidden + 1
        note("a chat line came hidden from addons (" .. event .. "); the game's chat lock reads " .. tostring(ns.Adapter.ChatLocked()), "hidden")
        return
    end
    if not plain:find("|H", 1, true) then
        return
    end
    local channel = select(7, ...)
    local links = Model.Read(event, plain, who, you, type(channel) == "string" and channel or nil, ns.Adapter.ItemQuality)
    if links[1] then
        list = Model.Add(list, links)
        note("a link was kept from " .. event, event)
    end
end

-- The panel in the addon's look (Windows/ListLook.lua Panel): who sent it at the left, "1 of 5" at the right, the
-- strip of hints under them (Widgets.Legend).
local function build()
    local Theme, px = ns.Theme, ns.Theme.px
    panel = CreateFrame("Frame", BUTTON .. "Panel", UIParent)
    panel:SetFrameStrata("TOOLTIP")
    panel:Hide()
    ns.ListLook.Panel(panel)
    from = Theme.Text(panel, "body", "cream")
    from:SetPoint("TOPLEFT", px(10), -px(8))
    number = Theme.Text(panel, "small", "muted")
    number:SetPoint("TOPRIGHT", -px(10), -px(9))
    -- a quest link's state, under the sender
    state = Theme.Text(panel, "small", "muted")
    state:SetPoint("TOPLEFT", from, "BOTTOMLEFT", 0, -px(4))
    state:Hide()
    legend = ns.Widgets.Legend(panel, "LEFT")
    legend:SetPoint("BOTTOMLEFT", px(10), px(8))
    bar = ns.Widgets.HoldLine(panel, 4)
end

function Links.OnLogin()
    you = ns.Adapter.PlayerName()
    build()
    for event in pairs(Model.EVENTS) do
        ns.On(event, "ChatLinks", function(...)
            heard(event, ...)
        end)
    end
    -- the bind's secure button and B's plain one are made out of a fight: after a reload in one, when it ends
    ns.Queue.Run("ChatLinks", function()
        ns.Adapter.LinkButton(BUTTON, function(down)
            ns.Call("ChatLinks", press, down)
        end)
        closeKey = ns.ListLook.Key("ChatLinks", BUTTON .. "Close", "B", function(down)
            if down then
                close("B")
            end
        end, note)
        later()
    end)
    -- a window took the controller (a game window, the settings, the talk or vendor view)
    ns.Listen("pad", "ChatLinks", function(gameplay)
        if not gameplay then
            close("a window took the controller")
        end
    end)
    -- a fight starts (Look.Key gives B back at once) or ends; a wheel, the keyboard, Mouse Mode or a window came or went
    ns.On("PLAYER_REGEN_DISABLED", "ChatLinks", later)
    ns.On("PLAYER_REGEN_ENABLED", "ChatLinks", later)
    ns.ListLook.Watch("ChatLinks", later)
end
