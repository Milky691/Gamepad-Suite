-- Mouse mode's magnet: when the right stick comes back to the middle, the pointer slides onto the
-- nearest thing of an open window that takes a click, in a short eased move, and stays there. A
-- push of the stick moves it on as before. It is for the windows that the game's own controller
-- navigation does not reach, and it works in the others too. Never onto the world (a unit or the
-- ground): only a window's things and the suite's fixed slots count, and none is in reach over the world. Nothing happens
-- while a mouse button is down: that is a drag.
--
-- What counts, as ConsolePort's cursor counts it: a shown child of an open window that takes the
-- mouse and is a button, a check box, a text box or a slider, or that shows
-- something when the pointer is over it. A pointer that rests on such a thing stays there, so a
-- text box can still be clicked to type in it. A thing scrolled out of its list does not count.
--
-- The open windows are a list kept by the game's word, not looked for again and again: each window
-- that the game lists (its panels, the frames that Escape closes, its menus, the bags, the popups)
-- tells when it shows or hides, and a panel of an addon of the game's that loads late is heard when
-- the game shows it. The windows' things are read only when the stick comes to rest, and when a
-- window shows or hides while mouse mode is on and the stick rests.
--
-- The game allows a move of its own pointer at a word of the stick (the log says if it did): at the
-- word that the stick is back in the middle, that move goes straight to the end, so a click and the
-- thing's light are right at once. The picture slides there; the slide's frame runs each frame of
-- the slide only, a few frames.
local _, ns = ...

local Magnet = ns.Module("PointerMagnet", { "pointer", "pointerMagnet" }, "Pointer Magnet")
ns.PointerMagnet = Magnet

local Model = ns.PointerModel

-- the kinds of frame that take a click
local KINDS = { Button = true, CheckButton = true, EditBox = true, Slider = true }

local open, hooked = {}, {}  -- the windows that are open; those whose show and hide are heard
local on = false             -- mouse mode is on
local resting = true         -- the right stick is in the middle
local slide                  -- from x, from y, to x, to y, seconds since it began
local frame                  -- shows only while the picture slides: its script runs each frame then
local waiting = false        -- a window showed or hid: the look waits for the next frame
local notes = 0

-- A few lines each time mouse mode is on: what the magnet found, and what the game allowed.
local function note(text)
    if notes < 6 then
        notes = notes + 1
        ns.Log.Add("pointer", "magnet: " .. text)
    end
end

local function box(f)
    return ns.Adapter.FrameBox(f)
end

-- The things in a window, each with the window's layer. clip is the box of the nearest list
-- around them: what is scrolled out of it does not count.
local function walk(parent, layer, clip, things)
    for _, child in ipairs({ parent:GetChildren() }) do
        if not child:IsForbidden() and child:IsVisible() then
            local kind, place = child:GetObjectType(), box(child)
            if place and kind ~= "ScrollFrame" and child:IsMouseEnabled() and (KINDS[kind] or child:IsMouseMotionEnabled())
                and (not clip or Model.On((place[1] + place[3]) / 2, (place[2] + place[4]) / 2, clip)) then
                place.layer, place.frame = layer, child
                things[#things + 1] = place
            end
            walk(child, layer, (kind == "ScrollFrame" or child:DoesClipChildren()) and place or clip, things)
        end
    end
end

local function layerOf(f)
    return (Model.STRATA[f:GetFrameStrata()] or 0) * 100000 + f:GetFrameLevel()
end

-- The things of the open windows, and the windows' boxes: a window on a higher layer hides what
-- is under it. A window that cannot be read is passed over, and the log says so. The suite's fixed
-- slots count too (Screen/Slots.lua): the secure button over a slot runs it at a click, as a mouse
-- click on the slot does, so the aim clicks it ("fixed slot n" in its log line) and the magnet pulls.
local function look()
    local things, windows = {}, {}
    for n, tap in ipairs(ns.SlotView.Taps()) do
        local place = tap:IsVisible() and box(tap)
        if place then
            place.layer, place.frame, place.slot = layerOf(tap), tap, n
            things[#things + 1] = place
        end
    end
    for window in pairs(open) do
        local ok, fault = pcall(function()
            if window:IsVisible() then
                local layer = layerOf(window)
                local place = box(window)
                if place then
                    place.layer = layer
                    windows[#windows + 1] = place
                end
                walk(window, layer, nil, things)
            end
        end)
        if not ok then
            note("a window could not be read: " .. tostring(fault))
        end
    end
    return things, windows
end
-- (mouse mode's aim asks the same, to know what the pointer rests on: Screen/PointerAim.lua)
Magnet.Look = look

local function stop()
    slide = nil
    frame:Hide()
end

-- The stick came to rest, or a window showed or hid while it rests: the pointer slides onto the
-- nearest thing in reach, if there is one. Not during a slide, and not while a mouse button is down.
local function pull()
    if not (on and resting) or slide or ns.Adapter.PointerHeld("LeftButton") or ns.Adapter.PointerHeld("RightButton")
        or not ns.Registry.Get("controller.pointer_magnet") then
        return
    end
    local x, y = ns.Pointer.Spot()
    local things, windows = look()
    local _, _, scale = ns.Adapter.PointerSpace()
    local toX, toY = Model.Magnet(x, y, things, windows, Model.REACH * scale, Model.INSET * scale)
    if toX and (toX ~= x or toY ~= y) then
        -- (the frame shows first: a fault below then ends the slide at its first frame)
        slide = { x, y, toX, toY, 0 }
        frame:Show()
        local moved = ns.Pointer.MoveTo(toX, toY)
        ns.Pointer.Draw(x, y)
        note("open windows: " .. #windows .. ", things in them: " .. #things .. "; it slides " .. math.floor(math.sqrt((toX - x) ^ 2 + (toY - y) ^ 2))
            .. " units; the game's pointer went there at once: " .. tostring(moved))
    end
end

local function step(elapsed)
    slide[5] = slide[5] + elapsed
    local x, y, done = Model.Slide(slide[1], slide[2], slide[3], slide[4], slide[5])
    ns.Pointer.Draw(x, y)
    if done then
        stop()
    end
end

-- A window of the game showed or hid (its own script ran first). While mouse mode is on and the
-- stick rests, the magnet looks again one frame later: a window places itself as it shows.
local function changed(window)
    if not on then
        return
    end
    open[window] = window:IsVisible() or nil
    if resting and not waiting then
        waiting = true
        C_Timer.After(0, function()
            waiting = false
            ns.Call("PointerMagnet", pull)
            -- (and mouse mode's aim looks again: a window came or went under the pointer)
            if ns.PointerAim then
                ns.PointerAim.Later()
            end
        end)
    end
end

local function add(window)
    if not hooked[window] then
        hooked[window] = true
        ns.Adapter.OnShownOrHidden(window, changed)
    end
    open[window] = window:IsVisible() or nil
end

function Magnet.OnLogin()
    frame = CreateFrame("Frame")
    frame:Hide()
    frame:SetScript("OnUpdate", function(_, elapsed)
        -- a fault here would come each frame: it is logged once and the slide ends
        if not ns.Call("PointerMagnet", step, elapsed) then
            stop()
        end
    end)
    -- Mouse mode came on: the windows of the game that are there now are heard from now on, and
    -- the list of the open ones is made anew. It goes off (a fight, a wheel, B): a slide ends.
    ns.Listen("pointer", "PointerMagnet", function(now)
        on, resting = now, true
        stop()
        if on then
            notes = 0
            ns.Adapter.PointerWindows(add)
        end
    end)
    ns.Listen("pointer:stick", "PointerMagnet", function(rest)
        resting = rest
        if rest then
            pull()
        elseif slide then
            -- pushed during a slide: the pointer goes on from where the player sees it
            local x, y = Model.Slide(slide[1], slide[2], slide[3], slide[4], slide[5])
            stop()
            ns.Pointer.MoveTo(x, y)
        end
    end)
    -- (this runs inside the game's own code that shows the panel: a fault is logged, not thrown there)
    ns.Adapter.OnPanelShown(function(window)
        if on then
            ns.Call("PointerMagnet", add, window)
            changed(window)
        end
    end)
end
