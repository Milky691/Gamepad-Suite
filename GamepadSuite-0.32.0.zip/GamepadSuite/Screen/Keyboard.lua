-- The on-screen keyboard: a panel at the bottom of the screen, over everything, with which a
-- player who has only the controller types a text. The D-pad or the left stick moves the focus
-- from key to key, A types the key, X deletes a letter, Y is a space, LT held shows the capital
-- letters and more marks, Menu or the key Done ends it, B cancels. On a chat line LB held is voice
-- to text (Screen/KeyboardVoice.lua). The panel itself is in
-- Screen/KeyboardDraw.lua, the rules in Screen/KeyboardModel.lua.
--
-- It has one job: a text is asked for, the player types it on the panel, and at Done the asker
-- gets it. The name of a wheel is asked for by the settings window. A chat line is asked for by
-- the keyboard's chat part (Screen/KeyboardChat.lua), when the game's chat box takes the focus
-- while the player's hands are on the controller; there Done is Send, the keyboard stays for the
-- next line, and the line has word guesses and a channel row. With a real keyboard or the mouse
-- the chat box opens as it always did.
--
-- What keeps the game's program safe (Core/AdapterKeyboard.lua says why):
--   The chat box is only read. Nothing is written into it, and it is not sent or closed by us:
--   text written into it from addon code makes the game's next send or close of it run as this
--   addon, and the game blocks that ("Gamepad Suite has been blocked").
--   The panel keeps every press of the controller but one: Send on a chat line goes on to a key
--   bind of ours, held only while the keyboard is open for chat, that clicks a secure button of
--   ours with the line on it. The game runs the line as its own code. That press is handed on
--   the way ConsolePort hands a press on (the frame's SetPropagateKeyboardInput, in the press:
--   ConsolePort/Widget/Helpers.lua 47 to 58), and the script says true too, as the game's own
--   flyout does (Blizzard_GamepadActionBars/FlyoutRadial.lua 252 to 270): in the game a "true"
--   alone did not hand a stick on from an addon's frame (0.15.0).
--   Inside a script that the game runs for a press, and inside a message from the game's chat
--   code, it only takes note. The panel shows or goes, the binds are set or let go, and the
--   asker gets the text one frame later, from a timer.
--   It does no work while nothing happens: no script runs on each frame, and a part of the
--   panel is drawn again only when the player or the game changed it.
--
-- This game has no keyboard that an addon can bring up. Its program can show the Windows touch
-- keyboard, and players see it at the mailbox, where the game's own gamepad code presses the
-- text box. In the game, a press or a focus that came from this addon did not bring it, and
-- the chat box that the game opens for a bind did not either. So the keys here are ours.
--
-- It works out of a fight only: it does not open in one, and it closes when one starts, so the
-- controller is free for the fight. The name of a wheel is then not changed. A chat line that was
-- not sent is kept, and the keyboard opens again with it after the fight if the chat box is still
-- open (Screen/KeyboardChat.lua).
local _, ns = ...

local Keyboard = ns.Module("Keyboard", { "padButtons" }, "Chat Keyboard")
ns.Keyboard = Keyboard

local Model, Draw = ns.KeyboardModel, ns.KeyboardDraw

local frame               -- the panel
-- nil while the keyboard is closed. Open: title, text, limit, done, the focus (row, col, and zone with
-- its place: Screen/KeyboardModel.lua), and for a chat line box, the chat box it is for, and the rows
-- of the chat part (words, chips, names, lit, guess).
local state
local layer = false       -- LT is held: the second layer shows and is typed
local stick               -- the direction the left stick is pushed in now
local notes, told = 0, {}

-- A few lines for the saved file: what the game did at the points its code cannot prove. A line
-- with a name (once) is written one time only. The chat part writes here too.
function Keyboard.Note(text, once)
    if notes < 20 and not (once and told[once]) then
        notes = notes + 1
        if once then
            told[once] = true
        end
        ns.Log.Add("keyboard", text)
    end
end

-- True while the keyboard is open: from the moment a text is asked for until Done or Cancel.
function Keyboard.IsOpen()
    return state ~= nil
end

-- What the open keyboard holds, for its chat part; nil while it is closed.
function Keyboard.State()
    return state
end

-- The panel shows while a text is typed, as large as the player made the settings window. This
-- runs from a timer or at the game's word of a fight, and never inside a press or a message of
-- the game's chat code: the game is then still at work with the frames that hear the controller.
-- The chat part binds or lets go Menu and A here. The rest of the suite is told that the keyboard
-- opened or closed ("keyboard").
local function follow()
    if state then
        -- every press is kept again, and the sticks too, until a Send hands its press on
        if not ns.Adapter.InCombat() then
            frame:SetPropagateKeyboardInput(false)
        end
        frame:SetScale(ns.Registry.Get("window.scale") / 100)
        frame:Show()
        frame:Raise()
    else
        frame:Hide()
    end
    ns.KeyboardChat.Follow(state)
    ns.Send("keyboard", state ~= nil)
end

-- One frame later the panel is as the keyboard is now: after a Send that keeps it open.
function Keyboard.Follow()
    C_Timer.After(0, follow)
end

-- Every part of the panel that a letter, a pick or a move between its rows can change.
local function redraw()
    local chat = state.box ~= nil
    Draw.Line(state.title, state.text)
    if chat then
        Draw.Words(state.words or {})
        Draw.Chips(state.chips or {}, state.lit, state.zone == "chips" and state.chip)
        Draw.Names(state.zone == "names" and state.names or nil, state.name)
    end
    local voice = chat and ns.KeyboardVoice and ns.KeyboardVoice.Can() and (ns.KeyboardVoice.Talking() and "talking" or "can") or nil
    Draw.Hints(state.zone == "names" and "names" or chat and "chat" or "plain", state.guess, voice)
    Draw.Focus(state)
end

-- The chat part changed what the keyboard holds (a send ran, a line came back).
function Keyboard.Redraw()
    if state then
        redraw()
    end
end

-- LT went down or up: the keys show the other layer.
local function setLayer(now)
    if state and now ~= layer then
        layer = now
        Draw.Keys(layer, state.box ~= nil)
    end
end

-- The game's event for Shift, Ctrl and Alt. LT is one of them when the game's settings make it
-- so, and then this event tells of LT; LB too (Ctrl at the game's start), held for voice to text
-- on a chat line. It is heard only while the keyboard is open.
local function modifier(key, down)
    local mods = ns.Adapter.Modifiers()
    if mods.LT and key:find(mods.LT, 1, true) then
        setLayer(down == 1)
    end
    local voice = ns.KeyboardVoice
    if mods.LB and key:find(mods.LB, 1, true) and voice and state and state.box then
        C_Timer.After(0, function() ns.Call("Keyboard", down == 1 and voice.Down or voice.Up) end)
    end
end

-- The keyboard is closed, and nothing is given back. The panel goes one frame later; `now` is
-- for a close that no press and no message of the game made. keep: the close is not the
-- player's (a fight, "fight", or the game closed the chat box), so a chat line is kept.
function Keyboard.Close(now, keep)
    if not state then
        return
    end
    if keep and state.box then
        ns.KeyboardChat.Keep(state, keep == "fight")
    end
    state = nil
    ns.Off("MODIFIER_STATE_CHANGED", "Keyboard")
    if ns.KeyboardVoice then
        ns.KeyboardVoice.Up(true)
    end
    if now then
        follow()
    else
        C_Timer.After(0, follow)
    end
end

-- Words that came by voice (Screen/KeyboardVoice.lua) go at the end of a chat line, after a space.
function Keyboard.AddText(words)
    if state and state.box then
        local gap = (state.text == "" or state.text:find(" $")) and "" or " "
        state.text = Model.Add(state.text, gap .. words, state.limit)
        ns.KeyboardChat.Typed(state)
        redraw()
    end
end

-- The typing is done: the keyboard closes and the asker gets the text, one frame later.
local function finish()
    local done, text = state.done, state.text
    Keyboard.Close()
    C_Timer.After(0, function() ns.Call("Keyboard", done, text) end)
end

-- ---------------------------------------------------------------- the buttons

-- A button went down, by our name for it (Model.ACT has what each does). A press that comes
-- while the panel waits for its frame to go does nothing. True hands the press on to the game.
local function act(button)
    if not state then
        return
    end
    local what, value = Model.Press(state, button, layer)
    if what == "move" then
        ns.Adapter.Sound("U_CHAT_SCROLL_BUTTON")
        if state.box then
            redraw()
        else
            Draw.Focus(state)
        end
    elseif what == "char" or what == "back" then
        state.text = what == "back" and Model.Back(state.text) or Model.Add(state.text, value, state.limit)
        if state.box then
            ns.KeyboardChat.Typed(state)
        end
        redraw()
    elseif what == "done" then
        if state.box then
            return ns.KeyboardChat.Send(state, button)
        end
        finish()
    elseif what == "cancel" then
        Keyboard.Close()
    elseif what then
        -- a guess, a channel or a whisper name: the rows of a chat line
        ns.KeyboardChat.Pick(state, what, value)
        Keyboard.Redraw()
    end
end

-- A fault at a press must not leave the keyboard up with the controller: it is logged, and the
-- keyboard closes. Gives what fn gave.
local function guarded(fn, ...)
    local ok, pass = ns.Call("Keyboard", fn, ...)
    if not ok then
        Keyboard.Close()
    end
    return pass
end

-- The settings window got a press while the keyboard is open: it is the keyboard's. what is the
-- window's own word for the button (A, B, X, Y, up, down, left, right; nil for any other). True
-- when the keyboard is open, and the window then does nothing with the press. The game's code
-- does not say which of two shown frames hears a button first; this way the answer does not matter.
function Keyboard.Act(what)
    if not state then
        return false
    end
    Keyboard.Note("a press came to the settings window before the keyboard", "window")
    guarded(act, what)
    return true
end

local function stickMoved(name, x, y)
    if name ~= "Left" and name ~= "Movement" then
        return
    end
    local dir = Model.Dir(x or 0, y or 0, stick)
    if dir ~= stick then
        stick = dir
        if dir then
            act(dir)
        end
    end
end

-- ---------------------------------------------------------------- open

-- A text is asked for. The keyboard is open from now on (a press that the settings window hears
-- first is the keyboard's at once), and its panel shows one frame later. The chat part opens it
-- for a chat line with the chat box in new.box.
function Keyboard.Open(new)
    state = new
    state.row, state.col = Model.START[1], Model.START[2]
    layer, stick = ns.Adapter.Held() and true or false, nil
    ns.On("MODIFIER_STATE_CHANGED", "Keyboard", modifier)
    Draw.Mode(state.box ~= nil)
    Draw.Keys(layer, state.box ~= nil)
    redraw()
    C_Timer.After(0, follow)
end

-- Asks the player for a text. name says what it is for, text is the text so far, limit the most
-- letters it may have (nil for no limit). When the player ends with Done, done(newText) is
-- called, one frame after the press; on Cancel nothing is called. True when the keyboard opened.
-- A keyboard that was open for another text closes, and that text is not given back.
function Keyboard.Ask(name, text, limit, done)
    if not frame or ns.Adapter.InCombat() then
        return false
    end
    Keyboard.Open({ title = name, text = text or "", limit = limit, done = done })
    return true
end

-- The panel, hidden. While it shows, it gets the controller's buttons and sticks before the
-- game's binds do, and it keeps every one of them (each script says false, "not for the game"),
-- but the press of Send on a chat line.
local function build()
    frame = Draw.Build()
    ns.KeyboardChat.Build()
    frame:EnableGamePadButton(true)
    frame:EnableGamePadStick(true)
    frame:SetScript("OnGamePadButtonDown", function(self, name)
        Keyboard.Note("a press came to the keyboard itself", "own")
        local button = ns.Adapter.NAME[name]
        -- LT as a plain button, for a player whose LT is no Shift, Ctrl or Alt
        if button == "LT" then
            setLayer(true)
        end
        -- LB on a chat line: voice to text while it is held, one frame later (Screen/KeyboardVoice.lua)
        if button == "LB" and state and state.box and ns.KeyboardVoice then
            C_Timer.After(0, function() guarded(ns.KeyboardVoice.Down) end)
        end
        -- set at each press, so a press that comes after a Send is kept
        local pass = guarded(act, button) == true
        if not ns.Adapter.InCombat() then
            self:SetPropagateKeyboardInput(pass)
        end
        return pass
    end)
    frame:SetScript("OnGamePadButtonUp", function(_, name)
        if ns.Adapter.NAME[name] == "LT" then
            setLayer(false)
        elseif ns.Adapter.NAME[name] == "LB" and ns.KeyboardVoice then
            C_Timer.After(0, function() guarded(ns.KeyboardVoice.Up) end)
        end
        return false
    end)
    frame:SetScript("OnGamePadStick", function(_, name, x, y)
        guarded(stickMoved, name, x, y)
        return false
    end)
end

function Keyboard.OnLogin()
    -- The panel is made at login, and not at its first use: a frame that hears the controller is
    -- not made inside a press. After a reload in a fight it is made when the fight ends.
    ns.Queue.Run("Keyboard", build)
    -- A fight starts: the keyboard goes at once, and so does a panel that waits for its frame to
    -- go, with the keys of a chat line: the game tells of the fight before it locks anything. A
    -- chat line is kept.
    ns.On("PLAYER_REGEN_DISABLED", "Keyboard", function()
        if state then
            Keyboard.Close(true, "fight")
        elseif frame then
            follow()
        end
    end)
    -- the fight is over: a chat line that it closed comes back while its chat box has the focus
    ns.On("PLAYER_REGEN_ENABLED", "Keyboard", function()
        ns.Call("Keyboard", ns.KeyboardChat.Back)
    end)
    -- the settings window closed under a text that it asked for
    ns.Listen("settings:closed", "Keyboard", function()
        if state and not state.box then
            Keyboard.Close()
        end
    end)
    ns.KeyboardChat.Login()
end
