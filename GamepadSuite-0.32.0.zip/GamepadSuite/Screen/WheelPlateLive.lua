-- The party wheel of healer mode while it is open: its plates (Screen/WheelPlate.lua draws them) and the spell in
-- its middle follow the game's word of a change, and only while it is open.
--   The middle: the spell's cooldown, and the one look of the on-screen buttons for "cannot be used now"
--     (HudFace.Unusable): blue for too little mana, grey for another reason. An item's party wheel (a bandage)
--     hears the bags too: its cooldown, and how many are left, as the consumables wheel shows it.
--   The reach follows the game's word of its party range (UNIT_IN_RANGE_UPDATE, as its raid frames use it). A
--     spell that reaches less far, or an item, has no word of the game: it is asked again each second.
--   A member who left in a fight: the ring is not drawn again until the fight ends (Core/Wheels.lua), and the game
--     gives the left member's token to the next member. At the game's word of a change of the group each plate is
--     done over, its portrait too; a token that holds no one now leaves its place empty, and the stick can still
--     land there (the flick fails). UNIT_PORTRAIT_UPDATE and PORTRAITS_UPDATED draw a portrait again.
--   The aggro edge: a ring round the portrait in the game's colour for the state while the game says the member
--     has the aggro (Core/AdapterPlate.lua ShowThreat), at UNIT_THREAT_SITUATION_UPDATE. A colour on a widget, in
--     a fight too, and it asks for no press.
--   The game's own mark of a resurrection on its way, at the right end of a dead member's bar (ShowRez).
--   The game's own aura boxes (AddAuraBox): in a fight the game hides a unit's auras from addon code, so the game
--     itself draws the player's own buffs and the mark of a debuff the player can remove on two frames of the
--     plate, in a fight and out of one, and the plate's own row of buffs and its own mark stay hidden. The boxes
--     are made when a party wheel opens, for each plate with a member, again when the group changes, and they go
--     when the wheel closes. If the game gives no box, the plate's own row and mark show as before (empty while
--     the game hides the auras), and the log says why.
local _, ns = ...

local Live = {}
ns.WheelPlateLive = Live

local Theme, Plate = ns.Theme, ns.WheelPlate
local px = Theme.px
local note = Plate.Note

-- The game's events that change a plate or the middle, heard while a party wheel is open; an item's wheel hears BAGS too.
local EVENTS = { "UNIT_HEALTH", "UNIT_MAXHEALTH", "UNIT_HEAL_PREDICTION", "UNIT_AURA", "RAID_TARGET_UPDATE", "PLAYER_ROLES_ASSIGNED",
    "GROUP_ROSTER_UPDATE", "SPELL_UPDATE_COOLDOWN", "SPELL_UPDATE_USABLE", "UNIT_POWER_UPDATE", "UNIT_CONNECTION", "PLAYER_FLAGS_CHANGED", "UNIT_NAME_UPDATE",
    "UNIT_IN_RANGE_UPDATE", "UNIT_PORTRAIT_UPDATE", "PORTRAITS_UPDATED", "UNIT_THREAT_SITUATION_UPDATE", "INCOMING_RESURRECT_CHANGED" }
local BAGS = { "BAG_UPDATE_COOLDOWN", "BAG_UPDATE_DELAYED" }
Live.EVENTS = EVENTS
local EVERY = { RAID_TARGET_UPDATE = true, PLAYER_ROLES_ASSIGNED = true, GROUP_ROSTER_UPDATE = true, PORTRAITS_UPDATED = true }   -- (no unit: every member)
local MIDDLE = { SPELL_UPDATE_COOLDOWN = true, SPELL_UPDATE_USABLE = true, UNIT_POWER_UPDATE = true, BAG_UPDATE_COOLDOWN = true, BAG_UPDATE_DELAYED = true }
local COOL = { SPELL_UPDATE_COOLDOWN = true, BAG_UPDATE_COOLDOWN = true }
-- seconds between two looks at the reach of a spell that reaches less far than the game's party range (40 yards), or
-- of an item: no event of the game tells of those
local REACH, PARTY_YARDS = 1, 40
local MARK, GAME_MARK = 12, 14   -- the plate's own debuff mark, lines across; the game's own picture of one, units
local open              -- the party wheel that is open: { cells, list (gives its entries now), middle, kind, id }
local watch, cool, ticker, count
local boxed = {}        -- the plates with the game's boxes now: cell -> true

-- True for a value the game hides from addon code (an event's unit in a restricted fight). A compare with one is an error.
local function hidden(value)
    return issecretvalue ~= nil and issecretvalue(value)
end

-- The boxes of a plate go.
local function drop(c)
    for _, key in ipairs({ "buffAnchor", "markAnchor" }) do
        if c[key] then
            ns.Adapter.RemoveAuraBox(c[key])
            c[key] = false
        end
    end
    boxed[c] = nil
end

-- The game's boxes for a plate's member: the row of buffs on the portrait's top edge, from the right end of the
-- plate's own row of four (the game's row starts 3 units in from its box's corner); the mark in the top left corner,
-- the game's 14-unit picture grown to the plate's mark.
local function box(c, unit)
    drop(c)
    if not (ns.Adapter.AddAuraBox and unit and c.line) then
        return
    end
    local line, N, B, UP = c.line, Plate.BUFFS, Plate.BUFF, Plate.BUFF_UP
    c.buffBox = c.buffBox or CreateFrame("Frame", nil, c)
    c.buffBox:SetSize(px(N * B * line) + 6, px(B * line) + 6)
    c.buffBox:ClearAllPoints()
    c.buffBox:SetPoint("TOPRIGHT", c, "TOP", px(((N - 1) / 2 * (B + 1) + B / 2) * line) + 3, px((B + UP) * line) + 3)
    c.markBox = c.markBox or CreateFrame("Frame", nil, c)
    c.markBox:SetScale(px(MARK * line) / GAME_MARK)
    c.markBox:SetSize(GAME_MARK + 6, GAME_MARK + 4)
    c.markBox:ClearAllPoints()
    c.markBox:SetPoint("TOPLEFT", c, "TOPLEFT", 0, 0)
    local id, why = ns.Adapter.AddAuraBox(c.buffBox, unit, "buffs", px(B * line))
    local markId, markWhy
    if ns.Cleanse and ns.Cleanse.on then
        markId, markWhy = ns.Adapter.AddAuraBox(c.markBox, unit, "mark", GAME_MARK)
    end
    c.buffAnchor, c.markAnchor = id or false, markId or false
    boxed[c], c.boxUnit, c.boxLine = true, unit, line
    -- (the game draws them now: the plate's own row and mark would stand on them)
    if c.buffAnchor then
        Plate.Hide(c.buffs)
    end
    if c.markAnchor then
        c.mark:Hide()
    end
    note(c.buffAnchor and "box" or "box refused", "aura anchor on " .. unit .. ": " .. (c.buffAnchor and "drawn by the game" or "refused, " .. tostring(why))
        .. (markWhy and "; the mark refused, " .. markWhy or "") .. ".")
end

-- A plate was laid out anew while a party wheel is open (a new member on it, or a new size): its boxes follow.
function Live.Lay(c, unit)
    if not unit then
        drop(c)
    elseif open and boxed[c] and (c.boxUnit ~= unit or c.boxLine ~= c.line) then
        box(c, unit)
    end
end

-- More of a member's plate, after Screen/WheelPlate.lua drew its own parts (what: the game's event, or nil for all;
-- health: the state was drawn again). With no unit: nothing of these shows.
function Live.Show(c, unit, what, health)
    if not unit then
        Plate.Hide({ c.threat, c.rez })
        return drop(c)
    end
    if what == nil or what == "UNIT_THREAT_SITUATION_UPDATE" then
        local said = ns.Adapter.ShowThreat and ns.Adapter.ShowThreat(c.threat, unit) or "plain 0"
        -- (the log keeps the first aggro seen, and the first hidden answer: one fight in the game tells which comes)
        if not (said == "plain 0" or said == "plain 1" or said == "no group") then
            note("threat " .. said:match("^%S+"), "threat read for " .. unit .. ": " .. said)
        end
    end
    if health and c.dead and ns.Adapter.ShowRez then
        local said = ns.Adapter.ShowRez(c.rez, unit)
        if said ~= "false" then
            note("rez " .. said, "A plate's resurrection on its way for " .. unit .. ": " .. said .. ".")
        end
    elseif health then
        c.rez:Hide()
    end
end

-- Is a member's token still someone (what: nil, or the game's word of a change of the group or of a portrait)? A
-- token that holds no one: the place empties, as an entry with no member, and false. Back: its parts show again.
function Live.There(c, unit, what)
    local there = not ns.Adapter.UnitThere or ns.Adapter.UnitThere(unit)
    if not there then
        if not c.away then
            note("away", "A member left in a fight: the plate of " .. unit .. " is empty until the ring is drawn again.")
        end
        Plate.Bare(c)
        c.away = true
        Plate.Hide({ c.bar, c.who, c.art })
        Plate.ShowBack(c.whoBack, false)
        Live.Show(c)
        return false
    elseif c.away then
        c.away = false
        for _, part in ipairs({ c.bar, c.who, c.art }) do
            part:Show()
        end
        Plate.ShowBack(c.whoBack, true)
    end
    if what then
        ns.Adapter.Portrait(c.art, unit)
    end
    if what == "GROUP_ROSTER_UPDATE" and open then
        box(c, unit)
    end
    return true
end

-- The count of an item's party wheel on the middle, in the type of the counts on the ring (Screen/Wheel.lua: the
-- Theme's row size at a line of the wheel; the middle is 0.7 of a picture). Nothing on a spell's.
local function counted()
    local art = open.middle
    if not count then
        count = Theme.Text(art:GetParent(), "tiny", "cream")
        count:SetPoint("TOPRIGHT", art, "TOPRIGHT")
    end
    count:SetShown(open.kind == "item")
    local across = open.kind == "item" and art:GetWidth() or 0
    if across > 0 then
        count:SetFont(Theme.font.text, across * Theme.size.row / (0.7 * ns.WheelRules.PICTURE * ns.WheelRules.GAME), "")
        ns.Adapter.ShowCount(count, { kind = "item", id = open.id })
    end
end

-- The middle of the open party wheel: the spell's cooldown, by the game's own clock, and the look
-- of "cannot be used now" while the game says it cannot be cast now, too little mana or another
-- reason (the game's own answer, as its bar buttons use it: Core/AdapterHud.lua Usable). what: the
-- game's event that told of a change, or nil for both.
local function middle(what)
    local bind = { kind = open.kind, id = open.id }
    if what == nil or COOL[what] then
        ns.Adapter.ShowCooldown(cool, bind, true)
    end
    if not COOL[what] then
        local usable = ns.Adapter.Usable(bind)
        ns.HudFace.Unusable(open.middle, usable)
        note("usable", "The spell in the middle of a party wheel: can it be cast now " .. tostring(usable) .. ".")
        counted()
    end
end

-- The reach of the open party wheel's spell to a member (unit), or to each (nil). An event for a token that no
-- plate has (another name of the same member): every plate.
local function reach(unit)
    local found
    for i, entry in ipairs(open and open.list() or {}) do
        local c = open.cells[i]
        if entry.unit and c and not c.away and (not unit or entry.unit == unit) then
            found = true
            note("reach", "A plate's reach for " .. entry.unit .. ": " .. ns.Adapter.ShowReach(c, c.art, open.kind, open.id, entry.unit, c.gone) .. ".")
        end
    end
    return found or unit and reach()
end

-- The game told of a change while a party wheel is open. It can hide the unit of an event in a fight (UNIT_AURA
-- is marked so, UnitAuraDocumentation.lua 645 to 655, and UNIT_IN_RANGE_UPDATE, UnitDocumentation.lua 4329 to
-- 4339): such a unit is never compared, and every plate hears the event.
local function heard(_, event, unit)
    if not open then
        return
    elseif hidden(unit) then
        note("hidden unit", "The game hid the unit of " .. event .. ": every plate was drawn again for it.")
        unit = nil
    end
    if MIDDLE[event] then
        return (event ~= "UNIT_POWER_UPDATE" or unit == nil or unit == "player") and middle(event)
    elseif event == "UNIT_IN_RANGE_UPDATE" then
        return reach(unit)
    end
    for i, entry in ipairs(open.list()) do
        if entry.unit and (EVERY[event] or unit == nil or entry.unit == unit) and open.cells[i] then
            Plate.Show(open.cells[i], entry.unit, event)
        end
    end
    return event == "GROUP_ROSTER_UPDATE" and reach()
end

-- The open party wheel ends (or any wheel: nothing happens for another one).
function Plate.Close()
    if watch then
        watch:UnregisterAllEvents()
    end
    if ticker then
        ticker:Cancel()
        ticker = nil
    end
    if cool then
        cool:Clear()
        cool:Hide()
    end
    if count then
        count:Hide()
    end
    if open then
        open.middle:SetVertexColor(1, 1, 1)
    end
    for c in pairs(boxed) do
        drop(c)
    end
    open = nil
end

-- A wheel opened: for a party wheel (kind "spell" or "item", id its number) its plates and its
-- middle follow the game from now on. cells are the ring's pictures, list() gives its entries now,
-- art is the middle's picture. A fault in the look at the reach stops that look, and is logged.
function Plate.Open(cells, list, art, kind, id)
    Plate.Close()
    if not kind then
        return
    end
    open = { cells = cells, list = list, middle = art, kind = kind, id = id }
    if not watch then
        watch = CreateFrame("Frame")
        watch:SetScript("OnEvent", function(...)
            ns.Call("Wheel", heard, ...)
        end)
        cool = CreateFrame("Cooldown", nil, art:GetParent(), "CooldownFrameTemplate")
        cool:SetSwipeTexture(Plate.ROUND)
        cool:SetSwipeColor(0, 0, 0, 0.7)
        cool:SetDrawEdge(false)
    end
    -- (an event this game does not have is left out)
    for _, event in ipairs(EVENTS) do
        pcall(watch.RegisterEvent, watch, event)
    end
    for _, event in ipairs(kind == "item" and BAGS or {}) do
        pcall(watch.RegisterEvent, watch, event)
    end
    cool:ClearAllPoints()
    cool:SetAllPoints(art)
    cool:Show()
    for i, entry in ipairs(list()) do
        local c = cells[i]
        if c and c.away then
            c.art:Hide()
        elseif c and entry.unit then
            box(c, entry.unit)
        end
    end
    middle()
    reach()
    local yards = ns.Adapter.ReachYards and ns.Adapter.ReachYards(kind, id) or 0
    note("reach " .. kind .. id, "The reach of " .. kind .. " " .. tostring(id) .. " follows the game's word of its party range"
        .. (yards >= PARTY_YARDS and "." or ", and a look each second (it reaches " .. (yards > 0 and yards or "an unknown number of") .. " yards)."))
    if yards < PARTY_YARDS then
        ticker = C_Timer.NewTicker(REACH, function()
            if not ns.Call("Wheel", reach) and ticker then
                ticker:Cancel()
                ticker = nil
            end
        end)
    end
end
