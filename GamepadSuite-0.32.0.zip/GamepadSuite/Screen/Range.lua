-- Range Finder: a small, quiet text a little above the nameplate of a hostile target tells how
-- far the target is, as a band of yards: "5-30 yd". It turns red when the target is farther
-- than the longest attack the character has (a spell that reaches past 45 yards is no attack:
-- RangeModel.lua, Model.FARTHEST). A target with no nameplate shows no text: an addon
-- cannot know where a character stands on screen in any other way.
--
-- Range Tick: the controller gives one short pulse when the hostile target comes into reach of
-- the character's longest attack, and none when it goes out of reach. The pulse has the
-- strength of the Rumble setting, and with Rumble off there is none. It needs no nameplate and
-- no text, so it works with Range Finder off too. A tick is left out while another pulse plays,
-- and for a target that went out of reach a moment ago (it stands at the edge).
--
-- The game gives no distance to an enemy. It tells if the target is inside the reach of a spell
-- or of an item, and it sends an event when a spell's answer changes (Core/AdapterRange.lua).
-- The melee reach is a spell of 5 yards the character knows, else an item that every character
-- can ask about; that item has no event, so it is read again at the player's swing, at a hit the
-- player takes and when the player stops moving. So nothing runs on a timer. With no hostile target nothing runs at all: the events are heard
-- only while the target is hostile and alive, and the text or the tick is in use. Then each event costs one
-- question for each reach, six at most. The text is set only when the band is another one. The
-- game's word of a nameplate that comes or goes is heard only while it can move the text. A
-- change of the spell book only marks the list of reaches as old: the book is read one time, at
-- the next reading. The rules are in RangeModel.lua.
--
-- The owner's log of 0.21.0 shows the game's range event and the tick at work. The log (kind
-- "range") keeps a few lines: what the range is read from, the first readings, the first changes
-- of each kind (a range event, a swing, a hit, the end of a walk), and the first ticks.
local _, ns = ...

local Range = ns.Module("Range", { "plates", "rangeEvents", "spellBook" }, "Range Finder")
ns.Range = Range

local Model = ns.RangeModel

-- The text's size (the Theme's name size) and its lift over the nameplate, in the mockup's units.
-- The text is small and quiet, and still reads on a handheld held at arm's length: about 27 pixels
-- high on a screen of 2560 x 1600 at the interface scale 0.72. Past every reach it is the Theme's red.
local SIZE, LIFT = ns.Theme.size.name, 3
local MAX_NOTES = 4                 -- lines of each sort for the log in one session

local holder, text
local probes                -- the things with a reach that are watched; nil: to be read from the spell book again
local watched = {}          -- spell number -> true for the spells among them
local hostile = false       -- the target is an enemy that is alive (as of the last change of target or reading)
local rested = false        -- the log told that a target died, one time in a session
local watching = false      -- the game's range events are heard
local placed = false        -- the text has a nameplate to stand on
local hearsCame, hearsWent = false, false   -- the game's word of a nameplate that comes, and of one that goes, is heard
local plateCame, plateWent  -- what is done at each of the two
local label, far            -- what the text says now
local seen = {}             -- what the tick knows of this target's reach (RangeModel.lua, Model.Tick)
local notes = {}

local function note(sort, words)
    notes[sort] = (notes[sort] or 0) + 1
    if notes[sort] <= MAX_NOTES then
        ns.Log.Add("range", words)
    end
end

-- The tick is in use: its setting is on, and Rumble is not off.
local function ticking()
    return ns.Registry.Get("feel.range_tick") and ns.Registry.Get("feel.rumble") ~= "Off"
end

local function show()
    holder:SetShown(placed and label ~= nil)
end

-- Each of the two nameplate events is heard only while it can change something. "A nameplate
-- came": while the text waits for the nameplate of a hostile target. "A nameplate went": while
-- the text stands on one. With Range Finder off the text has no place, so neither is heard.
local function hearPlates()
    local came = hostile and not placed and ns.Registry.Get("screen.range_finder") and true or false
    if came ~= hearsCame then
        hearsCame = came
        if came then
            ns.On("NAME_PLATE_UNIT_ADDED", "Range", plateCame)
        else
            ns.Off("NAME_PLATE_UNIT_ADDED", "Range")
        end
    end
    if placed ~= hearsWent then
        hearsWent = placed
        if placed then
            ns.On("NAME_PLATE_UNIT_REMOVED", "Range", plateWent)
        else
            ns.Off("NAME_PLATE_UNIT_REMOVED", "Range")
        end
    end
end

local function stop()
    holder:Hide()
    label, far, placed = nil, nil, false
    if watching then
        watching = false
        ns.Adapter.OffRangeChanged("Range")
    end
end

-- Asks the game for each reach. It plays the tick, and shows the band. The text is touched only
-- when it changes. A target that died stays the target, and the game sends no change of target:
-- each reading asks first, and the reaches rest until the next target.
local function read(why)
    if not ns.Adapter.EnemyTargeted() then
        hostile = false
        stop()
        hearPlates()
        if not rested then
            rested = true
            ns.Log.Add("range", "the target died: the reaches rest")
        end
        return
    end
    local states = {}
    for i, probe in ipairs(probes) do
        states[i] = ns.Adapter.InRange(probe)
    end
    local now, beyond = Model.Text(Model.Band(probes, states))
    if ticking() then
        local inside
        if now then
            inside = not beyond
        end
        if Model.Tick(seen, inside, GetTime(), ns.Rumble.Busy()) then
            local felt = ns.Rumble.Pulse(Model.TICK)
            note("a tick", "a tick: the target came into reach" .. (felt and "" or " (the controller did not rumble)"))
        end
    end
    if now == label and beyond == far then
        return
    end
    label, far = now, beyond
    if now then
        text:SetText(now)
        if beyond then
            text:SetTextColor(ns.Theme.Color("red"))
        else
            text:SetTextColor(ns.Theme.Color("cream"))
        end
    end
    show()
    note(why, why .. ": " .. tostring(now))
end

-- Puts the text at the target's nameplate. False when it has no place: Range Finder is off, the
-- target has no nameplate, or the game refuses a place at a nameplate that addon code may not measure.
local function place()
    local plate = ns.Registry.Get("screen.range_finder") and ns.Adapter.TargetPlate()
    placed = plate and pcall(function()
        holder:ClearAllPoints()
        holder:SetPoint("BOTTOM", plate, "TOP", 0, ns.Theme.px(LIFT))
    end) or false
    return placed
end

-- The game says that an answer changed: for one of our spells, or (no spell) a swing, a hit or
-- the end of a walk, which why names for the log. After a change of the spell book the list of
-- reaches is old: this reading makes it anew.
local function changed(spell, why)
    if spell == nil or watched[spell] then
        if probes then
            read(why or "the game told of a change")
        else
            Range.Update()
        end
    end
end

-- The target, its nameplate or a setting changed. (With no hostile target the game is asked nothing.)
function Range.Update()
    if hostile and (place() or ticking()) then
        if not probes then
            probes, watched = Model.Probes(ns.Adapter.RangeSpells(), ns.Adapter.RangeMelee()), {}
            local names = {}
            for i, probe in ipairs(probes) do
                if probe.spell then
                    watched[probe.spell] = true
                end
                names[i] = tostring(probe.name) .. " " .. Model.Text({ lo = probe.min, hi = probe.max })
            end
            note("the range is read from", "the range is read from: " .. (names[1] and table.concat(names, ", ") or "nothing: no spell of the character reaches an enemy"))
        end
        -- asked again at each new target: it costs nothing, and the game may have dropped a watch
        ns.Adapter.WatchReach(probes)
        if not watching then
            watching = true
            ns.Adapter.OnRangeChanged("Range", changed)
        end
        read("a hostile target")
        show()
    else
        stop()
    end
    hearPlates()
end

-- A nameplate came: it can be the one of the hostile target, which had none.
plateCame = function()
    if not place() then
        return
    end
    if watching then
        show()
        hearPlates()
    else
        Range.Update()
    end
end

-- The nameplate of the target goes: the text goes with it, and the tick stays.
plateWent = function(unit)
    if ns.Adapter.IsTargetPlate(unit) then
        placed = false
        if ticking() then
            show()
        else
            stop()
        end
        hearPlates()
    end
end

-- A new target: the reach of the one before says nothing about it, so its first answer gives no tick.
local function retarget()
    hostile, seen = ns.Adapter.EnemyTargeted(), {}
    Range.Update()
end

function Range.OnLogin()
    holder = CreateFrame("Frame", "GamepadSuiteRange", UIParent)
    holder:SetFrameStrata("BACKGROUND")
    holder:SetSize(ns.Theme.px(5 * SIZE), ns.Theme.px(SIZE + 2))
    holder:SetAlpha(0.9)
    holder:Hide()
    text = ns.Theme.Text(holder, SIZE, "cream")
    text:SetPoint("CENTER")
    -- (the game loads the melee item's data now, so its answers come from the first target on)
    ns.Adapter.RangeMelee()
    ns.On("PLAYER_TARGET_CHANGED", "Range", retarget)
    ns.On("PLAYER_ENTERING_WORLD", "Range", retarget)
    -- A new spell, or a talent that makes a spell reach farther. The game sends this often and
    -- in bursts: the list of reaches is only marked as old here, and no spell book is read.
    pcall(ns.On, "SPELLS_CHANGED", "Range", function()
        probes = nil
    end)
    -- (after a change of a setting the first answer gives no tick: the reach was not followed before)
    ns.Listen("setting", "Range", function(key)
        if key == "screen.range_finder" or key == "feel.range_tick" or key == "feel.rumble" then
            seen = {}
            Range.Update()
        end
    end)
end
