-- Loot rolls with the controller. While a roll is on the screen, a card of our own sits low in
-- the middle of the screen: the item's picture with the time left and the stack's size on it, its
-- name in the color of its quality, the game's reason on a Need it does not allow, and the strip of
-- button hints of every part: A, X and B with the words Need, Greed and Pass. A hold of A
-- is Need, of X Greed and of B Pass, on the roll on the card. A tap of these buttons stays the
-- player's own: it casts the bind on the button, in combat and out of it, and makes no roll. After
-- a hold of one second the card says to let go, and the let-go makes the roll. A hold of more than
-- two and a half seconds was for a spell that casts again while its button is held: it makes no
-- roll. With more than one roll the card says which one of how many it shows, and D-pad up and
-- down change it (the D-pad's own binds act as well). Beside the card is the item's tooltip, with
-- what is worn in its place.
--
-- The game's own roll cards stay where the game puts them: nothing of the game's is moved, hidden
-- or given a frame of ours. (Its cards sit in a scroll box that cuts off whatever reaches out of
-- it: Blizzard_SharedXML/Shared/Scroll/ScrollBox.xml 20. A card of ours hung on one of them could
-- not be seen.)
--
-- No key is taken. A plain frame of ours hears each press of the controller while a roll shows
-- and hands it on to the game: the frame's switch for that is set out of combat, and the game
-- keeps it in combat. The keyboard of the suite hands a press on the same way, and the owner's
-- 0.23.0 log has such a press reach a bind (16:34:45). So the button's bind acts at the press as
-- always, and a hold casts the bind once at its start as well: a hold cannot be told from a tap
-- before the let-go, and a tap must cast at once. The let-go is read from the controller's own
-- state, one look a frame and only during a hold.
--
-- The roll is the game's own call for it, made by addon code (Core/AdapterRolls.lua). For an item
-- that binds on pickup it is the call of the game's own "are you sure" box, so no box opens as the
-- addon's: a box opened by addon code in combat would have its window binds refused.
--
-- While a window of the game has the controller, A, X and B are that window's (the loot window:
-- loot, loot all, close; the game's roll list after Focus UI: Need, Greed, Pass at a tap): a hold
-- there would act twice. So the frame rests, and the card stays with its buttons dim and says why.
-- The same in mouse mode (the pointer clicks the game's roll), while a wheel is open (B closes it) and while the
-- keyboard is open. But a wheel that the press of a hold opened (Healer Mode: a heal on A, X or B opens its party
-- wheel at the press) lets the hold go on, and out of combat that wheel closes with the roll. In combat addon code
-- cannot close it: the player closes it with B. The tooltip does not show then, nor in combat. The log (kind "rolls")
-- says which frames showed, the first press heard in and out of combat, if each roll went, and if the tooltip showed.
local _, ns = ...

local Rolls = ns.Module("Rolls", { "rolls" }, "Roll Buttons")
ns.Rolls = Rolls

local Model = ns.RollsModel
local LOW, GAP = 150, 8    -- with no on-screen buttons the card's middle is LOW under the middle of the screen; GAP: room above the buttons

local ear, ready           -- the frame that hears the controller; true once its switch hands each press on
local card, icon, timer, name, count, words, bar, stack, reason
local entries = {}         -- our key -> its entry of the card's strip of button hints (Widgets.Legend)
local held                 -- the hold that runs now: { key, choice, at }
local rolls = {}           -- the rolls on the screen that have a button to press, top first
local place, focus         -- the place of the roll on the card in that list, and its id
local rest                 -- why A, X and B are not for a roll now (a key of Model.REST), or nil
local since = 0            -- when the card came to that roll by itself, or the buttons rested or came back
local tipped               -- the id of the roll whose tooltip was asked for
local waiting = false      -- a look at the screen is due at the next step
local wheel, mouse, keyboard = nil, false, false   -- the wheel that is open; mouse mode is on; the keyboard is open
local told, tipTold, heard, stackTold = nil, {}, {}, false
local notes = {}           -- lines in the log so far, by group
local tick, changed

-- A few lines for a session: what the game showed and allowed. Read from the saved file. The
-- lines of combat have a count of their own, so that rolls out of combat do not use them up, and
-- so do the rolls made with the call of the game's box (group "box").
local function note(text, group)
    group = tostring(ns.Adapter.InCombat()) .. (group or "")
    notes[group] = (notes[group] or 0) + 1
    if notes[group] <= 12 then
        ns.Log.Add("rolls", text)
    end
end

-- The choices on the card during a hold of key (nil: no hold), full is how far the hold is (1 or
-- more: a let-go makes the roll). A choice the game does not allow for the item is dim, and all
-- three are while the buttons rest. The held button shows its gold ring and the other two go dim,
-- so the held one stands out.
local function shade(roll, key, full)
    for other, entry in pairs(entries) do
        entry:SetAlpha((rest or not (roll and roll[Model.CHOICE[other]])) and 0.25 or (key == nil or other == key) and 1 or 0.35)
        entry.keys.glyphs[1]:SetLit(other == key)
    end
    words:SetText(rest and Model.REST[rest] or key and full >= 1 and Model.LET_GO or Model.WORDS)
    -- (shown from the start of a hold)
    bar:SetPart(key and math.max(full, 0.001) or 0)
end

-- A hold starts for a button, or with nil the hold is over. The frame's update script is set only
-- while a hold runs. A wheel that a hold's press opened rests the buttons once the hold is over.
local function hold(key)
    held = key and { key = key, choice = Model.CHOICE[key], at = GetTime() } or nil
    shade(place and rolls[place], key, 0)
    ear:SetScript("OnUpdate", held and tick or nil)
    if not key and wheel then
        changed()
    end
end

-- The card of the roll in focus, and the item's tooltip beside it. The tooltip is asked for when
-- the focus comes to a roll, not at each drawing. In combat there is none: the screen is the
-- fight's, and the roll is still there after it.
local function draw()
    local roll = place and rolls[place]
    card:SetShown(roll ~= nil)
    if roll then
        icon:SetIcon(roll.icon)
        name:SetText(roll.name)
        local r, g, b = ns.Adapter.DialogueQuality(roll.quality)
        if not r then
            r, g, b = ns.Theme.Color("white")
        end
        name:SetTextColor(r, g, b)
        count:SetText(#rolls > 1 and Model.COUNT:format(place, #rolls) or "")
        stack:SetText(Model.Stack(roll))
        reason:SetText(Model.Reason(roll))
        if not stackTold and (roll.count > 1 or Model.Reason(roll) ~= "") then
            stackTold = true
            note("a roll showed count " .. roll.count .. ", need reason " .. tostring(roll.why), "stack")
        end
        -- the game's own clock runs the sweep and the seconds on the picture: nothing here each frame
        timer:SetCooldown(roll.ends and roll.ends - roll.length or 0, roll.ends and roll.length or 0)
    end
    shade(roll, held and held.key, held and (GetTime() - held.at) / Model.HOLD or 0)
    local id = roll and not rest and not ns.Adapter.InCombat() and roll.id or nil
    if id ~= tipped then
        tipped = id
        if not id then
            ns.Adapter.HideRollTooltip()
        else
            local shown, what = ns.Adapter.ShowRollTooltip(roll, card)
            -- each answer of the game is told one time
            if not tipTold[what] then
                tipTold[what] = true
                note("the tooltip of roll " .. id .. (shown and " shows, " or " does not show: ") .. what)
            end
        end
    end
end

-- The rolls to show from now, and why the buttons rest (nil: they roll). The frame that hears the
-- controller, the focus, the card and the tooltip follow. A hold goes on while its roll keeps the
-- focus and the buttons do not rest.
local function show(list, why)
    local before, was = focus, rest
    rolls, rest = list, why
    ear:SetShown(#rolls > 0 and not rest)
    place = Model.Place(rolls, focus, place)
    focus = place and rolls[place].id
    if focus ~= before or rest ~= was then
        since = GetTime()
        hold(nil)
    end
    draw()
end

-- A look at the screen. The card shows while the row Roll Buttons is on and the game's
-- controller interface is on. The buttons roll while play has the controller, and not while a
-- wheel is open (B closes it; but a hold goes on: its own press opened that wheel), in mouse mode
-- (B turns it off) or while the keyboard is open (A on Done sends the chat line).
local function sync()
    waiting = false
    local list, seen = ns.Adapter.Rolls()
    -- why nothing shows now: the log has it, so one roll in the game tells
    local off = not ns.Registry.Get("controller.roll_buttons") and "the row Roll Buttons is off"
        or not ns.Pad.Controller() and "the game's controller interface is off"
        or not ready and "the frame that hears the controller is not ready"
    local why = not ns.Pad.Gameplay() and "window" or wheel and not held and "wheel" or mouse and "mouse" or keyboard and "keyboard" or nil
    show(off and {} or list, why)
    local line = #list .. " rolls with a button; " .. (off or why and "the card says: " .. Model.REST[why] or "the controller is heard")
        .. "; the game shows " .. tostring(seen)
    if seen and line ~= told then
        told = line
        note(line)
    end
end

-- Something changed: the rolls, who has the controller, a wheel, the setting, combat.
-- The look is one step later: the game has drawn its frames then.
function changed()
    if not waiting then
        waiting = true
        C_Timer.After(0, function()
            ns.Call("Rolls", sync)
        end)
    end
end

-- A full hold is let go: the roll in focus gets the choice, with the game's own call. Two seconds
-- later the log says if the game took the roll. An item that binds on pickup got the call of the
-- game's box: if the roll still shows then out of combat, the roll is made again with the call of
-- its button, and the game asks if the player is sure (Core/AdapterRolls.lua answers for it).
local function choose(choice)
    local roll = place and rolls[place]
    if not (roll and roll[choice]) then
        return
    end
    local id, fight = roll.id, ns.Adapter.InCombat()
    local group = roll.bop and choice ~= "pass" and "box" or nil
    local ran, inside, how = ns.Adapter.PressRoll(roll, choice)
    note(choice .. " on roll " .. id .. (fight and " in combat" or "") .. ": " .. how .. " ran " .. tostring(ran)
        .. ", the game ended the roll inside it: " .. tostring(inside), group)
    -- the game takes a roll off the screen when it has the answer
    C_Timer.After(2, function()
        local still = false
        for _, other in ipairs(ns.Adapter.Rolls()) do
            still = still or other.id == id
        end
        note("roll " .. id .. (still and " still shows" or " is gone") .. " 2 seconds after " .. choice
            .. "; play has the controller: " .. tostring(ns.Pad.Gameplay()), group)
        if still and group and not ns.Adapter.InCombat() then
            local again = select(3, ns.Adapter.PressRoll(roll, choice, true))
            note(choice .. " on roll " .. id .. " again: " .. again, group)
        end
    end)
end

-- A button went down, as the frame heard it. The D-pad changes the roll on the card with two
-- rolls or more. A, X or B starts a hold; its let-go makes the roll after a full hold
-- (Model.Stage). Any other of these buttons that goes down ends a hold with no roll. Every press
-- goes on to the game as well.
local function press(key)
    local roll = place and rolls[place]
    if not (roll and (Model.CHOICE[key] or Model.STEP[key])) then
        return
    end
    hold(nil)
    local fight = ns.Adapter.InCombat()
    if not heard[fight] then
        heard[fight] = true
        note("the frame heard " .. key .. " down" .. (fight and " in combat" or "") .. "; the key reads "
            .. tostring(ns.Adapter.EffectiveBinding(ns.Adapter.KEY[key])))
    end
    local step = Model.STEP[key]
    if step then
        if #rolls > 1 then
            place = Model.Move(place, step, #rolls)
            focus = rolls[place].id
            draw()
        end
        return
    end
    -- no button: the game does not allow this choice for the item, and the card shows it dim
    if not roll[Model.CHOICE[key]] or not Model.Ready(GetTime(), since) then
        return
    end
    -- a held layer button: the press was for a bind of that layer. It makes no roll.
    local lt, rt, lb, rb = ns.Adapter.Held()
    if lt or rt or lb or rb then
        return
    end
    hold(key)
end

-- The work of the update script during a hold: the bar grows, and when it is full the card says
-- to let go. The controller tells of the let-go: after a full hold it makes the roll. A hold that
-- goes on too long was for a spell: the bar empties, and that button counts again at its next press.
local function update()
    local seconds = GetTime() - held.at
    local stage = Model.Stage(seconds)
    if not ns.Adapter.ButtonDown(held.key) then
        local choice = stage == "ready" and held.choice
        hold(nil)
        if choice then
            choose(choice)
            -- the wheel that the press opened (a heal in Healer Mode) closes with the roll
            if wheel then
                local id = wheel
                note(ns.Adapter.CloseWheel("a roll's hold") and "the wheel " .. id .. " that the press opened closes with the roll: true"
                    or "the wheel " .. id .. " that the press opened stays open in combat: B closes it", "wheel")
            end
        end
    elseif stage == "long" then
        hold(nil)
    else
        shade(rolls[place], held.key, seconds / Model.HOLD)
    end
end

-- The frame's update script, each frame during a hold. A fault here would come every frame: it is
-- logged once, and the hold stops.
function tick(self)
    if not ns.Call("Rolls", update) then
        held = nil
        self:SetScript("OnUpdate", nil)
    end
end

-- The card, low in the middle of the screen: its foot is just above the on-screen buttons (their
-- frame, Screen/Hud.lua, which follows the player's size and place for them), so it covers no
-- button, and it stands over the play frames (strata HIGH, as the talk and the wheel). A dark
-- ground with a gold edge, the item's picture (56) with the time left on it, its name, the strip
-- of button hints with A, X and B, and under it the bar of a hold, as on every hold.
local function build()
    local Theme, px = ns.Theme, ns.Theme.px
    card = CreateFrame("Frame", nil, UIParent)
    card:SetSize(px(380), px(136))
    card:SetFrameStrata("HIGH")
    local buttons = _G.GamepadSuiteScreen
    if buttons then
        card:SetPoint("BOTTOM", buttons, "TOP", 0, px(GAP))
    else
        card:SetPoint("CENTER", UIParent, "CENTER", 0, -px(LOW))
    end
    card:Hide()
    Theme.Fill(card, "BACKGROUND", Theme.Color("ground", 0.8)):SetAllPoints()
    for _, side in ipairs({ { "TOPLEFT", "TOPRIGHT" }, { "BOTTOMLEFT", "BOTTOMRIGHT" },
        { "TOPLEFT", "BOTTOMLEFT", true }, { "TOPRIGHT", "BOTTOMRIGHT", true } }) do
        local line = Theme.Fill(card, "OVERLAY", Theme.Color("gold"))
        line:SetPoint(side[1])
        line:SetPoint(side[2])
        if side[3] then
            line:SetWidth(px(2))
        else
            line:SetHeight(px(2))
        end
    end
    icon = ns.Widgets.Icon(card, px(56))
    icon:SetPoint("TOPLEFT", px(14), -px(14))
    timer = CreateFrame("Cooldown", nil, icon, "CooldownFrameTemplate")
    timer:SetAllPoints()
    timer:SetDrawEdge(false)
    timer:SetHideCountdownNumbers(false)
    name = Theme.Text(card, "row", "white")
    name:SetPoint("TOPLEFT", icon, "TOPRIGHT", px(12), -px(4))
    -- "Hold to roll" under the name, so that a player who never saw it knows a tap is not enough
    words = Theme.Text(card, "small", "cream")
    words:SetPoint("BOTTOMLEFT", icon, "BOTTOMRIGHT", px(12), px(4))
    count = Theme.Text(card, "small", "muted")
    count:SetPoint("TOPRIGHT", -px(12), -px(12))
    name:SetPoint("RIGHT", count, "LEFT", -px(8), 0)
    local legend = ns.Widgets.Legend(card, "LEFT")
    legend:SetPoint("BOTTOMLEFT", px(14), px(24))
    local keys = { "A", "X", "B" }
    local list = {}
    for n, key in ipairs(keys) do
        list[n] = { keys = { key }, text = Model.LABEL[key] }
    end
    legend.Set(list)
    for n, key in ipairs(keys) do
        entries[key] = legend.items[n]
    end
    -- the stack's size on the picture, over the clock's sweep (a clock hides when it ends); the reason across the card
    local over = CreateFrame("Frame", nil, icon)
    over:SetAllPoints()
    over:SetFrameLevel(timer:GetFrameLevel() + 1)
    stack = Theme.Text(over, "row", "white")
    stack:SetFont(Theme.font.text, px(Theme.size.row), "OUTLINE")
    stack:SetPoint("BOTTOMRIGHT", -px(4), px(2))
    reason = Theme.Text(card, "tiny", "muted")
    reason:SetPoint("TOPLEFT", icon, "BOTTOMLEFT", 0, -px(2))
    reason:SetPoint("RIGHT", -px(12), 0)
    -- the bar of a hold along the foot, full when the hold is long enough
    bar = ns.Widgets.HoldLine(card, 12)
end

function Rolls.OnLogin()
    build()
    ear = CreateFrame("Frame", nil, UIParent)
    ear:SetFrameStrata("BACKGROUND")
    ear:SetSize(1, 1)
    ear:SetPoint("TOPLEFT")
    ear:Hide()
    -- "true" as well: the game's own flyout says so for a press it hands on (Screen/Keyboard.lua)
    ear:SetScript("OnGamePadButtonDown", function(_, button)
        ns.Call("Rolls", press, ns.Adapter.NAME[button])
        return true
    end)
    -- The game takes the frame's switches out of combat only (after a reload in combat, at its
    -- end). Until the one that hands each press on reads as set, the frame never shows: it would
    -- keep every press.
    ns.Queue.Run("Rolls", function()
        ear:EnableGamePadButton(true)
        ready = ns.Adapter.HandSticksOn(ear)
        ns.Log.Add("rolls", "the frame that hears the controller hands each press on to the game: " .. tostring(ready))
        changed()
    end)
    ns.Adapter.OnRollsChanged(changed)
    ns.Listen("pad", "Rolls", changed)
    ns.Listen("wheel", "Rolls", function(id)
        wheel = id
        changed()
    end)
    ns.Listen("pointer", "Rolls", function(on)
        mouse = on
        changed()
    end)
    ns.Listen("keyboard", "Rolls", function(open)
        keyboard = open
        changed()
    end)
    ns.Listen("setting", "Rolls", function(key)
        if key == "controller.roll_buttons" then
            changed()
        end
    end)
    -- the tooltip goes when combat starts, and comes back when it ends
    ns.On("PLAYER_REGEN_ENABLED", "Rolls", changed)
    ns.On("PLAYER_REGEN_DISABLED", "Rolls", changed)
    -- rolls that are on the screen already (a reload in a dungeon)
    changed()
end
