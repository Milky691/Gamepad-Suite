-- The on-screen buttons: two groups that show what each controller button does now. They take
-- the place of Blizzard's own gamepad bar, which cannot show the player's binds. They only show:
-- a press goes from the key to the bind core's secure buttons or to the game's own bar, not
-- through these frames. A button shows a bind of ours, or the game's own action for that button
-- and layer where we have none. The rules (places, the layer in view, the colours, the fade, the
-- three looks of the row Button Look) are in HudModel.lua; the parts of one button are in
-- HudFace.lua; the list of what a button shows is build_plan/packs/P01_bound_button.md.
local _, ns = ...

local Hud = ns.Module("Screen", nil, "On-Screen Buttons")
ns.Screen = Hud

local Theme, Widgets, Model, Face = ns.Theme, ns.Widgets, ns.HudModel, ns.HudFace
local px = Theme.px

local frame
-- buttons: the look's name and the key ("RoundA") -> the button, which keeps its look
local groups, buttons = {}, {}
local lastPress, lastLayer = 0, nil
-- strength: how strongly the buttons show. watching: tick() runs. polling: it reads the controller.
local strength, watching, polling = nil, false, false
-- padMark: the buttons that were down at the watch's last look, as one number. last: what the last full draw found.
local padMark, last = 0, {}
-- the rows of the page Layout; while one of them changes, the buttons show above the settings window
local LAYOUT = { ["screen.x"] = true, ["screen.y"] = true, ["screen.size"] = true, ["screen.spread"] = true, ["screen.look"] = true,
    ["screen.other_layers"] = true }

-- the game's own action for a button that has no bind of ours (the rule is HudModel.Game)
local game

-- A fixed slot and a line of the cooldown list are the same button, in the chosen look; a fixed slot holds one for each
-- look it was shown in (Screen/Slots.lua): Fill and Look act on the one of the look now (the Slot Binds page shows them).
local function now(b) return rawget(b, "Face") and b.Face() or b end
Hud.Face, Hud.Cool, Hud.Count = Face.Make, Face.Cool, Face.Count
function Hud.Fill(b, bind, numbers) Face.Fill(now(b), bind, numbers) end
function Hud.Look(b) Face.Look(now(b)) end

-- The peek over the settings window, of every on-screen part (HudFace.lua).
Hud.Peek, Hud.Peeking = Face.Peek, Face.Peeking

-- The button of a look for one entry of Model.Buttons (Bars: one for each layer, Screen/HudBars.lua).
local function button(look, slot)
    local id = look.name .. (slot.layer or "") .. slot.key
    local b = buttons[id]
    if not b then
        b = Face.Make(frame, look, slot.size)
        b.key, b.index, b.layer = slot.key, ns.Adapter.PadIndex(slot.key), slot.layer or false
        Face.Badge(b, look, slot)
        buttons[id] = b
    end
    return b
end

-- How strongly the buttons show now. quiet: the caller tells the fixed slots and the cooldown
-- list itself.
local function fade(quiet)
    local idle = GetTime() - lastPress
    local busy = ns.Adapter.InCombat() or ns.Adapter.EnemyTargeted() or ns.Drop.Carrying() or ns.HudParty and ns.HudParty.On()
    -- out of sight on a mount or at rest (Screen/HudHide.lua) but not with a thing in reach (Dynamic
    -- Interact shows it), else the dim of Fade When Idle
    local now = ns.HudHide and ns.HudHide.Hidden(busy, last.interact ~= nil) and 0 or Model.Alpha(ns.Registry.Get("screen.fade_when_idle"), busy, idle)
    if now ~= strength then
        strength = now
        frame:SetAlpha(now)
        if not quiet then
            -- the fixed slots and the cooldown list dim with the buttons
            ns.Send("screen:look")
        end
    end
end

-- The watch runs on each frame, and only while there is something to wait for: a controller
-- button is down (Hud.Poll, twenty times a second), or the buttons are awake and their dim is
-- still to come (one look at the clock; none comes with Fade When Idle Off). Else nothing runs.
local since = 0
local function tick(self, elapsed)
    since = since + elapsed
    if since < 0.05 then
        return
    end
    since = 0
    if polling then
        -- a fault here would come twenty times a second: it is logged once and the watch stops
        if not ns.Call("Screen", Hud.Poll) then
            self:SetScript("OnUpdate", nil)
        end
    elseif GetTime() - lastPress >= Model.IDLE or ns.Registry.Get("screen.fade_when_idle") == "Off" then
        watching = false
        self:SetScript("OnUpdate", nil)
        ns.Call("Screen", fade)
    end
end

-- A press, or a change the player made: the buttons wake from the dim, and the watch waits for
-- the next dim. down: a controller button can be down now, so the watch reads the controller.
local function active(down)
    lastPress = GetTime()
    fade()
    polling = polling or down == true
    if not watching then
        watching = true
        frame:SetScript("OnUpdate", tick)
    end
end

-- The layer in view. down: the controller's buttons, when the caller has read them already.
local function layerNow(down)
    -- in mouse mode a trigger is a mouse button and no layer (Screen/Pointer.lua)
    if ns.Pointer and ns.Pointer.IsOn() then
        return 1
    end
    local lt, rt = ns.Adapter.Held(down)
    -- a trigger held or kept on by a tap ("L", "R" or "LR", Sticky Layers); LB + RB while the bind core holds that layer
    local stuck = ns.BindCore.Stuck() or ""
    lt, rt = lt or stuck:find("L", 1, true) ~= nil, rt or stuck:find("R", 1, true) ~= nil
    return Model.Layer(lt, rt, ns.BindHolds.Both() and ns.Registry.Get("layers.hold_lb_rb_set"))
end

-- Are the on-screen buttons shown, how strong (the dim after idle seconds), and which layer is
-- in view. The fixed slots and the cooldown list follow them.
function Hud.State()
    return frame ~= nil and frame:IsShown(), frame and frame:GetAlpha() or 1, lastLayer or 1
end

-- Tells fn each on-screen button that is in use: b.key is its button, b.bind what it shows (the
-- cooldown list leaves those out; a drop with the mouse lands on one).
function Hud.Each(fn)
    for _, b in pairs(buttons) do
        if b.used then
            fn(b)
        end
    end
end

local function drawOne(look, slot, interact, numbers, ring)
    local b = button(look, slot)
    b.used = true
    Face.Show(b, look, slot, groups[slot.group] or slot.group, interact, numbers, ring)
    last.button = interact and b or (last.button ~= b and last.button or nil)   -- the button of Dynamic Interact now
end

function Hud.Draw()
    if not frame then
        return
    end
    local get = ns.Registry.Get
    local forms = get("layers.forms_and_stances") ~= "Off" and ns.Adapter.Forms() or {}
    local state = ns.Adapter.BindState(get("layers.combat_set"), forms, get("layers.forms_and_stances") == "Combat First")
    -- a bind, false for a slot that the player made empty on purpose in the set in use, or nil
    local from, ring = {}, get("screen.form_ring")
    local find = function(layer, key)
        local bind, set = ns.BindRules.Find(ns.Binds.Get, state, layer, key)
        -- a bind of the moment (Fishing Pole, Slot 3) shows as what it runs now
        bind = bind and ns.BindRules.Real(bind)
        if bind then
            from[bind] = set
            return bind
        elseif set then
            return false
        end
        return nil
    end
    local numbers, look = get("screen.cooldown_numbers"), Model.Look(get("screen.look"))
    for _, b in pairs(buttons) do
        b.used = false
    end
    local layer, bound, rings = layerNow(), {}, {}
    lastLayer = layer
    -- Dynamic Interact: with no trigger held, its button shows what a press does now. With a
    -- fishing pole in the hands that is Fishing, and Interact while the line is out (Core/Hands.lua).
    local rod = layer == 1 and ns.Hands.on and ns.Hands.Rod() or nil
    -- (spot: the button of Dynamic Interact, with or without a thing in reach)
    local spot = layer == 1 and ns.BindCore.InteractButton(state, true) or nil
    local interact = spot and (rod == "interact" or ns.Adapter.InteractNear()) and spot or nil
    local rodKey = rod and rod ~= "interact" and not interact and spot or nil
    -- the Interact button shows its other job while it has one: the attack, or Fishing
    local job = layer == 1 and ns.Hands.on and ns.Hands.Shown() or nil
    -- the buttons of the controller picture in use
    local keys = Model.Keys(Widgets.PAD[Widgets.PadStyle()].order or Widgets.PAD.xbox.order)
    game = game or Model.Game(ns.Adapter, ns.Catalog.CommandIcon)
    local slots = look.bars and ns.HudBars.Buttons(find, game, look, frame, layer, keys) or Model.Buttons(find, layer, keys, game, look)
    for _, slot in ipairs(slots) do
        -- (here: the button of the layer in view; with Bars the other bars show their layer's binds and no more)
        local bind, here, id = slot.bind, (slot.layer or layer) == layer, (slot.layer or "") .. slot.key
        if here and slot.key == rodKey then
            slot.bind = rod
        elseif here and job and bind and bind.kind == "command" and bind.id == ns.BindRules.INTERACT_TARGET then
            slot.bind = job
        end
        bound[slot.key] = slot.bind ~= nil or slot.key == interact
        rings[id] = ring and slot.bind and Model.Ring(from[slot.bind]) or nil
        -- a fault in one button's drawing is logged and does not stop the others
        ns.Call("Screen", drawOne, look, slot, here and slot.key == interact, numbers, rings[id])
    end
    last.spot, last.rod, last.interact, last.slots, last.rings, last.bound, last.look, last.numbers, last.job = spot, rod, interact, slots, rings, bound, look, numbers, job and job.id
    for _, b in pairs(buttons) do
        if not b.used then
            b:Hide()
        end
    end
    -- the plate, the layer's name and the pictures in the middle of a group, in a look that has them
    ns.Call("Screen", Face.Backs, groups, look, layer, bound)
    -- the small pictures of the other layers on the main buttons (Screen/HudMini.lua), with the row Other Layers on
    ns.Send("screen:minis", get("screen.other_layers") and not look.bars and not (ns.HudParty and ns.HudParty.On()) and find, game, look, layer, slots, buttons)
    -- the buttons step back while a window has the controller, and when the game is not played
    -- with one; they stay while the pointer carries a spell from the spellbook or a bag (Screen/Drop.lua)
    local peek = Hud.Peeking("Screen", frame)
    frame:SetShown(peek or (ns.Pad.Gameplay() or ns.Drop.Carrying()) and ns.Adapter.PadActive())
    fade(true)
    -- The fixed slots and the cooldown list follow a full draw. With true, the set of binds in
    -- use changed (a fight, a form): a fixed slot then looks for its button again.
    local set = tostring(state.combat) .. tostring(state.form)
    ns.Send("screen", set ~= last.set)
    last.set = set
end

-- Something came in reach or went out of it: the button of Dynamic Interact changes, and no
-- other button is drawn.
local function near()
    local key = last.spot and (last.rod == "interact" or ns.Adapter.InteractNear()) and last.spot or nil
    if key == last.interact then
        if key and last.button then
            -- the same button, another thing in reach: its picture
            ns.Adapter.InteractPicture(last.button.icon.art)
        end
        return
    end
    for _, slot in ipairs(last.slots) do
        if (slot.layer or 1) == 1 and (slot.key == key or slot.key == last.interact) then
            last.bound[slot.key] = slot.bind ~= nil or slot.key == key
            drawOne(last.look, slot, slot.key == key, last.numbers, last.rings[(slot.layer or "") .. slot.key])
        end
    end
    last.interact = key
    Face.Backs(groups, last.look, lastLayer, last.bound)
    -- a thing in reach brings the buttons back from Hide While Mounted or Resting
    fade()
end

-- Where the buttons sit and how large they are (the page Layout). X and Y are from the place they have at first,
-- at the bottom in the middle; Spread moves the two groups apart (with Bars, the two columns: Screen/HudBars.lua).
local function layout()
    local get = ns.Registry.Get
    local scale = get("screen.size") / 100
    frame:SetScale(scale)
    frame:ClearAllPoints()
    -- a look that reaches farther down than Square is lifted where its lowest pictures would leave the screen
    local lift = Model.Lift(Model.Look(get("screen.look")), scale, 70 + get("screen.y"))
    -- (a frame's place is counted in its own scale: the two numbers are units of the screen)
    frame:SetPoint("BOTTOM", UIParent, "BOTTOM", px(get("screen.x")) / scale, px(70 + get("screen.y") + lift) / scale)
    for name, side in pairs({ left = -1, right = 1 }) do
        groups[name]:ClearAllPoints()
        groups[name]:SetPoint("CENTER", frame, "CENTER", side * px(300 + get("screen.spread")), 0)
    end
end

-- Many game events can come in one frame. The work is done once, on the next frame: a full draw
-- ("draw") when what a button shows can change (a bind, a layer, a form, a set, a setting, the look,
-- the Interact button's other job), or only the passes asked for: "cool" the clocks, "count" the
-- counts, "look" the colors and the rims, "near" the button of Dynamic Interact. The fixed slots follow.
local asked, want = false, {}
local function work()
    if want.draw or want.near and (ns.Hands.on and ns.Hands.Shown() or {}).id ~= last.job then
        Hud.Draw()
    else
        if want.near then
            near()
        end
        if want.cool then
            Hud.Each(Face.Cool)
        end
        if want.count then
            Hud.Each(Face.Count)
        end
        -- (an item that is used up can be used no more)
        if want.look or want.count then
            Hud.Each(Face.Look)
            ns.Send("screen:look")
        end
        if want.cool or want.count then
            ns.Send("screen:cool", want.count)
        end
    end
    for what in pairs(want) do
        want[what] = nil
    end
end

local function ask(what)
    want[what] = true
    if not asked then
        asked = true
        C_Timer.After(0, function()
            asked = false
            ns.Call("Screen", work)
        end)
    end
end

local function draw() ask("draw") end

-- Twenty times a second, and only while a controller button is down (a press or a held trigger
-- starts it). The controller is read once. When the same buttons are down as at the last look,
-- nothing else is done. At a change: the picture of a held button goes dark, the buttons stay
-- awake, and the layer in view follows a button that joins a hold (RB after LB). With no button
-- down it ends, and the looks are read once: a press can start an attack that waits for a swing.
function Hud.Poll()
    local down, mark = ns.Adapter.PadState(), 0
    for index, on in pairs(down) do
        if on == true then
            mark = mark + 2 ^ index
        end
    end
    if mark ~= padMark then
        padMark = mark
        for _, b in pairs(buttons) do
            if b.used then
                b.shade:SetShown(b.bind and b.index and down[b.index] == true and (b.layer or lastLayer) == lastLayer or false)
            end
        end
        ns.Send("screen:poll", down)
        lastPress = GetTime()
        if layerNow(down) ~= lastLayer then
            draw()
        end
        fade()
    end
    if mark == 0 then
        polling = false
        Hud.Each(Face.Look)
        ns.Send("screen:look")
    end
end

function Hud.OnLogin()
    frame = CreateFrame("Frame", "GamepadSuiteScreen", UIParent)
    frame:SetSize(px(900), px(260))
    for _, name in ipairs({ "left", "right" }) do
        groups[name] = CreateFrame("Frame", nil, frame)
        groups[name]:SetSize(px(220), px(260))
    end
    layout()
    ns.Adapter.NativeBarAlpha(0)

    -- The game's events, and the pass that each asks for (see ask and HudModel.lua, Model.EVENTS).
    -- An event this game version does not have is left out.
    for what, events in pairs(Model.EVENTS) do
        for _, event in ipairs(events) do
            pcall(ns.On, event, "Screen", function() ask(what) end)
        end
    end
    -- The target went out of reach or came back: the game's event for the spells and slots that
    -- Face.Fill named to it. The first one goes in the log, so one play tells that the event comes.
    local told = false
    for _, event in ipairs({ "SPELL_RANGE_CHECK_UPDATE", "ACTION_RANGE_CHECK_UPDATE" }) do
        pcall(ns.On, event, "Screen", function()
            if not told then
                told = true
                ns.Log.Add("screen", "The game sent " .. event .. ": the red of a target out of reach follows the game's event.")
            end
            ask("look")
        end)
    end
    -- the game's own bar changed its page or the bar in use: it sends no game event for that
    ns.Adapter.OnNativeBarChanged(draw)
    -- one of the game's own eight bar buttons went down or up, for a button with no bind of ours
    ns.Adapter.OnNativePress(function() active(true) end)
    -- a trigger went down or up (one that is a modifier key, one that is none), or a tap keeps a layer on
    local function hold()
        active(true)
        draw()
    end
    ns.On("MODIFIER_STATE_CHANGED", "Screen", hold)
    ns.Listen("hold", "Screen", hold)
    -- a bind, a fixed slot or a wheel changed; the fishing line or the pole; a window took the
    -- controller; the pointer took up or let go a spell to drop on a button; Hide While Mounted
    -- or Resting changed its answer; the party look of Healer Mode came or went (Screen/HudParty.lua)
    for _, message in ipairs({ "bind", "drop", "slots", "wheels", "line", "hands", "marknext", "pad", "screen:hide", "screen:party" }) do
        ns.Listen(message, "Screen", draw)
    end
    ns.Listen("setting", "Screen", function(key)
        if LAYOUT[key] then
            layout()
            Hud.Peek("Screen", draw)
            active()
        end
        draw()
    end)
    ns.Listen("press", "Screen", function(signature)
        active(true)
        for _, b in pairs(buttons) do
            if b.used and b.signature and b.signature == signature then
                b.flash:Show()
                C_Timer.After(0.12, function() b.flash:Hide() end)
            end
        end
    end)
    active()
    Hud.Draw()
end
