-- Mouse Mode at the Auction House: our pointer (Screen/Pointer.lua) comes on when the auction window opens and goes
-- off when it closes, out of combat. A pointer that was on before the window opened is left on. B and the bind still
-- turn it off; one the player turns on again at the auction house is theirs and stays on after it. The row
-- controller.pointer_auction (Mouse Mode page) starts On.
--
-- The game's word is its interaction manager's (PLAYER_INTERACTION_MANAGER_FRAME_SHOW and _HIDE with the kind
-- Auctioneer): the auction window opens at it, before AUCTION_HOUSE_SHOW (decision 143). The pointer comes on and goes
-- off one frame after that word, never inside it: it takes keys. Pointer.On says no in combat, with a wheel open, and
-- with the game's controller interface off; the log (kind "pointer") has the first four tries of a session.
local _, ns = ...

local Auction = ns.Module("PointerAuction", { "pointer" }, "Mouse Mode at the Auction House")

local KEY = "controller.pointer_auction"
local open = false   -- the auction window is open
local mine = false   -- mouse mode is on because the auction window opened
local notes = 0

-- (a row that is not in Settings/Data.lua yet has its start value, On)
local function wanted()
    return not ns.Registry.Has(KEY) or ns.Registry.Get(KEY) ~= false
end

local function cameOn()
    if not open or ns.Pointer.IsOn() then
        return
    end
    local on, why = ns.Pointer.On()
    mine = on
    if notes < 4 then
        notes = notes + 1
        ns.Log.Add("pointer", "the auction house opened: mouse mode " .. (on and "came on" or "did not come on: " .. tostring(why)))
    end
end

local function wentOff()
    if mine and not (ns.Adapter.InCombat() or ns.fightStarted) then
        mine = false
        ns.Pointer.Off()
    end
end

function Auction.OnLogin()
    ns.On("PLAYER_INTERACTION_MANAGER_FRAME_SHOW", "PointerAuction", function(kind)
        if ns.Adapter.AuctionKind(kind) and wanted() then
            open = true
            C_Timer.After(0, function()
                ns.Call("PointerAuction", cameOn)
            end)
        end
    end)
    ns.On("PLAYER_INTERACTION_MANAGER_FRAME_HIDE", "PointerAuction", function(kind)
        if ns.Adapter.AuctionKind(kind) then
            open = false
            if mine then
                C_Timer.After(0, function()
                    ns.Call("PointerAuction", wentOff)
                end)
            end
        end
    end)
    -- B, the bind, a wheel, a fight: mouse mode ended its own way, and is no longer ours to end
    ns.Listen("pointer", "PointerAuction", function(on)
        if not on then
            mine = false
        end
    end)
end
