-- The hints row of the dialogue view, at the foot of its column: at the left the place in the
-- text (a bar for each part, and the arrow "more follows"), at the right the button hints, in the
-- strip of every part (Widgets.Legend). And
-- the time left of a part when the text moves on by itself: a thin gold line at the foot of the
-- words. Screen/DialogueDraw.lua makes the rest and calls Foot.Build.
local _, ns = ...

local Theme, Widgets, Model = ns.Theme, ns.Widgets, ns.DialogueModel
local px = Theme.px

local Foot = {}
ns.DialogueFoot = Foot

local MORE = "Interface\\Buttons\\Arrow-Down-Up"
local HIGH = 26
local TIME_Y = 203   -- the line of the time left, from the top of the block (the words end at 196)
local ui = {}
local bars = {}
local left, total, whole, after = 0, 0, 0, nil   -- the time left of a part, its whole time, the line's full width, what comes after

-- parent: the frame of all that is at the right of the portrait. col: the column. left: where
-- the words start in the column.
function Foot.Build(parent, col, left)
    ui.parent, ui.col, ui.left = parent, col, left
    -- "5 of 20", for a text of more parts than there are bars
    ui.place = Theme.Text(parent, "row", "muted")
    ui.place:SetPoint("LEFT", col, "BOTTOMLEFT", px(left), px(HIGH / 2))
    -- "more follows": the game's small arrow, which dims and comes back while it shows
    ui.more = parent:CreateTexture(nil, "ARTWORK")
    ui.more:SetTexture(MORE)
    ui.more:SetSize(px(24), px(24))
    ui.blink = ui.more:CreateAnimationGroup()
    ui.blink:SetLooping("BOUNCE")
    local dim = ui.blink:CreateAnimation("Alpha")
    dim:SetFromAlpha(1)
    dim:SetToAlpha(0.45)
    dim:SetDuration(0.8)
    -- the time left of a part, and the frame whose script runs only while that time runs
    ui.time = Theme.Fill(parent, "OVERLAY", Theme.Color("gold", 0.8))
    ui.time:SetHeight(px(2))
    ui.time:SetPoint("TOPLEFT", col, "TOPLEFT", px(left), -px(TIME_Y))
    ui.time:Hide()
    ui.clock = CreateFrame("Frame", nil, parent)
    -- the button hints, the right edge at the column's: a click on a hint is a press of its button,
    -- so the mouse and mouse mode reach every step (Screen/DialogueInput.lua is loaded later; the
    -- D-pad's hint stands for four buttons: no click)
    ui.legend = Widgets.Legend(parent, "RIGHT", function(key)
        if key ~= "DPAD" then
            ns.DialogueInput.Key(key)
        end
    end)
    ui.legend:SetPoint("BOTTOMRIGHT", col, "BOTTOMRIGHT")
end

-- The place in the text: a bar for each part when there are two or more (sixteen at most; more
-- parts are told as "5 of 20"), and after it the arrow when a part follows (more). They are
-- under the block of the words, so no line of text can reach them.
function Foot.Place(state, more)
    local count, many = state.count, state.count > Model.BARS
    local after = ui.left
    for n = 1, math.max(count, #bars) do
        if n <= count and count > 1 and not many then
            if not bars[n] then
                bars[n] = Theme.Fill(ui.parent, "ARTWORK", 1, 1, 1, 1)
                bars[n]:SetSize(px(22), px(3))
                bars[n]:SetPoint("LEFT", ui.col, "BOTTOMLEFT", px(ui.left + (n - 1) * 28), px(HIGH / 2))
            end
            if n == state.part then
                bars[n]:SetColorTexture(Theme.Color("gold"))
            elseif n < state.part then
                bars[n]:SetColorTexture(Theme.Color("goldDeep", 0.7))
            else
                bars[n]:SetColorTexture(Theme.Color("cream", 0.22))
            end
            bars[n]:Show()
            after = ui.left + n * 28 - 6
        elseif bars[n] then
            bars[n]:Hide()
        end
    end
    ui.place:SetShown(many)
    ui.place:SetText(many and state.part .. " of " .. count or "")
    ui.more:SetShown(more)
    if more then
        -- 12 after the last bar, its top 6 under the row's top: the file has its triangle in its
        -- upper half, so the triangle is on the line of the bars
        ui.more:ClearAllPoints()
        if many then
            ui.more:SetPoint("TOPLEFT", ui.place, "RIGHT", px(12), px(HIGH / 2 - 6))
        else
            ui.more:SetPoint("TOPLEFT", ui.col, "BOTTOMLEFT", px(after + 12), px(HIGH - 6))
        end
        ui.blink:Play()
    else
        ui.blink:Stop()
    end
end

-- The button hints (Model.Hints), each the button's picture and a word. A button that does
-- nothing now is dim.
function Foot.Hints(list)
    ui.legend.Set(list)
    ui.pad = nil
    for _, item in ipairs(ui.legend.items) do
        ui.pad = item:IsShown() and item.key == "DPAD" and item or ui.pad
    end
end

-- A press of A that cannot act (on) and 0.2 seconds after it (off): the D-pad's hint lights up.
function Foot.Sign(on)
    if ui.pad then
        ui.pad.text:SetTextColor(Theme.Color(on and "gold" or "cream"))
    end
end

-- The time of a part runs out: the line shrinks, and at the end done() is told. A fault stops it.
local function tick(elapsed)
    left = left - elapsed
    if left > 0 then
        ui.time:SetWidth(math.max(1, whole * left / total))
        return
    end
    local done = after
    Foot.Time(nil)
    done()
end

local function onUpdate(_, elapsed)
    if not ns.Call("Dialogue", tick, elapsed) then
        Foot.Time(nil)
    end
end

-- The text moves on by itself: seconds for the part in view (nil: no time runs), the width of
-- the words, and done (what comes when the time is up).
function Foot.Time(seconds, width, done)
    total, left, whole, after = seconds or 0, seconds or 0, px(width or 0), done
    ui.time:SetShown(seconds ~= nil)
    ui.time:SetWidth(whole)
    ui.clock:SetScript("OnUpdate", seconds and onUpdate or nil)
end

-- True while the time of a part runs.
function Foot.Timing()
    return after ~= nil
end

-- The view goes: the arrow rests and no time runs.
function Foot.Rest()
    ui.blink:Stop()
    Foot.Time(nil)
end
