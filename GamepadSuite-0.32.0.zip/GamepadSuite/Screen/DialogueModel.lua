-- The rules of the dialogue view, with no game calls: how an NPC's text is cut into parts, how
-- long a part shows when the text moves on by itself, how a part is said, and where the focus
-- starts. What each button does and which hints show is in Screen/DialogueKeys.lua.
--
-- A talk is one of four kinds. "gossip": the NPC's words and one list of rows (quests and
-- choices). "offer": a quest's text in parts, then the last part with the objectives and the
-- rewards. "progress": the NPC's question and the quest's objectives with their counts.
-- "handin": the NPC's thanks and the rewards. A quest's last part can be asked about first (confirm): the game asks
-- before a quest that flags the player for PvP and before a hand-in that costs money.
local _, ns = ...

local Model = {}

Model.ROWS = 5                              -- the rows of the list that show at one time
Model.TALK, Model.READ, Model.LAST = 540, 912, 500   -- the width of the words: beside the list, alone, beside the rewards
Model.TALK_LINES, Model.READ_LINES = 5, 4   -- the lines of a part
Model.TILES = 8                             -- the most items the rewards show
Model.BARS = 16                             -- the most parts that have a bar each; more are told as "5 of 20"

-- The sentences of a paragraph. A sentence ends at a period, a question mark or an exclamation
-- mark with a space after it, or at the paragraph's end.
-- Limit: "Mr. Hale" ends a sentence too. It only moves where a part may end.
local function sentences(paragraph)
    local out, from = {}, 1
    while true do
        local _, to = paragraph:find("[%.%?!][\"')]*%s+", from)
        if not to then
            break
        end
        out[#out + 1] = paragraph:sub(from, to):match("^(.-)%s*$")
        from = to + 1
    end
    if from <= #paragraph then
        out[#out + 1] = paragraph:sub(from)
    end
    return out
end

-- The start of a text that fits in limit lines, cut at a word, and the rest. A first word that
-- alone is too long goes whole.
local function fit(text, limit, lines)
    local head, after
    for _, to in text:gmatch("()%S+()") do
        if head and lines(text:sub(1, to - 1)) > limit then
            break
        end
        head, after = text:sub(1, to - 1), to
    end
    return head, (text:sub(after):gsub("^%s+", ""))
end

-- The seconds a part shows when the text moves on by itself: one and a half, and one more for
-- each twenty letters; three at least.
function Model.Time(text)
    return math.max(3, 1.5 + #(text or "") / 20)
end

-- How a part is said: "emote" for a text in angle brackets (<She bows.>), else by its last mark:
-- "ask" (?), "shout" (!) or "talk".
function Model.Tone(text)
    text = (text or ""):match("^%s*(.-)%s*$")
    if text:find("^<") and text:find(">$") then
        return "emote"
    end
    local mark = text:match("([%?!])[\"')]*$")
    return mark == "?" and "ask" or mark == "!" and "shout" or "talk"
end

-- Cuts a text of the game into parts of at most limit lines. lines(text) says how many lines a
-- text takes at the width it will show in.
--   A part is filled sentence by sentence. A sentence that does not fit starts the next part.
--   A sentence that alone is too long is cut at the last word that fits.
--   The end of a paragraph ends the part, unless the whole next paragraph fits in the lines
--   that are left: then it joins, on a new line.
function Model.Cut(text, limit, lines)
    local parts, now = {}, nil
    for paragraph in (text or ""):gmatch("[^\r\n]+") do
        paragraph = paragraph:match("^%s*(.-)%s*$")
        if paragraph ~= "" and now and lines(now .. "\n" .. paragraph) <= limit then
            now = now .. "\n" .. paragraph
        elseif paragraph ~= "" then
            parts[#parts + 1], now = now, nil
            for _, sentence in ipairs(sentences(paragraph)) do
                local try = now and (now .. " " .. sentence) or sentence
                if lines(try) <= limit then
                    now = try
                else
                    parts[#parts + 1], now = now, sentence
                    while now ~= "" and lines(now) > limit do
                        parts[#parts + 1], now = fit(now, limit, lines)
                    end
                    now = now ~= "" and now or nil
                end
            end
        end
    end
    parts[#parts + 1] = now
    return parts
end

-- The name of an objective: the game's text for it without the count. The game writes the count
-- into the text, at the end ("Wolf Claw: 2/6") or at the start ("2/6 Wolf Claw").
function Model.GoalName(text)
    local name = (text or ""):gsub("^%s*%d+%s*/%s*%d+%s*", "")
    name = name:gsub("%s*:?%s*%d+%s*/%s*%d+%s*$", "")
    name = name:match("^%s*(.-)%s*$")
    return name ~= "" and name or text or ""
end

-- The rows of a quest in progress, and true when they are the small rows. data.goals are the
-- game's objectives ({ text, have, need, done }); a row whose name is the name of a needed item
-- has that item's picture. With no objectives (a quest that is not in the log) the rows are the
-- needed items. Money that the quest needs is one more row. Three rows are large. Four are
-- small; of more than four the rows that are not done come first, and four show.
function Model.Goals(data)
    local rows = {}
    for _, goal in ipairs(data.goals or {}) do
        local row = { name = Model.GoalName(goal.text), have = goal.have or 0, need = goal.need or 0, done = goal.done and true or false }
        for _, item in ipairs(data.needed) do
            row.icon = row.icon or (item.name == row.name and item.icon) or nil
        end
        rows[#rows + 1] = row
    end
    for _, item in ipairs(#rows == 0 and data.needed or {}) do
        rows[#rows + 1] = { name = item.name, icon = item.icon, have = item.have, need = item.count, done = item.have >= item.count }
    end
    if (data.needMoney or 0) > 0 then
        rows[#rows + 1] = { name = data.coins or "", coins = true, done = false }
    end
    local tight = #rows >= 4
    if #rows > 4 then
        local order = {}
        for _, done in ipairs({ false, true }) do
            for _, row in ipairs(rows) do
                order[#order + 1] = row.done == done and row or nil
            end
        end
        rows = { order[1], order[2], order[3], order[4] }
    end
    return rows, tight
end

-- The rank of a row of a list for the first focus: a quest to hand in that is done, a quest to
-- take, a choice, a quest that is not done. A row that cannot be taken has none.
local function rank(row)
    if row.off then
        return 0
    elseif row.act == "gossipActive" or row.act == "greetActive" then
        return row.ready and 4 or 1
    end
    return row.act == "option" and 2 or 3
end

-- A new talk. data is what the adapter read: for a gossip { text, rows = { { text, act, id, off,
-- ready } } }; for a quest { title, text, objectives, fixed = {}, choices = {}, needed = {}, goals,
-- needMoney, completable, confirm, auto }. lines(width, text) counts the lines of a text at a
-- width. before is the state this one takes the place of: when it showed the same text, the part
-- and the focus stay (the game told that an item or the quest log changed).
function Model.Open(kind, data, lines, before)
    local s = { kind = kind, data = data, part = 1, focus = 0, top = 1 }
    local function cut(width, limit)
        return Model.Cut(data.text, limit, function(text) return lines(width, text) end)
    end
    if kind == "gossip" then
        s.parts = cut(Model.TALK, Model.TALK_LINES)
        -- the first focus is on the first row of the best rank, and the list shows it
        s.focus = #data.rows > 0 and 1 or 0
        for n, row in ipairs(data.rows) do
            s.focus = rank(row) > rank(data.rows[s.focus]) and n or s.focus
        end
        s.top = math.max(1, s.focus - Model.ROWS + 1)
    else
        -- what the last part shows at the right
        if kind ~= "progress" then
            s.side = "rewards"
        else
            s.goals, s.tight = Model.Goals(data)
            s.side = #s.goals > 0 and "goals" or nil
        end
        -- a short text at a hand-in or in a quest in progress shows beside the rewards, as one part
        local short = kind ~= "offer" and s.side and lines(Model.LAST, data.text) <= Model.READ_LINES
        s.parts = short and { data.text } or cut(Model.READ, Model.READ_LINES)
        -- the last part comes after the text: always in an offer, and after a long text
        s.extra = kind == "offer" or (s.side ~= nil and not short)
    end
    if #s.parts == 0 and not s.extra then
        s.parts = { "" }
    end
    s.count = #s.parts + (s.extra and 1 or 0)
    if before and before.kind == kind and before.data.text == data.text and before.data.title == data.title then
        s.part = math.min(before.part, s.count)
        s.confirm = data.confirm and before.confirm or nil
        local most = kind == "gossip" and #data.rows or #data.fixed + #data.choices
        s.focus = math.min(before.focus, most)
        if kind == "gossip" then
            s.focus = math.max(s.focus, most > 0 and 1 or 0)
            s.top = math.max(1, math.min(before.top, s.focus), s.focus - Model.ROWS + 1)
        end
    end
    return s
end

-- What the part in view shows: words (nil for none), width (of the words), side ("list",
-- "rewards", "goals" or nil), objectives (true in the last part of an offer), last (the part
-- where A acts), more (a part follows), ask (the game's question before the last step).
function Model.View(s)
    local last = s.part == s.count
    -- (head: the title with the quest's level and kind, Core/AdapterDialogue.lua)
    local view = { last = last, more = not last, title = s.data.head or s.data.title, width = Model.READ }
    if s.kind == "gossip" then
        view.words, view.width, view.side, view.last = s.parts[s.part], Model.TALK, "list", true
    elseif not last then
        view.words = s.parts[s.part]
    else
        view.side = s.side
        view.width = s.side and Model.LAST or Model.READ
        if s.confirm then
            view.ask = s.confirm
        elseif s.kind == "offer" then
            view.objectives = true
        elseif not s.extra then
            view.words = s.parts[s.part]
        end
    end
    return view
end

-- The first and the last item the focus can stand on, counted over the items you get for sure
-- and then the items to choose from. At a hand-in with a choice the focus chooses, so it stands
-- on the items to choose from only.
local function span(s)
    local fixed, choices = math.min(#s.data.fixed, Model.TILES - math.min(#s.data.choices, Model.TILES)), math.min(#s.data.choices, Model.TILES)
    if s.kind == "handin" and choices >= 2 then
        return fixed + 1, fixed + choices, fixed
    end
    return 1, fixed + choices, fixed
end
Model.Span = span

-- The reward that a hand-in takes: 0 with nothing to choose, 1 with one choice, the choice with
-- the focus with more. nil while no choice has the focus: then A must do nothing, so a fast
-- press cannot take a reward by mistake.
function Model.Choice(s)
    local _, _, fixed = span(s)
    local choices = #s.data.choices
    if choices <= 1 then
        return choices
    end
    return s.focus > fixed and s.focus - fixed or nil
end

if ns then
    ns.DialogueModel = Model
end
return Model
