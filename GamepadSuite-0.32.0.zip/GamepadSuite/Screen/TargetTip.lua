-- Target Tooltip: the tooltip of the player's target, for a controller, which has no mouse to
-- hover with: an enemy, a friend, an NPC. When the player takes a target, the game shows its own
-- tooltip of it for a few seconds and then fades it. This tooltip waits while the game's one is
-- at the place for a tooltip, and comes on at the moment the game's one starts to fade or hides:
-- at the same place, from the same template, filled by the game for the same target
-- (Core/AdapterTip.lua). So the player sees one tooltip that stays. When the game shows no
-- tooltip of its own, this one comes on at once. From then it stays 5 or 10 seconds, or for as
-- long as the target is the target ("Always"). It goes when the target is lost, and while a
-- window has the controller (a game window, the settings, a talk). A fight changes nothing: it
-- shows in a fight as out of one, and stays when a fight starts. With the game's controller
-- interface off it works as with it on (decision 104), save that no window is known then.
-- Nothing is done on each frame: the game's own word of its tooltip is heard, and the only timer
-- is the one of 5 or 10 seconds. The log (kind "tooltip") keeps a few lines: when this tooltip
-- came on and why, how long after the target was taken, the sizes of the two tooltips, and when
-- the game filled its own one again while it faded (ours goes then, so the two never overlap).
local _, ns = ...

local Tip = ns.Module("TargetTip", nil, "Target Tooltip")
ns.TargetTip = Tip

local SECONDS = { ["5 seconds"] = 5, ["10 seconds"] = 10 }
local MAX_NOTES = 12   -- lines for the log in one session
local count = 0        -- each new target and each hide start a new count, so an old timer hides nothing
local over = false     -- the 5 or 10 seconds of this target ran out
local taken = 0        -- when the target was taken
local notes = 0

local function note(text)
    if notes < MAX_NOTES then
        notes = notes + 1
        ns.Log.Add("tooltip", text)
    end
end

-- Shows the tooltip or hides it, as things are now. why: how it came to be shown, for the log.
local function refresh(why)
    local mode = ns.Registry.Get("screen.target_tooltip")
    if mode == "Off" or over or not ns.Adapter.HasTarget() or ns.Adapter.GameTipUp() or ns.Pad.Controller() and not ns.Pad.Gameplay() then
        count = count + 1
        ns.Adapter.HideTargetTip()
        return
    end
    if ns.Adapter.TargetTipUp() then
        return
    end
    local shown, fault = ns.Adapter.ShowTargetTip()
    if not shown then
        note("ours did not come on (" .. mode .. "): " .. tostring(fault))
        return
    end
    local game, ours = ns.Adapter.TargetTipSizes()
    note(string.format("ours came on (%s) %s, %.1f s after the target was taken; its size %s", mode, why or "at once", GetTime() - taken, ours)
        .. (why and ", the game's was " .. game or ""))
    if SECONDS[mode] then
        local mine = count
        C_Timer.After(SECONDS[mode], function()
            if mine == count then
                over = true
                refresh()
            end
        end)
    end
end

-- A new target, or the row changed: the time starts again.
function Tip.Update()
    count, over, taken = count + 1, false, GetTime()
    ns.Adapter.HideTargetTip()
    if ns.Adapter.GameTipUp() and ns.Adapter.HasTarget() then
        note("a target was taken; the game's own tooltip is at the place, ours waits")
    end
    refresh()
end

function Tip.OnLogin()
    ns.Adapter.OnGameTip(function(came, how)
        -- (only a fill with no new show tells this: the log says if the game does that)
        if came and how ~= "came" and ns.Adapter.TargetTipUp() then
            note("the game's own tooltip " .. how .. ": ours went")
        end
        refresh(not came and "when the game's own tooltip " .. how or nil)
    end)
    ns.On("PLAYER_TARGET_CHANGED", "TargetTip", Tip.Update)
    ns.Listen("pad", "TargetTip", function()
        refresh()
    end)
    ns.Listen("setting", "TargetTip", function(key)
        if key == "screen.target_tooltip" then
            Tip.Update()
        end
    end)
end
