-- The frames of the merchant view: the dialogue view's band over the whole width of the screen at
-- its foot, with its soft top edge and the soft shade at the screen's top (Screen/DialogueDraw.lua),
-- 16 units taller so that the hints row has room under the cards, and in a column in the middle of the screen the NPC's portrait at the
-- left, the tabs row (LB, Buy, Sell, Buyback, RB, the line, the player's gold) and under it the
-- cards (Screen/MerchantCards.lua), and the hints row at the foot (the page at the left).
-- Every size is in the units of the sample sheet (mockups/merchant_sample.py, a screen 900 units
-- high) and goes through Theme.px. Places are from the top left corner of the block: the upper
-- 208 units of the column.
local _, ns = ...

local Theme, Widgets, Model, Cards = ns.Theme, ns.Widgets, ns.MerchantModel, ns.MerchantCards
local px = Theme.px

local Draw = {}
ns.MerchantDraw = Draw

local TONE = { 0.04, 0.035, 0.03 }   -- the band's tone: the dialogue view's
local SHADOW = "Interface\\AddOns\\GamepadSuite\\Art\\HudShadow.tga"
local BAND, BLOCK, FOOT, HINTS, ROOM = 302, 208, 16, 26, 30   -- the band, the block, the room under the column, the hints row, the room over it
local SOFT = { 0.9, 0.7, 0.3, 0 }   -- the band's strength at its top and at the top of each of its three soft slopes of 16 units
local COLUMN, FIT = 1400, 1440       -- the column's width; the width of screen it needs
local FACE_W, FACE_H, PLATE = 256, 384, 36
local RIGHT_X, TAB_GAP = 288, 28     -- the tabs and the cards start here; the room between two tabs
local SHORT, ASK = { 0.94, 0.44, 0.36 }, "gold"     -- the line's red (the B button's letter) for a reason, and its gold for a question

local ui = {}
local faces = 0
local alpha, alphaTo, onFault = 0, 0, nil

local function tone(strength)
    return CreateColor(TONE[1], TONE[2], TONE[3], strength)
end

local function slab(parent, low, high)
    local piece = Theme.Fill(parent, "BACKGROUND", 1, 1, 1, 1)
    piece:SetGradient("VERTICAL", tone(low), tone(high))
    return piece
end

local function at(region, x, y)
    region:ClearAllPoints()
    region:SetPoint("TOPLEFT", ui.col, "TOPLEFT", px(x), -px(y))
    return region
end

-- The portrait, as the dialogue view's: on the block's foot and taller than the band, a soft
-- shadow, a thin gold line round it, the model and the name plate over it.
local function portrait(col, thin)
    local face = CreateFrame("Frame", nil, col)
    face:SetSize(px(FACE_W), px(FACE_H))
    face:SetPoint("BOTTOMLEFT", col, "TOPLEFT", 0, -px(BLOCK))
    local shadow = face:CreateTexture(nil, "BACKGROUND", nil, -2)
    shadow:SetTexture(SHADOW)
    shadow:SetTexCoord(0, 0.5, 0, 1)
    shadow:SetVertexColor(0, 0, 0, 0.55)
    shadow:SetPoint("TOPLEFT", -px(26), px(22))
    shadow:SetPoint("BOTTOMRIGHT", px(26), -px(30))
    local line = Theme.Fill(face, "BACKGROUND", Theme.Color("goldDeep", 0.6))
    line:SetDrawLayer("BACKGROUND", -1)
    line:SetPoint("TOPLEFT", -thin, thin)
    line:SetPoint("BOTTOMRIGHT", thin, -thin)
    local ground = Theme.Fill(face, "BACKGROUND", 1, 1, 1, 1)
    ground:SetDrawLayer("BACKGROUND", 1)
    ground:SetAllPoints()
    ground:SetGradient("VERTICAL", CreateColor(0.09, 0.075, 0.055, 1), CreateColor(0.23, 0.195, 0.15, 1))
    ui.model = CreateFrame("PlayerModel", nil, face)
    ui.model:SetPoint("TOPLEFT")
    ui.model:SetPoint("TOPRIGHT")
    ui.model:SetHeight(px(FACE_H - PLATE))
    ui.picture = face:CreateTexture(nil, "ARTWORK")
    local plate = CreateFrame("Frame", nil, face)
    plate:SetFrameLevel(ui.model:GetFrameLevel() + 2)
    plate:SetPoint("BOTTOMLEFT")
    plate:SetPoint("BOTTOMRIGHT")
    plate:SetHeight(px(PLATE))
    Theme.Fill(plate, "BACKGROUND", TONE[1], TONE[2], TONE[3], 0.82):SetAllPoints()
    local edge = Theme.Fill(plate, "BORDER", Theme.Color("goldDeep", 0.45))
    edge:SetPoint("TOPLEFT")
    edge:SetPoint("TOPRIGHT")
    edge:SetHeight(thin)
    ui.name = Theme.Text(plate, "name", "gold")
    ui.name:SetPoint("CENTER")
    ui.name:SetWidth(px(240))
    ui.name:SetJustifyH("CENTER")
end

-- The tabs row: LB, the three tab names (the one in view gold with a gold line under it, the
-- others muted), RB, the line (a reason or a question), and the player's gold at the right end.
local function tabs(right, thin)
    ui.lb = at(Widgets.Glyph(right, "LB", px(Theme.size.glyph)), RIGHT_X, 4)
    ui.rb = Widgets.Glyph(right, "RB", px(Theme.size.glyph))
    ui.tabs, ui.under = {}, Theme.Fill(right, "ARTWORK", Theme.Color("gold"))
    ui.under:SetHeight(px(2))
    for n, key in ipairs(Model.TABS) do
        local text = Theme.Text(right, "name", "muted")
        text:SetText(Model.TITLE[key])
        ui.tabs[n] = text
    end
    ui.line = Theme.Text(right, "body", "muted")
    ui.money = Theme.Text(right, "name", "cream")
    ui.money:SetPoint("TOPRIGHT", ui.col, "TOPLEFT", px(COLUMN), -px(8))
    ui.money:SetJustifyH("RIGHT")
    ui.thin = thin
end

-- Makes the view under root, a plain frame of the module. It is no protected frame.
function Draw.Build(root)
    ui.root = root
    root:SetFrameStrata("HIGH")
    root:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT")
    root:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT")
    root:SetHeight(px(BAND + 48))
    local thin = ns.Adapter.DialogueThin(root, px(1))
    for n = 0, 3 do
        local piece = slab(root, SOFT[math.max(1, n)], SOFT[n + 1])
        local from = n == 0 and 0 or BAND + (n - 1) * 16
        piece:SetPoint("BOTTOMLEFT", 0, px(from))
        piece:SetPoint("BOTTOMRIGHT", 0, px(from))
        piece:SetHeight(px(n == 0 and BAND or 16))
    end
    local shade = CreateFrame("Frame", nil, root)
    shade:SetFrameStrata("BACKGROUND")
    shade:SetPoint("TOPLEFT", UIParent, "TOPLEFT")
    shade:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT")
    shade:SetHeight(px(64))
    slab(shade, 0, 0.5):SetAllPoints()

    local col = CreateFrame("Frame", nil, root)
    col:SetSize(px(COLUMN), px(BLOCK + ROOM + HINTS))
    col:SetPoint("BOTTOM", 0, px(FOOT))
    ui.col = col
    portrait(col, thin)
    local right = CreateFrame("Frame", nil, col)
    right:SetAllPoints()
    tabs(right, thin)
    -- the page, at the left of the hints row; the hints at its right (a click on a hint is a
    -- press of its button; the D-pad's hint stands for four buttons: no click)
    ui.page = Theme.Text(right, "row", "muted")
    ui.page:SetPoint("LEFT", col, "BOTTOMLEFT", px(RIGHT_X), px(HINTS / 2))
    ui.legend = Widgets.Legend(right, "RIGHT", function(key)
        if key ~= "DPAD" then
            ns.MerchantInput.Key(key)
        end
    end)
    ui.legend:SetPoint("BOTTOMRIGHT", col, "BOTTOMRIGHT")
    -- the place of a card's tooltip: its bottom right corner, 10 units over the band's top
    ui.corner = CreateFrame("Frame", nil, col)
    ui.corner:SetSize(1, 1)
    ui.corner:SetPoint("BOTTOMRIGHT", col, "BOTTOMRIGHT", 0, px(BAND + 10 - FOOT))
    Cards.Build(right, at, RIGHT_X, thin)
end

-- The size of the view: the row Dialogue Size, and less on a screen too narrow for the column.
function Draw.Scale(percent)
    ui.root:SetScale(math.min((percent or 100) / 100, UIParent:GetWidth() * 900 / 768 / FIT))
end

-- The view comes in 0.2 seconds (to: 1) or goes in 0.15 (to: 0); the script runs on each frame
-- only for that time. A model does not follow its frame's strength by itself, so it is told. A
-- fault stops the script, the view goes, and fault(why) is told.
local function strength()
    ui.root:SetAlpha(alpha)
    pcall(ui.model.SetModelAlpha, ui.model, alpha)
end

local function fading(root, elapsed)
    local by = elapsed / (alphaTo > alpha and 0.2 or 0.15)
    alpha = alphaTo > alpha and math.min(alphaTo, alpha + by) or math.max(alphaTo, alpha - by)
    local ok = ns.Call("Merchant", strength)
    if not ok or alpha == alphaTo then
        root:SetScript("OnUpdate", nil)
        root:SetShown(ok and alpha > 0)
    end
    if not ok then
        onFault("a fault while the view faded")
    end
end

function Draw.Fade(to, fault)
    alphaTo, onFault = to, fault
    ui.root:SetScript("OnUpdate", alpha ~= to and fading or nil)
end

-- The view goes at once, with no fade (a fight starts).
function Draw.Gone()
    alpha, alphaTo = 0, 0
    ui.root:SetScript("OnUpdate", nil)
    strength()
    ui.root:Hide()
end

-- Puts the NPC into the portrait, as the dialogue view does (Adapter.DialogueFace): its model, or
-- one frame later its flat picture. Returns what shows and a few words for the log; log(text)
-- tells of the second look.
function Draw.Face(unit, log)
    faces = faces + 1
    local mine = faces
    local function shown(kind)
        ui.model:SetShown(kind == "model" or kind == "wait")
        ui.picture:SetShown(kind == "picture")
        ui.picture:ClearAllPoints()
        ui.picture:SetSize(px(192), px(192))
        ui.picture:SetPoint("TOP", ui.model, "TOP", 0, -px(32))
    end
    local kind, words = ns.Adapter.DialogueFace(ui.model, ui.picture, unit)
    shown(kind)
    if kind == "wait" then
        C_Timer.After(0, function()
            if mine == faces then
                local late, more = ns.Adapter.DialogueFace(ui.model, ui.picture, unit, true)
                shown(late)
                log("one frame later the portrait shows the " .. late .. " (" .. tostring(more) .. ")")
            end
        end)
    end
    ui.name:SetFont(Theme.font.text, px(Theme.size.name), "")
    ui.name:SetText(ns.Adapter.DialogueName(unit) or "")
    if (ui.name.GetUnboundedStringWidth and ui.name:GetUnboundedStringWidth() or ui.name:GetStringWidth() or 0) > px(236) then
        ui.name:SetFont(Theme.font.text, px(Theme.size.body), "")
    end
    return kind, words
end

-- The line of the tabs row: text in red for a reason (how "say"), in gold for a question
-- ("ask"), or nothing.
function Draw.Line(text, how)
    ui.line:SetText(text or "")
    if how == "say" then
        ui.line:SetTextColor(SHORT[1], SHORT[2], SHORT[3])
    else
        ui.line:SetTextColor(Theme.Color(how == "ask" and ASK or "muted"))
    end
end

-- Draws the vendor in view (Model.New): the tabs, the gold, the page, the hints and the cards.
-- coins(copper) writes gold in the game's coin pictures. Returns what Cards.Show returns.
function Draw.Show(s, coins)
    local x = RIGHT_X + Theme.size.glyph + 12
    for n, key in ipairs(Model.TABS) do
        local text, on = ui.tabs[n], key == s.tab
        text:SetTextColor(Theme.Color(on and "gold" or "muted"))
        at(text, x, 6)
        local wide = text:GetStringWidth() / px(1)
        if on then
            ui.under:ClearAllPoints()
            ui.under:SetPoint("TOPLEFT", ui.col, "TOPLEFT", px(x), -px(31))
            ui.under:SetWidth(math.max(1, px(wide)))
        end
        x = x + wide + TAB_GAP
    end
    at(ui.rb, x - TAB_GAP + 12, 4)
    local lineX = x - TAB_GAP + 12 + Theme.size.glyph + TAB_GAP
    at(ui.line, lineX, 10)
    ui.money:SetText(coins(s.money))
    -- the line ends 24 before the gold; a longer one is cut by the game
    ui.line:SetWidth(math.max(1, px(COLUMN - lineX - 24) - ui.money:GetStringWidth()))
    local page, pages = Model.Page(s)
    ui.page:SetShown(pages > 1)
    ui.page:SetText(pages > 1 and "Page " .. page .. " of " .. pages or "")
    ui.legend.Set(Model.Hints(s, coins))
    return Cards.Show(s, coins, ui.corner)
end

-- The thin gold line of a hold of A on the card in focus of s: part 0 to 1, 0 for none.
function Draw.Hold(part, s)
    local _, _, first = Model.Page(s)
    Cards.Hold(part, s.at[s.tab] - first + 1)
end

-- The view goes: what moves by itself stops, and the tooltip goes.
function Draw.Rest()
    faces = faces + 1
    Cards.Hold(0)
    ns.Adapter.MerchantTipHide()
end
