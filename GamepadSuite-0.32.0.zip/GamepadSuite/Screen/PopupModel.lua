-- The rules of the top pop-up (Screen/Popup.lua), with no game calls: which item takes the place, which waits in the
-- list and which comes next, and the words that more than one pop-up uses.
--
-- One place, one item at a time, and a short list of items that wait for it. The order of the owners: 1 an item the
-- game waits for now (a poison on the pointer), 2 a whisper (a person waits), 3 a quest to share (a member waits),
-- 4 the hungry pet (it stays true, it can wait), 5 a rare (it comes back at the next sighting). An item of a higher
-- place takes the place; the one it pushes out goes back to the list with the wait it has left. When the place frees,
-- the next item that can show and is not too old shows: the first by place, then the oldest. Each owner gives its
-- own wait in seconds (a whisper 60, a share 30, the pet 60, a weapon item 10); an item with no wait is not kept (a
-- rare). A new item of an owner takes the place of its older one, on the screen and in the list (the newest whisper);
-- an owner whose items say each keeps one for each who, and they wait in turn (three quests to share).
local _, ns = ...

local Model = {}

Model.RANK = { weapon = 1, whisper = 2, share = 3, pet = 4, rare = 5 }
local LAST = 9

local function rank(item)
    return Model.RANK[item.owner] or LAST
end

-- True when item takes the place of other: the same owner, and for an owner of each, the same who.
function Model.Same(item, other)
    return item.owner == other.owner and (not item.each or item.who == other.who)
end

-- True when item goes before other: a higher place first, then the older.
function Model.Before(item, other)
    local a, b = rank(item), rank(other)
    if a ~= b then
        return a < b
    end
    return (item.at or 0) < (other.at or 0)
end

-- What a new item does against shown (the item on the place, or nil) while the place is free (free) or busy:
-- "show" (it takes the place), "wait" (it waits in the list) or "drop" (it is not shown).
function Model.Place(shown, item, free)
    if free and (not shown or Model.Same(item, shown) or rank(item) < rank(shown)) then
        return "show"
    end
    return item.wait and "wait" or "drop"
end

-- Puts item in the list, in the place of an older item of its owner.
function Model.Put(list, item)
    for i = #list, 1, -1 do
        if Model.Same(item, list[i]) then
            table.remove(list, i)
        end
    end
    list[#list + 1] = item
end

-- Takes the next item out of the list and gives it, or nil: the first by place, then the oldest, of those that can
-- show now (can(item)). An item that waited longer than its wait is dropped first.
function Model.Next(list, now, can)
    for i = #list, 1, -1 do
        if now - list[i].at > list[i].wait then
            table.remove(list, i)
        end
    end
    local best, at
    for i, item in ipairs(list) do
        if can(item) and (not best or Model.Before(item, best)) then
            best, at = item, i
        end
    end
    if best then
        table.remove(list, at)
    end
    return best
end

-- The names of a list for a hint: "Bob", "Bob, Ann", and past two the count ("3").
function Model.Names(names)
    return #names > 2 and tostring(#names) or table.concat(names, ", ")
end

-- The line of what is known of the sender of a whisper: { name (a Battle.net friend's character), level, race,
-- class, zone }, each nil when not known. "Level 23 Night Elf Hunter, Westfall", "Bobchar, level 40 Mage, Orgrimmar",
-- or nil when nothing is known.
function Model.Facts(facts)
    local kind = table.concat({ facts.race or "", facts.class or "" }, " "):gsub("^ +", ""):gsub(" +$", "")
    local level = facts.level and ((facts.name and "level " or "Level ") .. facts.level) or nil
    local who = table.concat({ level or "", kind }, " "):gsub("^ +", ""):gsub(" +$", "")
    local parts = {}
    for _, part in ipairs({ facts.name or "", who, facts.zone or "" }) do
        if part ~= "" then
            parts[#parts + 1] = part
        end
    end
    return #parts > 0 and table.concat(parts, ", ") or nil
end

if ns then
    ns.PopupModel = Model
end
return Model
