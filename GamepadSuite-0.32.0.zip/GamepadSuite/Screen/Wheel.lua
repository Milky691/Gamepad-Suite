-- The ring of a wheel on screen. It only shows. The bind opens the wheel and the flick uses an
-- entry in the game's restricted code (Core/BindSecure.lua), so both work in a fight. This file
-- hears which wheel is open, draws its round pictures in a ring, and puts a gold frame on the
-- entry that a let-go of the stick uses now (the restricted code's own pick). The look follows the
-- Wheels tab: size, place, background. Each wheel opens at its own place, or at All Wheels' (Screen/WheelPlace.lua).
-- Background None shows the pictures, the lines of words and the gold frame, and nothing dark.
-- An entry of the party wheel (healer mode) is a member of the party: it shows the member's
-- portrait and plate (Screen/WheelPlate.lua: health and its percent, the heals on the way, marks,
-- role, reach), and the spell's picture sits in the middle with its cooldown. In a raid it shows a
-- radial for each pair of groups, the chosen one larger with the gold ring (Screen/WheelRaid.lua).
-- An entry that uses an item shows how many of it are in the bags. The name of the entry in the
-- frame, a cooldown and a "cannot use now" look on each entry and the tick: Screen/WheelInfo.lua.
-- An entry of the quick chat wheel is words and no picture: a dark plate with its line on it; the
-- middle shows the line in the frame and the channel it goes to.
-- The sticks: while a wheel is open, and until the right stick is back near its middle, two frames
-- of ours hear the sticks: the right stick does not turn the camera and the left stick walks
-- (Screen/WheelModel.lua). The game's direction keys of the right stick choose and use the entry.
-- Nothing here runs on a timer or each frame: the ring follows the game's word of a stick and
-- of a change of a wheel (the party wheel's plates: Screen/WheelPlate.lua). The test wheel shows for
-- the peek of the on-screen parts (Screen/HudFace.lua) and then fades by the game's own animation.
-- The type is the Theme's sizes, grown with the setting Wheel Size.
local _, ns = ...

local View = ns.Module("Wheel", nil, "Wheels")
ns.WheelView = View

local Theme, Rules, Model, Words, Plate = ns.Theme, ns.WheelRules, ns.WheelModel, ns.ChatWheelRules, ns.WheelPlate
local px = Theme.px

local MAX_NOTES = 12    -- lines for the log in one session
local REST = 0.35       -- how dim a line is while it rests (Core/ChatWheel.lua)
local FADE = 0.5           -- the test wheel fades out in half a second at the end of the peek
local ring, back, middle, ear, wall, says, goes, fade
local cells = {}
local open, pointed, hooked   -- the wheel open; the entry with the gold frame; the restricted code's pick is heard
local entries, picks = {}, {}   -- the ring's entries; the list the restricted code picks in (in a raid: the chosen radial's)
local wordy, plain = false, false   -- the wheel drawn is one of words; Background is None
local sticks = {}           -- what the stick frames saw while the wheel was open (WheelModel.Stick)
local since, fight = 0, false   -- when the wheel opened, and if a fight was on then
local turn = 0              -- counts the wheels opened: the timer of an earlier close does nothing
local holdAll, broken = false, false   -- the wall keeps every stick for this wheel (see stick); a fault put the frames away for good
local notes = 0

local piece, round = Plate.Piece, Plate.Round   -- a texture with a circle mask that can be put on and taken off

local function cell(i)
    local c = cells[i]
    if not c then
        c = CreateFrame("Frame", nil, ring)
        -- the gold frame on the picture the stick points at, and the black edge round each picture
        c.rim = piece(c, "BACKGROUND", 1)
        c.rim:SetColorTexture(Theme.Color("gold"))
        c.edge = piece(c, "BACKGROUND", 2)
        c.edge:SetColorTexture(0, 0, 0, 1)
        c.art = piece(c, "ARTWORK")
        c.art:SetAllPoints()
        round(c.art, true)
        -- how many of an item are in the bags, as on the on-screen buttons
        c.count = Theme.Text(c, "tiny", "cream")
        -- the line of an entry that is words
        c.words = Theme.Text(c, "body", "cream")
        c.words:SetPoint("CENTER")
        -- a party member's plate: health, heals on the way, the mark of a debuff
        Plate.Make(c)
        cells[i] = c
    end
    return c
end

-- A texture that stands out from its frame by `by` on every side.
local function around(texture, frame, by)
    texture:ClearAllPoints()
    texture:SetPoint("TOPLEFT", frame, "TOPLEFT", -by, by)
    texture:SetPoint("BOTTOMRIGHT", frame, "BOTTOMRIGHT", by, -by)
end

-- the My Wheels page of the settings window draws its ring with the same parts
View.Piece, View.Round = piece, round

-- The focus mark: the gold frame on the entry the stick points at. With Background None a line of
-- words has no plate for the frame to stand round: the line itself turns gold.
local function mark()
    for i, c in ipairs(cells) do
        c.rim:SetShown(i == pointed and not (plain and wordy))
        c.words:SetTextColor(Theme.Color(plain and i == pointed and "gold" or "cream"))
    end
end

-- The middle of a wheel of words: the line the stick points at, and under it the channel the
-- lines go to. A line that rests is dim here, as it is on the ring.
local function say()
    local entry = entries[pointed]
    says:SetText(entry and entry.text or "")
    says:SetAlpha(entry and entry.rest and REST or 1)
    goes:SetText(entries[1].to or "")
end

-- Draws the wheel that is open with the look of the Wheels tab, or the entries of the test wheel (at: its place).
function View.Draw(test, at)
    local get = ns.Registry.Get
    -- the wheel's own size and place, or All Wheels' (Screen/WheelPlace.lua); with no such file: the settings
    local place, id = ns.WheelPlace, test and at or open
    local scale = place and place.Size(id) or get("wheels.size")
    -- a raid's party wheel: the members of every group, each group at its own place (raid gives the measures)
    local raid = not test and ns.WheelRaid and ns.WheelRaid.Entries(open, scale)
    entries = test or raid and raid.entries or ns.Wheels.Entries(open)
    picks = raid and raid.radials[raid.chosen].entries or entries
    local unit = entries[1] and (entries[1].unit or entries[1].blank)   -- (a raid's radial can start with an empty place)
    -- a wheel with fixed places (the party wheel, a wheel of the player's own) keeps the ring of all its places
    local size, radius, across = Rules.Measure(entries[1] and entries[1].of or #entries, scale)
    if raid then
        size, radius = raid.size, raid.radius
    end
    -- a wheel of words: each entry is a plate, all of one size, and the wheel is as wide as the plates need
    local words = entries[1] and entries[1].text and Words.Measure(scale, radius)
    wordy, across = words and true or false, words and words.across or across
    -- the frame, the black line, the count and the health bar grow with the pictures; the Theme's
    -- sizes of type grow with the setting Wheel Size (a line is Rules.GAME units at 100%)
    local line = size / Rules.PICTURE
    -- Background None: no dark disc, no black edge round a picture, no plate behind a line of words
    plain = get("wheels.background") ~= "Dark"
    local x, y = get("wheels.x"), get("wheels.y")
    if place then x, y = place.Of(id) end
    ring:ClearAllPoints()
    ring:SetPoint("CENTER", UIParent, "CENTER", px(x), px(y))
    ring:SetSize(px(raid and raid.wide or across), px(raid and raid.high or across))
    back:SetShown(not plain and not raid)
    says:SetShown(wordy)
    goes:SetShown(wordy)
    if words then
        says:SetFont(Theme.font.text, px(words.focus), "")
        goes:SetFont(Theme.font.text, px(words.small), "")
        say()
    end
    -- the spell of the party wheel, in the middle
    middle:SetShown(unit ~= nil)
    if unit then
        middle:SetSize(px(size * 0.7), px(size * 0.7))
        middle:SetPoint("CENTER", ring, "CENTER", px(raid and raid.x or 0), px(raid and raid.y or 0))
        middle:SetTexture(entries[1].icon)
    end
    for i, entry in ipairs(entries) do
        local c = cell(i)
        local x, y = Rules.Place(entries, i)
        local size, radius, line = entry.size or size, entry.radius or radius, (entry.size or size) / Rules.PICTURE   -- (each radial of a raid its own)
        c:SetSize(px(words and words.wide or size), px(words and words.high or size))
        c:ClearAllPoints()
        c:SetPoint("CENTER", ring, "CENTER", px(x * radius + (entry.dx or 0)), px(y * radius + (entry.dy or 0)))
        -- (a plate's frame is thinner: a plate and the one beside it are nearer than two pictures)
        around(c.rim, c, px((words and 2 or 4) * line))
        around(c.edge, c, px(line))
        Plate.Lay(c, size, line, entry.unit)
        if entry.unit then
            c.art:SetTexCoord(0, 1, 0, 1)
            ns.Adapter.Portrait(c.art, entry.unit)
        elseif words then
            -- the black line behind a picture is the plate here
            c.words:SetFont(Theme.font.text, px(words.letters), "")
            c.words:SetText(entry.text)
            c.words:SetAlpha(entry.rest and REST or 1)
        else
            ns.Widgets.Art(c.art, entry.icon)
        end
        c.art:SetShown(not words)
        c.words:SetShown(wordy)
        c.count:SetFont(Theme.font.text, px(Theme.size.row * line / Rules.GAME), "")
        c.count:ClearAllPoints()
        c.count:SetPoint("TOPRIGHT", c, "TOPRIGHT", -px(2 * line), -px(2 * line))
        ns.Adapter.ShowCount(c.count, entry.item and { kind = "item", id = entry.item } or nil)
        c.edge:SetShown(not plain)
        round(c.rim, not words)
        round(c.edge, not words)
        c:Show()
    end
    for i = #entries + 1, #cells do
        cells[i]:Hide()
    end
    if ns.WheelRaid then
        ns.WheelRaid.Lay(ring, cells, entries, raid, plain)
    end
    mark()
    ns.Send("wheel:drawn", ring, cells, entries, pointed, size, radius, test ~= nil)
end

-- The two stick frames hear the sticks, or stop. While the wall keeps every stick it is up for
-- the whole time.
local function listen(on)
    on = on and not broken
    ear:SetShown(on)
    wall:SetShown(on and holdAll)
end

-- The game told one of the two frames of a stick (onWall: the wall). The wall goes up or down
-- for the next stick. (The frame on the ring follows the restricted code's pick: aim.)
local function stick(name, onWall, x, y)
    local now, gameplay = GetTime(), ns.Pad.Gameplay()
    x, y = x or 0, y or 0
    -- for the log: the sticks of one frame of the screen in the order the game told them
    if now ~= sticks.at then
        sticks.at, sticks.order = now, #sticks.line > #(sticks.order or "") and sticks.line or sticks.order
        sticks.line = ""
    end
    if #sticks.line < 60 then
        sticks.line = sticks.line .. (sticks.line ~= "" and " > " or "") .. tostring(name)
    end
    local up = holdAll and gameplay or not holdAll and Model.Stick(sticks, name, onWall, now, gameplay, x * x + y * y)
    -- The wall came too late for the camera's stick, time after time (both sticks pushed at
    -- once). For the rest of this wheel the wall keeps every stick, so that the camera stands
    -- still at least. The next wheel tries again: the left stick walks there.
    if not holdAll and Model.TooLate(sticks) then
        holdAll, up = true, gameplay
        if notes < MAX_NOTES then
            ns.Log.Add("wheel", "The wall came too late for the camera's stick (" .. sticks.leaked .. " passed, " .. sticks.kept
                .. " taken). For the rest of this wheel it keeps every stick: the camera stands still and the left stick does not walk.")
        end
    end
    if up ~= wall:IsShown() then
        wall:SetShown(up)
    end
    -- the wheel has closed and the right stick is back near its middle: the frames go
    if name == "Right" and not open and x * x + y * y < 0.04 then
        listen(false)
    end
end

-- The restricted code picked the entry a let-go of the stick uses now (sel: Core/BindWheelUse.lua), or forgot it. The
-- gold frame marks that entry and no other, so frame and flick agree (in a raid sel counts in the chosen radial).
local function aim(sel)
    local at = open and Model.Marked(entries, picks, sel) or nil
    if at ~= pointed then
        pointed = at
        mark()
        if wordy then
            say()
        end
        ns.Send("wheel:aim", at)
    end
end

-- A frame's script for the sticks. A fault in it would come at every move of a stick: it is
-- logged once, and the frames are put away for good, so that the sticks are the game's.
local function heard(onWall)
    return function(_, name, x, y)
        if not ns.Call("Wheel", stick, name, onWall, x, y) then
            broken = true
            listen(false)
        end
    end
end

-- One line for the log each time a wheel closes: what closed it (why, from the restricted code:
-- the stick's let-go, its bind, B, a window) and what became of the two sticks.
local function note(id, why)
    if notes >= MAX_NOTES then
        return
    end
    notes = notes + 1
    local order = #sticks.line > #(sticks.order or "") and sticks.line or sticks.order
    ns.Log.Add("wheel", string.format("%s was open %.1f s, in a fight: %s, closed by %s. Camera's stick: the wall took it %d times, it passed %d times. "
        .. "Walking stick: it passed %d times, the wall took it %d times. One frame of sticks: %s.%s",
        tostring(id), GetTime() - since, tostring(fight or ns.Adapter.InCombat()), tostring(why), sticks.kept, sticks.leaked, sticks.walked, sticks.stolen,
        order ~= "" and order or "none", holdAll and " The wall keeps every stick." or ""))
end

-- id is the wheel that is open now, or nil; why is what closed the one before.
local function show(id, why)
    if id == open then
        return
    end
    -- LB or RB on a raid's party wheel: another group of the same wheel ("heal774:3"), no close
    local base = id and open and tostring(id):match("^heal%a*%d+")
    if base and base == tostring(open):match("^heal%a*%d+") then
        open, pointed = id, nil
        View.Draw()
        return Plate.Open(cells, function() return entries end, middle, Rules.HealOf(id))
    end
    local was = open
    open, pointed = id, nil
    Plate.Close()
    if id then
        sticks = { kept = 0, leaked = 0, stolen = 0, walked = 0, line = "" }
        hooked = hooked or ns.Adapter.OnWheelPick and ns.Adapter.OnWheelPick(function(sel) ns.Call("Wheel", aim, sel) end)   -- (the binds' frame is there now)
        since, fight, turn, holdAll = GetTime(), ns.Adapter.InCombat(), turn + 1, false
        -- the sticks are heard from here on, also when the drawing fails
        listen(true)
        -- (a test wheel that still shows gives the ring back)
        fade:Stop()
        ring:SetFrameStrata("HIGH")
        View.Draw()
        ring:Show()
        -- a party wheel: its plates and its middle follow the game's word of a change
        Plate.Open(cells, function() return entries end, middle, Rules.HealOf(id))
    else
        ring:Hide()
        if was then
            note(was, why)
            -- The stick can still be out: the frames stay until its word says that it is back
            -- near its middle, and a second and a half at the most.
            local x, y = ns.Adapter.RightStick()
            if x * x + y * y < 0.04 then
                listen(false)
            else
                local mine = turn
                C_Timer.After(1.5, function()
                    if not open and turn == mine then
                        listen(false)
                    end
                end)
            end
        end
    end
end

function View.OnLogin()
    ring = CreateFrame("Frame", "GamepadSuiteWheelRing", UIParent)
    ring:SetFrameStrata("HIGH")
    -- (a place past the screen's edge: a smaller screen, a larger wheel)
    ring:SetClampedToScreen(true)
    ring:Hide()
    back = piece(ring, "BACKGROUND")
    back:SetColorTexture(0, 0, 0, 0.62)
    back:SetAllPoints()
    back:AddMaskTexture(back.mask)
    middle = piece(ring, "ARTWORK")
    middle:SetPoint("CENTER")
    middle:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    round(middle, true)
    middle:Hide()
    -- the test wheel's fade, by the game's own animation (Blizzard_HelpPlate.lua makes one the same way)
    fade = ring:CreateAnimationGroup()
    local out = fade:CreateAnimation("Alpha")
    out:SetFromAlpha(1)
    out:SetToAlpha(0)
    out:SetDuration(FADE)
    fade:SetScript("OnFinished", function() ring:Hide() end)
    -- a wheel of words: the line in focus stands over the middle, the channel under it
    says, goes = Theme.Text(ring, "row", "cream"), Theme.Text(ring, "tiny", "gold")
    says:SetPoint("BOTTOM", ring, "CENTER", 0, px(1))
    goes:SetPoint("TOP", ring, "CENTER", 0, -px(3))

    -- The two stick frames (Screen/WheelModel.lua). The wall is above the ear, so the game
    -- tells the wall first while it is up. The ear's switch is set out of a fight: the game
    -- refuses it in one, and until it is set the ear keeps every stick, as the wall does.
    ear = CreateFrame("Frame", "GamepadSuiteWheelEar", UIParent)
    ear:SetFrameStrata("BACKGROUND")
    wall = CreateFrame("Frame", "GamepadSuiteWheelWall", UIParent)
    wall:SetFrameStrata("TOOLTIP")
    for frame, onWall in pairs({ [ear] = false, [wall] = true }) do
        frame:Hide()
        frame:EnableGamePadStick(true)
        frame:SetScript("OnGamePadStick", heard(onWall))
    end
    ns.Queue.Run("WheelEar", function()
        ear:SetPropagateKeyboardInput(true)
        -- (no source says that the game takes this switch from an addon: the log keeps what it reads back)
        ns.Log.Add("wheel", "The ear's switch that hands the sticks on to the game reads " .. tostring(ear:GetPropagateKeyboardInput()) .. ".")
    end)

    ns.Listen("wheel", "Wheel", show)
    local function again()
        if open then
            View.Draw()
        end
    end
    ns.Listen("wheels", "Wheel", again)
    -- a line of the quick chat wheel rests, or its rest is over
    ns.Listen("chat", "Wheel", again)
    ns.Listen("setting", "Wheel", function(key)
        if open and key:find("^wheels%.") then
            View.Draw()
        elseif key == "wheels.x" or key == "wheels.y" or key == "wheels.size" or key == "wheels.move" then
            -- The test wheel: while the player moves a wheel or changes the size in the settings window,
            -- the wheel being moved (Screen/WheelPlace.lua Test; All Wheels: the raid markers) shows at its
            -- place and size, over the window. It has no focus mark, hears no stick and no button, and does
            -- nothing in the game. At the end of the peek (three seconds after the last change) it fades
            -- out, unless a wheel opened.
            View.Draw((ns.WheelPlace and ns.WheelPlace.Test or Rules.Markers)())
            fade:Stop()
            ns.Screen.Peek("Wheel", function()
                if not open then
                    fade:Play()
                end
            end)
            ns.Screen.Peeking("Wheel", ring, "HIGH")
            ring:Show()
        end
    end)
    -- a press on the bind of a wheel that holds nothing: the player is told once for each wheel
    local told = {}
    ns.Listen("wheel:pressed", "Wheel", function(id)
        if #ns.Wheels.Entries(id) == 0 and not told[id] then
            told[id] = true
            for _, wheel in ipairs(Rules.LIST) do
                if wheel.id == id then
                    ns.Print("The " .. wheel.name .. " is empty." .. (wheel.fills and " It fills by itself with " .. wheel.fills .. "." or ""))
                end
            end
        end
    end)
end
