-- The rules of Destroy Gray Item, with no game calls: which thing in the bags is offered, how
-- long the hold is, and the words.
-- Offered is the gray thing whose whole stack a vendor pays least for. Never offered: a thing
-- that is not gray, a quest item or a thing that starts a quest, a thing with a use that the
-- consumables wheel would keep, a thing the game holds locked (it is being moved or sold), and
-- a thing whose price the game has not loaded yet.
local _, ns = ...

local Model = {}

-- The game's number of the quality "Poor": the gray items.
Model.GRAY = 0
-- The hold is this many seconds. A full hold destroys nothing by itself: it makes the prompt
-- ready, and the next press down of the button destroys the item. The game takes the call that
-- destroys an item only inside a press down of the player. The moment the bar is full is no
-- press, and a let-go is none either.
Model.HOLD = 1
-- The prompt goes away by itself this many seconds after it came, or after a hold became full.
Model.STAY = 10
-- The game answers a destroy with a change of the bags. With no answer in this many seconds the
-- destroy counts as not done, and a new prompt can come.
Model.ANSWER = 2
-- The words beside the picture of the button, one line for each step: at rest (the three steps,
-- as the row Destroy Gray Item says them in Settings/Data.lua, with the time of HOLD), while the
-- bar is full and the button is still down, and after the let-go.
Model.WORDS = ("Hold %s second%s, let go, press once more"):format(Model.HOLD, Model.HOLD == 1 and "" or "s")
Model.LET_GO = "Let go, then press once more to destroy it"
Model.AGAIN = "Press once more to destroy it"
-- The chat line when the game does not let the addon destroy an item: nothing is offered again.
Model.REFUSED = "Destroy Gray Item is off for this session. The game did not let Gamepad Suite destroy the item."

-- A thing in the bags: quality, count, price (what a vendor pays for one, in copper; nil while
-- the game has not loaded the item), quest, keep, locked.
function Model.Offered(thing)
    return thing.quality == Model.GRAY and thing.price ~= nil and not (thing.quest or thing.keep or thing.locked)
end

function Model.Worth(thing)
    return thing.price * thing.count
end

-- The thing to offer of everything in the bags, or nil. Of two with the same worth it is the
-- one that comes first in the bags.
function Model.Cheapest(things)
    local best
    for _, thing in ipairs(things) do
        if Model.Offered(thing) and (not best or Model.Worth(thing) < Model.Worth(best)) then
            best = thing
        end
    end
    return best
end

-- True when the loot holds a thing worth the room of the offered stack: a thing that is not gray, a quest item, a
-- thing the game has not loaded yet (no price), or a gray stack worth more. Else false, with how many gray stacks the
-- loot holds and the worth of the best of them. loot: { quality, count, price, quest } for each thing that takes a bag
-- slot (money does not); nil when the game could not be read, which counts as worth it.
function Model.Worthy(loot, offered)
    local grays, most = 0, 0
    for _, thing in ipairs(loot or {}) do
        if thing.quest or thing.price == nil or thing.quality ~= Model.GRAY or Model.Worth(thing) > Model.Worth(offered) then
            return true
        end
        grays, most = grays + 1, math.max(most, Model.Worth(thing))
    end
    return loot == nil, grays, most
end

-- True when a hold of this many seconds is a full one.
function Model.Full(seconds)
    return seconds >= Model.HOLD
end

-- The two lines of the prompt, and the chat line after the destroy. worth is the thing's worth
-- as the chat shows money ("1s 25c").
function Model.Title(thing)
    return thing.count .. " " .. thing.name
end

function Model.Value(worth)
    return "Worth " .. worth .. ". Destroy it so the loot fits?"
end

function Model.Line(thing, worth)
    return "Destroyed " .. thing.count .. " " .. thing.name .. " (worth " .. worth .. ") to make room."
end

if ns then
    ns.DestroyModel = Model
end
return Model
