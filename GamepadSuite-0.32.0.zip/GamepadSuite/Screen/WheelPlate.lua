-- A member's plate on the party wheel of healer mode.
-- Screen/Wheel.lua draws the ring; this file adds to the picture of a member what the plate shows:
--   under the portrait, a party member's health as a bar, green at full, yellow at half and red
--   when low, and over it the health in percent;
--   after the health, the heals on their way to that member as a lighter part of the same bar, up
--   to full health (the game's own count, as its raid frames show it);
--   on the portrait's top left corner, a small mark while the member has a debuff that the
--   character can remove now (Auto/Cleanse.lua knows which). The mark is the game's own picture
--   for that kind of debuff, in its colour, as on the game's raid frames;
--   on the top right corner the member's raid target mark, and on the bottom left its group role
--   (tank, healer, damage), with the game's own pictures, when it has one;
--   on the portrait's top edge, a small row of the player's own buffs on that member (the owner: "only my
--   buffs above their portrait"), four at most, with the game's own pictures; while the game draws them
--   itself (its aura boxes, Screen/WheelPlateLive.lua, in a fight too) this row and the mark stay hidden;
--   round the portrait, the aggro edge; at the bar's right end, the mark of a resurrection on its way
--   (made here, shown by Screen/WheelPlateLive.lua at the game's word);
--   a member out of reach of the spell is dimmed and gray. It can still be chosen: the cast fails;
--   under the bar the member's name, in the colour of its class, cut by the game to fit the plate,
--   on a soft dark backing with Wheel Background None (see SOFT);
--   a member who is offline, dead or a ghost has the game's own word for it (Offline, Dead) in place
--   of the percent, and a gray bar, name and portrait (a feigning hunter has the name of the spell, Feign
--   Death, and stays a live member, its bar in its colour). It can still be chosen: a resurrection's party
--   wheel is this wheel, and the flick on a dead member does not stop the cast that runs
--   (Core/WheelRules.lua Party), so a heal that the game refuses on the dead costs nothing.
-- The game can hide many of these values from an addon in a fight: Core/AdapterPlate.lua gives
-- them to the parts that take them as they are, and a part with no answer shows nothing.
-- The spell in the middle, the reach, and all that follows the game's word of a change while a party
-- wheel is open: Screen/WheelPlateLive.lua.
local _, ns = ...

local Plate = {}
ns.WheelPlate = Plate

local Theme = ns.Theme
local px = Theme.px

-- The game's events of a member's state (a death comes with the health; offline, a ghost and a new name come with
-- their own events, as on the game's raid frames; a resurrection on its way with its own), and of the group (the
-- group's own word: every part again, with the portrait).
local HEALTH = { UNIT_HEALTH = true, UNIT_MAXHEALTH = true, UNIT_HEAL_PREDICTION = true, UNIT_CONNECTION = true, PLAYER_FLAGS_CHANGED = true, UNIT_NAME_UPDATE = true,
    INCOMING_RESURRECT_CHANGED = true }
local ROSTER = { GROUP_ROSTER_UPDATE = true, UNIT_PORTRAIT_UPDATE = true, PORTRAITS_UPDATED = true }
local GRAY = { r = 0.5, g = 0.5, b = 0.5 }
local ROLE = { PLAYER_ROLES_ASSIGNED = true }
local EDGE = 2.5        -- the aggro edge stands this many lines out round the portrait (the black edge: 1, the gold frame: 4)
local REZ = 9           -- the mark of a resurrection, lines high, at the right end of the bar (6 high)
-- The game's own pictures of the kinds of debuff, from its raid frames.
local MARK = {
    Magic = "Interface\\RaidFrame\\Raid-Icon-DebuffMagic", Curse = "Interface\\RaidFrame\\Raid-Icon-DebuffCurse",
    Poison = "Interface\\RaidFrame\\Raid-Icon-DebuffPoison", Disease = "Interface\\RaidFrame\\Raid-Icon-DebuffDisease",
}
local BAR = "Interface\\TargetingFrame\\UI-StatusBar"
local ROUND = "Interface\\CharacterFrame\\TempPortraitAlphaMask"
Plate.ROUND = ROUND
local MAX_NOTES = 30    -- lines for the log in one session
-- The player's own buffs over a portrait: four at most (a druid's Mark of the Wild, Thorns, Rejuvenation and Regrowth),
-- each BUFF lines across (the marks in the corners are 12), one line apart: as wide as the portrait. The row stands on
-- the portrait's top edge, half over it (BUFF_UP: its bottom edge, from that top edge). Higher, the row of a lower plate
-- would stand on the name under the plate beside it, which ends about 6 lines over the lower plate's top edge (a ring of
-- five places, Core/WheelRules.lua). The marks in the corners are drawn over a buff where the two meet.
local BUFFS, BUFF, BUFF_UP = 4, 10, -5
Plate.BUFFS, Plate.BUFF, Plate.BUFF_UP = BUFFS, BUFF, BUFF_UP
-- With Wheel Background None a name stands over the world, and over snow or sand a light line with its
-- 1 px shadow is lost. A soft dark backing stands behind it then: the soft black band that the game's
-- level up text stands on (Theme.art.levelUp), its upper half and the same turned over, round the
-- text's box. It fades out all round, so it does not cover the pictures near it as a flat disc would.
local LEVELUP = "Interface\\LevelUp\\LevelUpTex"   -- Theme.art.levelUp
local SOFT = { 25 / 512, 309 / 512, 35 / 512, 122 / 512 }
local SOFT_ALPHA = 0.8  -- the band itself fades out from 0.94 in its middle: about half dark under the letters
local told, notes = {}, 0

-- The first time a plate shows a thing, the log says so: one try in the game tells what works.
local function note(about, text)
    if not told[about] and notes < MAX_NOTES then
        told[about], notes = true, notes + 1
        ns.Log.Add("wheel", text)
    end
end
Plate.Note = note

-- A part of Screen/WheelPlateLive.lua; with no such file none of them, and nothing else changes.
local function live(name, ...)
    local Live = ns.WheelPlateLive
    if Live then
        return Live[name](...)
    end
end

-- A backing for a line of text (see SOFT): two halves on parent's lowest layer, hidden at first.
function Plate.Backing(parent, text)
    local back = { text = text }
    for i = 1, 2 do
        back[i] = parent:CreateTexture(nil, "BACKGROUND")
        back[i]:SetTexture(LEVELUP)
        back[i]:SetAlpha(SOFT_ALPHA)
        back[i]:Hide()
    end
    back[1]:SetTexCoord(SOFT[1], SOFT[2], SOFT[3], SOFT[4])
    back[2]:SetTexCoord(SOFT[1], SOFT[2], SOFT[4], SOFT[3])
    return back
end

-- Puts a backing round its text's box, out by across and up on each side.
function Plate.PlaceBack(back, across, up)
    back[1]:ClearAllPoints()
    back[1]:SetPoint("TOPLEFT", back.text, "TOPLEFT", -across, up)
    back[1]:SetPoint("BOTTOMRIGHT", back.text, "RIGHT", across, 0)
    back[2]:ClearAllPoints()
    back[2]:SetPoint("TOPLEFT", back.text, "LEFT", -across, 0)
    back[2]:SetPoint("BOTTOMRIGHT", back.text, "BOTTOMRIGHT", across, -up)
end

-- Shows a backing while on, and only with Wheel Background None (Screen/Wheel.lua's rule).
function Plate.ShowBack(back, on)
    local shown = on and ns.Registry.Get("wheels.background") ~= "Dark"
    back[1]:SetShown(shown)
    back[2]:SetShown(shown)
end

-- A texture with a circle mask that can be put on and taken off (Screen/Wheel.lua, Screen/WheelRaid.lua).
function Plate.Piece(parent, layer, level)
    local texture = parent:CreateTexture(nil, layer, nil, level)
    texture.mask = parent:CreateMaskTexture()
    texture.mask:SetTexture(ROUND, "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
    texture.mask:SetAllPoints(texture)
    return texture
end

function Plate.Round(texture, on)
    if on and texture.round ~= true then
        texture:AddMaskTexture(texture.mask)
    elseif not on and texture.round == true then
        texture:RemoveMaskTexture(texture.mask)
    end
    texture.round = on
end

-- Adds a member's parts to a picture of the ring. They stay hidden on a picture of any other wheel.
function Plate.Make(c)
    c.bar = CreateFrame("StatusBar", nil, c)
    c.bar:SetStatusBarTexture(BAR)
    c.bar:SetStatusBarColor(0.2, 0.8, 0.25)
    c.ground = c.bar:CreateTexture(nil, "BACKGROUND")
    c.ground:SetColorTexture(0, 0, 0, 0.8)
    -- The heals on the way start where the health ends and have the same scale, as wide as the
    -- whole bar: the game places them, and no sum of health and heals is made here.
    c.coming = CreateFrame("StatusBar", nil, c.bar)
    c.coming:SetStatusBarTexture(BAR)
    c.coming:SetStatusBarColor(Theme.Color("green"))
    local health = c.bar:GetStatusBarTexture()
    c.coming:SetPoint("TOPLEFT", health, "TOPRIGHT")
    c.coming:SetPoint("BOTTOMLEFT", health, "BOTTOMRIGHT")
    c.mark = c:CreateTexture(nil, "OVERLAY")
    -- The percent ends at the bar's middle and the sign starts there: the game may hide the number,
    -- so no width of it is read. (Its frame is made after the bar of the heals: it is drawn over it.)
    local over = CreateFrame("Frame", nil, c.bar)
    over:SetAllPoints()
    c.percent, c.sign = Theme.Text(over, "tiny", "white"), Theme.Text(over, "tiny", "white")
    c.percent:SetPoint("RIGHT", over, "CENTER")
    c.sign:SetPoint("LEFT", c.percent, "RIGHT")
    c.sign:SetText("%")
    -- Dead or Offline, in the bar's middle; the name under the bar, one line (the game cuts a longer one)
    c.state = Theme.Text(over, "tiny", "white")
    c.state:SetPoint("CENTER", over, "CENTER")
    c.who = Theme.Text(c, "tiny", "cream")
    c.who:SetJustifyH("CENTER")
    c.whoBack = Plate.Backing(c, c.who)
    c.raid, c.role = c:CreateTexture(nil, "OVERLAY"), c:CreateTexture(nil, "OVERLAY")
    c.buffs = {}
    for i = 1, BUFFS do
        c.buffs[i] = c:CreateTexture(nil, "OVERLAY", nil, -1)
        c.buffs[i]:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    end
    -- the aggro edge, under the portrait; the mark of a resurrection, on the frame of the bar's words (over the bar)
    c.threat = Plate.Piece(c, "BACKGROUND", 3)
    c.threat:SetColorTexture(1, 1, 1, 1)
    Plate.Round(c.threat, true)
    c.rez = over:CreateTexture(nil, "OVERLAY")
    c.threat:Hide()
    c.rez:Hide()
    -- (what Screen/WheelPlateLive.lua keeps on a plate: a member who left, a dead one, the game's boxes and their anchors)
    c.away, c.dead, c.buffBox, c.markBox, c.buffAnchor, c.markAnchor = false, false, false, false, false, false
end

-- The player's own buffs on a member, again: the ones that show stand side by side in the middle over the portrait.
-- (They come from Core/AdapterPlate.lua; with no such part, none show.)
local function buffs(c, unit)
    local count, how = 0, "plain"
    if c.buffAnchor then   -- (the game's own box draws them)
        return Plate.Hide(c.buffs)
    end
    if ns.Adapter.ShowMyBuffs then
        count, how = ns.Adapter.ShowMyBuffs(c.buffs, unit)
    end
    for i = 1, count do
        c.buffs[i]:ClearAllPoints()
        c.buffs[i]:SetPoint("BOTTOM", c, "TOP", (i - (count + 1) / 2) * c.buffStep, c.buffUp)
    end
    if how == "hidden" then
        note("buffs hidden", "The game hides the auras on " .. unit .. " now: its plate shows none of your buffs.")
    elseif how ~= "plain" then
        note("buffs fault", "Your buffs on " .. unit .. " could not be read: " .. how)
    elseif count > 0 then
        note("buffs", "A plate shows " .. count .. " of your buffs on " .. unit .. ".")
    end
end

-- Shows a member's state on its plate. what is the game's event that told of a change: an event
-- of health changes the bar and the percent, UNIT_AURA the debuff mark, RAID_TARGET_UPDATE the raid
-- target mark, PLAYER_ROLES_ASSIGNED the role, and the group's own word every part with the portrait (a token can
-- hold another member now, or no one: Screen/WheelPlateLive.lua There); nil all of them.
function Plate.Show(c, unit, what)
    if what == nil or ROSTER[what] then
        if live("There", c, unit, what) == false or what and what ~= "GROUP_ROSTER_UPDATE" then
            return
        end
        what = nil
    elseif c.away then
        return
    end
    if what == nil or HEALTH[what] then
        local color = ns.Adapter.ShowHealth(c.bar, unit) or "none"
        note("color " .. color, "A plate's health color for " .. unit .. ": " .. color .. ".")
        local shown, coming = ns.Adapter.ShowIncoming(c.coming, unit)
        c.coming:SetShown(shown)
        if not shown then
            note("hidden", "The game hides the heals on the way to " .. unit .. ": the plate shows none of them.")
        elseif coming > 0 then
            note("heals", "The first heal on the way that a plate shows: " .. coming .. " to " .. unit .. ".")
        end
        local how = ns.Adapter.ShowPercent(c.percent, unit)
        note("percent", "A plate's health in percent for " .. unit .. ": " .. how .. ".")
        -- offline, dead or a ghost: the game's word in place of the percent, and a gray bar and name
        local word, state = ns.Adapter.MemberState(unit)
        c.gone, c.dead = word ~= nil and state ~= "feign", state == "dead"
        c.state:SetText(word or "")
        c.percent:SetShown(word == nil)
        c.sign:SetShown(word == nil and (how == "hidden" or how == "plain"))
        if c.gone then
            c.bar:SetStatusBarColor(GRAY.r, GRAY.g, GRAY.b)
        end
        if word then
            note(word, "A plate shows " .. unit .. " as " .. word .. ".")
        end
        local color, said = ns.Adapter.ShowName(c.who, unit)
        color = c.gone and GRAY or color
        if color then
            c.who:SetTextColor(color.r, color.g, color.b)
        else
            c.who:SetTextColor(Theme.Color("cream"))
        end
        note("name", "A plate's name for " .. unit .. ": " .. said .. ".")
    end
    if what == nil or what == "UNIT_AURA" then
        local kind = not c.markAnchor and ns.Cleanse and ns.Cleanse.on and ns.Cleanse.Mark(unit) or nil
        c.mark:SetShown(kind ~= nil)
        if kind then
            c.mark:SetTexture(MARK[kind])
            note(kind, "A plate shows the mark for " .. kind .. " on " .. unit .. ".")
        end
        buffs(c, unit)
    end
    if what == nil or what == "RAID_TARGET_UPDATE" then
        local said = ns.Adapter.ShowMark(c.raid, unit)
        if said ~= "none" then
            note("raid", "A plate shows the raid target mark of " .. unit .. ": " .. said .. ".")
        end
    end
    if what == nil or ROLE[what] then
        note("role", "A plate's group role for " .. unit .. ": " .. ns.Adapter.ShowRole(c.role, unit) .. ".")
    end
    live("Show", c, unit, what, what == nil or HEALTH[what])
end

function Plate.Hide(textures)
    for _, texture in ipairs(textures) do
        texture:Hide()
    end
end

-- Nothing of a member is left on a picture: a picture of another wheel, or of a member who left.
function Plate.Bare(c)
    Plate.Hide(c.buffs)
    Plate.Hide({ c.mark, c.raid, c.role, c.threat, c.rez })
    c.state:SetText("")
    c.gone, c.dead = false, false
end

-- Places a picture's parts for pictures of size units (line is one unit of the frame and of the
-- black line), and shows them for a member (unit), or hides them on an entry that is no member.
-- The type is the Theme's tiny size, grown with the setting Wheel Size (line / Rules.GAME).
function Plate.Lay(c, size, line, unit)
    local tiny = px(Theme.size.tiny * line / ns.WheelRules.GAME)
    c.bar:ClearAllPoints()
    c.bar:SetPoint("TOPLEFT", c, "BOTTOMLEFT", 0, -px(4 * line))
    c.bar:SetPoint("TOPRIGHT", c, "BOTTOMRIGHT", 0, -px(4 * line))
    c.bar:SetHeight(px(6 * line))
    c.ground:ClearAllPoints()
    c.ground:SetPoint("TOPLEFT", c.bar, "TOPLEFT", -px(line), px(line))
    c.ground:SetPoint("BOTTOMRIGHT", c.bar, "BOTTOMRIGHT", px(line), -px(line))
    c.coming:SetWidth(px(size))
    c.percent:SetFont(Theme.font.text, tiny, "OUTLINE")
    c.sign:SetFont(Theme.font.text, tiny, "OUTLINE")
    c.state:SetFont(Theme.font.text, tiny, "OUTLINE")
    -- (a name may be wider than the portrait: two plates side by side stand 1.7 pictures apart)
    c.who:SetFont(Theme.font.text, tiny, "")
    c.who:SetWidth(px(size * 1.6))
    c.who:ClearAllPoints()
    c.who:SetPoint("TOP", c.bar, "BOTTOM", 0, -px(3 * line))
    c.who:SetShown(unit ~= nil)
    Plate.PlaceBack(c.whoBack, px(5 * line), px(4 * line))
    Plate.ShowBack(c.whoBack, unit ~= nil)
    -- the debuff mark and the raid target mark sit in the top corners, the role in the bottom left, as far in
    for texture, corner in pairs({ [c.mark] = "TOPLEFT", [c.raid] = "TOPRIGHT", [c.role] = "BOTTOMLEFT" }) do
        texture:SetSize(px(12 * line), px(12 * line))
        texture:ClearAllPoints()
        texture:SetPoint(corner, c, corner, px((corner:find("LEFT") and 2 or -2) * line), px((corner:find("TOP") and -2 or 2) * line))
    end
    for _, icon in ipairs(c.buffs) do
        icon:SetSize(px(BUFF * line), px(BUFF * line))
    end
    c.buffStep, c.buffUp = px((BUFF + 1) * line), px(BUFF_UP * line)
    c.threat:ClearAllPoints()
    c.threat:SetPoint("TOPLEFT", c, "TOPLEFT", -px(EDGE * line), px(EDGE * line))
    c.threat:SetPoint("BOTTOMRIGHT", c, "BOTTOMRIGHT", px(EDGE * line), -px(EDGE * line))
    c.rez:SetSize(px(REZ * line), px(REZ * line))
    c.rez:ClearAllPoints()
    c.rez:SetPoint("RIGHT", c.bar, "RIGHT", 0, 0)
    c.bar:SetShown(unit ~= nil)
    c.line = line
    live("Lay", c, unit)
    if unit then
        Plate.Show(c, unit)
    else
        -- (a picture of another wheel)
        c.away = false
        Plate.Bare(c)
        c:SetAlpha(1)
        c.art:SetDesaturated(false)
    end
end

-- A party wheel opens or closes: Screen/WheelPlateLive.lua follows the game for its plates and its
-- middle. With no such file the plates are drawn and follow nothing.
function Plate.Open() end
function Plate.Close() end
