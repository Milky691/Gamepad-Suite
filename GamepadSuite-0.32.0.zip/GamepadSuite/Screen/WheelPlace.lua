-- Where each wheel opens on the screen (the owner: "healer wheel on my right and consumes on my left"), and how
-- large it is (the owner, 2026-10-17: "wheel size should be adjustable for every wheel individually").
-- The page Wheel Settings (Wheels tab) changes one wheel at a time, as the Fixed Slots tab moves one slot
-- (Core/Slots.lua): Wheel to Change names the wheel, and the rows Wheel Size, Wheel X Position and Wheel Y Position
-- stand for that wheel's size and place. The choices are All Wheels, then every wheel the player has: the wheels of every
-- character (the Portal Wheel for a mage, the Quick Chat Wheel where the game has it), the Healer Wheel (one
-- place for the party wheel of every spell and item) while healer mode is on, and each of My Wheels by its name
-- (Screen/WheelModel.lua Places).
--   All Wheels is the place of every wheel that has no place of its own. It starts at the one place of the
--   builds before (the settings Wheel X / Y Position, read here once), so nothing moves until a wheel is moved.
--   A wheel gets a place of its own the first time it is moved, from where it stood. Its size is apart from its
--   place: a wheel with a size of its own and no place of its own still moves with All Wheels. All Wheels' size
--   starts at the setting Wheel Size of the builds before.
--   The places of All Wheels and of the wheels of every character are the account's, as every other place on
--   the screen is; the places of My Wheels are the character's own, as those wheels are, and each build of the
--   character has its own (Core/BuildRules.lua). A text does not carry them.
-- The two rows reach the edges of the player's screen at the player's UI scale, fitted each time the settings
-- window opens (Fit): a wheel's middle stops half a wheel and MARGIN short of the edge, so the whole ring is on
-- the screen; a slot's middle stops MARGIN short (the 780 and 430 of the builds before, on a screen of 1600 x 900
-- units). The rows of the fixed slots get the same reach here.
-- Nothing here runs on a timer: it follows the settings window, a change of the wheels and two settings.
local _, ns = ...

local Place = ns.Module("WheelPlace", nil, "Wheels")
ns.WheelPlace = Place

local Model, Rules = ns.WheelModel, ns.WheelRules

local MARGIN = 20
local MIDDLE = { x = 0, y = 0 }
-- the Healer Wheel's test wheel has no spell: its middle shows the game's picture of a heal
local HEAL_ICON = "Interface\\Icons\\Spell_Holy_FlashHeal"
local shared, own                   -- the places: { [key] = { x =, y =, size = } }; own: My Wheels, this character's
local moving = "all"                -- the place the two rows move now (not saved, as Slot to Move is not)
local keys, names = { [Model.ALL] = "all" }, { all = Model.ALL }   -- choice -> place, place -> choice
local rows, most = {}, {}           -- the rows of the settings that this file changes; their widest reach

local function store(key)
    return tostring(key):match("^my") and own or shared
end

-- Where a wheel opens (id: a wheel, or a place): x and y from the middle of the screen.
function Place.Of(id)
    local key = Model.PlaceKey(id or "all")
    local at = store(key)[key]
    at = at and at.x and at or shared.all or MIDDLE
    return at.x, at.y
end

-- How large a wheel is (id: a wheel, or a place), in percent: its own size, else All Wheels'.
function Place.Size(id)
    local key = Model.PlaceKey(id or "all")
    local at = store(key)[key]
    return at and at.size or shared.all and shared.all.size or 100
end

-- The entry of a wheel's place and size, made the first time one of them changes.
local function entry(key)
    local places = store(key)
    places[key] = places[key] or {}
    return places[key]
end

-- The test wheel (decision 99): the wheel being moved, with what it holds now, and its place. All Wheels, and a
-- wheel that holds nothing now, show the raid markers.
function Place.Test()
    local entries = {}
    if moving == "heal" then
        local units = ns.Adapter.PartyUnits()
        entries = Rules.Party(#units > 0 and units or { "player" }, "spell", 0, HEAL_ICON)
    elseif moving ~= "all" then
        entries = ns.Wheels.Entries(moving)
    end
    return #entries > 0 and entries or Rules.Markers(), moving
end

-- The choices of Wheel to Change, from the wheels the player has now. The row's choices are the setting's own
-- (one table: Settings/Window.lua), so they change in place. A wheel that is gone: the rows move All Wheels.
local function choose()
    local list
    list, keys = Model.Places(ns.Wheels.Binds(), ns.Registry.Get("combat.healer_mode") == "Wheel")
    names = {}
    for name, key in pairs(keys) do
        names[key] = name
    end
    local options = rows["wheels.move"].options
    for i = #options, 1, -1 do
        options[i] = nil
    end
    for i, name in ipairs(list) do
        options[i] = name
    end
    moving = names[moving] and moving or "all"
end

-- The reach of the position rows on this screen (Screen/WheelModel.lua Reach), never past what the settings hold.
function Place.Fit()
    local wide, high = ns.Adapter.ScreenUnits()
    local _, _, across = Rules.Measure(Rules.MOST, Place.Size(moving))
    for part, margin in pairs({ wheels = MARGIN + across / 2, slots = MARGIN }) do
        local x, y = Model.Reach(wide, high, margin)
        for axis, reach in pairs({ x = x, y = y }) do
            local row = rows[part .. "." .. axis]
            if row then
                reach = math.min(reach, most[row.key])
                row.min, row.max = -reach, reach
            end
        end
    end
end

-- A build of this character takes the place of the one in use (Core/Profiles.lua): its places of My Wheels.
function Place.Replace(places)
    GamepadSuiteCharDB.wheelPlaces, own = places, places
end

-- Reset All Settings: every wheel opens in the middle again (and the setting of the builds before is not read again).
function Place.Reset()
    for _, places in ipairs({ shared, own }) do
        for key in pairs(places) do
            places[key] = nil
        end
    end
    shared.all = { x = 0, y = 0, size = 100 }
end

-- The rows of the settings that this file changes, wherever they stand (Settings/Data.lua).
local CHANGED = { ["wheels.move"] = true, ["wheels.x"] = true, ["wheels.y"] = true, ["slots.x"] = true, ["slots.y"] = true }
local function find(list)
    for _, row in ipairs(list) do
        if CHANGED[row.key] then
            rows[row.key], most[row.key] = row, row.max
        end
        if row.sub then
            find(row.sub.rows)
        end
    end
end

function Place.OnLogin()
    local Registry = ns.Registry
    GamepadSuiteCharDB = GamepadSuiteCharDB or {}
    GamepadSuiteCharDB.wheelPlaces = GamepadSuiteCharDB.wheelPlaces or {}
    shared, own = Registry.Store("wheelPlaces"), GamepadSuiteCharDB.wheelPlaces
    if not shared.all then
        local before = Registry.Saved()
        shared.all = { x = before["wheels.x"] or 0, y = before["wheels.y"] or 0 }
    end
    shared.all.size = shared.all.size or Registry.Saved()["wheels.size"] or 100
    for _, tab in ipairs(ns.SettingsData) do
        find(tab.rows)
    end
    Registry.Virtual("wheels.move", function()
        return names[moving] or Model.ALL
    end, function(name)
        moving = keys[name] or "all"
    end)
    for _, axis in ipairs({ "x", "y" }) do
        Registry.Virtual("wheels." .. axis, function()
            return (select(axis == "x" and 1 or 2, Place.Of(moving)))
        end, function(value)
            local x, y = Place.Of(moving)
            local at = entry(moving)
            at.x, at.y = x, y
            at[axis] = value
        end)
    end
    Registry.Virtual("wheels.size", function()
        return Place.Size(moving)
    end, function(value)
        entry(moving).size = value
    end)
    choose()
    ns.Listen("settings:opened", "WheelPlace", Place.Fit)
    ns.Listen("wheels", "WheelPlace", choose)
    ns.Listen("setting", "WheelPlace", function(key)
        if key == "combat.healer_mode" then
            choose()
        elseif key == "wheels.size" or key == "wheels.move" then
            Place.Fit()
        end
    end)
end
