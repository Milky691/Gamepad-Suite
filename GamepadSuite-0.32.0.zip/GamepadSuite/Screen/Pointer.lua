-- Mouse mode: a pointer that the right stick moves. LT is the left mouse button and RT the right
-- one: a whole click (press and let-go at once) at the let-go of the trigger, so a held trigger
-- never drags. It is a bind, "Mouse Mode" in the list Game Actions, and View + Menu
-- (Screen/PointerPair.lua): each turns it on with the pointer where the game's own pointer is,
-- and off again, in a window of the game too. B turns it off too. It ends when a fight starts,
-- and when a wheel opens: a wheel has the right stick and B too. With the game's controller
-- interface off (the master switch, Core/Pad.lua) it rests.
-- Each time it comes on or goes off, the message "pointer" tells the other modules (true: on).
--
-- This game turns its own controller pointer off again as soon as it is on (ControllerForever's
-- notes say so after eight tries; the idea of a pointer that the addon draws is from there, the
-- code is ours). So the pointer is a picture of ours. A click is the game's own: at a press that
-- comes from the controller it lets an addon put the real mouse pointer at a place and press a
-- mouse button there (Core/AdapterPointer.lua), so a click works on a window and in the world.
-- For that the game's camera look is off while mouse mode is on: with it on, the game holds its
-- pointer in the middle of the screen and every click goes there (Adapter.CameraLook says why).
-- The owner's 0.23.0 log: a mouse button held from the press to the let-go turned the game's
-- camera look back on before the let-go, and the game said the button was still down for good
-- after, so mouse mode kept B after it went off. No mouse button is ever held now.
-- While the right stick rests, Screen/PointerAim.lua puts LT and RT straight onto what is under
-- the pointer (a button, the world), in ways that need no pointer of the game's or that check it.
--
-- The sticks come through two frames of ours (Screen/PointerSticks.lua). The buttons come
-- through no frame: while mouse mode is on, LT, RT and B are key binds of ours, and every other
-- button is the game's as before. All of them are given back the moment it goes off.
local _, ns = ...

local Pointer = ns.Module("Pointer", { "pointer", "tempSetting" }, "Mouse Mode")
ns.Pointer = Pointer

local Model, Sticks = ns.PointerModel, ns.PointerSticks

local TOGGLE, CLICK = "GamepadSuitePointerToggle", "GamepadSuitePointerClick"
local COMMAND = "CLICK " .. TOGGLE .. ":LeftButton"
local ART = "Interface\\Cursor\\Point"
-- The buttons that are ours while mouse mode is on, and what each tells the click button: a
-- mouse button to click, or "Off".
local KEYS = { { "LT", "LeftButton" }, { "RT", "RightButton" }, { "B", "Off" } }

local frame, toggle, click
local on = false           -- mouse mode is on
local wheel                -- the wheel that is open, if one is
local x, y = 0, 0          -- the pointer's place, in the units of the game's mouse pointer
local stickX, stickY = 0, 0
local unit = 1             -- what the game wants a place multiplied by (Model.Units)
local askedX, askedY, askedAt   -- the last place the game took, and when
local checked, tries = false, 0 -- the units were learned; how many times they were looked at
local pressed = {}         -- mouse button -> true from its trigger's press in mouse mode to the let-go, which clicks
local notes, refused = 0, 0    -- lines written to the log since mouse mode came on; lines for a try that failed
local taken = 0            -- frames in which the game had taken its pointer back for the camera, this time
local resting = true       -- the right stick is in the middle (the magnet hears when that changes)

-- A few lines for each time mouse mode is on: what the game allowed. Read from the saved file.
local function note(text)
    if notes < 14 then
        notes = notes + 1
        ns.Log.Add("pointer", text)
    end
end

local function at(px, py)
    return math.floor(px) .. ", " .. math.floor(py)
end

-- The bind list's entry (Core/Catalog.lua).
function Pointer.Bind()
    return { kind = "command", id = COMMAND, name = "Mouse Mode", detail = "The right stick moves a pointer", icon = ART }
end

function Pointer.IsOn()
    return on
end

local function place(px, py)
    local _, _, scale = ns.Adapter.PointerSpace()
    frame:ClearAllPoints()
    -- the tip of the picture is its top left corner
    frame:SetPoint("TOPLEFT", UIParent, "BOTTOMLEFT", (px or x) / scale, (py or y) / scale)
end

-- Puts the game's own mouse pointer under ours. The game allows it only at a press or a move
-- that comes from the controller. Where the game took its pointer back for the camera (it does
-- after a click) it is set free first, which Adapter.PointerFree does only where a move is allowed
-- too: so it never shows where the game held it, in the middle of the screen. freeAsked: the caller
-- asked for that already. Gives if it moved, and if it had to be set free.
local function follow(freeAsked)
    local freed = not freeAsked and ns.Adapter.PointerFree(true)
    if ns.Adapter.PointerMove(x * unit, y * unit) then
        askedX, askedY, askedAt = x, y, GetTime()
        return true, freed
    end
    return false, freed
end

-- One frame after a click the log says if the game shows its own pointer too, and where: the
-- owner's report of 0.25.1 was a second pointer in the middle of the screen at each click.
local lookAfter    -- the click to look after in the next frame
function Pointer.LookAfter(what)
    lookAfter = on and what or nil
end

local function shown()
    local gotX, gotY = ns.Adapter.PointerPlace()
    if not ns.Adapter.PointerShows() then
        return "the game's own pointer is hidden (the game holds it for the camera): one pointer"
    end
    return "the game's own pointer shows at " .. at(gotX, gotY) .. (Model.Near(x, y, gotX, gotY) and ", under ours: one pointer"
        or ", and ours is at " .. at(x, y) .. ": two pointers")
end

-- For the magnet (Screen/PointerMagnet.lua): where the pointer is; a move of it, which the game's
-- own pointer follows where the game allows it (true when it did); the picture alone at a place.
function Pointer.Spot()
    return x, y
end

function Pointer.MoveTo(toX, toY)
    x, y = toX, toY
    place()
    return follow()
end

Pointer.Draw = place

-- Mouse mode ends, by any way: LT, RT, B and the bind's buttons are the game's again at once. A
-- key can be given back out of a fight only; the game tells of a fight before it locks the keys,
-- and Off runs then (OnLogin).
function Pointer.Off()
    if not on then
        return
    end
    on, pressed = false, {}
    frame:Hide()
    local seen = Sticks.Stop()
    ns.Adapter.GiveKeys(click)
    ns.Adapter.PointerTriggers(false)
    ns.Adapter.CameraLook(true)
    ns.Send("pointer", false)
    ns.Log.Add("pointer", "off. " .. seen .. " The game took its pointer back for the camera in " .. taken .. " frames. " .. ns.Adapter.PointerState())
end

-- LT, RT and B are ours, and so is each button that has the bind, on any layer (in mouse mode a
-- trigger is a mouse button, so a layer cannot be held). On a key the newest bind wins, so the
-- keys are given back and taken anew each time. Gives what the game read back, for the log.
local function takeKeys()
    ns.Adapter.GiveKeys(click)
    local said = {}
    for _, key in ipairs(KEYS) do
        said[#said + 1] = key[1] .. " " .. tostring(ns.Adapter.TakeKey(click, key[1], key[2]))
    end
    ns.Binds.Each(function(bind, _, _, key)
        if bind.kind == "command" and bind.id == COMMAND and ns.Adapter.KEY[key] then
            ns.Adapter.TakeKey(click, key, "Bind")
        end
    end)
    return table.concat(said, ", ")
end

-- True when mouse mode came on. Else false and why, in a few words. Not in a fight, and not at
-- the start of one: the game is about to lock the keys then. Not while a wheel is open: the right
-- stick and B are the wheel's. Not with the game's controller interface off.
function Pointer.On()
    local why = (ns.Adapter.InCombat() or ns.fightStarted) and "a fight" or wheel and "a wheel is open"
        or not ns.Pad.Controller() and "the controller is off in the game's settings" or on and "it is on"
    if why then
        return false, why
    end
    -- ours starts where the game's pointer is (its centered place while the stick was the camera),
    -- so the two are one from the start; the middle of the screen when the game gives no place there
    local width, height = ns.Adapter.PointerSpace()
    local gx, gy = ns.Adapter.PointerPlace()
    local inside = gx > 0 and gx < width and gy > 0 and gy < height
    x, y = inside and gx or width / 2, inside and gy or height / 2
    stickX, stickY, notes, taken, resting, pressed, lookAfter = 0, 0, 0, 0, true, {}, nil
    on = true
    -- first the triggers stop being Shift, Ctrl or Alt: a key that is one cannot have a bind
    ns.Adapter.PointerTriggers(true)
    local keys = takeKeys()
    -- the game's camera look goes off, and its pointer is put under ours at once: the press that
    -- turned mouse mode on came from the controller, so the game allows one move
    ns.Adapter.CameraLook(false)
    local moved = follow()
    place()
    frame:Show()
    local earOn = Sticks.Start()
    note("on at " .. at(x, y) .. "; keys of ours: " .. keys .. "; the ear hands the sticks on: " .. tostring(earOn)
        .. "; " .. ns.Adapter.TriggerSettings() .. "; the game's pointer was put under ours: " .. tostring(moved) .. "; " .. ns.Adapter.PointerState())
    ns.Send("pointer", true)
    return true
end

-- The bind, and the press of two buttons. A try that turns nothing on says why in the log.
function Pointer.Toggle()
    if on then
        Pointer.Off()
        return
    end
    local came, why = Pointer.On()
    if not came and refused < 6 then
        refused = refused + 1
        ns.Log.Add("pointer", "mouse mode did not come on: " .. why)
    end
end

-- A press of the bind. One that comes less than half a second after the last one is no new
-- press: a hard push of the right stick can click it twice (the owner's log of 0.21.0, with the
-- bind on RS: on and off within one second, two times). The log has the first ones left out.
local bindAt, bounced = -1, 0
local function bind()
    local now = GetTime()
    if now - bindAt < 0.5 then
        if bounced < 4 then
            bounced = bounced + 1
            ns.Log.Add("pointer", ("a press of the bind %.2f s after the last one was left out"):format(now - bindAt))
        end
        return
    end
    bindAt = now
    Pointer.Toggle()
end

-- A key of ours went down or up (a click of the click button): LT or RT clicks its mouse button
-- at the let-go, B turns mouse mode off, and so does the button with the bind ("Bind").
local function press(mouse, down)
    if mouse == "Off" or mouse == "Bind" then
        if down then
            (mouse == "Bind" and bind or Pointer.Off)()
        end
        return
    end
    -- (a let-go with no press of ours behind it, a trigger held from before mouse mode: no click)
    if not on or not (down or pressed[mouse]) then
        return
    end
    pressed[mouse] = down or nil
    -- the game may have taken its pointer back for the camera since the last frame: it is set free
    -- first (follow), else the move comes to nothing and the click goes to the middle of the screen
    local moved, freed = follow()
    if down then
        return
    end
    -- a click goes where the game's pointer is: none while that is not under ours
    local gotX, gotY = ns.Adapter.PointerPlace()
    local done = Model.Near(x, y, gotX, gotY) and ns.Adapter.PointerButton(mouse, true) and ns.Adapter.PointerButton(mouse, false)
    note(mouse .. " click at " .. at(x, y) .. ": set free first " .. tostring(freed) .. ", moved " .. tostring(moved) .. "; the game's pointer is at "
        .. at(gotX, gotY) .. "; clicked " .. tostring(done) .. "; " .. ns.Adapter.PointerState())
    Pointer.LookAfter(mouse .. " click")
end

-- A stick that the two stick frames heard: the right stick's word moves the pointer.
local function stick(name, sx, sy)
    if Model.STICK[name] then
        stickX, stickY = sx, sy
        -- it came back to the middle, or left it: told first, so the magnet can take the game's one move here
        if (sx * sx + sy * sy <= Model.DEAD * Model.DEAD) ~= resting then
            resting = not resting
            ns.Send("pointer:stick", resting)
        end
        follow()
    end
end

-- Each frame while mouse mode is on (the frame shows only then).
local function update(_, elapsed)
    -- (first: what the game shows after a click, before anything here sets its pointer free)
    if lookAfter then
        note("a frame after the " .. lookAfter .. ": " .. shown() .. "; " .. ns.Adapter.PointerState())
        lookAfter = nil
    end
    -- the game takes its pointer back for the camera (its controller camera look comes back after a
    -- click): it is set free in a frame where the game also allows a move, and put under ours at
    -- once (below). The log says so the first time, and Off says in how many frames.
    local freed = ns.Adapter.PointerFree(true)
    if freed then
        taken = taken + 1
        if taken == 1 then
            note("the game held its pointer for the camera while mouse mode was on: set free and put under ours in the same frame; "
                .. ns.Adapter.PointerState())
        end
    end
    local width, height, scale = ns.Adapter.PointerSpace()
    -- the place the game took is read back, a frame or more later, and the units are set right
    if not checked and askedAt and askedAt < GetTime() then
        local gotX, gotY = ns.Adapter.PointerPlace()
        local by = Model.Units(askedX, gotX, scale)
        tries = tries + 1
        if by or tries >= 30 then
            checked, unit = true, by or 1
            note("asked for " .. at(askedX, askedY) .. ", the game says " .. at(gotX, gotY) .. "; units x" .. unit .. (by and "" or " (no fit)"))
        end
        askedAt = nil
    end
    local nextX, nextY = Model.Step(x, y, stickX, stickY, elapsed, width, height)
    local moving = nextX ~= x or nextY ~= y
    if moving then
        x, y = nextX, nextY
        place()
    end
    -- where the game allows it between two presses, its own pointer follows, so that the thing
    -- under it lights up; one it set free is put under ours in this frame, never left in the middle
    if moving or freed then
        follow(true)
    end
end

-- A window of the game has the controller: the bind core has given every key back for that
-- time. The button with the bind Mouse Mode, on no layer, keeps its key, because a window is
-- what the pointer is for. It is a bind of the toggle button's own (as the game menu's Y).
local function keys()
    if ns.Adapter.InCombat() or ns.fightStarted or not toggle then -- (after a reload in combat it is made at its end)
        return
    end
    ns.Adapter.GiveKeys(toggle)
    -- the game's controller interface went off: mouse mode ends, and no key is ours
    if not ns.Pad.Controller() then
        return Pointer.Off()
    end
    -- Mouse mode is on and the game's binds changed: a window that opens (the bags) takes LT and
    -- RT for its own Previous and Next. A click in a window is what mouse mode is for, so LT, RT
    -- and B are taken anew. Never while it is off: then no key is ours.
    if on then
        note("the game's binds changed. Keys of ours, taken anew: " .. takeKeys())
        -- (they stand over the aim now: Screen/PointerAim.lua puts LT and RT back on it)
        ns.Send("pointer:keys")
    end
    if ns.Pad.Gameplay() or (ns.Settings and ns.Settings.IsOpen()) then
        return
    end
    ns.Binds.Each(function(bind, set, layer, key)
        if set == "normal" and layer == 1 and bind.kind == "command" and bind.id == COMMAND and ns.Adapter.KEY[key] then
            ns.Adapter.TakeKey(toggle, key)
        end
    end)
end

function Pointer.OnLogin()
    -- The picture. This frame shows only while mouse mode is on, and only then does its script
    -- run each frame, to move the pointer.
    frame = CreateFrame("Frame", "GamepadSuitePointer", UIParent)
    frame:SetFrameStrata("TOOLTIP")
    -- over the chat keyboard, which is TOOLTIP at level 500 (Screen/KeyboardDraw.lua)
    frame:SetFrameLevel(600)
    frame:SetSize(32, 32)
    -- it must not take the mouse: the click is for what is under it
    frame:EnableMouse(false)
    frame:Hide()
    frame.art = frame:CreateTexture(nil, "OVERLAY")
    frame.art:SetTexture(ART)
    frame.art:SetAllPoints()
    frame:SetScript("OnUpdate", function(self, elapsed)
        -- a fault here would come every frame: it is logged once, the watch stops and mouse mode ends
        if not ns.Call("Pointer", update, self, elapsed) then
            self:SetScript("OnUpdate", nil)
            Pointer.Off()
        end
    end)
    -- the two stick frames (Screen/PointerSticks.lua)
    Sticks.Build(stick, note, Pointer.Off)
    -- the button that LT, RT and B click while mouse mode is on
    click = CreateFrame("Button", CLICK, UIParent)
    click:RegisterForClicks("AnyDown", "AnyUp")
    click:SetScript("OnClick", function(_, mouse, down)
        ns.Call("Pointer", press, mouse, down)
    end)
    -- The button that the bind clicks. A secure button (made out of a fight), so the bind core can
    -- hear its press too (Sticky Layers, Core/BindCore.lua).
    ns.Queue.Run("PointerToggle", function()
        toggle = CreateFrame("Button", TOGGLE, UIParent, "SecureActionButtonTemplate")
        toggle:RegisterForClicks("AnyDown")
        toggle:SetScript("OnClick", function()
            ns.Call("Pointer", bind)
        end)
    end)
    -- A wheel opens: mouse mode ends first, so B closes the wheel and the right stick chooses on
    -- it. A wheel can open in a fight, where mouse mode could not give its keys back. The two do
    -- not meet there: mouse mode does not come on in a fight, and it ends at the start of one,
    -- with its keys given back while the game still allows that (see below).
    ns.Listen("wheel", "Pointer", function(id)
        wheel = id or nil
        if wheel and on then
            ns.Log.Add("pointer", "the wheel " .. tostring(wheel) .. " opened: mouse mode ends")
            Pointer.Off()
        end
    end)
    ns.Listen("pad:stack", "Pointer", keys)
    ns.Listen("bind", "Pointer", keys)
    ns.On("PLAYER_REGEN_ENABLED", "Pointer", keys)
    -- A fight: the game's buttons that a click could reach are closed to an addon then, and the
    -- triggers are needed for the fight. The game tells of the fight before it locks anything,
    -- so every key of ours is given back here.
    ns.On("PLAYER_REGEN_DISABLED", "Pointer", function()
        Pointer.Off()
        ns.Adapter.GiveKeys(toggle)
    end)
    -- (a reload with mouse mode on: the trigger settings are let go first)
    ns.On("PLAYER_LOGOUT", "Pointer", Pointer.Off)
end
