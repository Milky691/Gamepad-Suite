-- The rules of Trackpad and Touch, with no game calls: when the pointer becomes the player's,
-- and when the controller has it back.
local _, ns = ...

local Model = {}

Model.MOVE = 3     -- the pointer went farther than this between two looks: it moved
Model.LOOKS = 3    -- that many looks in a row with a move: a hand moves it
Model.REST = 0.2   -- every stick pushed less than this, and no button down: the controller is at rest
Model.PUSH = 0.5   -- a stick pushed farther than this: the player is on the controller

-- What the rules keep between two looks: is the pointer the player's, how many looks in a row
-- saw the pointer move, and what was down on the controller when the pointer became the player's.
function Model.New()
    return { on = false, moves = 0, base = {} }
end

-- A mouse button that makes the pointer the player's when it goes down. Not the right one: a
-- press of it is most often the start of a drag that turns the camera, and that is the game's.
function Model.Begins(button)
    return button ~= "RightButton"
end

-- One look at the mouse and the controller. s is the table of Model.New. now has:
--   click    the name of a mouse button that went down since the last look (Model.Begins), or nil
--   moved    how far the pointer went since the last look, the larger of across and up
--   locked   the game has the pointer hidden and locked for the camera
--   held     a mouse button is down
--   buttons  the controller's buttons: place -> true while down
--   pushes   how far each stick is pushed, 0 to 1, by its place
-- Gives "begins" or "ends" and what set it off, or nothing when the state stays as it is.
--
-- It begins at a press of a mouse button (a tap is one), or when the pointer moves in three
-- looks in a row while it is free, no mouse button is down and the controller is at rest. One
-- jump is the game putting the pointer back, and a move under a pushed stick is not a hand on
-- the mouse. It does not begin at a move while the pointer is locked: a player can turn the
-- camera with a mouse or a gyro.
-- It ends at a button newly pressed, or a stick newly pushed past halfway. What was down when
-- it began does not end it before it was let go: the button that the player still holds, and a
-- stick that walks the character. So the player can walk and tap.
function Model.Look(s, now)
    local down, rest = {}, true
    for place, isDown in pairs(now.buttons) do
        if isDown then
            down[place], rest = "a button was pressed", false
        end
    end
    for place, push in pairs(now.pushes) do
        if push > Model.PUSH then
            down["stick" .. place] = "a stick was pushed"
        end
        rest = rest and push < Model.REST
    end
    if s.on then
        for what in pairs(s.base) do
            if not down[what] then
                s.base[what] = nil
            end
        end
        for what, why in pairs(down) do
            if not s.base[what] then
                s.on = false
                return "ends", why
            end
        end
        return
    end
    local moved = now.moved > Model.MOVE and rest and not now.locked and not now.held
    s.moves = moved and s.moves + 1 or 0
    local why = now.click and now.click .. " went down" or s.moves >= Model.LOOKS and "the pointer moved"
    if why then
        s.on, s.moves, s.base = true, 0, down
        return "begins", why
    end
end

if ns then
    ns.HandoffModel = Model
end
return Model
