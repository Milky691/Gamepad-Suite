-- The rules of the button cues and of hiding the on-screen buttons, with no game calls. HudCues.lua
-- draws the cues (Proc Glow, Interrupt Glow, Gray While Cooling, Flash When Ready) and HudHide.lua
-- hides the buttons (Hide While Mounted, Hide While Resting). Pack: build_plan/packs/P15_button_cues.md.
local _, ns = ...

local Model = {}

-- The interrupts of this game, by the spell number of one rank. A button glows for any rank: the
-- game's name of the spell a press casts now is matched with the game's names of these.
Model.KICKS = {
    1766, -- Kick
    6552, -- Pummel
    72, -- Shield Bash
    2139, -- Counterspell
    8042, -- Earth Shock
    57994, -- Wind Shear (ControllerForever names it for this game)
    16979, -- Feral Charge in Bear Form (the Cat version does not interrupt)
    15487, -- Silence
    19244, -- Spell Lock (the warlock's felhunter)
}

-- The colors, by their names in the Theme: its gold for a lit spell, its red for an interrupt. A
-- glow reaches in from the edge by a part of the picture, and is this strong at the edge.
Model.PROC, Model.KICK = "gold", "red"
Model.GLOW = { reach = 0.34, edge = 0.95 }
-- The flash when a cooldown ends: its strength at the start, and how long it takes to fade.
Model.FLASH = { from = 0.85, seconds = 0.45 }

-- The four strips of a glow inside a picture of `size` units, one along each side. Each lies
-- between two points of the picture, has a width (or a height) and fades from the edge inward:
-- the game's gradient goes from min to max, bottom to top (VERTICAL) or left to right (HORIZONTAL).
function Model.Strips(size)
    local reach, edge = size * Model.GLOW.reach, Model.GLOW.edge
    return {
        { points = { "TOPLEFT", "TOPRIGHT" }, height = reach, orient = "VERTICAL", min = 0, max = edge },
        { points = { "BOTTOMLEFT", "BOTTOMRIGHT" }, height = reach, orient = "VERTICAL", min = edge, max = 0 },
        { points = { "TOPLEFT", "BOTTOMLEFT" }, width = reach, orient = "HORIZONTAL", min = edge, max = 0 },
        { points = { "TOPRIGHT", "BOTTOMRIGHT" }, width = reach, orient = "HORIZONTAL", min = 0, max = edge },
    }
end

-- The keys of the spells the game lights now, from its spell numbers (number -> key). Kept by
-- number: with two ranks lit, one that goes out leaves the other.
function Model.LitKeys(ids)
    local keys = {}
    for _, key in pairs(ids) do
        keys[key] = true
    end
    return keys
end

-- Which glows a button shows now. on: the rows { proc, kick }. cue: the button's { key, isKick,
-- cooling }; cooling: the interrupt's own cooldown runs, so a press now does nothing and the red
-- glow stays dark. lit: Model.LitKeys. cast: the target's { casting, enemy }. Gives proc, kick.
function Model.Glows(on, cue, lit, cast)
    local proc = on.proc and cue.key ~= nil and lit[cue.key] == true or false
    local kick = on.kick and cue.isKick and not cue.cooling and cast.casting and cast.enemy or false
    return proc, kick
end

-- Are the on-screen buttons out of sight? switches: the rows { mounted, resting }. game: what the
-- game says { mounted (a travel form too), taxi (a flight path), resting }. They come back at once in a fight or with an
-- enemy as the target (busy), while the settings window or a wheel is open (open), and while a
-- thing is in reach (near: Dynamic Interact shows the vendor or the mailbox on its button).
function Model.Hidden(switches, game, busy, open, near)
    if busy or open or near then
        return false
    end
    return switches.mounted and (game.mounted or game.taxi) or switches.resting and game.resting or false
end

if ns then
    ns.HudCueModel = Model
end
return Model
