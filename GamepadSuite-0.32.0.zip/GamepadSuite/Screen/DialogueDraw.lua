-- The frames of the dialogue view: a dark band over the whole width of the screen at its foot,
-- with a soft top edge, and a soft shade at the screen's top. In the band, in a column in the
-- middle of the screen: the NPC's portrait with its name, the NPC's words, and the button hints.
-- The portrait is taller than the band: the NPC's head is over the soft edge, in the clear world.
-- The right side (list, rewards, objectives) is in Screen/DialogueSide.lua, the hints row in
-- Screen/DialogueFoot.lua.
-- Every size is in the units of the sample sheet (mockups/dialogue_sample.py, a screen 900 units
-- high) and goes through Theme.px. Places are from the top left corner of the block: the upper
-- 208 units of the column.
local _, ns = ...

local Theme, Model, Foot = ns.Theme, ns.DialogueModel, ns.DialogueFoot
local px = Theme.px

local Draw = {}
ns.DialogueDraw = Draw

local TONE = { 0.04, 0.035, 0.03 }   -- the band's tone: the well of a picture box
local SHADOW = "Interface\\AddOns\\GamepadSuite\\Art\\HudShadow.tga"
local BAND, BLOCK, FOOT, HINTS = 286, 208, 16, 26   -- the band's height, the block's height, the room under the column, the hints row
local COLUMN, FIT = 1400, 1440       -- the column's width; the width of screen it needs
local FACE_W, FACE_H, PLATE = 256, 384, 36
local WORDS_X, HEAD = 288, 52        -- the words start here; a quest's name and its line take this much
local TEXT, LEAD, SMALL, SMALL_LEAD = Theme.size.talk, 36, Theme.size.name, 30
local MOTION, STAND = { ask = 65, shout = 64, talk = 60 }, 0   -- the NPC's animation for each way a part is said

local ui = {}
local talks, faces = 0, 0
local alpha, alphaTo, onFault = 0, 0, nil   -- the strength of the view now, and where its fade goes

local function tone(strength)
    return CreateColor(TONE[1], TONE[2], TONE[3], strength)
end

-- A piece of the band: the band's tone, from the strength low at its foot to high at its top.
-- (The first color of an upright gradient is the foot: the warm light at the top of the
-- settings window is made the same way, Settings/Frames.lua 44.)
local function slab(parent, low, high)
    local piece = Theme.Fill(parent, "BACKGROUND", 1, 1, 1, 1)
    piece:SetGradient("VERTICAL", tone(low), tone(high))
    return piece
end

local function at(region, x, y)
    region:ClearAllPoints()
    region:SetPoint("TOPLEFT", ui.col, "TOPLEFT", px(x), -px(y))
    return region
end

-- A frame's content comes in over 0.15 seconds: the game runs it, no script of ours does.
local function comesIn(frame)
    local group = frame:CreateAnimationGroup()
    local motion = group:CreateAnimation("Alpha")
    motion:SetFromAlpha(0)
    motion:SetToAlpha(1)
    motion:SetDuration(0.15)
    return group
end

-- The type of a text of more than one line: its size, and the room from line to line.
local function set(text, size, lead)
    text:SetFont(Theme.font.text, px(size), "")
    text:SetSpacing(px(lead - size))
end

-- Makes the view under root, a plain frame of the module. It is no protected frame.
function Draw.Build(root)
    ui.root = root
    root:SetFrameStrata("HIGH")
    root:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT")
    root:SetPoint("BOTTOMRIGHT", UIParent, "BOTTOMRIGHT")
    root:SetHeight(px(BAND + 48))
    local thin = ns.Adapter.DialogueThin(root, px(1))
    -- the band, and three slopes over it that make its top edge soft
    for _, part in ipairs({ { 0, BAND, 0.9, 0.9 }, { BAND, 302, 0.9, 0.7 }, { 302, 318, 0.7, 0.3 }, { 318, 334, 0.3, 0 } }) do
        local piece = slab(root, part[3], part[4])
        piece:SetPoint("BOTTOMLEFT", 0, px(part[1]))
        piece:SetPoint("BOTTOMRIGHT", 0, px(part[1]))
        piece:SetHeight(px(part[2] - part[1]))
    end
    -- the shade at the screen's top: under the minimap and the buffs, and it fades with the band
    local shade = CreateFrame("Frame", nil, root)
    shade:SetFrameStrata("BACKGROUND")
    shade:SetPoint("TOPLEFT", UIParent, "TOPLEFT")
    shade:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT")
    shade:SetHeight(px(64))
    slab(shade, 0, 0.5):SetAllPoints()

    local col = CreateFrame("Frame", nil, root)
    col:SetSize(px(COLUMN), px(BLOCK + 14 + HINTS))
    col:SetPoint("BOTTOM", 0, px(FOOT))
    ui.col = col

    -- the portrait: on the block's foot, and 154 units over the band's top
    local face = CreateFrame("Frame", nil, col)
    face:SetSize(px(FACE_W), px(FACE_H))
    face:SetPoint("BOTTOMLEFT", col, "TOPLEFT", 0, -px(BLOCK))
    local shadow = face:CreateTexture(nil, "BACKGROUND", nil, -2)
    shadow:SetTexture(SHADOW)
    shadow:SetTexCoord(0, 0.5, 0, 1)
    shadow:SetVertexColor(0, 0, 0, 0.55)
    shadow:SetPoint("TOPLEFT", -px(26), px(22))
    shadow:SetPoint("BOTTOMRIGHT", px(26), -px(30))
    -- the thin gold line round it: a plate one line larger, under the ground
    local line = Theme.Fill(face, "BACKGROUND", Theme.Color("goldDeep", 0.6))
    line:SetDrawLayer("BACKGROUND", -1)
    line:SetPoint("TOPLEFT", -thin, thin)
    line:SetPoint("BOTTOMRIGHT", thin, -thin)
    local ground = Theme.Fill(face, "BACKGROUND", 1, 1, 1, 1)
    ground:SetDrawLayer("BACKGROUND", 1)
    ground:SetAllPoints()
    ground:SetGradient("VERTICAL", CreateColor(0.09, 0.075, 0.055, 1), CreateColor(0.23, 0.195, 0.15, 1))
    ui.model = CreateFrame("PlayerModel", nil, face)
    ui.model:SetPoint("TOPLEFT")
    ui.model:SetPoint("TOPRIGHT")
    ui.model:SetHeight(px(FACE_H - PLATE))
    ui.picture = face:CreateTexture(nil, "ARTWORK")
    -- the name plate is a frame above the model: a model draws over the textures of its own frame
    local plate = CreateFrame("Frame", nil, face)
    plate:SetFrameLevel(ui.model:GetFrameLevel() + 2)
    plate:SetPoint("BOTTOMLEFT")
    plate:SetPoint("BOTTOMRIGHT")
    plate:SetHeight(px(PLATE))
    Theme.Fill(plate, "BACKGROUND", TONE[1], TONE[2], TONE[3], 0.82):SetAllPoints()
    local edge = Theme.Fill(plate, "BORDER", Theme.Color("goldDeep", 0.45))
    edge:SetPoint("TOPLEFT")
    edge:SetPoint("TOPRIGHT")
    edge:SetHeight(thin)
    ui.name = Theme.Text(plate, "name", "gold")
    ui.name:SetPoint("CENTER")
    ui.name:SetWidth(px(240))
    ui.name:SetJustifyH("CENTER")

    -- all that is at the right of the portrait: it comes in at a new state of the talk
    local right = CreateFrame("Frame", nil, col)
    right:SetAllPoints()
    ui.right, ui.rightIn = right, comesIn(right)
    ui.title = at(Theme.Text(right, "talk", "gold", true), WORDS_X, 0)
    ui.rule = at(Theme.Fill(right, "ARTWORK", 1, 1, 1, 1), WORDS_X, 42)
    ui.rule:SetHeight(thin)
    ui.rule:SetGradient("HORIZONTAL", CreateColor(Theme.Color("gold", 0.7)), CreateColor(Theme.Color("gold", 0)))
    -- the words: they come in at a new part of the text
    local say = CreateFrame("Frame", nil, right)
    say:SetAllPoints()
    ui.sayIn = comesIn(say)
    ui.label = Theme.Text(say, "body", "muted")
    ui.label:SetText("Objectives")
    -- the suggested group size of an offer, beside the label, in the game's own words
    ui.group = Theme.Text(say, "body", "muted")
    ui.group:SetPoint("LEFT", ui.label, "RIGHT", px(24), 0)
    ui.words = Theme.Text(say, TEXT, "cream")
    ui.words:SetWordWrap(true)
    ui.words:SetJustifyV("TOP")
    -- a text that is never seen, in the type of the words: it counts the lines of a text
    ui.measure = at(Theme.Text(say, TEXT, "cream"), WORDS_X, 0)
    ui.measure:SetWordWrap(true)
    ui.measure:SetAlpha(0)
    -- the place of a reward's tooltip: its bottom right corner, 10 units over the band's top
    local corner = CreateFrame("Frame", nil, col)
    corner:SetSize(1, 1)
    corner:SetPoint("BOTTOMRIGHT", col, "BOTTOMRIGHT", 0, px(BAND + 10 - FOOT))
    ns.DialogueSide.Build(right, at, thin, corner)
    Foot.Build(right, col, WORDS_X)
end

-- The lines a text takes at a width, in the type of the words (or in the type of size). The
-- game counts them. Its count is not believed when it is no number, when it is 0 for a text,
-- and when it is 1 for a text that is wider than the line or has a line break in it: then the
-- lines are counted by the letters, so a long text is still cut into parts.
function Draw.Lines(width, text, size)
    local measure = ui.measure
    set(measure, size or TEXT, size and SMALL_LEAD or LEAD)
    measure:SetWidth(px(width))
    measure:SetText(text)
    local lines = measure:GetNumLines()
    local one = lines == 1 and (text:find("\n", 1, true) ~= nil
        or (measure.GetUnboundedStringWidth and measure:GetUnboundedStringWidth() or 0) > px(width))
    if type(lines) ~= "number" or (lines < 1 and text ~= "") or one then
        lines = 0
        for line in text:gmatch("[^\n]+") do
            lines = lines + math.ceil(#line * (size or TEXT) * 0.5 / width)
        end
    end
    return lines
end

-- The size of the view: the row Dialogue Size, and less on a screen too narrow for the column.
function Draw.Scale(percent)
    ui.root:SetScale(math.min(percent / 100, UIParent:GetWidth() * 900 / 768 / FIT))
end

-- The view comes in 0.2 seconds (to: 1) or goes in 0.15 (to: 0). The script runs on each frame
-- only during that time. A model does not follow its frame by itself, so it is told. A fault
-- stops the script, the view goes, and fault(why) is told.
local function strength()
    ui.root:SetAlpha(alpha)
    pcall(ui.model.SetModelAlpha, ui.model, alpha)
end

local function fading(root, elapsed)
    local by = elapsed / (alphaTo > alpha and 0.2 or 0.15)
    alpha = alphaTo > alpha and math.min(alphaTo, alpha + by) or math.max(alphaTo, alpha - by)
    local ok = ns.Call("Dialogue", strength)
    if not ok or alpha == alphaTo then
        root:SetScript("OnUpdate", nil)
        root:SetShown(ok and alpha > 0)
    end
    if not ok then
        onFault("a fault while the view faded")
    end
end

function Draw.Fade(to, fault)
    alphaTo, onFault = to, fault
    ui.root:SetScript("OnUpdate", alpha ~= to and fading or nil)
end

-- The view goes at once, with no fade (a fight starts).
function Draw.Gone()
    alpha, alphaTo = 0, 0
    ui.root:SetScript("OnUpdate", nil)
    strength()
    ui.root:Hide()
end

-- What the portrait shows: the model frame for a model (and while the game is asked again for
-- one), else the picture, at its size.
local function shown(kind)
    ui.model:SetShown(kind == "model" or kind == "wait")
    ui.picture:SetShown(kind == "picture" or kind == "book")
    ui.picture:ClearAllPoints()
    if kind == "book" then
        ui.picture:SetSize(px(96), px(96))
        ui.picture:SetPoint("CENTER", ui.model, "CENTER")
    else
        -- the game's flat picture is small: it is not drawn over the whole frame
        ui.picture:SetSize(px(192), px(192))
        ui.picture:SetPoint("TOP", ui.model, "TOP", 0, -px(32))
    end
end

-- Puts the speaker into the portrait: the unit's 3D model, or its flat picture, or the game's
-- book picture with the quest's name for a quest that has no NPC. When the game has no model's
-- file at once, it is asked again one frame later, and only then the flat picture shows.
-- Returns what shows and a few words for the log; log(text) tells of the second look.
function Draw.Face(unit, title, log)
    faces = faces + 1
    local mine = faces
    local kind, note = ns.Adapter.DialogueFace(ui.model, ui.picture, unit)
    shown(kind)
    if kind == "wait" then
        C_Timer.After(0, function()
            if mine == faces then
                local late, words = ns.Adapter.DialogueFace(ui.model, ui.picture, unit, true)
                shown(late)
                log("one frame later the portrait shows the " .. late .. " of " .. tostring(unit) .. " (" .. tostring(words) .. ")")
            end
        end)
    end
    -- one line: a long name in smaller type, and a longer one is cut by the game
    local name = ui.name
    name:SetFont(Theme.font.text, px(Theme.size.name), "")
    name:SetText(kind ~= "book" and ns.Adapter.DialogueName(unit) or title or "")
    if (name.GetUnboundedStringWidth and name:GetUnboundedStringWidth() or name:GetStringWidth() or 0) > px(236) then
        name:SetFont(Theme.font.text, px(Theme.size.body), "")
    end
    return kind, note
end

-- The model has changed (the game says so), or the screen has: the portrait is set up again.
function Draw.FaceAgain()
    pcall(function()
        ui.model:RefreshUnit()
        ui.model:RefreshCamera()
    end)
end

-- The NPC says a part for two seconds, when its model can: it asks at a question mark, calls
-- out at an exclamation mark, else talks. At an emote (tone "emote") it stands.
local function talk(tone)
    local model, motion = ui.model, MOTION[tone]
    talks = talks + 1
    local mine = talks
    if not motion then
        pcall(model.SetAnimation, model, STAND)
    elseif model:IsShown() and pcall(function()
        assert(model:HasAnimation(motion))
        model:SetAnimation(motion)
    end) then
        C_Timer.After(2, function()
            if mine == talks then
                pcall(model.SetAnimation, model, STAND)
            end
        end)
    end
end

-- Draws the part of the text in view (state: Model.Open, view: Model.View): the quest's name
-- and its thin line, the words or the objectives, and the place in the text. how: "state" for a
-- new window of the talk (all at the right of the portrait comes in), "part" for another part
-- of the text (the words come in), nil for the same part again. An emote is in muted words.
-- Words that the game cuts off get the small type; a line for the log is returned when even
-- the small type is cut off.
function Draw.Part(state, view, how)
    local quest = state.kind ~= "gossip"
    ui.title:SetShown(quest)
    ui.rule:SetShown(quest)
    ui.title:SetWidth(px(view.width))
    ui.title:SetText(view.title or "")
    ui.rule:SetWidth(px(view.width))

    local top = quest and HEAD or 0
    local words, size, most = view.words, TEXT, quest and Model.READ_LINES or Model.TALK_LINES
    local tone, cut = words and Model.Tone(words) or "talk", nil
    ui.label:SetShown(view.objectives or false)
    ui.group:SetShown(view.objectives and state.data.group ~= nil or false)
    ui.group:SetText(state.data.group or "")
    -- (in a group Auto Quest leaves such an offer for A: the line says why it waits)
    ui.group:SetTextColor(Theme.Color(state.data.party and "gold" or "muted"))
    if view.objectives then
        -- up to three lines in the large type; a longer text in smaller type, up to four lines
        at(ui.label, WORDS_X, top)
        words, top, most = state.data.objectives or "", top + 24, 3
        if Draw.Lines(view.width, words) > 3 then
            size, most = SMALL, 4
        end
    elseif view.ask then
        words = state.data.ask or ""
    end
    ui.words:SetShown(words ~= nil)
    if words then
        set(ui.words, size, size == TEXT and LEAD or SMALL_LEAD)
        at(ui.words, WORDS_X, top)
        ui.words:SetWidth(px(view.width))
        ui.words:SetMaxLines(most)
        ui.words:SetText(words)
        ui.words:SetTextColor(Theme.Color(tone == "emote" and "muted" or "cream"))
        if ns.Adapter.DialogueCut(ui.words) then
            ui.words:SetMaxLines(math.floor(most * (size == TEXT and LEAD or SMALL_LEAD) / SMALL_LEAD))
            set(ui.words, SMALL, SMALL_LEAD)
            ui.words:SetText(words)
            cut = ns.Adapter.DialogueCut(ui.words) and "part " .. state.part .. " of " .. state.count .. " is cut off in the small type" or nil
        end
    end
    Foot.Place(state, view.more)

    local group = how == "state" and ui.rightIn or how == "part" and ui.sayIn
    if group then
        group:Stop()
        group:Play()
        talk(tone)
    end
    return cut
end

-- The view goes: what moves by itself stops.
function Draw.Rest()
    Foot.Rest()
    talks, faces = talks + 1, faces + 1
    ns.Adapter.DialogueTipHide()
end
