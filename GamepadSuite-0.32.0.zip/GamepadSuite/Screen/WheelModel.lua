-- The rules of a wheel's two stick frames, with no game calls (Screen/Wheel.lua has the frames).
-- While a wheel is open the right stick chooses an entry and must not turn the camera, and the
-- left stick must still walk.
-- On this game a frame of an addon that takes the sticks takes every stick: what its script
-- gives back hands no stick on. (Build 0.15.0 gave "true" for the walking stick 232 times in one
-- wheel, and the character stood still.) A frame hands the sticks on only with the game's own
-- switch for that, and the switch cannot be changed in a fight. So there are two frames:
--   the ear has the switch on: it hears every stick and every stick goes on to the game;
--   the wall has it off: it takes every stick it is told of, and is up only for a moment.
-- What the game tells the frames in one frame of the screen, as ConsolePort's notes say
-- (ConsolePort/Controller/Radial.lua 33 to 37): first each stick that moved, by its own name
-- (Left, Right, Gyro), then the stick of each that the game acts on (Movement for Left, Camera
-- for Right, Look for Gyro). So a stick's own name says which of those two is still to come in
-- this frame of the screen. The wall is up while the camera's stick is to come and the walking
-- stick is not: it takes the camera's stick, and the walking stick passes before or after.
-- On this game a wall that goes up at the walking stick came too late for the camera's stick of
-- the same frame (the owner's log of 0.23.0: "Left > Right > Movement > Camera", 8 passed, 0
-- taken). There the left stick was only touched: the game did not walk. So the wall waits only
-- for a walking stick that the game acts on (see Stick).
local _, ns = ...

local Model = {}

-- A left stick that is pushed less than this (the square of a fifth of its way) does not walk:
-- a stick at rest is never at its exact middle, and the wall does not wait for it.
Model.PUSHED = 0.04

-- One stick told to a frame. s is what the frames remember while a wheel is open:
--   { kept = 0, leaked = 0, walked = 0, stolen = 0 }
-- name is the stick, onWall is true when the wall was told (it is up), now is the game's time
-- (it stays the same for one frame of the screen), gameplay is false while a window has the
-- controller (the sticks are that window's then, and the wall stays down), far is the square of
-- the stick's push.
-- Gives true when the wall must be up for the next stick, false when it must be down.
-- It counts for the log: kept (the wall took the camera's stick), leaked (the camera's stick
-- passed the ear: the camera turned), walked (the walking stick passed the ear), stolen (the
-- wall took the walking stick).
function Model.Stick(s, name, onWall, now, gameplay, far)
    if now ~= s.tick then
        s.tick, s.camera, s.walk, s.left = now, false, false, nil
    end
    far = far or 1
    local pushed = far > Model.PUSHED
    if name == "Right" then
        s.camera = gameplay and true or false
    elseif name == "Left" then
        -- The walking stick's words must reach the game while the character walks, and one time
        -- more when it is let go: a wall that took that last word would leave the character walking.
        -- The game's own word (Movement) tells if it walks. A push that the game turned into no walk
        -- before ("dead": a thumb that rests on the stick, drift) does not make the wall wait.
        s.walk, s.left = s.moving or far > (s.dead or Model.PUSHED), far
    elseif name == "Camera" then
        local count = onWall and "kept" or "leaked"
        s[count] = s[count] + (gameplay and 1 or 0)
        s.camera = false
    elseif name == "Movement" then
        local count = onWall and "stolen" or "walked"
        s[count] = s[count] + (pushed and 1 or 0)
        s.walk, s.moving = false, pushed
        if not pushed and (s.left or 0) > (s.dead or Model.PUSHED) then
            s.dead = s.left
        end
    end
    return s.camera and not s.walk
end

-- True when the camera's stick passed the ear more often than the wall took it while one wheel
-- was open: on such a game the two frames cannot keep the camera still.
function Model.TooLate(s)
    return s.leaked >= 8 and s.leaked > s.kept
end

-- The rumble tick when the stick points at another entry: one pulse of TICK seconds. A sweep over the
-- ring changes the entry many times in a moment; a change less than GAP seconds after the last tick
-- has no tick of its own (it is felt in that one). last is when the last tick played, or nil.
-- TICK is the one tick length of the suite (RangeModel.TICK is the same): the shortest pulse the
-- suite plays already (each pulse of a whisper, Auto/RumbleModel.lua), shorter than GAP so that
-- the next tick of a sweep is never left out as busy, and lighter than every event's pattern.
Model.TICK, Model.GAP = 0.06, 0.12
function Model.Tick(last, now)
    return not last or now - last >= Model.GAP
end

-- The entry of the ring that the restricted code's pick sel is (Core/BindWheelUse.lua "wsel": the one a let-go uses).
-- picks is the list it counts in (the open wheel's entries; in a raid the chosen radial's, while the ring draws every
-- radial), entries the ring's. nil for no pick, a pick past the list, and a blank place of a raid's radial (no member).
function Model.Marked(entries, picks, sel)
    local entry = sel and picks[sel]
    for i, drawn in ipairs(entry and not entry.blank and entries or {}) do
        if drawn == entry then
            return i
        end
    end
    return nil
end

-- ---- where each wheel opens (Screen/WheelPlace.lua keeps the places and the page Wheel Position)
-- All Wheels is the place of every wheel that has no place of its own; the Healer Wheel is the one place of the party
-- wheel of every spell and item of healer mode.
Model.ALL, Model.HEAL = "All Wheels", "Healer Wheel"

-- The place of a wheel: "heal" for every party wheel ("heal774", "healitem1251", a raid group's "heal774:3"), else the
-- wheel's own id.
function Model.PlaceKey(id)
    return tostring(id):match("^heal%a*%d+:?%d*$") and "heal" or id
end

-- The choices of Wheel to Change and the place each one changes: All Wheels, the wheels of every character, the Healer
-- Wheel while healer mode is on, then the player's own wheels. wheels: { { id, name } } in the order of the bind list.
-- A second wheel of one name gets its number after the name, so that each choice is a wheel of its own.
function Model.Places(wheels, healer)
    local names, keys = {}, {}
    local function add(name, key)
        name = keys[name] and name .. " (" .. (tostring(key):match("%d+") or key) .. ")" or name
        names[#names + 1], keys[name] = name, key
    end
    add(Model.ALL, "all")
    for _, own in ipairs({ false, true }) do
        if own and healer then
            add(Model.HEAL, "heal")
        end
        for _, wheel in ipairs(wheels) do
            if (tostring(wheel.id):match("^my") ~= nil) == own then
                add(wheel.name, wheel.id)
            end
        end
    end
    return names, keys
end

-- How far a position row reaches from the middle of the screen, in steps of ten: to the edge, less margin. wide and
-- high are the screen in the units of a place (Core/AdapterWheel.lua ScreenUnits); at least one step.
function Model.Reach(wide, high, margin)
    local function edge(half)
        return math.max(10, math.floor((half - margin) / 10) * 10)
    end
    return edge(wide / 2), edge(high / 2)
end

if ns then
    ns.WheelModel = Model
end
return Model
