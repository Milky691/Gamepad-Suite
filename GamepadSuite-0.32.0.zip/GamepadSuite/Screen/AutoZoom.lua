-- Auto Camera Zoom: a controller has no scroll wheel, so the camera zooms by itself. It moves out
-- by a step when a fight starts or the player gets on a mount (or takes a travel form), out by two
-- steps on a flight path, and in by a step at a window of an NPC (a talk, a quest, a vendor, a
-- trainer, the bank) or indoors. When the situation ends it comes back to where the player had
-- it. The row Auto Camera Zoom says how far: Low 3 yards, Full 6 yards, Off not at all
-- (Screen/AutoZoomModel.lua). Three rows turn off the mount, the flight path and indoors alone.
--
-- When two hold at once the camera follows the one of the highest rank: a flight path, then a
-- fight or an NPC (one rank: the one that came first keeps the camera), then indoors, then a
-- mount. Every distance is counted from the player's own, so a fight on a mount or an NPC indoors
-- moves nothing more. When the stronger one ends, the camera goes to the distance of the one that
-- still holds; when none holds, it comes back.
--
-- A move is one zoom call, as one turn of the mouse wheel is (Blizzard_FrameXML/Bindings_Camelot.xml
-- 1426): the game moves the camera there smoothly, at its own zoom speed. (Small calls, one each
-- frame, lost a tenth of each move in the owner's log of 0.21.0: the camera came back nearer each
-- time, 15.0 yards to 10.4 in eight talks.) A second after the way back the camera is at rest:
-- where it missed the player's distance, one more call sets it right, as DynamicCam's LibCamera
-- does after a move (LibCamera.lua 291 to 297).
-- ponytail: a move that starts while the last one is still on its way starts from where the camera
-- is then, so it can stop short; the way back is set right a second later. Keep the asked distance
-- for a second if the owner's log shows it.
--
-- A camera at the player's farthest cannot go out. So for the time of an out move the game's
-- setting for how far the camera may go is held at the top of its slider (Core/AdapterZoom.lua
-- CameraRoom), and given back once the camera is back.
--
-- The player's hand always wins. A zoom by hand (the stick zoom, the mouse wheel, a zoom bind,
-- the game's own LB + RB zoom) makes the camera the player's: no end brings it back, and a change
-- down to a weaker situation moves nothing. The next start (a situation after none, or one of a
-- higher rank) takes it again, from where the player has it then. The addon knows of such a zoom
-- because it watches the game's zoom calls (Core/AdapterZoom.lua).
--
-- It never works against the player. No move while the settings window is open, while mouse mode
-- is on, or while the camera is in first person. A situation that holds at login (a reload on a
-- mount) moves nothing: the camera may be out for it already.
--
-- No script runs each frame. The game's messages say when a mount, a flight path or indoors can
-- have changed (Core/AdapterZoom.lua OnSituation); a burst of them is read once, a frame later.
-- Indoors must hold a second before the camera moves in (Model.INDOORS): a door or a cave mouth
-- flips it within a second. A fight, a mount and a flight path start at once.
-- The log (kind "autozoom") has one line at login, one for each time the camera is taken (where it
-- was, each situation it went through, where it was at the end and a second after the way back),
-- and once in a session for each start and end of a situation, the messages that told of it.
local _, ns = ...

local Auto = ns.Module("AutoZoom", { "cameraZoom", "cameraRead" }, "Auto Camera Zoom")
ns.AutoZoom = Auto

local Model = ns.AutoZoomModel

local WHAT = { fight = "a fight", npc = "an NPC's window", mount = "a mount", taxi = "a flight path", indoors = "indoors" }
local MAX_NOTES = 12    -- lines for the log in one session
local LONGEST = 300     -- letters of one line for the log: a long time indoors with many fights stops adding to it

local holds = {}        -- the situations that hold now: kind -> true
local seen = {}         -- what the game said of a mount, a flight path and indoors at the last read (rows aside)
local top               -- the situation the camera follows; nil when none holds
local home              -- the camera's distance as the player had it, while the addon may bring it back; nil when the camera is the player's
local line              -- the log's line for this time, as far as it is known
local open = {}         -- the windows of an NPC that are open, by their kind
local denied = {}       -- [true]: the game refused the zoom call in a fight; [false]: out of a fight
local heard             -- the game's messages since the last read, for the log
local waiting = false   -- a read waits for the next frame
local settling          -- the number of the step indoors whose second runs now; nil when none waits
local steps = 0         -- the steps indoors so far: an older wait knows it is not the last
local notes, told = 0, {}

-- A line for the log. A line with a name (once) is written one time in a session; of the other
-- lines the log gets twelve.
local function note(text, once)
    if once and told[once] or not once and notes >= MAX_NOTES then
        return
    end
    if once then
        told[once] = true
    else
        notes = notes + 1
    end
    ns.Log.Add("autozoom", text)
end

local function refusal(distance)
    return Model.Refusal(distance, ns.Settings and ns.Settings.IsOpen(), ns.Pointer and ns.Pointer.IsOn())
end

-- A situation's row is on (a row that is not in the settings yet has its start value, On).
local function on(kind)
    local key = Model.ROW[kind]
    return not ns.Registry.Has(key) or ns.Registry.Get(key) ~= false
end

-- One move of that many yards (above 0 is in). False when the game refused the call. (The move
-- out for a fight is made when the game tells of the fight, a moment before the fight is on.)
local function zoom(yards)
    local fight = top == "fight" or ns.Adapter.InCombat()
    local done, err = ns.Adapter.CameraZoom(yards, true)
    if not done then
        denied[fight] = true
        note("the game refused the zoom call " .. (fight and "in a fight" or "out of a fight") .. " (" .. tostring(err) .. "): the camera is left alone there")
    end
    return done
end

-- A second after the way back: the camera is at rest. A miss of the player's distance is set right
-- with one call, then the line goes in the log. The camera is the player's from here.
local function settle()
    if top then
        -- a new start in that second: it brings the camera back to the same distance
        return
    end
    if home then
        local distance = ns.Adapter.CameraDistance()
        local miss = not refusal(distance) and Model.Miss(distance, home)
        line = line .. string.format(", %s a second after the way back", ns.Adapter.ZoomText())
        if miss and zoom(miss) then
            line = line .. string.format(", set right by %+.1f", miss)
        end
        note(line)
    end
    home = nil
    ns.Adapter.CameraRoom(false)
end

-- The camera goes to the distance of the situation kind: at a start (old is nil, or weaker), or,
-- while the camera is the addon's, when a stronger one (old) has ended.
local function go(kind, old)
    local level = ns.Registry.Get("feel.camera")
    if not home and not Model.STEP[level] or denied[kind == "fight" or ns.Adapter.InCombat()] then
        return
    end
    local distance = ns.Adapter.CameraDistance()
    local stop = not distance and "the game does not tell the camera's distance" or refusal(distance)
    if stop and home then
        note(line .. ", then " .. WHAT[kind] .. "; it was left there: " .. stop)
        home = nil
        return
    elseif stop then
        note(WHAT[kind] .. ": the camera was left alone: " .. stop, stop)
        return
    end
    if old and home then
        line = #line < LONGEST and line .. ", then " .. WHAT[kind] or line
    else
        -- (a start in the second after a way back: the distance the player had is the same)
        home = home or distance
        line = string.format("%s, %s: the camera was %.1f yards away", WHAT[kind], level, home)
    end
    if Model.OUT[kind] then
        ns.Adapter.CameraRoom(true)
    end
    if not zoom(Model.Yards(distance, Model.Goal(kind, level, home))) then
        home = nil
    end
end

-- No situation holds any more: the camera goes back.
local function back()
    local distance = home and ns.Adapter.CameraDistance()
    local stop = home and (not distance and "the game does not tell the camera's distance" or refusal(distance))
    if stop then
        note(line .. "; it was not brought back: " .. stop)
        home = nil
    elseif home then
        line = line .. string.format(", %.1f at the end", distance)
        if zoom(Model.Yards(distance, home)) then
            C_Timer.After(Model.SETTLE, function()
                ns.Call("AutoZoom", settle)
            end)
            return
        end
        home = nil
    end
    -- the player zoomed by hand since the start, or the camera stays: it is the player's
    ns.Adapter.CameraRoom(false)
end

-- The camera follows the situation of the highest rank (Model.Top). A change down while the camera
-- is the player's moves nothing.
local function follow()
    local new = Model.Top(holds, top)
    if new == top then
        return
    end
    local old = top
    top = new
    if not new then
        back()
    elseif home or Model.Rises(old, new) then
        go(new, old)
    end
end

-- Indoors counts only when it has held Model.INDOORS seconds, as an NPC's window waits (Model.WAIT):
-- at a cave mouth the game flips indoors and out several times in a second. A step in starts one
-- wait; a step out within it ends it, and nothing moves. At login it counts at once (it moves nothing).
local function inside(now, silent)
    if now and on("indoors") and not holds.indoors and not silent then
        if not settling then
            steps = steps + 1
            local step = steps
            settling = step
            C_Timer.After(Model.INDOORS, function()
                ns.Call("AutoZoom", function()
                    if settling == step then
                        settling = nil
                        holds.indoors = seen.indoors and on("indoors") or nil
                        follow()
                    end
                end)
            end)
        end
        return
    end
    if settling and not now then
        note("indoors flipped back within the settle: no move", "flip")
    end
    settling = nil
    holds.indoors = now and on("indoors") or nil
end

-- What the game says of a mount (or a travel form), a flight path and indoors, with the rows.
-- silent: at login, nothing goes in the log.
local function read(silent)
    local mounted, form, taxi, indoors = ns.Adapter.Situation()
    for kind, now in pairs({ mount = mounted or Model.TRAVEL[form] or false, taxi = taxi, indoors = indoors }) do
        if now ~= (seen[kind] or false) and not silent then
            note(string.format("the game told of %s (%s) with %s", WHAT[kind], now and "on" or "off", tostring(heard)), "told " .. kind .. tostring(now))
        end
        seen[kind] = now
        if kind == "indoors" then
            inside(now, silent)
        else
            holds[kind] = now and on(kind) or nil
        end
    end
    heard = nil
end

local function hear(event)
    if not heard then
        heard = event
    elseif not (", " .. heard .. ","):find(", " .. event .. ",", 1, true) then
        heard = heard .. ", " .. event
    end
end

local function look()
    waiting = false
    read()
    follow()
end

-- A message of the game for a mount, a flight path or indoors. A burst of them (a door gives three
-- or four) is read once, a frame later. SPELL_UPDATE_USABLE comes often in a fight: it is not
-- heard there, and the fight's end reads all again.
local function message(event)
    if event == "SPELL_UPDATE_USABLE" and holds.fight then
        return
    end
    hear(event)
    if not waiting then
        waiting = true
        C_Timer.After(0, function()
            ns.Call("AutoZoom", look)
        end)
    end
end

-- The player zoomed by hand. (This is told at every zoom call of the stick: it must cost nothing
-- while the camera is the player's.)
local function hand()
    if home then
        note(line .. "; then the player zoomed by hand: the camera stays where the player puts it")
        home = nil
    end
end

-- A window of an NPC opened or closed. A talk that goes on to a quest or a vendor closes one
-- window and opens the next: when the NPC is what the camera follows, it waits for it.
local function window(kind, shown)
    open[kind] = shown or nil
    if shown then
        holds.npc = true
        follow()
    elseif holds.npc and not next(open) then
        local function close()
            if not next(open) then
                holds.npc = nil
                follow()
            end
        end
        if top == "npc" then
            C_Timer.After(Model.WAIT, function()
                ns.Call("AutoZoom", close)
            end)
        else
            close()
        end
    end
end

function Auto.OnLogin()
    -- the game tells of a fight before it locks anything
    ns.On("PLAYER_REGEN_DISABLED", "AutoZoom", function()
        holds.fight = true
        follow()
    end)
    ns.On("PLAYER_REGEN_ENABLED", "AutoZoom", function()
        holds.fight = nil
        hear("PLAYER_REGEN_ENABLED")
        read()
        follow()
    end)
    local windows = ns.Adapter.OnNpcWindow("AutoZoom", window)
    local messages = ns.Adapter.OnSituation("AutoZoom", message)
    ns.Adapter.OnHandZoom(function()
        ns.Call("AutoZoom", hand)
    end)
    -- a situation that holds now moves nothing, and its end brings nothing back
    read(true)
    top = Model.Top(holds)
    local rows = {}
    for i, kind in ipairs({ "mount", "taxi", "indoors" }) do
        rows[i] = on(kind) and "on" or "off"
    end
    note("at login: Auto Camera Zoom is " .. tostring(ns.Registry.Get("feel.camera")) .. "; the camera is " .. ns.Adapter.ZoomText()
        .. " yards away; " .. windows .. " of the game's messages for an NPC's window are heard; a mount, a flight path, indoors: "
        .. table.concat(rows, ", ") .. "; " .. messages .. " of the game's messages for them are heard; holding now, left as it is: "
        .. (top and WHAT[top] or "none"))
end
