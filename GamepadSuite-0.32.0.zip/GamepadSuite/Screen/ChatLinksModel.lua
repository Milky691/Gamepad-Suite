-- The rules of Last Link, with no game calls: which links of a chat line are kept, the words for who sent one, the
-- list of the newest five, and where a press goes. Screen/ChatLinks.lua uses them.
local _, ns = ...

local Model = {}

Model.MAX = 5            -- links kept
Model.SECONDS = 15       -- the tooltip closes by itself after this long with no press (Screen/ChatLinks.lua says why)
Model.LOOT_QUALITY = 2   -- from loot lines only items of this quality (Uncommon, green) or better
Model.COUNT = "%d of %d"
-- The suite's one hold (Screen/RollsModel.lua): a let-go under HOLD seconds steps, one between HOLD and LIMIT whispers
-- the sender, a longer one does nothing.
Model.HOLD, Model.LIMIT = 1, 2.5
-- The line under the sender for a quest link (17 item 9).
Model.STATE = { on = "You are on this quest", done = "Done before", no = "Not on it" }
Model.EMPTY = "Last Link has no chat link to show yet."
Model.HIDDEN = " In a dungeon or raid the game hides party and raid chat from addons. Loot links still count."

-- The link kinds the game's own link window shows as a tooltip (Blizzard_UIPanels_Game/Mainline/ItemRef.lua 15 to 27:
-- the kinds no handler takes go to SetHyperlink). Every other kind opens a menu or a window, not a tooltip.
Model.KINDS = { item = true, quest = true, spell = true, enchant = true, talent = true, achievement = true, currency = true,
    instancelock = true }

-- The chat events heard, and the word for each. "from" and "to" are whispers; "Loot" lines have no sender.
Model.EVENTS = {
    CHAT_MSG_SAY = "Say", CHAT_MSG_YELL = "Yell", CHAT_MSG_EMOTE = "Emote",
    CHAT_MSG_PARTY = "Party", CHAT_MSG_PARTY_LEADER = "Party", CHAT_MSG_RAID = "Raid", CHAT_MSG_RAID_LEADER = "Raid",
    CHAT_MSG_RAID_WARNING = "Raid Warning", CHAT_MSG_INSTANCE_CHAT = "Instance", CHAT_MSG_INSTANCE_CHAT_LEADER = "Instance",
    CHAT_MSG_GUILD = "Guild", CHAT_MSG_OFFICER = "Officer",
    CHAT_MSG_WHISPER = "from", CHAT_MSG_BN_WHISPER = "from", CHAT_MSG_WHISPER_INFORM = "to", CHAT_MSG_BN_WHISPER_INFORM = "to",
    CHAT_MSG_CHANNEL = "Channel", CHAT_MSG_COMMUNITIES_CHANNEL = "Community", CHAT_MSG_LOOT = "Loot",
}

-- The links of a text that show a tooltip, in reading order, each one time, five at most: { link, text, kind }. link
-- is what the game's tooltip takes ("item:19019::..."), text the whole link with its colour, as chat shows it.
function Model.Links(text)
    local out, seen, at = {}, {}, 1
    while #out < Model.MAX do
        local first, last, data = text:find("|H(.-)|h.-|h", at)
        if not first then
            break
        end
        at = last + 1
        local kind = data:match("^([^:]+)")
        if Model.KINDS[kind] and not seen[data] then
            seen[data] = true
            -- the colour in front: "|cffa335ee", or the game's named one "|cnIQ4:"
            local before = text:sub(1, first - 1)
            local colour = before:match("|c%x%x%x%x%x%x%x%x$") or before:match("|cn[%w_]+:$")
            out[#out + 1] = { link = data, kind = kind, text = (colour or "") .. text:sub(first, last) .. (colour and "|r" or "") }
        end
    end
    return out
end

-- Who sent a line, in words. name: the sender's short name, or nil when the game hid it; you: the player's own name;
-- channel: a channel's own name.
function Model.From(event, name, you, channel)
    local word = Model.EVENTS[event]
    if word == "Loot" then
        return word
    end
    local who = name ~= nil and name ~= "" and (name == you and "You" or name) or nil
    if word == "from" or word == "to" then
        return "Whisper" .. (who and " " .. word .. " " .. who or "")
    end
    word = event == "CHAT_MSG_CHANNEL" and channel ~= nil and channel ~= "" and channel or word
    return who and who .. " in " .. word or word
end

-- The links of one chat line to keep, with who sent it ("from"). From a loot line only items of Uncommon quality or
-- better: a group's cloth and junk would push the linked item out at once. quality(text) gives an item's quality,
-- or nil while the game does not know the item yet: that one is kept.
function Model.Read(event, text, name, you, channel, quality)
    local links = Model.Links(text)
    for i = #links, 1, -1 do
        local grade = event == "CHAT_MSG_LOOT" and links[i].kind == "item" and quality(links[i].text)
        if grade and grade < Model.LOOT_QUALITY then
            table.remove(links, i)
        end
    end
    local from, who = Model.From(event, name, you, channel), Model.Who(event, name, you)
    for _, one in ipairs(links) do
        one.from, one.who = from, who
    end
    return links
end

-- The name a hold of the bind whispers, or nil: none for a loot line, a Battle.net whisper (no name to type), the
-- player's own line, or a whisper the player sent ("to Bob" is the player's line); never a name with a "|" in it.
function Model.Who(event, name, you)
    local word = Model.EVENTS[event]
    if word == "Loot" or word == "to" or event:find("_BN_", 1, true) or type(name) ~= "string" or name == "" or name == you
        or name:find("|", 1, true) then
        return nil
    end
    return name
end

-- The quest's number in a quest link ("quest:176:10"), or nil for any other link.
function Model.QuestID(link)
    return tonumber((link or ""):match("^quest:(%d+)"))
end

-- A let-go of the bind after a press of seconds while the tooltip showed: "step" (to an older link, or close on the
-- oldest), "whisper", or nil (held too long: nothing).
function Model.Let(seconds)
    return seconds < Model.HOLD and "step" or seconds <= Model.LIMIT and "whisper" or nil
end

-- The list after a line's links: they come first, in their order; a link that was there already moves up with its new
-- sender; the newest five stay.
function Model.Add(list, links)
    local out, again = {}, {}
    for _, one in ipairs(links) do
        out[#out + 1], again[one.link] = one, true
    end
    for _, old in ipairs(list) do
        if not again[old.link] and #out < Model.MAX then
            out[#out + 1] = old
        end
    end
    return out
end

-- The place to show after a press: the newest (1) when nothing shows, then the next older one; nil past the oldest
-- (it closes) and when there is none.
function Model.Next(place, count)
    if not place then
        return count > 0 and 1 or nil
    end
    return place < count and place + 1 or nil
end

-- The strip of button hints: the bind's own buttons (keys, nil when they are not known) step to an older link, or
-- close on the oldest; held, they whisper the sender (who), dim in a fight (the chat keyboard opens after it); B
-- closes while it is a key of ours (not twice on the oldest).
function Model.Hints(keys, place, count, onB, who, fight)
    local list, last = {}, place >= count
    if keys then
        list[1] = { keys = keys, text = last and "Close" or "Older" }
        if who then
            list[2] = { keys = keys, text = fight and "Whisper after combat" or "Hold: whisper " .. who, off = fight or nil }
        end
    end
    if onB and not (last and keys) then
        list[#list + 1] = { keys = { "B" }, text = "Close" }
    end
    return list
end

if ns then
    ns.ChatLinksModel = Model
end
return Model
