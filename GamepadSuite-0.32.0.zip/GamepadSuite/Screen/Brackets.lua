-- Target brackets: two plain brackets hang from the nameplate of the target. They are yellow
-- while it is the target and red while the player attacks it. Each bracket is three plain lines
-- with a dark twin behind them, so it reads on bright ground; no art file is used. The shape is
-- the approved sample (mockups/brackets_sample.py). A target with no nameplate shows no brackets:
-- an addon cannot know where a character stands on screen in any other way.
--
-- The brackets hang on the nameplate itself, so the game moves them with it. The addon acts only
-- when the game tells of the target, of the target's own nameplate, or of an attack. The lines
-- are placed again only for a new size, and colored again only for a new color: the nameplates
-- of other units come and go all the time when the camera turns, and cost nothing here.
local _, ns = ...

local Brackets = ns.Module("Brackets", { "plates" }, "Show Brackets")
ns.Brackets = Brackets

-- yellow while it is the target; red (the Theme's) while the player attacks it
local YELLOW = { 1, 0.85, 0.2 }
-- At 100% a bracket is 110 high and a fifth of that wide; its inner edge stands 42 from the middle.
local HEIGHT, GAP = 110, 42

local holder
local sides = {}
local melee, ranged = false, false
local hasTarget = false     -- there is a target, as of the game's last word on it
local drawn = {}            -- what the brackets are now: scale, color, plate
local told = {}             -- the log lines written: "out of combat", "in combat"

-- One bracket: lines 1 to 3 are the upright, the top and the bottom. The right one is the
-- left one seen in a mirror.
local function bracket(mirror)
    local f = CreateFrame("Frame", nil, holder)
    f.mirror, f.lines, f.shades = mirror, {}, {}
    for i = 1, 3 do
        f.shades[i] = ns.Theme.Fill(f, "BACKGROUND", 0, 0, 0, 0.55)
        f.lines[i] = ns.Theme.Fill(f, "ARTWORK", 1, 1, 1, 0.95)
    end
    return f
end

-- The lines of one bracket at a size.
local function shape(f, width, height, thick)
    f:SetSize(width, height)
    local outer = f.mirror and "RIGHT" or "LEFT"
    for _, set in ipairs({ { f.shades, 1.5, -1.5 }, { f.lines, 0, 0 } }) do
        local list, dx, dy = set[1], set[2], set[3]
        for _, line in ipairs(list) do
            line:ClearAllPoints()
        end
        list[1]:SetPoint("TOP" .. outer, dx, dy)
        list[1]:SetPoint("BOTTOM" .. outer, dx, dy)
        list[1]:SetWidth(thick)
        list[2]:SetPoint("TOPLEFT", dx, dy)
        list[2]:SetPoint("TOPRIGHT", dx, dy)
        list[2]:SetHeight(thick)
        list[3]:SetPoint("BOTTOMLEFT", dx, dy)
        list[3]:SetPoint("BOTTOMRIGHT", dx, dy)
        list[3]:SetHeight(thick)
    end
end

-- Puts the brackets on the target's nameplate, or hides them. Only what is new is done.
function Brackets.Update()
    local plate = ns.Registry.Get("screen.target_brackets") and ns.Adapter.TargetPlate()
    if not plate then
        holder:Hide()
        return
    end
    local px = ns.Theme.px
    local scale = ns.Registry.Get("screen.bracket_size") / 100
    Brackets.color = (melee or ranged) and "red" or "yellow"
    if scale ~= drawn.scale then
        drawn.scale = scale
        local height = px(HEIGHT * scale)
        local thick = px(2 + HEIGHT * scale * 0.02)
        holder:SetSize(px(2 * GAP), height)
        shape(sides.left, height * 0.2, height, thick)
        shape(sides.right, height * 0.2, height, thick)
    end
    if Brackets.color ~= drawn.color then
        drawn.color = Brackets.color
        local r, g, b = YELLOW[1], YELLOW[2], YELLOW[3]
        if Brackets.color == "red" then
            r, g, b = ns.Theme.Color("red")
        end
        for _, side in pairs(sides) do
            for _, line in ipairs(side.lines) do
                line:SetColorTexture(r, g, b, 0.95)
            end
        end
    end
    if plate ~= drawn.plate or not holder:IsShown() then
        drawn.plate = plate
        holder:ClearAllPoints()
        holder:SetPoint("TOP", plate, "BOTTOM", 0, -px(4))
        holder:Show()
        -- One line out of combat and one in combat, for the log (kind "brackets"): did the game let them show?
        local when = ns.Adapter.InCombat() and "in combat" or "out of combat"
        if not told[when] then
            told[when] = true
            ns.Log.Add("brackets", "put on the target's nameplate " .. when .. "; shown: " .. tostring(holder:IsShown()))
        end
    end
end

function Brackets.OnLogin()
    holder = CreateFrame("Frame", "GamepadSuiteBrackets", UIParent)
    holder:SetFrameStrata("BACKGROUND")
    holder:Hide()
    sides.left, sides.right = bracket(false), bracket(true)
    sides.left:SetPoint("TOPRIGHT", holder, "TOPLEFT")
    sides.right:SetPoint("TOPLEFT", holder, "TOPRIGHT")
    local function target()
        hasTarget = ns.Adapter.HasTarget()
        Brackets.Update()
    end
    ns.On("PLAYER_TARGET_CHANGED", "Brackets", target)
    ns.On("PLAYER_ENTERING_WORLD", "Brackets", target)
    -- A nameplate came. It matters only when it is the target's own and the brackets wait for
    -- it: the nameplate of any other unit is not even asked about.
    ns.On("NAME_PLATE_UNIT_ADDED", "Brackets", function(unit)
        if hasTarget and not holder:IsShown() and ns.Registry.Get("screen.target_brackets") and ns.Adapter.IsTargetPlate(unit) then
            Brackets.Update()
        end
    end)
    -- the nameplate of the target goes: the game can still give that plate at this moment, so the
    -- brackets are hidden here and not left at the old place
    ns.On("NAME_PLATE_UNIT_REMOVED", "Brackets", function(unit)
        if holder:IsShown() and ns.Adapter.IsTargetPlate(unit) then
            holder:Hide()
        end
    end)
    -- the player attacks: the swing, or auto shot and the wand
    local function attack(which, on)
        return function()
            if which == "melee" then
                melee = on
            else
                ranged = on
            end
            Brackets.Update()
        end
    end
    for event, fn in pairs({ PLAYER_ENTER_COMBAT = attack("melee", true), PLAYER_LEAVE_COMBAT = attack("melee", false),
        START_AUTOREPEAT_SPELL = attack("ranged", true), STOP_AUTOREPEAT_SPELL = attack("ranged", false) }) do
        -- an event this game version does not have is left out
        pcall(ns.On, event, "Brackets", fn)
    end
    ns.Listen("setting", "Brackets", function(key)
        if key == "screen.target_brackets" or key == "screen.bracket_size" then
            Brackets.Update()
        end
    end)
end
