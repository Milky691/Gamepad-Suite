-- Healer Mode at Bumpers: while the friendly bumper is held in a group, the on-screen buttons that target the group
-- show who a press of each targets now: the D-pad, A, X and B (Core/BindGroup.lua), in every look of the row Button
-- Look. A button shows the member's portrait on a dark face in the look's shape, and the name in its class colour on the
-- side away from the middle of its group (under each button of the bar in view in Bars). The other buttons step back,
-- as they do while LB + RB is held. At the let-go the buttons show their binds again. The game's own friendly targeting
-- bar puts portraits on the same buttons (Blizzard_GamepadActionBars/TargetActionBars/FriendlyTargetingActionBar.lua 108
-- to 196). The list of the small details is build_plan/packs/P36_healer_dpad.md.
-- The hold is heard, never polled: the bumper's own button tells the owner frame of its press and its let-go, in combat
-- too, and a hook hears that (Core/AdapterParty.lua). A tap of the bumper for its own bind must not make the buttons
-- blink, so the look waits as the game's own bar waits (Adapter.TargetingDelay) and comes at once with the first press
-- of the group. While it shows it hears the game's events of the group, the pet and the target's target, and no more.
-- Display only: plain frames, nothing secure, the same in combat.
local _, ns = ...

local Party = {}
ns.HudParty = Party

local Theme = ns.Theme
local px = Theme.px

local BACK, EMPTY = 0.3, 0.4      -- a button that does not target the group steps back; a face with nobody on it
local INSET, GAP, WIDE = 2, 4, 90 -- in units: the portrait inside its face; between a button and its name; a name's width
local BAR_GAP = 8                 -- between two buttons of a bar (Screen/HudBars.lua): a name there is a button and a gap wide
local GRAY = { r = 0.5, g = 0.5, b = 0.5 }
-- where a name stands by its button: away from the middle of its group (Bars: under every button)
local SIDE = { DU = "up", DD = "down", A = "down", DL = "left", X = "left", DR = "right", B = "right" }
-- the game's events that change who a button shows, or a picture; heard only while the look shows, as the game's own bar
-- hears them (FriendlyTargetingActionBar.lua 20 to 27). A unit's event counts for that unit only.
local EVENTS = { "GROUP_ROSTER_UPDATE", "UNIT_PET", "PLAYER_TARGET_CHANGED", "UNIT_TARGET", "UNIT_PORTRAIT_UPDATE", "UNIT_NAME_UPDATE" }
local ONLY = { UNIT_PET = "player", UNIT_TARGET = "target" }

-- Who a press of each key targets now, by the rule of the group button's own code (Core/BindGroup.lua SNIPPET): key ->
-- unit, or false for nobody there. get(name) gives the group button's attribute; there(unit) says the unit is there. In
-- a raid ("groups") up and down step through the group in focus ("k", at the place "s"), left and right go to the group
-- before or after, at the same place or its last; all of them wrap round.
function Party.Targets(get, there)
    local out, groups = {}, get("groups")
    for key, what in pairs(ns.BindRules.GROUP_KEYS) do
        local unit = what
        if what == "up" or what == "down" or what == "left" or what == "right" then
            unit = get("party:" .. what)
            if groups then
                local k, s = get("k") or 1, get("s") or 1
                if what == "left" or what == "right" then
                    k = k + (what == "right" and 1 or -1)
                    k = k < 1 and groups or k > groups and 1 or k
                    s = math.min(s, get("n:" .. k) or 1)
                else
                    local n = get("n:" .. k) or 1
                    s = s + (what == "down" and 1 or -1)
                    s = s < 1 and n or s > n and 1 or s
                end
                unit = get("u:" .. k .. ":" .. s)
            end
        end
        out[key] = unit ~= nil and there(unit) and unit or false
    end
    return out
end

local hold = { held = false, used = false, get = function() return nil end }
local hooked, waited, ticket, showing, asked = false, false, 0, false, false
local last = {}     -- the last full draw of Screen/Hud.lua: its look, the layer in view, its buttons
local faces = {}    -- a button -> its face
local watch         -- hears the game's events while the look shows
local told = {}     -- the log's lines: one of each kind

-- True while the look shows. Screen/Hud.lua then hides Other Layers and keeps the buttons in sight.
function Party.On()
    return showing
end

-- The face of a button: the dark face in the look's shape, the portrait on it, the name beside it on the party wheel's
-- soft backing (Screen/WheelPlate.lua). Over the cooldown and the count; under the controller button picture (HudFace.lua Badge).
local function make(b, look)
    local face = CreateFrame("Frame", nil, b)
    face:SetAllPoints(b)
    face:SetFrameLevel(b.cooldown:GetFrameLevel() + 2)
    face.back = face:CreateTexture(nil, "BACKGROUND")
    face.back:SetColorTexture(Theme.Color("ground"))
    face.back:SetAllPoints()
    ns.HudFace.Shape(face.back, look, look.main)
    face.art = face:CreateTexture(nil, "ARTWORK")
    face.art:SetPoint("TOPLEFT", px(INSET), -px(INSET))
    face.art:SetPoint("BOTTOMRIGHT", -px(INSET), px(INSET))
    local name, side = Theme.Text(face, "tiny", "cream"), look.bars and "down" or SIDE[b.key]
    -- (the controller button picture in the corner of Square and Bars reaches out at the bottom and the right)
    local gap = px(GAP + ((look.keyAt == "corner" and (side == "down" or side == "right")) and look.key / 2 - look.keyGap or 0))
    name:SetWidth(px(look.bars and look.main + BAR_GAP or WIDE))
    name:SetJustifyH(side == "left" and "RIGHT" or side == "right" and "LEFT" or "CENTER")
    if side == "up" then
        name:SetPoint("BOTTOM", face, "TOP", 0, gap)
    elseif side == "down" then
        name:SetPoint("TOP", face, "BOTTOM", 0, -gap)
    elseif side == "left" then
        name:SetPoint("RIGHT", face, "LEFT", -gap, 0)
    else
        name:SetPoint("LEFT", face, "RIGHT", gap, 0)
    end
    face.name, face.band = name, ns.WheelPlate.Backing(face, name)
    ns.WheelPlate.PlaceBack(face.band, px(5), px(4))
    return face
end

-- Shows a unit on a face, or nobody (false): the dark face alone (paint makes its button faint). A member who is offline or dead
-- has the gray of the party wheel; a target's target that is no player has the cream. No health: the game hides it.
local function fill(face, unit)
    for _, part in ipairs({ face.art, face.name, face.band[1], face.band[2] }) do
        part:SetShown(unit ~= false)
    end
    if not unit then
        return
    end
    ns.Adapter.Portrait(face.art, unit)
    local color = ns.Adapter.ShowName(face.name, unit)
    local player = ns.Adapter.IsPlayerUnit(unit)
    -- (a feigning hunter is a live member: Core/AdapterPlate.lua MemberState)
    local word, state = ns.Adapter.MemberState(unit)
    local gone = player and word ~= nil and state ~= "feign"
    face.art:SetDesaturated(gone)
    color = gone and GRAY or player and color or nil
    if color then
        face.name:SetTextColor(color.r, color.g, color.b)
    else
        face.name:SetTextColor(Theme.Color("cream"))
    end
end

-- Puts the faces on the buttons of the last full draw (in Bars the bar of the layer in view), or takes them off. A button
-- with a face has b.who: its bind's rims do not show under it (HudFace.lua Look).
local function paint()
    local units = showing and Party.Targets(hold.get, ns.Adapter.UnitThere) or {}
    for _, b in pairs(last.buttons or {}) do
        local here, unit = b.used and (not b.layer or b.layer == last.layer), nil
        if here then
            unit = units[b.key]
        end
        local had = b.who
        b.who = unit ~= nil or nil
        if unit ~= nil then
            faces[b] = faces[b] or make(b, last.look)
            faces[b]:Show()
            fill(faces[b], unit)
            b:SetAlpha(unit and 1 or EMPTY)
        elseif faces[b] then
            faces[b]:Hide()
        end
        if showing and here and unit == nil then
            b:SetAlpha(BACK)
        end
        if had ~= b.who then
            ns.HudFace.Look(b)
        end
    end
end

-- The first time the look shows in each kind of group, in or out of combat, the log says how.
local function tell()
    local kind = (hold.get("groups") and "raid" or "party") .. (ns.Adapter.InCombat() and ", in combat" or "")
    if not told[kind] then
        told[kind] = true
        local count = 0
        for _, unit in pairs(Party.Targets(hold.get, ns.Adapter.UnitThere)) do
            count = count + (unit and 1 or 0)
        end
        ns.Log.Add("screen", ("Healer Mode Bumpers: the buttons show who they target (%s), %s; %d of 7 have someone"):format(kind,
            hold.used and "at the first press" or "after the wait of " .. ns.Adapter.TargetingDelay() .. " s", count))
    end
end

local changed

-- The look shows while the bumper is held in a group, after the wait or from the first press of the group. When it
-- turns on or off, Screen/Hud.lua draws in full once (the message "screen:party"); the faces follow at once.
local function update()
    local on = hold.held and (hold.used or waited) and ns.Adapter.InGroup() or false
    if on ~= showing then
        showing = on
        if not watch then
            watch = CreateFrame("Frame")
            watch:SetScript("OnEvent", function(_, event, unit)
                if not ONLY[event] or ONLY[event] == unit then
                    changed()
                end
            end)
        end
        if on then
            for _, event in ipairs(EVENTS) do
                pcall(watch.RegisterEvent, watch, event)
            end
            tell()
        else
            watch:UnregisterAllEvents()
        end
        ns.Send("screen:party")
    end
    paint()
end

-- The owner frame changed, or the group: read it. A new hold starts the wait.
local function read()
    local was = hold.held
    hold = ns.Adapter.GroupHold()
    if hold.held and not was then
        ticket, waited = ticket + 1, false
        local mine = ticket
        C_Timer.After(ns.Adapter.TargetingDelay(), function()
            if mine == ticket and hold.held then
                waited = true
                ns.Call("HudParty", update)
            end
        end)
    end
    update()
end

-- A burst of changes (a press moves "k" and "s" together) is read once, on the next frame.
function changed()
    if not asked then
        asked = true
        C_Timer.After(0, function()
            asked = false
            ns.Call("HudParty", read)
        end)
    end
end

-- After each full draw of the on-screen buttons. The hook goes on at the first draw that finds the bind core's frames
-- (they are made at login, or after the combat of a reload).
ns.Listen("screen:minis", "HudParty", function(_, _, look, layer, _, buttons)
    if not hooked then
        hooked = ns.Adapter.OnGroupHold(changed)
        if hooked then
            changed()
        end
    end
    last.look, last.layer, last.buttons = look, layer, buttons
    paint()
end)
