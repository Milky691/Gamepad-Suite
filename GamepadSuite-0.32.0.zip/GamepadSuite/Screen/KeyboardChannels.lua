-- The channel row of the chat keyboard and its list of whisper names, with no game calls. The game's
-- facts come from Core/AdapterKeyboard.lua (ChatFacts, ChatNames).
--
-- A chip of the row: { id, label, title, prefix }. prefix is the game's chat command that goes in front of
-- the line ("/p"); the title is what the keyboard's top line shows ("Party:"). Whisper has no prefix and no
-- title until a name is picked (Channels.Whisper), only the command (slash); Close has neither.
local _, ns = ...

local Channels = {}

-- The named channels in the row's order, and when each works: the group the player is in ("party",
-- "raid", "instance" or nil), a guild, a last whisper, a name to whisper.
local NAMED = {
    { "say", "Say" },
    { "party", "Party", function(f) return f.group == "party" or f.group == "raid" end },
    { "raid", "Raid", function(f) return f.group == "raid" end },
    { "instance", "Instance", function(f) return f.group == "instance" end },
    { "guild", "Guild", function(f) return f.guild end },
    { "yell", "Yell" },
    { "whisper", "Whisper", function(f) return f.canWhisper end },
    { "reply", "Reply", function(f) return f.lastTell end },
}

-- The chips that work now, then Close. facts: { slash = { say = "/s", ... }, group, guild, lastTell,
-- canWhisper, channels = { { number, name } } }, or nil when the game lacks the calls: then Close alone.
function Channels.Chips(facts)
    local chips = {}
    for _, named in ipairs(facts and NAMED or {}) do
        local id, label, works = named[1], named[2], named[3]
        local slash = facts.slash[id]
        if slash and (not works or works(facts)) then
            local chip = { id = id, label = label }
            if id == "reply" then
                chip.prefix, chip.title = slash, "To " .. facts.lastTell .. ":"
            elseif id == "whisper" then
                chip.slash = slash
            else
                chip.prefix, chip.title = slash, label .. ":"
            end
            chips[#chips + 1] = chip
        end
    end
    for _, channel in ipairs(facts and facts.channels or {}) do
        -- "General - Elwynn Forest" is the channel General
        local name = channel.name:match("^(.-) %- ") or channel.name
        chips[#chips + 1] = {
            id = "channel" .. channel.number, label = channel.number .. " " .. name,
            title = channel.number .. ". " .. name .. ":", prefix = "/" .. channel.number,
        }
    end
    chips[#chips + 1] = { id = "close", label = "Close" }
    return chips
end

-- The game's chat types that a chip stands for.
local KIND = { SAY = "say", PARTY = "party", RAID = "raid", INSTANCE_CHAT = "instance", GUILD = "guild", YELL = "yell", WHISPER = "whisper" }
-- and the other way: the game's chat type of a chip, for its colour. Reply has the whisper's (the game's own colour for it).
local TYPE = { reply = "WHISPER" }
for kind, id in pairs(KIND) do
    TYPE[id] = kind
end

-- The game's chat type of a chip ("GUILD", "CHANNEL2"), or nil (Close).
function Channels.Kind(chip)
    local number = chip.id:match("^channel(%d+)$")
    return number and "CHANNEL" .. number or TYPE[chip.id]
end

-- The place in `chips` of the chip `id`, or nil.
function Channels.At(chips, id)
    for i, chip in ipairs(chips) do
        if chip.id == id then
            return i
        end
    end
    return nil
end

-- The place in `chips` of the chat box's own channel (its chat type, and its channel number), or nil.
function Channels.Find(chips, kind, number)
    return Channels.At(chips, kind == "CHANNEL" and "channel" .. tostring(number) or KIND[kind])
end

-- The channel of a whisper to `name`, picked from the list that the chip Whisper of `chips` opened.
function Channels.Whisper(chips, name)
    local slash = chips[Channels.Find(chips, "WHISPER")].slash
    return { id = "whisper", label = "Whisper", target = name, prefix = slash .. " " .. name, title = "To " .. name .. ":" }
end

-- A kept channel (the last one picked, or one kept through a fight), as it works now: a whisper to a
-- name always, any other while the row still has it, else nil.
function Channels.Keep(chips, channel)
    if channel and channel.id == "whisper" then
        return channel
    end
    return channel and chips[Channels.At(chips, channel.id)] or nil
end

-- The names to whisper: `first` (the box's own whisper name), the group, the friends, the guild; each
-- name once, whatever its capitals, and not the player's own. lists: { me, group, friends, guild }.
function Channels.Names(lists, first)
    local out, seen = {}, { [(lists.me or ""):lower()] = true }
    -- (state: "away" or "busy", Core/AdapterKeyboard.lua ChatNames)
    local function add(name, tag)
        if type(name) == "string" and name ~= "" and not seen[name:lower()] then
            seen[name:lower()] = true
            out[#out + 1] = { name = name, tag = tag, state = lists.state and lists.state[name] or nil }
        end
    end
    add(first, "")
    for _, part in ipairs({ { "group", "Group" }, { "friends", "Friend" }, { "guild", "Guild" } }) do
        for _, name in ipairs(lists[part[1]] or {}) do
            add(name, part[2])
        end
    end
    return out
end

if ns then
    ns.KeyboardChannels = Channels
end
return Channels
