-- The names that the chat keyboard's word guesses offer (Screen/KeyboardWords.lua, Words.names): the people of
-- the player's group, the friends and the guild members who are in the game, read the same way as the
-- whisper names (Adapter.ChatNames, Channels.Names: the player's own name is left out, a name of another
-- realm keeps its realm, a name the game hides is skipped).
--
-- They are read when the keyboard opens for a chat line, and again when the game says that a list changed
-- while it is open: GROUP_ROSTER_UPDATE, FRIENDLIST_UPDATE, GUILD_ROSTER_UPDATE. Those words are heard only
-- while the keyboard is open for a chat line with Word Guess on, and a burst of them is one read, a frame
-- later. No timer runs while nothing happens. When the keyboard closes (a fight closes it too) the names go.
-- Nothing is written to the game, and nothing here is saved.
--
-- It hears the keyboard's own message "keyboard" (open or closed), which Screen/Keyboard.lua sends one frame
-- after the panel shows or goes, after the chat part has made its first guesses; so the first read makes
-- the guesses again.
local _, ns = ...

local Names = {}
ns.KeyboardNames = Names

local OWNER = "KeyboardNames"
local EVENTS = { "GROUP_ROSTER_UPDATE", "FRIENDLIST_UPDATE", "GUILD_ROSTER_UPDATE" }

local watching        -- the keyboard (its state) whose names are held, or nil
local waiting         -- the word of the game that a read waits for, until the next frame

-- Reads the names, hands them to the guesses and makes the guesses of the line again. why is for the log:
-- one line for each reason, once, so the saved file shows that the calls worked in the game.
local function read(why)
    local state = ns.Keyboard.State()
    if not state or state ~= watching then
        return
    end
    local lists = ns.Adapter.ChatNames()
    local names = {}
    for _, entry in ipairs(ns.KeyboardChannels.Names(lists)) do
        names[#names + 1] = entry.name
    end
    ns.KeyboardWords.SetNames(names)
    ns.Keyboard.Note("name guesses: " .. why .. ": " .. #names .. " names (group " .. #lists.group .. ", friends "
        .. #lists.friends .. ", guild " .. #lists.guild .. ")", "names " .. why)
    if (lists.hidden or 0) > 0 then
        ns.Keyboard.Note("name guesses: the game hid " .. lists.hidden .. " names, they are not offered", "names hidden")
    end
    ns.KeyboardChat.Typed(state)
    ns.Keyboard.Redraw()
end

-- The game says that a list changed.
local function changed(event)
    if watching and not waiting then
        waiting = event
        C_Timer.After(0, function()
            local why = waiting
            waiting = nil
            ns.Call(OWNER, read, why)
        end)
    end
end

-- The keyboard opened or closed (its panel shows or goes). A keyboard that is no chat line, or has Word
-- Guess off, has no names; one that opens again after a send is the same keyboard.
local function follow(open)
    local state = ns.Keyboard.State()
    if open and state and state.box and state.guess then
        if watching ~= state then
            if not watching then
                for _, event in ipairs(EVENTS) do
                    ns.On(event, OWNER, function() changed(event) end)
                end
            end
            watching = state
            read("the keyboard opened")
        end
    elseif watching then
        watching = nil
        for _, event in ipairs(EVENTS) do
            ns.Off(event, OWNER)
        end
        ns.KeyboardWords.SetNames()
    end
end

ns.Listen("keyboard", OWNER, follow)
