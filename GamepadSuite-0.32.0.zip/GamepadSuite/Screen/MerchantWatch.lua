-- What the merchant view hears of the game (Screen/Merchant.lua has what it does with it).
--
-- Heard always, from login on. Each costs nothing while no vendor is open:
--   the game opens a vendor (MERCHANT_SHOW) or closes it (MERCHANT_CLOSED);
--   the game tells its manager to show the vendor window (for the log: which came first);
--   the game's own vendor window shows (a hook after its own script: it must not show while the
--   view has the vendor);
--   a controller comes or goes, or the game's controller interface is turned off or on: one that
--   goes while the view is open closes it, as combat does;
--   combat starts; a row of the settings changes;
--   a window or a question of the game takes the controller or gives it back, and a question of
--   the game opens or closes. These come from inside the game's code.
-- Heard only while the view is open:
--   the vendor's list, the bags, the gold, the gear's wear or an item's facts changed: the view
--   reads it all again a moment later, one time for many;
--   the game wrote its red line ("Inventory is full", not enough money): the view's line says it too.
local _, ns = ...

local Watch = {}
ns.MerchantWatch = Watch

local DURING = { MERCHANT_UPDATE = true, BAG_UPDATE_DELAYED = true, PLAYER_MONEY = true, UPDATE_INVENTORY_DURABILITY = true,
    GET_ITEM_INFO_RECEIVED = true }
local view            -- the module's side: its functions by name (Merchant.OnLogin)
local again = false   -- the vendor in view is to be read again

local function changed()
    if not again then
        again = true
        C_Timer.After(0.1, function()
            again = false
            view.guarded(view.reread)
        end)
    end
end

-- The game's red line, while the view is open.
local function line(_, text)
    if view.shop() and type(text) == "string" then
        view.note("the game wrote '" .. text .. "'", "line" .. text)
        view.say(text, "say")
    end
end

-- A controller came or went. One that goes while the view is open closes it, as combat does.
local function pad()
    if view.busy() and not ns.Adapter.DialoguePad() then
        view.quit("no controller is in use")
        ns.Print("Merchant View closed because no controller is in use.")
    end
end

-- The view is open (on), or closed.
function Watch.Set(on)
    for event in pairs(DURING) do
        if on then
            ns.On(event, "Merchant", changed)
        else
            ns.Off(event, "Merchant")
        end
    end
    if on then
        ns.On("UI_ERROR_MESSAGE", "Merchant", line)
    else
        ns.Off("UI_ERROR_MESSAGE", "Merchant")
    end
end

-- At login. module: the module's side.
function Watch.Login(module)
    view = module
    ns.On("MERCHANT_SHOW", "Merchant", function() view.guarded(view.opened) end)
    ns.On("MERCHANT_CLOSED", "Merchant", function() view.closed() end)
    ns.On("PLAYER_INTERACTION_MANAGER_FRAME_SHOW", "Merchant", function(kind)
        if ns.Adapter.MerchantKind(kind) then
            view.heard()
        end
    end)
    ns.Adapter.OnMerchantWindow(view.gameWindow)
    for _, event in ipairs({ "GAME_PAD_CONNECTED", "GAME_PAD_DISCONNECTED", "GAME_PAD_ACTIVE_CHANGED" }) do
        ns.On(event, "Merchant", pad)
    end
    -- the game's own "Enable Gamepad UI" turned off or on (Core/Pad.lua tells it as "pad")
    ns.Listen("pad", "Merchant", pad)
    -- combat always wins: the view closes at once and the game's own window has the next vendor
    ns.On("PLAYER_REGEN_DISABLED", "Merchant", function() view.quit("combat started") end)
    ns.Listen("setting", "Merchant", function(key, value)
        if key == "windows.dialogue_size" and view.shop() then
            ns.MerchantDraw.Scale(value)
        end
        view.later()
    end)
    ns.Listen("pad:stack", "Merchant", view.later)
    ns.Listen("pointer", "Merchant", view.later)
    ns.Listen("settings:opened", "Merchant", view.later)
    ns.Listen("settings:closed", "Merchant", view.later)
    ns.Adapter.OnPopups(view.later)
    ns.Listen("popup", "Merchant", view.later)
end
