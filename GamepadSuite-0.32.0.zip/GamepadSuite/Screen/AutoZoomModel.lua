-- The rules of Auto Camera Zoom, with no game calls: how far the camera goes in each situation (a
-- fight, an NPC, a mount, a flight path, indoors), which one it follows when two hold, when it is
-- left alone, and when it has missed the player's distance.
local _, ns = ...

local Model = {}

-- The yards the camera moves, by the value of the row Auto Camera Zoom. Off has no step.
Model.STEP = { Low = 3, Full = 6 }
-- The situations that move the camera out, by how many steps. The others (an NPC, indoors) move it in by one.
Model.OUT = { fight = 1, mount = 1, taxi = 2 }
-- The rank of each situation: the camera follows the highest that holds. A flight path is above all
-- (nothing else can happen on it), a fight and an NPC have one rank (the one that came first keeps
-- the camera, the rule "one start at a time"), indoors is above a mount (the walls are near).
Model.RANK = { taxi = 4, fight = 3, npc = 3, indoors = 2, mount = 1 }
Model.ORDER = { "taxi", "fight", "npc", "indoors", "mount" }
-- The forms that count as a mount, by GetShapeshiftFormID: travel, aquatic, Ghost Wolf, the two
-- flight forms (Blizzard_FrameXMLBase/Constants.lua 327 to 337). Hide While Mounted reads this
-- list too (Core/AdapterCue.lua Travel): one list for both features.
Model.TRAVEL = { [3] = true, [4] = true, [16] = true, [27] = true, [29] = true }
-- The rows of the three situations of the game's world. Each starts On.
Model.ROW = { mount = "feel.camera_mount", taxi = "feel.camera_flight", indoors = "feel.camera_indoors" }
Model.NEAR = 4       -- at an NPC the camera is never brought nearer than this, in yards
Model.FIRST = 0.5    -- nearer than this the camera is in first person: the character is not on screen
Model.SETTLE = 1     -- seconds after the way back: the camera is at rest, and its distance is looked at
Model.CLOSE = 0.1    -- a miss of the player's distance by more than this, in yards, is set right
-- Seconds after the last window of an NPC closed before the camera goes back. A talk that goes
-- on to a quest or a vendor closes one window and opens the next: the camera waits for it.
Model.WAIT = 0.3
-- Seconds that indoors must hold before the camera moves in. At a cave mouth, a bridge or a roof
-- edge the game flips indoors and out several times in a second: a flip back moves nothing.
Model.INDOORS = 1

-- The distance the camera should have in a situation. A fight or a mount is out by the step, a
-- flight path out by two; an NPC or indoors is in by the step, but not nearer than NEAR, and a
-- camera that is nearer already stays. home is the distance the player had: every goal is counted
-- from it, never from another situation's, so a fight on a mount moves nothing more.
function Model.Goal(kind, level, home)
    local step = Model.STEP[level] or 0
    if Model.OUT[kind] then
        return home + Model.OUT[kind] * step
    end
    return math.min(home, math.max(Model.NEAR, home - step))
end

-- The situation the camera follows: the highest rank in holds (kind -> true), or nil when none
-- holds. now, the one it follows now, keeps the camera against one of the same rank.
function Model.Top(holds, now)
    local top = holds[now] and now or nil
    for _, kind in ipairs(Model.ORDER) do
        if holds[kind] and (not top or Model.RANK[kind] > Model.RANK[top]) then
            top = kind
        end
    end
    return top
end

-- Is the change from old to new a start: a situation after none, or one of a higher rank? A start
-- takes the camera again after a zoom by hand; an end, or a change down, does not.
function Model.Rises(old, new)
    return new ~= nil and (old == nil or Model.RANK[new] > Model.RANK[old])
end

-- The yards to zoom to bring the camera from distance to goal: above 0 is in, below 0 is out,
-- as the adapter's zoom call takes them.
function Model.Yards(distance, goal)
    return distance - goal
end

-- Why the camera is left alone now, in words for the log, or nil when it may move. distance is
-- nil when the game does not tell it: that alone stops no move.
function Model.Refusal(distance, settings, mouse)
    if settings then
        return "the settings window is open"
    elseif mouse then
        return "mouse mode is on"
    elseif distance and distance < Model.FIRST then
        return "the camera is in first person"
    end
    return nil
end

-- The yards that set the camera right after the way back (above 0 is in), or nil when it is
-- close enough to the player's distance, or its distance is not known.
function Model.Miss(distance, home)
    local off = distance and home and Model.Yards(distance, home)
    return off and math.abs(off) > Model.CLOSE and off or nil
end

if ns then
    ns.AutoZoomModel = Model
end
return Model
