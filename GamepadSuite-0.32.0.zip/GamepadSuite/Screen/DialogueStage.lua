-- The stage of the dialogue view: with the row Hide Interface In Talks on (windows.dialogue_hide,
-- on at first), while the view shows and has the controller, the game's interface (minimap,
-- unit frames, chat, bars) is out of sight, so only the world, the NPC and the view are on the
-- screen. When the view closes the interface is back. With the row off it never goes.
--
-- How: the strength of the game's own root frame goes to nothing in 0.2 seconds, and back in
-- 0.15. The view is a child of that frame and ignores its parent's strength, so it stays in
-- sight; nameplates and chat bubbles are not that frame's children and stay too. A frame's
-- strength is no protected thing: the game lets an addon set it in a fight
-- (SimpleRegionAPIDocumentation.lua 123 to 131 and 158), and the game's own code never sets
-- or reads the strength of its root frame. The root frame is never hidden from here.
--
-- The player is never left with no interface. It is back at once, with no fade:
--   when a fight starts;
--   when the view's frame hides, for any reason: the talk ended, a fault, or the game hid its
--   whole interface (a movie, a window over the whole screen);
--   when a cinematic, a movie or a loading screen starts (the talk ends too), and at login;
--   while a window or a question of the game is on the screen (a price to confirm, a group
--   invite, a loot roll), and while a chat box has the typing focus;
--   when the game writes its red line (bags full): then for the rest of that talk;
--   when the view gives the controller away: to the settings window, or to a window of the game.
-- It never goes while the game's windows are made for the mouse and not for the controller:
-- the game then keeps no list of its windows and questions (FrameControlsManager.lua 397 to
-- 400, Blizzard_StaticPopup/StaticPopupGamepad.lua 263 to 271), so a question would open unseen.
-- And the view checks itself at each step of the fade: if it is not in sight while the
-- interface goes, the interface comes back and stays for the session.
local _, ns = ...

local Stage = {}
ns.DialogueStage = Stage

local OUT, BACK = 0.2, 0.15
local root, fader, note
local able = false           -- this game has the calls, and the view was in sight when it was tried
local wanted = false         -- the view shows and has the controller
local out = false            -- the interface is out of sight, or on its way there
local typing = false         -- a chat box has the typing focus
local held = false           -- the game wrote a line the player must read: in sight for the rest of the talk
local full, now, to, time = 1, 1, 1, OUT   -- the interface's own strength; the fade: now, to where, in how long

-- At once: the interface at its own strength, and no fade runs.
local function snap()
    fader:SetScript("OnUpdate", nil)
    now, to = full, full
    UIParent:SetAlpha(full)
end

-- The interface is back at once and stays until the view asks again.
function Stage.Back()
    wanted = false
    if fader and (out or now ~= to) then
        out = false
        snap()
    end
end

local function step(elapsed)
    local by = elapsed / time * full
    now = to > now and math.min(to, now + by) or math.max(to, now - by)
    UIParent:SetAlpha(now)
    -- while the interface goes, the view itself must be in sight: at each step, whatever the
    -- order of the two fades and the speed of the game
    if out and root:GetEffectiveAlpha() < root:GetAlpha() * 0.5 then
        able = false
        note("the view was not in sight with the interface gone: the interface stays for this session")
        return Stage.Back()
    end
    if now == to then
        fader:SetScript("OnUpdate", nil)
    end
end

-- The fade runs on each frame only while the interface goes or comes. A fault stops it and
-- brings the interface back.
local function onUpdate(_, elapsed)
    if not ns.Call("Dialogue", step, elapsed) then
        able = false
        Stage.Back()
    end
end

-- Why the player must see the interface now, in a few words; nil when nothing asks for it.
local function needed()
    local ok, hide = pcall(ns.Registry.Get, "windows.dialogue_hide")
    return not (ok and hide == true) and "the row Hide Interface In Talks is off"
        or (ns.fightStarted or ns.Adapter.InCombat()) and "combat is on"
        or typing and "a chat box has the typing focus"
        or held and "the game wrote a line to read"
        or not ns.Adapter.PadWindowStyle() and "the game's windows are made for the mouse"
        or (ns.Adapter.GameWindows() > 0 or ns.Adapter.PopupShown()) and "a window or a question of the game is on the screen"
        or nil
end

-- Makes the interface follow what is true now. soft: it comes back with a fade (the view closed).
local function settle(soft)
    local why = able and wanted and needed()
    local want = able and wanted and not why
    if why then
        -- for the log, one time for each cause: why the interface stays in sight during a talk
        note("the game's interface stays in sight: " .. why, why)
    end
    if want == out then
        return
    end
    out = want
    if out then
        note("the game's interface goes out of sight for the talk", "out")
        if now == to then
            -- at rest: the strength the interface has now is the one it gets back
            full = UIParent:GetAlpha()
            now = full
        end
        to, time = 0, OUT
    elseif soft then
        to, time = full, BACK
    else
        return snap()
    end
    fader:SetScript("OnUpdate", now ~= to and onUpdate or nil)
end

-- The view has the controller (on) or not. soft: the view closed, the interface fades back,
-- and a line of the game that kept it in sight is done with.
function Stage.Want(on, soft)
    wanted = on and true or false
    held = held and not soft
    if fader then
        settle(soft)
    end
end

-- The game wrote a line that the player must read: the interface is back at once, and stays
-- for the rest of this talk.
function Stage.Hold()
    held = true
    if fader then
        settle()
    end
end

-- view: the view's frame. log(text, once) writes a line to the log. over(why) ends the talk at
-- once. Called at login.
function Stage.Build(view, log, over)
    root, note = view, log
    -- a cinematic, a movie or a loading screen: the interface is back and the talk is over
    for _, event in ipairs({ "CINEMATIC_START", "PLAY_MOVIE", "LOADING_SCREEN_ENABLED", "PLAYER_LEAVING_WORLD" }) do
        pcall(ns.On, event, "DialogueStage", function()
            Stage.Back()
            over(event)
        end)
    end
    able = ns.Adapter.Results().dialogueStage and true or false
    if not able then
        return note("the game's interface stays in sight during a talk: this game build lacks a call for it")
    end
    fader = CreateFrame("Frame")
    root:SetIgnoreParentAlpha(true)
    -- at login the interface is never left at nothing
    if UIParent:GetAlpha() == 0 then
        UIParent:SetAlpha(1)
    end
    root:HookScript("OnHide", Stage.Back)
    -- the game tells of a fight before it locks anything: the interface is back at that moment
    ns.On("PLAYER_REGEN_DISABLED", "DialogueStage", function() settle() end)
    ns.On("PLAYER_REGEN_ENABLED", "DialogueStage", function() settle() end)
    -- told from inside the game's own code: the interface follows one frame later
    local function later()
        if wanted or out then
            C_Timer.After(0, function() settle() end)
        end
    end
    ns.Adapter.OnGameWindows(later)
    ns.Adapter.OnTyping(function(on)
        typing = on
        later()
    end)
end
