-- Mouse mode by a press of two buttons: the setting Mouse Mode Buttons (Off, View + Menu). Hold
-- View and press Menu: mouse mode goes on or off, and the menu does not open. A press of Menu
-- alone opens the menu at once, as before.
--
-- A button does its own job when it goes down, and no addon can move a game command to the
-- let-go of a button. So View keeps its job wherever it has one, and its press is heard: at the
-- button that View's key clicks (a bind of the player's: a spell, an item, a macro, Cancel; the
-- game's own button for its party frames), or at the game's own Focus UI, its action for View
-- while a window of the game is open or has the controller. From that press Menu is ours until
-- View's let-go, which the pad tells. With no bind and no window open, View has no job (the
-- game's Focus UI would only say that there is nothing to focus): View is ours then, and does
-- nothing by itself. A command of the game on View (Jump) runs through no button and no call an
-- addon can hear: then the pair rests, and one line in chat says that the bind Mouse Mode works
-- on any button.
-- The dialogue view keeps every button while a talk shows, so it asks here first (Pair.Heard).
-- In a fight no key of ours is held for the pair: each button does its own job, and mouse mode
-- does not come on. With the game's controller interface off the pair rests too. Nothing runs on
-- a timer but one look a frame after the pair is found to rest; the pad is looked at each frame
-- only while Menu is ours.
local _, ns = ...

local Pair = ns.Module("PointerPair", { "pointer", "tempSetting" }, "Mouse Mode")
ns.PointerPair = Pair

local Model = ns.PointerModel

local READY = "View + Menu is ready: View keeps its job, and Menu pressed while View is held turns mouse mode on or off"
-- the buttons that the dialogue view uses in a talk (Screen/DialogueKeys.lua 24 to 31)
local TALK = { A = true, B = true, X = true, Y = true, DU = true, DD = true, DL = true, DR = true, LB = true, RB = true, MN = true }

local hold                 -- the button that View clicks while it is ours, and Menu while View is down
local viewOurs = false     -- View clicks the hold button now
local said, lines = nil, 0 -- the last line about "ready" in the log; lines about presses in this session
local told = 0             -- lines about "ready" in this session
local saved                -- kept for the account: the line that the player was told in chat
local hooked = {}          -- the buttons whose press is heard for View
local watch                -- the frame that looks for View's let-go while Menu is ours
local pending              -- a look is set for the next frame, to see that the pair still rests

-- One line when what the pair can do changes: the log says why a press of the two did nothing.
local function ready(text)
    if text ~= said then
        said = text
        if told < 8 then
            told = told + 1
            ns.Log.Add("pointer", text)
        end
    end
end

-- A fight, or its start: the game is about to lock the keys.
local function fight()
    return ns.Adapter.InCombat() or ns.fightStarted
end

-- A press of the two buttons: mouse mode goes on or off, and the log says which.
local function toggled(by)
    local was = ns.Pointer.IsOn()
    ns.Pointer.Toggle()
    if lines < 20 then
        lines = lines + 1
        ns.Log.Add("pointer", by .. " was pressed: mouse mode was " .. (was and "on" or "off") .. " and is " .. (ns.Pointer.IsOn() and "on" or "off") .. " now")
    end
end

-- View and Menu are the game's, or the bind core's. The game tells of a fight before it locks
-- the keys, so this is done then too.
local function release()
    ns.Adapter.GiveKeys(hold)
    viewOurs = false
    watch:Hide()
end

-- View went down and did its job (at its button, or the game's Focus UI ran). With View held
-- now, Menu is ours until View's let-go, which the pad tells (a button may hear no let-go).
local function viewDown(down)
    if not down or viewOurs or fight() or not ns.Pad.Controller() or ns.Registry.Get("controller.mouse_mode") ~= "View + Menu" then
        return
    end
    if ns.Adapter.ViewHeld() then
        ns.Adapter.TakeKey(hold, "MN", "Menu")
        watch:Show()
    end
end

-- Says in the log what the pair can do now, and makes View ours while it has no job. Out of a
-- fight only: a key cannot change hands in one. confirm: the look one frame after an answer "rests".
local function keys(confirm)
    if fight() then
        return
    end
    if ns.Registry.Get("controller.mouse_mode") ~= "View + Menu" then
        if viewOurs then
            release()
        end
        return
    end
    -- A window has the controller: the bind core gave View back, and the game's window binds come
    -- and go on its key, so a read now flips between two answers (up to 25 lines in one second in
    -- the owner's 0.21.0 log). View's press is heard at the game's Focus UI there (Pair.OnLogin),
    -- and its key is read again when gameplay has the controller back.
    if not viewOurs and not ns.Pad.Gameplay() then
        return
    end
    local layer, set = ns.BindAsk.Where("VW")
    -- (while View is ours, nothing of the game's is on it: a party is looked at anew when it changes)
    local action = viewOurs and "" or ns.Adapter.ViewAction()
    local way = Model.ViewWay(action, layer, select(2, ns.Adapter.WindowFocus()), ns.Pad.Gameplay())
    if way ~= "ours" and viewOurs then
        -- View has a job again: it is given back, and what its key does then is read
        release()
        return keys(confirm)
    elseif way == "ours" then
        if not viewOurs then
            viewOurs = ns.Adapter.TakeKey(hold, "VW")
            ready("View + Menu is ready: View is ours while no window is open (the key reads back as ours: " .. tostring(viewOurs) .. ")")
        end
        return
    end
    if way == "heard" and action ~= "" and not hooked[action] then
        hooked[action] = ns.Adapter.HookPress(action, function(down)
            ns.Call("PointerPair", viewDown, down)
        end)
    end
    if way == "heard" and (action == "" or hooked[action]) then
        ready(READY)
        return
    end
    -- At login the key reads a command of the game for a moment before the plan settles (the owner's log: "does not work
    -- now", then "is ready" a second later). So "rests" is told only when it still holds one frame after the plan is in.
    if not confirm then
        if ns.BindCore and ns.BindCore.plan and not pending then
            pending = true
            C_Timer.After(0, function()
                pending = false
                ns.Call("PointerPair", keys, true)
            end)
        end
        return
    end
    local rests = Model.Rests(layer, set)
    ready(rests)
    if saved.told ~= rests then
        saved.told = rests
        ns.Print(rests)
    end
end

-- View went down or up while it is ours, or Menu went down while View is down.
local function clicked(mouse, down)
    if mouse == "Menu" then
        if down then
            toggled("View + Menu")
        end
    elseif not fight() then
        if down then
            ns.Adapter.TakeKey(hold, "MN", "Menu")
        else
            -- Menu is the game's again, and View is ours again if it still has no job
            release()
            keys()
        end
    end
end

-- The dialogue view keeps every button while a talk shows (Screen/DialogueInput.lua), so it asks
-- here first, by our name for the button. True when the press was mouse mode's and turned it on
-- or off: Menu while View is held (the view has no job for View), or the button with the bind
-- Mouse Mode where the view has no job for that button.
function Pair.Heard(ourKey)
    if not Pair.on or fight() then
        return false
    end
    local bind = ns.Binds.Get("normal", 1, ourKey)
    local pair = ourKey == "MN" and ns.Registry.Get("controller.mouse_mode") == "View + Menu" and ns.Adapter.ViewHeld()
    if pair or not TALK[ourKey] and bind and bind.id == ns.Pointer.Bind().id then
        toggled((pair and "View + Menu" or "The bind Mouse Mode") .. ", in a talk,")
        return true
    end
    return false
end

function Pair.OnLogin()
    hold = CreateFrame("Button", "GamepadSuitePointerHold", UIParent)
    hold:RegisterForClicks("AnyDown", "AnyUp")
    hold:SetScript("OnClick", function(_, mouse, down)
        ns.Call("PointerPair", clicked, mouse, down)
    end)
    -- the frame that looks for View's let-go while Menu is ours for View + Menu
    watch = CreateFrame("Frame", "GamepadSuitePointerViewWatch")
    watch:Hide()
    watch:SetScript("OnUpdate", function()
        if not ns.Adapter.ViewHeld() then
            ns.Call("PointerPair", function()
                if not ns.Adapter.InCombat() then
                    release()
                    keys()
                end
            end)
            watch:Hide()
        end
    end)
    -- View's press while the game's Focus UI is its job: the game's call is heard after it ran
    ns.Adapter.OnFocusUI(function()
        ns.Call("PointerPair", viewDown, true)
    end)
    saved = ns.Registry.Store("pointer")
    keys()
    -- What the pair can do changes with its setting, the settings of the layers and sets (which
    -- binds can come in use), a bind, a window, a party, and the end of a fight. The addon or the
    -- game tells of each: nothing is looked at on a timer.
    ns.Listen("setting", "PointerPair", function(key)
        if key == "controller.mouse_mode" or key:find("^layers%.") then
            keys()
        end
    end)
    local function look()
        keys()
    end
    ns.Listen("bind", "PointerPair", look)
    ns.Listen("pad", "PointerPair", look)
    ns.Listen("pad:stack", "PointerPair", look)
    ns.On("PLAYER_REGEN_ENABLED", "PointerPair", look)
    -- (the game may take View for the party frames after it was ours: it is looked at anew)
    ns.On("GROUP_ROSTER_UPDATE", "PointerPair", function()
        if not fight() then
            release()
            keys()
        end
    end)
    ns.On("PLAYER_REGEN_DISABLED", "PointerPair", function()
        release()
        ready("the pair rests: a fight")
    end)
end
