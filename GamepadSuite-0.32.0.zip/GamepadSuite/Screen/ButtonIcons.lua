-- Button Icons: every button picture of the suite in the set the player picks on the Setup tab,
-- or in the game's own set for the controller in use (Auto). The pictures are the game's own
-- (Core/AdapterController.lua). A change shows at once on every picture.
local _, ns = ...

local Icons = ns.Module("ButtonIcons", { "padIcons" }, "Button Icons")
ns.ButtonIcons = Icons

local function apply()
    ns.Adapter.SetIconStyle(ns.Registry.Get("screen.button_symbols"))
    ns.Widgets.RefreshGlyphs()
end

function Icons.OnLogin()
    apply()
    ns.Listen("setting", "ButtonIcons", function(key)
        if key == "screen.button_symbols" then
            apply()
        end
    end)
end
