-- Bars, the fourth choice of the row Button Look: the on-screen buttons as one bar for each layer, all at once, in
-- place of the two groups. The bars stand as the controller does: No trigger on top in the middle, LT at the left and RT
-- at the right under it, then LT + RT at the left and LB + RB at the right (while the row LB + RB Layer is on). Each bar has the D-pad (left, up, down,
-- right) and then X, Y, A and B, as they sit on the controller from left to right, with a wider space and a faint line
-- between the two halves. The buttons are the buttons of Square (Screen/HudModel.lua, LOOKS.Bars): each shows what
-- that button does on that bar's layer, by the rule of every on-screen button (Model.Shown), with its cooldown, its
-- colors and its alerts. The bar of the layer in view has a gold ring with a soft glow and a gold name; the other bars
-- have a dark shade over each picture. Nothing moves or changes size when a trigger is held.
-- Beside the No trigger bar, small: LB, LS and View at its left, Menu, RS and RB at its right (each only on a controller
-- that has it), and past the bumpers L4, L5 and R4, R5 while the row Back Buttons on Bars is on. They show what they do
-- on the layer in view, as the buttons of the two groups do, and change with it.
-- Hide Empty Bars (start Off): a bar where none of the eight buttons shows anything folds away and the rows close up.
-- Screen/Hud.lua asks this file for the buttons (Bars.Buttons) and puts them as it puts every button; the names, the
-- lines, the ring and the shades follow each full draw (the message "screen:minis"). Group Spread is added to the
-- space between the two columns; Buttons X and Y Position and Button Size move and size them as the groups.
local _, ns = ...

local Bars = {}
ns.HudBars = Bars

local Theme = ns.Theme
local px = Theme.px

-- the buttons of a bar, left to right
Bars.ORDER = { "DL", "DU", "DD", "DR", "X", "Y", "A", "B" }
-- the small buttons beside the No trigger bar, from the bar outward: View or Menu, the stick, the bumper (as on the
-- controller), then the back grips
local SMALL = { left = { "VW", "LS", "LB", "L4", "L5" }, right = { "MN", "RS", "RB", "R4", "R5" } }
-- the rows Hide Empty Bars (start Off) and Back Buttons on Bars (start Off)
local HIDE, GRIPS = "screen.hide_empty_bars", "screen.bars_grips"
local SIDE_GAP = 12      -- between the bar and the first small button, in units
-- the layers of each row of bars, top to bottom, left to right (1 No trigger, 2 LT, 3 RT, 4 LT + RT, 5 LB + RB)
local ROWS = { { 1 }, { 2, 3 }, { 4, 5 } }
-- in units: between two buttons; between DR and X; round the buttons at the sides, the top and the bottom (the
-- controller button pictures reach 4 units under the buttons); the line of the name; between two rows and two columns;
-- the bottom edge of the lowest bar over the bottom of the on-screen buttons
local GAP, MID, PAD, TOP, BOTTOM, NAME, ROW_GAP, COLUMN_GAP, BASE = 8, 28, 8, 8, 12, 20, 10, 24, 4
local DIM, DIM_KEY = 0.4, 0.6         -- a bar that is not in view: the dark shade over each picture; the strength of its controller button pictures
local MARK, MARK_HIGH = 0.22, 0.6     -- the faint line between the halves: its strength, its height as a part of a button
local GLOW, GLOW_STRENGTH, RING_DARK = 12, 0.4, 0.6
-- the soft edge of the square half of the shadow art fades over its outer 10 of 64 pixels; the file is 128 x 64
local SHADOW = "Interface\\AddOns\\GamepadSuite\\Art\\HudShadow.tga"
local U, V = 10 / 128, 10 / 64

-- How large one bar is, in units: wide and high (with the line of its name).
function Bars.Size(look)
    return 8 * look.main + 6 * GAP + MID + 2 * PAD, NAME + TOP + look.main + BOTTOM
end

-- Where each bar that shows stands: its left edge and its top edge (over its name) in units from the bottom middle of
-- the on-screen buttons, y up. shown: bar -> true for each bar that shows. spread: the row Group Spread. No trigger
-- stays on top; a bar keeps its side; a row with no bar left goes and the rows under it move up, so the bottom middle,
-- where the form picture is (Screen/HudForm.lua), stays clear.
function Bars.Places(look, shown, spread)
    local width, height = Bars.Size(look)
    local column = math.max(4, COLUMN_GAP + (spread or 0))
    local places, top = {}, BASE + #ROWS * height + (#ROWS - 1) * ROW_GAP
    for _, row in ipairs(ROWS) do
        local any = false
        for c, layer in ipairs(row) do
            if shown[layer] then
                any = true
                places[layer] = { left = #row == 1 and -width / 2 or c == 1 and -width - column / 2 or column / 2, top = top }
            end
        end
        if any then
            top = top - height - ROW_GAP
        end
    end
    return places, width, height
end

-- A row's value; its start value while the settings do not have the row.
local function setting(key, start)
    if ns.Registry.Has(key) then
        return ns.Registry.Get(key)
    end
    return start
end

-- One log line of each kind in a session, so the owner's saved file tells what the fold did.
local told = {}
local function tell(kind, text)
    if not told[kind] then
        told[kind] = true
        ns.Log.Add("screen", "Bars: " .. text)
    end
end

local block            -- the frame of the bars, at the bottom middle of the on-screen buttons
local names, marks = {}, {}
local ring             -- the ring and the glow round the bar in view
local places = {}      -- where the bars of the last full draw stand (Bars.Places)

-- Eight pieces of the soft edge round a frame, out units wide, in one color: the four corners and the four sides of
-- the shadow art, with no middle, so the glow lies round the bar and not under it.
local CORNERS = { { "BOTTOMRIGHT", "TOPLEFT", 0, U, 0, V }, { "BOTTOMLEFT", "TOPRIGHT", 0.5 - U, 0.5, 0, V },
    { "TOPRIGHT", "BOTTOMLEFT", 0, U, 1 - V, 1 }, { "TOPLEFT", "BOTTOMRIGHT", 0.5 - U, 0.5, 1 - V, 1 } }
local SIDES = { { "BOTTOMLEFT", "TOPLEFT", "BOTTOMRIGHT", "TOPRIGHT", U, 0.5 - U, 0, V, "SetHeight" },
    { "TOPLEFT", "BOTTOMLEFT", "TOPRIGHT", "BOTTOMRIGHT", U, 0.5 - U, 1 - V, 1, "SetHeight" },
    { "TOPRIGHT", "TOPLEFT", "BOTTOMRIGHT", "BOTTOMLEFT", 0, U, V, 1 - V, "SetWidth" },
    { "TOPLEFT", "TOPRIGHT", "BOTTOMLEFT", "BOTTOMRIGHT", 0.5 - U, 0.5, V, 1 - V, "SetWidth" } }
local function glow(frame, out, r, g, b, a)
    local function piece(left, right, top, bottom)
        local texture = frame:CreateTexture(nil, "BACKGROUND")
        texture:SetTexture(SHADOW)
        texture:SetTexCoord(left, right, top, bottom)
        texture:SetVertexColor(r, g, b, a)
        return texture
    end
    for _, c in ipairs(CORNERS) do
        local texture = piece(c[3], c[4], c[5], c[6])
        texture:SetSize(px(out), px(out))
        texture:SetPoint(c[1], frame, c[2])
    end
    for _, s in ipairs(SIDES) do
        local texture = piece(s[5], s[6], s[7], s[8])
        texture:SetPoint(s[1], frame, s[2])
        texture:SetPoint(s[3], frame, s[4])
        texture[s[9]](texture, px(out))
    end
end

-- A line of 1 unit round a frame, by units outside its edge.
local LINES = { { "TOPLEFT", "TOPRIGHT", "SetHeight" }, { "BOTTOMLEFT", "BOTTOMRIGHT", "SetHeight" },
    { "TOPLEFT", "BOTTOMLEFT", "SetWidth" }, { "TOPRIGHT", "BOTTOMRIGHT", "SetWidth" } }
local function around(frame, by, r, g, b, a)
    for _, side in ipairs(LINES) do
        local texture = frame:CreateTexture(nil, "BORDER")
        texture:SetColorTexture(r, g, b, a)
        for i = 1, 2 do
            local point = side[i]
            texture:SetPoint(point, frame, point, (point:find("LEFT") and -1 or 1) * px(by), (point:find("TOP") and 1 or -1) * px(by))
        end
        texture[side[3]](texture, px(1))
    end
end

local function make(parent)
    block = CreateFrame("Frame", nil, parent)
    block:SetSize(px(1), px(1))
    block:SetPoint("CENTER", parent, "BOTTOM")
    -- under the buttons, which are the frame's other children
    block:SetFrameLevel(parent:GetFrameLevel())
    ring = CreateFrame("Frame", nil, block)
    ring:SetFrameLevel(parent:GetFrameLevel())
    glow(ring, GLOW, Theme.Color("gold", GLOW_STRENGTH))
    around(ring, 0, Theme.Color("gold", 0.9))
    around(ring, 1, 0, 0, 0, RING_DARK)
end

-- The buttons of every bar, as Model.Buttons gives those of the two groups: { key, layer, group, x, y, main, size,
-- bind }, then the small ones beside the No trigger bar (no layer: they show the layer in view). find, game: as there.
-- parent: the frame of the on-screen buttons. layer: the layer in view. keys: our key names on the controller in use.
function Bars.Buttons(find, game, look, parent, layer, keys)
    if not block then
        make(parent)
    end
    -- What each button of each bar shows, and the bars that show. With Hide Empty Bars on, a bar where none of the eight
    -- shows anything (no bind of ours, no game action) folds away, as the game's own gamepad bar hides an empty bar
    -- (Blizzard_GamepadActionBars/ActionBar.lua 155-205); No trigger always shows. None of it hangs on the layer in
    -- view, so nothing moves when a trigger is held. While the pointer carries a thing to drop (Screen/Drop.lua) every
    -- bar shows, so the drop has a place to land.
    local five = ns.Registry.Get("layers.hold_lb_rb_set") and true or false
    local hide, carrying = setting(HIDE, false), ns.Drop.Carrying()
    local binds, shown, empty = {}, {}, {}
    for bar = 1, five and 5 or 4 do
        local any = bar == 1
        binds[bar] = {}
        for i, key in ipairs(Bars.ORDER) do
            binds[bar][i] = ns.HudModel.Shown(find, game, bar, key)
            any = any or binds[bar][i] ~= nil
        end
        shown[bar] = any or not hide or carrying
        if not any and hide then
            empty[#empty + 1] = ns.BindsModel.LAYERS[bar]
        end
    end
    if #empty > 0 and carrying then
        tell("drop", "the pointer carries a thing to drop, so " .. table.concat(empty, ", ") .. " show until it lands or is let go.")
    elseif #empty > 0 then
        tell("fold", "Hide Empty Bars folded " .. table.concat(empty, ", ") .. ": none of their buttons has a bind of yours or a game action.")
    end
    places = Bars.Places(look, shown, ns.Registry.Get("screen.spread"))
    local slots, size = {}, look.main
    for bar = 1, 5 do
        local place = places[bar]
        if place then
            for i, key in ipairs(Bars.ORDER) do
                slots[#slots + 1] = { key = key, layer = bar, group = block, main = true, size = size,
                    x = place.left + PAD + size / 2 + (i - 1) * (size + GAP) + (i > 4 and MID - GAP or 0),
                    y = place.top - NAME - TOP - size / 2, bind = binds[bar][i] }
            end
        end
    end
    local has, top, small = {}, places[1], look.small
    for _, key in ipairs(keys or {}) do
        has[key] = true
    end
    -- the back grips show while their row is on, whatever the controller picture (a Steam Deck under Steam Input often
    -- says it is an Xbox pad), and never while it is off
    local grips = setting(GRIPS, false)
    for _, key in ipairs({ "L4", "L5", "R4", "R5" }) do
        has[key] = grips
    end
    for side, list in pairs(SMALL) do
        local sign, edge = side == "left" and -1 or 1, Bars.Size(look) / 2 + SIDE_GAP + small / 2
        for i, key in ipairs(list) do
            if has[key] then
                slots[#slots + 1] = { key = key, group = block, main = false, size = small, x = sign * (edge + (i - 1) * (small + GAP)),
                    y = top.top - NAME - TOP - size / 2, bind = ns.HudModel.Shown(find, game, layer, key) }
            end
        end
    end
    return slots
end

-- After each full draw: the names, the lines between the halves, the ring round the bar in view, and the dark shade
-- over the pictures of the other bars (their controller button pictures a little faint). With another look, none of it shows.
local function decorate(_, _, look, layer, _, buttons)
    if not block then
        return
    end
    block:SetShown(look.bars == true)
    if not look.bars then
        return
    end
    -- (the bars of the full draw just made: Bars.Buttons)
    local width, height = Bars.Size(look)
    local size = look.main
    for bar = 1, 5 do
        local place = places[bar]
        names[bar] = names[bar] or Theme.Text(block, "tiny", "cream")
        marks[bar] = marks[bar] or block:CreateTexture(nil, "ARTWORK")
        names[bar]:SetShown(place ~= nil)
        marks[bar]:SetShown(place ~= nil)
        if place then
            names[bar]:SetText(ns.BindsModel.LAYERS[bar])
            names[bar]:SetTextColor(Theme.Color(bar == layer and "gold" or "cream", bar == layer and 1 or 0.7))
            names[bar]:ClearAllPoints()
            names[bar]:SetPoint("LEFT", block, "CENTER", px(place.left + PAD), px(place.top - NAME / 2))
            marks[bar]:SetColorTexture(Theme.Color("cream", MARK))
            marks[bar]:SetSize(px(1), px(size * MARK_HIGH))
            marks[bar]:ClearAllPoints()
            marks[bar]:SetPoint("CENTER", block, "CENTER", px(place.left + PAD + 4 * size + 3 * GAP + MID / 2), px(place.top - NAME - TOP - size / 2))
        end
    end
    local place = places[layer]
    ring:SetShown(place ~= nil)
    if place then
        ring:ClearAllPoints()
        ring:SetPoint("TOPLEFT", block, "CENTER", px(place.left), px(place.top - NAME))
        ring:SetPoint("BOTTOMRIGHT", block, "CENTER", px(place.left + width), px(place.top - height))
    end
    for _, b in pairs(buttons) do
        if b.layer then
            if not b.dim then
                b.dim = b.over:CreateTexture(nil, "ARTWORK", nil, -1)
                b.dim:SetAllPoints(b)
                b.dim:SetColorTexture(0, 0, 0, DIM)
            end
            b.dim:SetShown(b.layer ~= layer)
            if b.glyph then
                b.glyph:SetAlpha(b.layer ~= layer and DIM_KEY or 1)
            end
        end
    end
end
ns.Listen("screen:minis", "HudBars", decorate)

-- A change of either row shows the buttons over the settings window for a moment while the look is Bars, as the rows
-- of the page Layout do (Screen/Hud.lua).
ns.Listen("setting", "HudBars", function(key)
    if (key == HIDE or key == GRIPS) and ns.HudModel.Look(ns.Registry.Get("screen.look")).bars then
        ns.Screen.Peek("Screen", ns.Screen.Draw)
    end
end)
