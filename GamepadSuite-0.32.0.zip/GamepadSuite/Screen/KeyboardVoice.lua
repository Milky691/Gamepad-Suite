-- Voice to text on the chat keyboard: on a chat line, hold LB and speak; at the let-go the words that the game's
-- voice chat writes down for the player come into the line, to send with Send (the owner, 2026-10-17: "hold down LB
-- when chat window is open to voice to text"). The game has no call that turns speech into text for an addon. Its
-- voice chat writes what each member says into the chat, as a line of the kind VOICE_TEXT, while transcription is
-- on (CHAT_MSG_VOICE_TEXT: Blizzard_APIDocumentationGenerated/ChatInfoDocumentation.lua 2566 to 2580). So a hold:
--   1. needs a voice channel in use, the game's speech to text on, and voice chat not muted (Core/AdapterVoice.lua);
--   2. turns transcription on if it is off, and opens the microphone while LB is held: an addon cannot press the
--      game's push-to-talk key, but it can set the other way to talk, the open microphone;
--   3. at the let-go puts the way to talk back, and for LISTEN seconds takes the player's own lines into the line.
-- The event is heard only while a hold or its LISTEN seconds last, and one timer ends that. The saved file says how
-- many lines of the player's came back: that tells in one try if the game writes down the player's own words.
local _, ns = ...

local Voice = {}
ns.KeyboardVoice = Voice

local LISTEN = 10
local WHY = {
    allowed = "Voice to text is not allowed in this voice chat.",
    setting = "Voice to text needs the game's speech to text: turn it on in Options, under Accessibility.",
    channel = "Voice to text works in a voice channel. Join one first.",
    muted = "Voice to text: your voice chat is muted.",
}
local talking, before   -- LB is held; the way to talk before the hold
local listening = false -- the event is heard (a hold, or its LISTEN seconds after)
local holds, heard = 0, 0   -- holds so far (a newer hold makes an older end do nothing); the player's lines in this one

-- The game has the calls for it (the login checks of Core/AdapterVoice.lua).
function Voice.Can()
    local results = ns.Adapter.Results and ns.Adapter.Results() or {}
    return (results.voiceText and results.voiceTalk) and true or false
end

-- LB is held now: the keyboard's hint says so.
function Voice.Talking()
    return talking == true
end

local function listen()
    listening = true
    ns.On("CHAT_MSG_VOICE_TEXT", "KeyboardVoice", function(text, name)
        if ns.Adapter.IsMyVoiceLine(text, name) then
            heard = heard + 1
            ns.Keyboard.AddText(text)
        end
    end)
end

local function stop(hold)
    if listening and hold == holds then
        listening = false
        ns.Off("CHAT_MSG_VOICE_TEXT", "KeyboardVoice")
        ns.Keyboard.Note("voice to text: " .. heard .. " line(s) of the player's own words came back within " .. LISTEN .. " s of the let-go")
    end
end

-- LB went down on a chat line.
function Voice.Down()
    if talking or not Voice.Can() then
        return
    end
    local why, channel, on = ns.Adapter.VoiceText()
    why = why or (ns.Adapter.VoiceMuted() and "muted") or nil
    if why then
        ns.Print(WHY[why])
        return
    end
    if not on then
        ns.Adapter.SetVoiceText(channel, true)
    end
    talking, before = true, ns.Adapter.VoiceTalk(true)
    holds, heard = holds + 1, 0
    listen()
    ns.Keyboard.Redraw()
end

-- LB came up, or the keyboard closed (closed: no more words come in).
function Voice.Up(closed)
    if talking then
        ns.Adapter.VoiceTalk(false, before)
        talking, before = false, nil
        local hold = holds
        C_Timer.After(LISTEN, function()
            ns.Call("KeyboardVoice", stop, hold)
        end)
        ns.Keyboard.Redraw()
    end
    if closed then
        stop(holds)
        holds = holds + 1
    end
end
