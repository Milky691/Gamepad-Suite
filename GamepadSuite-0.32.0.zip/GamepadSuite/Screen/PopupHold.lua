-- The holds of the top pop-up (Screen/Popup.lua), shared by every item on it: an item gives its acts, and this file
-- draws their hints, hears the controller, and runs an act at the end of its hold (the pack: P42_popups_fix.md).
-- An act: { key ("Y" first, "X" second; A and B never), words, go (once the hold is full), fight, steps (the press
-- grammar's three steps), again (after its let-go) (each words or a function(item)), can(item) (false: no hint now),
-- done(item, clicked) (false back: it did not take; clicked: our secure button did it), check(item) (one frame later:
-- false when it did not take), press, secure, fallback ("press", else off for the session with line in the chat),
-- after (words for 2 seconds once it took: "Invited"), log }.
-- The hold grammar is the roll card's (Screen/RollsModel.lua): no key is taken, a tap is the button's own bind, hold
-- 1 second and let go within 2.5. A plain frame of ours hears the controller while such an item shows, out of combat,
-- and hands each press on (its switch is set out of combat; until it reads as set the frame never shows). Not in the
-- first 0.4 seconds of an item, not with LT, RT, LB or RB held. A refusal at the let-go (ADDON_ACTION_BLOCKED or
-- ADDON_ACTION_FORBIDDEN names the addon) is the act's fallback.
-- The press grammar (a cast from a secure button), as Destroy Gray Item's: hold 1 second, let go, press once more.
-- The hold is heard as the hold grammar's: no key is taken, a tap stays the button's bind. Only the let-go of a full
-- hold arms the act: then the act's button is a key bind of ours (Screen/PopupKey.lua) until that press, and the press
-- runs the act inside the press down, or clicks the act's secure button. The key goes back at that press, when the
-- item goes (its seconds begin again at the arming), and when combat starts.
-- Y has one owner at a time: a part of ours that holds it as a key bind first (Destroy Gray Item). Then, and for X
-- while a loot roll card shows, the hint is dim and no hold is heard. In combat the hints are dim with fight words.
local _, ns = ...

local Hold = {}
ns.PopupHold = Hold

local Rules = ns.RollsModel

local ear, ready      -- the frame that hears the controller; true once it hands each press on
local item, since     -- the item with acts that shows, and when it showed
local held            -- { act, at, full } while a hold runs
local armed           -- the act of the press grammar whose hold was full and let go: the next press runs it
local told = {}
local tick, sync

local function note(kind, text)
    if not told[kind] then
        told[kind] = true
        ns.Log.Add("popups", text)
    end
end

local function fight()
    return ns.fightStarted or ns.Adapter.InCombat()
end

local function rolls()
    local ok, list = pcall(ns.Adapter.Rolls)
    return ok and type(list) == "table" and #list > 0
end

-- Why the act cannot be held now ("fight", "ready", "taken", "roll"), or nil.
local function blocked(act)
    if fight() then
        return "fight"
    elseif not ready and armed ~= act then
        return "ready"
    elseif ns.PopupKey.Others(act.key) then
        return "taken"
    elseif act.key == "X" and rolls() then
        return "roll"
    end
end

local function offered(act)
    return not act.off and (not act.can or act.can(item) and true or false)
end

-- The act of the press grammar whose hold was full and let go, while it is still offered: its press comes next.
function Hold.Armed()
    return armed and item and offered(armed) and armed or nil
end

-- The hold ends: the bar goes, no script runs each frame, and the item may go if its time ran out.
local function stop()
    held = nil
    ear:SetScript("OnUpdate", nil)
    ns.Popup.Hold(0)
    ns.Popup.Keep(false)
end

-- The hints of the item that shows, and the frame that hears the controller.
function sync()
    if not item then
        ear:Hide()
        return
    end
    local entries, hears = {}, false
    for _, act in ipairs(item.acts) do
        if offered(act) then
            local why = blocked(act)
            local text = held and held.act == act and held.full and act.go or armed == act and act.again
                or why == "fight" and act.fight or act.press and act.steps or act.words
            if type(text) == "function" then
                text = text(item)
            end
            entries[#entries + 1] = { keys = { act.key }, text = text, off = why ~= nil }
            hears = hears or (not why and armed ~= act)
        end
    end
    ns.Popup.Hints(entries)
    ear:SetShown(hears and ready and true or false)
end

-- The act runs. One frame later it is judged: a refusal of the game (ADDON_ACTION_BLOCKED or ADDON_ACTION_FORBIDDEN
-- names this addon) or an act that says it did not take is the act's fallback; else the act's own words stand on
-- the pop-up for 2 seconds (after), or the owner has made the pop-up go.
local running, refused = false, nil
local function run(act, it, clicked)
    running, refused = true, nil
    local ok, took = pcall(act.done, it, clicked)
    C_Timer.After(0, function()
        running = false
        ns.Call("PopupHold", function()
            if ok and took ~= false and not refused and not (act.check and act.check(it) == false) then
                note("ran " .. (act.log or act.key), "an act ran: " .. (act.log or act.key) .. (act.press and " (at a press)" or " (at a let-go)"))
                if act.after and item then
                    ns.Popup.Done(act.after)
                end
                return
            end
            local why = refused and "the game refused " .. refused or not ok and tostring(took) or "it did not take"
            if act.fallback == "press" and not act.press then
                act.press = true
                note("press " .. (act.log or act.key), "an act at a let-go did not work (" .. why .. "): it needs a press from now on")
                ns.PopupKey.Later()
            else
                act.off = true
                note("off " .. (act.log or act.key), "an act did not work (" .. why .. "): it is off for this session")
                if act.line then
                    ns.Print(act.line)
                end
            end
            sync()
        end)
    end)
end

-- The act of the hold grammar that a press of this button starts now, or nil.
local function starts(button)
    if not item or not Rules.Ready(GetTime(), since) then
        return nil
    end
    local lt, rt, lb, rb = ns.Adapter.Held()
    for _, act in ipairs(not (lt or rt or lb or rb) and item.acts or {}) do
        if act.key == button and armed ~= act and offered(act) and not blocked(act) then
            return act
        end
    end
end

-- A button went down, as the frame heard it (the hold grammar). An act's button starts a hold; another button ends one.
local function heard(button)
    if held then
        if button ~= held.act.key then
            stop()
            sync()
        end
        return
    end
    local act = starts(button)
    if act then
        held = { act = act, at = GetTime() }
        ns.Popup.Keep(true)
        ear:SetScript("OnUpdate", tick)
    end
end

-- Each frame during a hold: the bar grows; at one second the hint says to let go. The let-go after a full hold runs
-- the act, or for the press grammar arms it: the key is taken one frame later, and the item's seconds begin again (a
-- player who holds wants it, as at Destroy Gray Item). A hold that goes on too long ends with nothing.
local function update()
    local act, seconds = held.act, GetTime() - held.at
    local stage = Rules.Stage(seconds)
    if not ns.Adapter.ButtonDown(act.key) then
        local it = item
        stop()
        if stage == "ready" and act.press then
            armed = act
            ns.Popup.Renew()
            ns.PopupKey.Later()
        elseif stage == "ready" then
            run(act, it)
        end
        sync()
    elseif stage == "long" then
        stop()
        sync()
    else
        local full = stage == "ready"
        if full ~= (held.full or false) then
            held.full = full
            sync()
        end
        ns.Popup.Hold(seconds / Rules.HOLD)
    end
end

-- The script, each frame during a hold. A fault here would come every frame: it is logged once, and the hold stops.
function tick()
    if not ns.Call("PopupHold", update) then
        ns.Call("PopupHold", stop)
    end
end

-- The press grammar's plain key went down (Screen/PopupKey.lua): the armed act runs inside that press, and one frame
-- later the key goes back.
function Hold.Pressed(down)
    local taking = ns.PopupKey.Taking()
    local act = taking and taking.act
    if down and act and item and armed == act then
        armed = nil
        run(act, item)
        ns.PopupKey.Later()
    end
end

-- The press clicked the act's secure button: one frame later the key goes back and the act's own part runs.
function Hold.Clicked(act)
    local it = item
    armed = nil
    C_Timer.After(0, function()
        ns.Call("PopupHold", function()
            ns.PopupKey.Stop()
            run(act, it, true)
        end)
    end)
end

-- What the pop-up shows changed: a hold stops, and the acts of the new item are looked at.
local function changed(shown)
    if held then
        stop()
    end
    armed = nil
    item = shown and shown.acts and shown or nil
    since = GetTime()
    for _, act in ipairs(item and item.acts or {}) do
        ns.PopupKey.Watch(act.secure)
    end
    ns.PopupKey.Stop()
    sync()
end

-- Started by the pop-up at login (Screen/Popup.lua).
function Hold.Start()
    ear = CreateFrame("Frame", nil, UIParent)
    ear:SetFrameStrata("BACKGROUND")
    ear:SetSize(1, 1)
    ear:SetPoint("TOPLEFT")
    ear:Hide()
    -- "true" as well: the game's own flyout says so for a press it hands on (Screen/Rolls.lua)
    ear:SetScript("OnGamePadButtonDown", function(_, button)
        ns.Call("PopupHold", heard, ns.Adapter.NAME[button])
        return true
    end)
    ns.PopupKey.Start()
    -- The game sets the frame's switches out of combat only. Until the one that hands each press on reads as set,
    -- the frame never shows: it would keep every press.
    ns.Queue.Run("PopupHold", function()
        ear:EnableGamePadButton(true)
        ready = ns.Adapter.HandSticksOn(ear)
        note("ready", "the frame that hears the controller for the pop-up's holds hands each press on: " .. tostring(ready))
        sync()
    end)
    ns.Listen("popup:shown", "PopupHold", changed)
    -- combat: a hold ends, the hints read their fight words (the key goes back: Screen/PopupKey.lua)
    ns.On("PLAYER_REGEN_DISABLED", "PopupHold", function()
        armed = nil
        if held then
            stop()
        end
        sync()
    end)
    ns.On("PLAYER_REGEN_ENABLED", "PopupHold", sync)
    -- (rare events: heard always, kept only while an act runs)
    local function blockedCall(addon, call)
        if running and addon == ns.addon then
            refused = tostring(call)
        end
    end
    ns.On("ADDON_ACTION_BLOCKED", "PopupHold", blockedCall)
    ns.On("ADDON_ACTION_FORBIDDEN", "PopupHold", blockedCall)
    if ns.Adapter.OnRollsChanged then
        ns.Adapter.OnRollsChanged(function()
            ns.Call("PopupHold", sync)
        end)
    end
end

-- An owner changed what its acts offer (the group changed, a hand lost its weapon): the hints are drawn again.
function Hold.Sync()
    if item then
        sync()
    end
end

-- True when a press of this button ("Y", "X") now is a hold of the top pop-up, or goes to the pop-up's own key bind
-- (Auto/LookBehind.lua asks: it then does not turn the camera).
function Hold.Holds(button)
    if held then
        return held.act.key == button
    end
    local taking = ns.PopupKey.Taking()
    return taking ~= nil and taking.act.key == button or armed ~= nil and armed.key == button or starts(button) ~= nil
end
