-- The rules of the loot roll buttons, with no game calls: which controller button is which
-- choice, which roll is on the card, how the D-pad changes it, when a hold makes a roll, the
-- card's words, and which roll is passed on by itself.
local _, ns = ...

local Model = {}

-- The choice of each button. Greed stands for the game's Transmog button too, on a roll that has
-- that one in the place of Greed.
Model.CHOICE = { A = "need", X = "greed", B = "pass" }
-- The words beside each button's picture on the card of the roll in focus.
Model.LABEL = { A = "Need", X = "Greed", B = "Pass" }
-- D-pad up and down: one roll up or down on the screen.
Model.STEP = { DU = -1, DD = 1 }

-- A choice counts only when its roll has had the focus for this many seconds. The focus can come
-- to a roll by itself: a new roll shows, or the roll in focus goes and the next one takes its
-- place. A press that was meant for the roll before, or for a jump, must not roll on the new one.
Model.SETTLE = 0.4

-- A choice is a hold: the button's own bind acts at the press as always, so a tap casts a spell
-- and makes no roll. The roll is made at the let-go, and only when the button was down for HOLD
-- seconds or more and for no more than LIMIT: a shorter press was for the bind, and a longer hold
-- was for a spell that casts again and again while its button is held.
Model.HOLD = 1
Model.LIMIT = 2.5

-- The words on the card at rest, and while a let-go makes the roll.
Model.WORDS = "Hold to roll"
Model.LET_GO = "Let go to roll"
-- The words on the card while A, X and B are not for a roll, by the reason.
Model.REST = {
    window = "A window has A, X and B now",
    wheel = "Close the wheel to roll",
    mouse = "Mouse mode is on: click the game's roll",
    keyboard = "Close the keyboard to roll",
}
-- Which roll of how many is on the card, when there is more than one.
Model.COUNT = "%d of %d"

-- The number on the item's picture: the stack's size, as the game's own card prints it
-- (GroupLootFrame.lua 333 to 338), and nothing for one. The line beside the picture: the game's
-- reason on a Need it does not allow, and nothing while Need is allowed.
function Model.Stack(roll)
    return roll.count and roll.count > 1 and tostring(roll.count) or ""
end

function Model.Reason(roll)
    return not roll.need and roll.reason or ""
end

-- A hold by the seconds the button has been down: "short" (a let-go does nothing), "ready" (a
-- let-go makes the roll) or "long" (the hold is over, and nothing is rolled).
function Model.Stage(seconds)
    return seconds < Model.HOLD and "short" or seconds <= Model.LIMIT and "ready" or "long"
end

-- The place of the roll in focus in the list of rolls (top of the screen first; each has id).
-- focus is the id of the roll that had the focus, and was its place then. The focus stays on its
-- roll when other rolls come or go. When its own roll is gone, the roll now at that place has
-- it, or the last one. nil with no roll.
function Model.Place(rolls, focus, was)
    for place, roll in ipairs(rolls) do
        if roll.id == focus then
            return place
        end
    end
    if #rolls == 0 then
        return nil
    end
    return math.max(1, math.min(was or 1, #rolls))
end

-- The place after a step of the D-pad. Down from the last roll is the first one, and up from the
-- first is the last.
function Model.Move(place, step, count)
    return (place - 1 + step) % count + 1
end

-- True when a choice counts: the roll has had the focus since `since`, long enough.
function Model.Ready(now, since)
    return now - since >= Model.SETTLE
end

-- Pass on Gear You Cannot Wear (Auto/PassUnusable.lua): a roll for armor or a weapon that the
-- character's class can never learn is passed on. The game's numbers: item class 2 is a weapon
-- and 4 armor. Armor 1 to 4 is cloth, leather, mail and plate, and 6 a shield. Only these kinds
-- are judged. A ring, a cloak, a relic, a fishing pole, a recipe, a bag or a quest item never is.
local WEAPON, ARMOR = 2, 4
local CLOTH, LEATHER, MAIL, PLATE, SHIELD = 1, 2, 3, 4, 6
local AXE, AXE2, BOW, GUN, MACE, MACE2, POLE, SWORD, SWORD2 = 0, 1, 2, 3, 4, 5, 6, 7, 8
local STAFF, FIST, DAGGER, THROWN, XBOW, WAND = 10, 13, 15, 16, 18, 19
Model.JUDGED = { [ARMOR] = { CLOTH, LEATHER, MAIL, PLATE, SHIELD },
    [WEAPON] = { AXE, AXE2, BOW, GUN, MACE, MACE2, POLE, SWORD, SWORD2, STAFF, FIST, DAGGER, THROWN, XBOW, WAND } }
-- What each class can learn at some level, by the classic rules, under the game's name of the
-- class. A class that is not here (a new one on this game) is never judged.
Model.LEARNS = {
    WARRIOR = { [ARMOR] = { CLOTH, LEATHER, MAIL, PLATE, SHIELD },
        [WEAPON] = { AXE, AXE2, BOW, GUN, MACE, MACE2, POLE, SWORD, SWORD2, STAFF, FIST, DAGGER, THROWN, XBOW } },
    PALADIN = { [ARMOR] = { CLOTH, LEATHER, MAIL, PLATE, SHIELD }, [WEAPON] = { AXE, AXE2, MACE, MACE2, POLE, SWORD, SWORD2 } },
    HUNTER = { [ARMOR] = { CLOTH, LEATHER, MAIL },
        [WEAPON] = { AXE, AXE2, BOW, GUN, POLE, SWORD, SWORD2, STAFF, FIST, DAGGER, THROWN, XBOW } },
    SHAMAN = { [ARMOR] = { CLOTH, LEATHER, MAIL, SHIELD }, [WEAPON] = { AXE, AXE2, MACE, MACE2, STAFF, FIST, DAGGER } },
    ROGUE = { [ARMOR] = { CLOTH, LEATHER }, [WEAPON] = { BOW, GUN, MACE, SWORD, FIST, DAGGER, THROWN, XBOW } },
    DRUID = { [ARMOR] = { CLOTH, LEATHER }, [WEAPON] = { MACE, MACE2, STAFF, FIST, DAGGER } },
    PRIEST = { [ARMOR] = { CLOTH }, [WEAPON] = { MACE, STAFF, DAGGER, WAND } },
    MAGE = { [ARMOR] = { CLOTH }, [WEAPON] = { SWORD, STAFF, DAGGER, WAND } },
    WARLOCK = { [ARMOR] = { CLOTH }, [WEAPON] = { SWORD, STAFF, DAGGER, WAND } },
}
-- The chat line for a roll that was passed on.
Model.PASSED = "Passed on %s. Your class cannot use it."

local function has(list, value)
    for _, each in ipairs(list or {}) do
        if each == value then
            return true
        end
    end
    return false
end

-- True when the roll on item is passed on, and a few words for the log. item: class and sub (the
-- game's numbers), worn (it goes in a place on the character), canNeed (the roll allows Need) and
-- usable (the game says the character can use it now). class: the game's name of the class.
-- Both the list and the game must say no: the list alone does not know a rule of this game, and
-- the game alone says no to gear that the character learns to wear at a higher level.
function Model.Unusable(item, class)
    if not (item.worn and has(Model.JUDGED[item.class], item.sub)) then
        return false, "not armor or a weapon that is judged"
    elseif not Model.LEARNS[class] then
        return false, "no list for the class " .. tostring(class)
    elseif has(Model.LEARNS[class][item.class], item.sub) then
        return false, "the class can learn it"
    elseif item.usable ~= false and item.canNeed ~= false then
        return false, "the game does not say that the character cannot use it"
    end
    return true, "the class can never learn it"
end

if ns then
    ns.RollsModel = Model
end
return Model
