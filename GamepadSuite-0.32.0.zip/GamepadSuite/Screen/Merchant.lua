-- Merchant View: the suite's own view of a vendor, in place of the game's vendor window, in the
-- dialogue view's band at the foot of the screen: the NPC's portrait at the left, the tabs Buy,
-- Sell and Buyback, and big item cards. The D-pad picks a card, A buys one lot (a hold buys a
-- stack), sells or buys back, X sells the junk (the gray items, then the stacks marked by Mark
-- Junk), Y repairs everything where the vendor repairs, a hold of Y on the Sell tab marks the card
-- as junk or takes the mark off, LB and RB change the tab, B closes the vendor. Its other files: MerchantModel.lua (the rules),
-- MerchantDraw.lua and MerchantCards.lua (the frames), MerchantInput.lua (the buttons),
-- MerchantWatch.lua (what the game says), Core/AdapterMerchant.lua. The checklist is
-- build_plan/packs/P18_merchant_view.md.
--
-- How it stays out of the game's way:
--   The view has a vendor only with the row on, out of combat, while a controller is in use, and
--   with no fault in this session. Then, at MERCHANT_SHOW, the game's interaction manager does
--   not hear the show of its windows for one frame, so the game's vendor window stays shut
--   (Core/AdapterMerchant.lua has the proof); it hears it again one frame later, and at every way
--   out. When the game's window shows all the same, the view stays away and is off until /reload.
--   Combat and a controller that goes away close the view at once and end the vendor talk: every
--   button is free, and the next vendor has the game's own window.
--   While a window or a question of the game has the controller, the view steps aside.
--   Nothing is shown, hidden or asked of the game inside a press: it is noted, and done one frame
--   later, from a timer.
--   A fault closes the view, gives everything back and turns it off until the next login.
--   No work is done while no vendor is open, and a script runs on each frame only for a fade or
--   during a hold of A.
-- The log (kind "merchant") says in which order the game told of the vendor, if its window
-- stayed away, and what each press did.
local _, ns = ...

local Merchant = ns.Module("Merchant", { "merchantView" }, "Merchant View")
ns.Merchant = Merchant

local Model, Draw, Input, Watch = ns.MerchantModel, ns.MerchantDraw, ns.MerchantInput, ns.MerchantWatch

local ROW, SIZE, MARK = "windows.merchant_view", "windows.dialogue_size", "helpers.mark_junk"
local root, input          -- the view's frame, and its child that hears the controller
local built = false        -- the parts of the view are made at the first vendor
local shop                 -- the vendor in view (Model.New); nil with none
local wait                 -- a vendor that the game opened and the view has not drawn yet
local open = false         -- a vendor is open: between the game's MERCHANT_SHOW and MERCHANT_CLOSED
local held = false         -- the game's manager does not hear the show of its windows now
local shownAt              -- when the game's own vendor window last showed
local off                  -- why the view never has a vendor in this session; nil while it can
local notes, told = 0, {}  -- the lines written to the log, and the names of those written once

-- A line for the saved file, eighty at most. A line with a name (once) is written one time only.
local function note(text, once)
    if notes < 80 and not (once and told[once]) then
        notes, told[once or 0] = notes + 1, true
        ns.Log.Add("merchant", text)
    end
end

local function coins(copper)
    return ns.Adapter.CoinText(copper)
end

-- True while the view has a vendor (the rest of the suite can ask).
function Merchant.IsOpen()
    return shop ~= nil
end

-- True while the vendor is open and the view has it: the only time a bag item may be sold.
function Merchant.Has()
    return shop ~= nil and open
end

-- The game's manager hears the show of its windows again. Safe at any time.
local function giveBack()
    if held then
        held = not ns.Adapter.MerchantHold(false)
        note(held and "the game's manager did not take back the show of its windows" or "the game's manager hears the show of its windows again", "back" .. tostring(held))
    end
end

-- True when the view may have the vendor that opens now.
local function wanted()
    local ok, on = pcall(ns.Registry.Get, ROW)
    if not ok then
        note("the row " .. ROW .. " is not in the settings: the view counts as on", "norow")
    end
    -- (root: the frames are made; after a login in a fight they are made when it ends)
    return root ~= nil and not off and (not ok or on) and not (ns.fightStarted or ns.Adapter.InCombat()) and ns.Adapter.DialoguePad() and true or false
end

-- The controller is the view's while a vendor shows. It is not while a window or a question of
-- the game has it, while the settings window is open, or in mouse mode (which has LT, RT and B).
-- Never called inside a press.
local function follow()
    local mine = shop ~= nil and ns.Adapter.GameplayHasPad() ~= false and not (ns.Settings and ns.Settings.IsOpen())
        and (ns.Adapter.PadWindowStyle() or not ns.Adapter.PopupShown())
    input:SetShown(mine and not (ns.Pointer and ns.Pointer.IsOn()) or false)
end

-- True while Mark Junk is on (its start value, On, while its row is not in the settings), so the
-- view's Sell tab shows the marks, a hold of Y marks, and X sells the marks too.
local function marking()
    local ok, on = pcall(ns.Registry.Get, MARK)
    return ns.JunkModel ~= nil and ns.Adapter.JunkMarks ~= nil and (not ok or on ~= false)
end

local function needs()
    local J = ns.JunkModel
    return J and ns.Adapter.QuestLog and J.Needs(ns.Adapter.QuestLog()) or {}
end

-- Everything the view shows, read from the game: the three lists, the gold, the repair, the junk.
local function read(s)
    Model.Fill(s, "buy", ns.Adapter.MerchantGoods())
    Model.Fill(s, "buyback", ns.Adapter.MerchantBuyback())
    local things, J = ns.Adapter.MerchantBags(), ns.JunkModel
    if J then
        local known = needs()
        for _, thing in ipairs(things) do
            thing.need = J.Needed(thing, known)
        end
    end
    s.marking = marking()
    Model.Fill(s, "sell", Model.Sellable(things, s.marking and ns.Adapter.JunkMarks() or {}))
    s.money, s.repairs = ns.Adapter.MerchantMoney(), ns.Adapter.MerchantRepairs()
    local cost, gold, guild = ns.Adapter.RepairCost()
    s.repair = cost and { cost = cost, gold = gold, guild = guild } or nil
    s.canJunk, s.junk = ns.Adapter.MerchantJunk()
end

local function draw()
    note(Draw.Show(shop, coins), "tip")
end

-- The line of the tabs row: a reason (how "say") or a question ("ask"), or nothing.
local function say(text, how)
    Draw.Line(text, how)
end

-- The vendor's lists changed (the game says so): read again and drawn again.
local function reread()
    if shop then
        read(shop)
        draw()
    end
end

-- A fault of the view, or the game's own window showed all the same. The view is off until the
-- next login. Its frames go one frame later (this can run inside a press); the manager hears
-- everything again; the vendor talk ends unless the game's own window has it.
local function fail(why)
    local had = (shop or wait) ~= nil
    if off and not had then
        return
    end
    off = off or why
    giveBack()
    note("the view is off until the next login: " .. tostring(why))
    shop, wait = nil, nil
    C_Timer.After(0, function()
        pcall(function()
            root:SetScript("OnUpdate", nil)
            root:Hide()
            input:Hide()
            Input.Rest()
            Watch.Set(false)
            if built then
                Draw.Rest()
            end
        end)
        local game = ns.Adapter.MerchantGameWindow()
        if had and open and not game then
            ns.Adapter.MerchantDo("close")
        end
        note("the game's own window has the vendor: " .. tostring(game))
        ns.Send("merchant:closed")
        ns.Print(game and "Merchant View is off until you type /reload. The game's own vendor window is back."
            or "Merchant View had a fault and is off until you type /reload. Talk to the vendor again for the game's own window.")
    end)
end

-- The vendor is closed: the view goes, and the controller is the game's again. now: at once,
-- with no fade (combat, no controller).
local function finish(now)
    local shown = shop ~= nil
    shop, wait = nil, nil
    giveBack()
    Input.Rest()
    if shown then
        Watch.Set(false)
        Draw.Rest()
        if now then
            Draw.Gone()
        else
            Draw.Fade(0, fail)
        end
        follow()
        ns.Send("merchant:closed")
    end
end

local function guarded(fn, ...)
    if not ns.Call("Merchant", fn, ...) then
        fail("a fault in the view")
    end
end

-- Combat or a controller that went: the view goes at once and the vendor talk ends, so nothing of
-- the view keeps a button and the next vendor has the game's own window. Plain calls only.
local function quit(why)
    giveBack()
    if shop or wait then
        note(why .. ": the view closes at once and the vendor talk ends")
        guarded(finish, true)
        ns.Adapter.MerchantDo("close")
    end
end

-- A full hold of Y on the Sell tab: the card's item is marked as junk or its mark goes (the chat
-- line of Mark Junk, Auto/JunkModel.lua Toggle), and the card keeps the focus where the list puts it
-- now (junk first). The bag window's coins are drawn again.
local function mark(thing)
    local text = ns.JunkModel.Toggle(ns.Adapter.JunkMarks(), thing, needs())
    ns.Print(text)
    note("a hold of Y on the Sell tab: " .. text, "mark")
    read(shop)
    for n, entry in ipairs(shop.lists.sell) do
        if entry.bag == thing.bag and entry.slot == thing.slot and entry.id == thing.id then
            shop.at.sell = n
        end
    end
    draw()
    if ns.JunkMark and ns.JunkMark.Later then
        ns.JunkMark.Later()
    end
end

-- A step of the game, one frame after the press that asked for it, while the vendor is open. X:
-- the game's own sale of the gray items, then the stacks marked as junk, one at a time at the game's
-- word (Auto/JunkSell.lua).
local function step(name, value, amount)
    C_Timer.After(0, function()
        if not (shop and open) then
            note(name .. " was not made: the vendor is closed")
            return
        elseif name == "mark" then
            return guarded(mark, value)
        end
        local ok, err = ns.Adapter.MerchantDo(name, value, amount)
        if not ok then
            note(name .. " did not run: " .. tostring(err))
        end
        if name == "junk" and shop.marking and select(2, Model.Junk(shop)) > 0 and ns.JunkSell and ns.JunkSell.Sell then
            note("X: the marked stacks are sold too: " .. tostring(ns.JunkSell.Sell()), "marked")
        end
    end)
end

-- ---------------------------------------------------------------- a vendor opens and closes
local function show()
    if not built then
        Draw.Build(root)
        built = true
    end
    local ok, size = pcall(ns.Registry.Get, SIZE)
    Draw.Scale(ok and size or 100)
    root:Show()
    shop = Model.New(ns.Adapter.MerchantWords())
    read(shop)
    local face, words = Draw.Face("npc", note)
    note("the portrait shows the " .. face .. " (" .. tostring(words) .. ")", "face")
    local starts, holds = 0, 0
    for _, item in ipairs(shop.lists.buy) do
        starts = starts + (item.questStart and 1 or 0)
    end
    for _, thing in ipairs(shop.lists.sell) do
        holds = holds + (thing.hasLoot and 1 or 0)
    end
    note("a vendor: " .. #shop.lists.buy .. " things to buy, " .. #shop.lists.sell .. " stacks to sell, " .. #shop.lists.buyback
        .. " to buy back; it repairs: " .. tostring(shop.repairs) .. "; cards with a quest start: " .. starts
        .. "; sell cards that hold things: " .. holds, "vendor")
    say(nil)
    draw()
    Watch.Set(true)
    Input.Fresh()
    Draw.Fade(1, fail)
    follow()
    ns.Send("merchant:opened")
end

-- One frame after MERCHANT_SHOW: the manager hears everything again, and the view shows when the
-- game's own window stayed away.
local function begin()
    local now = wait
    wait = nil
    giveBack()
    if not (now and open) then
        return
    elseif ns.Adapter.MerchantGameWindow() then
        fail("the game's own vendor window showed")
    elseif shop then
        reread()
    else
        show()
    end
end

-- The game said MERCHANT_SHOW (it can say it again for the vendor that is open).
local function opened()
    open = true
    if ns.Adapter.MerchantGameWindow() then
        -- the game's window showed in this same moment, before MERCHANT_SHOW: on this game build
        -- the view cannot keep it shut
        if wanted() and shownAt == GetTime() then
            off = "the game opens its vendor window before it says MERCHANT_SHOW"
            note("the view stays off for this session: " .. off)
            ns.Print("Merchant View is off: this game build opens its own vendor window first.")
        end
        return
    elseif not (shop or wanted()) then
        return
    end
    held = ns.Adapter.MerchantHold(true)
    note("MERCHANT_SHOW came: the game's manager does not hear the show of its windows for one frame: " .. tostring(held), "hold")
    if not held then
        -- the game did not let the show be held: it is asked back at once, and the game's window opens
        ns.Adapter.MerchantHold(false)
        return
    end
    wait = { at = GetTime() }
    C_Timer.After(0, function()
        guarded(begin)
    end)
end

-- The game told the manager to show its vendor window (the manager did not hear it while held).
local function heard()
    note("the manager's show for the vendor came " .. (wait and "after MERCHANT_SHOW: the manager did not hear it: " .. tostring(held)
        or "before MERCHANT_SHOW (the game's window has the vendor: " .. tostring(ns.Adapter.MerchantGameWindow()) .. ")"), "order")
end

-- The game said MERCHANT_CLOSED.
local function closed()
    open = false
    guarded(finish)
end

-- The game's own vendor window showed. Told inside the game's code: the view acts one frame later,
-- when the window still shows.
local function gameWindow()
    shownAt = GetTime()
    C_Timer.After(0, function()
        if (shop or wait) and ns.Adapter.MerchantGameWindow() then
            fail("the game's own vendor window showed while the view had the vendor")
        end
    end)
end

-- A window or a question of the game took the controller or gave it back, or the settings window
-- opened or closed, or mouse mode changed: the view follows one frame later.
local function later()
    if shop then
        C_Timer.After(0, function()
            if shop then
                follow()
            end
        end)
    end
end

function Merchant.OnLogin()
    local side = { note = note, guarded = guarded, step = step, draw = draw, say = say, reread = reread, fail = fail, quit = quit,
        opened = opened, closed = closed, heard = heard, gameWindow = gameWindow, later = later, coins = coins,
        shop = function() return shop end, busy = function() return shop or wait end }
    if not ns.Adapter.MerchantManager() then
        off = "the game's interaction manager was not found"
    end
    note("the game's interaction manager was found: " .. tostring(off == nil), "manager")
    -- the frames are made at login and out of combat (Screen/MerchantInput.lua says why)
    ns.Queue.Run("Merchant", function()
        root = CreateFrame("Frame", "GamepadSuiteMerchant", UIParent)
        root:SetAlpha(0)
        root:Hide()
        input = Input.Build(root, side)
    end)
    Watch.Login(side)
end
